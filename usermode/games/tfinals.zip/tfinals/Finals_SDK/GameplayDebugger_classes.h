// Class GameplayDebugger.GameplayDebuggerCategoryReplicator
// Size: 0x460 (Inherited: 0x3a0)
struct AGameplayDebuggerCategoryReplicator : AActor {
	struct APlayerController* OwnerPC; // 0x398(0x08)
	bool bIsEnabled; // 0x3a0(0x01)
	struct FGameplayDebuggerNetPack ReplicatedData; // 0x3a8(0x18)
	struct FGameplayDebuggerDebugActor DebugActor; // 0x3c0(0x14)
	char pad_3d5[0x3]; // 0x3d5(0x03)
	struct FGameplayDebuggerVisLogSync VisLogSync; // 0x3d8(0x10)
	struct UGameplayDebuggerRenderingComponent* RenderingComp; // 0x3e8(0x08)
	char pad_3f0[0x70]; // 0x3f0(0x70)

	void ServerSetViewPoint(struct FVector InViewLocation, struct FVector InViewDirection); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetViewPoint // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|HasDefaults|NetValidate) // @ game+0x5a5dea0
	void ServerSetEnabled(bool bEnable); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetEnabled // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x5a4bfb0
	void ServerSetDebugActor(struct AActor* Actor, bool bSelectInEditor); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetDebugActor // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x5a4c5d0
	void ServerSetCategoryEnabled(int32_t CategoryId, bool bEnable); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSetCategoryEnabled // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x5a5e650
	void ServerSendExtensionInputEvent(int32_t ExtensionId, int32_t HandlerId); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSendExtensionInputEvent // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x5a52860
	void ServerSendCategoryInputEvent(int32_t CategoryId, int32_t HandlerId); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerSendCategoryInputEvent // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x5a50520
	void ServerResetViewPoint(); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ServerResetViewPoint // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x5a4c500
	void OnRep_ReplicatedData(); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.OnRep_ReplicatedData // (Final|RequiredAPI|Native|Protected) // @ game+0x5a567a0
	void ClientDataPackPacket(struct FGameplayDebuggerDataPackRPCParams Params); // Function GameplayDebugger.GameplayDebuggerCategoryReplicator.ClientDataPackPacket // (RequiredAPI|Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x5a56b60
};

// Class GameplayDebugger.GameplayDebuggerConfig
// Size: 0x2d0 (Inherited: 0xa0)
struct UGameplayDebuggerConfig : UObject {
	struct FKey ActivationKey; // 0x98(0x18)
	struct FKey CategoryRowNextKey; // 0xb0(0x18)
	struct FKey CategoryRowPrevKey; // 0xc8(0x18)
	struct FKey CategorySlot0; // 0xe0(0x18)
	struct FKey CategorySlot1; // 0xf8(0x18)
	struct FKey CategorySlot2; // 0x110(0x18)
	struct FKey CategorySlot3; // 0x128(0x18)
	struct FKey CategorySlot4; // 0x140(0x18)
	struct FKey CategorySlot5; // 0x158(0x18)
	struct FKey CategorySlot6; // 0x170(0x18)
	struct FKey CategorySlot7; // 0x188(0x18)
	struct FKey CategorySlot8; // 0x1a0(0x18)
	struct FKey CategorySlot9; // 0x1b8(0x18)
	float DebugCanvasPaddingLeft; // 0x1d0(0x04)
	float DebugCanvasPaddingRight; // 0x1d4(0x04)
	float DebugCanvasPaddingTop; // 0x1d8(0x04)
	float DebugCanvasPaddingBottom; // 0x1dc(0x04)
	bool bDebugCanvasEnableTextShadow; // 0x1e0(0x01)
	struct TArray<struct FGameplayDebuggerCategoryConfig> Categories; // 0x1e8(0x10)
	struct TArray<struct FGameplayDebuggerExtensionConfig> Extensions; // 0x1f8(0x10)
	char pad_209[0xc7]; // 0x209(0xc7)
};

// Class GameplayDebugger.GameplayDebuggerUserSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UGameplayDebuggerUserSettings : UDeveloperSettings {
	char bEnableGameplayDebuggerInEditor : 1; // 0xa8(0x01)
	float MaxViewDistance; // 0xac(0x04)
	float MaxViewAngle; // 0xb0(0x04)
	int32_t FontSize; // 0xb4(0x04)
	char pad_bc_1 : 7; // 0xbc(0x01)
	char pad_bd[0x3]; // 0xbd(0x03)
};

// Class GameplayDebugger.GameplayDebuggerLocalController
// Size: 0x100 (Inherited: 0xa0)
struct UGameplayDebuggerLocalController : UObject {
	struct AGameplayDebuggerCategoryReplicator* CachedReplicator; // 0x98(0x08)
	struct AGameplayDebuggerPlayerManager* CachedPlayerManager; // 0xa0(0x08)
	struct AActor* DebugActorCandidate; // 0xa8(0x08)
	struct UFont* HUDFont; // 0xb0(0x08)
	char pad_c0[0x40]; // 0xc0(0x40)
};

// Class GameplayDebugger.GameplayDebuggerPlayerManager
// Size: 0x3d0 (Inherited: 0x3a0)
struct AGameplayDebuggerPlayerManager : AActor {
	struct TArray<struct FGameplayDebuggerPlayerData> PlayerData; // 0x3a0(0x10)
	struct TArray<struct AGameplayDebuggerCategoryReplicator*> PendingRegistrations; // 0x3b0(0x10)
	char pad_3c0[0x10]; // 0x3c0(0x10)
};

// Class GameplayDebugger.GameplayDebuggerRenderingComponent
// Size: 0x770 (Inherited: 0x710)
struct UGameplayDebuggerRenderingComponent : UDebugDrawComponent {
	char pad_710[0x60]; // 0x710(0x60)
};

