// Class PhysicsCore.PhysicalMaterialPropertyBase
// Size: 0xa0 (Inherited: 0xa0)
struct UPhysicalMaterialPropertyBase : UObject {
};

// Class PhysicsCore.BodySetupCore
// Size: 0xc0 (Inherited: 0xa0)
struct UBodySetupCore : UObject {
	struct FName BoneName; // 0x98(0x08)
	enum class EPhysicsType PhysicsType; // 0xa0(0x01)
	enum class ECollisionTraceFlag CollisionTraceFlag; // 0xa1(0x01)
	enum class EBodyCollisionResponse CollisionReponse; // 0xa2(0x01)
	char pad_ab[0x15]; // 0xab(0x15)
};

// Class PhysicsCore.ChaosPhysicalMaterial
// Size: 0xc0 (Inherited: 0xa0)
struct UChaosPhysicalMaterial : UObject {
	float Friction; // 0x98(0x04)
	float StaticFriction; // 0x9c(0x04)
	float Restitution; // 0xa0(0x04)
	float LinearEtherDrag; // 0xa4(0x04)
	float AngularEtherDrag; // 0xa8(0x04)
	float SleepingLinearVelocityThreshold; // 0xac(0x04)
	float SleepingAngularVelocityThreshold; // 0xb0(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// Class PhysicsCore.PhysicalMaterial
// Size: 0x100 (Inherited: 0xa0)
struct UPhysicalMaterial : UObject {
	float Friction; // 0x98(0x04)
	float StaticFriction; // 0x9c(0x04)
	enum class EFrictionCombineMode FrictionCombineMode; // 0xa0(0x01)
	bool bOverrideFrictionCombineMode; // 0xa1(0x01)
	float Restitution; // 0xa4(0x04)
	enum class EFrictionCombineMode RestitutionCombineMode; // 0xa8(0x01)
	bool bOverrideRestitutionCombineMode; // 0xa9(0x01)
	float Density; // 0xac(0x04)
	float SleepLinearVelocityThreshold; // 0xb0(0x04)
	float SleepAngularVelocityThreshold; // 0xb4(0x04)
	int32_t SleepCounterThreshold; // 0xb8(0x04)
	float RaiseMassToPower; // 0xbc(0x04)
	float DestructibleDamageThresholdScale; // 0xc0(0x04)
	struct UPhysicalMaterialPropertyBase* PhysicalMaterialProperty; // 0xc8(0x08)
	enum class EPhysicalSurface SurfaceType; // 0xd0(0x01)
	char pad_d1[0x3]; // 0xd1(0x03)
	struct FPhysicalMaterialStrength Strength; // 0xd4(0x0c)
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class PhysicsCore.PhysicsSettingsCore
// Size: 0x150 (Inherited: 0xb0)
struct UPhysicsSettingsCore : UDeveloperSettings {
	float DefaultGravityZ; // 0xa8(0x04)
	float DefaultTerminalVelocity; // 0xac(0x04)
	float DefaultFluidFriction; // 0xb0(0x04)
	int32_t SimulateScratchMemorySize; // 0xb4(0x04)
	int32_t RagdollAggregateThreshold; // 0xb8(0x04)
	float TriangleMeshTriangleMinAreaThreshold; // 0xbc(0x04)
	bool bEnableEnhancedDeterminism; // 0xc0(0x01)
	bool bEnableShapeSharing; // 0xc1(0x01)
	bool bEnablePCM; // 0xc2(0x01)
	bool bEnableStabilization; // 0xc3(0x01)
	bool bWarnMissingLocks; // 0xc4(0x01)
	bool bEnable2DPhysics; // 0xc5(0x01)
	bool bDefaultHasComplexCollision; // 0xc6(0x01)
	float BounceThresholdVelocity; // 0xc8(0x04)
	enum class EFrictionCombineMode FrictionCombineMode; // 0xcc(0x01)
	enum class EFrictionCombineMode RestitutionCombineMode; // 0xcd(0x01)
	float MaxAngularVelocity; // 0xd0(0x04)
	float MaxDepenetrationVelocity; // 0xd4(0x04)
	float ContactOffsetMultiplier; // 0xd8(0x04)
	float MinContactOffset; // 0xdc(0x04)
	float MaxContactOffset; // 0xe0(0x04)
	bool bSimulateSkeletalMeshOnDedicatedServer; // 0xe4(0x01)
	enum class ECollisionTraceFlag DefaultShapeComplexity; // 0xe5(0x01)
	struct FChaosSolverConfiguration SolverOptions; // 0xe8(0x68)
};

