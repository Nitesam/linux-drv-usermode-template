// Class PacketHandler.HandlerComponentFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UHandlerComponentFactory : UObject {
};

// Class PacketHandler.PacketHandlerProfileConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UPacketHandlerProfileConfig : UObject {
	struct TArray<struct FString> Components; // 0x98(0x10)
};

