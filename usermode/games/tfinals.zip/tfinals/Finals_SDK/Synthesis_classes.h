// Class Synthesis.AudioImpulseResponse
// Size: 0xd0 (Inherited: 0xa0)
struct UAudioImpulseResponse : UObject {
	struct TArray<float> ImpulseResponse; // 0x98(0x10)
	int32_t NumChannels; // 0xa8(0x04)
	int32_t SampleRate; // 0xac(0x04)
	float NormalizationVolumeDb; // 0xb0(0x04)
	bool bTrueStereo; // 0xb4(0x01)
	struct TArray<float> IRData; // 0xb8(0x10)
	char pad_cd[0x3]; // 0xcd(0x03)
};

// Class Synthesis.ModularSynthPresetBank
// Size: 0xb0 (Inherited: 0xa0)
struct UModularSynthPresetBank : UObject {
	struct TArray<struct FModularSynthPresetBankEntry> Presets; // 0x98(0x10)
};

// Class Synthesis.ModularSynthLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UModularSynthLibrary : UBlueprintFunctionLibrary {

	void AddModularSynthPresetToBankAsset(struct UModularSynthPresetBank* InBank, struct FModularSynthPreset& Preset, struct FString PresetName); // Function Synthesis.ModularSynthLibrary.AddModularSynthPresetToBankAsset // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6133440
};

// Class Synthesis.ModularSynthComponent
// Size: 0x10f0 (Inherited: 0xa20)
struct UModularSynthComponent : USynthComponent {
	int32_t VoiceCount; // 0xa20(0x04)
	char pad_a24[0x6cc]; // 0xa24(0x6cc)

	void SetSynthPreset(struct FModularSynthPreset& SynthPreset); // Function Synthesis.ModularSynthComponent.SetSynthPreset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6142ca0
	void SetSustainGain(float SustainGain); // Function Synthesis.ModularSynthComponent.SetSustainGain // (Final|Native|Public|BlueprintCallable) // @ game+0x60f50a0
	void SetStereoDelayWetlevel(float DelayWetlevel); // Function Synthesis.ModularSynthComponent.SetStereoDelayWetlevel // (Final|Native|Public|BlueprintCallable) // @ game+0x61042a0
	void SetStereoDelayTime(float DelayTimeMsec); // Function Synthesis.ModularSynthComponent.SetStereoDelayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6113630
	void SetStereoDelayRatio(float DelayRatio); // Function Synthesis.ModularSynthComponent.SetStereoDelayRatio // (Final|Native|Public|BlueprintCallable) // @ game+0x611e3a0
	void SetStereoDelayMode(enum class ESynthStereoDelayMode StereoDelayMode); // Function Synthesis.ModularSynthComponent.SetStereoDelayMode // (Final|Native|Public|BlueprintCallable) // @ game+0x60f42f0
	void SetStereoDelayIsEnabled(bool StereoDelayEnabled); // Function Synthesis.ModularSynthComponent.SetStereoDelayIsEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x614a690
	void SetStereoDelayFeedback(float DelayFeedback); // Function Synthesis.ModularSynthComponent.SetStereoDelayFeedback // (Final|Native|Public|BlueprintCallable) // @ game+0x613b390
	void SetSpread(float Spread); // Function Synthesis.ModularSynthComponent.SetSpread // (Final|Native|Public|BlueprintCallable) // @ game+0x6143f60
	void SetReleaseTime(float ReleaseTimeMsec); // Function Synthesis.ModularSynthComponent.SetReleaseTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6124cf0
	void SetPortamento(float Portamento); // Function Synthesis.ModularSynthComponent.SetPortamento // (Final|Native|Public|BlueprintCallable) // @ game+0x60f6480
	void SetPitchBend(float PitchBend); // Function Synthesis.ModularSynthComponent.SetPitchBend // (Final|Native|Public|BlueprintCallable) // @ game+0x61444c0
	void SetPan(float Pan); // Function Synthesis.ModularSynthComponent.SetPan // (Final|Native|Public|BlueprintCallable) // @ game+0x61382d0
	void SetOscType(int32_t OscIndex, enum class ESynth1OscType OscType); // Function Synthesis.ModularSynthComponent.SetOscType // (Final|Native|Public|BlueprintCallable) // @ game+0x60fab60
	void SetOscSync(bool bIsSynced); // Function Synthesis.ModularSynthComponent.SetOscSync // (Final|Native|Public|BlueprintCallable) // @ game+0x61205c0
	void SetOscSemitones(int32_t OscIndex, float Semitones); // Function Synthesis.ModularSynthComponent.SetOscSemitones // (Final|Native|Public|BlueprintCallable) // @ game+0x6149950
	void SetOscPulsewidth(int32_t OscIndex, float Pulsewidth); // Function Synthesis.ModularSynthComponent.SetOscPulsewidth // (Final|Native|Public|BlueprintCallable) // @ game+0x60f1610
	void SetOscOctave(int32_t OscIndex, float Octave); // Function Synthesis.ModularSynthComponent.SetOscOctave // (Final|Native|Public|BlueprintCallable) // @ game+0x61429d0
	void SetOscGainMod(int32_t OscIndex, float OscGainMod); // Function Synthesis.ModularSynthComponent.SetOscGainMod // (Final|Native|Public|BlueprintCallable) // @ game+0x6106140
	void SetOscGain(int32_t OscIndex, float OscGain); // Function Synthesis.ModularSynthComponent.SetOscGain // (Final|Native|Public|BlueprintCallable) // @ game+0x60f8170
	void SetOscFrequencyMod(int32_t OscIndex, float OscFreqMod); // Function Synthesis.ModularSynthComponent.SetOscFrequencyMod // (Final|Native|Public|BlueprintCallable) // @ game+0x612c770
	void SetOscCents(int32_t OscIndex, float Cents); // Function Synthesis.ModularSynthComponent.SetOscCents // (Final|Native|Public|BlueprintCallable) // @ game+0x6137260
	void SetModEnvSustainGain(float SustainGain); // Function Synthesis.ModularSynthComponent.SetModEnvSustainGain // (Final|Native|Public|BlueprintCallable) // @ game+0x6111060
	void SetModEnvReleaseTime(float Release); // Function Synthesis.ModularSynthComponent.SetModEnvReleaseTime // (Final|Native|Public|BlueprintCallable) // @ game+0x60f3ac0
	void SetModEnvPatch(enum class ESynthModEnvPatch InPatchType); // Function Synthesis.ModularSynthComponent.SetModEnvPatch // (Final|Native|Public|BlueprintCallable) // @ game+0x613d570
	void SetModEnvInvert(bool bInvert); // Function Synthesis.ModularSynthComponent.SetModEnvInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x6124c20
	void SetModEnvDepth(float Depth); // Function Synthesis.ModularSynthComponent.SetModEnvDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x60e6cd0
	void SetModEnvDecayTime(float DecayTimeMsec); // Function Synthesis.ModularSynthComponent.SetModEnvDecayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6113700
	void SetModEnvBiasPatch(enum class ESynthModEnvBiasPatch InPatchType); // Function Synthesis.ModularSynthComponent.SetModEnvBiasPatch // (Final|Native|Public|BlueprintCallable) // @ game+0x6108650
	void SetModEnvBiasInvert(bool bInvert); // Function Synthesis.ModularSynthComponent.SetModEnvBiasInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x610eed0
	void SetModEnvAttackTime(float AttackTimeMsec); // Function Synthesis.ModularSynthComponent.SetModEnvAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6149af0
	void SetLFOType(int32_t LFOIndex, enum class ESynthLFOType LFOType); // Function Synthesis.ModularSynthComponent.SetLFOType // (Final|Native|Public|BlueprintCallable) // @ game+0x6149630
	void SetLFOPatch(int32_t LFOIndex, enum class ESynthLFOPatchType LFOPatchType); // Function Synthesis.ModularSynthComponent.SetLFOPatch // (Final|Native|Public|BlueprintCallable) // @ game+0x6146a60
	void SetLFOMode(int32_t LFOIndex, enum class ESynthLFOMode LFOMode); // Function Synthesis.ModularSynthComponent.SetLFOMode // (Final|Native|Public|BlueprintCallable) // @ game+0x60fdb00
	void SetLFOGainMod(int32_t LFOIndex, float GainMod); // Function Synthesis.ModularSynthComponent.SetLFOGainMod // (Final|Native|Public|BlueprintCallable) // @ game+0x6146870
	void SetLFOGain(int32_t LFOIndex, float Gain); // Function Synthesis.ModularSynthComponent.SetLFOGain // (Final|Native|Public|BlueprintCallable) // @ game+0x613a410
	void SetLFOFrequencyMod(int32_t LFOIndex, float FrequencyModHz); // Function Synthesis.ModularSynthComponent.SetLFOFrequencyMod // (Final|Native|Public|BlueprintCallable) // @ game+0x6106470
	void SetLFOFrequency(int32_t LFOIndex, float FrequencyHz); // Function Synthesis.ModularSynthComponent.SetLFOFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x613c5c0
	void SetGainDb(float GainDb); // Function Synthesis.ModularSynthComponent.SetGainDb // (Final|Native|Public|BlueprintCallable) // @ game+0x6138150
	void SetFilterType(enum class ESynthFilterType FilterType); // Function Synthesis.ModularSynthComponent.SetFilterType // (Final|Native|Public|BlueprintCallable) // @ game+0x6133930
	void SetFilterQMod(float FilterQ); // Function Synthesis.ModularSynthComponent.SetFilterQMod // (Final|Native|Public|BlueprintCallable) // @ game+0x6132160
	void SetFilterQ(float FilterQ); // Function Synthesis.ModularSynthComponent.SetFilterQ // (Final|Native|Public|BlueprintCallable) // @ game+0x6103e00
	void SetFilterFrequencyMod(float FilterFrequencyHz); // Function Synthesis.ModularSynthComponent.SetFilterFrequencyMod // (Final|Native|Public|BlueprintCallable) // @ game+0x61385a0
	void SetFilterFrequency(float FilterFrequencyHz); // Function Synthesis.ModularSynthComponent.SetFilterFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x6111b30
	void SetFilterAlgorithm(enum class ESynthFilterAlgorithm FilterAlgorithm); // Function Synthesis.ModularSynthComponent.SetFilterAlgorithm // (Final|Native|Public|BlueprintCallable) // @ game+0x612cbf0
	void SetEnableUnison(bool EnableUnison); // Function Synthesis.ModularSynthComponent.SetEnableUnison // (Final|Native|Public|BlueprintCallable) // @ game+0x6121310
	void SetEnableRetrigger(bool RetriggerEnabled); // Function Synthesis.ModularSynthComponent.SetEnableRetrigger // (Final|Native|Public|BlueprintCallable) // @ game+0x610cd50
	void SetEnablePolyphony(bool bEnablePolyphony); // Function Synthesis.ModularSynthComponent.SetEnablePolyphony // (Final|Native|Public|BlueprintCallable) // @ game+0x6119a50
	bool SetEnablePatch(struct FPatchId PatchId, bool bIsEnabled); // Function Synthesis.ModularSynthComponent.SetEnablePatch // (Final|Native|Public|BlueprintCallable) // @ game+0x61215e0
	void SetEnableLegato(bool LegatoEnabled); // Function Synthesis.ModularSynthComponent.SetEnableLegato // (Final|Native|Public|BlueprintCallable) // @ game+0x60f07f0
	void SetDecayTime(float DecayTimeMsec); // Function Synthesis.ModularSynthComponent.SetDecayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6111350
	void SetChorusFrequency(float Frequency); // Function Synthesis.ModularSynthComponent.SetChorusFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x6119960
	void SetChorusFeedback(float Feedback); // Function Synthesis.ModularSynthComponent.SetChorusFeedback // (Final|Native|Public|BlueprintCallable) // @ game+0x6127e30
	void SetChorusEnabled(bool EnableChorus); // Function Synthesis.ModularSynthComponent.SetChorusEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x6138fc0
	void SetChorusDepth(float Depth); // Function Synthesis.ModularSynthComponent.SetChorusDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x60fa0c0
	void SetAttackTime(float AttackTimeMsec); // Function Synthesis.ModularSynthComponent.SetAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x61310b0
	void NoteOn(float Note, int32_t Velocity, float Duration); // Function Synthesis.ModularSynthComponent.NoteOn // (Final|Native|Public|BlueprintCallable) // @ game+0x6104970
	void NoteOff(float Note, bool bAllNotesOff, bool bKillAllNotes); // Function Synthesis.ModularSynthComponent.NoteOff // (Final|Native|Public|BlueprintCallable) // @ game+0x60f1cb0
	struct FPatchId CreatePatch(enum class ESynth1PatchSource PatchSource, struct TArray<struct FSynth1PatchCable>& PatchCables, bool bEnableByDefault); // Function Synthesis.ModularSynthComponent.CreatePatch // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6142010
};

// Class Synthesis.SourceEffectBitCrusherPreset
// Size: 0x280 (Inherited: 0xe0)
struct USourceEffectBitCrusherPreset : USoundEffectSourcePreset {
	char pad_e0[0xe0]; // 0xe0(0xe0)
	struct FSourceEffectBitCrusherSettings Settings; // 0x1c0(0xc0)

	void SetSettings(struct FSourceEffectBitCrusherBaseSettings& Settings); // Function Synthesis.SourceEffectBitCrusherPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6122e60
	void SetSampleRateModulators(struct TSet<struct USoundModulatorBase*>& InModulators); // Function Synthesis.SourceEffectBitCrusherPreset.SetSampleRateModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6118e10
	void SetSampleRateModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectBitCrusherPreset.SetSampleRateModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x60f4960
	void SetSampleRate(float SampleRate); // Function Synthesis.SourceEffectBitCrusherPreset.SetSampleRate // (Final|Native|Public|BlueprintCallable) // @ game+0x610a5d0
	void SetModulationSettings(struct FSourceEffectBitCrusherSettings& ModulationSettings); // Function Synthesis.SourceEffectBitCrusherPreset.SetModulationSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x612b620
	void SetBits(float Bits); // Function Synthesis.SourceEffectBitCrusherPreset.SetBits // (Final|Native|Public|BlueprintCallable) // @ game+0x611dae0
	void SetBitModulators(struct TSet<struct USoundModulatorBase*>& InModulators); // Function Synthesis.SourceEffectBitCrusherPreset.SetBitModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60f2840
	void SetBitModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectBitCrusherPreset.SetBitModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x6126580
};

// Class Synthesis.SourceEffectChorusPreset
// Size: 0x550 (Inherited: 0xe0)
struct USourceEffectChorusPreset : USoundEffectSourcePreset {
	char pad_e0[0x248]; // 0xe0(0x248)
	struct FSourceEffectChorusSettings Settings; // 0x328(0x228)

	void SetWetModulators(struct TSet<struct USoundModulatorBase*>& Modulators); // Function Synthesis.SourceEffectChorusPreset.SetWetModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x611f320
	void SetWetModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectChorusPreset.SetWetModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x6104c00
	void SetWet(float WetAmount); // Function Synthesis.SourceEffectChorusPreset.SetWet // (Final|Native|Public|BlueprintCallable) // @ game+0x6132ef0
	void SetSpreadModulators(struct TSet<struct USoundModulatorBase*>& Modulators); // Function Synthesis.SourceEffectChorusPreset.SetSpreadModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6100730
	void SetSpreadModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectChorusPreset.SetSpreadModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x6106dd0
	void SetSpread(float Spread); // Function Synthesis.SourceEffectChorusPreset.SetSpread // (Final|Native|Public|BlueprintCallable) // @ game+0x612d4c0
	void SetSettings(struct FSourceEffectChorusBaseSettings& Settings); // Function Synthesis.SourceEffectChorusPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6104120
	void SetModulationSettings(struct FSourceEffectChorusSettings& ModulationSettings); // Function Synthesis.SourceEffectChorusPreset.SetModulationSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60e6f90
	void SetFrequencyModulators(struct TSet<struct USoundModulatorBase*>& Modulators); // Function Synthesis.SourceEffectChorusPreset.SetFrequencyModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60ffe70
	void SetFrequencyModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectChorusPreset.SetFrequencyModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x610cbd0
	void SetFrequency(float Frequency); // Function Synthesis.SourceEffectChorusPreset.SetFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x60f8f60
	void SetFeedbackModulators(struct TSet<struct USoundModulatorBase*>& Modulators); // Function Synthesis.SourceEffectChorusPreset.SetFeedbackModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x613b200
	void SetFeedbackModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectChorusPreset.SetFeedbackModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x6114bd0
	void SetFeedback(float Feedback); // Function Synthesis.SourceEffectChorusPreset.SetFeedback // (Final|Native|Public|BlueprintCallable) // @ game+0x612bc20
	void SetDryModulators(struct TSet<struct USoundModulatorBase*>& Modulators); // Function Synthesis.SourceEffectChorusPreset.SetDryModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60ff540
	void SetDryModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectChorusPreset.SetDryModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x611bbe0
	void SetDry(float DryAmount); // Function Synthesis.SourceEffectChorusPreset.SetDry // (Final|Native|Public|BlueprintCallable) // @ game+0x6104f90
	void SetDepthModulators(struct TSet<struct USoundModulatorBase*>& Modulators); // Function Synthesis.SourceEffectChorusPreset.SetDepthModulators // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x61118c0
	void SetDepthModulator(struct USoundModulatorBase* Modulator); // Function Synthesis.SourceEffectChorusPreset.SetDepthModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x610a160
	void SetDepth(float Depth); // Function Synthesis.SourceEffectChorusPreset.SetDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x6123670
};

// Class Synthesis.SourceEffectConvolutionReverbPreset
// Size: 0x130 (Inherited: 0xe0)
struct USourceEffectConvolutionReverbPreset : USoundEffectSourcePreset {
	struct UAudioImpulseResponse* ImpulseResponse; // 0xd8(0x08)
	struct FSourceEffectConvolutionReverbSettings Settings; // 0xe0(0x10)
	enum class ESubmixEffectConvolutionReverbBlockSize BlockSize; // 0xf0(0x01)
	bool bEnableHardwareAcceleration; // 0xf1(0x01)
	char pad_fa[0x36]; // 0xfa(0x36)

	void SetSettings(struct FSourceEffectConvolutionReverbSettings& InSettings); // Function Synthesis.SourceEffectConvolutionReverbPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6130f30
	void SetImpulseResponse(struct UAudioImpulseResponse* InImpulseResponse); // Function Synthesis.SourceEffectConvolutionReverbPreset.SetImpulseResponse // (Final|Native|Public|BlueprintCallable) // @ game+0x6121170
};

// Class Synthesis.SourceEffectDynamicsProcessorPreset
// Size: 0x150 (Inherited: 0xe0)
struct USourceEffectDynamicsProcessorPreset : USoundEffectSourcePreset {
	char pad_e0[0x48]; // 0xe0(0x48)
	struct FSourceEffectDynamicsProcessorSettings Settings; // 0x128(0x28)

	void SetSettings(struct FSourceEffectDynamicsProcessorSettings& InSettings); // Function Synthesis.SourceEffectDynamicsProcessorPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6116b60
};

// Class Synthesis.EnvelopeFollowerListener
// Size: 0x180 (Inherited: 0x160)
struct UEnvelopeFollowerListener : UActorComponent {
	struct FMulticastInlineDelegate OnEnvelopeFollowerUpdate; // 0x158(0x10)
	char pad_170[0x10]; // 0x170(0x10)
};

// Class Synthesis.SourceEffectEnvelopeFollowerPreset
// Size: 0x120 (Inherited: 0xe0)
struct USourceEffectEnvelopeFollowerPreset : USoundEffectSourcePreset {
	char pad_e0[0x2c]; // 0xe0(0x2c)
	struct FSourceEffectEnvelopeFollowerSettings Settings; // 0x10c(0x0c)
	char pad_118[0x8]; // 0x118(0x08)

	void UnregisterEnvelopeFollowerListener(struct UEnvelopeFollowerListener* EnvelopeFollowerListener); // Function Synthesis.SourceEffectEnvelopeFollowerPreset.UnregisterEnvelopeFollowerListener // (Final|Native|Public|BlueprintCallable) // @ game+0x6135740
	void SetSettings(struct FSourceEffectEnvelopeFollowerSettings& InSettings); // Function Synthesis.SourceEffectEnvelopeFollowerPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6149ef0
	void RegisterEnvelopeFollowerListener(struct UEnvelopeFollowerListener* EnvelopeFollowerListener); // Function Synthesis.SourceEffectEnvelopeFollowerPreset.RegisterEnvelopeFollowerListener // (Final|Native|Public|BlueprintCallable) // @ game+0x6113580
};

// Class Synthesis.SourceEffectEQPreset
// Size: 0x120 (Inherited: 0xe0)
struct USourceEffectEQPreset : USoundEffectSourcePreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSourceEffectEQSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSourceEffectEQSettings& InSettings); // Function Synthesis.SourceEffectEQPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad84d0
};

// Class Synthesis.SourceEffectFilterPreset
// Size: 0x140 (Inherited: 0xe0)
struct USourceEffectFilterPreset : USoundEffectSourcePreset {
	char pad_e0[0x40]; // 0xe0(0x40)
	struct FSourceEffectFilterSettings Settings; // 0x120(0x20)

	void SetSettings(struct FSourceEffectFilterSettings& InSettings); // Function Synthesis.SourceEffectFilterPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x612d0f0
};

// Class Synthesis.SourceEffectFoldbackDistortionPreset
// Size: 0x120 (Inherited: 0xe0)
struct USourceEffectFoldbackDistortionPreset : USoundEffectSourcePreset {
	char pad_e0[0x2c]; // 0xe0(0x2c)
	struct FSourceEffectFoldbackDistortionSettings Settings; // 0x10c(0x0c)
	char pad_118[0x8]; // 0x118(0x08)

	void SetSettings(struct FSourceEffectFoldbackDistortionSettings& InSettings); // Function Synthesis.SourceEffectFoldbackDistortionPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60e73e0
};

// Class Synthesis.SourceEffectMidSideSpreaderPreset
// Size: 0x110 (Inherited: 0xe0)
struct USourceEffectMidSideSpreaderPreset : USoundEffectSourcePreset {
	char pad_e0[0x28]; // 0xe0(0x28)
	struct FSourceEffectMidSideSpreaderSettings Settings; // 0x108(0x08)

	void SetSettings(struct FSourceEffectMidSideSpreaderSettings& InSettings); // Function Synthesis.SourceEffectMidSideSpreaderPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60fb030
};

// Class Synthesis.SourceEffectMotionFilterPreset
// Size: 0x1f0 (Inherited: 0xe0)
struct USourceEffectMotionFilterPreset : USoundEffectSourcePreset {
	char pad_e0[0x98]; // 0xe0(0x98)
	struct FSourceEffectMotionFilterSettings Settings; // 0x178(0x78)

	void SetSettings(struct FSourceEffectMotionFilterSettings& InSettings); // Function Synthesis.SourceEffectMotionFilterPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6131800
};

// Class Synthesis.SourceEffectPannerPreset
// Size: 0x110 (Inherited: 0xe0)
struct USourceEffectPannerPreset : USoundEffectSourcePreset {
	char pad_e0[0x28]; // 0xe0(0x28)
	struct FSourceEffectPannerSettings Settings; // 0x108(0x08)

	void SetSettings(struct FSourceEffectPannerSettings& InSettings); // Function Synthesis.SourceEffectPannerPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60f36f0
};

// Class Synthesis.SourceEffectPhaserPreset
// Size: 0x120 (Inherited: 0xe0)
struct USourceEffectPhaserPreset : USoundEffectSourcePreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSourceEffectPhaserSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSourceEffectPhaserSettings& InSettings); // Function Synthesis.SourceEffectPhaserPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x61375f0
};

// Class Synthesis.SourceEffectRingModulationPreset
// Size: 0x140 (Inherited: 0xe0)
struct USourceEffectRingModulationPreset : USoundEffectSourcePreset {
	char pad_e0[0x40]; // 0xe0(0x40)
	struct FSourceEffectRingModulationSettings Settings; // 0x120(0x20)

	void SetSettings(struct FSourceEffectRingModulationSettings& InSettings); // Function Synthesis.SourceEffectRingModulationPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6127f00
};

// Class Synthesis.SourceEffectSimpleDelayPreset
// Size: 0x130 (Inherited: 0xe0)
struct USourceEffectSimpleDelayPreset : USoundEffectSourcePreset {
	char pad_e0[0x38]; // 0xe0(0x38)
	struct FSourceEffectSimpleDelaySettings Settings; // 0x118(0x18)

	void SetSettings(struct FSourceEffectSimpleDelaySettings& InSettings); // Function Synthesis.SourceEffectSimpleDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6121c00
};

// Class Synthesis.SourceEffectStereoDelayPreset
// Size: 0x150 (Inherited: 0xe0)
struct USourceEffectStereoDelayPreset : USoundEffectSourcePreset {
	char pad_e0[0x44]; // 0xe0(0x44)
	struct FSourceEffectStereoDelaySettings Settings; // 0x124(0x24)
	char pad_148[0x8]; // 0x148(0x08)

	void SetSettings(struct FSourceEffectStereoDelaySettings& InSettings); // Function Synthesis.SourceEffectStereoDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x61147b0
};

// Class Synthesis.SourceEffectWaveShaperPreset
// Size: 0x110 (Inherited: 0xe0)
struct USourceEffectWaveShaperPreset : USoundEffectSourcePreset {
	char pad_e0[0x28]; // 0xe0(0x28)
	struct FSourceEffectWaveShaperSettings Settings; // 0x108(0x08)

	void SetSettings(struct FSourceEffectWaveShaperSettings& InSettings); // Function Synthesis.SourceEffectWaveShaperPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60f36f0
};

// Class Synthesis.SubmixEffectConvolutionReverbPreset
// Size: 0x170 (Inherited: 0xe0)
struct USubmixEffectConvolutionReverbPreset : USoundEffectSubmixPreset {
	struct UAudioImpulseResponse* ImpulseResponse; // 0xd8(0x08)
	struct FSubmixEffectConvolutionReverbSettings Settings; // 0xe0(0x30)
	enum class ESubmixEffectConvolutionReverbBlockSize BlockSize; // 0x110(0x01)
	bool bEnableHardwareAcceleration; // 0x111(0x01)
	char pad_11a[0x56]; // 0x11a(0x56)

	void SetWetLevel(float NewWetLevel_dB); // Function Synthesis.SubmixEffectConvolutionReverbPreset.SetWetLevel // (Final|Native|Public|BlueprintCallable) // @ game+0x6130030
	void SetSettings(struct FSubmixEffectConvolutionReverbSettings& InSettings); // Function Synthesis.SubmixEffectConvolutionReverbPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60f0460
	void SetImpulseResponse(struct UAudioImpulseResponse* InImpulseResponse); // Function Synthesis.SubmixEffectConvolutionReverbPreset.SetImpulseResponse // (Final|Native|Public|BlueprintCallable) // @ game+0x6122ad0
};

// Class Synthesis.SubmixEffectDelayStatics
// Size: 0xa0 (Inherited: 0xa0)
struct USubmixEffectDelayStatics : UBlueprintFunctionLibrary {

	struct FSubmixEffectDelaySettings SetMaximumDelayLength(struct FSubmixEffectDelaySettings& DelaySettings, float MaximumDelayLength); // Function Synthesis.SubmixEffectDelayStatics.SetMaximumDelayLength // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60fc390
	struct FSubmixEffectDelaySettings SetInterpolationTime(struct FSubmixEffectDelaySettings& DelaySettings, float InterpolationTime); // Function Synthesis.SubmixEffectDelayStatics.SetInterpolationTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6112820
	struct FSubmixEffectDelaySettings SetDelayLength(struct FSubmixEffectDelaySettings& DelaySettings, float DelayLength); // Function Synthesis.SubmixEffectDelayStatics.SetDelayLength // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60eede0
};

// Class Synthesis.SubmixEffectDelayPreset
// Size: 0x130 (Inherited: 0xe0)
struct USubmixEffectDelayPreset : USoundEffectSubmixPreset {
	char pad_e0[0x2c]; // 0xe0(0x2c)
	struct FSubmixEffectDelaySettings Settings; // 0x10c(0x0c)
	struct FSubmixEffectDelaySettings DynamicSettings; // 0x118(0x0c)
	char pad_124[0xc]; // 0x124(0x0c)

	void SetSettings(struct FSubmixEffectDelaySettings& InSettings); // Function Synthesis.SubmixEffectDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x612b0a0
	void SetInterpolationTime(float Time); // Function Synthesis.SubmixEffectDelayPreset.SetInterpolationTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6113c20
	void SetDelay(float Length); // Function Synthesis.SubmixEffectDelayPreset.SetDelay // (Final|Native|Public|BlueprintCallable) // @ game+0x61197e0
	void SetDefaultSettings(struct FSubmixEffectDelaySettings& InSettings); // Function Synthesis.SubmixEffectDelayPreset.SetDefaultSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6110750
	float GetMaxDelayInMilliseconds(); // Function Synthesis.SubmixEffectDelayPreset.GetMaxDelayInMilliseconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x613c2c0
};

// Class Synthesis.SubmixEffectFilterPreset
// Size: 0x120 (Inherited: 0xe0)
struct USubmixEffectFilterPreset : USoundEffectSubmixPreset {
	char pad_e0[0x2c]; // 0xe0(0x2c)
	struct FSubmixEffectFilterSettings Settings; // 0x10c(0x0c)
	char pad_118[0x8]; // 0x118(0x08)

	void SetSettings(struct FSubmixEffectFilterSettings& InSettings); // Function Synthesis.SubmixEffectFilterPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x610d5a0
	void SetFilterType(enum class ESubmixFilterType InType); // Function Synthesis.SubmixEffectFilterPreset.SetFilterType // (Final|Native|Public|BlueprintCallable) // @ game+0x6106d00
	void SetFilterQMod(float InQ); // Function Synthesis.SubmixEffectFilterPreset.SetFilterQMod // (Final|Native|Public|BlueprintCallable) // @ game+0x6121800
	void SetFilterQ(float InQ); // Function Synthesis.SubmixEffectFilterPreset.SetFilterQ // (Final|Native|Public|BlueprintCallable) // @ game+0x6103d30
	void SetFilterCutoffFrequencyMod(float InFrequency); // Function Synthesis.SubmixEffectFilterPreset.SetFilterCutoffFrequencyMod // (Final|Native|Public|BlueprintCallable) // @ game+0x60ec670
	void SetFilterCutoffFrequency(float InFrequency); // Function Synthesis.SubmixEffectFilterPreset.SetFilterCutoffFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x6107720
	void SetFilterAlgorithm(enum class ESubmixFilterAlgorithm InAlgorithm); // Function Synthesis.SubmixEffectFilterPreset.SetFilterAlgorithm // (Final|Native|Public|BlueprintCallable) // @ game+0x614c5d0
};

// Class Synthesis.SubmixEffectFlexiverbPreset
// Size: 0x120 (Inherited: 0xe0)
struct USubmixEffectFlexiverbPreset : USoundEffectSubmixPreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSubmixEffectFlexiverbSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSubmixEffectFlexiverbSettings& InSettings); // Function Synthesis.SubmixEffectFlexiverbPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6115690
};

// Class Synthesis.SubmixEffectMultibandCompressorPreset
// Size: 0x170 (Inherited: 0xe0)
struct USubmixEffectMultibandCompressorPreset : USoundEffectSubmixPreset {
	char pad_e0[0x58]; // 0xe0(0x58)
	struct FSubmixEffectMultibandCompressorSettings Settings; // 0x138(0x38)

	void SetSettings(struct FSubmixEffectMultibandCompressorSettings& InSettings); // Function Synthesis.SubmixEffectMultibandCompressorPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6100cc0
	void SetExternalSubmix(struct USoundSubmix* Submix); // Function Synthesis.SubmixEffectMultibandCompressorPreset.SetExternalSubmix // (Final|Native|Public|BlueprintCallable) // @ game+0x60ff8a0
	void SetAudioBus(struct UAudioBus* AudioBus); // Function Synthesis.SubmixEffectMultibandCompressorPreset.SetAudioBus // (Final|Native|Public|BlueprintCallable) // @ game+0x61280d0
	void ResetKey(); // Function Synthesis.SubmixEffectMultibandCompressorPreset.ResetKey // (Final|Native|Public|BlueprintCallable) // @ game+0x61198c0
};

// Class Synthesis.SubmixEffectStereoDelayPreset
// Size: 0x150 (Inherited: 0xe0)
struct USubmixEffectStereoDelayPreset : USoundEffectSubmixPreset {
	char pad_e0[0x44]; // 0xe0(0x44)
	struct FSubmixEffectStereoDelaySettings Settings; // 0x124(0x24)
	char pad_148[0x8]; // 0x148(0x08)

	void SetSettings(struct FSubmixEffectStereoDelaySettings& InSettings); // Function Synthesis.SubmixEffectStereoDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x61147b0
};

// Class Synthesis.SubmixEffectStereoToQuadPreset
// Size: 0x110 (Inherited: 0xe0)
struct USubmixEffectStereoToQuadPreset : USoundEffectSubmixPreset {
	char pad_e0[0x28]; // 0xe0(0x28)
	struct FSubmixEffectStereoToQuadSettings Settings; // 0x108(0x08)

	void SetSettings(struct FSubmixEffectStereoToQuadSettings& InSettings); // Function Synthesis.SubmixEffectStereoToQuadPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x612dec0
};

// Class Synthesis.SubmixEffectTapDelayPreset
// Size: 0x150 (Inherited: 0xe0)
struct USubmixEffectTapDelayPreset : USoundEffectSubmixPreset {
	char pad_e0[0x38]; // 0xe0(0x38)
	struct FSubmixEffectTapDelaySettings Settings; // 0x118(0x18)
	char pad_130[0x20]; // 0x130(0x20)

	void SetTap(int32_t TapId, struct FTapDelayInfo& TapInfo); // Function Synthesis.SubmixEffectTapDelayPreset.SetTap // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60f05c0
	void SetSettings(struct FSubmixEffectTapDelaySettings& InSettings); // Function Synthesis.SubmixEffectTapDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6142220
	void SetInterpolationTime(float Time); // Function Synthesis.SubmixEffectTapDelayPreset.SetInterpolationTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6137510
	void RemoveTap(int32_t TapId); // Function Synthesis.SubmixEffectTapDelayPreset.RemoveTap // (Final|Native|Public|BlueprintCallable) // @ game+0x614bf30
	void GetTapIds(struct TArray<int32_t>& TapIds); // Function Synthesis.SubmixEffectTapDelayPreset.GetTapIds // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60faa30
	void GetTap(int32_t TapId, struct FTapDelayInfo& TapInfo); // Function Synthesis.SubmixEffectTapDelayPreset.GetTap // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6144100
	float GetMaxDelayInMilliseconds(); // Function Synthesis.SubmixEffectTapDelayPreset.GetMaxDelayInMilliseconds // (Final|Native|Public|BlueprintCallable) // @ game+0x326f7b0
	void AddTap(int32_t& TapId); // Function Synthesis.SubmixEffectTapDelayPreset.AddTap // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x61373b0
};

// Class Synthesis.GranularSynth
// Size: 0xe00 (Inherited: 0xa20)
struct UGranularSynth : USynthComponent {
	struct USoundWave* GranulatedSoundWave; // 0xa20(0x08)
	char pad_a28[0x3d8]; // 0xa28(0x3d8)

	void SetSustainGain(float SustainGain); // Function Synthesis.GranularSynth.SetSustainGain // (Final|Native|Public|BlueprintCallable) // @ game+0x6129e00
	void SetSoundWave(struct USoundWave* InSoundWave); // Function Synthesis.GranularSynth.SetSoundWave // (Final|Native|Public|BlueprintCallable) // @ game+0x60fda00
	void SetScrubMode(bool bScrubMode); // Function Synthesis.GranularSynth.SetScrubMode // (Final|Native|Public|BlueprintCallable) // @ game+0x6124320
	void SetReleaseTimeMsec(float ReleaseTimeMsec); // Function Synthesis.GranularSynth.SetReleaseTimeMsec // (Final|Native|Public|BlueprintCallable) // @ game+0x610a6a0
	void SetPlayheadTime(float InPositionSec, float LerpTimeSec, enum class EGranularSynthSeekType SeekType); // Function Synthesis.GranularSynth.SetPlayheadTime // (Final|Native|Public|BlueprintCallable) // @ game+0x60f9810
	void SetPlaybackSpeed(float InPlayheadRate); // Function Synthesis.GranularSynth.SetPlaybackSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x6126950
	void SetGrainVolume(float BaseVolume, struct FVector2D VolumeRange); // Function Synthesis.GranularSynth.SetGrainVolume // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x61045d0
	void SetGrainsPerSecond(float InGrainsPerSecond); // Function Synthesis.GranularSynth.SetGrainsPerSecond // (Final|Native|Public|BlueprintCallable) // @ game+0x60ef2f0
	void SetGrainProbability(float InGrainProbability); // Function Synthesis.GranularSynth.SetGrainProbability // (Final|Native|Public|BlueprintCallable) // @ game+0x6108580
	void SetGrainPitch(float BasePitch, struct FVector2D PitchRange); // Function Synthesis.GranularSynth.SetGrainPitch // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6115f50
	void SetGrainPan(float BasePan, struct FVector2D PanRange); // Function Synthesis.GranularSynth.SetGrainPan // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x61192b0
	void SetGrainEnvelopeType(enum class EGranularSynthEnvelopeType EnvelopeType); // Function Synthesis.GranularSynth.SetGrainEnvelopeType // (Final|Native|Public|BlueprintCallable) // @ game+0x610ba70
	void SetGrainDuration(float BaseDurationMsec, struct FVector2D DurationRange); // Function Synthesis.GranularSynth.SetGrainDuration // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x614af10
	void SetDecayTime(float DecayTimeMsec); // Function Synthesis.GranularSynth.SetDecayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6131cd0
	void SetAttackTime(float AttackTimeMsec); // Function Synthesis.GranularSynth.SetAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6131cd0
	void NoteOn(float Note, int32_t Velocity, float Duration); // Function Synthesis.GranularSynth.NoteOn // (Final|Native|Public|BlueprintCallable) // @ game+0x6120b30
	void NoteOff(float Note, bool bKill); // Function Synthesis.GranularSynth.NoteOff // (Final|Native|Public|BlueprintCallable) // @ game+0x6145c00
	bool IsLoaded(); // Function Synthesis.GranularSynth.IsLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x613a830
	float GetSampleDuration(); // Function Synthesis.GranularSynth.GetSampleDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60f6e00
	float GetCurrentPlayheadTime(); // Function Synthesis.GranularSynth.GetCurrentPlayheadTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x612ce00
};

// Class Synthesis.MonoWaveTableSynthPreset
// Size: 0x1e0 (Inherited: 0xa0)
struct UMonoWaveTableSynthPreset : UObject {
	struct FString PresetName; // 0x98(0x10)
	char bLockKeyframesToGridBool : 1; // 0xa8(0x01)
	int32_t LockKeyframesToGrid; // 0xac(0x04)
	int32_t WaveTableResolution; // 0xb0(0x04)
	struct TArray<struct FRuntimeFloatCurve> WaveTable; // 0xb8(0x10)
	char bNormalizeWaveTables : 1; // 0xc8(0x01)
	char pad_c8_2 : 6; // 0xc8(0x01)
	char pad_c9[0x117]; // 0xc9(0x117)
};

// Class Synthesis.SynthComponentMonoWaveTable
// Size: 0x1170 (Inherited: 0xa20)
struct USynthComponentMonoWaveTable : USynthComponent {
	struct FMulticastInlineDelegate OnTableAltered; // 0xa20(0x10)
	struct FMulticastInlineDelegate OnNumTablesChanged; // 0xa30(0x10)
	struct UMonoWaveTableSynthPreset* CurrentPreset; // 0xa40(0x08)
	char pad_a48[0x728]; // 0xa48(0x728)

	void SetWaveTablePosition(float InPosition); // Function Synthesis.SynthComponentMonoWaveTable.SetWaveTablePosition // (Final|Native|Public|BlueprintCallable) // @ game+0x60efef0
	void SetSustainPedalState(bool InSustainPedalState); // Function Synthesis.SynthComponentMonoWaveTable.SetSustainPedalState // (Final|Native|Public|BlueprintCallable) // @ game+0x60ff040
	void SetPosLfoType(enum class ESynthLFOType InLfoType); // Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoType // (Final|Native|Public|BlueprintCallable) // @ game+0x6119160
	void SetPosLfoFrequency(float InLfoFrequency); // Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x60fef30
	void SetPosLfoDepth(float InLfoDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetPosLfoDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x60fea00
	void SetPositionEnvelopeSustainGain(float InSustainGain); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeSustainGain // (Final|Native|Public|BlueprintCallable) // @ game+0x61404a0
	void SetPositionEnvelopeReleaseTime(float InReleaseTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeReleaseTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6106bd0
	void SetPositionEnvelopeInvert(bool bInInvert); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x6148b10
	void SetPositionEnvelopeDepth(float InDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x610e190
	void SetPositionEnvelopeDecayTime(float InDecayTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeDecayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6108cd0
	void SetPositionEnvelopeBiasInvert(bool bInBiasInvert); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeBiasInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x61090f0
	void SetPositionEnvelopeBiasDepth(float InDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeBiasDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x60f8070
	void SetPositionEnvelopeAttackTime(float InAttackTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetPositionEnvelopeAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x610d7b0
	void SetLowPassFilterResonance(float InNewQ); // Function Synthesis.SynthComponentMonoWaveTable.SetLowPassFilterResonance // (Final|Native|Public|BlueprintCallable) // @ game+0x60e6e10
	void SetFrequencyWithMidiNote(float InMidiNote); // Function Synthesis.SynthComponentMonoWaveTable.SetFrequencyWithMidiNote // (Final|Native|Public|BlueprintCallable) // @ game+0x612e770
	void SetFrequencyPitchBend(float FrequencyOffsetCents); // Function Synthesis.SynthComponentMonoWaveTable.SetFrequencyPitchBend // (Final|Native|Public|BlueprintCallable) // @ game+0x612afd0
	void SetFrequency(float FrequencyHz); // Function Synthesis.SynthComponentMonoWaveTable.SetFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x6106320
	void SetFilterEnvelopeSustainGain(float InSustainGain); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeSustainGain // (Final|Native|Public|BlueprintCallable) // @ game+0x612e280
	void SetFilterEnvelopeReleaseTime(float InReleaseTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeReleaseTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6120cd0
	void SetFilterEnvelopenDecayTime(float InDecayTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopenDecayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6142440
	void SetFilterEnvelopeInvert(bool bInInvert); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x60f08c0
	void SetFilterEnvelopeDepth(float InDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x60f1270
	void SetFilterEnvelopeBiasInvert(bool bInBiasInvert); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeBiasInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x613da00
	void SetFilterEnvelopeBiasDepth(float InDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeBiasDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x60fead0
	void SetFilterEnvelopeAttackTime(float InAttackTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetFilterEnvelopeAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6100000
	bool SetCurveValue(int32_t TableIndex, int32_t KeyframeIndex, float NewValue); // Function Synthesis.SynthComponentMonoWaveTable.SetCurveValue // (Final|Native|Public|BlueprintCallable) // @ game+0x6143970
	bool SetCurveTangent(int32_t TableIndex, float InNewTangent); // Function Synthesis.SynthComponentMonoWaveTable.SetCurveTangent // (Final|Native|Public|BlueprintCallable) // @ game+0x610b280
	bool SetCurveInterpolationType(enum class CurveInterpolationType InterpolationType, int32_t TableIndex); // Function Synthesis.SynthComponentMonoWaveTable.SetCurveInterpolationType // (Final|Native|Public|BlueprintCallable) // @ game+0x613be00
	void SetAmpEnvelopeSustainGain(float InSustainGain); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeSustainGain // (Final|Native|Public|BlueprintCallable) // @ game+0x6110450
	void SetAmpEnvelopeReleaseTime(float InReleaseTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeReleaseTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6105bb0
	void SetAmpEnvelopeInvert(bool bInInvert); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x60f4a30
	void SetAmpEnvelopeDepth(float InDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x6149880
	void SetAmpEnvelopeDecayTime(float InDecayTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeDecayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6110980
	void SetAmpEnvelopeBiasInvert(bool bInBiasInvert); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeBiasInvert // (Final|Native|Public|BlueprintCallable) // @ game+0x611c070
	void SetAmpEnvelopeBiasDepth(float InDepth); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeBiasDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x613b7b0
	void SetAmpEnvelopeAttackTime(float InAttackTimeMsec); // Function Synthesis.SynthComponentMonoWaveTable.SetAmpEnvelopeAttackTime // (Final|Native|Public|BlueprintCallable) // @ game+0x60fa750
	void RefreshWaveTable(int32_t Index); // Function Synthesis.SynthComponentMonoWaveTable.RefreshWaveTable // (Final|Native|Public|BlueprintCallable) // @ game+0x6123960
	void RefreshAllWaveTables(); // Function Synthesis.SynthComponentMonoWaveTable.RefreshAllWaveTables // (Final|Native|Public|BlueprintCallable) // @ game+0x6145100
	void NoteOn(float InMidiNote, float InVelocity); // Function Synthesis.SynthComponentMonoWaveTable.NoteOn // (Final|Native|Public|BlueprintCallable) // @ game+0x612a240
	void NoteOff(float InMidiNote); // Function Synthesis.SynthComponentMonoWaveTable.NoteOff // (Final|Native|Public|BlueprintCallable) // @ game+0x60e7f70
	int32_t GetNumTableEntries(); // Function Synthesis.SynthComponentMonoWaveTable.GetNumTableEntries // (Final|Native|Public|BlueprintCallable) // @ game+0x612f7c0
	int32_t GetMaxTableIndex(); // Function Synthesis.SynthComponentMonoWaveTable.GetMaxTableIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60ee590
	struct TArray<float> GetKeyFrameValuesForTable(float TableIndex); // Function Synthesis.SynthComponentMonoWaveTable.GetKeyFrameValuesForTable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x61427e0
	float GetCurveTangent(int32_t TableIndex); // Function Synthesis.SynthComponentMonoWaveTable.GetCurveTangent // (Final|Native|Public|BlueprintCallable) // @ game+0x612a0e0
};

// Class Synthesis.SynthComponentToneGenerator
// Size: 0xb10 (Inherited: 0xa20)
struct USynthComponentToneGenerator : USynthComponent {
	float Frequency; // 0xa20(0x04)
	float Volume; // 0xa24(0x04)
	struct FRuntimeFloatCurve DistanceAttenuationCurve; // 0xa28(0x88)
	struct FVector2D DistanceRange; // 0xab0(0x10)
	float AttenuationDbAtMaxRange; // 0xac0(0x04)
	char pad_ac4[0x4c]; // 0xac4(0x4c)

	void SetVolume(float InVolume); // Function Synthesis.SynthComponentToneGenerator.SetVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x6130120
	void SetFrequency(float InFrequency); // Function Synthesis.SynthComponentToneGenerator.SetFrequency // (Final|Native|Public|BlueprintCallable) // @ game+0x6111a50
};

// Class Synthesis.SynthSamplePlayer
// Size: 0xb50 (Inherited: 0xa20)
struct USynthSamplePlayer : USynthComponent {
	struct USoundWave* SoundWave; // 0xa20(0x08)
	struct FMulticastInlineDelegate OnSampleLoaded; // 0xa28(0x10)
	struct FMulticastInlineDelegate OnSamplePlaybackProgress; // 0xa38(0x10)
	char pad_a48[0x108]; // 0xa48(0x108)

	void SetSoundWave(struct USoundWave* InSoundWave); // Function Synthesis.SynthSamplePlayer.SetSoundWave // (Final|Native|Public|BlueprintCallable) // @ game+0x612e860
	void SetScrubTimeWidth(float InScrubTimeWidthSec); // Function Synthesis.SynthSamplePlayer.SetScrubTimeWidth // (Final|Native|Public|BlueprintCallable) // @ game+0x6110660
	void SetScrubMode(bool bScrubMode); // Function Synthesis.SynthSamplePlayer.SetScrubMode // (Final|Native|Public|BlueprintCallable) // @ game+0x61314a0
	void SetPitch(float InPitch, float TimeSec); // Function Synthesis.SynthSamplePlayer.SetPitch // (Final|Native|Public|BlueprintCallable) // @ game+0x612bcf0
	void SeekToTime(float TimeSec, enum class ESamplePlayerSeekType SeekType, bool bWrap); // Function Synthesis.SynthSamplePlayer.SeekToTime // (Final|Native|Public|BlueprintCallable) // @ game+0x6108f10
	bool IsLoaded(); // Function Synthesis.SynthSamplePlayer.IsLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60f7530
	float GetSampleDuration(); // Function Synthesis.SynthSamplePlayer.GetSampleDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6136700
	float GetCurrentPlaybackProgressTime(); // Function Synthesis.SynthSamplePlayer.GetCurrentPlaybackProgressTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x612ad40
	float GetCurrentPlaybackProgressPercent(); // Function Synthesis.SynthSamplePlayer.GetCurrentPlaybackProgressPercent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x610a770
};

// Class Synthesis.SynthesisUtilitiesBlueprintFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USynthesisUtilitiesBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	float GetLogFrequency(float InLinearValue, float InDomainMin, float InDomainMax, float InRangeMin, float InRangeMax); // Function Synthesis.SynthesisUtilitiesBlueprintFunctionLibrary.GetLogFrequency // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x61322d0
	float GetLinearFrequency(float InLogFrequencyValue, float InDomainMin, float InDomainMax, float InRangeMin, float InRangeMax); // Function Synthesis.SynthesisUtilitiesBlueprintFunctionLibrary.GetLinearFrequency // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x6111490
};

// Class Synthesis.Synth2DSlider
// Size: 0x6e0 (Inherited: 0x1f0)
struct USynth2DSlider : UWidget {
	float ValueX; // 0x1f0(0x04)
	float ValueY; // 0x1f4(0x04)
	struct FDelegate ValueXDelegate; // 0x1f8(0x10)
	struct FDelegate ValueYDelegate; // 0x208(0x10)
	char pad_218[0x8]; // 0x218(0x08)
	struct FSynth2DSliderStyle WidgetStyle; // 0x220(0x430)
	struct FLinearColor SliderHandleColor; // 0x650(0x10)
	bool IndentHandle; // 0x660(0x01)
	bool Locked; // 0x661(0x01)
	char pad_662[0x2]; // 0x662(0x02)
	float StepSize; // 0x664(0x04)
	bool IsFocusable; // 0x668(0x01)
	char pad_669[0x7]; // 0x669(0x07)
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // 0x670(0x10)
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // 0x680(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // 0x690(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // 0x6a0(0x10)
	struct FMulticastInlineDelegate OnValueChangedX; // 0x6b0(0x10)
	struct FMulticastInlineDelegate OnValueChangedY; // 0x6c0(0x10)
	char pad_6d0[0x10]; // 0x6d0(0x10)

	void SetValue(struct FVector2D InValue); // Function Synthesis.Synth2DSlider.SetValue // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6142360
	void SetStepSize(float InValue); // Function Synthesis.Synth2DSlider.SetStepSize // (Final|Native|Public|BlueprintCallable) // @ game+0x610a7b0
	void SetSliderHandleColor(struct FLinearColor InValue); // Function Synthesis.Synth2DSlider.SetSliderHandleColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x61426c0
	void SetLocked(bool InValue); // Function Synthesis.Synth2DSlider.SetLocked // (Final|Native|Public|BlueprintCallable) // @ game+0x6132dd0
	void SetIndentHandle(bool InValue); // Function Synthesis.Synth2DSlider.SetIndentHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x60ec9d0
	struct FVector2D GetValue(); // Function Synthesis.Synth2DSlider.GetValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x6137b30
};

// Class Synthesis.SynthKnob
// Size: 0x620 (Inherited: 0x1f0)
struct USynthKnob : UWidget {
	float Value; // 0x1f0(0x04)
	float StepSize; // 0x1f4(0x04)
	float MouseSpeed; // 0x1f8(0x04)
	float MouseFineTuneSpeed; // 0x1fc(0x04)
	char ShowTooltipInfo : 1; // 0x200(0x01)
	char pad_200_1 : 7; // 0x200(0x01)
	char pad_201[0x7]; // 0x201(0x07)
	struct FText ParameterName; // 0x208(0x18)
	struct FText ParameterUnits; // 0x220(0x18)
	struct FDelegate ValueDelegate; // 0x238(0x10)
	char pad_248[0x8]; // 0x248(0x08)
	struct FSynthKnobStyle WidgetStyle; // 0x250(0x360)
	bool Locked; // 0x5b0(0x01)
	bool IsFocusable; // 0x5b1(0x01)
	char pad_5b2[0x6]; // 0x5b2(0x06)
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // 0x5b8(0x10)
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // 0x5c8(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // 0x5d8(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // 0x5e8(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x5f8(0x10)
	char pad_608[0x18]; // 0x608(0x18)

	void SetValue(float InValue); // Function Synthesis.SynthKnob.SetValue // (Final|Native|Public|BlueprintCallable) // @ game+0x611c980
	void SetStepSize(float InValue); // Function Synthesis.SynthKnob.SetStepSize // (Final|Native|Public|BlueprintCallable) // @ game+0x6141900
	void SetLocked(bool InValue); // Function Synthesis.SynthKnob.SetLocked // (Final|Native|Public|BlueprintCallable) // @ game+0x6147690
	float GetValue(); // Function Synthesis.SynthKnob.GetValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6149770
};

