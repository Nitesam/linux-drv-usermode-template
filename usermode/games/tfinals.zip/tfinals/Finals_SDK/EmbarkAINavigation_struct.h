// Enum EmbarkAINavigation.EHpaNavigationQueryStatus
enum class EHpaNavigationQueryStatus : uint8_t {
	Unscheduled = 0,
	InProgress = 1,
	Success = 2,
	Failure = 3,
	QueryHasNoSolution = 4,
	TimedOut = 5,
	EHpaNavigationQueryStatus_MAX = 6
};

// Enum EmbarkAINavigation.EEmbarkOctreeNavigationDirection
enum class EEmbarkOctreeNavigationDirection : uint8_t {
	Front = 0,
	Back = 1,
	Right = 2,
	Left = 3,
	Top = 4,
	Bottom = 5,
	EEmbarkOctreeNavigationDirection_MAX = 6
};

// Enum EmbarkAINavigation.ENavLinkSize
enum class ENavLinkSize : uint8_t {
	Small = 0,
	Large = 1,
	ENavLinkSize_MAX = 2
};

// Enum EmbarkAINavigation.EHpaGraphSize
enum class EHpaGraphSize : uint8_t {
	Voxel_200 = 0,
	Voxel_500 = 1,
	Voxel_MAX = 2
};

// ScriptStruct EmbarkAINavigation.HierarchicalHeightMapLayer
// Size: 0x18 (Inherited: 0x00)
struct FHierarchicalHeightMapLayer {
	int32_t Dimensions; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<uint16_t> HeightMap; // 0x08(0x10)
};

// ScriptStruct EmbarkAINavigation.HierarchicalHeightMapData
// Size: 0x20 (Inherited: 0x00)
struct FHierarchicalHeightMapData {
	struct TArray<struct FHierarchicalHeightMapLayer> DataLayers; // 0x00(0x10)
	float BaseCellSize; // 0x10(0x04)
	int32_t BaseDimensions; // 0x14(0x04)
	float MinHeight; // 0x18(0x04)
	float Granularity; // 0x1c(0x04)
};

// ScriptStruct EmbarkAINavigation.EmbarkOctreeNavigationPosition
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkOctreeNavigationPosition {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkAINavigation.EmbarkOctreeNavigationQueryTask
// Size: 0x158 (Inherited: 0x00)
struct FEmbarkOctreeNavigationQueryTask {
	char pad_0[0x158]; // 0x00(0x158)
};

// ScriptStruct EmbarkAINavigation.EmbarkOctreeNavigationNode
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkOctreeNavigationNode {
	int32_t FirstChildIndex; // 0x00(0x04)
	char ChildMask; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
};

// ScriptStruct EmbarkAINavigation.EmbarkOctreeNavigationNodeTransform
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkOctreeNavigationNodeTransform {
	struct FVector Position; // 0x00(0x18)
	float Size; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkAINavigation.EmbarkOctreeNavigationPath
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkOctreeNavigationPath {
	struct TArray<struct FEmbarkOctreeNavigationNodeTransform> Nodes; // 0x00(0x10)
};

// ScriptStruct EmbarkAINavigation.OctreeNavSubGrid
// Size: 0x58 (Inherited: 0x00)
struct FOctreeNavSubGrid {
	char pad_0[0x18]; // 0x00(0x18)
	int64_t GridX; // 0x18(0x08)
	int64_t GridY; // 0x20(0x08)
	int64_t GridZ; // 0x28(0x08)
	int64_t OctreeDim; // 0x30(0x08)
	int64_t VoxelSize; // 0x38(0x08)
	bool bOversizeVoxels; // 0x40(0x01)
	char pad_41[0x17]; // 0x41(0x17)
};

// ScriptStruct EmbarkAINavigation.EmbarkRecastNavLinkGenerationConfig
// Size: 0x34 (Inherited: 0x00)
struct FEmbarkRecastNavLinkGenerationConfig {
	bool bEnableAutomaticNavLinkGeneration; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float MaxHeight; // 0x04(0x04)
	float AreaSamplingStepSize; // 0x08(0x04)
	enum class ECollisionChannel VaultComponentTraceChannel; // 0x0c(0x01)
	enum class ECollisionChannel DestructibleBlockerTraceChannel; // 0x0d(0x01)
	char pad_e[0x2]; // 0x0e(0x02)
	float VaultComponentTraceUpOffset; // 0x10(0x04)
	float VaultComponentTraceDownOffset; // 0x14(0x04)
	float DestructibleBlockerUpOffset; // 0x18(0x04)
	float DestructibleBlockerDownOffset; // 0x1c(0x04)
	float MaxDropDownDistance; // 0x20(0x04)
	float MaxDropDownFenceHeight; // 0x24(0x04)
	bool bEnableHorizontalGapNavLinks; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float MaxHorizontalGapDistance; // 0x2c(0x04)
	float MaxHorizontalGapHeightModifier; // 0x30(0x04)
};

// ScriptStruct EmbarkAINavigation.EmbarkRecastDebugNavLinkHeader
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkRecastDebugNavLinkHeader {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct EmbarkAINavigation.EmbarkNavLinkSegmentData
// Size: 0x70 (Inherited: 0x00)
struct FEmbarkNavLinkSegmentData {
	bool bIsNavLinkTraversal; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector NavLinkTargetLocation; // 0x08(0x18)
	struct FVector NavLinkDirection; // 0x20(0x18)
	struct FVector NavLinkStartLocation; // 0x38(0x18)
	enum class ENavLinkSize NavLinkSize; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	int64_t NavLinkId; // 0x58(0x08)
	int32_t NavLinkSegmentIndex; // 0x60(0x04)
	struct TWeakObjectPtr<struct UEmbarkRecastNavLinkBase> NavLinkComponent; // 0x64(0x08)
	char pad_6c[0x4]; // 0x6c(0x04)
};

// ScriptStruct EmbarkAINavigation.EmbarkNavPathSegment
// Size: 0xd0 (Inherited: 0x00)
struct FEmbarkNavPathSegment {
	struct FVector StartLocation; // 0x00(0x18)
	struct FVector EndLocation; // 0x18(0x18)
	struct FVector StartGround; // 0x30(0x18)
	struct FVector EndGround; // 0x48(0x18)
	struct FEmbarkNavLinkSegmentData NavLinkData; // 0x60(0x70)
};

// ScriptStruct EmbarkAINavigation.EmbarkNavPathSegmentResult
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkNavPathSegmentResult {
	struct TArray<struct FEmbarkNavPathSegment> Segments; // 0x00(0x10)
	bool bSuccess; // 0x10(0x01)
	bool bIsPartialPath; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
};

// ScriptStruct EmbarkAINavigation.EmbarkNavProjectionResult
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkNavProjectionResult {
	bool bSuccess; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector ProjectedLocation; // 0x08(0x18)
};

// ScriptStruct EmbarkAINavigation.PathResult
// Size: 0x18 (Inherited: 0x00)
struct FPathResult {
	float Distance; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FVector> Path; // 0x08(0x10)
};

// ScriptStruct EmbarkAINavigation.HpaVertex
// Size: 0x10 (Inherited: 0x00)
struct FHpaVertex {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkAINavigation.HpaVoxelDataSlice
// Size: 0x30 (Inherited: 0x00)
struct FHpaVoxelDataSlice {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct EmbarkAINavigation.HpaNavigationQueryParams
// Size: 0x28 (Inherited: 0x00)
struct FHpaNavigationQueryParams {
	struct TArray<struct AActor*> ActorsToIgnore; // 0x00(0x10)
	float CollisionRadius; // 0x10(0x04)
	int32_t QueryIterationTimeout; // 0x14(0x04)
	float QueryTimeout; // 0x18(0x04)
	bool bFlexibleOriginGoal; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
	int32_t MaxOptimizerSweepAttemptsPerVertex; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct EmbarkAINavigation.HpaNavigationQueryData
// Size: 0x118 (Inherited: 0x00)
struct FHpaNavigationQueryData {
	char pad_0[0x118]; // 0x00(0x118)
};

// ScriptStruct EmbarkAINavigation.HpaNavigationQueryTask
// Size: 0x2b8 (Inherited: 0x00)
struct FHpaNavigationQueryTask {
	char pad_0[0x2b8]; // 0x00(0x2b8)
};

// ScriptStruct EmbarkAINavigation.HpaNavDataHandle
// Size: 0x38 (Inherited: 0x00)
struct FHpaNavDataHandle {
	char pad_0[0x38]; // 0x00(0x38)
};

