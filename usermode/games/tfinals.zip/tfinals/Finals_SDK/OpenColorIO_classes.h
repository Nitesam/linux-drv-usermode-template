// Class OpenColorIO.OpenColorIOSettings
// Size: 0xb0 (Inherited: 0xb0)
struct UOpenColorIOSettings : UDeveloperSettings {
	char bUseLegacyProcessor : 1; // 0xa8(0x01)
	char bUse32fLUT : 1; // 0xa8(0x01)
	char bSupportInverseViewTransforms : 1; // 0xa8(0x01)
};

// Class OpenColorIO.OpenColorIOBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UOpenColorIOBlueprintLibrary : UBlueprintFunctionLibrary {

	bool ApplyColorSpaceTransform(struct UObject* WorldContextObject, struct FOpenColorIOColorConversionSettings& ConversionSettings, struct UTexture* InputTexture, struct UTextureRenderTarget2D* OutputRenderTarget); // Function OpenColorIO.OpenColorIOBlueprintLibrary.ApplyColorSpaceTransform // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b39220
};

// Class OpenColorIO.OpenColorIOColorTransform
// Size: 0x1d0 (Inherited: 0xa0)
struct UOpenColorIOColorTransform : UObject {
	bool bIsDisplayViewType; // 0x98(0x01)
	struct FString SourceColorSpace; // 0xa0(0x10)
	struct FString DestinationColorSpace; // 0xb0(0x10)
	struct FString Display; // 0xc0(0x10)
	struct FString View; // 0xd0(0x10)
	enum class EOpenColorIOViewTransformDirection DisplayViewDirection; // 0xe0(0x01)
	char pad_e2[0x6]; // 0xe2(0x06)
	struct TMap<int32_t, struct UTexture*> Textures; // 0xe8(0x50)
	char pad_138[0x98]; // 0x138(0x98)
};

// Class OpenColorIO.OpenColorIOConfiguration
// Size: 0x100 (Inherited: 0xa0)
struct UOpenColorIOConfiguration : UObject {
	struct FFilePath ConfigurationFile; // 0x98(0x10)
	struct TArray<struct FOpenColorIOColorSpace> DesiredColorSpaces; // 0xa8(0x10)
	struct TArray<struct FOpenColorIODisplayView> DesiredDisplayViews; // 0xb8(0x10)
	struct TArray<struct UOpenColorIOColorTransform*> ColorTransforms; // 0xc8(0x10)
	char pad_e0[0x20]; // 0xe0(0x20)

	void ReloadExistingColorspaces(); // Function OpenColorIO.OpenColorIOConfiguration.ReloadExistingColorspaces // (Final|Native|Public|BlueprintCallable) // @ game+0x29fb8f0
};

// Class OpenColorIO.OpenColorIODisplayExtensionWrapper
// Size: 0xb0 (Inherited: 0xa0)
struct UOpenColorIODisplayExtensionWrapper : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)

	void SetSceneExtensionIsActiveFunctions(struct TArray<struct FSceneViewExtensionIsActiveFunctor>& IsActiveFunctions); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.SetSceneExtensionIsActiveFunctions // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b38c30
	void SetSceneExtensionIsActiveFunction(struct FSceneViewExtensionIsActiveFunctor& IsActiveFunction); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.SetSceneExtensionIsActiveFunction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b409b0
	void SetOpenColorIOConfiguration(struct FOpenColorIODisplayConfiguration InDisplayConfiguration); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.SetOpenColorIOConfiguration // (Final|Native|Public|BlueprintCallable) // @ game+0x9b345a0
	void RemoveSceneExtension(); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.RemoveSceneExtension // (Final|Native|Public|BlueprintCallable) // @ game+0x5f4c7c0
	struct FOpenColorIODisplayConfiguration GetOpenColorIOConfiguration(); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.GetOpenColorIOConfiguration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b34f10
	struct UOpenColorIODisplayExtensionWrapper* CreateOpenColorIODisplayExtension(struct FOpenColorIODisplayConfiguration InDisplayConfiguration, struct FSceneViewExtensionIsActiveFunctor& IsActiveFunction); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.CreateOpenColorIODisplayExtension // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b41320
	struct UOpenColorIODisplayExtensionWrapper* CreateInGameOpenColorIODisplayExtension(struct FOpenColorIODisplayConfiguration InDisplayConfiguration); // Function OpenColorIO.OpenColorIODisplayExtensionWrapper.CreateInGameOpenColorIODisplayExtension // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b3f300
};

