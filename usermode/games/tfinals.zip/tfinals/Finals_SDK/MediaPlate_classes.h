// Class MediaPlate.MediaPlate
// Size: 0x3b0 (Inherited: 0x3a0)
struct AMediaPlate : AActor {
	struct UMediaPlateComponent* MediaPlateComponent; // 0x398(0x08)
	struct UStaticMeshComponent* StaticMeshComponent; // 0x3a0(0x08)
};

// Class MediaPlate.MediaPlateAssetUserData
// Size: 0xb0 (Inherited: 0xa0)
struct UMediaPlateAssetUserData : UAssetUserData {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class MediaPlate.MediaPlateComponent
// Size: 0x220 (Inherited: 0x160)
struct UMediaPlateComponent : UActorComponent {
	bool bPlayOnOpen; // 0x160(0x01)
	bool bAutoPlay; // 0x161(0x01)
	bool bEnableAudio; // 0x162(0x01)
	char pad_163[0x1]; // 0x163(0x01)
	float StartTime; // 0x164(0x04)
	struct UMediaSoundComponent* SoundComponent; // 0x168(0x08)
	struct UStaticMeshComponent* StaticMeshComponent; // 0x170(0x08)
	struct TArray<struct UStaticMeshComponent*> Letterboxes; // 0x178(0x10)
	struct UMediaPlaylist* MediaPlaylist; // 0x188(0x08)
	int32_t PlaylistIndex; // 0x190(0x04)
	struct FMediaSourceCacheSettings CacheSettings; // 0x194(0x08)
	bool bIsMediaPlatePlaying; // 0x19c(0x01)
	char pad_19d[0x7]; // 0x19d(0x07)
	bool bPlayOnlyWhenVisible; // 0x1a4(0x01)
	bool bLoop; // 0x1a5(0x01)
	enum class EMediaTextureVisibleMipsTiles VisibleMipsTilesCalculations; // 0x1a6(0x01)
	char pad_1a7[0x1]; // 0x1a7(0x01)
	float MipMapBias; // 0x1a8(0x04)
	bool bIsAspectRatioAuto; // 0x1ac(0x01)
	bool bEnableMipMapUpscaling; // 0x1ad(0x01)
	char pad_1ae[0x2]; // 0x1ae(0x02)
	int32_t MipLevelToUpscale; // 0x1b0(0x04)
	float LetterboxAspectRatio; // 0x1b4(0x04)
	char pad_1b8[0x8]; // 0x1b8(0x08)
	struct FVector2D MeshRange; // 0x1c0(0x10)
	struct TArray<struct UMediaTexture*> MediaTextures; // 0x1d0(0x10)
	struct UMediaPlayer* MediaPlayer; // 0x1e0(0x08)
	char pad_1e8[0x38]; // 0x1e8(0x38)

	void SetPlayOnlyWhenVisible(bool bInPlayOnlyWhenVisible); // Function MediaPlate.MediaPlateComponent.SetPlayOnlyWhenVisible // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad0580
	void SetMeshRange(struct FVector2D InMeshRange); // Function MediaPlate.MediaPlateComponent.SetMeshRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9ad16b0
	void SetLoop(bool bInLoop); // Function MediaPlate.MediaPlateComponent.SetLoop // (Final|Native|Public|BlueprintCallable) // @ game+0x9aced50
	void SetLetterboxAspectRatio(float AspectRatio); // Function MediaPlate.MediaPlateComponent.SetLetterboxAspectRatio // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad1fe0
	void SetIsAspectRatioAuto(bool bInIsAspectRatioAuto); // Function MediaPlate.MediaPlateComponent.SetIsAspectRatioAuto // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad2860
	bool Seek(struct FTimespan& Time); // Function MediaPlate.MediaPlateComponent.Seek // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9ad1510
	bool Rewind(); // Function MediaPlate.MediaPlateComponent.Rewind // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad6060
	void Play(); // Function MediaPlate.MediaPlateComponent.Play // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad5ea0
	void Pause(); // Function MediaPlate.MediaPlateComponent.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0x9aceb30
	void Open(); // Function MediaPlate.MediaPlateComponent.Open // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad2aa0
	void OnMediaOpened(struct FString DeviceUrl); // Function MediaPlate.MediaPlateComponent.OnMediaOpened // (Final|Native|Private) // @ game+0x9ad1e00
	void OnMediaEnd(); // Function MediaPlate.MediaPlateComponent.OnMediaEnd // (Final|Native|Private) // @ game+0x9ad1ca0
	bool IsMediaPlatePlaying(); // Function MediaPlate.MediaPlateComponent.IsMediaPlatePlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9ad5970
	struct FVector2D GetMeshRange(); // Function MediaPlate.MediaPlateComponent.GetMeshRange // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9acee70
	struct UMediaTexture* GetMediaTexture(int32_t Index); // Function MediaPlate.MediaPlateComponent.GetMediaTexture // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad1ba0
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaPlate.MediaPlateComponent.GetMediaPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad29c0
	bool GetLoop(); // Function MediaPlate.MediaPlateComponent.GetLoop // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x9ad1f00
	float GetLetterboxAspectRatio(); // Function MediaPlate.MediaPlateComponent.GetLetterboxAspectRatio // (Final|Native|Public|BlueprintCallable) // @ game+0x9ad2690
	bool GetIsAspectRatioAuto(); // Function MediaPlate.MediaPlateComponent.GetIsAspectRatioAuto // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9ad21d0
	void Close(); // Function MediaPlate.MediaPlateComponent.Close // (Final|Native|Public|BlueprintCallable) // @ game+0x9acef90
};

