// Class EmbarkDirectReplicationHandlerComponent.DirectReplicationHandlerComponentFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UDirectReplicationHandlerComponentFactory : UHandlerComponentFactory {
};

// Class EmbarkDirectReplicationHandlerComponent.DirectReplicationWrapperComponent
// Size: 0x190 (Inherited: 0x160)
struct UDirectReplicationWrapperComponent : UActorComponent {
	char pad_160[0x30]; // 0x160(0x30)
};

