// ScriptStruct FieldNotification.FieldNotificationId
// Size: 0x08 (Inherited: 0x00)
struct FFieldNotificationId {
	struct FName FieldName; // 0x00(0x08)
};

