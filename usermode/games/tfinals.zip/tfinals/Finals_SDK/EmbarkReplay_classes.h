// Class EmbarkReplay.EmbarkInstantReplayDownloadComponent
// Size: 0x290 (Inherited: 0x160)
struct UEmbarkInstantReplayDownloadComponent : UActorComponent {
	struct APlayerController* OwningController; // 0x158(0x08)
	struct UDirectReplicationWrapperComponent* DirectReplicationWrapperComp; // 0x160(0x08)
	struct UEmbarkInstantReplayPlayback* EmbarkInstantReplayPlayback; // 0x168(0x08)
	char pad_178[0x118]; // 0x178(0x118)

	int32_t StartInstantReplayTransmission_Server(float StartTimeStamp, float EndTimestamp, uint64_t DebugViewTarget, bool bInIsEarlyInit, struct FGameplayAbilityTargetDataHandle& OptionalPayload); // Function EmbarkReplay.EmbarkInstantReplayDownloadComponent.StartInstantReplayTransmission_Server // (Final|Native|Public|HasOutParms) // @ game+0x5fd8910
};

// Class EmbarkReplay.EmbarkInstantReplayNetDriver
// Size: 0x840 (Inherited: 0x840)
struct UEmbarkInstantReplayNetDriver : UNetDriver {
};

// Class EmbarkReplay.EmbarkInstantReplayDemoNetDriver
// Size: 0x1650 (Inherited: 0x1650)
struct UEmbarkInstantReplayDemoNetDriver : UDemoNetDriver {
};

// Class EmbarkReplay.EmbarkInstantReplayDemoNetConnection
// Size: 0x1ec0 (Inherited: 0x1ec0)
struct UEmbarkInstantReplayDemoNetConnection : UDemoNetConnection {
};

// Class EmbarkReplay.InstantReplayAudioSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UInstantReplayAudioSettings : UDeveloperSettings {
	struct TArray<struct TSoftObjectPtr<USoundClass>> SoundClassesToKeepPlaying; // 0xa8(0x10)
};

// Class EmbarkReplay.EmbarkInstantReplayPlayback
// Size: 0x1e0 (Inherited: 0xb0)
struct UEmbarkInstantReplayPlayback : UTickableWorldSubsystem {
	char pad_b0[0x98]; // 0xb0(0x98)
	struct FMulticastInlineDelegate OnInstantReplayDownloadFinish; // 0x148(0x10)
	struct FMulticastInlineDelegate OnInstantReplayDownloadStarted; // 0x158(0x10)
	struct FMulticastInlineDelegate OnInstantReplayCompleted; // 0x168(0x10)
	char pad_178[0x68]; // 0x178(0x68)

	bool TryPlayAvailableInstantReplay(uint64_t InViewTargetNetGuid); // Function EmbarkReplay.EmbarkInstantReplayPlayback.TryPlayAvailableInstantReplay // (Final|Native|Public) // @ game+0x5fda940
	bool PrewarmReplayWorld(struct UWorld* InSourceWorld); // Function EmbarkReplay.EmbarkInstantReplayPlayback.PrewarmReplayWorld // (Final|Native|Public) // @ game+0x5fda6c0
	bool IsReplayEarlyInitComplete(); // Function EmbarkReplay.EmbarkInstantReplayPlayback.IsReplayEarlyInitComplete // (Final|Native|Public|Const) // @ game+0x5fda8e0
	bool IsPlayingInstantReplay(); // Function EmbarkReplay.EmbarkInstantReplayPlayback.IsPlayingInstantReplay // (Final|RequiredAPI|Native|Public|Const) // @ game+0x5fda320
	struct UWorld* GetReplayWorld(); // Function EmbarkReplay.EmbarkInstantReplayPlayback.GetReplayWorld // (Final|Native|Public|Const) // @ game+0x5fda910
	struct APlayerController* GetReplayPlayerController(); // Function EmbarkReplay.EmbarkInstantReplayPlayback.GetReplayPlayerController // (Final|Native|Public|Const) // @ game+0x5fd9b50
	bool GetCurrentPlayback(float& PlaybackTime, float& MaxTime); // Function EmbarkReplay.EmbarkInstantReplayPlayback.GetCurrentPlayback // (Final|Native|Public|HasOutParms|Const) // @ game+0x5fd9a30
	void EndReplay(); // Function EmbarkReplay.EmbarkInstantReplayPlayback.EndReplay // (Final|Native|Public) // @ game+0x5fda530
	void AutoPlayInstantReplaysFromDisk(); // Function EmbarkReplay.EmbarkInstantReplayPlayback.AutoPlayInstantReplaysFromDisk // (Final|Native|Public) // @ game+0x33aadf0
};

// Class EmbarkReplay.EmbarkInstantReplayWorldDuplicationSubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkInstantReplayWorldDuplicationSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TMap<struct UWorld*, struct FEmbarkInstantReplayWorldPackages> DuplicatedPackagesPerWorld; // 0xa8(0x50)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class EmbarkReplay.EmbarkReplayRecorder
// Size: 0xc0 (Inherited: 0xb0)
struct UEmbarkReplayRecorder : UTickableWorldSubsystem {
	char pad_b0[0x10]; // 0xb0(0x10)

	void StartRecordingReplay(); // Function EmbarkReplay.EmbarkReplayRecorder.StartRecordingReplay // (Final|Native|Public|BlueprintCallable) // @ game+0x5fdb210
	void SetRecordingTriggerDelegate(struct FDelegate& InDelegate); // Function EmbarkReplay.EmbarkReplayRecorder.SetRecordingTriggerDelegate // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5fdaea0
};

