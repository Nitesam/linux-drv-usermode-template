// Enum StreamlineReflexBlueprint.EStreamlineReflexMode
enum class EStreamlineReflexMode : uint8_t {
	Off = 0,
	Enabled = 1,
	Boost = 3,
	EStreamlineReflexMode_MAX = 4
};

