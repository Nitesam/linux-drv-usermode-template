// Class AudioModulation.AudioModulationStyle
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioModulationStyle : UBlueprintFunctionLibrary {

	struct FColor GetPatchColor(); // Function AudioModulation.AudioModulationStyle.GetPatchColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6a7adb0
	struct FColor GetParameterColor(); // Function AudioModulation.AudioModulationStyle.GetParameterColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6a69e20
	struct FColor GetModulationGeneratorColor(); // Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6a5fc80
	struct FColor GetControlBusMixColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusMixColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6a738a0
	struct FColor GetControlBusColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x6a83210
};

// Class AudioModulation.AudioModulationSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UAudioModulationSettings : UDeveloperSettings {
	struct TArray<struct FSoftObjectPath> Parameters; // 0xa8(0x10)
};

// Class AudioModulation.AudioModulationStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioModulationStatics : UBlueprintFunctionLibrary {

	void UpdateModulator(struct UObject* WorldContextObject, struct USoundModulatorBase* Modulator); // Function AudioModulation.AudioModulationStatics.UpdateModulator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a66ce0
	void UpdateMixFromObject(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMixFromObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a91620
	void UpdateMixByFilter(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, struct FString AddressFilter, struct USoundModulationParameter* ParamClassFilter, struct USoundModulationParameter* ParamFilter, float Value, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMixByFilter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6aa60a0
	void UpdateMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, struct TArray<struct FSoundControlBusMixStage> Stages, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a8c3c0
	void SetGlobalBusMixValue(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float Value, float FadeTime); // Function AudioModulation.AudioModulationStatics.SetGlobalBusMixValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a8cd10
	void SaveMixToProfile(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, int32_t ProfileIndex); // Function AudioModulation.AudioModulationStatics.SaveMixToProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a59930
	struct TArray<struct FSoundControlBusMixStage> LoadMixFromProfile(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, bool bActivate, int32_t ProfileIndex); // Function AudioModulation.AudioModulationStatics.LoadMixFromProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a4d250
	float GetModulatorValue(struct UObject* WorldContextObject, struct USoundModulatorBase* Modulator); // Function AudioModulation.AudioModulationStatics.GetModulatorValue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a97720
	struct TSet<struct USoundModulatorBase*> GetModulatorsFromDestination(struct FSoundModulationDestinationSettings& Destination); // Function AudioModulation.AudioModulationStatics.GetModulatorsFromDestination // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x6a51380
	void DeactivateGenerator(struct UObject* WorldContextObject, struct USoundModulationGenerator* Generator); // Function AudioModulation.AudioModulationStatics.DeactivateGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a82b30
	void DeactivateBusMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix); // Function AudioModulation.AudioModulationStatics.DeactivateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a4b750
	void DeactivateBus(struct UObject* WorldContextObject, struct USoundControlBus* Bus); // Function AudioModulation.AudioModulationStatics.DeactivateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a4e060
	void DeactivateAllBusMixes(struct UObject* WorldContextObject); // Function AudioModulation.AudioModulationStatics.DeactivateAllBusMixes // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6aa0f60
	struct USoundModulationParameter* CreateModulationParameter(struct UObject* WorldContextObject, struct FName Name, struct USoundModulationParameter* ParamClass, float DefaultValue); // Function AudioModulation.AudioModulationStatics.CreateModulationParameter // (Final|Native|Static|Public) // @ game+0x6a9f840
	struct USoundModulationGeneratorLFO* CreateLFOGenerator(struct UObject* WorldContextObject, struct FName Name, struct FSoundModulationLFOParams Params); // Function AudioModulation.AudioModulationStatics.CreateLFOGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a7f1f0
	struct USoundModulationGeneratorEnvelopeFollower* CreateEnvelopeFollowerGenerator(struct UObject* WorldContextObject, struct FName Name, struct FEnvelopeFollowerGeneratorParams Params); // Function AudioModulation.AudioModulationStatics.CreateEnvelopeFollowerGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a620e0
	struct FSoundControlBusMixStage CreateBusMixStage(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float Value, float AttackTime, float ReleaseTime); // Function AudioModulation.AudioModulationStatics.CreateBusMixStage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a4e1f0
	struct USoundControlBusMix* CreateBusMix(struct UObject* WorldContextObject, struct FName Name, struct TArray<struct FSoundControlBusMixStage> Stages, bool Activate); // Function AudioModulation.AudioModulationStatics.CreateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6aa4930
	struct USoundControlBus* CreateBus(struct UObject* WorldContextObject, struct FName Name, struct USoundModulationParameter* Parameter, bool Activate); // Function AudioModulation.AudioModulationStatics.CreateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a4a400
	struct USoundModulationGeneratorADEnvelope* CreateADEnvelopeGenerator(struct UObject* WorldContextObject, struct FName Name, struct FSoundModulationADEnvelopeParams& Params); // Function AudioModulation.AudioModulationStatics.CreateADEnvelopeGenerator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6a597d0
	void ClearGlobalBusMixValue(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float FadeTime); // Function AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6ab5400
	void ClearAllGlobalBusMixValues(struct UObject* WorldContextObject, float FadeTime); // Function AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a98090
	void ActivateGenerator(struct UObject* WorldContextObject, struct USoundModulationGenerator* Generator); // Function AudioModulation.AudioModulationStatics.ActivateGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a5e460
	void ActivateBusMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix); // Function AudioModulation.AudioModulationStatics.ActivateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a5b1f0
	void ActivateBus(struct UObject* WorldContextObject, struct USoundControlBus* Bus); // Function AudioModulation.AudioModulationStatics.ActivateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a579c0
};

// Class AudioModulation.SoundModulationGenerator
// Size: 0xa0 (Inherited: 0xa0)
struct USoundModulationGenerator : USoundModulatorBase {
};

// Class AudioModulation.SoundModulationGeneratorADEnvelope
// Size: 0xc0 (Inherited: 0xa0)
struct USoundModulationGeneratorADEnvelope : USoundModulationGenerator {
	struct FSoundModulationADEnvelopeParams Params; // 0xa0(0x14)
	char pad_b4[0xc]; // 0xb4(0x0c)
};

// Class AudioModulation.SoundModulationGeneratorEnvelopeFollower
// Size: 0xc0 (Inherited: 0xa0)
struct USoundModulationGeneratorEnvelopeFollower : USoundModulationGenerator {
	struct FEnvelopeFollowerGeneratorParams Params; // 0xa0(0x20)
};

// Class AudioModulation.SoundModulationGeneratorLFO
// Size: 0xc0 (Inherited: 0xa0)
struct USoundModulationGeneratorLFO : USoundModulationGenerator {
	struct FSoundModulationLFOParams Params; // 0xa0(0x20)
};

// Class AudioModulation.SoundControlBus
// Size: 0xd0 (Inherited: 0xa0)
struct USoundControlBus : USoundModulatorBase {
	bool bBypass; // 0xa0(0x01)
	char pad_a1[0x7]; // 0xa1(0x07)
	struct FString Address; // 0xa8(0x10)
	struct TArray<struct USoundModulationGenerator*> Generators; // 0xb8(0x10)
	struct USoundModulationParameter* Parameter; // 0xc8(0x08)
};

// Class AudioModulation.SoundControlBusMix
// Size: 0xb0 (Inherited: 0xa0)
struct USoundControlBusMix : UObject {
	uint32_t ProfileIndex; // 0x98(0x04)
	struct TArray<struct FSoundControlBusMixStage> MixStages; // 0xa0(0x10)

	void SoloMix(); // Function AudioModulation.SoundControlBusMix.SoloMix // (Final|Native|Protected) // @ game+0x6aa9740
	void SaveMixToProfile(); // Function AudioModulation.SoundControlBusMix.SaveMixToProfile // (Final|Native|Protected) // @ game+0x6a5f0b0
	void LoadMixFromProfile(); // Function AudioModulation.SoundControlBusMix.LoadMixFromProfile // (Final|Native|Protected) // @ game+0x6a46140
	void DeactivateMix(); // Function AudioModulation.SoundControlBusMix.DeactivateMix // (Final|Native|Protected) // @ game+0x6a474f0
	void DeactivateAllMixes(); // Function AudioModulation.SoundControlBusMix.DeactivateAllMixes // (Final|Native|Protected) // @ game+0x6ab8300
	void ActivateMix(); // Function AudioModulation.SoundControlBusMix.ActivateMix // (Final|Native|Protected) // @ game+0x6a79900
};

// Class AudioModulation.SoundModulationParameter
// Size: 0xb0 (Inherited: 0xa0)
struct USoundModulationParameter : UObject {
	struct FSoundModulationParameterSettings Settings; // 0xa0(0x04)
	char pad_a4[0xc]; // 0xa4(0x0c)
};

// Class AudioModulation.SoundModulationParameterScaled
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterScaled : USoundModulationParameter {
	float UnitMin; // 0xa8(0x04)
	float UnitMax; // 0xac(0x04)
};

// Class AudioModulation.SoundModulationParameterFrequencyBase
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterFrequencyBase : USoundModulationParameter {
};

// Class AudioModulation.SoundModulationParameterFrequency
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterFrequency : USoundModulationParameterFrequencyBase {
	float UnitMin; // 0xa8(0x04)
	float UnitMax; // 0xac(0x04)
};

// Class AudioModulation.SoundModulationParameterFilterFrequency
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterFilterFrequency : USoundModulationParameterFrequencyBase {
};

// Class AudioModulation.SoundModulationParameterLPFFrequency
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterLPFFrequency : USoundModulationParameterFilterFrequency {
};

// Class AudioModulation.SoundModulationParameterHPFFrequency
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterHPFFrequency : USoundModulationParameterFilterFrequency {
};

// Class AudioModulation.SoundModulationParameterBipolar
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterBipolar : USoundModulationParameter {
	float UnitRange; // 0xa8(0x04)
};

// Class AudioModulation.SoundModulationParameterVolume
// Size: 0xb0 (Inherited: 0xb0)
struct USoundModulationParameterVolume : USoundModulationParameter {
	float MinVolume; // 0xa8(0x04)
};

// Class AudioModulation.SoundModulationPatch
// Size: 0xc0 (Inherited: 0xa0)
struct USoundModulationPatch : USoundModulatorBase {
	struct FSoundControlModulationPatch PatchSettings; // 0xa0(0x20)
};

