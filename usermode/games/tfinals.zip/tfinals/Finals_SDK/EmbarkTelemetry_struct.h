// Enum EmbarkTelemetry.EBackendGameTransformationNativeErrorCode
enum class EBackendGameTransformationNativeErrorCode : uint8_t {
	Default = 0,
	BackendInvalidData = 1,
	ThirdPartyInvalidData = 2,
	EBackendGameTransformationNativeErrorCode_MAX = 3
};

// Enum EmbarkTelemetry.EBackendGameTransformationNativeDetailedInfo
enum class EBackendGameTransformationNativeDetailedInfo : uint8_t {
	StoreOfferInvalidThirdPartyProductId = 0,
	CharacterItemMissingSkinSelection = 1,
	CharacterItemSelectedSkinDoesNotExist = 2,
	CharacterItemSelectedSchematicDoesNotExist = 3,
	StoreOfferNoCachedThirdPartyProduct = 4,
	EBackendGameTransformationNativeDetailedInfo_MAX = 5
};

// Enum EmbarkTelemetry.ETelemetryClientActivity
enum class ETelemetryClientActivity : uint8_t {
	MainMenu = 0,
	Matchmaking = 1,
	InRound = 2,
	ETelemetryClientActivity_MAX = 3
};

// Enum EmbarkTelemetry.ClientPlatform
enum class ClientPlatform : uint8_t {
	Unknown = 0,
	Epic = 1,
	Playstation = 2,
	Steam = 3,
	Xbox = 4,
	Embark = 5,
	Playstation4 = 11,
	WinGDK = 12,
	ClientPlatform_MAX = 13
};

