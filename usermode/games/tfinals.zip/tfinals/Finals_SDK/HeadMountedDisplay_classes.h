// Class HeadMountedDisplay.HandKeypointConversion
// Size: 0xa0 (Inherited: 0xa0)
struct UHandKeypointConversion : UBlueprintFunctionLibrary {

	int32_t Conv_HandKeypointToInt32(enum class EHandKeypoint Input); // Function HeadMountedDisplay.HandKeypointConversion.Conv_HandKeypointToInt32 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x20cef50
};

// Class HeadMountedDisplay.MotionControllerComponent
// Size: 0x830 (Inherited: 0x6c0)
struct UMotionControllerComponent : UPrimitiveComponent {
	int32_t PlayerIndex; // 0x6b8(0x04)
	struct FName MotionSource; // 0x6bc(0x08)
	char bDisableLowLatencyUpdate : 1; // 0x6c4(0x01)
	enum class ETrackingStatus CurrentTrackingStatus; // 0x6c8(0x01)
	bool bDisplayDeviceModel; // 0x6c9(0x01)
	struct FName DisplayModelSource; // 0x6cc(0x08)
	char pad_6d6_1 : 7; // 0x6d6(0x01)
	char pad_6d7[0x1]; // 0x6d7(0x01)
	struct UStaticMesh* CustomDisplayMesh; // 0x6d8(0x08)
	struct TArray<struct UMaterialInterface*> DisplayMeshMaterialOverrides; // 0x6e0(0x10)
	struct UPrimitiveComponent* DisplayComponent; // 0x6f0(0x08)
	char pad_6f8[0x138]; // 0x6f8(0x138)

	void SetTrackingSource(enum class EControllerHand NewSource); // Function HeadMountedDisplay.MotionControllerComponent.SetTrackingSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x20c3570
	void SetTrackingMotionSource(struct FName NewSource); // Function HeadMountedDisplay.MotionControllerComponent.SetTrackingMotionSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x20bfa80
	void SetShowDeviceModel(bool bShowControllerModel); // Function HeadMountedDisplay.MotionControllerComponent.SetShowDeviceModel // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x20c33a0
	void SetDisplayModelSource(struct FName NewDisplayModelSource); // Function HeadMountedDisplay.MotionControllerComponent.SetDisplayModelSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x20c4360
	void SetCustomDisplayMesh(struct UStaticMesh* NewDisplayMesh); // Function HeadMountedDisplay.MotionControllerComponent.SetCustomDisplayMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x20c2590
	void SetAssociatedPlayerIndex(int32_t NewPlayer); // Function HeadMountedDisplay.MotionControllerComponent.SetAssociatedPlayerIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x20c9650
	void OnMotionControllerUpdated(); // Function HeadMountedDisplay.MotionControllerComponent.OnMotionControllerUpdated // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool IsTracked(); // Function HeadMountedDisplay.MotionControllerComponent.IsTracked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x20bfa40
	enum class EControllerHand GetTrackingSource(); // Function HeadMountedDisplay.MotionControllerComponent.GetTrackingSource // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x20ce690
	float GetParameterValue(struct FName InName, bool& bValueFound); // Function HeadMountedDisplay.MotionControllerComponent.GetParameterValue // (Final|RequiredAPI|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x20ccc90
	bool GetLinearVelocity(struct FVector& OutLinearVelocity); // Function HeadMountedDisplay.MotionControllerComponent.GetLinearVelocity // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x20cc800
	bool GetLinearAcceleration(struct FVector& OutLinearAcceleration); // Function HeadMountedDisplay.MotionControllerComponent.GetLinearAcceleration // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x20c42b0
	struct FVector GetHandJointPosition(int32_t jointIndex, bool& bValueFound); // Function HeadMountedDisplay.MotionControllerComponent.GetHandJointPosition // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x20ca960
	bool GetAngularVelocity(struct FRotator& OutAngularVelocity); // Function HeadMountedDisplay.MotionControllerComponent.GetAngularVelocity // (Final|RequiredAPI|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x20c2220
};

