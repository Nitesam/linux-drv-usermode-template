// Class EmbarkPerfTesting.EmbarkPerfTestingBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkPerfTestingBlueprintLibrary : UBlueprintFunctionLibrary {

	void CaptureScreenshotAsyncDelegate(struct FString Filename, struct FDelegate Callback); // Function EmbarkPerfTesting.EmbarkPerfTestingBlueprintLibrary.CaptureScreenshotAsyncDelegate // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6968830
	void CaptureScreenshotAsync(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct FString Filename); // Function EmbarkPerfTesting.EmbarkPerfTestingBlueprintLibrary.CaptureScreenshotAsync // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x695fd20
	void CapturePerformanceSnapshot(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, float Duration, struct FString Name); // Function EmbarkPerfTesting.EmbarkPerfTestingBlueprintLibrary.CapturePerformanceSnapshot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6961940
};

// Class EmbarkPerfTesting.IEmbarkPerfTestRunScenario
// Size: 0x140 (Inherited: 0xa0)
struct UIEmbarkPerfTestRunScenario : UObject {
	struct FString Key; // 0x98(0x10)
	char pad_b0[0x90]; // 0xb0(0x90)

	bool Run(struct FEmbarkPerfTestRunGlobalParams& GlobalParams); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.Run // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x69681c0
	struct FEmbarkPerfTestSnapshotContext NewMeasuredSnapshotStep(struct FString SnapshotName); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.NewMeasuredSnapshotStep // (Final|Native|Public|BlueprintCallable) // @ game+0x6963d40
	int32_t IncrementDeduplicationCounter(); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.IncrementDeduplicationCounter // (Final|Native|Public|BlueprintCallable) // @ game+0x695fce0
	struct FEmbarkPerfTestGauntletScenario GenerateGauntletScenario(); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.GenerateGauntletScenario // (Native|Event|Public|BlueprintEvent) // @ game+0x6968680
	struct FEmbarkPerfTestGauntletScenario BaseGauntletScenario(); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.BaseGauntletScenario // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6960930
	void AddWaitStep(float Duration); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.AddWaitStep // (Final|Native|Public|BlueprintCallable) // @ game+0x2e7fe30
	void AddWaitForShaderCompilationStep(); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.AddWaitForShaderCompilationStep // (Final|Native|Public|BlueprintCallable) // @ game+0x29fb8f0
	void AddStepByName(struct FName FuncName); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.AddStepByName // (Final|Native|Public|BlueprintCallable) // @ game+0x69687a0
	void AddStep(struct FDelegate StepDelegate); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.AddStep // (Final|Native|Public|BlueprintCallable) // @ game+0x536a6e0
	void AddConnectToServerStep(struct FString ServerAddress); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.AddConnectToServerStep // (Final|Native|Public|BlueprintCallable) // @ game+0x2f6f520
	void AddAsyncScreenshotStep(struct FString Filename); // Function EmbarkPerfTesting.IEmbarkPerfTestRunScenario.AddAsyncScreenshotStep // (Final|Native|Public|BlueprintCallable) // @ game+0x2f6f520
};

// Class EmbarkPerfTesting.IEmbarkPerfTestAsset
// Size: 0xd0 (Inherited: 0xa0)
struct UIEmbarkPerfTestAsset : UDataAsset {
	struct FString ShortName; // 0xa0(0x10)
	bool bEnabled; // 0xb0(0x01)
	bool bIsCritical; // 0xb1(0x01)
	char pad_b2[0x6]; // 0xb2(0x06)
	struct TArray<struct FEmbarkPerfTestScenarioWrapper> CachedScenarios; // 0xb8(0x10)
	char pad_c8[0x8]; // 0xc8(0x08)

	bool ValidateCanStart(); // Function EmbarkPerfTesting.IEmbarkPerfTestAsset.ValidateCanStart // (Native|Event|Public|BlueprintEvent) // @ game+0x3247a90
	bool GenerateScenarios(); // Function EmbarkPerfTesting.IEmbarkPerfTestAsset.GenerateScenarios // (Native|Event|Public|BlueprintEvent) // @ game+0x2b5ca40
	void AddScenario(struct UIEmbarkPerfTestRunScenario* Scenario); // Function EmbarkPerfTesting.IEmbarkPerfTestAsset.AddScenario // (Final|Native|Public) // @ game+0x6964180
};

// Class EmbarkPerfTesting.EmbarkPerfTestRepository
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkPerfTestRepository : UPrimaryDataAsset {
	struct TArray<struct UIEmbarkPerfTestAsset*> Tests; // 0xa0(0x10)
};

// Class EmbarkPerfTesting.EmbarkPerfTestSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkPerfTestSubsystem : UEngineSubsystem {
	struct TArray<struct UEmbarkPerfTestRepository*> Repositories; // 0xa0(0x10)

	bool StartTest(struct FString TestName, struct FString ScenarioKey); // Function EmbarkPerfTesting.EmbarkPerfTestSubsystem.StartTest // (Final|Native|Public|BlueprintCallable) // @ game+0x6962bc0
	struct UWorld* GetWorldForTests(); // Function EmbarkPerfTesting.EmbarkPerfTestSubsystem.GetWorldForTests // (Final|Native|Public|BlueprintCallable) // @ game+0x6963b80
	struct TArray<struct UIEmbarkPerfTestAsset*> GetTestsOfClass(struct UIEmbarkPerfTestAsset* TestClass); // Function EmbarkPerfTesting.EmbarkPerfTestSubsystem.GetTestsOfClass // (Final|Native|Public|Const) // @ game+0x6968d30
};

