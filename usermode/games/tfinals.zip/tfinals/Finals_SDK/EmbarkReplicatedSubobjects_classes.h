// Class EmbarkReplicatedSubobjects.ActorComponentReplicatedSubobjects
// Size: 0x170 (Inherited: 0x160)
struct UActorComponentReplicatedSubobjects : UActorComponent {
	char pad_160[0x10]; // 0x160(0x10)

	void ScriptReplicateSubobjects(); // Function EmbarkReplicatedSubobjects.ActorComponentReplicatedSubobjects.ScriptReplicateSubobjects // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void AddObjectToReplicate(struct UReplicatedSubobject* ObjectToReplicate); // Function EmbarkReplicatedSubobjects.ActorComponentReplicatedSubobjects.AddObjectToReplicate // (Final|Native|Protected|BlueprintCallable) // @ game+0x5151580
};

// Class EmbarkReplicatedSubobjects.ActorReplicatedSubobjects
// Size: 0x3b0 (Inherited: 0x3a0)
struct AActorReplicatedSubobjects : AActor {
	char pad_3a0[0x10]; // 0x3a0(0x10)

	void ScriptReplicateSubobjects(); // Function EmbarkReplicatedSubobjects.ActorReplicatedSubobjects.ScriptReplicateSubobjects // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void AddObjectToReplicate(struct UReplicatedSubobject* ObjectToReplicate); // Function EmbarkReplicatedSubobjects.ActorReplicatedSubobjects.AddObjectToReplicate // (Final|Native|Protected|BlueprintCallable) // @ game+0x5152410
};

// Class EmbarkReplicatedSubobjects.ReplicatedSubobject
// Size: 0xd0 (Inherited: 0xa0)
struct UReplicatedSubobject : UObject {
	char bUseRepKeyForReplication : 1; // 0x98(0x01)
	char pad_a0_1 : 7; // 0xa0(0x01)
	char pad_a1[0x17]; // 0xa1(0x17)
	struct UActorComponent* ActorComponentToPropagateReplicationKeyDirtyTo; // 0xb8(0x08)
	struct UReplicatedSubobject* ReplicatedSubobjectToPropagateReplicationKeyDirtyTo; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)

	void SetUsesReplicationKeyForReplication(bool bNewUserRepKeyForReplication); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.SetUsesReplicationKeyForReplication // (Final|Native|Public|BlueprintCallable) // @ game+0x5152620
	void SetReplicationKeyDirty(); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.SetReplicationKeyDirty // (Final|Native|Public|BlueprintCallable) // @ game+0x514d700
	void SetReplicatedSubobjectToPropagateReplicationKeyDirtyTo(struct UReplicatedSubobject* TargtReplicatedSubobject); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.SetReplicatedSubobjectToPropagateReplicationKeyDirtyTo // (Final|Native|Public|BlueprintCallable) // @ game+0x5151960
	void SetOuter(struct UObject* Outer); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.SetOuter // (Final|Native|Protected|BlueprintCallable) // @ game+0x514dc80
	void SetActorComponentToPropagateReplicationKeyDirtyTo(struct UActorComponent* ActorComponent); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.SetActorComponentToPropagateReplicationKeyDirtyTo // (Final|Native|Public|BlueprintCallable) // @ game+0x514db00
	void ScriptReplicateSubobjects(); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.ScriptReplicateSubobjects // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void PostReplication(); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.PostReplication // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool GetUsesReplicationKeyForReplication(); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.GetUsesReplicationKeyForReplication // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5151660
	void AddObjectToReplicate(struct UReplicatedSubobject* ObjectToReplicate); // Function EmbarkReplicatedSubobjects.ReplicatedSubobject.AddObjectToReplicate // (Final|Native|Protected|BlueprintCallable) // @ game+0x5151860
};

// Class EmbarkReplicatedSubobjects.ReplicatedSubobjectWithPreSave
// Size: 0xd0 (Inherited: 0xd0)
struct UReplicatedSubobjectWithPreSave : UReplicatedSubobject {
	bool bCallPreSave; // 0xc8(0x01)

	void ReceivePreSave(); // Function EmbarkReplicatedSubobjects.ReplicatedSubobjectWithPreSave.ReceivePreSave // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

