// ScriptStruct EmbarkVoiceConversionCommon.VoiceConversionSpeakerAudioData
// Size: 0x20 (Inherited: 0x00)
struct FVoiceConversionSpeakerAudioData {
	float F0Mean; // 0x00(0x04)
	float F0Std; // 0x04(0x04)
	float LogF0Mean; // 0x08(0x04)
	float LogF0Std; // 0x0c(0x04)
	struct TArray<float> SpeakerEmbedding; // 0x10(0x10)
};

