// Class EmbarkCamera.EmbarkPlayerCameraManager
// Size: 0x1d70 (Inherited: 0x1d50)
struct AEmbarkPlayerCameraManager : APlayerCameraManager {
	struct FVector2D OffCenterProjectionOffset; // 0x1d50(0x10)
	struct FMulticastInlineDelegate OnViewTargetChanged; // 0x1d60(0x10)
};

