// Enum EmbarkReplayInterface.EInstantReplaySetting
enum class EInstantReplaySetting : uint8_t {
	Autodetect = 0,
	On = 1,
	Off = 2,
	EInstantReplaySetting_MAX = 3
};

