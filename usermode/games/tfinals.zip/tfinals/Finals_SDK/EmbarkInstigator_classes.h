// Class EmbarkInstigator.InstigatorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UInstigatorMixinLibrary : UObject {

	void SetInstigatorPlayerState(struct FInstigator& InInstigator, struct APlayerState* InPlayerState); // Function EmbarkInstigator.InstigatorMixinLibrary.SetInstigatorPlayerState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514c7f0
	void SetInstigator(struct FInstigator& InInstigator, struct AActor* InInstigatorActor); // Function EmbarkInstigator.InstigatorMixinLibrary.SetInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514d0d0
	void SetInstigatingItem(struct FInstigator& InInstigator, struct AActor* InInstigatingItem); // Function EmbarkInstigator.InstigatorMixinLibrary.SetInstigatingItem // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514d270
	void SetCauser(struct FInstigator& InInstigator, struct AActor* InCauser); // Function EmbarkInstigator.InstigatorMixinLibrary.SetCauser // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514c970
	struct APlayerState* GetInstigatorPlayerState(struct FInstigator& InInstigator); // Function EmbarkInstigator.InstigatorMixinLibrary.GetInstigatorPlayerState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514d5c0
	struct AActor* GetInstigator(struct FInstigator& InInstigator); // Function EmbarkInstigator.InstigatorMixinLibrary.GetInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514cde0
	struct AActor* GetInstigatingItem(struct FInstigator& InInstigator); // Function EmbarkInstigator.InstigatorMixinLibrary.GetInstigatingItem // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514c5a0
	struct AActor* GetCauser(struct FInstigator& InInstigator); // Function EmbarkInstigator.InstigatorMixinLibrary.GetCauser // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x514cf20
};

