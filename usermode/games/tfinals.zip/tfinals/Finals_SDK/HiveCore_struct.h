// ScriptStruct HiveCore.AgentIdentity
// Size: 0x08 (Inherited: 0x00)
struct FAgentIdentity {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct HiveCore.MLInferenceOutput
// Size: 0x50 (Inherited: 0x00)
struct FMLInferenceOutput {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct HiveCore.MLInferenceInput
// Size: 0x50 (Inherited: 0x00)
struct FMLInferenceInput {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct HiveCore.MLTrainingInferenceInput
// Size: 0x1f8 (Inherited: 0x00)
struct FMLTrainingInferenceInput {
	struct FMLInferenceInput InferenceInput; // 0x00(0x50)
	struct FHiveObservation TrainingInput; // 0x50(0x1a8)
};

