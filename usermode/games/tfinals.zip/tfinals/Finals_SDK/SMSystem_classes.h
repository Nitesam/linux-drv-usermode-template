// Class SMSystem.SMEditorGraphNodeInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USMEditorGraphNodeInterface : UInterface {

	bool SetNodeName(struct FString NewName, struct FText& OutErrorMessage); // Function SMSystem.SMEditorGraphNodeInterface.SetNodeName // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d507c0
	void ResetNodeName(); // Function SMSystem.SMEditorGraphNodeInterface.ResetNodeName // (Native|Public|BlueprintCallable) // @ game+0x340cb00
	struct FString GetNodeName(); // Function SMSystem.SMEditorGraphNodeInterface.GetNodeName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4dbb0
	struct TArray<struct TScriptInterface<ISMEditorGraphPropertyNodeInterface>> GetEditorGraphPropertyAsArray(struct FName PropertyName, struct USMNodeInstance* NodeInstance, int32_t ArrayIndex); // Function SMSystem.SMEditorGraphNodeInterface.GetEditorGraphPropertyAsArray // (Native|Public|BlueprintCallable|Const) // @ game+0x5d51d50
	struct TScriptInterface<ISMEditorGraphPropertyNodeInterface> GetEditorGraphProperty(struct FName PropertyName, struct USMNodeInstance* NodeInstance, int32_t ArrayIndex); // Function SMSystem.SMEditorGraphNodeInterface.GetEditorGraphProperty // (Native|Public|BlueprintCallable|Const) // @ game+0x5d4a2d0
	struct TArray<struct TScriptInterface<ISMEditorGraphPropertyNodeInterface>> GetAllEditorGraphProperties(struct USMNodeInstance* NodeInstance); // Function SMSystem.SMEditorGraphNodeInterface.GetAllEditorGraphProperties // (Native|Public|BlueprintCallable|Const) // @ game+0x5d51f80
	struct TScriptInterface<ISMEditorGraphNode_StateBaseInterface> AsStateBaseInterface(); // Function SMSystem.SMEditorGraphNodeInterface.AsStateBaseInterface // (Native|Public|BlueprintCallable) // @ game+0x5d4c390
};

// Class SMSystem.SMEditorGraphNode_StateBaseInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USMEditorGraphNode_StateBaseInterface : UInterface {

	void SetAnyStateTags(struct FGameplayTagContainer& InAnyStateTags); // Function SMSystem.SMEditorGraphNode_StateBaseInterface.SetAnyStateTags // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d4f180
	struct FGameplayTagContainer GetAnyStateTags(); // Function SMSystem.SMEditorGraphNode_StateBaseInterface.GetAnyStateTags // (Native|Public|BlueprintCallable) // @ game+0x5d57840
};

// Class SMSystem.SMEditorGraphPropertyNodeInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USMEditorGraphPropertyNodeInterface : UInterface {

	void SetNotificationAndHighlight(bool bEnable, enum class ESMLogType Severity, struct FString Message, bool bClearOnCompile); // Function SMSystem.SMEditorGraphPropertyNodeInterface.SetNotificationAndHighlight // (Native|Public|BlueprintCallable) // @ game+0x5d59dc0
	void SetNotification(bool bEnable, enum class ESMLogType Severity, struct FString Message, bool bClearOnCompile); // Function SMSystem.SMEditorGraphPropertyNodeInterface.SetNotification // (Native|Public|BlueprintCallable) // @ game+0x5d52170
	void SetHighlight(bool bEnable, struct FLinearColor Color, bool bClearOnCompile); // Function SMSystem.SMEditorGraphPropertyNodeInterface.SetHighlight // (Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5d4bf40
	void ResetProperty(); // Function SMSystem.SMEditorGraphPropertyNodeInterface.ResetProperty // (Native|Public|BlueprintCallable) // @ game+0x5d49150
};

// Class SMSystem.SMInstanceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USMInstanceInterface : UInterface {
};

// Class SMSystem.SMStateMachineInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USMStateMachineInterface : UInterface {
};

// Class SMSystem.SMStateMachineNetworkedInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USMStateMachineNetworkedInterface : UInterface {

	bool IsSimulatedProxy(); // Function SMSystem.SMStateMachineNetworkedInterface.IsSimulatedProxy // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4bc70
	bool IsConfiguredForNetworking(); // Function SMSystem.SMStateMachineNetworkedInterface.IsConfiguredForNetworking // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4b440
	bool HasAuthority(); // Function SMSystem.SMStateMachineNetworkedInterface.HasAuthority // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d58110
};

// Class SMSystem.SMBlueprint
// Size: 0x120 (Inherited: 0x120)
struct USMBlueprint : UBlueprint {
	int32_t AssetVersion; // 0x118(0x04)
	int32_t PluginVersion; // 0x11c(0x04)
};

// Class SMSystem.SMNodeBlueprint
// Size: 0x120 (Inherited: 0x120)
struct USMNodeBlueprint : UBlueprint {
	int32_t AssetVersion; // 0x118(0x04)
	int32_t PluginVersion; // 0x11c(0x04)
};

// Class SMSystem.SMBlueprintGeneratedClass
// Size: 0x460 (Inherited: 0x450)
struct USMBlueprintGeneratedClass : UBlueprintGeneratedClass {
	struct FGuid RootGuid; // 0x450(0x10)
};

// Class SMSystem.SMNodeBlueprintGeneratedClass
// Size: 0x450 (Inherited: 0x450)
struct USMNodeBlueprintGeneratedClass : UBlueprintGeneratedClass {
};

// Class SMSystem.SMNodeInstance
// Size: 0x120 (Inherited: 0xa0)
struct USMNodeInstance : UObject {
	bool bHasGameConstructionScripts; // 0xa0(0x01)
	char bEvalDefaultProperties : 1; // 0xa1(0x01)
	char bAutoEvalExposedProperties : 1; // 0xa1(0x01)
	char pad_a1_2 : 6; // 0xa1(0x01)
	char pad_a2[0x6]; // 0xa2(0x06)
	struct UTexture2D* NodeIcon; // 0xa8(0x08)
	struct FVector2D NodeIconSize; // 0xb0(0x10)
	struct FLinearColor NodeIconTintColor; // 0xc0(0x10)
	bool bResetVariablesOnInitialize; // 0xd0(0x01)
	char bIsThreadSafe : 1; // 0xd1(0x01)
	char pad_d1_1 : 7; // 0xd1(0x01)
	char pad_d2[0x6]; // 0xd2(0x06)
	struct UInputComponent* InputComponent; // 0xd8(0x08)
	enum class ESMNodeInput AutoReceiveInput; // 0xe0(0x01)
	char pad_e1[0x3]; // 0xe1(0x03)
	int32_t InputPriority; // 0xe4(0x04)
	char bBlockInput : 1; // 0xe8(0x01)
	char pad_e8_1 : 7; // 0xe8(0x01)
	char pad_e9[0x1f]; // 0xe9(0x1f)
	struct FGuid TemplateGuid; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)

	void WithExecutionEnvironment(enum class ESMExecutionEnvironment& ExecutionEnvironment); // Function SMSystem.SMNodeInstance.WithExecutionEnvironment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d5c4c0
	void SetVariableReadOnly(struct FName VariableName, bool bSetIsReadOnly); // Function SMSystem.SMNodeInstance.SetVariableReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5a350
	void SetVariableHidden(struct FName VariableName, bool bSetHidden); // Function SMSystem.SMNodeInstance.SetVariableHidden // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5a350
	void SetUseCustomIcon(bool bValue); // Function SMSystem.SMNodeInstance.SetUseCustomIcon // (Final|Native|Public|BlueprintCallable) // @ game+0x5193460
	void SetUseCustomColor(bool bValue); // Function SMSystem.SMNodeInstance.SetUseCustomColor // (Final|Native|Public|BlueprintCallable) // @ game+0x5193460
	void SetNodeDescriptionText(struct FText NewDescription); // Function SMSystem.SMNodeInstance.SetNodeDescriptionText // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5b820
	void SetNodeColor(struct FLinearColor NewColor); // Function SMSystem.SMNodeInstance.SetNodeColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5d5f410
	void SetDisplayName(struct FName NewDisplayName); // Function SMSystem.SMNodeInstance.SetDisplayName // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5b910
	void ResetVariables(); // Function SMSystem.SMNodeInstance.ResetVariables // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5f4b0
	void OnRootStateMachineStop(); // Function SMSystem.SMNodeInstance.OnRootStateMachineStop // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16fe8b0
	void OnRootStateMachineStart(); // Function SMSystem.SMNodeInstance.OnRootStateMachineStart // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x17031b0
	void OnPreCompileValidate(struct USMCompilerLog* CompilerLog); // Function SMSystem.SMNodeInstance.OnPreCompileValidate // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x4fad190
	void OnContextPawnControllerChanged(struct APawn* Pawn, struct AController* NewController); // Function SMSystem.SMNodeInstance.OnContextPawnControllerChanged // (Final|Native|Protected) // @ game+0x5d5cf70
	void K2_TryGetOwningEditorGraphNode(struct TScriptInterface<ISMEditorGraphNodeInterface>& EditorNode, enum class ESMValidEditorNode& IsValidNode); // Function SMSystem.SMNodeInstance.K2_TryGetOwningEditorGraphNode // (Final|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x5d5a200
	bool IsInitializedAndReadyForInputEvents(); // Function SMSystem.SMNodeInstance.IsInitializedAndReadyForInputEvents // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5e980
	bool IsInitialized(); // Function SMSystem.SMNodeInstance.IsInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5d8d0
	bool IsInEndState(); // Function SMSystem.SMNodeInstance.IsInEndState // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x48d40b0
	bool IsEditorExecution(); // Function SMSystem.SMNodeInstance.IsEditorExecution // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5198790
	bool IsActive(); // Function SMSystem.SMNodeInstance.IsActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5b160
	bool HasUpdated(); // Function SMSystem.SMNodeInstance.HasUpdated // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x327bee0
	float GetTimeInState(); // Function SMSystem.SMNodeInstance.GetTimeInState // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5f550
	struct USMInstance* GetStateMachineInstance(bool bTopMostInstance); // Function SMSystem.SMNodeInstance.GetStateMachineInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5da30
	struct USMStateMachineInstance* GetOwningStateMachineNodeInstance(); // Function SMSystem.SMNodeInstance.GetOwningStateMachineNodeInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5f910
	struct TScriptInterface<ISMEditorGraphNodeInterface> GetOwningEditorGraphNode(); // Function SMSystem.SMNodeInstance.GetOwningEditorGraphNode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5bef0
	struct FVector2D GetNodePosition(); // Function SMSystem.SMNodeInstance.GetNodePosition // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5b130
	struct FString GetNodeName(); // Function SMSystem.SMNodeInstance.GetNodeName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5af70
	struct FLinearColor GetNodeIconTintColor(); // Function SMSystem.SMNodeInstance.GetNodeIconTintColor // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x5d5d070
	struct FVector2D GetNodeIconSize(); // Function SMSystem.SMNodeInstance.GetNodeIconSize // (Native|Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x5d5c5b0
	struct UTexture2D* GetNodeIcon(); // Function SMSystem.SMNodeInstance.GetNodeIcon // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2c546d0
	struct FText GetNodeDescriptionText(); // Function SMSystem.SMNodeInstance.GetNodeDescriptionText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5cbd0
	struct TScriptInterface<ISMStateMachineNetworkedInterface> GetNetworkInterface(); // Function SMSystem.SMNodeInstance.GetNetworkInterface // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5c270
	struct UInputComponent* GetInputComponent(); // Function SMSystem.SMNodeInstance.GetInputComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5f8f0
	struct FGuid GetGuid(); // Function SMSystem.SMNodeInstance.GetGuid // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5cf40
	struct UObject* GetContext(); // Function SMSystem.SMNodeInstance.GetContext // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5d6b0
	void EvaluateGraphProperties(bool bTargetOnly); // Function SMSystem.SMNodeInstance.EvaluateGraphProperties // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5c1c0
	void ConstructionScript(); // Function SMSystem.SMNodeInstance.ConstructionScript // (Native|Event|Protected|BlueprintEvent) // @ game+0x537cec0
};

// Class SMSystem.SMStateInstance_Base
// Size: 0x160 (Inherited: 0x120)
struct USMStateInstance_Base : USMNodeInstance {
	char bEvalGraphsOnStart : 1; // 0x118(0x01)
	char bEvalGraphsOnUpdate : 1; // 0x118(0x01)
	char bEvalGraphsOnEnd : 1; // 0x118(0x01)
	char bEvalGraphsOnRootStateMachineStart : 1; // 0x118(0x01)
	char bEvalGraphsOnRootStateMachineStop : 1; // 0x118(0x01)
	char bDisableTickTransitionEvaluation : 1; // 0x11a(0x01)
	char bEvalTransitionsOnStart : 1; // 0x11a(0x01)
	char bAlwaysUpdate : 1; // 0x11a(0x01)
	char pad_121_0 : 3; // 0x121(0x01)
	char bCanBeEndState : 1; // 0x11a(0x01)
	char bDefaultToParallel : 1; // 0x11a(0x01)
	char bAllowParallelReentry : 1; // 0x11a(0x01)
	char bStayActiveOnStateChange : 1; // 0x11a(0x01)
	char bExcludeFromAnyState : 1; // 0x11a(0x01)
	struct FMulticastInlineDelegate OnStateBeginEvent; // 0x120(0x10)
	struct FMulticastInlineDelegate OnPostStateBeginEvent; // 0x130(0x10)
	struct FMulticastInlineDelegate OnStateUpdateEvent; // 0x140(0x10)
	struct FMulticastInlineDelegate OnStateEndEvent; // 0x150(0x10)

	bool SwitchToLinkedStateByTransitionName(struct FString TransitionName, bool bRequireTransitionToPass, bool bActivateNow); // Function SMSystem.SMStateInstance_Base.SwitchToLinkedStateByTransitionName // (Final|Native|Public|BlueprintCallable) // @ game+0x5d63ca0
	bool SwitchToLinkedStateByTransition(struct USMTransitionInstance* TransitionInstance, bool bRequireTransitionToPass, bool bActivateNow); // Function SMSystem.SMStateInstance_Base.SwitchToLinkedStateByTransition // (Final|Native|Public|BlueprintCallable) // @ game+0x5d604e0
	bool SwitchToLinkedStateByName(struct FString NextStateName, bool bRequireTransitionToPass, bool bActivateNow); // Function SMSystem.SMStateInstance_Base.SwitchToLinkedStateByName // (Final|Native|Public|BlueprintCallable) // @ game+0x5d608b0
	bool SwitchToLinkedState(struct USMStateInstance_Base* NextStateInstance, bool bRequireTransitionToPass, bool bActivateNow); // Function SMSystem.SMStateInstance_Base.SwitchToLinkedState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d621b0
	void SetStayActiveOnStateChange(bool bValue); // Function SMSystem.SMStateInstance_Base.SetStayActiveOnStateChange // (Final|Native|Public|BlueprintCallable) // @ game+0x5d63e50
	void SetExcludeFromAnyState(bool bValue); // Function SMSystem.SMStateInstance_Base.SetExcludeFromAnyState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d60810
	void SetEvalTransitionsOnStart(bool bValue); // Function SMSystem.SMStateInstance_Base.SetEvalTransitionsOnStart // (Final|Native|Public|BlueprintCallable) // @ game+0x5d60650
	void SetDisableTickTransitionEvaluation(bool bValue); // Function SMSystem.SMStateInstance_Base.SetDisableTickTransitionEvaluation // (Final|Native|Public|BlueprintCallable) // @ game+0x5d619b0
	void SetDefaultToParallel(bool bValue); // Function SMSystem.SMStateInstance_Base.SetDefaultToParallel // (Final|Native|Public|BlueprintCallable) // @ game+0x5d61560
	void SetCanBeEndState(bool bValue); // Function SMSystem.SMStateInstance_Base.SetCanBeEndState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d614c0
	void SetAlwaysUpdate(bool bValue); // Function SMSystem.SMStateInstance_Base.SetAlwaysUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x5d639d0
	void SetAllowParallelReentry(bool bValue); // Function SMSystem.SMStateInstance_Base.SetAllowParallelReentry // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5fa70
	void SetActive(bool bValue, bool bSetAllParents, bool bActivateNow); // Function SMSystem.SMStateInstance_Base.SetActive // (Final|Native|Public|BlueprintCallable) // @ game+0x5d62440
	void OnStateUpdate(float DeltaSeconds); // Function SMSystem.SMStateInstance_Base.OnStateUpdate // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5d638c0
	void OnStateEnd(); // Function SMSystem.SMStateInstance_Base.OnStateEnd // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5d60060
	void OnStateBegin(); // Function SMSystem.SMStateInstance_Base.OnStateBegin // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2f78920
	bool IsStateMachine(); // Function SMSystem.SMStateInstance_Base.IsStateMachine // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64260
	bool IsEntryState(); // Function SMSystem.SMStateInstance_Base.IsEntryState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d625d0
	bool IsEndState(); // Function SMSystem.SMStateInstance_Base.IsEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d616a0
	struct USMTransitionInstance* GetTransitionToTake(); // Function SMSystem.SMStateInstance_Base.GetTransitionToTake // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64c20
	struct USMTransitionInstance* GetTransitionByIndex(int32_t Index); // Function SMSystem.SMStateInstance_Base.GetTransitionByIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61ea0
	bool GetStayActiveOnStateChange(); // Function SMSystem.SMStateInstance_Base.GetStayActiveOnStateChange // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64a40
	void GetStateInfo(struct FSMStateInfo& State); // Function SMSystem.SMStateInstance_Base.GetStateInfo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d616d0
	struct FDateTime GetStartTime(); // Function SMSystem.SMStateInstance_Base.GetStartTime // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61670
	float GetServerTimeInState(bool& bOutUsedLocalTime); // Function SMSystem.SMStateInstance_Base.GetServerTimeInState // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d63ac0
	struct USMStateInstance_Base* GetPreviousStateByName(struct FString StateName); // Function SMSystem.SMStateInstance_Base.GetPreviousStateByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d63fa0
	struct USMTransitionInstance* GetPreviousActiveTransition(); // Function SMSystem.SMStateInstance_Base.GetPreviousActiveTransition // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61f50
	struct USMStateInstance_Base* GetPreviousActiveState(); // Function SMSystem.SMStateInstance_Base.GetPreviousActiveState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d60d70
	bool GetOutgoingTransitions(struct TArray<struct USMTransitionInstance*>& Transitions, bool bExcludeAlwaysFalse); // Function SMSystem.SMStateInstance_Base.GetOutgoingTransitions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d601f0
	struct USMTransitionInstance* GetOutgoingTransitionByName(struct FString Name); // Function SMSystem.SMStateInstance_Base.GetOutgoingTransitionByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d606f0
	struct USMStateInstance_Base* GetNextStateByTransitionIndex(int32_t Index); // Function SMSystem.SMStateInstance_Base.GetNextStateByTransitionIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d611e0
	struct USMStateInstance_Base* GetNextStateByName(struct FString StateName); // Function SMSystem.SMStateInstance_Base.GetNextStateByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64120
	bool GetIncomingTransitions(struct TArray<struct USMTransitionInstance*>& Transitions, bool bExcludeAlwaysFalse); // Function SMSystem.SMStateInstance_Base.GetIncomingTransitions // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61d40
	struct USMTransitionInstance* GetIncomingTransitionByName(struct FString Name); // Function SMSystem.SMStateInstance_Base.GetIncomingTransitionByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61400
	bool GetExcludeFromAnyState(); // Function SMSystem.SMStateInstance_Base.GetExcludeFromAnyState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d60d00
	bool GetEvalTransitionsOnStart(); // Function SMSystem.SMStateInstance_Base.GetEvalTransitionsOnStart // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d639a0
	bool GetDisableTickTransitionEvaluation(); // Function SMSystem.SMStateInstance_Base.GetDisableTickTransitionEvaluation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61cb0
	bool GetDefaultToParallel(); // Function SMSystem.SMStateInstance_Base.GetDefaultToParallel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64930
	bool GetCanBeEndState(); // Function SMSystem.SMStateInstance_Base.GetCanBeEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d63640
	bool GetAlwaysUpdate(); // Function SMSystem.SMStateInstance_Base.GetAlwaysUpdate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d5fb50
	bool GetAllowParallelReentry(); // Function SMSystem.SMStateInstance_Base.GetAllowParallelReentry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d61b30
	void EvaluateTransitions(); // Function SMSystem.SMStateInstance_Base.EvaluateTransitions // (Final|Native|Public|BlueprintCallable) // @ game+0x5d60150
	bool AreAllOutgoingTransitionsFromAnAnyState(); // Function SMSystem.SMStateInstance_Base.AreAllOutgoingTransitionsFromAnAnyState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d63970
	bool AreAllIncomingTransitionsFromAnAnyState(); // Function SMSystem.SMStateInstance_Base.AreAllIncomingTransitionsFromAnAnyState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d62600
};

// Class SMSystem.SMConduitInstance
// Size: 0x170 (Inherited: 0x160)
struct USMConduitInstance : USMStateInstance_Base {
	bool bEvalGraphsOnInitialize; // 0x160(0x01)
	bool bEvalGraphsOnTransitionEval; // 0x161(0x01)
	char bEvalWithTransitions : 1; // 0x162(0x01)
	char bCanEvaluate : 1; // 0x162(0x01)
	char pad_162_2 : 6; // 0x162(0x01)
	char pad_163[0xd]; // 0x163(0x0d)

	void SetEvalWithTransitions(bool bValue); // Function SMSystem.SMConduitInstance.SetEvalWithTransitions // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4d300
	void SetCanEvaluate(bool bValue); // Function SMSystem.SMConduitInstance.SetCanEvaluate // (Final|Native|Public|BlueprintCallable) // @ game+0x5d50a50
	void OnConduitShutdown(); // Function SMSystem.SMConduitInstance.OnConduitShutdown // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3b06180
	void OnConduitInitialized(); // Function SMSystem.SMConduitInstance.OnConduitInitialized // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x32a8d60
	void OnConduitEntered(); // Function SMSystem.SMConduitInstance.OnConduitEntered // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2f930f0
	bool GetEvalWithTransitions(); // Function SMSystem.SMConduitInstance.GetEvalWithTransitions // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4cc90
	bool GetCanEvaluate(); // Function SMSystem.SMConduitInstance.GetCanEvaluate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d52360
	bool CanEnterTransition(); // Function SMSystem.SMConduitInstance.CanEnterTransition // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2b24420
};

// Class SMSystem.SMInstance
// Size: 0x770 (Inherited: 0xa0)
struct USMInstance : UObject {
	char pad_a0[0x50]; // 0xa0(0x50)
	struct TArray<struct FSMReferenceContainer> ReplicatedReferences; // 0xf0(0x10)
	struct FGuid RootStateMachineGuid; // 0x100(0x10)
	struct FMulticastInlineDelegate OnPreStateMachineInitializedEvent; // 0x110(0x10)
	struct FMulticastInlineDelegate OnStateMachineInitializedEvent; // 0x120(0x10)
	struct FMulticastInlineDelegate OnStateMachineStartedEvent; // 0x130(0x10)
	struct FMulticastInlineDelegate OnStateMachineUpdatedEvent; // 0x140(0x10)
	struct FMulticastInlineDelegate OnStateMachineStoppedEvent; // 0x150(0x10)
	struct FMulticastInlineDelegate OnStateMachineShutdownEvent; // 0x160(0x10)
	struct FMulticastInlineDelegate OnStateMachineTransitionTakenEvent; // 0x170(0x10)
	struct FMulticastInlineDelegate OnStateMachineStateChangedEvent; // 0x180(0x10)
	struct FMulticastInlineDelegate OnStateMachineStateStartedEvent; // 0x190(0x10)
	struct USMStateMachineComponent* ComponentOwner; // 0x1a0(0x08)
	struct TScriptInterface<ISMStateMachineNetworkedInterface> NetworkInterface; // 0x1a8(0x10)
	char pad_1b8[0x140]; // 0x1b8(0x140)
	struct FSMStateMachine RootStateMachine; // 0x2f8(0x2c8)
	struct UObject* R_StateMachineContext; // 0x5c0(0x08)
	struct USMInstance* ReferenceOwner; // 0x5c8(0x08)
	struct USMStateMachineInstance* StateMachineClass; // 0x5d0(0x08)
	char bAutoManageTime : 1; // 0x5d8(0x01)
	char bStopOnEndState : 1; // 0x5d8(0x01)
	char bCanEverTick : 1; // 0x5d8(0x01)
	char bCanTickWhenPaused : 1; // 0x5d8(0x01)
	char bTickRegistered : 1; // 0x5d8(0x01)
	char bTickBeforeInitialize : 1; // 0x5d8(0x01)
	char bTickBeforeBeginPlay : 1; // 0x5d8(0x01)
	char pad_5d8_7 : 1; // 0x5d8(0x01)
	char pad_5d9[0x3]; // 0x5d9(0x03)
	float TickInterval; // 0x5dc(0x04)
	char pad_5e0[0x10]; // 0x5e0(0x10)
	struct UInputComponent* InputComponent; // 0x5f0(0x08)
	enum class ESMStateMachineInput AutoReceiveInput; // 0x5f8(0x01)
	char pad_5f9[0x3]; // 0x5f9(0x03)
	int32_t InputPriority; // 0x5fc(0x04)
	char bBlockInput : 1; // 0x600(0x01)
	char pad_600_1 : 7; // 0x600(0x01)
	char pad_601[0x7]; // 0x601(0x07)
	struct TArray<struct FSMStateHistory> StateHistory; // 0x608(0x10)
	int32_t StateHistoryMaxCount; // 0x618(0x04)
	char bEnableLogging : 1; // 0x61c(0x01)
	char bLogStateChange : 1; // 0x61c(0x01)
	char bLogTransitionTaken : 1; // 0x61c(0x01)
	char bCanReplicateAsReference : 1; // 0x61c(0x01)
	char pad_61c_4 : 4; // 0x61c(0x01)
	char pad_61d[0x3]; // 0x61d(0x03)
	struct TMap<struct FGuid, struct FGuid> PathGuidRedirectMap; // 0x620(0x50)
	struct TMap<struct FGuid, struct FSMGuidMap> RootPathGuidCache; // 0x670(0x50)
	char pad_6c0[0x10]; // 0x6c0(0x10)
	struct TArray<struct UObject*> ReferenceTemplates; // 0x6d0(0x10)
	struct TMap<struct FGuid, struct FSMExposedNodeFunctions> NodeExposedFunctions; // 0x6e0(0x50)
	char pad_730[0x40]; // 0x730(0x40)

	void Update(float DeltaSeconds); // Function SMSystem.SMInstance.Update // (Native|Public|BlueprintCallable) // @ game+0x5d582b0
	void TryGetTransitionInfo(struct FGuid& Guid, struct FSMTransitionInfo& TransitionInfo, bool& bSuccess); // Function SMSystem.SMInstance.TryGetTransitionInfo // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4e770
	void TryGetStateInfo(struct FGuid& Guid, struct FSMStateInfo& StateInfo, bool& bSuccess); // Function SMSystem.SMInstance.TryGetStateInfo // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d598d0
	void TryGetNestedActiveState(struct FSMStateInfo& FoundState, bool& bSuccess); // Function SMSystem.SMInstance.TryGetNestedActiveState // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d49830
	void Tick(float DeltaTime); // Function SMSystem.SMInstance.Tick // (Native|Event|Public|BlueprintEvent) // @ game+0x5d5a000
	bool TakeTransitionChain(struct TArray<struct USMTransitionInstance*>& InTransitionChain); // Function SMSystem.SMInstance.TakeTransitionChain // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d52a20
	void SwitchActiveStateByQualifiedName(struct FString InFullPath, bool bDeactivateOtherStates); // Function SMSystem.SMInstance.SwitchActiveStateByQualifiedName // (Final|Native|Public|BlueprintCallable) // @ game+0x5d513b0
	void SwitchActiveState(struct USMStateInstance_Base* NewStateInstance, bool bDeactivateOtherStates); // Function SMSystem.SMInstance.SwitchActiveState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d59090
	void Stop(); // Function SMSystem.SMInstance.Stop // (Native|Public|BlueprintCallable) // @ game+0x5d51a10
	void StartWithNewContext(struct UObject* Context); // Function SMSystem.SMInstance.StartWithNewContext // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4e200
	void Start(); // Function SMSystem.SMInstance.Start // (Native|Public|BlueprintCallable) // @ game+0x5d4bca0
	void Shutdown(); // Function SMSystem.SMInstance.Shutdown // (Native|Public|BlueprintCallable) // @ game+0x5d4f3c0
	void SetTickOnManualUpdate(bool Value); // Function SMSystem.SMInstance.SetTickOnManualUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x5d54f50
	void SetTickInterval(float Value); // Function SMSystem.SMInstance.SetTickInterval // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4ef70
	void SetTickBeforeBeginPlay(bool Value); // Function SMSystem.SMInstance.SetTickBeforeBeginPlay // (Final|Native|Public|BlueprintCallable) // @ game+0x5d51970
	void SetStopOnEndState(bool Value); // Function SMSystem.SMInstance.SetStopOnEndState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d57f20
	void SetStateMachineClass(struct USMStateMachineInstance* NewStateMachineClass); // Function SMSystem.SMInstance.SetStateMachineClass // (Final|Native|Public|BlueprintCallable) // @ game+0x5d55c60
	void SetStateHistoryMaxCount(int32_t NewSize); // Function SMSystem.SMInstance.SetStateHistoryMaxCount // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4c9b0
	void SetRootStateMachineNodeClass(struct USMStateMachineInstance* NewStateMachineNodeClass); // Function SMSystem.SMInstance.SetRootStateMachineNodeClass // (Final|Native|Public|BlueprintCallable) // @ game+0x5d55c60
	void SetGuidRedirectMap(struct TMap<struct FGuid, struct FGuid>& InGuidMap); // Function SMSystem.SMInstance.SetGuidRedirectMap // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d504f0
	void SetContext(struct UObject* Context); // Function SMSystem.SMInstance.SetContext // (Final|Native|Public|BlueprintCallable) // @ game+0x5d56880
	void SetCanTickWhenPaused(bool Value); // Function SMSystem.SMInstance.SetCanTickWhenPaused // (Final|Native|Public|BlueprintCallable) // @ game+0x5d57490
	void SetCanEverTick(bool Value); // Function SMSystem.SMInstance.SetCanEverTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5d526f0
	void SetAutoManageTime(bool Value); // Function SMSystem.SMInstance.SetAutoManageTime // (Final|Native|Public|BlueprintCallable) // @ game+0x5d57c20
	void RunUpdateAsReference(float DeltaSeconds); // Function SMSystem.SMInstance.RunUpdateAsReference // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4ff20
	void Restart(); // Function SMSystem.SMInstance.Restart // (Native|Public|BlueprintCallable) // @ game+0x5d59820
	void ReplicatedStop(); // Function SMSystem.SMInstance.ReplicatedStop // (Final|Native|Public|BlueprintCallable) // @ game+0x5d49a10
	void ReplicatedStart(); // Function SMSystem.SMInstance.ReplicatedStart // (Final|Native|Public|BlueprintCallable) // @ game+0x5d56c20
	void ReplicatedRestart(); // Function SMSystem.SMInstance.ReplicatedRestart // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4ec60
	void REP_OnReplicatedReferencesLoaded(); // Function SMSystem.SMInstance.REP_OnReplicatedReferencesLoaded // (Final|Native|Private) // @ game+0x5d49a70
	void PreloadAllNodeInstances(); // Function SMSystem.SMInstance.PreloadAllNodeInstances // (Final|Native|Public|BlueprintCallable) // @ game+0x5d49c70
	void OnStateMachineUpdate(float DeltaSeconds); // Function SMSystem.SMInstance.OnStateMachineUpdate // (Native|Event|Public|BlueprintEvent) // @ game+0x5d555a0
	void OnStateMachineTransitionTaken(struct FSMTransitionInfo& Transition); // Function SMSystem.SMInstance.OnStateMachineTransitionTaken // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5d4f050
	void OnStateMachineStop(); // Function SMSystem.SMInstance.OnStateMachineStop // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void OnStateMachineStateStarted(struct FSMStateInfo& State); // Function SMSystem.SMInstance.OnStateMachineStateStarted // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5d4c1a0
	void OnStateMachineStateChanged(struct FSMStateInfo& ToState, struct FSMStateInfo& FromState); // Function SMSystem.SMInstance.OnStateMachineStateChanged // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5d4a7e0
	void OnStateMachineStart(); // Function SMSystem.SMInstance.OnStateMachineStart // (Native|Event|Public|BlueprintEvent) // @ game+0x16fe6f0
	void OnStateMachineShutdown(); // Function SMSystem.SMInstance.OnStateMachineShutdown // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void OnStateMachineInitialStateLoaded(struct FGuid& StateGuid); // Function SMSystem.SMInstance.OnStateMachineInitialStateLoaded // (Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x5d4a220
	void OnStateMachineInitialized(); // Function SMSystem.SMInstance.OnStateMachineInitialized // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	void OnPreStateMachineInitialized(); // Function SMSystem.SMInstance.OnPreStateMachineInitialized // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
	void OnContextPawnRestarted(struct APawn* Pawn); // Function SMSystem.SMInstance.OnContextPawnRestarted // (Final|Native|Private) // @ game+0x5d55030
	void LoadFromState(struct FGuid& FromGuid, bool bAllParents, bool bNotify); // Function SMSystem.SMInstance.LoadFromState // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5d4f430
	void LoadFromMultipleStates(struct TArray<struct FGuid>& FromGuids, bool bNotify); // Function SMSystem.SMInstance.LoadFromMultipleStates // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d52dc0
	void K2_TryGetNetworkInterface(struct TScriptInterface<ISMStateMachineNetworkedInterface>& Interface, bool& bIsValid); // Function SMSystem.SMInstance.K2_TryGetNetworkInterface // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d5a0f0
	void K2_InitializeAsync(struct UObject* Context, struct FLatentActionInfo LatentInfo); // Function SMSystem.SMInstance.K2_InitializeAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x5d51820
	bool IsTickableWhenPaused(); // Function SMSystem.SMInstance.IsTickableWhenPaused // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d55220
	bool IsTickable(); // Function SMSystem.SMInstance.IsTickable // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d59f70
	bool IsStopping(); // Function SMSystem.SMInstance.IsStopping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d55af0
	bool IsInitializingAsync(); // Function SMSystem.SMInstance.IsInitializingAsync // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d59010
	bool IsInitialized(); // Function SMSystem.SMInstance.IsInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d56e80
	bool IsInEndState(); // Function SMSystem.SMInstance.IsInEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d50980
	bool IsActive(); // Function SMSystem.SMInstance.IsActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4fdf0
	void Internal_Update(float DeltaSeconds); // Function SMSystem.SMInstance.Internal_Update // (Final|Native|Protected|BlueprintCallable) // @ game+0x5d50af0
	void Internal_EventUpdate(); // Function SMSystem.SMInstance.Internal_EventUpdate // (Final|Native|Protected|BlueprintCallable) // @ game+0x5d512f0
	void Internal_EventCleanup(struct FGuid& PathGuid); // Function SMSystem.SMInstance.Internal_EventCleanup // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5d4f310
	bool Internal_EvaluateAndTakeTransitionChainByGuid(struct FGuid& PathGuid); // Function SMSystem.SMInstance.Internal_EvaluateAndTakeTransitionChainByGuid // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5d4a460
	void Initialize(struct UObject* Context); // Function SMSystem.SMInstance.Initialize // (Native|Public|BlueprintCallable) // @ game+0x5d4dc80
	bool HasStarted(); // Function SMSystem.SMInstance.HasStarted // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d51390
	struct USMTransitionInstance* GetTransitionInstanceByGuid(struct FGuid& Guid); // Function SMSystem.SMInstance.GetTransitionInstanceByGuid // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d59af0
	float GetTickInterval(); // Function SMSystem.SMInstance.GetTickInterval // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d50700
	bool GetStopOnEndState(); // Function SMSystem.SMInstance.GetStopOnEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d58ff0
	struct USMStateMachineInstance* GetStateMachineClass(); // Function SMSystem.SMInstance.GetStateMachineClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d51cb0
	struct USMStateInstance_Base* GetStateInstanceByQualifiedName(struct FString InFullPath); // Function SMSystem.SMInstance.GetStateInstanceByQualifiedName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d52390
	struct USMStateInstance_Base* GetStateInstanceByGuid(struct FGuid& Guid); // Function SMSystem.SMInstance.GetStateInstanceByGuid // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4d180
	int32_t GetStateHistoryMaxCount(); // Function SMSystem.SMInstance.GetStateHistoryMaxCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d56570
	struct TArray<struct FSMStateHistory> GetStateHistory(); // Function SMSystem.SMInstance.GetStateHistory // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4c520
	struct USMStateInstance_Base* GetSingleActiveStateInstance(bool bCheckNested); // Function SMSystem.SMInstance.GetSingleActiveStateInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d55690
	struct FGuid GetSingleActiveStateGuid(bool bCheckNested); // Function SMSystem.SMInstance.GetSingleActiveStateGuid // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4b1a0
	struct USMStateMachineInstance* GetRootStateMachineNodeInstance(); // Function SMSystem.SMInstance.GetRootStateMachineNodeInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4b9f0
	struct USMStateMachineInstance* GetRootStateMachineNodeClass(); // Function SMSystem.SMInstance.GetRootStateMachineNodeClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d51cb0
	struct USMInstance* GetReferenceOwner(); // Function SMSystem.SMInstance.GetReferenceOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4a7c0
	struct USMInstance* GetReferencedInstanceByGuid(struct FGuid& Guid); // Function SMSystem.SMInstance.GetReferencedInstanceByGuid // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4fd40
	struct USMInstance* GetPrimaryReferenceOwner(); // Function SMSystem.SMInstance.GetPrimaryReferenceOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5d51110
	struct USMNodeInstance* GetNodeInstanceByGuid(struct FGuid& Guid); // Function SMSystem.SMInstance.GetNodeInstanceByGuid // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4c3f0
	struct TScriptInterface<ISMStateMachineNetworkedInterface> GetNetworkInterface(); // Function SMSystem.SMInstance.GetNetworkInterface // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d59030
	struct UInputComponent* GetInputComponent(); // Function SMSystem.SMInstance.GetInputComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4a7a0
	struct TMap<struct FGuid, struct FGuid> GetGuidRedirectMap(); // Function SMSystem.SMInstance.GetGuidRedirectMap // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5d4d9c0
	struct UObject* GetContext(); // Function SMSystem.SMInstance.GetContext // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4c590
	struct USMStateMachineComponent* GetComponentOwner(); // Function SMSystem.SMInstance.GetComponentOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2517770
	void GetAllTransitionInstances(struct TArray<struct USMTransitionInstance*>& TransitionInstances); // Function SMSystem.SMInstance.GetAllTransitionInstances // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d52c80
	void GetAllStateInstances(struct TArray<struct USMStateInstance_Base*>& StateInstances); // Function SMSystem.SMInstance.GetAllStateInstances // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d50050
	struct TArray<struct USMInstance*> GetAllReferencedInstances(bool bIncludeChildren); // Function SMSystem.SMInstance.GetAllReferencedInstances // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d51bc0
	void GetAllActiveStateInstances(struct TArray<struct USMStateInstance_Base*>& ActiveStateInstances); // Function SMSystem.SMInstance.GetAllActiveStateInstances // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d56c80
	void GetAllActiveStateGuids(struct TArray<struct FGuid>& ActiveGuids); // Function SMSystem.SMInstance.GetAllActiveStateGuids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d56a40
	void EvaluateTransitions(); // Function SMSystem.SMInstance.EvaluateTransitions // (Final|Native|Public|BlueprintCallable) // @ game+0x5d57fd0
	bool EvaluateAndTakeTransitionChain(struct USMTransitionInstance* InFirstTransitionInstance); // Function SMSystem.SMInstance.EvaluateAndTakeTransitionChain // (Final|Native|Public|BlueprintCallable) // @ game+0x5d59770
	bool EvaluateAndFindTransitionChain(struct USMTransitionInstance* InFirstTransitionInstance, struct TArray<struct USMTransitionInstance*>& OutTransitionChain, struct USMStateInstance_Base*& OutDestinationState, bool bRequirePreviousStateActive); // Function SMSystem.SMInstance.EvaluateAndFindTransitionChain // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5d502a0
	void ClearStateHistory(); // Function SMSystem.SMInstance.ClearStateHistory // (Final|Native|Public|BlueprintCallable) // @ game+0x5d50a30
	void ClearLoadedStates(); // Function SMSystem.SMInstance.ClearLoadedStates // (Final|Native|Public|BlueprintCallable) // @ game+0x5d4da90
	bool CanTickOnManualUpdate(); // Function SMSystem.SMInstance.CanTickOnManualUpdate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d59ad0
	bool CanEverTick(); // Function SMSystem.SMInstance.CanEverTick // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d4d2e0
	bool CanAutoManageTime(); // Function SMSystem.SMInstance.CanAutoManageTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d592e0
	bool AreInitialStatesSetFromLoad(); // Function SMSystem.SMInstance.AreInitialStatesSetFromLoad // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d56460
};

// Class SMSystem.SMCompilerLog
// Size: 0xa0 (Inherited: 0xa0)
struct USMCompilerLog : UObject {

	void LogProperty(struct FName PropertyName, struct USMNodeInstance* NodeInstance, struct FString Message, enum class ESMCompilerLogType Severity, bool bHighlight, bool bSilent, int32_t ArrayIndex); // Function SMSystem.SMCompilerLog.LogProperty // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5d210
	void Log(enum class ESMCompilerLogType Severity, struct FString Message); // Function SMSystem.SMCompilerLog.Log // (Final|Native|Public|BlueprintCallable) // @ game+0x5d5edc0
};

// Class SMSystem.SMRuntimeSettings
// Size: 0xa0 (Inherited: 0xa0)
struct USMRuntimeSettings : UObject {
	bool bPreloadDefaultNodes; // 0x98(0x01)
};

// Class SMSystem.SMStateInstance
// Size: 0x160 (Inherited: 0x160)
struct USMStateInstance : USMStateInstance_Base {

	void RemoveStateFromStack(int32_t StackIndex); // Function SMSystem.SMStateInstance.RemoveStateFromStack // (Final|Native|Public|BlueprintCallable) // @ game+0x5d62310
	void OnStateShutdown(); // Function SMSystem.SMStateInstance.OnStateShutdown // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2f930f0
	void OnStateInitialized(); // Function SMSystem.SMStateInstance.OnStateInitialized // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2ce7e50
	int32_t GetStateStackCount(); // Function SMSystem.SMStateInstance.GetStateStackCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d618e0
	struct USMStateInstance_Base* GetStateInStackByClass(struct USMStateInstance* StateClass, bool bIncludeChildren); // Function SMSystem.SMStateInstance.GetStateInStackByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d63670
	struct USMStateInstance_Base* GetStateInStack(int32_t Index); // Function SMSystem.SMStateInstance.GetStateInStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d63bc0
	int32_t GetStateIndexInStack(struct USMStateInstance_Base* StateInstance); // Function SMSystem.SMStateInstance.GetStateIndexInStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d610f0
	struct USMStateInstance_Base* GetStackOwnerInstance(); // Function SMSystem.SMStateInstance.GetStackOwnerInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64900
	void GetAllStateStackInstances(struct TArray<struct USMStateInstance_Base*>& StateStackInstances); // Function SMSystem.SMStateInstance.GetAllStateStackInstances // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d60ae0
	void GetAllStatesInStackOfClass(struct USMStateInstance* StateClass, struct TArray<struct USMStateInstance_Base*>& StateStackInstances, bool bIncludeChildren); // Function SMSystem.SMStateInstance.GetAllStatesInStackOfClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d64ac0
	void ClearStateStack(); // Function SMSystem.SMStateInstance.ClearStateStack // (Final|Native|Public|BlueprintCallable) // @ game+0x5d61b10
	struct USMStateInstance* AddStateToStack(struct USMStateInstance* StateClass, int32_t StackIndex); // Function SMSystem.SMStateInstance.AddStateToStack // (Final|Native|Public|BlueprintCallable) // @ game+0x5d642a0
};

// Class SMSystem.SMEntryStateInstance
// Size: 0x160 (Inherited: 0x160)
struct USMEntryStateInstance : USMStateInstance_Base {
};

// Class SMSystem.SMAnyStateInstance
// Size: 0x160 (Inherited: 0x160)
struct USMAnyStateInstance : USMStateInstance_Base {
};

// Class SMSystem.SMStateMachineComponent
// Size: 0x2c0 (Inherited: 0x160)
struct USMStateMachineComponent : UActorComponent {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMulticastInlineDelegate OnStateMachineInitializedEvent; // 0x168(0x10)
	struct FMulticastInlineDelegate OnStateMachineStartedEvent; // 0x178(0x10)
	struct FMulticastInlineDelegate OnStateMachineUpdatedEvent; // 0x188(0x10)
	struct FMulticastInlineDelegate OnStateMachineStoppedEvent; // 0x198(0x10)
	struct FMulticastInlineDelegate OnStateMachineShutdownEvent; // 0x1a8(0x10)
	struct FMulticastInlineDelegate OnStateMachineTransitionTakenEvent; // 0x1b8(0x10)
	struct FMulticastInlineDelegate OnStateMachineStateChangedEvent; // 0x1c8(0x10)
	struct FMulticastInlineDelegate OnStateMachineStateStartedEvent; // 0x1d8(0x10)
	struct TSet<struct UActorChannel*> CurrentActorChannels; // 0x1e8(0x50)
	char pad_238[0x24]; // 0x238(0x24)
	char bAutomaticallyHandleNewConnections : 1; // 0x25c(0x01)
	char pad_25c_1 : 7; // 0x25c(0x01)
	char pad_25d[0x3]; // 0x25d(0x03)
	struct USMInstance* StateMachineClass; // 0x260(0x08)
	char bInitializeOnBeginPlay : 1; // 0x268(0x01)
	char bStartOnBeginPlay : 1; // 0x268(0x01)
	char bStopOnEndPlay : 1; // 0x268(0x01)
	char pad_268_3 : 5; // 0x268(0x01)
	enum class ESMThreadMode BeginPlayInitializationMode; // 0x269(0x01)
	char bReuseInstanceAfterShutdown : 1; // 0x26a(0x01)
	char bLetInstanceManageTick : 1; // 0x26a(0x01)
	char pad_26a_2 : 6; // 0x26a(0x01)
	enum class ESMNetworkConfigurationType StateChangeAuthority; // 0x26b(0x01)
	enum class ESMNetworkConfigurationType NetworkTickConfiguration; // 0x26c(0x01)
	enum class ESMNetworkConfigurationType NetworkStateExecution; // 0x26d(0x01)
	char bIncludeSimulatedProxies : 1; // 0x26e(0x01)
	char pad_26e_1 : 7; // 0x26e(0x01)
	enum class ESMThreadMode ReplicatedInitializationMode; // 0x26f(0x01)
	enum class ESMNetworkConfigurationType NetworkTransitionEnteredConfiguration; // 0x270(0x01)
	char bWaitForTransactionsFromServer : 1; // 0x271(0x01)
	char bHandleControllerChange : 1; // 0x271(0x01)
	char bCalculateServerTimeForClients : 1; // 0x271(0x01)
	char bUseOwnerNetUpdateFrequency : 1; // 0x271(0x01)
	char pad_271_4 : 4; // 0x271(0x01)
	char pad_272[0x2]; // 0x272(0x02)
	float ServerNetUpdateFrequency; // 0x274(0x04)
	float ClientNetUpdateFrequency; // 0x278(0x04)
	char bAlwaysMulticast : 1; // 0x27c(0x01)
	char pad_27c_1 : 7; // 0x27c(0x01)
	char pad_27d[0x3]; // 0x27d(0x03)
	struct USMStateMachineComponent* ComponentToCopy; // 0x280(0x08)
	char pad_288[0x18]; // 0x288(0x18)
	struct USMInstance* R_Instance; // 0x2a0(0x08)
	struct USMInstance* InstanceTemplate; // 0x2a8(0x08)
	char bCanInstanceNetworkTick : 1; // 0x2b0(0x01)
	char pad_2b0_1 : 7; // 0x2b0(0x01)
	char pad_2b1[0xf]; // 0x2b1(0x0f)

	void Update(float DeltaSeconds); // Function SMSystem.SMStateMachineComponent.Update // (Native|Public|BlueprintCallable) // @ game+0x5d67b00
	void Stop(); // Function SMSystem.SMStateMachineComponent.Stop // (Native|Public|BlueprintCallable) // @ game+0x5d6a270
	void Start(); // Function SMSystem.SMStateMachineComponent.Start // (Native|Public|BlueprintCallable) // @ game+0x5d6c320
	void Shutdown(); // Function SMSystem.SMStateMachineComponent.Shutdown // (Native|Public|BlueprintCallable) // @ game+0x5d6bba0
	void SetCanInstanceNetworkTick(bool bCanEverTick); // Function SMSystem.SMStateMachineComponent.SetCanInstanceNetworkTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5d6ca30
	void SERVER_Update(float DeltaTime); // Function SMSystem.SMStateMachineComponent.SERVER_Update // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d6d390
	void SERVER_TakeTransitions(struct TArray<struct FSMTransitionTransaction> TransitionTransactions); // Function SMSystem.SMStateMachineComponent.SERVER_TakeTransitions // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d67a00
	void SERVER_Stop(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.SERVER_Stop // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d6a370
	void SERVER_Start(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.SERVER_Start // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d6d990
	void SERVER_Shutdown(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.SERVER_Shutdown // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d68f50
	void SERVER_RequestFullSync(bool bForceFullRefresh); // Function SMSystem.SMStateMachineComponent.SERVER_RequestFullSync // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d69dc0
	void SERVER_Initialize(struct FSMInitializeTransaction Transaction); // Function SMSystem.SMStateMachineComponent.SERVER_Initialize // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d6c110
	void SERVER_FullSync(struct FSMFullSyncTransaction FullSyncTransaction); // Function SMSystem.SMStateMachineComponent.SERVER_FullSync // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d6cad0
	void SERVER_ActivateStates(struct TArray<struct FSMActivateStateTransaction> StateTransactions); // Function SMSystem.SMStateMachineComponent.SERVER_ActivateStates // (Net|NetReliableNative|Event|Protected|NetServer) // @ game+0x5d6be20
	void Restart(); // Function SMSystem.SMStateMachineComponent.Restart // (Native|Public|BlueprintCallable) // @ game+0x5d6cf80
	void REP_OnInstanceLoaded(); // Function SMSystem.SMStateMachineComponent.REP_OnInstanceLoaded // (Native|Protected) // @ game+0x503ad80
	void OnPostInitialize(); // Function SMSystem.SMStateMachineComponent.OnPostInitialize // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnContextPawnControllerChanged(struct APawn* Pawn, struct AController* NewController); // Function SMSystem.SMStateMachineComponent.OnContextPawnControllerChanged // (Final|Native|Private) // @ game+0x5d690f0
	void MULTICAST_TakeTransitions(struct TArray<struct FSMTransitionTransaction> Transactions); // Function SMSystem.SMStateMachineComponent.MULTICAST_TakeTransitions // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x5d6dc20
	void MULTICAST_Stop(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.MULTICAST_Stop // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x5d6b490
	void MULTICAST_Start(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.MULTICAST_Start // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x5d65170
	void MULTICAST_Shutdown(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.MULTICAST_Shutdown // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x5d69230
	void MULTICAST_FullSync(struct FSMFullSyncTransaction FullSyncTransaction); // Function SMSystem.SMStateMachineComponent.MULTICAST_FullSync // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x5d6b170
	void MULTICAST_ActivateStates(struct TArray<struct FSMActivateStateTransaction> StateTransactions); // Function SMSystem.SMStateMachineComponent.MULTICAST_ActivateStates // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x5d6a5a0
	void K2_InitializeAsync(struct UObject* Context, struct FLatentActionInfo LatentInfo); // Function SMSystem.SMStateMachineComponent.K2_InitializeAsync // (Final|Native|Public|BlueprintCallable) // @ game+0x5d698b0
	bool IsStateMachineActive(); // Function SMSystem.SMStateMachineComponent.IsStateMachineActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d69bb0
	bool IsInitialized(); // Function SMSystem.SMStateMachineComponent.IsInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6a500
	void Internal_OnStateMachineUpdated(struct USMInstance* Instance, float DeltaSeconds); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineUpdated // (Final|Native|Protected) // @ game+0x5d68710
	void Internal_OnStateMachineTransitionTaken(struct USMInstance* Instance, struct FSMTransitionInfo Transition); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineTransitionTaken // (Final|Native|Protected) // @ game+0x5d6b230
	void Internal_OnStateMachineStopped(struct USMInstance* Instance); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineStopped // (Final|Native|Protected) // @ game+0x5d69470
	void Internal_OnStateMachineStateStarted(struct USMInstance* Instance, struct FSMStateInfo State); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineStateStarted // (Final|Native|Protected) // @ game+0x5d6e3c0
	void Internal_OnStateMachineStateChanged(struct USMInstance* Instance, struct FSMStateInfo ToState, struct FSMStateInfo FromState); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineStateChanged // (Final|Native|Protected) // @ game+0x5d6dd10
	void Internal_OnStateMachineStarted(struct USMInstance* Instance); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineStarted // (Final|Native|Protected) // @ game+0x5d69630
	void Internal_OnStateMachineShutdown(struct USMInstance* Instance); // Function SMSystem.SMStateMachineComponent.Internal_OnStateMachineShutdown // (Final|Native|Protected) // @ game+0x5d67360
	void Internal_OnReplicatedInstanceInitialized(struct USMInstance* Instance); // Function SMSystem.SMStateMachineComponent.Internal_OnReplicatedInstanceInitialized // (Final|Native|Protected) // @ game+0x5d67000
	void Internal_OnInstanceInitializedAsync(struct USMInstance* Instance); // Function SMSystem.SMStateMachineComponent.Internal_OnInstanceInitializedAsync // (Final|Native|Protected) // @ game+0x5d6bcd0
	void Initialize(struct UObject* Context); // Function SMSystem.SMStateMachineComponent.Initialize // (Native|Public|BlueprintCallable) // @ game+0x5d6bd70
	struct AActor* GetTopMostParentActor(); // Function SMSystem.SMStateMachineComponent.GetTopMostParentActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6a570
	struct USMInstance* GetInstance(); // Function SMSystem.SMStateMachineComponent.GetInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d65150
	struct UObject* GetContextForInitialization(); // Function SMSystem.SMStateMachineComponent.GetContextForInitialization // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x5d6c090
	void CopySettingsFromOtherComponent(struct USMStateMachineComponent* OtherComponent); // Function SMSystem.SMStateMachineComponent.CopySettingsFromOtherComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5d6d5d0
	void CLIENT_TakeTransitions(struct TArray<struct FSMTransitionTransaction> Transactions); // Function SMSystem.SMStateMachineComponent.CLIENT_TakeTransitions // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5d66f10
	void CLIENT_Stop(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.CLIENT_Stop // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5d6e8c0
	void CLIENT_Start(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.CLIENT_Start // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5d6d8d0
	void CLIENT_Shutdown(struct FSMTransaction_Base Transaction); // Function SMSystem.SMStateMachineComponent.CLIENT_Shutdown // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5d6d2a0
	void CLIENT_FullSync(struct FSMFullSyncTransaction FullSyncTransaction); // Function SMSystem.SMStateMachineComponent.CLIENT_FullSync // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5d68810
	void CLIENT_ActivateStates(struct TArray<struct FSMActivateStateTransaction> StateTransactions); // Function SMSystem.SMStateMachineComponent.CLIENT_ActivateStates // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5d69580
};

// Class SMSystem.SMStateMachineInstance
// Size: 0x170 (Inherited: 0x160)
struct USMStateMachineInstance : USMStateInstance_Base {
	char bWaitForEndState : 1; // 0x160(0x01)
	char bReuseCurrentState : 1; // 0x160(0x01)
	char bReuseIfNotEndState : 1; // 0x160(0x01)
	char pad_160_3 : 5; // 0x160(0x01)
	char pad_161[0xf]; // 0x161(0x0f)

	void SetWaitForEndState(bool bValue); // Function SMSystem.SMStateMachineInstance.SetWaitForEndState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d6cc50
	void SetReuseIfNotEndState(bool bValue); // Function SMSystem.SMStateMachineInstance.SetReuseIfNotEndState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d68420
	void SetReuseCurrentState(bool bValue); // Function SMSystem.SMStateMachineInstance.SetReuseCurrentState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d68610
	void OnStateShutdown(); // Function SMSystem.SMStateMachineInstance.OnStateShutdown // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3b06180
	void OnStateMachineCompleted(); // Function SMSystem.SMStateMachineInstance.OnStateMachineCompleted // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2ce7e50
	void OnStateInitialized(); // Function SMSystem.SMStateMachineInstance.OnStateInitialized // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x32a8d60
	void OnEndStateReached(); // Function SMSystem.SMStateMachineInstance.OnEndStateReached // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2f930f0
	bool IsStateMachineInEndState(); // Function SMSystem.SMStateMachineInstance.IsStateMachineInEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6e760
	bool GetWaitForEndState(); // Function SMSystem.SMStateMachineInstance.GetWaitForEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d685a0
	struct USMInstance* GetStateMachineReference(); // Function SMSystem.SMStateMachineInstance.GetStateMachineReference // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d69d90
	bool GetReuseIfNotEndState(); // Function SMSystem.SMStateMachineInstance.GetReuseIfNotEndState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d69550
	bool GetReuseCurrentState(); // Function SMSystem.SMStateMachineInstance.GetReuseCurrentState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6cde0
	void GetEntryStates(struct TArray<struct USMStateInstance_Base*>& EntryStates); // Function SMSystem.SMStateMachineInstance.GetEntryStates // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6b780
	struct USMStateInstance_Base* GetContainedStateByName(struct FString StateName); // Function SMSystem.SMStateMachineInstance.GetContainedStateByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d69aa0
	void GetAllStateInstances(struct TArray<struct USMStateInstance_Base*>& StateInstances); // Function SMSystem.SMStateMachineInstance.GetAllStateInstances // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d67590
	void GetActiveStates(struct TArray<struct USMStateInstance_Base*>& ActiveStates); // Function SMSystem.SMStateMachineInstance.GetActiveStates // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d693a0
};

// Class SMSystem.SMTransitionInstance
// Size: 0x130 (Inherited: 0x120)
struct USMTransitionInstance : USMNodeInstance {
	int32_t PriorityOrder; // 0x118(0x04)
	char bRunParallel : 1; // 0x11c(0x01)
	char bEvalIfNextStateActive : 1; // 0x11c(0x01)
	char bCanEvaluate : 1; // 0x11c(0x01)
	char bCanEvaluateFromEvent : 1; // 0x11c(0x01)
	char bCanEvalWithStartState : 1; // 0x11c(0x01)
	struct FMulticastInlineDelegate OnTransitionEnteredEvent; // 0x120(0x10)

	void SetRunParallel(bool bValue); // Function SMSystem.SMTransitionInstance.SetRunParallel // (Final|Native|Public|BlueprintCallable) // @ game+0x5d76470
	void SetPriorityOrder(int32_t Value); // Function SMSystem.SMTransitionInstance.SetPriorityOrder // (Final|Native|Public|BlueprintCallable) // @ game+0x5d7a3b0
	void SetEvalIfNextStateActive(bool bValue); // Function SMSystem.SMTransitionInstance.SetEvalIfNextStateActive // (Final|Native|Public|BlueprintCallable) // @ game+0x5d78960
	void SetCanEvalWithStartState(bool bValue); // Function SMSystem.SMTransitionInstance.SetCanEvalWithStartState // (Final|Native|Public|BlueprintCallable) // @ game+0x5d7b370
	void SetCanEvaluateFromEvent(bool bValue); // Function SMSystem.SMTransitionInstance.SetCanEvaluateFromEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5d74cc0
	void SetCanEvaluate(bool bValue); // Function SMSystem.SMTransitionInstance.SetCanEvaluate // (Final|Native|Public|BlueprintCallable) // @ game+0x5d6f8d0
	void OnTransitionShutdown(); // Function SMSystem.SMTransitionInstance.OnTransitionShutdown // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2ce7e50
	void OnTransitionInitialized(); // Function SMSystem.SMTransitionInstance.OnTransitionInitialized // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5d60060
	void OnTransitionEntered(); // Function SMSystem.SMTransitionInstance.OnTransitionEntered // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2b63d50
	bool IsTransitionFromLinkState(); // Function SMSystem.SMTransitionInstance.IsTransitionFromLinkState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d78830
	bool IsTransitionFromAnyState(); // Function SMSystem.SMTransitionInstance.IsTransitionFromAnyState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d75fc0
	int32_t GetTransitionStackCount(); // Function SMSystem.SMTransitionInstance.GetTransitionStackCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d618e0
	struct USMTransitionInstance* GetTransitionInStackByClass(struct USMTransitionInstance* TransitionClass, bool bIncludeChildren); // Function SMSystem.SMTransitionInstance.GetTransitionInStackByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6f9c0
	struct USMTransitionInstance* GetTransitionInStack(int32_t Index); // Function SMSystem.SMTransitionInstance.GetTransitionInStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d70ee0
	void GetTransitionInfo(struct FSMTransitionInfo& Transition); // Function SMSystem.SMTransitionInstance.GetTransitionInfo // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d7acc0
	int32_t GetTransitionIndexInStack(struct USMTransitionInstance* TransitionInstance); // Function SMSystem.SMTransitionInstance.GetTransitionIndexInStack // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d610f0
	struct USMTransitionInstance* GetStackOwnerInstance(); // Function SMSystem.SMTransitionInstance.GetStackOwnerInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d790c0
	struct USMStateInstance_Base* GetSourceStateForActiveTransition(); // Function SMSystem.SMTransitionInstance.GetSourceStateForActiveTransition // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d75440
	struct FDateTime GetServerTimestamp(); // Function SMSystem.SMTransitionInstance.GetServerTimestamp // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d727c0
	bool GetRunParallel(); // Function SMSystem.SMTransitionInstance.GetRunParallel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d733a0
	int32_t GetPriorityOrder(); // Function SMSystem.SMTransitionInstance.GetPriorityOrder // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d73ab0
	struct USMStateInstance_Base* GetPreviousStateInstance(); // Function SMSystem.SMTransitionInstance.GetPreviousStateInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d70eb0
	struct USMStateInstance_Base* GetNextStateInstance(); // Function SMSystem.SMTransitionInstance.GetNextStateInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d72d60
	bool GetEvalIfNextStateActive(); // Function SMSystem.SMTransitionInstance.GetEvalIfNextStateActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d721a0
	struct USMStateInstance_Base* GetDestinationStateForActiveTransition(); // Function SMSystem.SMTransitionInstance.GetDestinationStateForActiveTransition // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d6fdf0
	bool GetCanEvalWithStartState(); // Function SMSystem.SMTransitionInstance.GetCanEvalWithStartState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d76590
	bool GetCanEvaluateFromEvent(); // Function SMSystem.SMTransitionInstance.GetCanEvaluateFromEvent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d727f0
	bool GetCanEvaluate(); // Function SMSystem.SMTransitionInstance.GetCanEvaluate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d737a0
	void GetAllTransitionStackInstances(struct TArray<struct USMTransitionInstance*>& TransitionStackInstances); // Function SMSystem.SMTransitionInstance.GetAllTransitionStackInstances // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d754f0
	void GetAllTransitionsInStackOfClass(struct USMTransitionInstance* TransitionClass, struct TArray<struct USMTransitionInstance*>& TransitionStackInstances, bool bIncludeChildren); // Function SMSystem.SMTransitionInstance.GetAllTransitionsInStackOfClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d72fd0
	bool EvaluateFromManuallyBoundEvent(); // Function SMSystem.SMTransitionInstance.EvaluateFromManuallyBoundEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5d76510
	bool DoesTransitionPass(); // Function SMSystem.SMTransitionInstance.DoesTransitionPass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5d77150
	bool CanEnterTransition(); // Function SMSystem.SMTransitionInstance.CanEnterTransition // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x31dafa0
};

// Class SMSystem.SMBlueprintUtils
// Size: 0xa0 (Inherited: 0xa0)
struct USMBlueprintUtils : UBlueprintFunctionLibrary {

	struct USMInstance* K2_CreateStateMachineInstancePure(struct USMInstance* StateMachineClass, struct UObject* Context, bool bInitializeNow); // Function SMSystem.SMBlueprintUtils.K2_CreateStateMachineInstancePure // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5d6f260
	struct USMInstance* K2_CreateStateMachineInstanceAsync(struct USMInstance* StateMachineClass, struct UObject* Context, struct FLatentActionInfo LatentInfo); // Function SMSystem.SMBlueprintUtils.K2_CreateStateMachineInstanceAsync // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d73410
	struct USMInstance* K2_CreateStateMachineInstance(struct USMInstance* StateMachineClass, struct UObject* Context, bool bInitializeNow); // Function SMSystem.SMBlueprintUtils.K2_CreateStateMachineInstance // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d6f260
	struct USMInstance* CreateStateMachineInstanceFromTemplate(struct USMInstance* StateMachineClass, struct UObject* Context, struct USMInstance* Template, bool bInitializeNow); // Function SMSystem.SMBlueprintUtils.CreateStateMachineInstanceFromTemplate // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5d768a0
};

