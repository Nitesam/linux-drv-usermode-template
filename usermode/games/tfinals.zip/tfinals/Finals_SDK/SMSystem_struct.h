// Enum SMSystem.ESMLogType
enum class ESMLogType : uint8_t {
	Note = 0,
	Warning = 1,
	Error = 2,
	ESMLogType_MAX = 3
};

// Enum SMSystem.ESMNetworkConfigurationType
enum class ESMNetworkConfigurationType : uint8_t {
	SM_Client = 0,
	SM_Server = 1,
	SM_ClientAndServer = 2,
	SM_MAX = 3
};

// Enum SMSystem.ESMExposedFunctionExecutionType
enum class ESMExposedFunctionExecutionType : uint8_t {
	SM_Graph = 0,
	SM_NodeInstance = 1,
	SM_None = 2,
	SM_MAX = 3
};

// Enum SMSystem.ESMConditionalEvaluationType
enum class ESMConditionalEvaluationType : uint8_t {
	SM_Graph = 0,
	SM_NodeInstance = 1,
	SM_AlwaysFalse = 2,
	SM_AlwaysTrue = 3,
	SM_MAX = 4
};

// Enum SMSystem.ESMStateMachineInput
enum class ESMStateMachineInput : uint8_t {
	Disabled = 0,
	UseContextController = 1,
	Player0 = 2,
	Player1 = 3,
	Player2 = 4,
	Player3 = 5,
	Player4 = 6,
	Player5 = 7,
	Player6 = 8,
	Player7 = 9,
	ESMStateMachineInput_MAX = 10
};

// Enum SMSystem.ESMNodeInput
enum class ESMNodeInput : uint8_t {
	Disabled = 0,
	UseOwningStateMachine = 1,
	UseContextController = 2,
	Player0 = 3,
	Player1 = 4,
	Player2 = 5,
	Player3 = 6,
	Player4 = 7,
	Player5 = 8,
	Player6 = 9,
	Player7 = 10,
	ESMNodeInput_MAX = 11
};

// Enum SMSystem.ESMExecutionEnvironment
enum class ESMExecutionEnvironment : uint8_t {
	EditorExecution = 0,
	GameExecution = 1,
	ESMExecutionEnvironment_MAX = 2
};

// Enum SMSystem.ESMValidEditorNode
enum class ESMValidEditorNode : uint8_t {
	IsValidEditorNode = 0,
	IsNotValidEditorNode = 1,
	ESMValidEditorNode_MAX = 2
};

// Enum SMSystem.ESMCompilerLogType
enum class ESMCompilerLogType : uint8_t {
	Note = 0,
	Warning = 1,
	Error = 2,
	ESMCompilerLogType_MAX = 3
};

// Enum SMSystem.ESMThreadMode
enum class ESMThreadMode : uint8_t {
	Blocking = 0,
	Async = 1,
	ESMThreadMode_MAX = 2
};

// Enum SMSystem.ESMTransactionType
enum class ESMTransactionType : uint8_t {
	SM_Unknown = 0,
	SM_Transition = 1,
	SM_State = 2,
	SM_FullSync = 3,
	SM_Start = 4,
	SM_Stop = 5,
	SM_Initialize = 6,
	SM_Shutdown = 7,
	SM_MAX = 8
};

// Enum SMSystem.ESMOptionalBool
enum class ESMOptionalBool : uint8_t {
	Unset = 0,
	IsFalse = 1,
	IsTrue = 2,
	ESMOptionalBool_MAX = 3
};

// ScriptStruct SMSystem.SMInfo_Base
// Size: 0x60 (Inherited: 0x00)
struct FSMInfo_Base {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString NodeName; // 0x08(0x10)
	struct FGuid Guid; // 0x18(0x10)
	struct FGuid OwnerGuid; // 0x28(0x10)
	struct FGuid NodeGuid; // 0x38(0x10)
	struct FGuid OwnerNodeGuid; // 0x48(0x10)
	struct USMNodeInstance* NodeInstance; // 0x58(0x08)
};

// ScriptStruct SMSystem.SMStateInfo
// Size: 0x80 (Inherited: 0x60)
struct FSMStateInfo : FSMInfo_Base {
	struct TArray<struct FSMTransitionInfo> OutgoingTransitions; // 0x60(0x10)
	bool bIsEndState; // 0x70(0x01)
	char pad_71[0xf]; // 0x71(0x0f)
};

// ScriptStruct SMSystem.SMTransitionInfo
// Size: 0x98 (Inherited: 0x60)
struct FSMTransitionInfo : FSMInfo_Base {
	struct FGuid FromStateGuid; // 0x60(0x10)
	struct FGuid ToStateGuid; // 0x70(0x10)
	int32_t Priority; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FDateTime LastNetworkTimestamp; // 0x88(0x08)
	char pad_90[0x8]; // 0x90(0x08)
};

// ScriptStruct SMSystem.SMNode_Base
// Size: 0x138 (Inherited: 0x00)
struct FSMNode_Base {
	char pad_0[0x10]; // 0x00(0x10)
	float TimeInState; // 0x10(0x04)
	bool bIsInEndState; // 0x14(0x01)
	bool bHasUpdated; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	int32_t DuplicateId; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct FVector2D NodePosition; // 0x20(0x10)
	char bHasInputEvents : 1; // 0x30(0x01)
	char pad_30_1 : 7; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	struct FGuid Guid; // 0x34(0x10)
	struct FGuid OwnerGuid; // 0x44(0x10)
	struct FGuid PathGuid; // 0x54(0x10)
	char pad_64[0xc]; // 0x64(0x0c)
	struct FString NodeName; // 0x70(0x10)
	struct FName TemplateName; // 0x80(0x08)
	struct TArray<struct FName> StackTemplateNames; // 0x88(0x10)
	struct TArray<struct USMNodeInstance*> StackNodeInstances; // 0x98(0x10)
	struct TArray<ClassPtrProperty> NodeStackClasses; // 0xa8(0x10)
	struct USMInstance* OwningInstance; // 0xb8(0x08)
	struct USMNodeInstance* NodeInstance; // 0xc0(0x08)
	char pad_c8[0x10]; // 0xc8(0x10)
	struct TMap<struct FGuid, struct FSMGraphPropertyTemplateOwner> TemplateVariableGraphProperties; // 0xd8(0x50)
	ClassPtrProperty NodeInstanceClass; // 0x128(0x08)
	char pad_130[0x8]; // 0x130(0x08)
};

// ScriptStruct SMSystem.SMGraphPropertyTemplateOwner
// Size: 0x10 (Inherited: 0x00)
struct FSMGraphPropertyTemplateOwner {
	struct TArray<struct FSMGraphProperty_Base_Runtime> VariableGraphProperties; // 0x00(0x10)
};

// ScriptStruct SMSystem.SMGraphProperty_Base_Runtime
// Size: 0x48 (Inherited: 0x00)
struct FSMGraphProperty_Base_Runtime {
	char pad_0[0x18]; // 0x00(0x18)
	struct FGuid Guid; // 0x18(0x10)
	struct FGuid OwnerGuid; // 0x28(0x10)
	char bIsDefaultValueOnly : 1; // 0x38(0x01)
	char pad_38_1 : 7; // 0x38(0x01)
	char pad_39[0xf]; // 0x39(0x0f)
};

// ScriptStruct SMSystem.SMState_Base
// Size: 0x188 (Inherited: 0x138)
struct FSMState_Base : FSMNode_Base {
	char bIsRootNode : 1; // 0x138(0x01)
	char bAlwaysUpdate : 1; // 0x138(0x01)
	char bEvalTransitionsOnStart : 1; // 0x138(0x01)
	char bDisableTickTransitionEvaluation : 1; // 0x138(0x01)
	char bStayActiveOnStateChange : 1; // 0x138(0x01)
	char bAllowParallelReentry : 1; // 0x138(0x01)
	char bCanBeEndState : 1; // 0x138(0x01)
	char pad_138_7 : 1; // 0x138(0x01)
	char pad_139[0x4f]; // 0x139(0x4f)
};

// ScriptStruct SMSystem.SMConduit
// Size: 0x190 (Inherited: 0x188)
struct FSMConduit : FSMState_Base {
	char bCanEnterTransition : 1; // 0x188(0x01)
	char bCanEvaluate : 1; // 0x188(0x01)
	char bEvalWithTransitions : 1; // 0x188(0x01)
	char pad_188_3 : 5; // 0x188(0x01)
	enum class ESMConditionalEvaluationType ConditionalEvaluationType; // 0x189(0x01)
	char pad_18a[0x6]; // 0x18a(0x06)
};

// ScriptStruct SMSystem.SMExposedFunctionHandler
// Size: 0x18 (Inherited: 0x00)
struct FSMExposedFunctionHandler {
	struct FName BoundFunction; // 0x00(0x08)
	enum class ESMExposedFunctionExecutionType ExecutionType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UFunction* Function; // 0x10(0x08)
};

// ScriptStruct SMSystem.SMExposedFunctionContainer
// Size: 0x10 (Inherited: 0x00)
struct FSMExposedFunctionContainer {
	struct TArray<struct FSMExposedFunctionHandler> ExposedFunctionHandlers; // 0x00(0x10)
};

// ScriptStruct SMSystem.SMNode_FunctionHandlers
// Size: 0x48 (Inherited: 0x00)
struct FSMNode_FunctionHandlers {
	struct TArray<struct FSMExposedFunctionHandler> NodeInitializedGraphEvaluators; // 0x00(0x10)
	struct TArray<struct FSMExposedFunctionHandler> NodeShutdownGraphEvaluators; // 0x10(0x10)
	struct TArray<struct FSMExposedFunctionHandler> OnRootStateMachineStartedGraphEvaluator; // 0x20(0x10)
	struct TArray<struct FSMExposedFunctionHandler> OnRootStateMachineStoppedGraphEvaluator; // 0x30(0x10)
	char pad_40[0x8]; // 0x40(0x08)
};

// ScriptStruct SMSystem.SMState_FunctionHandlers
// Size: 0x78 (Inherited: 0x48)
struct FSMState_FunctionHandlers : FSMNode_FunctionHandlers {
	struct TArray<struct FSMExposedFunctionHandler> BeginStateGraphEvaluator; // 0x48(0x10)
	struct TArray<struct FSMExposedFunctionHandler> UpdateStateGraphEvaluator; // 0x58(0x10)
	struct TArray<struct FSMExposedFunctionHandler> EndStateGraphEvaluator; // 0x68(0x10)
};

// ScriptStruct SMSystem.SMConduit_FunctionHandlers
// Size: 0x68 (Inherited: 0x48)
struct FSMConduit_FunctionHandlers : FSMNode_FunctionHandlers {
	struct TArray<struct FSMExposedFunctionHandler> CanEnterConduitGraphEvaluator; // 0x48(0x10)
	struct TArray<struct FSMExposedFunctionHandler> ConduitEnteredGraphEvaluator; // 0x58(0x10)
};

// ScriptStruct SMSystem.SMTransition_FunctionHandlers
// Size: 0x88 (Inherited: 0x48)
struct FSMTransition_FunctionHandlers : FSMNode_FunctionHandlers {
	struct TArray<struct FSMExposedFunctionHandler> CanEnterTransitionGraphEvaluator; // 0x48(0x10)
	struct TArray<struct FSMExposedFunctionHandler> TransitionEnteredGraphEvaluator; // 0x58(0x10)
	struct TArray<struct FSMExposedFunctionHandler> TransitionPreEvaluateGraphEvaluator; // 0x68(0x10)
	struct TArray<struct FSMExposedFunctionHandler> TransitionPostEvaluateGraphEvaluator; // 0x78(0x10)
};

// ScriptStruct SMSystem.SMExposedNodeFunctions
// Size: 0x80 (Inherited: 0x00)
struct FSMExposedNodeFunctions {
	struct TArray<struct FSMState_FunctionHandlers> FSMState_FunctionHandlers; // 0x00(0x10)
	struct TArray<struct FSMConduit_FunctionHandlers> FSMConduit_FunctionHandlers; // 0x10(0x10)
	struct TArray<struct FSMTransition_FunctionHandlers> FSMTransition_FunctionHandlers; // 0x20(0x10)
	struct TMap<struct FGuid, struct FSMExposedFunctionContainer> GraphPropertyFunctionHandlers; // 0x30(0x50)
};

// ScriptStruct SMSystem.SMGraphProperty_Runtime
// Size: 0x48 (Inherited: 0x48)
struct FSMGraphProperty_Runtime : FSMGraphProperty_Base_Runtime {
};

// ScriptStruct SMSystem.SMGraphProperty_Base
// Size: 0x108 (Inherited: 0x48)
struct FSMGraphProperty_Base : FSMGraphProperty_Base_Runtime {
	struct FName VariableName; // 0x48(0x08)
	struct FEdGraphPinType VariableType; // 0x50(0x58)
	struct FMemberReference MemberReference; // 0xa8(0x38)
	bool bIsInArray; // 0xe0(0x01)
	bool bReadOnly; // 0xe1(0x01)
	bool bHidden; // 0xe2(0x01)
	char pad_e3[0x1]; // 0xe3(0x01)
	struct FGuid GuidUnmodified; // 0xe4(0x10)
	struct FGuid TemplateGuid; // 0xf4(0x10)
	int32_t GuidIndex; // 0x104(0x04)
};

// ScriptStruct SMSystem.SMGraphProperty
// Size: 0x108 (Inherited: 0x108)
struct FSMGraphProperty : FSMGraphProperty_Base {
};

// ScriptStruct SMSystem.SMDebugStateMachine
// Size: 0x01 (Inherited: 0x00)
struct FSMDebugStateMachine {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct SMSystem.SMReferenceContainer
// Size: 0x18 (Inherited: 0x00)
struct FSMReferenceContainer {
	struct FGuid PathGuid; // 0x00(0x10)
	struct USMInstance* Reference; // 0x10(0x08)
};

// ScriptStruct SMSystem.SMGuidMap
// Size: 0x50 (Inherited: 0x00)
struct FSMGuidMap {
	struct TMap<struct FGuid, struct FGuid> NodeToPathGuids; // 0x00(0x50)
};

// ScriptStruct SMSystem.SMNodeDescription
// Size: 0x38 (Inherited: 0x00)
struct FSMNodeDescription {
	struct FName Name; // 0x00(0x08)
	struct FText Category; // 0x08(0x18)
	struct FText Description; // 0x20(0x18)
};

// ScriptStruct SMSystem.SMNodeClassRule
// Size: 0x10 (Inherited: 0x00)
struct FSMNodeClassRule {
	char pad_0[0x8]; // 0x00(0x08)
	bool bIncludeChildren; // 0x08(0x01)
	bool bNOT; // 0x09(0x01)
	char pad_a[0x6]; // 0x0a(0x06)
};

// ScriptStruct SMSystem.SMStateClassRule
// Size: 0x38 (Inherited: 0x10)
struct FSMStateClassRule : FSMNodeClassRule {
	struct TSoftClassPtr<UObject> StateClass; // 0x10(0x28)
};

// ScriptStruct SMSystem.SMTransitionClassRule
// Size: 0x38 (Inherited: 0x10)
struct FSMTransitionClassRule : FSMNodeClassRule {
	struct TSoftClassPtr<UObject> TransitionClass; // 0x10(0x28)
};

// ScriptStruct SMSystem.SMStateMachineClassRule
// Size: 0x38 (Inherited: 0x10)
struct FSMStateMachineClassRule : FSMNodeClassRule {
	struct TSoftClassPtr<UObject> StateMachineClass; // 0x10(0x28)
};

// ScriptStruct SMSystem.SMNodeConnectionRule
// Size: 0xa8 (Inherited: 0x00)
struct FSMNodeConnectionRule {
	struct FSMStateClassRule FromState; // 0x00(0x38)
	struct FSMStateClassRule ToState; // 0x38(0x38)
	struct FSMStateMachineClassRule InStateMachine; // 0x70(0x38)
};

// ScriptStruct SMSystem.SMConnectionValidator
// Size: 0x01 (Inherited: 0x00)
struct FSMConnectionValidator {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct SMSystem.SMTransitionConnectionValidator
// Size: 0x10 (Inherited: 0x01)
struct FSMTransitionConnectionValidator : FSMConnectionValidator {
	struct TArray<struct FSMNodeConnectionRule> AllowedConnections; // 0x00(0x10)
};

// ScriptStruct SMSystem.SMStateConnectionValidator
// Size: 0x30 (Inherited: 0x01)
struct FSMStateConnectionValidator : FSMConnectionValidator {
	struct TArray<struct FSMStateClassRule> AllowedInboundStates; // 0x00(0x10)
	struct TArray<struct FSMStateClassRule> AllowedOutboundStates; // 0x10(0x10)
	struct TArray<struct FSMStateMachineClassRule> AllowedInStateMachines; // 0x20(0x10)
};

// ScriptStruct SMSystem.SMStateMachineNodePlacementValidator
// Size: 0x50 (Inherited: 0x01)
struct FSMStateMachineNodePlacementValidator : FSMConnectionValidator {
	struct TArray<struct FSMStateClassRule> AllowedStates; // 0x00(0x10)
	struct TArray<struct FSMTransitionClassRule> AllowedTransitions; // 0x10(0x10)
	bool bAllowReferences; // 0x20(0x01)
	bool bAllowParents; // 0x21(0x01)
	bool bAllowSubStateMachines; // 0x22(0x01)
	char pad_24[0x4]; // 0x24(0x04)
	struct TSoftClassPtr<UObject> DefaultSubStateMachineClass; // 0x28(0x28)
};

// ScriptStruct SMSystem.SMNodeWidgetInfo
// Size: 0x01 (Inherited: 0x00)
struct FSMNodeWidgetInfo {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct SMSystem.SMTextDisplayWidgetInfo
// Size: 0x01 (Inherited: 0x01)
struct FSMTextDisplayWidgetInfo : FSMNodeWidgetInfo {
};

// ScriptStruct SMSystem.SMStateHistory
// Size: 0x20 (Inherited: 0x00)
struct FSMStateHistory {
	struct FGuid StateGuid; // 0x00(0x10)
	struct FDateTime StartTime; // 0x10(0x08)
	float TimeInState; // 0x18(0x04)
	float ServerTimeInState; // 0x1c(0x04)
};

// ScriptStruct SMSystem.SMState
// Size: 0x188 (Inherited: 0x188)
struct FSMState : FSMState_Base {
};

// ScriptStruct SMSystem.SMStateMachine
// Size: 0x2c8 (Inherited: 0x188)
struct FSMStateMachine : FSMState_Base {
	char bHasAdditionalLogic : 1; // 0x188(0x01)
	char bReuseCurrentState : 1; // 0x188(0x01)
	char bOnlyReuseIfNotEndState : 1; // 0x188(0x01)
	char bAllowIndependentTick : 1; // 0x188(0x01)
	char bCallReferenceTickOnManualUpdate : 1; // 0x188(0x01)
	char bWaitForEndState : 1; // 0x188(0x01)
	char pad_188_6 : 2; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	struct TScriptInterface<ISMStateMachineNetworkedInterface> NetworkedInterface; // 0x190(0x10)
	char pad_1a0[0xf0]; // 0x1a0(0xf0)
	ClassPtrProperty ReferencedStateMachineClass; // 0x290(0x08)
	struct FName ReferencedTemplateName; // 0x298(0x08)
	struct FName DynamicStateMachineReferenceVariable; // 0x2a0(0x08)
	struct USMInstance* ReferencedStateMachine; // 0x2a8(0x08)
	struct USMInstance* IsReferencedByInstance; // 0x2b0(0x08)
	char pad_2b8[0x10]; // 0x2b8(0x10)
};

// ScriptStruct SMSystem.SMTransaction_Base
// Size: 0x03 (Inherited: 0x00)
struct FSMTransaction_Base {
	char pad_0[0x1]; // 0x00(0x01)
	enum class ESMTransactionType TransactionType; // 0x01(0x01)
	char bOriginatedFromServer : 1; // 0x02(0x01)
	char pad_2_1 : 7; // 0x02(0x01)
};

// ScriptStruct SMSystem.SMInitializeTransaction
// Size: 0x10 (Inherited: 0x03)
struct FSMInitializeTransaction : FSMTransaction_Base {
	char pad_3[0x5]; // 0x03(0x05)
	struct UObject* Context; // 0x08(0x08)
};

// ScriptStruct SMSystem.SMTransitionTransaction
// Size: 0x38 (Inherited: 0x03)
struct FSMTransitionTransaction : FSMTransaction_Base {
	char pad_3[0x1]; // 0x03(0x01)
	struct FGuid BaseGuid; // 0x04(0x10)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FGuid> AdditionalGuids; // 0x18(0x10)
	struct FDateTime Timestamp; // 0x28(0x08)
	float ActiveTime; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct SMSystem.SMActivateStateTransaction
// Size: 0x1c (Inherited: 0x03)
struct FSMActivateStateTransaction : FSMTransaction_Base {
	char pad_3[0x1]; // 0x03(0x01)
	struct FGuid BaseGuid; // 0x04(0x10)
	float TimeInState; // 0x14(0x04)
	char bIsActive : 1; // 0x18(0x01)
	char bSetAllParents : 1; // 0x18(0x01)
	char pad_18_2 : 6; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
};

// ScriptStruct SMSystem.SMFullSyncStateTransaction
// Size: 0x18 (Inherited: 0x03)
struct FSMFullSyncStateTransaction : FSMTransaction_Base {
	char pad_3[0x1]; // 0x03(0x01)
	struct FGuid BaseGuid; // 0x04(0x10)
	float TimeInState; // 0x14(0x04)
};

// ScriptStruct SMSystem.SMFullSyncTransaction
// Size: 0x20 (Inherited: 0x03)
struct FSMFullSyncTransaction : FSMTransaction_Base {
	char pad_3[0x5]; // 0x03(0x05)
	struct TArray<struct FSMFullSyncStateTransaction> ActiveStates; // 0x08(0x10)
	char bHasStarted : 1; // 0x18(0x01)
	char bFromUserLoad : 1; // 0x18(0x01)
	char bForceFullRefresh : 1; // 0x18(0x01)
	char pad_18_3 : 5; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct SMSystem.SMTransition
// Size: 0x190 (Inherited: 0x138)
struct FSMTransition : FSMNode_Base {
	int32_t Priority; // 0x138(0x04)
	char bCanEnterTransition : 1; // 0x13c(0x01)
	char bCanEnterTransitionFromEvent : 1; // 0x13c(0x01)
	char bIsEvaluating : 1; // 0x13c(0x01)
	char bCanEvaluate : 1; // 0x13c(0x01)
	char bCanEvaluateFromEvent : 1; // 0x13c(0x01)
	char bRunParallel : 1; // 0x13c(0x01)
	char bEvalIfNextStateActive : 1; // 0x13c(0x01)
	char bCanEvalWithStartState : 1; // 0x13c(0x01)
	char bAlwaysFalse : 1; // 0x13d(0x01)
	char bFromAnyState : 1; // 0x13d(0x01)
	char bFromLinkState : 1; // 0x13d(0x01)
	char pad_13d_3 : 5; // 0x13d(0x01)
	char pad_13e[0x2]; // 0x13e(0x02)
	struct FGuid FromGuid; // 0x140(0x10)
	struct FGuid ToGuid; // 0x150(0x10)
	enum class ESMConditionalEvaluationType ConditionalEvaluationType; // 0x160(0x01)
	char pad_161[0x2f]; // 0x161(0x2f)
};

