// Class TcpMessaging.TcpMessagingSettings
// Size: 0xd0 (Inherited: 0xa0)
struct UTcpMessagingSettings : UObject {
	bool EnableTransport; // 0x98(0x01)
	struct FString ListenEndpoint; // 0xa0(0x10)
	struct TArray<struct FString> ConnectToEndpoints; // 0xb0(0x10)
	int32_t ConnectionRetryDelay; // 0xc0(0x04)
	int32_t ConnectionRetryPeriod; // 0xc4(0x04)
	bool bStopServiceWhenAppDeactivates; // 0xc8(0x01)
	char pad_ca[0x6]; // 0xca(0x06)
};

