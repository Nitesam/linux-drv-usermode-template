// Class EmbarkMovement.EmbarkAimRotationInheritanceComponent
// Size: 0x170 (Inherited: 0x160)
struct UEmbarkAimRotationInheritanceComponent : UActorComponent {
	bool bInheritPitch; // 0x158(0x01)
	bool bInheritYaw; // 0x159(0x01)
	bool bClampPitch; // 0x15a(0x01)
	bool bClampYaw; // 0x15b(0x01)
	float MaxPitchDelta; // 0x15c(0x04)
	float MaxYawDelta; // 0x160(0x04)
	char pad_16c[0x4]; // 0x16c(0x04)
};

// Class EmbarkMovement.EmbarkCharacterMovementComponentBase
// Size: 0x1060 (Inherited: 0x1030)
struct UEmbarkCharacterMovementComponentBase : UCharacterMovementComponent {
	char pad_1030[0x30]; // 0x1030(0x30)

	void SetOverrideCapsuleSize(bool bOverrideCapsuleRadius, float NewRadiusOverride, bool bOverrideCapsuleHeight, float NewHeightOverride); // Function EmbarkMovement.EmbarkCharacterMovementComponentBase.SetOverrideCapsuleSize // (Final|Native|Public|BlueprintCallable) // @ game+0x5ce5a20
	float GetCapsuleRadiusOverride(); // Function EmbarkMovement.EmbarkCharacterMovementComponentBase.GetCapsuleRadiusOverride // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cdffe0
	float GetCapsuleHeightOverride(); // Function EmbarkMovement.EmbarkCharacterMovementComponentBase.GetCapsuleHeightOverride // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce4000
};

// Class EmbarkMovement.EmbarkCharacterMovementComponent
// Size: 0x2100 (Inherited: 0x1060)
struct UEmbarkCharacterMovementComponent : UEmbarkCharacterMovementComponentBase {
	char pad_1060[0x10]; // 0x1060(0x10)
	struct FEmbarkMovementParamsStatic MovementParamsStatics; // 0x1070(0x390)
	struct FEmbarkMovementParamsDynamic MovementParamsDynamics; // 0x1400(0x540)
	bool bOwnerOrientMeshToLookAtYaw; // 0x1940(0x01)
	char pad_1941[0x7]; // 0x1941(0x07)
	struct FReplicatedTransform ReplicatedTransform; // 0x1948(0x68)
	struct FLocalBaseReplicatedInfo LocalBaseReplicatedInfo; // 0x19b0(0x80)
	int32_t ReplicatedServerProcessedLatestInputFrame; // 0x1a30(0x04)
	struct FEmbarkCustomMovementFlags CustomMovementFlags; // 0x1a34(0x01)
	char pad_1a35[0x3]; // 0x1a35(0x03)
	struct AEmbarkCharacterMovementGlobalActorBase* CharacterMovementSystem; // 0x1a38(0x08)
	float RootMotionEvalServerTime; // 0x1a40(0x04)
	float RootMotionEvalServerTime_ClientInterpData; // 0x1a44(0x04)
	char pad_1a48[0x428]; // 0x1a48(0x428)
	struct FEmbarkRootWarpSpace RootWarpSpace; // 0x1e70(0x140)
	char pad_1fb0[0x150]; // 0x1fb0(0x150)

	void OnRep_ReplicatedTransform(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.OnRep_ReplicatedTransform // (Final|Native|Private) // @ game+0x5ce9b70
	void OnRep_LocalBaseReplicatedInfo(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.OnRep_LocalBaseReplicatedInfo // (Final|Native|Private) // @ game+0x5cdfee0
	bool IsCheatFlying(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.IsCheatFlying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce3990
	bool HasLocalBaseInfoReplicatedThisFrame(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.HasLocalBaseInfoReplicatedThisFrame // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce0a80
	struct FEmbarkRootWarpSpace GetRootWarpSpace(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetRootWarpSpace // (Final|Native|Public|BlueprintCallable) // @ game+0x5ce67b0
	struct FEmbarkRootMotionInputScale GetRootMotionInputScale(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetRootMotionInputScale // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce5c50
	struct FEmbarkCharacterMovementBaseState GetReplicatedBaseState(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetReplicatedBaseState // (Native|Public|Const) // @ game+0x5ce0c40
	struct FEmbarkCharacterMovementBaseState GetMutableReplicatedBaseState(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetMutableReplicatedBaseState // (Native|Public) // @ game+0x5ce74b0
	struct FVector GetGroundNormal(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetGroundNormal // (Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce36c0
	struct UPrimitiveComponent* GetFloorComponent(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetFloorComponent // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce0680
	struct FName GetFloorBoneName(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetFloorBoneName // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ce26c0
	struct UEmbarkCharacterMovementStateInterpolatorDataBase* GetEmbarkCharacterMovementStateInterpData(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.GetEmbarkCharacterMovementStateInterpData // (Final|Native|Protected|BlueprintCallable) // @ game+0x5ce7b90
	void ClearRootMotionSources(); // Function EmbarkMovement.EmbarkCharacterMovementComponent.ClearRootMotionSources // (Final|Native|Public|BlueprintCallable) // @ game+0x5ce04d0
};

// Class EmbarkMovement.EmbarkCharacterMovementGlobalActorBase
// Size: 0x3b0 (Inherited: 0x3a0)
struct AEmbarkCharacterMovementGlobalActorBase : AEmbarkGlobalActor {
	char pad_3a0[0x10]; // 0x3a0(0x10)

	void UpdateDynamicMovementParams(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.UpdateDynamicMovementParams // (Native|Public|HasOutParms|Const) // @ game+0x5ce1910
	void GenerateStaticMovementParams(struct FEmbarkMovementParamsStatic& OutResult, struct ACharacter* Character, struct FVector& InputVector, struct FPendulumClaims& PendulumClaims, bool bWantsToJump, bool bWantsToCrouch, float OverrideDeltaSeconds); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.GenerateStaticMovementParams // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5cead10
	struct FEmbarkMovementParamsDynamic GenerateDynamicMovementParams(struct FEmbarkMovementParamsStatic& Statics, struct FEmbarkCharacterMovementBaseState& BaseState); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.GenerateDynamicMovementParams // (Native|Public|HasOutParms|Const) // @ game+0x5ce8240
	void BlueprintModifyInputVector(struct ACharacter* Character, struct FVector& CurrentInputVector); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintModifyInputVector // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x4abfe0
	float BlueprintGetMaxSpeedModifier(struct ACharacter* Character); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintGetMaxSpeedModifier // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	float BlueprintGetMaxSpeed(struct FEmbarkMovementParamsStatic& Statics, struct FEmbarkMovementParamsDynamic& Dynamics); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintGetMaxSpeed // (Native|Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x5ce5ce0
	float BlueprintGetGravityScaleModifier(struct ACharacter* Character); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintGetGravityScaleModifier // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool BlueprintGetCurrentLocalBase_Server(struct ACharacter* Character, enum class EEmbarkLocalBaseType LocalBaseRequestTypeBitmask, struct UPrimitiveComponent*& OutBase, struct FName& OutBone); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintGetCurrentLocalBase_Server // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	float BlueprintGetAirControlModifier(struct ACharacter* Character); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintGetAirControlModifier // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BlueprintGenerateStaticMovementParams(struct ACharacter* Character, struct FEmbarkMovementParamsStatic& OutStatics); // Function EmbarkMovement.EmbarkCharacterMovementGlobalActorBase.BlueprintGenerateStaticMovementParams // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkMovement.EmbarkCharacterMovementSettings
// Size: 0x1a0 (Inherited: 0x160)
struct UEmbarkCharacterMovementSettings : UActorComponent {
	float MaxWalkingAcceleration; // 0x158(0x04)
	float MaxWalkingAccelerationForward; // 0x15c(0x04)
	float MaxWalkingAccelerationSideways; // 0x160(0x04)
	float MaxWalkingAccelerationBackwards; // 0x164(0x04)
	bool bEnableDirectionalWalkingAccelerationModel; // 0x168(0x01)
	float MaxFallingAcceleration; // 0x16c(0x04)
	float MaxFallingSpeedHorizontal; // 0x170(0x04)
	float FallingHorizontalDragCoefficient; // 0x174(0x04)
	float FallingHorizontalDragThresholdSpeed; // 0x178(0x04)
	float MaxFlyingAcceleration; // 0x17c(0x04)
	float JumpStaminaConsumptionPerJump; // 0x180(0x04)
	float JumpStaminaGainSpeed; // 0x184(0x04)
	float JumpStaminaHorizontalVelMinScale; // 0x188(0x04)
	float JumpCoyoteTimeThreshold; // 0x18c(0x04)
	float MinJumpStaminaZVelocity; // 0x190(0x04)
	struct UEmbarkDataAsset* RootMotionDefinitions; // 0x198(0x08)
};

// Class EmbarkMovement.EmbarkMovementParamsDynamicMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMovementParamsDynamicMixinLibrary : UObject {

	float GetCapsuleHalfHeight(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function EmbarkMovement.EmbarkMovementParamsDynamicMixinLibrary.GetCapsuleHalfHeight // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ce1050
};

// Class EmbarkMovement.EmbarkMovementFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMovementFunctionLibrary : UBlueprintFunctionLibrary {

	void CalcVelocity(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function EmbarkMovement.EmbarkMovementFunctionLibrary.CalcVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ce90d0
	void CalcOnGroundVelocity(struct FVector& Velocity, float SimulateTime, float MinAnalogSpeed, struct FRotator& ControlRotation, struct FVector& InputVector, struct FVector& GroundNormal, struct FOnGroundAccelerationParams& Statics, float MaxSpeed); // Function EmbarkMovement.EmbarkMovementFunctionLibrary.CalcOnGroundVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5ce39f0
	void CalcMostRelevantHitResult(struct TArray<struct FHitResult>& HitResults, struct FHitResult& OutMostRelevantHitResult); // Function EmbarkMovement.EmbarkMovementFunctionLibrary.CalcMostRelevantHitResult // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ce70c0
	void CalcFlyingVelocity(struct FVector& Velocity, float SimulateTime, float MinAnalogSpeed, struct FRotator& ControlRotation, struct FVector& InputVector, struct FVector& GroundNormal, struct FInAirAccelerationParams& AccParms, float MaxSpeed); // Function EmbarkMovement.EmbarkMovementFunctionLibrary.CalcFlyingVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5ce0070
	void CalcFallingVelocity(struct FVector& Velocity, float GravityZ, float SimulateTime, float MinAnalogSpeed, struct FRotator& ControlRotation, struct FVector& InputVector, struct FVector& GroundNormal, struct FInAirAccelerationParams& Statics, float MaxSpeed); // Function EmbarkMovement.EmbarkMovementFunctionLibrary.CalcFallingVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5ce4a90
};

// Class EmbarkMovement.EmbarkCharacterMovementStaticCallerBase
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkCharacterMovementStaticCallerBase : UObject {

	float ReceiveGetUnCrouchHeightAdjustment(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function EmbarkMovement.EmbarkCharacterMovementStaticCallerBase.ReceiveGetUnCrouchHeightAdjustment // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkMovement.EmbarkCharacterMovementStateInterpolatorDataBase
// Size: 0x3b0 (Inherited: 0xa0)
struct UEmbarkCharacterMovementStateInterpolatorDataBase : UObject {
	struct FVector CharacterMovementVelocity; // 0x98(0x18)
	enum class EMovementMode MovementMode; // 0xb0(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
	struct FEmbarkRootWarpSpace RootWarpSpace; // 0xc0(0x140)
	float RootMotionEvalServerTime; // 0x200(0x04)
	float CurrentMovementTime; // 0x204(0x04)
	char pad_208[0x8]; // 0x208(0x08)
	struct FPendulumRootMotionState RootMotionState; // 0x210(0x1a0)
};

// Class EmbarkMovement.EmbarkCharacterMovementStateInterpolatorBase
// Size: 0x340 (Inherited: 0x340)
struct UEmbarkCharacterMovementStateInterpolatorBase : UBPObjectInterpolator {
};

// Class EmbarkMovement.MockEmbarkCharacterMovementStateInterpolatorBase
// Size: 0x340 (Inherited: 0x340)
struct UMockEmbarkCharacterMovementStateInterpolatorBase : UEmbarkCharacterMovementStateInterpolatorBase {
};

// Class EmbarkMovement.EmbarkMovementParamsTransientResultColliderDataScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMovementParamsTransientResultColliderDataScriptMixinLibrary : UObject {

	struct UPrimitiveComponent* GetCollider(struct FEmbarkMovementParamsTransientResultColliderData& ColliderData); // Function EmbarkMovement.EmbarkMovementParamsTransientResultColliderDataScriptMixinLibrary.GetCollider // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ceb510
};

// Class EmbarkMovement.EmbarkMovementParamsTransientResultScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMovementParamsTransientResultScriptMixinLibrary : UObject {

	void GetCollidingComponents(struct FEmbarkMovementParamsTransientResult& TransientResult, struct TArray<struct UPrimitiveComponent*>& OutCollidingComponents); // Function EmbarkMovement.EmbarkMovementParamsTransientResultScriptMixinLibrary.GetCollidingComponents // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ceded0
	bool GetColliderWithOwner(struct FEmbarkMovementParamsTransientResult& TransientResult, struct AActor* Owner, struct FEmbarkMovementParamsTransientResultColliderData& OutColliderData); // Function EmbarkMovement.EmbarkMovementParamsTransientResultScriptMixinLibrary.GetColliderWithOwner // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ceb870
	void AddUniqueCollider(struct FEmbarkMovementParamsTransientResult& TransientResult, struct FEmbarkMovementParamsTransientResultColliderData& AddColliderData); // Function EmbarkMovement.EmbarkMovementParamsTransientResultScriptMixinLibrary.AddUniqueCollider // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf0130
};

// Class EmbarkMovement.KneeHeightHelpers
// Size: 0xa0 (Inherited: 0xa0)
struct UKneeHeightHelpers : UBlueprintFunctionLibrary {

	bool DebugKneeHeightVirtualDitch(); // Function EmbarkMovement.KneeHeightHelpers.DebugKneeHeightVirtualDitch // (Final|Native|Static|Public) // @ game+0x5198790
	bool DebugKneeHeightVerticalSweeps(); // Function EmbarkMovement.KneeHeightHelpers.DebugKneeHeightVerticalSweeps // (Final|Native|Static|Public) // @ game+0x5198790
	bool DebugKneeHeightPillSweeps(); // Function EmbarkMovement.KneeHeightHelpers.DebugKneeHeightPillSweeps // (Final|Native|Static|Public) // @ game+0x5198790
};

// Class EmbarkMovement.EmbarkMovementBlockedFloorsContainerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMovementBlockedFloorsContainerMixinLibrary : UObject {

	bool IsFloorBlocked(struct FEmbarkMovementBlockedFloorsContainer& Container, struct AActor* InBlockedFloorActor); // Function EmbarkMovement.EmbarkMovementBlockedFloorsContainerMixinLibrary.IsFloorBlocked // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf4910
	void FillBlockedFloors(struct FEmbarkMovementBlockedFloorsContainer& Container, struct TArray<struct AActor*>& InOutBlockedFloorActors); // Function EmbarkMovement.EmbarkMovementBlockedFloorsContainerMixinLibrary.FillBlockedFloors // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf72f0
	void AddBlockedFloor(struct FEmbarkMovementBlockedFloorsContainer& Container, struct AActor* InBlockedFloorActor); // Function EmbarkMovement.EmbarkMovementBlockedFloorsContainerMixinLibrary.AddBlockedFloor // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf3300
};

// Class EmbarkMovement.EmbarkPawnMovementComponent
// Size: 0x280 (Inherited: 0x210)
struct UEmbarkPawnMovementComponent : UPawnMovementComponent {
	char pad_210[0x8]; // 0x210(0x08)
	char bUseRVOAvoidance : 1; // 0x218(0x01)
	char pad_218_1 : 7; // 0x218(0x01)
	char pad_219[0x3]; // 0x219(0x03)
	int32_t AvoidanceUID; // 0x21c(0x04)
	float AvoidanceWeight; // 0x220(0x04)
	float AvoidanceConsiderationRadius; // 0x224(0x04)
	float AvoidanceRadius; // 0x228(0x04)
	float AvoidanceHalfHeight; // 0x22c(0x04)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x230(0x04)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x234(0x04)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x238(0x04)
	char bWasAvoidanceUpdated : 1; // 0x23c(0x01)
	char pad_23c_1 : 7; // 0x23c(0x01)
	char pad_23d[0x43]; // 0x23d(0x43)

	void SetAvoidanceEnabled(bool bEnable); // Function EmbarkMovement.EmbarkPawnMovementComponent.SetAvoidanceEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5cf2420
	struct FVector GetAvoidanceVelocity(); // Function EmbarkMovement.EmbarkPawnMovementComponent.GetAvoidanceVelocity // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf9100
};

// Class EmbarkMovement.EmbarkRootWarpSpaceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRootWarpSpaceMixinLibrary : UObject {

	void UpdateTransforms(struct FEmbarkRootWarpSpace& RootWarpSpace, struct FTransform& OutStartTransform, struct FTransform& OutEndTransform); // Function EmbarkMovement.EmbarkRootWarpSpaceMixinLibrary.UpdateTransforms // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5cf65d0
	void SetStartAndEndTransforms(struct FEmbarkRootWarpSpace& RootWarpSpace, struct FTransform& WorldStartTransform, struct FTransform& WorldEndTransform, struct USceneComponent* InAttachComponent, struct FName InAttachToBone); // Function EmbarkMovement.EmbarkRootWarpSpaceMixinLibrary.SetStartAndEndTransforms // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5cf95d0
	struct USceneComponent* GetAttachedToComponent(struct FEmbarkRootWarpSpace& RootWarpSpace); // Function EmbarkMovement.EmbarkRootWarpSpaceMixinLibrary.GetAttachedToComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf9160
	struct FName GetAttachedToBone(struct FEmbarkRootWarpSpace& RootWarpSpace); // Function EmbarkMovement.EmbarkRootWarpSpaceMixinLibrary.GetAttachedToBone // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf2c70
};

// Class EmbarkMovement.EmbarkServersideReplicatedInputScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkServersideReplicatedInputScriptMixinLibrary : UObject {

	bool GetBool(struct FEmbarkServersideReplicatedInput& Input, struct FName InputName); // Function EmbarkMovement.EmbarkServersideReplicatedInputScriptMixinLibrary.GetBool // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf7660
};

// Class EmbarkMovement.EmbarkServersideInputReplicationComponent
// Size: 0x870 (Inherited: 0x160)
struct UEmbarkServersideInputReplicationComponent : UActorComponent {
	struct FMulticastInlineDelegate OnPreInputCreationClientEvent; // 0x158(0x10)
	struct FMulticastInlineDelegate OnPreInputCreationClientEvent_Synchronized; // 0x168(0x10)
	bool bSyncronizedInputModel; // 0x178(0x01)
	int32_t SyncronizedInputServerBufferSize; // 0x17c(0x04)
	int32_t SyncronizedInputServerBufferMergeOffset; // 0x180(0x04)
	float ReapplyInputMaxTime; // 0x184(0x04)
	struct FEmbarkMoveModifiers MoveModifier; // 0x188(0x08)
	struct FEmbarkMoveOverrides MoveOverride; // 0x190(0x08)
	char pad_19d[0x43]; // 0x19d(0x43)
	struct APlayerController* OwningController; // 0x1e0(0x08)
	struct UEmbarkInputSubsystem* InputSubSystem; // 0x1e8(0x08)
	char pad_1f0[0x480]; // 0x1f0(0x480)
	struct UDirectReplicationWrapperComponent* DirectReplicationWrapperComp; // 0x670(0x08)
	char pad_678[0x18]; // 0x678(0x18)
	float InputSyncInterval; // 0x690(0x04)
	char pad_694[0x1cc]; // 0x694(0x1cc)
	struct UPrimitiveComponent* LocalBase; // 0x860(0x08)
	char pad_868[0x8]; // 0x868(0x08)

	void StopInputGeneration(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.StopInputGeneration // (Final|Native|Public|BlueprintCallable) // @ game+0x5cf1fa0
	void StartInputGeneration(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.StartInputGeneration // (Final|Native|Public|BlueprintCallable) // @ game+0x5cf3c50
	void SetLocalBaseForInputVector_Client(struct UPrimitiveComponent* InLocalBase, struct FName InLocalBaseBone); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.SetLocalBaseForInputVector_Client // (Final|Native|Public|BlueprintCallable) // @ game+0x5cf7160
	void ServerInputProcessingCanBeStarted(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.ServerInputProcessingCanBeStarted // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x5cf4ec0
	void RecalculatePendingInput(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.RecalculatePendingInput // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x5cf2720
	bool IsInputNewer(int32_t NewInputFrame, int32_t BaseInputFrame); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.IsInputNewer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x337dc40
	int32_t GetServerLatestInputFrame_Server(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetServerLatestInputFrame_Server // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf6f30
	struct TArray<struct FEmbarkServersideReplicatedInput> GetNewInputs(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetNewInputs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf9990
	float GetLatestInputProcessingTime(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetLatestInputProcessingTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf6c70
	struct FEmbarkServersideReplicatedInput GetLatestInput(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetLatestInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf2050
	float GetInputTimestamp(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetInputTimestamp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf5020
	float GetInputSyncInterval(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetInputSyncInterval // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf7f10
	int32_t GetInputBufferSize(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetInputBufferSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5cf4460
	bool GetInput_Server(int32_t InputFrame, struct FEmbarkServersideReplicatedInput& OutInput, bool bGetClosestOlderInput, bool bGetClosestNewerInput, bool bAllowLookingAtNotAppliedInput); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.GetInput_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5cf2e20
	void CreateInput_Client(struct FEmbarkServersideReplicatedInput& NewInput); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.CreateInput_Client // (Final|Native|Protected|HasOutParms) // @ game+0x5cf58a0
	void ClientInputProcessingStarted(); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.ClientInputProcessingStarted // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x36ad7d0
	void ClientInputProcessingSpeedChange(float SpeedChange); // Function EmbarkMovement.EmbarkServersideInputReplicationComponent.ClientInputProcessingSpeedChange // (Final|Net|Native|Event|Private|NetClient) // @ game+0x3f59840
};

// Class EmbarkMovement.VirtualTerrainFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UVirtualTerrainFunctionLibrary : UBlueprintFunctionLibrary {

	void TraceForGroundPlane(struct UObject* WorldContextObject, struct FVirtualTerrainParams& TraceParams, struct FVirtualTerrainGroundPlane& OutGroundPlane); // Function EmbarkMovement.VirtualTerrainFunctionLibrary.TraceForGroundPlane // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf4a30
	int64_t StandingStillTraceSingle(struct UObject* WorldContextObject, struct FVirtualTerrainParams& TraceParams, struct TArray<struct FHitResult>& OutHitResults); // Function EmbarkMovement.VirtualTerrainFunctionLibrary.StandingStillTraceSingle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf8a80
	int64_t StandingStillTrace(struct UObject* WorldContextObject, struct FVirtualTerrainParams& TraceParams, struct TArray<struct FHitResult>& OutHitResults); // Function EmbarkMovement.VirtualTerrainFunctionLibrary.StandingStillTrace // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf3ec0
	int64_t MovingTraceSingle(struct UObject* WorldContextObject, struct FVirtualTerrainParams& TraceParams, struct TArray<struct FHitResult>& OutHitResults); // Function EmbarkMovement.VirtualTerrainFunctionLibrary.MovingTraceSingle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf8ce0
	int64_t MovingTrace(struct UObject* WorldContextObject, struct FVirtualTerrainParams& TraceParams, struct TArray<struct FHitResult>& OutHitResults); // Function EmbarkMovement.VirtualTerrainFunctionLibrary.MovingTrace // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf9310
	void CreateGroundPlane(struct UObject* DebugDrawCntxObj, struct FVector& RequesterFootLocation, struct FVector& RequesterGroundNormal, struct FVirtualTerrainWalkableThresholds& WalkableThresholds, struct TArray<struct FHitResult>& GroundGridHits, struct FVirtualTerrainGroundPlane& OutResult); // Function EmbarkMovement.VirtualTerrainFunctionLibrary.CreateGroundPlane // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5cf7f60
};

// Class EmbarkMovement.VirtualTerrainGroundPlaneMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UVirtualTerrainGroundPlaneMixinLibrary : UObject {

	bool IsGroundWalkable(struct FVirtualTerrainGroundPlane& GroundPlane); // Function EmbarkMovement.VirtualTerrainGroundPlaneMixinLibrary.IsGroundWalkable // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf5d10
	struct FHitResult GetBestHitResult(struct FVirtualTerrainGroundPlane& GroundPlane); // Function EmbarkMovement.VirtualTerrainGroundPlaneMixinLibrary.GetBestHitResult // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cf68e0
};

// Class EmbarkMovement.EmbarkRootMotionSourceUtilLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRootMotionSourceUtilLibrary : UBlueprintFunctionLibrary {

	struct FName Name_Warp_Upright(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_Upright // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5cfd2f0
	struct FName Name_Warp_TranslationVertical(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_TranslationVertical // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d049b0
	struct FName Name_Warp_TranslationHorizontal(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_TranslationHorizontal // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d06e40
	struct FName Name_Warp_SpeedWarp(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_SpeedWarp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d03e80
	struct FName Name_Warp_Rotation(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_Rotation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d05120
	struct FName Name_Warp_RootMotionScale(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_RootMotionScale // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5cfd360
	struct FName Name_Warp_InputScale(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_InputScale // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d06810
	struct FName Name_Warp_ApplyGravityCurve(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_ApplyGravityCurve // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5d03b80
	struct FName Name_Warp_Active(); // Function EmbarkMovement.EmbarkRootMotionSourceUtilLibrary.Name_Warp_Active // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5cfa4a0
};

// Class EmbarkMovement.KneeHeightMovementHelpers
// Size: 0xa0 (Inherited: 0xa0)
struct UKneeHeightMovementHelpers : UBlueprintFunctionLibrary {

	void SimulateMovementWithDebug(struct FKneeHeightMoveSimulationContext& SimContext, struct FKneeHeightMoveSimulationResult& OutSimResult, struct FEmbarkMovementParamsTransientResult& TransientResult, float Standing_Kneeheight, struct FKneeHeightMoveDebugData& OutDebugData); // Function EmbarkMovement.KneeHeightMovementHelpers.SimulateMovementWithDebug // (Final|RequiredAPI|Native|Static|Public|HasOutParms) // @ game+0x5cfb040
	void SimulateMovement(struct FKneeHeightMoveSimulationContext& SimContext, struct FKneeHeightMoveSimulationResult& OutSimResult, struct FEmbarkMovementParamsTransientResult& TransientResult, float Standing_Kneeheight); // Function EmbarkMovement.KneeHeightMovementHelpers.SimulateMovement // (Final|RequiredAPI|Native|Static|Public|HasOutParms) // @ game+0x5d04020
	struct FVector GetCollisionAdjustedMoveWithDebug(bool bDisallowUpwardsBounces, struct FKneeHeightPill& KneeHeightPill, struct FVector& MoveVec, float DeltaSeconds, struct FHitResult& OutHitResult, struct FVector& DepenetrationVec, struct TArray<struct UObject*>& IgnoreStartingPenetrationForTypes, struct FEmbarkMovementParamsTransientResult& TransientResult, struct FKneeHeightMoveDebugData& OutDebugData); // Function EmbarkMovement.KneeHeightMovementHelpers.GetCollisionAdjustedMoveWithDebug // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5d02710
	struct FVector GetCollisionAdjustedMove(bool bDisallowUpwardsBounces, struct FKneeHeightPill& KneeHeightPill, struct FVector& MoveVec, float DeltaSeconds, struct FHitResult& OutHitResult, struct FVector& DepenetrationVec, struct TArray<struct UObject*>& IgnoreStartingPenetrationForTypes, struct FEmbarkMovementParamsTransientResult& TransientResult); // Function EmbarkMovement.KneeHeightMovementHelpers.GetCollisionAdjustedMove // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5cfc610
};

// Class EmbarkMovement.KneeHeightVirtualDitchHelpers
// Size: 0xa0 (Inherited: 0xa0)
struct UKneeHeightVirtualDitchHelpers : UBlueprintFunctionLibrary {

	void FixGroundForPotentialVirtualDitch(struct FKneeHeightPill& KneeHeightPill, struct FVirtualTerrainWalkableThresholds& WalkableThresholds, struct FVirtualTerrainGroundPlane& GroundPlane); // Function EmbarkMovement.KneeHeightVirtualDitchHelpers.FixGroundForPotentialVirtualDitch // (Final|Native|Static|Public|HasOutParms) // @ game+0x5cfba10
};

// Class EmbarkMovement.PendulumUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumUtils : UBlueprintFunctionLibrary {

	float GetTimeFromTicks(int32_t Ticks); // Function EmbarkMovement.PendulumUtils.GetTimeFromTicks // (Final|Native|Static|Public) // @ game+0x5d04e50
	int32_t GetTicksFromTime(float Time); // Function EmbarkMovement.PendulumUtils.GetTicksFromTime // (Final|Native|Static|Public) // @ game+0x5d05140
	float GetAnimTimeFromTicks(int32_t Ticks); // Function EmbarkMovement.PendulumUtils.GetAnimTimeFromTicks // (Final|Native|Static|Public) // @ game+0x5d01840
	int32_t GetAnimTicksFromTime(float Time); // Function EmbarkMovement.PendulumUtils.GetAnimTicksFromTime // (Final|Native|Static|Public) // @ game+0x5d06b20
};

// Class EmbarkMovement.PendulumBlockedVaultablesStateMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumBlockedVaultablesStateMixinLibrary : UObject {

	void UpdateBlockedVaultables(struct FPendulumBlockedVaultables& BlockedVaultables, float CurrentTime); // Function EmbarkMovement.PendulumBlockedVaultablesStateMixinLibrary.UpdateBlockedVaultables // (Final|Native|Static|Private|HasOutParms) // @ game+0x5d03ea0
	bool IsVaultableBlocked(struct FPendulumBlockedVaultables& BlockedVaultables, struct UPrimitiveComponent* Vaultable, int16_t VaultableBoneIndex); // Function EmbarkMovement.PendulumBlockedVaultablesStateMixinLibrary.IsVaultableBlocked // (Final|Native|Static|Private|HasOutParms) // @ game+0x5cfbf20
	uint32_t GetNumBlockedVaultables(struct FPendulumBlockedVaultables& BlockedVaultables); // Function EmbarkMovement.PendulumBlockedVaultablesStateMixinLibrary.GetNumBlockedVaultables // (Final|Native|Static|Private|HasOutParms) // @ game+0x5cfd200
	void AddBlockedVaultable(struct FPendulumBlockedVaultables& BlockedVaultables, struct UPrimitiveComponent* Vaultable, int16_t VaultableBoneIndex, float BlockedUntilTimeStamp); // Function EmbarkMovement.PendulumBlockedVaultablesStateMixinLibrary.AddBlockedVaultable // (Final|Native|Static|Private|HasOutParms) // @ game+0x5d02e70
};

// Class EmbarkMovement.PendulumVaultSimStateMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumVaultSimStateMixinLibrary : UObject {

	void UpdateCooldowns(struct FPendulumVaultSimState& VaultSimState, float CurrentTime); // Function EmbarkMovement.PendulumVaultSimStateMixinLibrary.UpdateCooldowns // (Final|Native|Static|Private|HasOutParms) // @ game+0x5d072b0
	void StartVaultCooldown(struct FPendulumVaultSimState& VaultSimState, float CurrentTime, float Cooldown); // Function EmbarkMovement.PendulumVaultSimStateMixinLibrary.StartVaultCooldown // (Final|Native|Static|Private|HasOutParms) // @ game+0x5d09680
	bool IsVaultOnCooldown(struct FPendulumVaultSimState& VaultSimState, float CurrentTime); // Function EmbarkMovement.PendulumVaultSimStateMixinLibrary.IsVaultOnCooldown // (Final|Native|Static|Private|HasOutParms) // @ game+0x5d04d00
};

