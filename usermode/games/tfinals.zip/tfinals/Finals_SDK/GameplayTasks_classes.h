// Class GameplayTasks.GameplayTask
// Size: 0xe0 (Inherited: 0xa0)
struct UGameplayTask : UObject {
	struct FName InstanceName; // 0xa0(0x08)
	char pad_a8[0x2]; // 0xa8(0x02)
	enum class ETaskResourceOverlapPolicy ResourceOverlapPolicy; // 0xaa(0x01)
	char pad_ab[0x25]; // 0xab(0x25)
	struct UGameplayTask* ChildTask; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)

	void ReadyForActivation(); // Function GameplayTasks.GameplayTask.ReadyForActivation // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3df0490
	void GenericGameplayTaskDelegate__DelegateSignature(); // DelegateFunction GameplayTasks.GameplayTask.GenericGameplayTaskDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void EndTask(); // Function GameplayTasks.GameplayTask.EndTask // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3deddf0
};

// Class GameplayTasks.GameplayTaskOwnerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayTaskOwnerInterface : UInterface {
};

// Class GameplayTasks.GameplayTaskResource
// Size: 0xb0 (Inherited: 0xa0)
struct UGameplayTaskResource : UObject {
	int32_t ManualResourceID; // 0x98(0x04)
	int8_t AutoResourceID; // 0x9c(0x01)
	char bManuallySetID : 1; // 0xa0(0x01)
	char pad_a5_1 : 7; // 0xa5(0x01)
	char pad_a6[0xa]; // 0xa6(0x0a)
};

// Class GameplayTasks.GameplayTasksComponent
// Size: 0x1d0 (Inherited: 0x160)
struct UGameplayTasksComponent : UActorComponent {
	char pad_160[0x10]; // 0x160(0x10)
	struct TArray<struct UGameplayTask*> TaskPriorityQueue; // 0x170(0x10)
	char pad_180[0x10]; // 0x180(0x10)
	struct TArray<struct UGameplayTask*> TickingTasks; // 0x190(0x10)
	struct TArray<struct UGameplayTask*> KnownTasks; // 0x1a0(0x10)
	struct FMulticastInlineDelegate OnClaimedResourcesChange; // 0x1b0(0x10)
	struct TArray<struct UGameplayTask*> SimulatedTasks; // 0x1c0(0x10)

	void OnRep_SimulatedTasks(struct TArray<struct UGameplayTask*>& PreviousSimulatedTasks); // Function GameplayTasks.GameplayTasksComponent.OnRep_SimulatedTasks // (Final|RequiredAPI|Native|Public|HasOutParms) // @ game+0x3deb7e0
	enum class EGameplayTaskRunResult K2_RunGameplayTask(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, struct UGameplayTask* Task, char Priority, struct TArray<struct UGameplayTaskResource*> AdditionalRequiredResources, struct TArray<struct UGameplayTaskResource*> AdditionalClaimedResources); // Function GameplayTasks.GameplayTasksComponent.K2_RunGameplayTask // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3df2c60
};

// Class GameplayTasks.GameplayTask_ClaimResource
// Size: 0xe0 (Inherited: 0xe0)
struct UGameplayTask_ClaimResource : UGameplayTask {

	struct UGameplayTask_ClaimResource* ClaimResources(struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner, struct TArray<struct UGameplayTaskResource*> ResourceClasses, char Priority, struct FName TaskInstanceName); // Function GameplayTasks.GameplayTask_ClaimResource.ClaimResources // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3df29b0
	struct UGameplayTask_ClaimResource* ClaimResource(struct TScriptInterface<IGameplayTaskOwnerInterface> InTaskOwner, struct UGameplayTaskResource* ResourceClass, char Priority, struct FName TaskInstanceName); // Function GameplayTasks.GameplayTask_ClaimResource.ClaimResource // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3defe40
};

// Class GameplayTasks.GameplayTask_SpawnActor
// Size: 0x130 (Inherited: 0xe0)
struct UGameplayTask_SpawnActor : UGameplayTask {
	struct FMulticastInlineDelegate Success; // 0xd8(0x10)
	struct FMulticastInlineDelegate DidNotSpawn; // 0xe8(0x10)
	char pad_100[0x28]; // 0x100(0x28)
	struct AActor* ClassToSpawn; // 0x128(0x08)

	struct UGameplayTask_SpawnActor* SpawnActor(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, struct FVector SpawnLocation, struct FRotator SpawnRotation, struct AActor* Class, bool bSpawnOnlyOnAuthority); // Function GameplayTasks.GameplayTask_SpawnActor.SpawnActor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3ded650
	void FinishSpawningActor(struct UObject* WorldContextObject, struct AActor* SpawnedActor); // Function GameplayTasks.GameplayTask_SpawnActor.FinishSpawningActor // (Native|Public|BlueprintCallable) // @ game+0x3deb6e0
	bool BeginSpawningActor(struct UObject* WorldContextObject, struct AActor*& SpawnedActor); // Function GameplayTasks.GameplayTask_SpawnActor.BeginSpawningActor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3def160
};

// Class GameplayTasks.GameplayTask_TimeLimitedExecution
// Size: 0x110 (Inherited: 0xe0)
struct UGameplayTask_TimeLimitedExecution : UGameplayTask {
	struct FMulticastInlineDelegate OnFinished; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnTimeExpired; // 0xe8(0x10)
	char pad_100[0x10]; // 0x100(0x10)
};

// Class GameplayTasks.GameplayTask_WaitDelay
// Size: 0x100 (Inherited: 0xe0)
struct UGameplayTask_WaitDelay : UGameplayTask {
	struct FMulticastInlineDelegate OnFinish; // 0xd8(0x10)
	char pad_f0[0x10]; // 0xf0(0x10)

	struct UGameplayTask_WaitDelay* TaskWaitDelay(struct TScriptInterface<IGameplayTaskOwnerInterface> TaskOwner, float Time, char Priority); // Function GameplayTasks.GameplayTask_WaitDelay.TaskWaitDelay // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x3df40b0
	void TaskDelayDelegate__DelegateSignature(); // DelegateFunction GameplayTasks.GameplayTask_WaitDelay.TaskDelayDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
};

