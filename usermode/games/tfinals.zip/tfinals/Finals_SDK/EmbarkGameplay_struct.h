// Enum EmbarkGameplay.ESquadParticipationType
enum class ESquadParticipationType : uint8_t {
	Playing = 0,
	Spectating = 1,
	ESquadParticipationType_MAX = 2
};

// ScriptStruct EmbarkGameplay.MatchIdDesc
// Size: 0x18 (Inherited: 0x00)
struct FMatchIdDesc {
	struct FName PlatformName; // 0x00(0x08)
	struct FString MatchId; // 0x08(0x10)
};

// ScriptStruct EmbarkGameplay.CompactPlayerProfile
// Size: 0x50 (Inherited: 0x00)
struct FCompactPlayerProfile {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FString DisplayName; // 0x10(0x10)
	struct FString DisplayNameDiscriminator; // 0x20(0x10)
	struct FString ThirdPartyUserId; // 0x30(0x10)
	struct FString ThirdPartyLastSeenAccountName; // 0x40(0x10)
};

// ScriptStruct EmbarkGameplay.EmbarkAnimNotifyBoneSelection
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkAnimNotifyBoneSelection {
	struct FName SelectedSocket; // 0x00(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkAvoidanceAgentSettings
// Size: 0x24 (Inherited: 0x00)
struct FEmbarkAvoidanceAgentSettings {
	float AvoidanceAgentRadius; // 0x00(0x04)
	float AvoidanceHeight; // 0x04(0x04)
	float AvoidanceConsiderationRadius; // 0x08(0x04)
	float AvoidanceWeight; // 0x0c(0x04)
	float AvoidanceLockTime; // 0x10(0x04)
	struct FNavAvoidanceMask AvoidanceGroup; // 0x14(0x04)
	struct FNavAvoidanceMask GroupsToAvoid; // 0x18(0x04)
	struct FNavAvoidanceMask GroupsToIgnore; // 0x1c(0x04)
	bool bIsInitialized; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
};

// ScriptStruct EmbarkGameplay.EmbarkComponentSelection
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkComponentSelection {
	struct FName ComponentName; // 0x00(0x08)
	struct FName SanitizedComponentName; // 0x08(0x08)
	struct UActorComponent* ClassFilter; // 0x10(0x08)
	struct TWeakObjectPtr<struct UActorComponent> SelectedComponent; // 0x18(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkConvexVolume
// Size: 0x300 (Inherited: 0x00)
struct FEmbarkConvexVolume {
	char pad_0[0x300]; // 0x00(0x300)
};

// ScriptStruct EmbarkGameplay.EmbarkGameControlMessage
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkGameControlMessage {
	struct FString RoundId; // 0x00(0x10)
	struct FString ProjectData; // 0x10(0x10)
};

// ScriptStruct EmbarkGameplay.EmbarkOptimizedTick
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkOptimizedTick {
	int32_t TickOrder; // 0x00(0x04)
	enum class ETickingGroup TickGroup; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	float StartingTickInterval; // 0x08(0x04)
	bool bAlwaysAllowBackgroundTick; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	struct UEmbarkOptimizedTickObject* OptimizedTickObject; // 0x10(0x08)
	struct UEmbarkOptimizedTickObjectSubsystem* TickObjectSystem; // 0x18(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkOptimizedTickFunction
// Size: 0x50 (Inherited: 0x38)
struct FEmbarkOptimizedTickFunction : FTickFunction {
	char pad_38[0x18]; // 0x38(0x18)
};

// ScriptStruct EmbarkGameplay.PartyInfo
// Size: 0x18 (Inherited: 0x00)
struct FPartyInfo {
	char PartyIndex; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FUniqueNetIdRepl> PartyMembers; // 0x08(0x10)
};

// ScriptStruct EmbarkGameplay.EmbarkPropertyOuter
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkPropertyOuter {
	struct UObject* PropertyOuterCDO; // 0x00(0x08)
	struct AActor* PropertyActorClass; // 0x08(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkProxyTransform
// Size: 0xa0 (Inherited: 0x00)
struct FEmbarkProxyTransform {
	struct FTransform RelativeTransform; // 0x00(0x60)
	struct FName ComponentName; // 0x60(0x08)
	struct FName ComponentDisplayName; // 0x68(0x08)
	struct FEmbarkPropertyOuter PropertyOuter; // 0x70(0x10)
	char pad_80[0x20]; // 0x80(0x20)
};

// ScriptStruct EmbarkGameplay.EmbarkStructHolder_Test
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkStructHolder_Test {
	struct TMap<struct FName, struct FEmbarkScriptStruct> StructList; // 0x00(0x50)
};

// ScriptStruct EmbarkGameplay.PendingSkeletalMeshChange
// Size: 0x20 (Inherited: 0x00)
struct FPendingSkeletalMeshChange {
	struct USkeletalMesh* PendingMeshChange; // 0x00(0x08)
	char pad_8[0x18]; // 0x08(0x18)
};

// ScriptStruct EmbarkGameplay.SkeletalMeshPendingChanges
// Size: 0x40 (Inherited: 0x00)
struct FSkeletalMeshPendingChanges {
	struct TArray<struct UEmbarkSkeletalMeshComponent*> PendingChildComponentsToAdd; // 0x00(0x10)
	struct TArray<struct UEmbarkSkeletalMeshComponent*> PendingChildComponentsToRemove; // 0x10(0x10)
	struct TArray<struct FPendingSkeletalMeshChange> PendingMeshChanges; // 0x20(0x10)
	struct USkeletalMesh* PendingMeshChange; // 0x30(0x08)
	bool bPendingMeshChangeReinitPose; // 0x38(0x01)
	bool bPendingEndPlay; // 0x39(0x01)
	enum class EEndPlayReason PendingEndPlayReason; // 0x3a(0x01)
	char pad_3b[0x5]; // 0x3b(0x05)
};

// ScriptStruct EmbarkGameplay.AnimUpdateRateInfo
// Size: 0x0c (Inherited: 0x00)
struct FAnimUpdateRateInfo {
	char PoseEvalUpdateRate; // 0x00(0x01)
	char pad_1[0xb]; // 0x01(0x0b)
};

// ScriptStruct EmbarkGameplay.OptimizedChildPoseCopyInfo
// Size: 0x88 (Inherited: 0x00)
struct FOptimizedChildPoseCopyInfo {
	struct USkeletalMesh* CachedParentMesh; // 0x00(0x08)
	struct USkeletalMesh* CachedChildMesh; // 0x08(0x08)
	char pad_10[0x50]; // 0x10(0x50)
	float MeshScaleCorrection; // 0x60(0x04)
	float EnableAtThisDistanceToCamera_LowSignificance; // 0x64(0x04)
	float EnableAtThisDistanceToCamera_MediumSignificance; // 0x68(0x04)
	float EnableAtThisDistanceToCamera_HighSignificance; // 0x6c(0x04)
	char pad_70[0x4]; // 0x70(0x04)
	char Significance; // 0x74(0x01)
	char pad_75[0x3]; // 0x75(0x03)
	float CurrentDistanceToCamera; // 0x78(0x04)
	char pad_7c[0x4]; // 0x7c(0x04)
	bool bWasRecentlyRendered; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// ScriptStruct EmbarkGameplay.SimpleAttachInfo
// Size: 0x10 (Inherited: 0x00)
struct FSimpleAttachInfo {
	struct USkeletalMeshComponent* Component; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkSkelMeshSetTickEnabledScope
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkSkelMeshSetTickEnabledScope {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkSMActiveStateData
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkSMActiveStateData {
	struct TArray<char> StateIndices; // 0x00(0x10)
};

// ScriptStruct EmbarkGameplay.EmbarkSocketSelection
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkSocketSelection {
	struct FName SocketName; // 0x00(0x08)
};

// ScriptStruct EmbarkGameplay.EmbarkStateMachineTransitionInstance
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkStateMachineTransitionInstance {
	char pad_0[0x10]; // 0x00(0x10)
	struct UEmbarkStateMachineTransition* Transition; // 0x10(0x08)
	char pad_18[0x10]; // 0x18(0x10)
};

// ScriptStruct EmbarkGameplay.EmbarkStateMachineStateInstance
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkStateMachineStateInstance {
	struct UEmbarkStateMachineState* State; // 0x00(0x08)
	struct TArray<struct FEmbarkStateMachineTransitionInstance> ExitTransitions; // 0x08(0x10)
	char pad_18[0x18]; // 0x18(0x18)
};

// ScriptStruct EmbarkGameplay.EmbarkStateMachine
// Size: 0x990 (Inherited: 0x00)
struct FEmbarkStateMachine {
	struct FName Name; // 0x00(0x08)
	char pad_8[0x978]; // 0x08(0x978)
	struct TArray<struct UObject*> StatesAndTransitions; // 0x980(0x10)
};

// ScriptStruct EmbarkGameplay.ReleaseTag
// Size: 0x01 (Inherited: 0x00)
struct FReleaseTag {
	char pad_0[0x1]; // 0x00(0x01)
};

