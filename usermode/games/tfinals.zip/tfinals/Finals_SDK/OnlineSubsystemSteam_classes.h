// Class OnlineSubsystemSteam.SteamAuthComponentModuleInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USteamAuthComponentModuleInterface : UHandlerComponentFactory {
};

// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x1f10 (Inherited: 0x1f00)
struct USteamNetConnection : UIpConnection {
	bool bIsPassthrough; // 0x1f00(0x01)
	char pad_1f01[0xf]; // 0x1f01(0x0f)
};

// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x8f0 (Inherited: 0x8f0)
struct USteamNetDriver : UIpNetDriver {
};

