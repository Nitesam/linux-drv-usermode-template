// ScriptStruct MovieRenderPipelineSettings.MoviePipelineConsoleVariableEntry
// Size: 0x18 (Inherited: 0x00)
struct FMoviePipelineConsoleVariableEntry {
	struct FString Name; // 0x00(0x10)
	float Value; // 0x10(0x04)
	bool bIsEnabled; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

