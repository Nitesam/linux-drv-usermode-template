// Class AudioLinkCore.AudioLinkSettingsAbstract
// Size: 0xb0 (Inherited: 0xa0)
struct UAudioLinkSettingsAbstract : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

