// Class CoreUObject.Object
// Size: 0xa0 (Inherited: 0x00)
struct UObject {
	char pad_0[0xa0]; // 0x00(0xa0)

	void ExecuteUbergraph(int32_t EntryPoint); // Function CoreUObject.Object.ExecuteUbergraph // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class CoreUObject.GCObjectReferencer
// Size: 0xb0 (Inherited: 0xa0)
struct UGCObjectReferencer : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class CoreUObject.TextBuffer
// Size: 0xc0 (Inherited: 0xa0)
struct UTextBuffer : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class CoreUObject.Field
// Size: 0xa0 (Inherited: 0xa0)
struct UField : UObject {
};

// Class CoreUObject.Struct
// Size: 0x130 (Inherited: 0xa0)
struct UStruct : UField {
	char pad_a0[0x90]; // 0xa0(0x90)
};

// Class CoreUObject.ScriptStruct
// Size: 0x140 (Inherited: 0x130)
struct UScriptStruct : UStruct {
	char pad_130[0x10]; // 0x130(0x10)
};

// Class CoreUObject.Package
// Size: 0x100 (Inherited: 0xa0)
struct UPackage : UObject {
	char pad_a0[0x60]; // 0xa0(0x60)
};

// Class CoreUObject.Class
// Size: 0x2f0 (Inherited: 0x130)
struct UClass : UStruct {
	char pad_130[0x1c0]; // 0x130(0x1c0)
};

// Class CoreUObject.Function
// Size: 0x160 (Inherited: 0x130)
struct UFunction : UStruct {
	char pad_130[0x30]; // 0x130(0x30)
};

// Class CoreUObject.DelegateFunction
// Size: 0x160 (Inherited: 0x160)
struct UDelegateFunction : UFunction {
};

// Class CoreUObject.SparseDelegateFunction
// Size: 0x170 (Inherited: 0x160)
struct USparseDelegateFunction : UDelegateFunction {
	char pad_160[0x10]; // 0x160(0x10)
};

// Class CoreUObject.DynamicClass
// Size: 0x370 (Inherited: 0x2f0)
struct UDynamicClass : UClass {
	char pad_2f0[0x80]; // 0x2f0(0x80)
};

// Class CoreUObject.PackageMap
// Size: 0x150 (Inherited: 0xa0)
struct UPackageMap : UObject {
	char pad_a0[0xb0]; // 0xa0(0xb0)
};

// Class CoreUObject.Enum
// Size: 0xe0 (Inherited: 0xa0)
struct UEnum : UField {
	char pad_a0[0x40]; // 0xa0(0x40)
};

// Class CoreUObject.ObjectReachabilityStressData
// Size: 0xb0 (Inherited: 0xa0)
struct UObjectReachabilityStressData : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class CoreUObject.Interface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterface : UObject {
};

// Class CoreUObject.LinkerPlaceholderClass
// Size: 0x4b0 (Inherited: 0x2f0)
struct ULinkerPlaceholderClass : UClass {
	char pad_2f0[0x1c0]; // 0x2f0(0x1c0)
};

// Class CoreUObject.LinkerPlaceholderExportObject
// Size: 0x170 (Inherited: 0xa0)
struct ULinkerPlaceholderExportObject : UObject {
	char pad_a0[0xd0]; // 0xa0(0xd0)
};

// Class CoreUObject.LinkerPlaceholderFunction
// Size: 0x320 (Inherited: 0x160)
struct ULinkerPlaceholderFunction : UFunction {
	char pad_160[0x1c0]; // 0x160(0x1c0)
};

// Class CoreUObject.MetaData
// Size: 0x140 (Inherited: 0xa0)
struct UMetaData : UObject {
	char pad_a0[0xa0]; // 0xa0(0xa0)
};

// Class CoreUObject.ObjectRedirector
// Size: 0xa0 (Inherited: 0xa0)
struct UObjectRedirector : UObject {
};

// Class CoreUObject.Property
// Size: 0xe0 (Inherited: 0xa0)
struct UProperty : UField {
	char pad_a0[0x40]; // 0xa0(0x40)
};

// Class CoreUObject.EnumProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UEnumProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.ArrayProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UArrayProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.ObjectPropertyBase
// Size: 0xf0 (Inherited: 0xe0)
struct UObjectPropertyBase : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.BoolProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UBoolProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.NumericProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UNumericProperty : UProperty {
};

// Class CoreUObject.ByteProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UByteProperty : UNumericProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.ObjectProperty
// Size: 0xf0 (Inherited: 0xf0)
struct UObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.ClassProperty
// Size: 0xf0 (Inherited: 0xf0)
struct UClassProperty : UObjectProperty {
};

// Class CoreUObject.DelegateProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UDelegateProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.DoubleProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UDoubleProperty : UNumericProperty {
};

// Class CoreUObject.FloatProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UFloatProperty : UNumericProperty {
};

// Class CoreUObject.IntProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UIntProperty : UNumericProperty {
};

// Class CoreUObject.Int8Property
// Size: 0xe0 (Inherited: 0xe0)
struct UInt8Property : UNumericProperty {
};

// Class CoreUObject.Int16Property
// Size: 0xe0 (Inherited: 0xe0)
struct UInt16Property : UNumericProperty {
};

// Class CoreUObject.Int64Property
// Size: 0xe0 (Inherited: 0xe0)
struct UInt64Property : UNumericProperty {
};

// Class CoreUObject.InterfaceProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UInterfaceProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.LazyObjectProperty
// Size: 0xf0 (Inherited: 0xf0)
struct ULazyObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.MapProperty
// Size: 0x110 (Inherited: 0xe0)
struct UMapProperty : UProperty {
	char pad_e0[0x30]; // 0xe0(0x30)
};

// Class CoreUObject.MulticastDelegateProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UMulticastDelegateProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.MulticastInlineDelegateProperty
// Size: 0xf0 (Inherited: 0xf0)
struct UMulticastInlineDelegateProperty : UMulticastDelegateProperty {
};

// Class CoreUObject.MulticastSparseDelegateProperty
// Size: 0xf0 (Inherited: 0xf0)
struct UMulticastSparseDelegateProperty : UMulticastDelegateProperty {
};

// Class CoreUObject.NameProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UNameProperty : UProperty {
};

// Class CoreUObject.SetProperty
// Size: 0x100 (Inherited: 0xe0)
struct USetProperty : UProperty {
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class CoreUObject.SoftObjectProperty
// Size: 0xf0 (Inherited: 0xf0)
struct USoftObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.SoftClassProperty
// Size: 0xf0 (Inherited: 0xf0)
struct USoftClassProperty : USoftObjectProperty {
};

// Class CoreUObject.StrProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UStrProperty : UProperty {
};

// Class CoreUObject.StructProperty
// Size: 0xf0 (Inherited: 0xe0)
struct UStructProperty : UProperty {
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class CoreUObject.UInt16Property
// Size: 0xe0 (Inherited: 0xe0)
struct UUInt16Property : UNumericProperty {
};

// Class CoreUObject.UInt32Property
// Size: 0xe0 (Inherited: 0xe0)
struct UUInt32Property : UNumericProperty {
};

// Class CoreUObject.UInt64Property
// Size: 0xe0 (Inherited: 0xe0)
struct UUInt64Property : UNumericProperty {
};

// Class CoreUObject.WeakObjectProperty
// Size: 0xf0 (Inherited: 0xf0)
struct UWeakObjectProperty : UObjectPropertyBase {
};

// Class CoreUObject.TextProperty
// Size: 0xe0 (Inherited: 0xe0)
struct UTextProperty : UProperty {
};

// Class CoreUObject.PropertyWrapper
// Size: 0xa0 (Inherited: 0xa0)
struct UPropertyWrapper : UObject {
};

// Class CoreUObject.MulticastDelegatePropertyWrapper
// Size: 0xa0 (Inherited: 0xa0)
struct UMulticastDelegatePropertyWrapper : UPropertyWrapper {
};

// Class CoreUObject.MulticastInlineDelegatePropertyWrapper
// Size: 0xa0 (Inherited: 0xa0)
struct UMulticastInlineDelegatePropertyWrapper : UMulticastDelegatePropertyWrapper {
};

