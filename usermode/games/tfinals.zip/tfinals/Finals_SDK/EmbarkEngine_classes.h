// Class EmbarkEngine.ActorWithEditorTick
// Size: 0x3a0 (Inherited: 0x3a0)
struct AActorWithEditorTick : AActor {
	bool bUseEditorTick; // 0x398(0x01)

	void EditorTick(float DeltaSeconds); // Function EmbarkEngine.ActorWithEditorTick.EditorTick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkEngine.CurveTranslateRotate
// Size: 0x3a0 (Inherited: 0xa0)
struct UCurveTranslateRotate : UCurveBase {
	struct FRichCurve FloatCurves[0x6]; // 0xa0(0x300)

	void UpdateOrAddKeys(float Time, struct FTransform& Transform, bool bUnwindRotation); // Function EmbarkEngine.CurveTranslateRotate.UpdateOrAddKeys // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5514830
	void UpdateOrAddKey(enum class ECurveTRTrack Track, float Time, float Value, bool bUnwindRotation, float KeyTimeTolerance); // Function EmbarkEngine.CurveTranslateRotate.UpdateOrAddKey // (Final|Native|Public) // @ game+0x551b5c0
	bool UpdateKeyInterpMode(enum class ECurveTRTrack Track, float Time, enum class ERichCurveInterpMode InterpMode, enum class ERichCurveTangentMode TangentMode, float KeyTimeTolerance); // Function EmbarkEngine.CurveTranslateRotate.UpdateKeyInterpMode // (Final|Native|Public) // @ game+0x551bbb0
	void ResetAll(); // Function EmbarkEngine.CurveTranslateRotate.ResetAll // (Final|Native|Public) // @ game+0x55194d0
	void GetTrackValue(float InTime, struct FVector& OutTranslation, struct FVector& OutRotation); // Function EmbarkEngine.CurveTranslateRotate.GetTrackValue // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x55152c0
};

// Class EmbarkEngine.EmbarkDataAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDataAsset : UDataAsset {

	void ReceivePreSave(); // Function EmbarkEngine.EmbarkDataAsset.ReceivePreSave // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkEngine.EmbarkEditableObject
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkEditableObject : UObject {

	void ReceivePreSave(); // Function EmbarkEngine.EmbarkEditableObject.ReceivePreSave // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkEngine.EmbarkEnergySavingSubsystem
// Size: 0x120 (Inherited: 0xa0)
struct UEmbarkEnergySavingSubsystem : UEngineSubsystem {
	char pad_a0[0x80]; // 0xa0(0x80)

	void SetEnergySavingModeAllowed(struct FName& Reason, bool bIsAllowed); // Function EmbarkEngine.EmbarkEnergySavingSubsystem.SetEnergySavingModeAllowed // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x551b940
};

// Class EmbarkEngine.EmbarkEngineBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkEngineBlueprintLibrary : UBlueprintFunctionLibrary {

	uint64_t GetFrameCounter(); // Function EmbarkEngine.EmbarkEngineBlueprintLibrary.GetFrameCounter // (Final|Native|Static|Public) // @ game+0x5513960
	void GetAverageFPSAndNumFramesPresented(float& OutAverageFPS, int32_t& OutNumFramesPresented); // Function EmbarkEngine.EmbarkEngineBlueprintLibrary.GetAverageFPSAndNumFramesPresented // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x55195c0
	void AddViewInformationToStreaming(struct FVector& ViewOrigin, float ScreenSize, float FOV, float BoostFactor, bool bOverrideLocation, float Duration, struct AActor* ActorToBoost); // Function EmbarkEngine.EmbarkEngineBlueprintLibrary.AddViewInformationToStreaming // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5516f70
};

// Class EmbarkEngine.EmbarkEngineStatSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkEngineStatSubsystem : UEngineSubsystem {
};

// Class EmbarkEngine.EmbarkEngineTweakAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkEngineTweakAsset : UDataAsset {
};

// Class EmbarkEngine.EmbarkEngineTweakSubsystem
// Size: 0xe0 (Inherited: 0xa0)
struct UEmbarkEngineTweakSubsystem : UEngineSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct FSoftObjectPath DataAssetPath; // 0xb0(0x20)
	struct UEmbarkEngineTweakAsset* DataAsset; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class EmbarkEngine.EmbarkFileDownloadComponent
// Size: 0x310 (Inherited: 0x160)
struct UEmbarkFileDownloadComponent : UActorComponent {
	struct APlayerController* OwningController; // 0x158(0x08)
	char pad_168[0x198]; // 0x168(0x198)
	struct UDirectReplicationWrapperComponent* DirectReplicationWrapperComp; // 0x300(0x08)
	char pad_308[0x8]; // 0x308(0x08)
};

// Class EmbarkEngine.EmbarkGameEngine
// Size: 0x1360 (Inherited: 0x1360)
struct UEmbarkGameEngine : UGameEngine {
};

// Class EmbarkEngine.EmbarkGlobalSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkGlobalSubsystem : USubsystem {

	void OnInitialized(); // Function EmbarkEngine.EmbarkGlobalSubsystem.OnInitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitialized(); // Function EmbarkEngine.EmbarkGlobalSubsystem.OnDeinitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkEngine.LandscapeSubsystemMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULandscapeSubsystemMixinLibrary : UObject {

	void RegenerateGrass(struct ULandscapeSubsystem* LandscapeSubsystem, bool bInFlushGrass, bool bInForceSync, struct TArray<struct FVector> InCameraLocations); // Function EmbarkEngine.LandscapeSubsystemMixinLibrary.RegenerateGrass // (Final|Native|Static|Public) // @ game+0x5517b20
};

// Class EmbarkEngine.LevelInstanceSubsystemMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULevelInstanceSubsystemMixinLibrary : UObject {

	struct ALevelInstance* GetOwningLevelInstance(struct ULevelInstanceSubsystem* LevelInstanceSubsystem, struct ULevel* Level); // Function EmbarkEngine.LevelInstanceSubsystemMixinLibrary.GetOwningLevelInstance // (Final|Native|Static|Public) // @ game+0x551aa30
	struct ULevel* GetLevelInstanceLevel(struct ULevelInstanceSubsystem* LevelInstanceSubsystem, struct ALevelInstance* LevelInstanceActor); // Function EmbarkEngine.LevelInstanceSubsystemMixinLibrary.GetLevelInstanceLevel // (Final|Native|Static|Public) // @ game+0x55159c0
};

// Class EmbarkEngine.EmbarkMeshGeneratorComponent
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkMeshGeneratorComponent : UActorComponent {

	struct UStaticMeshComponent* ConstructStaticMeshComponent(struct UStaticMesh* StaticMesh, struct UMeshComponent* ParentComponent, struct FName& SocketName); // Function EmbarkEngine.EmbarkMeshGeneratorComponent.ConstructStaticMeshComponent // (Final|Native|Protected|HasOutParms) // @ game+0x5517df0
};

// Class EmbarkEngine.EmbarkPhysicsCollisionHandler
// Size: 0xc0 (Inherited: 0xb0)
struct UEmbarkPhysicsCollisionHandler : UPhysicsCollisionHandler {
	char pad_b0[0x10]; // 0xb0(0x10)

	void ReceiveInitCollisionHandler(); // Function EmbarkEngine.EmbarkPhysicsCollisionHandler.ReceiveInitCollisionHandler // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveHandlePhysicsCollisions(struct TArray<struct FEmbarkCollisionNotifyInfo>& PendingCollisionNotifies); // Function EmbarkEngine.EmbarkPhysicsCollisionHandler.ReceiveHandlePhysicsCollisions // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkEngine.EmbarkScriptWorldSubsystem
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkScriptWorldSubsystem : UScriptWorldSubsystem {

	void BP_InitializeWithCollection(struct FScriptSubsystemCollectionBase& CollectionBase); // Function EmbarkEngine.EmbarkScriptWorldSubsystem.BP_InitializeWithCollection // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkEngine.EmbarkSDFVolumeTexture
// Size: 0x2f0 (Inherited: 0x2a0)
struct UEmbarkSDFVolumeTexture : UTexture {
	int32_t SizeX; // 0x2a0(0x04)
	int32_t SizeY; // 0x2a4(0x04)
	int32_t SizeZ; // 0x2a8(0x04)
	enum class EPixelFormat PixelFormat; // 0x2ac(0x01)
	char pad_2ad[0x3]; // 0x2ad(0x03)
	float InitialValue; // 0x2b0(0x04)
	char pad_2b4[0x4]; // 0x2b4(0x04)
	struct FBox Bounds; // 0x2b8(0x38)

	void SetSize(int32_t InSizeX, int32_t InSizeY, int32_t InSizeZ); // Function EmbarkEngine.EmbarkSDFVolumeTexture.SetSize // (Final|Native|Public|BlueprintCallable) // @ game+0x5518f50
	void SetBounds(struct FBox& InBounds); // Function EmbarkEngine.EmbarkSDFVolumeTexture.SetBounds // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5514080
};

// Class EmbarkEngine.EmbarkSDFVolumeTextureLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkSDFVolumeTextureLibrary : UBlueprintFunctionLibrary {

	void WriteSDFSphereToVolumeTexture(struct UObject* WorldContextObject, struct UEmbarkSDFVolumeTexture* Texture, struct FVector& Origin, double Radius); // Function EmbarkEngine.EmbarkSDFVolumeTextureLibrary.WriteSDFSphereToVolumeTexture // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5517930
	void WriteBoxToVolumeTexture(struct UObject* WorldContextObject, struct UEmbarkSDFVolumeTexture* Texture, struct FVector& Origin, double Extent, double Intensity); // Function EmbarkEngine.EmbarkSDFVolumeTextureLibrary.WriteBoxToVolumeTexture // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5514320
	void ReleaseSDFVolumeTexture(struct UEmbarkSDFVolumeTexture* Texture); // Function EmbarkEngine.EmbarkSDFVolumeTextureLibrary.ReleaseSDFVolumeTexture // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x551a4d0
	void LerpVolumeTexture(struct UObject* WorldContextObject, struct UEmbarkSDFVolumeTexture* Texture, double TargetValue, double Alpha, struct FIntVector Size, struct FIntVector Offset); // Function EmbarkEngine.EmbarkSDFVolumeTextureLibrary.LerpVolumeTexture // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5513c40
	struct UEmbarkSDFVolumeTexture* CreateSDFVolumeTexture(struct UObject* WorldContextObject, struct FIntVector& Size, struct FBox& Bounds); // Function EmbarkEngine.EmbarkSDFVolumeTextureLibrary.CreateSDFVolumeTexture // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5515870
	void ClearSDFVolumeTexture(struct UObject* WorldContextObject, struct UEmbarkSDFVolumeTexture* Texture, float MaxDistance); // Function EmbarkEngine.EmbarkSDFVolumeTextureLibrary.ClearSDFVolumeTexture // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5518530
};

// Class EmbarkEngine.EmbarkTestASPerf
// Size: 0xc0 (Inherited: 0xb0)
struct UEmbarkTestASPerf : UScriptWorldSubsystem {
	struct FMulticastInlineDelegate DynamicMulticastDelegate; // 0xb0(0x10)

	void TestDynamicMulticastDelegateBroadcast(); // Function EmbarkEngine.EmbarkTestASPerf.TestDynamicMulticastDelegateBroadcast // (Final|Native|Public|BlueprintCallable) // @ game+0x551b2a0
	void SetTestRunnerCallback(struct FDelegate Callback); // Function EmbarkEngine.EmbarkTestASPerf.SetTestRunnerCallback // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5515450
	void SetNopCallback(struct FDelegate Callback); // Function EmbarkEngine.EmbarkTestASPerf.SetNopCallback // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5515450
	void Reset(struct TArray<double>& RandomDoubles); // Function EmbarkEngine.EmbarkTestASPerf.Reset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5519e90
	struct FString PerfTestToString(enum class EEmbarkTestASPerfType Type); // Function EmbarkEngine.EmbarkTestASPerf.PerfTestToString // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5514240
	void NopFunction(); // Function EmbarkEngine.EmbarkTestASPerf.NopFunction // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33aadf0
	double GetTimeSeconds(); // Function EmbarkEngine.EmbarkTestASPerf.GetTimeSeconds // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x55174b0
	double GetSecondsPerCycle64(); // Function EmbarkEngine.EmbarkTestASPerf.GetSecondsPerCycle64 // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x55174b0
	int64_t GetCycles64(); // Function EmbarkEngine.EmbarkTestASPerf.GetCycles64 // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5514210
	int32_t ExecPerfTest(enum class EEmbarkTestASPerfType Type, int32_t Arg0); // Function EmbarkEngine.EmbarkTestASPerf.ExecPerfTest // (Final|Native|Public|BlueprintCallable) // @ game+0x551b3f0
	void BlueprintNativeEvent(bool bBoolean, struct FVector& Vector); // Function EmbarkEngine.EmbarkTestASPerf.BlueprintNativeEvent // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x5514a00
	void BeginPerfTest(enum class EEmbarkTestASPerfType Type, int32_t Arg0); // Function EmbarkEngine.EmbarkTestASPerf.BeginPerfTest // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x55169b0
};

// Class EmbarkEngine.EmbarkTestGPUCrashSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkTestGPUCrashSubsystem : UEngineSubsystem {
};

// Class EmbarkEngine.EmbarkTestWorkloadSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkTestWorkloadSubsystem : UEngineSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class EmbarkEngine.WorldCompositionMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UWorldCompositionMixinLibrary : UObject {

	int32_t GetStreamingDistance(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.GetStreamingDistance // (Final|Native|Static|Public|HasOutParms) // @ game+0x551ee20
	struct FIntVector GetPosition(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.GetPosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x551d6c0
	struct FString GetParentTilePackageName(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.GetParentTilePackageName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5520430
	struct FString GetLayerName(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.GetLayerName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5520430
	bool GetDistanceStreamingEnabled(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.GetDistanceStreamingEnabled // (Final|Native|Static|Public|HasOutParms) // @ game+0x551c6c0
	struct FIntVector GetAbsolutePosition(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.GetAbsolutePosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x551d6c0
	bool DoesTileExists(struct UWorldComposition* WorldComposition, struct FName& PackageName); // Function EmbarkEngine.WorldCompositionMixinLibrary.DoesTileExists // (Final|Native|Static|Public|HasOutParms) // @ game+0x551f910
};

// Class EmbarkEngine.EmbarkWorldPartitionRuntimeSpatialHash
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkWorldPartitionRuntimeSpatialHash : UWorldPartitionRuntimeSpatialHash {
};

// Class EmbarkEngine.EmbarkWorldSettingsExtension
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWorldSettingsExtension : UObject {
};

// Class EmbarkEngine.EmbarkWorldSettingsBase
// Size: 0x640 (Inherited: 0x5c0)
struct AEmbarkWorldSettingsBase : AWorldSettings {
	struct FVector MaxWorldLimits; // 0x5b8(0x18)
	struct FVector MinWorldLimits; // 0x5d0(0x18)
	struct FIntVector FullChangeBitCountXYZ; // 0x5e8(0x0c)
	struct FIntVector SmallChangeBitCountXYZ; // 0x5f4(0x0c)
	int32_t BitCountForSmallChangeRotation; // 0x600(0x04)
	int32_t BitCountForFullChangeRotation; // 0x604(0x04)
	bool DisableActorTransformReplicationForDestruction; // 0x608(0x01)
	struct FIntVector HighQualityFullChangeBitCountXYZ; // 0x60c(0x0c)
	struct FIntVector HighQualitySmallChangeBitCountXYZ; // 0x618(0x0c)
	int32_t HighQualityBitCountForSmallChangeRotation; // 0x624(0x04)
	int32_t HighQualityBitCountForFullChangeRotation; // 0x628(0x04)
	struct TArray<struct UEmbarkWorldSettingsExtension*> WorldSettingsExtensions; // 0x630(0x10)
};

// Class EmbarkEngine.EmbarkHttpRequestContainer
// Size: 0xe0 (Inherited: 0xa0)
struct UEmbarkHttpRequestContainer : UObject {
	struct FMulticastInlineDelegate OnHttpRequestCompleted; // 0x98(0x10)
	struct TArray<char> ResponseContent; // 0xa8(0x10)
	int32_t ResponseCode; // 0xb8(0x04)
	struct TArray<struct FString> ResponseHeaders; // 0xc0(0x10)
	char pad_d4[0xc]; // 0xd4(0x0c)

	void SetVerb(struct FString NewVerb); // Function EmbarkEngine.EmbarkHttpRequestContainer.SetVerb // (Final|Native|Public|BlueprintCallable) // @ game+0x551e040
	void SetURL(struct FString NewUrl); // Function EmbarkEngine.EmbarkHttpRequestContainer.SetURL // (Final|Native|Public|BlueprintCallable) // @ game+0x5522710
	void SetPayloadBytes(struct TArray<char>& Payload); // Function EmbarkEngine.EmbarkHttpRequestContainer.SetPayloadBytes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5521a10
	void SetPayload(struct FString Payload); // Function EmbarkEngine.EmbarkHttpRequestContainer.SetPayload // (Final|Native|Public|BlueprintCallable) // @ game+0x551e1b0
	void SetHeader(struct FString HeaderName, struct FString HeaderValue); // Function EmbarkEngine.EmbarkHttpRequestContainer.SetHeader // (Final|Native|Public|BlueprintCallable) // @ game+0x5520f90
	void ProcessRequest(); // Function EmbarkEngine.EmbarkHttpRequestContainer.ProcessRequest // (Final|Native|Public|BlueprintCallable) // @ game+0x551c8c0
	struct FString GetVerb(); // Function EmbarkEngine.EmbarkHttpRequestContainer.GetVerb // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x551e750
	struct FString GetUrl(); // Function EmbarkEngine.EmbarkHttpRequestContainer.GetUrl // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x551cd00
	struct TArray<struct FString> GetHeaders(); // Function EmbarkEngine.EmbarkHttpRequestContainer.GetHeaders // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x551ed20
	struct FString GetHeader(struct FString HeaderName); // Function EmbarkEngine.EmbarkHttpRequestContainer.GetHeader // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5521910
	float GetElapsedTime(); // Function EmbarkEngine.EmbarkHttpRequestContainer.GetElapsedTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55226a0
};

// Class EmbarkEngine.HttpFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UHttpFunctionLibrary : UBlueprintFunctionLibrary {

	struct FString UrlEncode(struct FString InString); // Function EmbarkEngine.HttpFunctionLibrary.UrlEncode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x551fca0
	struct FString UrlDecode(struct FString InString); // Function EmbarkEngine.HttpFunctionLibrary.UrlDecode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x551efb0
	struct FEmbarkHttpParameter MakeHttpParameter(struct FString InParameterKey, struct FString InParameterValue); // Function EmbarkEngine.HttpFunctionLibrary.MakeHttpParameter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5522280
	void FlushPendingRequests(); // Function EmbarkEngine.HttpFunctionLibrary.FlushPendingRequests // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x551cfb0
	struct UEmbarkHttpRequestContainer* CreateSimpleHttpRequest(struct FString Verb, struct FString URL, struct TArray<struct FEmbarkHttpParameter>& Parameters); // Function EmbarkEngine.HttpFunctionLibrary.CreateSimpleHttpRequest // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x551d210
	struct UEmbarkHttpRequestContainer* CreateHttpRequest(struct FString AuthorizationToken, struct FString Verb, struct FString URL, struct TArray<struct FEmbarkHttpParameter>& Parameters); // Function EmbarkEngine.HttpFunctionLibrary.CreateHttpRequest // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5520b70
};

// Class EmbarkEngine.OptionallyCookableAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UOptionallyCookableAsset : UInterface {
};

// Class EmbarkEngine.LevelInstanceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULevelInstanceMixinLibrary : UObject {
};

// Class EmbarkEngine.MaterialExpressionEmbarkCompositeMeshNormal
// Size: 0x130 (Inherited: 0x120)
struct UMaterialExpressionEmbarkCompositeMeshNormal : UMaterialExpression {
	enum class EEmbarkVertexSpace NormalSpace; // 0x120(0x01)
	char pad_121[0xf]; // 0x121(0x0f)
};

// Class EmbarkEngine.MaterialExpressionEmbarkCompositeMeshPosition
// Size: 0x130 (Inherited: 0x120)
struct UMaterialExpressionEmbarkCompositeMeshPosition : UMaterialExpression {
	enum class EEmbarkVertexSpace PositionSpace; // 0x120(0x01)
	char pad_121[0xf]; // 0x121(0x0f)
};

// Class EmbarkEngine.EmbarkLandscapeLayerList
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkLandscapeLayerList : UDataAsset {
	struct TArray<struct ULandscapeLayerInfoObject*> Layers; // 0xa0(0x10)
};

// Class EmbarkEngine.MaterialExpressionEmbarkLandscapeLayerBlend
// Size: 0x140 (Inherited: 0x120)
struct UMaterialExpressionEmbarkLandscapeLayerBlend : UMaterialExpression {
	struct TArray<struct FEmbarkLayerBlendInput> EmbarkLayers; // 0x120(0x10)
	struct UEmbarkLandscapeLayerList* LayerList; // 0x130(0x08)
	char pad_138[0x8]; // 0x138(0x08)
};

// Class EmbarkEngine.MaterialExpressionEmbarkLandscapeLayerSample
// Size: 0x170 (Inherited: 0x120)
struct UMaterialExpressionEmbarkLandscapeLayerSample : UMaterialExpression {
	struct FName ParameterName; // 0x120(0x08)
	float PreviewWeight; // 0x128(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)
	struct FExpressionInput SharpnessInput; // 0x130(0x28)
	float ConstSharpness; // 0x158(0x04)
	bool bCompositeLayers; // 0x15c(0x01)
	char pad_15d[0x3]; // 0x15d(0x03)
	struct UEmbarkLandscapeLayerList* LayerList; // 0x160(0x08)
	char pad_168[0x8]; // 0x168(0x08)
};

// Class EmbarkEngine.OptionalPrimaryDataAsset
// Size: 0xb0 (Inherited: 0xa0)
struct UOptionalPrimaryDataAsset : UPrimaryDataAsset {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct FPrimaryAssetType OverridePrimaryAssetType; // 0xa8(0x08)
};

// Class EmbarkEngine.SimulatedSkinnedMeshComponent
// Size: 0xc60 (Inherited: 0xa80)
struct USimulatedSkinnedMeshComponent : USkinnedMeshComponent {
	bool bUseOptimizedBoundsCalculation; // 0xa78(0x01)
	bool bOptimizedBoundsCalculationActive; // 0xa79(0x01)
	bool bEnableKinematicKinematicHitEvents_Server; // 0xa7a(0x01)
	bool bEnableKinematicKinematicHitEvents_Client; // 0xa7b(0x01)
	char pad_a84[0x2d]; // 0xa84(0x2d)
	bool bOnlyReadAwakeBodies; // 0xab1(0x01)
	bool bUpdateOverlapsOnPhysicsread; // 0xab2(0x01)
	bool bCalculateBoundsUsingPhysics; // 0xab3(0x01)
	bool bUseConvexBoundingBoxesForGetClosestPointOnPhysicsAsset; // 0xab4(0x01)
	char pad_ab5[0x1ab]; // 0xab5(0x1ab)

	void TermBodiesBelow(struct FName ParentBoneName); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.TermBodiesBelow // (Final|Native|Public|BlueprintCallable) // @ game+0x551c620
	void SetBoneWorldTransform(int32_t BoneIndex, struct FTransform& Transform); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.SetBoneWorldTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x551ea00
	void SetBoneLocalTransform(int32_t BoneIndex, struct FTransform& Transform); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.SetBoneLocalTransform // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5520e50
	void SetBoneCollisionProfileName(struct FName BoneName, struct FName InCollisionProfileName); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.SetBoneCollisionProfileName // (Final|Native|Public|BlueprintCallable) // @ game+0x551d7b0
	void SetBodyTransform(struct FName BoneName, struct FTransform& Transform); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.SetBodyTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x551e520
	void SetBodySimulatePhysics(struct FName BoneName, bool bInSimulate); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.SetBodySimulatePhysics // (Final|Native|Public|BlueprintCallable) // @ game+0x5522100
	void SetAllBodiesBelowSimulatePhysics(struct FName& InBoneName, bool bNewSimulate, bool bIncludeSelf); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.SetAllBodiesBelowSimulatePhysics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5521220
	void OnPhysicsBodySleep(struct UPrimitiveComponent* SleepingComponent, struct FName BoneName); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.OnPhysicsBodySleep // (Final|Native|Protected) // @ game+0x5521bf0
	void OnPhysicsBodyAwake(struct UPrimitiveComponent* WakingComponent, struct FName BoneName); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.OnPhysicsBodyAwake // (Final|Native|Protected) // @ game+0x5521fc0
	bool K2_GetClosestPointOnPhysicsAsset(struct FVector& WorldPosition, struct FVector& ClosestWorldPosition, struct FVector& Normal, struct FName& BoneName, float& Distance); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.K2_GetClosestPointOnPhysicsAsset // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x551f0a0
	void ForceRefreshBoneTransforms(); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.ForceRefreshBoneTransforms // (Final|Native|Public) // @ game+0x5521170
	struct FName FindConstraintBoneName(int32_t ConstraintIndex); // Function EmbarkEngine.SimulatedSkinnedMeshComponent.FindConstraintBoneName // (Final|Native|Public|BlueprintCallable) // @ game+0x551ec00
};

