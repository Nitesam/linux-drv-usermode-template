// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0xde0 (Inherited: 0xda0)
struct UAudioCurveSourceComponent : UAudioComponent {
	struct FName CurveSourceBindingName; // 0xda0(0x08)
	float CurveSyncOffset; // 0xda8(0x04)
	char pad_dac[0x34]; // 0xdac(0x34)
};

