// Enum EmbarkSplineTools.ESplineMergeType
enum class ESplineMergeType : uint8_t {
	None = 0,
	StaticMesh = 1,
	SplineMesh = 2,
	ESplineMergeType_MAX = 3
};

// Enum EmbarkSplineTools.ESplineEndSegmentPlacement
enum class ESplineEndSegmentPlacement : uint8_t {
	Default = 0,
	PlaceOnSplineEndPoint = 1,
	SnapToLastSegment = 2,
	ESplineEndSegmentPlacement_MAX = 3
};

// Enum EmbarkSplineTools.ESplineMeshAlignment
enum class ESplineMeshAlignment : uint8_t {
	AlignToSpline = 0,
	AlignToGround = 1,
	ObjectSpace = 2,
	WorldSpace = 3,
	SplineHeadingOnly = 4,
	ESplineMeshAlignment_MAX = 5
};

// Enum EmbarkSplineTools.ESplineMeshDistributionMethod
enum class ESplineMeshDistributionMethod : uint8_t {
	BestFit = 0,
	OneMeshPerSplineSegment = 1,
	OneMeshPerSplinePoint = 2,
	ESplineMeshDistributionMethod_MAX = 3
};

// Enum EmbarkSplineTools.ESplineMeshSegmentObjectType
enum class ESplineMeshSegmentObjectType : uint8_t {
	StaticMesh = 0,
	SplineMesh = 1,
	ActorClass = 2,
	ESplineMeshSegmentObjectType_MAX = 3
};

// ScriptStruct EmbarkSplineTools.SplineMeshLayerStyleOverrides
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshLayerStyleOverrides {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshLayer
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshLayer {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshDeformationSettings
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshDeformationSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshSpacingSettings
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshSpacingSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshLightingSettings
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshLightingSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineSegmentWeightedMesh
// Size: 0x01 (Inherited: 0x00)
struct FSplineSegmentWeightedMesh {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.RandomOffsetTransform
// Size: 0x01 (Inherited: 0x00)
struct FRandomOffsetTransform {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshSocketAttachment
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshSocketAttachment {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshSegment
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshSegment {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineSegmentWeightedCornerMesh
// Size: 0x01 (Inherited: 0x00)
struct FSplineSegmentWeightedCornerMesh {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkSplineTools.SplineMeshCornerSegment
// Size: 0x01 (Inherited: 0x00)
struct FSplineMeshCornerSegment {
	char pad_0[0x1]; // 0x00(0x01)
};

