// Class BuildPatchServices.BuildPatchManifest
// Size: 0x190 (Inherited: 0xa0)
struct UBuildPatchManifest : UObject {
	char ManifestFileVersion; // 0x98(0x01)
	bool bIsFileData; // 0x99(0x01)
	uint32_t AppId; // 0x9c(0x04)
	struct FString AppName; // 0xa0(0x10)
	struct FString BuildVersion; // 0xb0(0x10)
	struct FString LaunchExe; // 0xc0(0x10)
	struct FString LaunchCommand; // 0xd0(0x10)
	struct TSet<struct FString> PrereqIds; // 0xe0(0x50)
	struct FString PrereqName; // 0x130(0x10)
	struct FString PrereqPath; // 0x140(0x10)
	struct FString PrereqArgs; // 0x150(0x10)
	struct TArray<struct FFileManifestData> FileManifestList; // 0x160(0x10)
	struct TArray<struct FChunkInfoData> ChunkList; // 0x170(0x10)
	struct TArray<struct FCustomFieldData> CustomFields; // 0x180(0x10)
};

