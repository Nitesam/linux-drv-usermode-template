// Class Overlay.Overlays
// Size: 0xa0 (Inherited: 0xa0)
struct UOverlays : UObject {
};

// Class Overlay.BasicOverlays
// Size: 0xb0 (Inherited: 0xa0)
struct UBasicOverlays : UOverlays {
	struct TArray<struct FOverlayItem> Overlays; // 0x98(0x10)
};

// Class Overlay.LocalizedOverlays
// Size: 0xf0 (Inherited: 0xa0)
struct ULocalizedOverlays : UOverlays {
	struct UBasicOverlays* DefaultOverlays; // 0x98(0x08)
	struct TMap<struct FString, struct UBasicOverlays*> LocaleToOverlaysMap; // 0xa0(0x50)
};

