// Class AntiCheatCore.AntiCheatDelegates
// Size: 0xe0 (Inherited: 0xa0)
struct UAntiCheatDelegates : UEngineSubsystem {
	struct FMulticastInlineDelegate OnViolation; // 0xa0(0x10)
	char pad_b0[0x30]; // 0xb0(0x30)
};

// Class AntiCheatCore.AntiCheatUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UAntiCheatUtils : UBlueprintFunctionLibrary {

	struct FString ViolationTypeToString(enum class EAntiCheatClientViolationType Value); // Function AntiCheatCore.AntiCheatUtils.ViolationTypeToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4884fe0
};

