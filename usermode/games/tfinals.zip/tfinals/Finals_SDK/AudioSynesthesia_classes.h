// Class AudioSynesthesia.AudioSynesthesiaSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioSynesthesiaSettings : UAudioAnalyzerSettings {
};

// Class AudioSynesthesia.AudioSynesthesiaNRTSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioSynesthesiaNRTSettings : UAudioAnalyzerNRTSettings {
};

// Class AudioSynesthesia.AudioSynesthesiaNRT
// Size: 0xf0 (Inherited: 0xf0)
struct UAudioSynesthesiaNRT : UAudioAnalyzerNRT {
};

// Class AudioSynesthesia.ConstantQNRTSettings
// Size: 0xc0 (Inherited: 0xa0)
struct UConstantQNRTSettings : UAudioSynesthesiaNRTSettings {
	float StartingFrequency; // 0x98(0x04)
	int32_t NumBands; // 0x9c(0x04)
	float NumBandsPerOctave; // 0xa0(0x04)
	float AnalysisPeriod; // 0xa4(0x04)
	bool bDownmixToMono; // 0xa8(0x01)
	enum class EConstantQFFTSizeEnum FFTSize; // 0xa9(0x01)
	enum class EFFTWindowType WindowType; // 0xaa(0x01)
	enum class EAudioSpectrumType SpectrumType; // 0xab(0x01)
	float BandWidthStretch; // 0xac(0x04)
	enum class EConstantQNormalizationEnum CQTNormalization; // 0xb0(0x01)
	float NoiseFloorDb; // 0xb4(0x04)
	char pad_bd[0x3]; // 0xbd(0x03)
};

// Class AudioSynesthesia.ConstantQNRT
// Size: 0xf0 (Inherited: 0xf0)
struct UConstantQNRT : UAudioSynesthesiaNRT {
	struct UConstantQNRTSettings* Settings; // 0xe8(0x08)

	void GetNormalizedChannelConstantQAtTime(float InSeconds, int32_t InChannel, struct TArray<float>& OutConstantQ); // Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d4c9a0
	void GetChannelConstantQAtTime(float InSeconds, int32_t InChannel, struct TArray<float>& OutConstantQ); // Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d4f350
};

// Class AudioSynesthesia.LoudnessSettings
// Size: 0xb0 (Inherited: 0xa0)
struct ULoudnessSettings : UAudioSynesthesiaSettings {
	float AnalysisPeriod; // 0x98(0x04)
	float MinimumFrequency; // 0x9c(0x04)
	float MaximumFrequency; // 0xa0(0x04)
	enum class ELoudnessCurveTypeEnum CurveType; // 0xa4(0x01)
	float NoiseFloorDb; // 0xa8(0x04)
	float ExpectedMaxLoudness; // 0xac(0x04)
};

// Class AudioSynesthesia.LoudnessAnalyzer
// Size: 0x150 (Inherited: 0x100)
struct ULoudnessAnalyzer : UAudioAnalyzer {
	struct ULoudnessSettings* Settings; // 0x100(0x08)
	struct FMulticastInlineDelegate OnOverallLoudnessResults; // 0x108(0x10)
	struct FMulticastInlineDelegate OnPerChannelLoudnessResults; // 0x118(0x10)
	struct FMulticastInlineDelegate OnLatestOverallLoudnessResults; // 0x128(0x10)
	struct FMulticastInlineDelegate OnLatestPerChannelLoudnessResults; // 0x138(0x10)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class AudioSynesthesia.LoudnessNRTSettings
// Size: 0xb0 (Inherited: 0xa0)
struct ULoudnessNRTSettings : UAudioSynesthesiaNRTSettings {
	float AnalysisPeriod; // 0x98(0x04)
	float MinimumFrequency; // 0x9c(0x04)
	float MaximumFrequency; // 0xa0(0x04)
	enum class ELoudnessNRTCurveTypeEnum CurveType; // 0xa4(0x01)
	float NoiseFloorDb; // 0xa8(0x04)
};

// Class AudioSynesthesia.LoudnessNRT
// Size: 0xf0 (Inherited: 0xf0)
struct ULoudnessNRT : UAudioSynesthesiaNRT {
	struct ULoudnessNRTSettings* Settings; // 0xe8(0x08)

	void GetNormalizedLoudnessAtTime(float InSeconds, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d50120
	void GetNormalizedChannelLoudnessAtTime(float InSeconds, int32_t InChannel, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d4c330
	void GetLoudnessAtTime(float InSeconds, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d50bc0
	void GetChannelLoudnessAtTime(float InSeconds, int32_t InChannel, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d53180
};

// Class AudioSynesthesia.MeterSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UMeterSettings : UAudioSynesthesiaSettings {
	float AnalysisPeriod; // 0x98(0x04)
	enum class EMeterPeakType PeakMode; // 0x9c(0x01)
	int32_t MeterAttackTime; // 0xa0(0x04)
	int32_t MeterReleaseTime; // 0xa4(0x04)
	int32_t PeakHoldTime; // 0xa8(0x04)
	float ClippingThreshold; // 0xac(0x04)
};

// Class AudioSynesthesia.MeterAnalyzer
// Size: 0x1b0 (Inherited: 0x100)
struct UMeterAnalyzer : UAudioAnalyzer {
	struct UMeterSettings* Settings; // 0x100(0x08)
	struct FMulticastInlineDelegate OnOverallMeterResults; // 0x108(0x10)
	char pad_118[0x18]; // 0x118(0x18)
	struct FMulticastInlineDelegate OnPerChannelMeterResults; // 0x130(0x10)
	char pad_140[0x18]; // 0x140(0x18)
	struct FMulticastInlineDelegate OnLatestOverallMeterResults; // 0x158(0x10)
	char pad_168[0x18]; // 0x168(0x18)
	struct FMulticastInlineDelegate OnLatestPerChannelMeterResults; // 0x180(0x10)
	char pad_190[0x20]; // 0x190(0x20)
};

// Class AudioSynesthesia.OnsetNRTSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UOnsetNRTSettings : UAudioSynesthesiaNRTSettings {
	bool bDownmixToMono; // 0x98(0x01)
	float GranularityInSeconds; // 0x9c(0x04)
	float Sensitivity; // 0xa0(0x04)
	float MinimumFrequency; // 0xa4(0x04)
	float MaximumFrequency; // 0xa8(0x04)
};

// Class AudioSynesthesia.OnsetNRT
// Size: 0xf0 (Inherited: 0xf0)
struct UOnsetNRT : UAudioSynesthesiaNRT {
	struct UOnsetNRTSettings* Settings; // 0xe8(0x08)

	void GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32_t InChannel, struct TArray<float>& OutOnsetTimestamps, struct TArray<float>& OutOnsetStrengths); // Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d4cb80
	void GetChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32_t InChannel, struct TArray<float>& OutOnsetTimestamps, struct TArray<float>& OutOnsetStrengths); // Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d55540
};

// Class AudioSynesthesia.SynesthesiaSpectrumAnalysisSettings
// Size: 0xa0 (Inherited: 0xa0)
struct USynesthesiaSpectrumAnalysisSettings : UAudioSynesthesiaSettings {
	float AnalysisPeriod; // 0x98(0x04)
	enum class EFFTSize FFTSize; // 0x9c(0x01)
	enum class EAudioSpectrumType SpectrumType; // 0x9d(0x01)
	enum class EFFTWindowType WindowType; // 0x9e(0x01)
	bool bDownmixToMono; // 0x9f(0x01)
};

// Class AudioSynesthesia.SynesthesiaSpectrumAnalyzer
// Size: 0x160 (Inherited: 0x100)
struct USynesthesiaSpectrumAnalyzer : UAudioAnalyzer {
	struct USynesthesiaSpectrumAnalysisSettings* Settings; // 0x100(0x08)
	struct FMulticastInlineDelegate OnSpectrumResults; // 0x108(0x10)
	char pad_118[0x18]; // 0x118(0x18)
	struct FMulticastInlineDelegate OnLatestSpectrumResults; // 0x130(0x10)
	char pad_140[0x20]; // 0x140(0x20)

	int32_t GetNumCenterFrequencies(); // Function AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetNumCenterFrequencies // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8d500a0
	void GetCenterFrequencies(float InSampleRate, struct TArray<float>& OutCenterFrequencies); // Function AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetCenterFrequencies // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8d4d5f0
};

