// Class EmbarkCloth.EmbarkClothConfig
// Size: 0x1f0 (Inherited: 0xa0)
struct UEmbarkClothConfig : UClothConfigCommon {
	bool bApplyAvaliableMorphTargetsAsDefault; // 0x98(0x01)
	bool bApplyUnholyScaleToNormals; // 0x99(0x01)
	float NormalScaleModifier; // 0x9c(0x04)
	struct FTransform3f SkinBindPoseOffset; // 0xa0(0x30)
	struct FName SkinBindPose_BoneName; // 0xd0(0x08)
	struct TArray<enum class EEmbarkClothDeformerType> PreSimulationDeformerTypes; // 0xd8(0x10)
	struct TArray<enum class EEmbarkClothDeformerType> PostSimulationDeformerTypes; // 0xe8(0x10)
	enum class EEmbarkClothSimulationType SimulationType; // 0xf8(0x01)
	char pad_ff[0x1]; // 0xff(0x01)
	struct FEmbarkClothPBDSettings PBDSettings; // 0x100(0xf0)
};

// Class EmbarkCloth.EmbarkClothingSimulationFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkClothingSimulationFactory : UClothingSimulationFactory {
};

// Class EmbarkCloth.EmbarkClothingInteractor
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkClothingInteractor : UClothingInteractor {
};

// Class EmbarkCloth.EmbarkClothingSimulationInteractor
// Size: 0x110 (Inherited: 0x100)
struct UEmbarkClothingSimulationInteractor : UClothingSimulationInteractor {
	char pad_100[0x10]; // 0x100(0x10)
};

