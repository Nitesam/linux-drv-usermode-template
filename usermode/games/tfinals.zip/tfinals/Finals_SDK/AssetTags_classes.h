// Class AssetTags.AssetTagsSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UAssetTagsSubsystem : UEngineSubsystem {

	struct TArray<struct FName> K2_GetCollectionsContainingAsset(struct FSoftObjectPath& AssetPath); // Function AssetTags.AssetTagsSubsystem.K2_GetCollectionsContainingAsset // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9c483b0
	struct TArray<struct FName> GetCollectionsContainingAssetPtr(struct UObject* AssetPtr); // Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr // (Final|Native|Public|BlueprintCallable) // @ game+0x9c48880
	struct TArray<struct FName> GetCollectionsContainingAssetData(struct FAssetData& AssetData); // Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9c45850
	struct TArray<struct FName> GetCollectionsContainingAsset(struct FName AssetPathName); // Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x9c47bd0
	struct TArray<struct FName> GetCollections(); // Function AssetTags.AssetTagsSubsystem.GetCollections // (Final|Native|Public|BlueprintCallable) // @ game+0x9c45780
	struct TArray<struct FAssetData> GetAssetsInCollection(struct FName Name); // Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection // (Final|Native|Public|BlueprintCallable) // @ game+0x9c47fb0
	bool CollectionExists(struct FName Name); // Function AssetTags.AssetTagsSubsystem.CollectionExists // (Final|Native|Public|BlueprintCallable) // @ game+0x9c48160
};

