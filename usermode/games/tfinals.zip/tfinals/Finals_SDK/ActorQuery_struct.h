// ScriptStruct ActorQuery.ActorQueryClassId
// Size: 0x04 (Inherited: 0x00)
struct FActorQueryClassId {
	uint32_t Value; // 0x00(0x04)
};

// ScriptStruct ActorQuery.ActorQueryClassRegistry
// Size: 0xc0 (Inherited: 0x00)
struct FActorQueryClassRegistry {
	char pad_0[0x8]; // 0x00(0x08)
	struct TArray<struct UObject*> IdToClass; // 0x08(0x10)
	struct TSet<struct UObject*> RegisteredClasses; // 0x18(0x50)
	struct TMap<struct UObject*, struct FActorQueryClassId> ClassToId; // 0x68(0x50)
	struct UObject* BaseClass; // 0xb8(0x08)
};

// ScriptStruct ActorQuery.ActorQuerySignature
// Size: 0x40 (Inherited: 0x00)
struct FActorQuerySignature {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct ActorQuery.ActorView
// Size: 0x18 (Inherited: 0x00)
struct FActorView {
	struct AActor* Actor; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct ActorQuery.SignatureToActors
// Size: 0x50 (Inherited: 0x00)
struct FSignatureToActors {
	char pad_0[0x40]; // 0x00(0x40)
	struct TArray<struct TWeakObjectPtr<struct AActor>> Actors; // 0x40(0x10)
};

// ScriptStruct ActorQuery.ActorQueryHandle
// Size: 0x40 (Inherited: 0x00)
struct FActorQueryHandle {
	struct FActorQuerySignature Signature; // 0x00(0x40)
};

// ScriptStruct ActorQuery.ActorStorageLocation
// Size: 0x08 (Inherited: 0x00)
struct FActorStorageLocation {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct ActorQuery.ActorQueryStorage
// Size: 0x100 (Inherited: 0x00)
struct FActorQueryStorage {
	struct TSet<struct TWeakObjectPtr<struct AActor>> TrackedActors; // 0x00(0x50)
	struct TMap<struct TWeakObjectPtr<struct AActor>, struct FActorStorageLocation> ActorToStorageLocation; // 0x50(0x50)
	struct TArray<struct FSignatureToActors> SignatureToActors; // 0xa0(0x10)
	char pad_b0[0x50]; // 0xb0(0x50)
};

// ScriptStruct ActorQuery.ActorQueryView
// Size: 0xa0 (Inherited: 0x00)
struct FActorQueryView {
	char pad_0[0xa0]; // 0x00(0xa0)
};

// ScriptStruct ActorQuery.CachedActorQueryView
// Size: 0xa8 (Inherited: 0x00)
struct FCachedActorQueryView {
	char pad_0[0x8]; // 0x00(0x08)
	struct FActorQueryView View; // 0x08(0xa0)
};

// ScriptStruct ActorQuery.ComponentClassArray
// Size: 0x10 (Inherited: 0x00)
struct FComponentClassArray {
	struct TArray<struct UActorComponent*> ComponentClasses; // 0x00(0x10)
};

