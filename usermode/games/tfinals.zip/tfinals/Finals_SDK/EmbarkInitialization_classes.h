// Class EmbarkInitialization.EmbarkInitializationExtensionObject
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkInitializationExtensionObject : UObject {

	int32_t IsAdditionalInitializationDone(bool bIsBaseDone, struct FEmbarkInitializationContext& InContext); // Function EmbarkInitialization.EmbarkInitializationExtensionObject.IsAdditionalInitializationDone // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x683a910
};

// Class EmbarkInitialization.EmbarkInitializationSubsystem
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkInitializationSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TMap<struct FEmbarkInitializationRequestKey, struct FEmbarkInitializationRequestValueArrayWrapper> Requests; // 0xa8(0x50)
	struct TMap<struct FEmbarkInitializationRequestKey, struct FEmbarkInitializationRequestValueArrayWrapper> PendingReplayRequests; // 0xf8(0x50)
	char pad_148[0x10]; // 0x148(0x10)
	struct FSoftClassPath InitializationClass; // 0x158(0x20)
	struct UEmbarkInitializationExtensionObject* InitializationExtensionObjectCDO; // 0x178(0x08)

	void TickTest(struct UObject* InObjectContext, float InDeltaSeconds); // Function EmbarkInitialization.EmbarkInitializationSubsystem.TickTest // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6839ac0
	bool RequestInitCallbackScript(struct UObject* InObjectContext, struct FDelegate InDelegate, int32_t AdditionalInitializationRequested, enum class EEmbarkInitializationFlags InFlags, struct UEmbarkInitializationExtensionObject* InCustomExtensionObject); // Function EmbarkInitialization.EmbarkInitializationSubsystem.RequestInitCallbackScript // (Final|Native|Static|Public) // @ game+0x6839d50
	void OnPreloadMap(struct FURL& InNonUsedUrl); // Function EmbarkInitialization.EmbarkInitializationSubsystem.OnPreloadMap // (Final|Native|Protected|HasOutParms) // @ game+0x6839f80
	bool IsInitializationReadyWithContext(struct UObject* InObjectContext, int32_t AdditionalInitializationRequested, struct FEmbarkInitializationContext& OutContext, enum class EEmbarkInitializationFlags InFlags, struct UEmbarkInitializationExtensionObject* InCustomExtensionObject); // Function EmbarkInitialization.EmbarkInitializationSubsystem.IsInitializationReadyWithContext // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6834590
	bool IsInitializationReady(struct UObject* InObjectContext, int32_t AdditionalInitializationRequested, enum class EEmbarkInitializationFlags InFlags, struct UEmbarkInitializationExtensionObject* InCustomExtensionObject); // Function EmbarkInitialization.EmbarkInitializationSubsystem.IsInitializationReady // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6835a80
	struct UEmbarkInitializationSubsystem* Get(struct UObject* InObjectContext); // Function EmbarkInitialization.EmbarkInitializationSubsystem.Get // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x683a150
	struct FString DebugStateFromSubsystem(struct UObject* InObjectCtx); // Function EmbarkInitialization.EmbarkInitializationSubsystem.DebugStateFromSubsystem // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6838210
	struct FString DebugStateFromInitializationContext(struct FEmbarkInitializationContext& InContext); // Function EmbarkInitialization.EmbarkInitializationSubsystem.DebugStateFromInitializationContext // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6838bc0
};

// Class EmbarkInitialization.EmbarkInitializationSubsystemGameplayDebuggerPage
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkInitializationSubsystemGameplayDebuggerPage : UEmbarkGameplayDebuggerPage {
};

// Class EmbarkInitialization.EmbarkInitializationTestPlayerController
// Size: 0xf10 (Inherited: 0xf10)
struct AEmbarkInitializationTestPlayerController : APlayerController {
};

