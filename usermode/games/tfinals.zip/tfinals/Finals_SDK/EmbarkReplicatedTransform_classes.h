// Class EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UReplicatedTransformMixinLibrary : UObject {

	bool IsTransformDormant(struct FReplicatedTransform& Transform, bool bOnlyIfReplicated); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.IsTransformDormant // (Final|Native|Static|Public|HasOutParms) // @ game+0x58ffab0
	bool IsLinearVelocityDormant(struct FReplicatedTransform& Transform); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.IsLinearVelocityDormant // (Final|Native|Static|Public|HasOutParms) // @ game+0x5900210
	bool IsAngularVelocityDormant(struct FReplicatedTransform& Transform); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.IsAngularVelocityDormant // (Final|Native|Static|Public|HasOutParms) // @ game+0x5901020
	bool HasTeleported(struct FReplicatedTransform& Transform); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.HasTeleported // (Final|Native|Static|Public|HasOutParms) // @ game+0x58fd900
	void FillFromRigidBodyState(struct FReplicatedTransform& Transform, struct FRigidBodyState& RBState); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.FillFromRigidBodyState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5900aa0
	void FillFromActor(struct FReplicatedTransform& Transform, struct AActor* Actor, struct FVector& SetAngularVelocity, bool bSetTeleported); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.FillFromActor // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5900ce0
	void CopyToRigidBodyState(struct FReplicatedTransform& Transform, struct FRigidBodyState& OutRBState); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.CopyToRigidBodyState // (Final|Native|Static|Public|HasOutParms) // @ game+0x58fd1c0
	void CopyToActor(struct FReplicatedTransform& Transform, struct AActor* Actor, struct FVector& OutAngularVelocity); // Function EmbarkReplicatedTransform.ReplicatedTransformMixinLibrary.CopyToActor // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58fd3d0
};

