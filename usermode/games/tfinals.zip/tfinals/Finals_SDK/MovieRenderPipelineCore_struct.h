// Enum MovieRenderPipelineCore.EMovieGraphValueType
enum class EMovieGraphValueType : uint8_t {
	None = 0,
	Bool = 1,
	Byte = 2,
	Int32 = 3,
	Int64 = 4,
	Float = 5,
	Double = 6,
	Name = 7,
	String = 8,
	Text = 9,
	Enum = 10,
	Struct = 11,
	Object = 12,
	SoftObject = 13,
	Class = 14,
	SoftClass = 15,
	Count = 16,
	EMovieGraphValueType_MAX = 17
};

// Enum MovieRenderPipelineCore.EMovieGraphContainerType
enum class EMovieGraphContainerType : uint8_t {
	None = 0,
	Array = 1,
	Count = 2,
	EMovieGraphContainerType_MAX = 3
};

// Enum MovieRenderPipelineCore.EMoviePipelineCollectionCommonQueryMode
enum class EMoviePipelineCollectionCommonQueryMode : uint8_t {
	And = 0,
	Or = 1,
	EMoviePipelineCollectionCommonQueryMode_MAX = 2
};

// Enum MovieRenderPipelineCore.EMoviePipelineEncodeQuality
enum class EMoviePipelineEncodeQuality : uint8_t {
	Low = 0,
	Medium = 1,
	High = 2,
	Epic = 3,
	EMoviePipelineEncodeQuality_MAX = 4
};

// Enum MovieRenderPipelineCore.FCPXMLExportDataSource
enum class FCPXMLExportDataSource : uint8_t {
	OutputMetadata = 0,
	SequenceData = 1,
	FCPXMLExportDataSource_MAX = 2
};

// Enum MovieRenderPipelineCore.EMoviePipelineTextureStreamingMethod
enum class EMoviePipelineTextureStreamingMethod : uint8_t {
	None = 0,
	Disabled = 1,
	FullyLoad = 2,
	EMoviePipelineTextureStreamingMethod_MAX = 3
};

// Enum MovieRenderPipelineCore.EMovieRenderPipelineState
enum class EMovieRenderPipelineState : uint8_t {
	Uninitialized = 0,
	ProducingFrames = 1,
	Finalize = 2,
	Export = 3,
	Finished = 4,
	EMovieRenderPipelineState_MAX = 5
};

// Enum MovieRenderPipelineCore.EMovieRenderShotState
enum class EMovieRenderShotState : uint8_t {
	Uninitialized = 0,
	WarmingUp = 1,
	MotionBlur = 2,
	Rendering = 3,
	Finished = 4,
	EMovieRenderShotState_MAX = 5
};

// Enum MovieRenderPipelineCore.EMoviePipelineShutterTiming
enum class EMoviePipelineShutterTiming : uint8_t {
	FrameOpen = 0,
	FrameCenter = 1,
	FrameClose = 2,
	EMoviePipelineShutterTiming_MAX = 3
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineOutputData
// Size: 0x28 (Inherited: 0x00)
struct FMoviePipelineOutputData {
	struct UMoviePipeline* Pipeline; // 0x00(0x08)
	struct UMoviePipelineExecutorJob* Job; // 0x08(0x08)
	bool bSuccess; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TArray<struct FMoviePipelineShotOutputData> ShotData; // 0x18(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineShotOutputData
// Size: 0x58 (Inherited: 0x00)
struct FMoviePipelineShotOutputData {
	struct TWeakObjectPtr<struct UMoviePipelineExecutorShot> Shot; // 0x00(0x08)
	struct TMap<struct FMoviePipelinePassIdentifier, struct FMoviePipelineRenderPassOutputData> RenderPassData; // 0x08(0x50)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelinePassIdentifier
// Size: 0x20 (Inherited: 0x00)
struct FMoviePipelinePassIdentifier {
	struct FString Name; // 0x00(0x10)
	struct FString CameraName; // 0x10(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineRenderPassOutputData
// Size: 0x10 (Inherited: 0x00)
struct FMoviePipelineRenderPassOutputData {
	struct TArray<struct FString> FilePaths; // 0x00(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphEvaluatedSettingsStack
// Size: 0x10 (Inherited: 0x00)
struct FMovieGraphEvaluatedSettingsStack {
	struct TArray<struct UMovieGraphNode*> NodeInstances; // 0x00(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphEvaluatedBranchConfig
// Size: 0x50 (Inherited: 0x00)
struct FMovieGraphEvaluatedBranchConfig {
	struct TMap<struct FString, struct FMovieGraphEvaluatedSettingsStack> NamedNodes; // 0x00(0x50)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphEvaluationContext
// Size: 0xe0 (Inherited: 0x00)
struct FMovieGraphEvaluationContext {
	struct FMovieGraphTraversalContext UserContext; // 0x00(0x78)
	struct TSet<struct UMovieGraphNode*> VisitedNodes; // 0x78(0x50)
	struct UMovieGraphPin* PinBeingFollowed; // 0xc8(0x08)
	struct TArray<struct UMovieGraphSubgraphNode*> SubgraphStack; // 0xd0(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphTraversalContext
// Size: 0x78 (Inherited: 0x00)
struct FMovieGraphTraversalContext {
	struct FName RootBranch; // 0x00(0x08)
	int32_t ShotIndex; // 0x08(0x04)
	int32_t ShotCount; // 0x0c(0x04)
	struct UMoviePipelineExecutorJob* Job; // 0x10(0x08)
	struct UMovieGraphConfig* RootGraph; // 0x18(0x08)
	struct FMovieGraphRenderDataIdentifier RenderDataIdentifier; // 0x20(0x38)
	struct FMovieGraphTimeStepData Time; // 0x58(0x20)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphTimeStepData
// Size: 0x20 (Inherited: 0x00)
struct FMovieGraphTimeStepData {
	int32_t OutputFrameNumber; // 0x00(0x04)
	float FrameDeltaTime; // 0x04(0x04)
	float WorldTimeDilation; // 0x08(0x04)
	float WorldSeconds; // 0x0c(0x04)
	float MotionBlurFraction; // 0x10(0x04)
	bool bIsFirstTemporalSampleForFrame; // 0x14(0x01)
	bool bIsLastTemporalSampleForFrame; // 0x15(0x01)
	bool bRequiresAccumulator; // 0x16(0x01)
	char pad_17[0x1]; // 0x17(0x01)
	struct UMovieGraphEvaluatedConfig* EvaluatedConfig; // 0x18(0x08)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphRenderDataIdentifier
// Size: 0x38 (Inherited: 0x00)
struct FMovieGraphRenderDataIdentifier {
	struct FName RootBranchName; // 0x00(0x08)
	struct FString RendererName; // 0x08(0x10)
	struct FString SubResourceName; // 0x18(0x10)
	struct FString CameraName; // 0x28(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphInitConfig
// Size: 0x20 (Inherited: 0x00)
struct FMovieGraphInitConfig {
	struct UMovieGraphTimeStepBase* TimeStepClass; // 0x00(0x08)
	struct UMovieGraphRendererBase* RendererClass; // 0x08(0x08)
	struct UMovieGraphDataSourceBase* DataSourceClass; // 0x10(0x08)
	bool bRenderViewport; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphRenderPassOutputData
// Size: 0x10 (Inherited: 0x00)
struct FMovieGraphRenderPassOutputData {
	struct TArray<struct FString> FilePaths; // 0x00(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphRenderOutputData
// Size: 0x58 (Inherited: 0x00)
struct FMovieGraphRenderOutputData {
	struct TWeakObjectPtr<struct UMoviePipelineExecutorShot> Shot; // 0x00(0x08)
	struct TMap<struct FMovieGraphRenderDataIdentifier, struct FMovieGraphRenderPassOutputData> RenderPassData; // 0x08(0x50)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphResolveArgs
// Size: 0xa0 (Inherited: 0x00)
struct FMovieGraphResolveArgs {
	struct TMap<struct FString, struct FString> FilenameArguments; // 0x00(0x50)
	struct TMap<struct FString, struct FString> FileMetadata; // 0x50(0x50)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphFilenameResolveParams
// Size: 0x128 (Inherited: 0x00)
struct FMovieGraphFilenameResolveParams {
	struct FMovieGraphRenderDataIdentifier RenderDataIdentifier; // 0x00(0x38)
	int32_t RootFrameNumber; // 0x38(0x04)
	int32_t ShotFrameNumber; // 0x3c(0x04)
	int32_t RootFrameNumberRel; // 0x40(0x04)
	int32_t ShotFrameNumberRel; // 0x44(0x04)
	struct TMap<struct FString, struct FString> FileMetadata; // 0x48(0x50)
	int32_t Version; // 0x98(0x04)
	bool bForceRelativeFrameNumbers; // 0x9c(0x01)
	bool bEnsureAbsolutePath; // 0x9d(0x01)
	char pad_9e[0x2]; // 0x9e(0x02)
	struct FDateTime InitializationTime; // 0xa0(0x08)
	int32_t ZeroPadFrameNumberCount; // 0xa8(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
	struct TMap<struct FString, struct FString> FileNameFormatOverrides; // 0xb0(0x50)
	struct UMoviePipelineExecutorJob* Job; // 0x100(0x08)
	struct UMoviePipelineExecutorShot* Shot; // 0x108(0x08)
	struct UMovieGraphEvaluatedConfig* EvaluatedConfig; // 0x110(0x08)
	int32_t FrameNumberOffset; // 0x118(0x04)
	struct FFrameRate DefaultFrameRate; // 0x11c(0x08)
	char pad_124[0x4]; // 0x124(0x04)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphPropertyInfo
// Size: 0x0c (Inherited: 0x00)
struct FMovieGraphPropertyInfo {
	struct FName Name; // 0x00(0x08)
	bool bIsDynamicProperty; // 0x08(0x01)
	enum class EMovieGraphValueType ValueType; // 0x09(0x01)
	char pad_a[0x2]; // 0x0a(0x02)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphPinProperties
// Size: 0x0c (Inherited: 0x00)
struct FMovieGraphPinProperties {
	struct FName Label; // 0x00(0x08)
	enum class EMovieGraphValueType Type; // 0x08(0x01)
	bool bAllowMultipleConnections; // 0x09(0x01)
	bool bIsBranch; // 0x0a(0x01)
	char pad_b[0x1]; // 0x0b(0x01)
};

// ScriptStruct MovieRenderPipelineCore.MovieGraphBranch
// Size: 0x08 (Inherited: 0x00)
struct FMovieGraphBranch {
	struct FName BranchName; // 0x00(0x08)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineSidecarCamera
// Size: 0x28 (Inherited: 0x00)
struct FMoviePipelineSidecarCamera {
	struct FGuid BindingID; // 0x00(0x10)
	char pad_10[0x8]; // 0x10(0x08)
	struct FString Name; // 0x18(0x10)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineSegmentWorkMetrics
// Size: 0x28 (Inherited: 0x00)
struct FMoviePipelineSegmentWorkMetrics {
	struct FString SegmentName; // 0x00(0x10)
	int32_t OutputFrameIndex; // 0x10(0x04)
	int32_t TotalOutputFrameCount; // 0x14(0x04)
	int32_t OutputSubSampleIndex; // 0x18(0x04)
	int32_t TotalSubSampleCount; // 0x1c(0x04)
	int32_t EngineWarmUpFrameIndex; // 0x20(0x04)
	int32_t TotalEngineWarmUpFrameCount; // 0x24(0x04)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineCameraCutInfo
// Size: 0xb0 (Inherited: 0x00)
struct FMoviePipelineCameraCutInfo {
	char pad_0[0xb0]; // 0x00(0xb0)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineFormatArgs
// Size: 0xa8 (Inherited: 0x00)
struct FMoviePipelineFormatArgs {
	struct TMap<struct FString, struct FString> FilenameArguments; // 0x00(0x50)
	struct TMap<struct FString, struct FString> FileMetadata; // 0x50(0x50)
	struct UMoviePipelineExecutorJob* InJob; // 0xa0(0x08)
};

// ScriptStruct MovieRenderPipelineCore.MoviePipelineFilenameResolveParams
// Size: 0x118 (Inherited: 0x00)
struct FMoviePipelineFilenameResolveParams {
	int32_t FrameNumber; // 0x00(0x04)
	int32_t FrameNumberShot; // 0x04(0x04)
	int32_t FrameNumberRel; // 0x08(0x04)
	int32_t FrameNumberShotRel; // 0x0c(0x04)
	struct FString CameraNameOverride; // 0x10(0x10)
	struct FString ShotNameOverride; // 0x20(0x10)
	int32_t ZeroPadFrameNumberCount; // 0x30(0x04)
	bool bForceRelativeFrameNumbers; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FString FileNameOverride; // 0x38(0x10)
	struct TMap<struct FString, struct FString> FileNameFormatOverrides; // 0x48(0x50)
	struct TMap<struct FString, struct FString> FileMetadata; // 0x98(0x50)
	struct FDateTime InitializationTime; // 0xe8(0x08)
	int32_t InitializationVersion; // 0xf0(0x04)
	char pad_f4[0x4]; // 0xf4(0x04)
	struct UMoviePipelineExecutorJob* Job; // 0xf8(0x08)
	char pad_100[0x8]; // 0x100(0x08)
	struct UMoviePipelineExecutorShot* ShotOverride; // 0x108(0x08)
	int32_t AdditionalFrameNumberOffset; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
};

