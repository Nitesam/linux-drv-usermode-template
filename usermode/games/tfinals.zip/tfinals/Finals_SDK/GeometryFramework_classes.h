// Class GeometryFramework.MeshCommandChangeTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshCommandChangeTarget : UInterface {
};

// Class GeometryFramework.MeshReplacementCommandChangeTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshReplacementCommandChangeTarget : UInterface {
};

// Class GeometryFramework.MeshVertexCommandChangeTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshVertexCommandChangeTarget : UInterface {
};

// Class GeometryFramework.BaseDynamicMeshComponent
// Size: 0x760 (Inherited: 0x6f0)
struct UBaseDynamicMeshComponent : UMeshComponent {
	char pad_6f0[0x20]; // 0x6f0(0x20)
	bool bExplicitShowWireframe; // 0x710(0x01)
	char pad_711[0x3]; // 0x711(0x03)
	struct FLinearColor WireframeColor; // 0x714(0x10)
	enum class EDynamicMeshComponentColorOverrideMode ColorMode; // 0x724(0x01)
	char pad_725[0x3]; // 0x725(0x03)
	struct FColor ConstantColor; // 0x728(0x04)
	enum class EDynamicMeshVertexColorTransformMode ColorSpaceMode; // 0x72c(0x01)
	bool bEnableFlatShading; // 0x72d(0x01)
	bool bEnableViewModeOverrides; // 0x72e(0x01)
	char pad_72f[0x1]; // 0x72f(0x01)
	struct UMaterialInterface* OverrideRenderMaterial; // 0x730(0x08)
	struct UMaterialInterface* SecondaryRenderMaterial; // 0x738(0x08)
	char pad_740[0x1]; // 0x740(0x01)
	bool bEnableRayTracing; // 0x741(0x01)
	char pad_742[0x6]; // 0x742(0x06)
	struct TArray<struct UMaterialInterface*> BaseMaterials; // 0x748(0x10)
	char pad_758[0x8]; // 0x758(0x08)

	void SetViewModeOverridesEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetViewModeOverridesEnabled // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x36e2920
	void SetVertexColorSpaceTransformMode(enum class EDynamicMeshVertexColorTransformMode NewMode); // Function GeometryFramework.BaseDynamicMeshComponent.SetVertexColorSpaceTransformMode // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x942e5d0
	void SetShadowsEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetShadowsEnabled // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94168e0
	void SetSecondaryRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94252a0
	void SetSecondaryBuffersVisibility(bool bSetVisible); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryBuffersVisibility // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9415430
	void SetOverrideRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetOverrideRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x942a670
	void SetEnableWireframeRenderPass(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableWireframeRenderPass // (Native|Public|BlueprintCallable) // @ game+0x94233b0
	void SetEnableRaytracing(bool bSetEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableRaytracing // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x942e2c0
	void SetEnableFlatShading(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableFlatShading // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9419120
	void SetConstantOverrideColor(struct FColor NewColor); // Function GeometryFramework.BaseDynamicMeshComponent.SetConstantOverrideColor // (RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x94286c0
	void SetColorOverrideMode(enum class EDynamicMeshComponentColorOverrideMode NewMode); // Function GeometryFramework.BaseDynamicMeshComponent.SetColorOverrideMode // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x940e310
	bool HasOverrideRenderMaterial(int32_t K); // Function GeometryFramework.BaseDynamicMeshComponent.HasOverrideRenderMaterial // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9420b10
	bool GetViewModeOverridesEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetViewModeOverridesEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x940d190
	enum class EDynamicMeshVertexColorTransformMode GetVertexColorSpaceTransformMode(); // Function GeometryFramework.BaseDynamicMeshComponent.GetVertexColorSpaceTransformMode // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x940f120
	bool GetShadowsEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetShadowsEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9429850
	struct UMaterialInterface* GetSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryRenderMaterial // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9410e80
	bool GetSecondaryBuffersVisibility(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryBuffersVisibility // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9428620
	struct UMaterialInterface* GetOverrideRenderMaterial(int32_t MaterialIndex); // Function GeometryFramework.BaseDynamicMeshComponent.GetOverrideRenderMaterial // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x942df50
	bool GetFlatShadingEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetFlatShadingEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94153b0
	bool GetEnableWireframeRenderPass(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableWireframeRenderPass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x940b030
	bool GetEnableRaytracing(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableRaytracing // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x94198f0
	struct UDynamicMesh* GetDynamicMesh(); // Function GeometryFramework.BaseDynamicMeshComponent.GetDynamicMesh // (Native|Public|BlueprintCallable) // @ game+0x940b1c0
	struct FColor GetConstantOverrideColor(); // Function GeometryFramework.BaseDynamicMeshComponent.GetConstantOverrideColor // (Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x940e200
	enum class EDynamicMeshComponentColorOverrideMode GetColorOverrideMode(); // Function GeometryFramework.BaseDynamicMeshComponent.GetColorOverrideMode // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9423040
	void ClearSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearSecondaryRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x942b330
	void ClearOverrideRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearOverrideRenderMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9421db0
};

// Class GeometryFramework.DynamicMeshComponent
// Size: 0x9c0 (Inherited: 0x760)
struct UDynamicMeshComponent : UBaseDynamicMeshComponent {
	struct UDynamicMesh* MeshObject; // 0x760(0x08)
	char pad_768[0x138]; // 0x768(0x138)
	enum class EDynamicMeshComponentTangentsMode TangentsType; // 0x8a0(0x01)
	char pad_8a1[0x3f]; // 0x8a1(0x3f)
	enum class ECollisionTraceFlag CollisionType; // 0x8e0(0x01)
	bool bUseAsyncCooking; // 0x8e1(0x01)
	bool bEnableComplexCollision; // 0x8e2(0x01)
	bool bDeferCollisionUpdates; // 0x8e3(0x01)
	char pad_8e4[0x4]; // 0x8e4(0x04)
	struct UBodySetup* MeshBodySetup; // 0x8e8(0x08)
	char pad_8f0[0x38]; // 0x8f0(0x38)
	struct FKAggregateGeom AggGeom; // 0x928(0x78)
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue; // 0x9a0(0x10)
	char pad_9b0[0x10]; // 0x9b0(0x10)

	bool ValidateMaterialSlots(bool bCreateIfMissing, bool bDeleteExtraSlots); // Function GeometryFramework.DynamicMeshComponent.ValidateMaterialSlots // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x941e8b0
	void UpdateCollision(bool bOnlyIfPending); // Function GeometryFramework.DynamicMeshComponent.UpdateCollision // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9428380
	void SetTangentsType(enum class EDynamicMeshComponentTangentsMode NewTangentsType); // Function GeometryFramework.DynamicMeshComponent.SetTangentsType // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x940f4c0
	void SetDynamicMesh(struct UDynamicMesh* NewMesh); // Function GeometryFramework.DynamicMeshComponent.SetDynamicMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x941e9c0
	void SetDeferredCollisionUpdatesEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetDeferredCollisionUpdatesEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x942f0c0
	void SetComplexAsSimpleCollisionEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetComplexAsSimpleCollisionEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94134a0
	void NotifyMeshVertexAttributesModified(bool bPositions, bool bNormals, bool bUVs, bool bColors); // Function GeometryFramework.DynamicMeshComponent.NotifyMeshVertexAttributesModified // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x940e4a0
	void NotifyMeshModified(); // Function GeometryFramework.DynamicMeshComponent.NotifyMeshModified // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94282b0
	enum class EDynamicMeshComponentTangentsMode GetTangentsTypePure(); // Function GeometryFramework.DynamicMeshComponent.GetTangentsTypePure // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x940ec30
	enum class EDynamicMeshComponentTangentsMode GetTangentsType(); // Function GeometryFramework.DynamicMeshComponent.GetTangentsType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x940ec30
	void EnableComplexAsSimpleCollision(); // Function GeometryFramework.DynamicMeshComponent.EnableComplexAsSimpleCollision // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9422170
	void ConfigureMaterialSet(struct TArray<struct UMaterialInterface*>& NewMaterialSet); // Function GeometryFramework.DynamicMeshComponent.ConfigureMaterialSet // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9414b30
};

// Class GeometryFramework.DynamicMeshActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ADynamicMeshActor : AActor {
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0x398(0x08)
	bool bEnableComputeMeshPool; // 0x3a0(0x01)
	struct UDynamicMeshPool* DynamicMeshPool; // 0x3a8(0x08)

	bool ReleaseComputeMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshActor.ReleaseComputeMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x942eec0
	void ReleaseAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.ReleaseAllComputeMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94243c0
	struct UDynamicMeshComponent* GetDynamicMeshComponent(); // Function GeometryFramework.DynamicMeshActor.GetDynamicMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33032c0
	struct UDynamicMeshPool* GetComputeMeshPool(); // Function GeometryFramework.DynamicMeshActor.GetComputeMeshPool // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x940e3b0
	void FreeAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.FreeAllComputeMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x941c670
	struct UDynamicMesh* AllocateComputeMesh(); // Function GeometryFramework.DynamicMeshActor.AllocateComputeMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9411ef0
};

// Class GeometryFramework.DynamicMeshGenerator
// Size: 0xa0 (Inherited: 0xa0)
struct UDynamicMeshGenerator : UObject {
};

// Class GeometryFramework.DynamicMesh
// Size: 0x120 (Inherited: 0xa0)
struct UDynamicMesh : UObject {
	char pad_a0[0x40]; // 0xa0(0x40)
	struct FMulticastInlineDelegate MeshModifiedBPEvent; // 0xe0(0x10)
	char pad_f0[0x20]; // 0xf0(0x20)
	struct UDynamicMeshGenerator* MeshGenerator; // 0x110(0x08)
	bool bEnableMeshGenerator; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)

	struct UDynamicMesh* ResetToCube(); // Function GeometryFramework.DynamicMesh.ResetToCube // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9429370
	struct UDynamicMesh* Reset(); // Function GeometryFramework.DynamicMesh.Reset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94191d0
	bool IsEmpty(); // Function GeometryFramework.DynamicMesh.IsEmpty // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9415400
	int32_t GetTriangleCount(); // Function GeometryFramework.DynamicMesh.GetTriangleCount // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x940cb40
};

// Class GeometryFramework.DynamicMeshPool
// Size: 0xc0 (Inherited: 0xa0)
struct UDynamicMeshPool : UObject {
	struct TArray<struct UDynamicMesh*> CachedMeshes; // 0x98(0x10)
	struct TArray<struct UDynamicMesh*> AllCreatedMeshes; // 0xa8(0x10)

	void ReturnMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshPool.ReturnMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9412f20
	void ReturnAllMeshes(); // Function GeometryFramework.DynamicMeshPool.ReturnAllMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x94153e0
	struct UDynamicMesh* RequestMesh(); // Function GeometryFramework.DynamicMeshPool.RequestMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9429880
	void FreeAllMeshes(); // Function GeometryFramework.DynamicMeshPool.FreeAllMeshes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9423330
};

