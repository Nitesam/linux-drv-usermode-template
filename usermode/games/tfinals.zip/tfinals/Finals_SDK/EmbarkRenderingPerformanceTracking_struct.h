// Enum EmbarkRenderingPerformanceTracking.ERenderThreadFrameBudget
enum class ERenderThreadFrameBudget : uint8_t {
	UpdatePrimitiveSceneInfo = 0,
	ComputeViewVisibility = 1,
	InitDynamicShadows = 2,
	ExecutePasses = 3,
	UpdateDeferredCachedUniformExpressions = 4,
	GatherRayTracingRelevantPrimitives = 5,
	GatherRayTracingWorldInstances = 6,
	WaitForRayTracingScene = 7,
	SlateRenderThread = 8,
	DrawSceneCommand = 9,
	PrepareDistanceFieldScene = 10,
	DeferredShadingSceneRenderer = 11,
	InitViews = 12,
	GatherDynamicMeshElements = 13,
	DispatchRayTracingWorldUpdates = 14,
	RenderLighting = 15,
	NiagaraGpuComputeDispatch = 16,
	Count = 17,
	ERenderThreadFrameBudget_MAX = 18
};

// Enum EmbarkRenderingPerformanceTracking.EGPUFrameBudget
enum class EGPUFrameBudget : uint8_t {
	BasePass = 0,
	ShadowDepth = 1,
	DistanceFieldShadows = 2,
	RenderVelocities = 3,
	RTXGIUpdate = 4,
	Lights = 5,
	ScreenSpaceReflections = 6,
	ReflectionEnvironment = 7,
	Translucency = 8,
	PostProcessing = 9,
	Count = 10,
	EGPUFrameBudget_MAX = 11
};

