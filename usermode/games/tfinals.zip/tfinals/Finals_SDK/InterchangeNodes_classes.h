// Class InterchangeNodes.InterchangeAnimationTrackSetNode
// Size: 0x100 (Inherited: 0xd0)
struct UInterchangeAnimationTrackSetNode : UInterchangeBaseNode {
	char pad_d0[0x30]; // 0xd0(0x30)

	bool SetCustomFrameRate(float& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.SetCustomFrameRate // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991cfb0
	bool RemoveCustomAnimationTrackUid(struct FString AnimationTrackUid); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.RemoveCustomAnimationTrackUid // (Final|Native|Public|BlueprintCallable) // @ game+0x9915b50
	bool GetCustomFrameRate(float& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.GetCustomFrameRate // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9918e30
	void GetCustomAnimationTrackUids(struct TArray<struct FString>& OutAnimationTrackUids); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.GetCustomAnimationTrackUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991c2a0
	int32_t GetCustomAnimationTrackUidCount(); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.GetCustomAnimationTrackUidCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9918270
	void GetCustomAnimationTrackUid(int32_t Index, struct FString& OutAnimationTrackUid); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.GetCustomAnimationTrackUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9916270
	bool AddCustomAnimationTrackUid(struct FString AnimationTrackUid); // Function InterchangeNodes.InterchangeAnimationTrackSetNode.AddCustomAnimationTrackUid // (Final|Native|Public|BlueprintCallable) // @ game+0x991a3f0
};

// Class InterchangeNodes.InterchangeAnimationTrackBaseNode
// Size: 0xe0 (Inherited: 0xd0)
struct UInterchangeAnimationTrackBaseNode : UInterchangeBaseNode {
	char pad_d0[0x10]; // 0xd0(0x10)

	bool SetCustomCompletionMode(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackBaseNode.SetCustomCompletionMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9918950
	bool GetCustomCompletionMode(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackBaseNode.GetCustomCompletionMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9916b30
};

// Class InterchangeNodes.InterchangeAnimationTrackSetInstanceNode
// Size: 0x120 (Inherited: 0xe0)
struct UInterchangeAnimationTrackSetInstanceNode : UInterchangeAnimationTrackBaseNode {
	char pad_e0[0x40]; // 0xe0(0x40)

	bool SetCustomTrackSetDependencyUid(struct FString AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.SetCustomTrackSetDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x99195a0
	bool SetCustomTimeScale(float& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.SetCustomTimeScale // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9917dd0
	bool SetCustomStartFrame(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.SetCustomStartFrame // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991b3d0
	bool SetCustomDuration(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.SetCustomDuration // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9919300
	bool GetCustomTrackSetDependencyUid(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.GetCustomTrackSetDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99185b0
	bool GetCustomTimeScale(float& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.GetCustomTimeScale // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9915ff0
	bool GetCustomStartFrame(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.GetCustomStartFrame // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9914d90
	bool GetCustomDuration(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackSetInstanceNode.GetCustomDuration // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991b830
};

// Class InterchangeNodes.InterchangeAnimationTrackNode
// Size: 0x130 (Inherited: 0xe0)
struct UInterchangeAnimationTrackNode : UInterchangeAnimationTrackBaseNode {
	char pad_e0[0x50]; // 0xe0(0x50)

	bool SetCustomTargetedProperty(int32_t& TargetedProperty); // Function InterchangeNodes.InterchangeAnimationTrackNode.SetCustomTargetedProperty // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99172e0
	bool SetCustomFrameCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackNode.SetCustomFrameCount // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99175f0
	bool SetCustomAnimationPayloadKey(struct FString InUniqueId, enum class EInterchangeAnimationPayLoadType& InType); // Function InterchangeNodes.InterchangeAnimationTrackNode.SetCustomAnimationPayloadKey // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991b4c0
	bool SetCustomActorDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeAnimationTrackNode.SetCustomActorDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x99142d0
	bool GetCustomTargetedProperty(int32_t& TargetedProperty); // Function InterchangeNodes.InterchangeAnimationTrackNode.GetCustomTargetedProperty // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991ee80
	bool GetCustomFrameCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeAnimationTrackNode.GetCustomFrameCount // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99145d0
	bool GetCustomAnimationPayloadKey(struct FInterchangeAnimationPayLoadKey& AnimationPayLoadKey); // Function InterchangeNodes.InterchangeAnimationTrackNode.GetCustomAnimationPayloadKey // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991b650
	bool GetCustomActorDependencyUid(struct FString& DependencyUid); // Function InterchangeNodes.InterchangeAnimationTrackNode.GetCustomActorDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991d950
};

// Class InterchangeNodes.InterchangeTransformAnimationTrackNode
// Size: 0x140 (Inherited: 0x130)
struct UInterchangeTransformAnimationTrackNode : UInterchangeAnimationTrackNode {
	char pad_130[0x10]; // 0x130(0x10)

	bool SetCustomUsedChannels(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeTransformAnimationTrackNode.SetCustomUsedChannels // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9918b80
	bool GetCustomUsedChannels(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeTransformAnimationTrackNode.GetCustomUsedChannels // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9914ce0
};

// Class InterchangeNodes.InterchangeSkeletalAnimationTrackNode
// Size: 0x300 (Inherited: 0xe0)
struct UInterchangeSkeletalAnimationTrackNode : UInterchangeAnimationTrackBaseNode {
	char pad_e0[0x220]; // 0xe0(0x220)

	bool SetCustomSkeletonNodeUid(struct FString AttributeValue); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.SetCustomSkeletonNodeUid // (Final|Native|Public|BlueprintCallable) // @ game+0x99140b0
	bool SetCustomAnimationStopTime(double& StopTime); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.SetCustomAnimationStopTime // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991abe0
	bool SetCustomAnimationStartTime(double& StartTime); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.SetCustomAnimationStartTime // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9914a30
	bool SetCustomAnimationSampleRate(double& SampleRate); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.SetCustomAnimationSampleRate // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9919240
	bool SetAnimationPayloadKeyForSceneNodeUid(struct FString SceneNodeUid, struct FString InUniqueId, enum class EInterchangeAnimationPayLoadType& InType); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.SetAnimationPayloadKeyForSceneNodeUid // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9917170
	bool SetAnimationPayloadKeyForMorphTargetNodeUid(struct FString MorphTargetNodeUid, struct FString InUniqueId, enum class EInterchangeAnimationPayLoadType& InType); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.SetAnimationPayloadKeyForMorphTargetNodeUid // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991aa70
	void GetSceneNodeAnimationPayloadKeys(struct TMap<struct FString, struct FString>& OutSceneNodeAnimationPayloadKeyUids, struct TMap<struct FString, char>& OutSceneNodeAnimationPayloadKeyTypes); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.GetSceneNodeAnimationPayloadKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9916ee0
	void GetMorphTargetNodeAnimationPayloadKeys(struct TMap<struct FString, struct FString>& OutMorphTargetNodeAnimationPayloadKeyUids, struct TMap<struct FString, char>& OutMorphTargetNodeAnimationPayloadKeyTypes); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.GetMorphTargetNodeAnimationPayloadKeys // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9916ce0
	bool GetCustomSkeletonNodeUid(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.GetCustomSkeletonNodeUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9916c20
	bool GetCustomAnimationStopTime(double& StopTime); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.GetCustomAnimationStopTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991e7d0
	bool GetCustomAnimationStartTime(double& StartTime); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.GetCustomAnimationStartTime // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991bf60
	bool GetCustomAnimationSampleRate(double& SampleRate); // Function InterchangeNodes.InterchangeSkeletalAnimationTrackNode.GetCustomAnimationSampleRate // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991d680
};

// Class InterchangeNodes.InterchangePhysicalCameraNode
// Size: 0x110 (Inherited: 0xd0)
struct UInterchangePhysicalCameraNode : UInterchangeBaseNode {
	char pad_d0[0x40]; // 0xd0(0x40)

	bool SetCustomSensorWidth(float& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.SetCustomSensorWidth // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99167a0
	bool SetCustomSensorHeight(float& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.SetCustomSensorHeight // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9918670
	bool SetCustomFocalLength(float& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.SetCustomFocalLength // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99196e0
	bool SetCustomEnableDepthOfField(bool& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.SetCustomEnableDepthOfField // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9916920
	bool GetCustomSensorWidth(float& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.GetCustomSensorWidth // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991ef70
	bool GetCustomSensorHeight(float& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.GetCustomSensorHeight // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9914170
	bool GetCustomFocalLength(float& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.GetCustomFocalLength // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9917390
	bool GetCustomEnableDepthOfField(bool& AttributeValue); // Function InterchangeNodes.InterchangePhysicalCameraNode.GetCustomEnableDepthOfField // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9918160
};

// Class InterchangeNodes.InterchangeStandardCameraNode
// Size: 0x130 (Inherited: 0xd0)
struct UInterchangeStandardCameraNode : UInterchangeBaseNode {
	char pad_d0[0x60]; // 0xd0(0x60)

	bool SetCustomWidth(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.SetCustomWidth // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991ddd0
	bool SetCustomProjectionMode(enum class EInterchangeCameraProjectionType& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.SetCustomProjectionMode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9918460
	bool SetCustomNearClipPlane(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.SetCustomNearClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99176a0
	bool SetCustomFieldOfView(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.SetCustomFieldOfView // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9915450
	bool SetCustomFarClipPlane(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.SetCustomFarClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991e590
	bool SetCustomAspectRatio(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.SetCustomAspectRatio // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x991e6b0
	bool GetCustomWidth(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.GetCustomWidth // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991def0
	bool GetCustomProjectionMode(enum class EInterchangeCameraProjectionType& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.GetCustomProjectionMode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991d740
	bool GetCustomNearClipPlane(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.GetCustomNearClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991c020
	bool GetCustomFieldOfView(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.GetCustomFieldOfView // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9917e80
	bool GetCustomFarClipPlane(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.GetCustomFarClipPlane // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9919e90
	bool GetCustomAspectRatio(float& AttributeValue); // Function InterchangeNodes.InterchangeStandardCameraNode.GetCustomAspectRatio // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991ace0
};

// Class InterchangeNodes.InterchangeBaseLightNode
// Size: 0x110 (Inherited: 0xd0)
struct UInterchangeBaseLightNode : UInterchangeBaseNode {
	char pad_d0[0x40]; // 0xd0(0x40)

	bool SetCustomUseTemperature(bool AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.SetCustomUseTemperature // (Final|Native|Public|BlueprintCallable) // @ game+0x9939260
	bool SetCustomTemperature(float AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.SetCustomTemperature // (Final|Native|Public|BlueprintCallable) // @ game+0x9932140
	bool SetCustomLightColor(struct FLinearColor& AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.SetCustomLightColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9921f00
	bool SetCustomIntensity(float AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.SetCustomIntensity // (Final|Native|Public|BlueprintCallable) // @ game+0x9928740
	bool GetCustomUseTemperature(bool& AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.GetCustomUseTemperature // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9929a30
	bool GetCustomTemperature(float& AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.GetCustomTemperature // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99340f0
	bool GetCustomLightColor(struct FLinearColor& AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.GetCustomLightColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x993e170
	bool GetCustomIntensity(float& AttributeValue); // Function InterchangeNodes.InterchangeBaseLightNode.GetCustomIntensity // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992d200
};

// Class InterchangeNodes.InterchangeLightNode
// Size: 0x140 (Inherited: 0x110)
struct UInterchangeLightNode : UInterchangeBaseLightNode {
	char pad_110[0x30]; // 0x110(0x30)

	bool SetCustomIntensityUnits(enum class EInterchangeLightUnits& AttributeValue); // Function InterchangeNodes.InterchangeLightNode.SetCustomIntensityUnits // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9934fa0
	bool SetCustomIESTexture(struct FString AttributeValue); // Function InterchangeNodes.InterchangeLightNode.SetCustomIESTexture // (Final|Native|Public|BlueprintCallable) // @ game+0x9936320
	bool SetCustomAttenuationRadius(float AttributeValue); // Function InterchangeNodes.InterchangeLightNode.SetCustomAttenuationRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x9924f20
	bool GetCustomIntensityUnits(enum class EInterchangeLightUnits& AttributeValue); // Function InterchangeNodes.InterchangeLightNode.GetCustomIntensityUnits // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99351e0
	bool GetCustomIESTexture(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeLightNode.GetCustomIESTexture // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992f1b0
	bool GetCustomAttenuationRadius(float& AttributeValue); // Function InterchangeNodes.InterchangeLightNode.GetCustomAttenuationRadius // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9938140
};

// Class InterchangeNodes.InterchangePointLightNode
// Size: 0x160 (Inherited: 0x140)
struct UInterchangePointLightNode : UInterchangeLightNode {
	char pad_140[0x20]; // 0x140(0x20)

	bool SetCustomUseInverseSquaredFalloff(bool AttributeValue); // Function InterchangeNodes.InterchangePointLightNode.SetCustomUseInverseSquaredFalloff // (Final|Native|Public|BlueprintCallable) // @ game+0x992e350
	bool SetCustomLightFalloffExponent(float AttributeValue); // Function InterchangeNodes.InterchangePointLightNode.SetCustomLightFalloffExponent // (Final|Native|Public|BlueprintCallable) // @ game+0x993c430
	bool GetCustomUseInverseSquaredFalloff(bool& AttributeValue); // Function InterchangeNodes.InterchangePointLightNode.GetCustomUseInverseSquaredFalloff // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9923110
	bool GetCustomLightFalloffExponent(float& AttributeValue); // Function InterchangeNodes.InterchangePointLightNode.GetCustomLightFalloffExponent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9922010
};

// Class InterchangeNodes.InterchangeSpotLightNode
// Size: 0x180 (Inherited: 0x160)
struct UInterchangeSpotLightNode : UInterchangePointLightNode {
	char pad_160[0x20]; // 0x160(0x20)

	bool SetCustomOuterConeAngle(float AttributeValue); // Function InterchangeNodes.InterchangeSpotLightNode.SetCustomOuterConeAngle // (Final|Native|Public|BlueprintCallable) // @ game+0x992ba30
	bool SetCustomInnerConeAngle(float AttributeValue); // Function InterchangeNodes.InterchangeSpotLightNode.SetCustomInnerConeAngle // (Final|Native|Public|BlueprintCallable) // @ game+0x9923620
	bool GetCustomOuterConeAngle(float& AttributeValue); // Function InterchangeNodes.InterchangeSpotLightNode.GetCustomOuterConeAngle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x993db50
	bool GetCustomInnerConeAngle(float& AttributeValue); // Function InterchangeNodes.InterchangeSpotLightNode.GetCustomInnerConeAngle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x993f0c0
};

// Class InterchangeNodes.InterchangeRectLightNode
// Size: 0x160 (Inherited: 0x140)
struct UInterchangeRectLightNode : UInterchangeLightNode {
	char pad_140[0x20]; // 0x140(0x20)

	bool SetCustomSourceWidth(float AttributeValue); // Function InterchangeNodes.InterchangeRectLightNode.SetCustomSourceWidth // (Final|Native|Public|BlueprintCallable) // @ game+0x9941e90
	bool SetCustomSourceHeight(float AttributeValue); // Function InterchangeNodes.InterchangeRectLightNode.SetCustomSourceHeight // (Final|Native|Public|BlueprintCallable) // @ game+0x993d250
	bool GetCustomSourceWidth(float& AttributeValue); // Function InterchangeNodes.InterchangeRectLightNode.GetCustomSourceWidth // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992e080
	bool GetCustomSourceHeight(float& AttributeValue); // Function InterchangeNodes.InterchangeRectLightNode.GetCustomSourceHeight // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9936580
};

// Class InterchangeNodes.InterchangeDirectionalLightNode
// Size: 0x110 (Inherited: 0x110)
struct UInterchangeDirectionalLightNode : UInterchangeBaseLightNode {
};

// Class InterchangeNodes.InterchangeTextureNode
// Size: 0x100 (Inherited: 0xd0)
struct UInterchangeTextureNode : UInterchangeBaseNode {
	char pad_d0[0x30]; // 0xd0(0x30)

	void SetPayLoadKey(struct FString PayloadKey); // Function InterchangeNodes.InterchangeTextureNode.SetPayLoadKey // (Native|Public|BlueprintCallable) // @ game+0x48ebd70
	bool SetCustomSRGB(bool& AttributeValue); // Function InterchangeNodes.InterchangeTextureNode.SetCustomSRGB // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x992ace0
	bool SetCustomFilter(enum class EInterchangeTextureFilterMode& AttributeValue); // Function InterchangeNodes.InterchangeTextureNode.SetCustomFilter // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9928230
	bool SetCustombFlipGreenChannel(bool& AttributeValue); // Function InterchangeNodes.InterchangeTextureNode.SetCustombFlipGreenChannel // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99221d0
	bool GetCustomSRGB(bool& AttributeValue); // Function InterchangeNodes.InterchangeTextureNode.GetCustomSRGB // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992a5a0
	bool GetCustomFilter(enum class EInterchangeTextureFilterMode& AttributeValue); // Function InterchangeNodes.InterchangeTextureNode.GetCustomFilter // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992ee00
	bool GetCustombFlipGreenChannel(bool& AttributeValue); // Function InterchangeNodes.InterchangeTextureNode.GetCustombFlipGreenChannel // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9929010
};

// Class InterchangeNodes.InterchangeTexture2DArrayNode
// Size: 0x100 (Inherited: 0x100)
struct UInterchangeTexture2DArrayNode : UInterchangeTextureNode {
};

// Class InterchangeNodes.InterchangeTextureCubeArrayNode
// Size: 0x100 (Inherited: 0x100)
struct UInterchangeTextureCubeArrayNode : UInterchangeTextureNode {
};

// Class InterchangeNodes.InterchangeTextureCubeNode
// Size: 0x100 (Inherited: 0x100)
struct UInterchangeTextureCubeNode : UInterchangeTextureNode {
};

// Class InterchangeNodes.InterchangeTextureLightProfileNode
// Size: 0x100 (Inherited: 0x100)
struct UInterchangeTextureLightProfileNode : UInterchangeTextureNode {
};

// Class InterchangeNodes.InterchangeVariantSetNode
// Size: 0x110 (Inherited: 0xd0)
struct UInterchangeVariantSetNode : UInterchangeBaseNode {
	char pad_d0[0x40]; // 0xd0(0x40)

	bool SetCustomVariantsPayloadKey(struct FString PayloadKey); // Function InterchangeNodes.InterchangeVariantSetNode.SetCustomVariantsPayloadKey // (Final|Native|Public|BlueprintCallable) // @ game+0x992c8b0
	bool SetCustomDisplayText(struct FString AttributeValue); // Function InterchangeNodes.InterchangeVariantSetNode.SetCustomDisplayText // (Final|Native|Public|BlueprintCallable) // @ game+0x993ef40
	bool RemoveCustomDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeVariantSetNode.RemoveCustomDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x993c950
	bool GetCustomVariantsPayloadKey(struct FString& PayloadKey); // Function InterchangeNodes.InterchangeVariantSetNode.GetCustomVariantsPayloadKey // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992c0d0
	bool GetCustomDisplayText(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeVariantSetNode.GetCustomDisplayText // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992ff70
	void GetCustomDependencyUids(struct TArray<struct FString>& OutDependencyUids); // Function InterchangeNodes.InterchangeVariantSetNode.GetCustomDependencyUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x993ee50
	int32_t GetCustomDependencyUidCount(); // Function InterchangeNodes.InterchangeVariantSetNode.GetCustomDependencyUidCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9930180
	void GetCustomDependencyUid(int32_t Index, struct FString& OutDependencyUid); // Function InterchangeNodes.InterchangeVariantSetNode.GetCustomDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9927680
	bool AddCustomDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeVariantSetNode.AddCustomDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x99301f0
};

// Class InterchangeNodes.InterchangeSceneVariantSetsNode
// Size: 0xf0 (Inherited: 0xd0)
struct UInterchangeSceneVariantSetsNode : UInterchangeBaseNode {
	char pad_d0[0x20]; // 0xd0(0x20)

	bool RemoveCustomVariantSetUid(struct FString VariantUid); // Function InterchangeNodes.InterchangeSceneVariantSetsNode.RemoveCustomVariantSetUid // (Final|Native|Public|BlueprintCallable) // @ game+0x991f380
	void GetCustomVariantSetUids(struct TArray<struct FString>& OutVariantUids); // Function InterchangeNodes.InterchangeSceneVariantSetsNode.GetCustomVariantSetUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9938f60
	int32_t GetCustomVariantSetUidCount(); // Function InterchangeNodes.InterchangeSceneVariantSetsNode.GetCustomVariantSetUidCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x992a900
	void GetCustomVariantSetUid(int32_t Index, struct FString& OutVariantUid); // Function InterchangeNodes.InterchangeSceneVariantSetsNode.GetCustomVariantSetUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9943580
	bool AddCustomVariantSetUid(struct FString VariantUid); // Function InterchangeNodes.InterchangeSceneVariantSetsNode.AddCustomVariantSetUid // (Final|Native|Public|BlueprintCallable) // @ game+0x9928060
};

// Class InterchangeNodes.InterchangeVolumeTextureNode
// Size: 0x100 (Inherited: 0x100)
struct UInterchangeVolumeTextureNode : UInterchangeTextureNode {
};

// Class InterchangeNodes.InterchangeMaterialInstanceNode
// Size: 0xe0 (Inherited: 0xd0)
struct UInterchangeMaterialInstanceNode : UInterchangeBaseNode {
	char pad_d0[0x10]; // 0xd0(0x10)

	bool SetCustomParent(struct FString AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.SetCustomParent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9930380
	bool GetVectorParameterValue(struct FString ParameterName, struct FLinearColor& AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.GetVectorParameterValue // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x992d460
	bool GetTextureParameterValue(struct FString ParameterName, struct FString& AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.GetTextureParameterValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9941ac0
	bool GetStaticSwitchParameterValue(struct FString ParameterName, bool& AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.GetStaticSwitchParameterValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992c5c0
	bool GetScalarParameterValue(struct FString ParameterName, float& AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.GetScalarParameterValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9943f20
	bool GetCustomParent(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.GetCustomParent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9941390
	bool AddVectorParameterValue(struct FString ParameterName, struct FLinearColor& AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.AddVectorParameterValue // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x99393b0
	bool AddTextureParameterValue(struct FString ParameterName, struct FString AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.AddTextureParameterValue // (Final|Native|Public|BlueprintCallable) // @ game+0x9931050
	bool AddStaticSwitchParameterValue(struct FString ParameterName, bool AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.AddStaticSwitchParameterValue // (Final|Native|Public|BlueprintCallable) // @ game+0x992a720
	bool AddScalarParameterValue(struct FString ParameterName, float AttributeValue); // Function InterchangeNodes.InterchangeMaterialInstanceNode.AddScalarParameterValue // (Final|Native|Public|BlueprintCallable) // @ game+0x9938840
};

// Class InterchangeNodes.InterchangeMeshNode
// Size: 0x260 (Inherited: 0xd0)
struct UInterchangeMeshNode : UInterchangeBaseNode {
	char pad_d0[0x190]; // 0xd0(0x190)

	bool SetSlotMaterialDependencyUid(struct FString SlotName, struct FString MaterialDependencyUid); // Function InterchangeNodes.InterchangeMeshNode.SetSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x9941210
	bool SetSkinnedMesh(bool bIsSkinnedMesh); // Function InterchangeNodes.InterchangeMeshNode.SetSkinnedMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x99325e0
	bool SetSkeletonDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeMeshNode.SetSkeletonDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x9938760
	bool SetSceneInstanceUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeMeshNode.SetSceneInstanceUid // (Final|Native|Public|BlueprintCallable) // @ game+0x99414f0
	void SetPayLoadKey(struct FString PayloadKey, enum class EInterchangeMeshPayLoadType& PayloadType); // Function InterchangeNodes.InterchangeMeshNode.SetPayLoadKey // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9935be0
	bool SetMorphTargetName(struct FString MorphTargetName); // Function InterchangeNodes.InterchangeMeshNode.SetMorphTargetName // (Final|Native|Public|BlueprintCallable) // @ game+0x9935cf0
	bool SetMorphTargetDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeMeshNode.SetMorphTargetDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x9926ec0
	bool SetMorphTarget(bool bIsMorphTarget); // Function InterchangeNodes.InterchangeMeshNode.SetMorphTarget // (Final|Native|Public|BlueprintCallable) // @ game+0x9941930
	bool SetCustomVertexCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomVertexCount // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x992a170
	bool SetCustomUVCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomUVCount // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x993fbd0
	bool SetCustomPolygonCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomPolygonCount // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x993cde0
	bool SetCustomHasVertexTangent(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomHasVertexTangent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x99432a0
	bool SetCustomHasVertexNormal(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomHasVertexNormal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9943af0
	bool SetCustomHasVertexColor(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomHasVertexColor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9939750
	bool SetCustomHasVertexBinormal(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomHasVertexBinormal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9929c20
	bool SetCustomHasSmoothGroup(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomHasSmoothGroup // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9928120
	bool SetCustomBoundingBox(struct FBox& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.SetCustomBoundingBox // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9923770
	bool RemoveSlotMaterialDependencyUid(struct FString SlotName); // Function InterchangeNodes.InterchangeMeshNode.RemoveSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x992e220
	bool RemoveSkeletonDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeMeshNode.RemoveSkeletonDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x992f090
	bool RemoveSceneInstanceUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeMeshNode.RemoveSceneInstanceUid // (Final|Native|Public|BlueprintCallable) // @ game+0x992fd30
	bool RemoveMorphTargetDependencyUid(struct FString DependencyUid); // Function InterchangeNodes.InterchangeMeshNode.RemoveMorphTargetDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x991f5e0
	bool IsSkinnedMesh(); // Function InterchangeNodes.InterchangeMeshNode.IsSkinnedMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x993fe50
	bool IsMorphTarget(); // Function InterchangeNodes.InterchangeMeshNode.IsMorphTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x993c790
	bool GetSlotMaterialDependencyUid(struct FString SlotName, struct FString& OutMaterialDependency); // Function InterchangeNodes.InterchangeMeshNode.GetSlotMaterialDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9932690
	void GetSlotMaterialDependencies(struct TMap<struct FString, struct FString>& OutMaterialDependencies); // Function InterchangeNodes.InterchangeMeshNode.GetSlotMaterialDependencies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9932a40
	void GetSkeletonDependency(int32_t Index, struct FString& OutDependency); // Function InterchangeNodes.InterchangeMeshNode.GetSkeletonDependency // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x993bf30
	void GetSkeletonDependencies(struct TArray<struct FString>& OutDependencies); // Function InterchangeNodes.InterchangeMeshNode.GetSkeletonDependencies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9940810
	int32_t GetSkeletonDependeciesCount(); // Function InterchangeNodes.InterchangeMeshNode.GetSkeletonDependeciesCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9943470
	int32_t GetSceneInstanceUidsCount(); // Function InterchangeNodes.InterchangeMeshNode.GetSceneInstanceUidsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x99343c0
	void GetSceneInstanceUids(struct TArray<struct FString>& OutDependencies); // Function InterchangeNodes.InterchangeMeshNode.GetSceneInstanceUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991f480
	void GetSceneInstanceUid(int32_t Index, struct FString& OutDependency); // Function InterchangeNodes.InterchangeMeshNode.GetSceneInstanceUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99345b0
	bool GetMorphTargetName(struct FString& OutMorphTargetName); // Function InterchangeNodes.InterchangeMeshNode.GetMorphTargetName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9939690
	void GetMorphTargetDependency(int32_t Index, struct FString& OutDependency); // Function InterchangeNodes.InterchangeMeshNode.GetMorphTargetDependency // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991ffd0
	void GetMorphTargetDependencies(struct TArray<struct FString>& OutDependencies); // Function InterchangeNodes.InterchangeMeshNode.GetMorphTargetDependencies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9931a30
	int32_t GetMorphTargetDependeciesCount(); // Function InterchangeNodes.InterchangeMeshNode.GetMorphTargetDependeciesCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x99352f0
	bool GetCustomVertexCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomVertexCount // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99241c0
	bool GetCustomUVCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomUVCount // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9929d70
	bool GetCustomPolygonCount(int32_t& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomPolygonCount // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9927e40
	bool GetCustomHasVertexTangent(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomHasVertexTangent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9941fa0
	bool GetCustomHasVertexNormal(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomHasVertexNormal // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9931220
	bool GetCustomHasVertexColor(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomHasVertexColor // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991fe30
	bool GetCustomHasVertexBinormal(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomHasVertexBinormal // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992eb10
	bool GetCustomHasSmoothGroup(bool& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomHasSmoothGroup // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9932c60
	bool GetCustomBoundingBox(struct FBox& AttributeValue); // Function InterchangeNodes.InterchangeMeshNode.GetCustomBoundingBox // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x99253b0
};

// Class InterchangeNodes.InterchangeSceneNode
// Size: 0x390 (Inherited: 0xd0)
struct UInterchangeSceneNode : UInterchangeBaseNode {
	char pad_d0[0x2c0]; // 0xd0(0x2c0)

	bool SetSlotMaterialDependencyUid(struct FString SlotName, struct FString MaterialDependencyUid); // Function InterchangeNodes.InterchangeSceneNode.SetSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x9920670
	bool SetMorphTargetCurveWeight(struct FString MorphTargetName, float& Weight); // Function InterchangeNodes.InterchangeSceneNode.SetMorphTargetCurveWeight // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x993c610
	bool SetCustomTimeZeroLocalTransform(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FTransform& AttributeValue, bool bResetCache); // Function InterchangeNodes.InterchangeSceneNode.SetCustomTimeZeroLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x992ae90
	bool SetCustomLocalTransform(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FTransform& AttributeValue, bool bResetCache); // Function InterchangeNodes.InterchangeSceneNode.SetCustomLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9920150
	bool SetCustomGeometricTransform(struct FTransform& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.SetCustomGeometricTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x992c190
	bool SetCustomBindPoseLocalTransform(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FTransform& AttributeValue, bool bResetCache); // Function InterchangeNodes.InterchangeSceneNode.SetCustomBindPoseLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x991f160
	bool SetCustomAssetInstanceUid(struct FString AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.SetCustomAssetInstanceUid // (Final|Native|Public|BlueprintCallable) // @ game+0x992c410
	bool SetCustomAnimationAssetUidToPlay(struct FString AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.SetCustomAnimationAssetUidToPlay // (Final|Native|Public|BlueprintCallable) // @ game+0x9932030
	bool RemoveSpecializedType(struct FString SpecializedType); // Function InterchangeNodes.InterchangeSceneNode.RemoveSpecializedType // (Final|Native|Public|BlueprintCallable) // @ game+0x992d6a0
	bool RemoveSlotMaterialDependencyUid(struct FString SlotName); // Function InterchangeNodes.InterchangeSceneNode.RemoveSlotMaterialDependencyUid // (Final|Native|Public|BlueprintCallable) // @ game+0x992d320
	bool IsSpecializedTypeContains(struct FString SpecializedType); // Function InterchangeNodes.InterchangeSceneNode.IsSpecializedTypeContains // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9932900
	void GetSpecializedTypes(struct TArray<struct FString>& OutSpecializedTypes); // Function InterchangeNodes.InterchangeSceneNode.GetSpecializedTypes // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x99270b0
	int32_t GetSpecializedTypeCount(); // Function InterchangeNodes.InterchangeSceneNode.GetSpecializedTypeCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9938730
	void GetSpecializedType(int32_t Index, struct FString& OutSpecializedType); // Function InterchangeNodes.InterchangeSceneNode.GetSpecializedType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9922f20
	bool GetSlotMaterialDependencyUid(struct FString SlotName, struct FString& OutMaterialDependency); // Function InterchangeNodes.InterchangeSceneNode.GetSlotMaterialDependencyUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9944870
	void GetSlotMaterialDependencies(struct TMap<struct FString, struct FString>& OutMaterialDependencies); // Function InterchangeNodes.InterchangeSceneNode.GetSlotMaterialDependencies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x991fd20
	void GetMorphTargetCurveWeights(struct TMap<struct FString, float>& OutMorphTargetCurveWeights); // Function InterchangeNodes.InterchangeSceneNode.GetMorphTargetCurveWeights // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9936960
	bool GetCustomTimeZeroLocalTransform(struct FTransform& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.GetCustomTimeZeroLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9921da0
	bool GetCustomTimeZeroGlobalTransform(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FTransform& GlobalOffsetTransform, struct FTransform& AttributeValue, bool bForceRecache); // Function InterchangeNodes.InterchangeSceneNode.GetCustomTimeZeroGlobalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9929e90
	bool GetCustomLocalTransform(struct FTransform& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.GetCustomLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x99394f0
	bool GetCustomGlobalTransform(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FTransform& GlobalOffsetTransform, struct FTransform& AttributeValue, bool bForceRecache); // Function InterchangeNodes.InterchangeSceneNode.GetCustomGlobalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x992d9b0
	bool GetCustomGeometricTransform(struct FTransform& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.GetCustomGeometricTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9931ec0
	bool GetCustomBindPoseLocalTransform(struct FTransform& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.GetCustomBindPoseLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9923ac0
	bool GetCustomBindPoseGlobalTransform(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FTransform& GlobalOffsetTransform, struct FTransform& AttributeValue, bool bForceRecache); // Function InterchangeNodes.InterchangeSceneNode.GetCustomBindPoseGlobalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x992bcc0
	bool GetCustomAssetInstanceUid(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.GetCustomAssetInstanceUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9930d10
	bool GetCustomAnimationAssetUidToPlay(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeSceneNode.GetCustomAnimationAssetUidToPlay // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x992ec60
	bool AddSpecializedType(struct FString SpecializedType); // Function InterchangeNodes.InterchangeSceneNode.AddSpecializedType // (Final|Native|Public|BlueprintCallable) // @ game+0x992aa10
};

// Class InterchangeNodes.InterchangeShaderPortsAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeShaderPortsAPI : UObject {

	struct FString MakeInputValueKey(struct FString InputName); // Function InterchangeNodes.InterchangeShaderPortsAPI.MakeInputValueKey // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9947290
	struct FString MakeInputName(struct FString InputKey); // Function InterchangeNodes.InterchangeShaderPortsAPI.MakeInputName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x994d320
	struct FString MakeInputConnectionKey(struct FString InputName); // Function InterchangeNodes.InterchangeShaderPortsAPI.MakeInputConnectionKey // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x994c8f0
	bool IsAnInput(struct FString AttributeKey); // Function InterchangeNodes.InterchangeShaderPortsAPI.IsAnInput // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x994b410
	bool HasInput(struct UInterchangeBaseNode* InterchangeNode, struct FName& InInputName); // Function InterchangeNodes.InterchangeShaderPortsAPI.HasInput // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x994c5c0
	bool GetInputConnection(struct UInterchangeBaseNode* InterchangeNode, struct FString InputName, struct FString& OutExpressionUid, struct FString& OutputName); // Function InterchangeNodes.InterchangeShaderPortsAPI.GetInputConnection // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9948950
	void GatherInputs(struct UInterchangeBaseNode* InterchangeNode, struct TArray<struct FString>& OutInputNames); // Function InterchangeNodes.InterchangeShaderPortsAPI.GatherInputs // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9945290
	bool ConnectOuputToInputByName(struct UInterchangeBaseNode* InterchangeNode, struct FString InputName, struct FString ExpressionUid, struct FString OutputName); // Function InterchangeNodes.InterchangeShaderPortsAPI.ConnectOuputToInputByName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x994c1c0
	bool ConnectOuputToInputByIndex(struct UInterchangeBaseNode* InterchangeNode, struct FString InputName, struct FString ExpressionUid, int32_t OutputIndex); // Function InterchangeNodes.InterchangeShaderPortsAPI.ConnectOuputToInputByIndex // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9946a70
	bool ConnectDefaultOuputToInput(struct UInterchangeBaseNode* InterchangeNode, struct FString InputName, struct FString ExpressionUid); // Function InterchangeNodes.InterchangeShaderPortsAPI.ConnectDefaultOuputToInput // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x99460b0
};

// Class InterchangeNodes.InterchangeShaderNode
// Size: 0xe0 (Inherited: 0xd0)
struct UInterchangeShaderNode : UInterchangeBaseNode {
	char pad_d0[0x10]; // 0xd0(0x10)

	bool SetCustomShaderType(struct FString AttributeValue); // Function InterchangeNodes.InterchangeShaderNode.SetCustomShaderType // (Final|Native|Public|BlueprintCallable) // @ game+0x994c0b0
	bool GetCustomShaderType(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeShaderNode.GetCustomShaderType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x994aea0
};

// Class InterchangeNodes.InterchangeFunctionCallShaderNode
// Size: 0xf0 (Inherited: 0xe0)
struct UInterchangeFunctionCallShaderNode : UInterchangeShaderNode {
	char pad_e0[0x10]; // 0xe0(0x10)

	bool SetCustomMaterialFunction(struct FString AttributeValue); // Function InterchangeNodes.InterchangeFunctionCallShaderNode.SetCustomMaterialFunction // (Final|Native|Public|BlueprintCallable) // @ game+0x9948820
	bool GetCustomMaterialFunction(struct FString& AttributeValue); // Function InterchangeNodes.InterchangeFunctionCallShaderNode.GetCustomMaterialFunction // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9948090
};

// Class InterchangeNodes.InterchangeShaderGraphNode
// Size: 0x130 (Inherited: 0xe0)
struct UInterchangeShaderGraphNode : UInterchangeShaderNode {
	char pad_e0[0x50]; // 0xe0(0x50)

	bool SetCustomTwoSidedTransmission(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.SetCustomTwoSidedTransmission // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9946320
	bool SetCustomTwoSided(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.SetCustomTwoSided // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x994aa80
	bool SetCustomScreenSpaceReflections(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.SetCustomScreenSpaceReflections // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9944f40
	bool SetCustomOpacityMaskClipValue(float& AttributeValue, bool bAddApplyDelegate); // Function InterchangeNodes.InterchangeShaderGraphNode.SetCustomOpacityMaskClipValue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x994bf50
	bool SetCustomIsAShaderFunction(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.SetCustomIsAShaderFunction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9949e60
	bool GetCustomTwoSidedTransmission(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.GetCustomTwoSidedTransmission // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9949170
	bool GetCustomTwoSided(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.GetCustomTwoSided // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9945f60
	bool GetCustomScreenSpaceReflections(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.GetCustomScreenSpaceReflections // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x994b020
	bool GetCustomOpacityMaskClipValue(float& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.GetCustomOpacityMaskClipValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9947f70
	bool GetCustomIsAShaderFunction(bool& AttributeValue); // Function InterchangeNodes.InterchangeShaderGraphNode.GetCustomIsAShaderFunction // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x994b700
};

// Class InterchangeNodes.InterchangeTexture2DNode
// Size: 0x1a0 (Inherited: 0x100)
struct UInterchangeTexture2DNode : UInterchangeTextureNode {
	char pad_100[0xa0]; // 0x100(0xa0)

	bool SetCustomWrapV(enum class EInterchangeTextureWrapMode& AttributeValue); // Function InterchangeNodes.InterchangeTexture2DNode.SetCustomWrapV // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9945770
	bool SetCustomWrapU(enum class EInterchangeTextureWrapMode& AttributeValue); // Function InterchangeNodes.InterchangeTexture2DNode.SetCustomWrapU // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9948ea0
	struct TMap<int32_t, struct FString> GetSourceBlocks(); // Function InterchangeNodes.InterchangeTexture2DNode.GetSourceBlocks // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9945050
	bool GetCustomWrapV(enum class EInterchangeTextureWrapMode& AttributeValue); // Function InterchangeNodes.InterchangeTexture2DNode.GetCustomWrapV // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9948360
	bool GetCustomWrapU(enum class EInterchangeTextureWrapMode& AttributeValue); // Function InterchangeNodes.InterchangeTexture2DNode.GetCustomWrapU // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x994cfe0
};

// Class InterchangeNodes.InterchangeTextureBlurNode
// Size: 0x1a0 (Inherited: 0x1a0)
struct UInterchangeTextureBlurNode : UInterchangeTexture2DNode {
};

