// Enum EmbarkAudio.EMapRangeCurve
enum class EMapRangeCurve : uint8_t {
	Linear = 0,
	Sine = 1,
	Squared = 2,
	SCurve = 3,
	EMapRangeCurve_MAX = 4
};

// Enum EmbarkAudio.EWeaponSynthSoundLayerType
enum class EWeaponSynthSoundLayerType : uint8_t {
	Bullet = 0,
	PreFiring = 1,
	PostFiring = 2,
	Disabled = 3,
	EWeaponSynthSoundLayerType_MAX = 4
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrainVoiceGroupConfig
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkAudioGrainVoiceGroupConfig {
	float MaxRange; // 0x00(0x04)
	int32_t VoicePolyphony; // 0x04(0x04)
	float FadeInTime; // 0x08(0x04)
	float FadeOutTime; // 0x0c(0x04)
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrainCooldownGroupConfig
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkAudioGrainCooldownGroupConfig {
	float MinCooldownTime; // 0x00(0x04)
	float MaxCooldownTime; // 0x04(0x04)
	bool bCooldownIsPerGrain; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrainSystemConfig
// Size: 0xb0 (Inherited: 0x00)
struct FEmbarkAudioGrainSystemConfig {
	float UpdateRate; // 0x00(0x04)
	float MovementPredictionFactor; // 0x04(0x04)
	float PlaybackChanceForCooldownPerGroup; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct TMap<struct FName, struct FEmbarkAudioGrainVoiceGroupConfig> VoiceGroups; // 0x10(0x50)
	struct TMap<struct FName, struct FEmbarkAudioGrainCooldownGroupConfig> CooldownGroups; // 0x60(0x50)
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrain
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkAudioGrain {
	struct FSoftObjectPath Sound; // 0x00(0x20)
	struct FName VoiceGroup; // 0x20(0x08)
	struct FName CooldownGroup; // 0x28(0x08)
	float MaxRandomStartTime; // 0x30(0x04)
	float ExclusionRadius; // 0x34(0x04)
	uint32_t MaxNumOfSameSound; // 0x38(0x04)
	float MinDistance; // 0x3c(0x04)
	float PruningRadius; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrainSowingData
// Size: 0x68 (Inherited: 0x00)
struct FEmbarkAudioGrainSowingData {
	struct FVector WorldPosition; // 0x00(0x18)
	struct FEmbarkAudioGrain GrainData; // 0x18(0x48)
	struct USceneComponent* AttachToComponent; // 0x60(0x08)
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrainParameterData
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkAudioGrainParameterData {
	struct FName Parameter; // 0x00(0x08)
	float Value; // 0x08(0x04)
};

// ScriptStruct EmbarkAudio.EmbarkAudioGrainSoundInfo
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkAudioGrainSoundInfo {
	struct USoundBase* Sound; // 0x00(0x08)
	struct FSoftObjectPath SoftPath; // 0x08(0x20)
	char pad_28[0x20]; // 0x28(0x20)
};

// ScriptStruct EmbarkAudio.EmbarkAudioSpatializationSourceSettings
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkAudioSpatializationSourceSettings {
	float SideAttenuationDistanceMin; // 0x00(0x04)
	float SideAttenuationDistanceMax; // 0x04(0x04)
	bool bDontPanCloseToListener; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float FullPanBeyondDistance; // 0x0c(0x04)
	float NoPanWithinDistance; // 0x10(0x04)
};

// ScriptStruct EmbarkAudio.DialogueTagPair
// Size: 0x10 (Inherited: 0x00)
struct FDialogueTagPair {
	struct FGameplayTag Intent; // 0x00(0x08)
	struct FGameplayTag Object; // 0x08(0x08)
};

// ScriptStruct EmbarkAudio.EmbarkAudioParameters
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkAudioParameters {
	struct TArray<struct FAudioParameter> Parameters; // 0x00(0x10)
};

// ScriptStruct EmbarkAudio.EmbarkPathfinderAudioOcclusionSourceSettings
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkPathfinderAudioOcclusionSourceSettings {
	float OcclusionLowPassFilterFrequency; // 0x00(0x04)
	float OcclusionVolumeAttenuation; // 0x04(0x04)
	float FullOcclusionDistance; // 0x08(0x04)
	int32_t PathFinderMaxIterations; // 0x0c(0x04)
	float VerticalOffset; // 0x10(0x04)
	float RateOfChange; // 0x14(0x04)
};

