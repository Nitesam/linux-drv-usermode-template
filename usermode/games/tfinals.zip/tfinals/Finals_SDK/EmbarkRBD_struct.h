// ScriptStruct EmbarkRBD.PhysicsBody
// Size: 0xf0 (Inherited: 0x00)
struct FPhysicsBody {
	char pad_0[0xe8]; // 0x00(0xe8)
	int32_t UserHandle; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// ScriptStruct EmbarkRBD.Contact
// Size: 0x58 (Inherited: 0x00)
struct FContact {
	int32_t BodyA; // 0x00(0x04)
	int32_t BodyB; // 0x04(0x04)
	struct FVector Normal; // 0x08(0x18)
	struct FVector PositionOnBodyAInA; // 0x20(0x18)
	struct FVector PositionOnBodyBInB; // 0x38(0x18)
	double Friction; // 0x50(0x08)
};

