// Enum EmbarkAI.EAIAlertnessSource
enum class EAIAlertnessSource : uint8_t {
	Unknown = 0,
	Resources = 1,
	Enemy = 2,
	EAIAlertnessSource_MAX = 3
};

// Enum EmbarkAI.EAIAlertness
enum class EAIAlertness : uint8_t {
	Idle = 0,
	Alert = 1,
	InCombat = 2,
	Dormant = 3,
	Fleeing = 4,
	EAIAlertness_MAX = 5
};

// Enum EmbarkAI.EAICombatPhase
enum class EAICombatPhase : uint8_t {
	Normal = 0,
	Aggressive = 1,
	Passive = 2,
	Impaired = 3,
	EAICombatPhase_MAX = 4
};

// Enum EmbarkAI.EAIEmotionalState
enum class EAIEmotionalState : uint8_t {
	Normal = 0,
	Enraged = 1,
	Weakened = 2,
	EAIEmotionalState_MAX = 3
};

// Enum EmbarkAI.EUtilitySelectionMethod
enum class EUtilitySelectionMethod : uint8_t {
	Priority = 0,
	Proportional = 1,
	EUtilitySelectionMethod_MAX = 2
};

// Enum EmbarkAI.EAIFocusMode
enum class EAIFocusMode : uint8_t {
	Movement = 0,
	Event = 1,
	Target = 2,
	Script = 3,
	Freeze = 4,
	NoFocus = 5,
	NUM = 6,
	EAIFocusMode_MAX = 7
};

// Enum EmbarkAI.EAIFocusFlags
enum class EAIFocusFlags : uint8_t {
	None = 0,
	RequireLOS = 1,
	RequireDistance = 2,
	EAIFocusFlags_MAX = 3
};

// Enum EmbarkAI.EStimulusSense
enum class EStimulusSense : uint8_t {
	None = 0,
	Bypass = 1,
	Damage = 2,
	Hearing = 3,
	Network = 4,
	Sight = 5,
	Touch = 6,
	EStimulusSense_MAX = 7
};

// Enum EmbarkAI.EAgentGroupRole
enum class EAgentGroupRole : uint8_t {
	None = 0,
	Hunt = 1,
	Guard = 2,
	Harvest = 3,
	EAgentGroupRole_MAX = 4
};

// Enum EmbarkAI.EAgentEncounterModifier
enum class EAgentEncounterModifier : uint8_t {
	Default = 0,
	Dormant = 1,
	Ambush = 2,
	EAgentEncounterModifier_MAX = 3
};

// Enum EmbarkAI.EPerceivedTargetLocationMode
enum class EPerceivedTargetLocationMode : uint8_t {
	LastKnownLocation = 0,
	LastSeenLocation = 1,
	LastSeenProximityLocation = 2,
	EPerceivedTargetLocationMode_MAX = 3
};

// Enum EmbarkAI.EAISensingStatusFilter
enum class EAISensingStatusFilter : uint8_t {
	Any = 0,
	All = 1,
	EAISensingStatusFilter_MAX = 2
};

// Enum EmbarkAI.EDamageTakenSecondType
enum class EDamageTakenSecondType : uint8_t {
	None = 0,
	Normalized = 1,
	Absolute = 2,
	NonPropagated = 3,
	EDamageTakenSecondType_MAX = 4
};

// Enum EmbarkAI.EAIKnowledgebaseNativeEventType
enum class EAIKnowledgebaseNativeEventType : uint8_t {
	NewTargetDiscovered = 0,
	TargetRemoved = 1,
	EAIKnowledgebaseNativeEventType_MAX = 2
};

// Enum EmbarkAI.EAIAgentOrder
enum class EAIAgentOrder : uint8_t {
	None = 0,
	NonBehavior = 1,
	BehaviorCustom = 2,
	BehaviorCharge = 3,
	BehaviorFlee = 4,
	EAIAgentOrder_MAX = 5
};

// Enum EmbarkAI.EAICombatStateDataSelection
enum class EAICombatStateDataSelection : uint8_t {
	Custom = 0,
	CapabilityGroup = 1,
	SelectedUtility = 2,
	ActiveOrder = 3,
	TransitionInstigator = 4,
	EAICombatStateDataSelection_MAX = 5
};

// Enum EmbarkAI.EAICombatStateCapabilityGroupSelection
enum class EAICombatStateCapabilityGroupSelection : uint8_t {
	None = 0,
	AssociatedCapabilityGroup = 1,
	HighestUtility = 2,
	EAICombatStateCapabilityGroupSelection_MAX = 3
};

// Enum EmbarkAI.EAICombatStateTargetSelection
enum class EAICombatStateTargetSelection : uint8_t {
	DefaultHostileTarget = 0,
	DefaultFriendlyTarget = 1,
	EAICombatStateTargetSelection_MAX = 2
};

// Enum EmbarkAI.EAINavigationCapability
enum class EAINavigationCapability : uint8_t {
	Ground = 0,
	Flying = 1,
	GroundAndFlying = 2,
	Default = 3,
	EAINavigationCapability_MAX = 4
};

// Enum EmbarkAI.EAIMovementSpeed
enum class EAIMovementSpeed : uint8_t {
	NotSpecified = 0,
	VerySlow = 1,
	Slow = 2,
	Normal = 3,
	Fast = 4,
	VeryFast = 5,
	EAIMovementSpeed_MAX = 6
};

// Enum EmbarkAI.EAITurnSpeed
enum class EAITurnSpeed : uint8_t {
	NotSpecified = 0,
	VerySlow = 1,
	Slow = 2,
	Normal = 3,
	Fast = 4,
	VeryFast = 5,
	EAITurnSpeed_MAX = 6
};

// Enum EmbarkAI.EAICombatPositionQueryState
enum class EAICombatPositionQueryState : uint8_t {
	Idle = 0,
	Searching = 1,
	SearchFailed = 2,
	SearchSuccess = 3,
	EAICombatPositionQueryState_MAX = 4
};

// Enum EmbarkAI.EAISoundMaskingEngine
enum class EAISoundMaskingEngine : uint8_t {
	None = 0,
	VeryQuiet = 1,
	Quiet = 2,
	Medium = 3,
	Loud = 4,
	EAISoundMaskingEngine_MAX = 5
};

// Enum EmbarkAI.EAISoundInterestRange
enum class EAISoundInterestRange : uint8_t {
	Short = 0,
	Medium = 1,
	Long = 2,
	Massive = 3,
	EAISoundInterestRange_MAX = 4
};

// Enum EmbarkAI.EEnvQueryDynamicShapeNavOption
enum class EEnvQueryDynamicShapeNavOption : uint8_t {
	None = 0,
	FromCenter = 1,
	FromReference = 2,
	EEnvQueryDynamicShapeNavOption_MAX = 3
};

// Enum EmbarkAI.EEmbarkEnvQueryFlyingProjection
enum class EEmbarkEnvQueryFlyingProjection : uint8_t {
	Geometry = 0,
	Voxel = 1,
	EEmbarkEnvQueryFlyingProjection_MAX = 2
};

// Enum EmbarkAI.EGeneratorProjectionType
enum class EGeneratorProjectionType : uint8_t {
	Default = 0,
	Voxel = 1,
	EGeneratorProjectionType_MAX = 2
};

// Enum EmbarkAI.EEmbarkEnvQueryCost
enum class EEmbarkEnvQueryCost : uint8_t {
	Low = 0,
	Medium = 1,
	High = 2,
	EEmbarkEnvQueryCost_MAX = 3
};

// Enum EmbarkAI.ESmartObjectNotify
enum class ESmartObjectNotify : uint8_t {
	Investigate = 0,
	Attack = 1,
	ESmartObjectNotify_MAX = 2
};

// ScriptStruct EmbarkAI.EmbarkAIVisLogInfo
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkAIVisLogInfo {
	struct TMap<struct FString, struct FString> DebugStringMap; // 0x00(0x50)
};

// ScriptStruct EmbarkAI.BTUtilityComposition
// Size: 0x30 (Inherited: 0x00)
struct FBTUtilityComposition {
	struct TArray<struct UBTUtilityCalculation*> Calculations; // 0x00(0x10)
	struct TArray<struct UBTUtilityCalculation*> MultiplicativeCalculations; // 0x10(0x10)
	struct UEmbarkAICombatPositionQueryBase* PositionQuery; // 0x20(0x08)
	struct FGameplayTag Tag; // 0x28(0x08)
};

// ScriptStruct EmbarkAI.SenseConfigPerAlertness
// Size: 0x18 (Inherited: 0x00)
struct FSenseConfigPerAlertness {
	enum class EAIAlertness Alertness; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct UAISenseConfig*> SenseConfigs; // 0x08(0x10)
};

// ScriptStruct EmbarkAI.ConstructablePerceptionServiceSenseConfig
// Size: 0x68 (Inherited: 0x00)
struct FConstructablePerceptionServiceSenseConfig {
	struct FGameplayTagQuery RequiredPartTags; // 0x00(0x48)
	struct TArray<struct UAISenseConfig*> SenseConfigs; // 0x48(0x10)
	struct TArray<struct FSenseConfigPerAlertness> SenseConfigsPerAlertness; // 0x58(0x10)
};

// ScriptStruct EmbarkAI.AIPerceiveResult
// Size: 0x50 (Inherited: 0x00)
struct FAIPerceiveResult {
	struct TMap<struct AActor*, struct FActorPerceptionBlueprintInfo> PerceivedActors; // 0x00(0x50)
};

// ScriptStruct EmbarkAI.TargetInfo
// Size: 0x78 (Inherited: 0x00)
struct FTargetInfo {
	struct AActor* Actor; // 0x00(0x08)
	struct UAITargetComponent* TargetComp; // 0x08(0x08)
	struct FVector Location; // 0x10(0x18)
	struct FVector Direction; // 0x28(0x18)
	struct FVector AimLocation; // 0x40(0x18)
	struct FVector AimDirection; // 0x58(0x18)
	float HealthFraction; // 0x70(0x04)
	enum class EEmbarkTeamId TeamId; // 0x74(0x01)
	bool bBypassPerception; // 0x75(0x01)
	bool bIsAiming; // 0x76(0x01)
	char pad_77[0x1]; // 0x77(0x01)
};

// ScriptStruct EmbarkAI.AITargetingParams
// Size: 0x58 (Inherited: 0x00)
struct FAITargetingParams {
	float MaxSpeed; // 0x00(0x04)
	float LookAheadTime; // 0x04(0x04)
	float DirectionCorrectionSpeed; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FVector AimAtPosition; // 0x10(0x18)
	struct FVector TrackingVelocity; // 0x28(0x18)
	struct FVector LastPosition; // 0x40(0x18)
};

// ScriptStruct EmbarkAI.AIAimParams
// Size: 0x10 (Inherited: 0x00)
struct FAIAimParams {
	float Accuracy; // 0x00(0x04)
	float OffsetDirection; // 0x04(0x04)
	float OffsetRadius; // 0x08(0x04)
	float OffsetMaxAngleDifference; // 0x0c(0x04)
};

// ScriptStruct EmbarkAI.TemporaryAITargetingModification
// Size: 0x04 (Inherited: 0x00)
struct FTemporaryAITargetingModification {
	float AccuracyFactorMultiplier; // 0x00(0x04)
};

// ScriptStruct EmbarkAI.AITargetHandle
// Size: 0x08 (Inherited: 0x00)
struct FAITargetHandle {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct EmbarkAI.FocusTarget
// Size: 0x28 (Inherited: 0x00)
struct FFocusTarget {
	struct UAITargetComponent* Target; // 0x00(0x08)
	struct AActor* Actor; // 0x08(0x08)
	struct FVector Location; // 0x10(0x18)
};

// ScriptStruct EmbarkAI.FocusRequest
// Size: 0x40 (Inherited: 0x00)
struct FFocusRequest {
	enum class EAIFocusMode FocusMode; // 0x00(0x01)
	enum class EAIFocusFlags FocusFlags; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FFocusTarget FocusTarget; // 0x08(0x28)
	float ExpireTime; // 0x30(0x04)
	float RequiredDistance; // 0x34(0x04)
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct EmbarkAI.AIStimulusInfo
// Size: 0x30 (Inherited: 0x00)
struct FAIStimulusInfo {
	float Alertness; // 0x00(0x04)
	float FirstSensedAt; // 0x04(0x04)
	float ExpiresAt; // 0x08(0x04)
	float SensedAt; // 0x0c(0x04)
	struct FGameplayTag Tag; // 0x10(0x08)
	struct FVector SensedLocation; // 0x18(0x18)
};

// ScriptStruct EmbarkAI.AIAgentStimuliInfo
// Size: 0x60 (Inherited: 0x00)
struct FAIAgentStimuliInfo {
	struct FVector LastKnownLocation; // 0x00(0x18)
	struct FVector LastSeenLocation; // 0x18(0x18)
	struct FVector LastSeenProximityLocation; // 0x30(0x18)
	enum class EAIAlertnessSource Source; // 0x48(0x01)
	char pad_49[0x17]; // 0x49(0x17)
};

// ScriptStruct EmbarkAI.PerceptionConfig
// Size: 0x10 (Inherited: 0x00)
struct FPerceptionConfig {
	struct UEmbarkAISenseConfig_Sight* SightConfig; // 0x00(0x08)
	struct UEmbarkAISenseConfig_Hearing* HearingConfig; // 0x08(0x08)
};

// ScriptStruct EmbarkAI.DamageTakenSecond
// Size: 0x58 (Inherited: 0x00)
struct FDamageTakenSecond {
	char pad_0[0x58]; // 0x00(0x58)
};

// ScriptStruct EmbarkAI.RecentDamageTaken
// Size: 0x20 (Inherited: 0x00)
struct FRecentDamageTaken {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct EmbarkAI.AgentTargetInfo
// Size: 0x160 (Inherited: 0x00)
struct FAgentTargetInfo {
	struct UAITargetComponent* TargetComp; // 0x00(0x08)
	struct FVector LastKnownLocation; // 0x08(0x18)
	struct FVector LastSeenLocation; // 0x20(0x18)
	struct FVector LastSeenProximityLocation; // 0x38(0x18)
	float LastProximityLocationUpdateTime; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct FVector TargetVelocityMovingAverage; // 0x58(0x18)
	char pad_70[0x18]; // 0x70(0x18)
	float LastVelocityAverageUpdateTime; // 0x88(0x04)
	char pad_8c[0x4]; // 0x8c(0x04)
	struct FVector ExposedLocationOffsetRaw; // 0x90(0x18)
	struct FVector ExposedLocationOffset; // 0xa8(0x18)
	bool bIdentifiedThreat; // 0xc0(0x01)
	bool bPotentialThreat; // 0xc1(0x01)
	char pad_c2[0x2]; // 0xc2(0x02)
	float IdentifiedThreatTime; // 0xc4(0x04)
	float LastValidTime; // 0xc8(0x04)
	float LastAimDotTowardsUs; // 0xcc(0x04)
	float LastAimDotLeftRightOfUs; // 0xd0(0x04)
	float LastAimedTime; // 0xd4(0x04)
	float ClearShotFactor; // 0xd8(0x04)
	float RecentSightFraction; // 0xdc(0x04)
	bool bWithinLoS; // 0xe0(0x01)
	bool bHasEverBeenUpdated; // 0xe1(0x01)
	char pad_e2[0x6]; // 0xe2(0x06)
	struct FAITargetingParams TargetingParams; // 0xe8(0x58)
	struct FRecentDamageTaken RecentDamageTargetDealtToAgent; // 0x140(0x20)
};

// ScriptStruct EmbarkAI.NetworkMessageSettings
// Size: 0x20 (Inherited: 0x00)
struct FNetworkMessageSettings {
	struct TArray<struct UAISense*> TriggerForSenses; // 0x00(0x10)
	float Range; // 0x10(0x04)
	float BroadcastInterval; // 0x14(0x04)
	float InitialNetworkBroadcastDelay; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkAI.AISmartObjectTagPrioritySettings
// Size: 0x50 (Inherited: 0x00)
struct FAISmartObjectTagPrioritySettings {
	struct FGameplayTagQuery SelectedTags; // 0x00(0x48)
	float BasePriority; // 0x48(0x04)
	char pad_4c[0x4]; // 0x4c(0x04)
};

// ScriptStruct EmbarkAI.AISmartObjectQuerySettings
// Size: 0xe0 (Inherited: 0x00)
struct FAISmartObjectQuerySettings {
	struct FGameplayTagQuery Hunt; // 0x00(0x48)
	struct FGameplayTagQuery Guard; // 0x48(0x48)
	struct FGameplayTagQuery Harvest; // 0x90(0x48)
	float Cooldown; // 0xd8(0x04)
	float SearchFrequency; // 0xdc(0x04)
};

// ScriptStruct EmbarkAI.AISmartObjectData
// Size: 0x2c0 (Inherited: 0x00)
struct FAISmartObjectData {
	struct FAISmartObjectQuerySettings IdleQuery; // 0x00(0xe0)
	struct FAISmartObjectQuerySettings AlertQuery; // 0xe0(0xe0)
	struct FAISmartObjectQuerySettings CombatQuery; // 0x1c0(0xe0)
	float InterestRange; // 0x2a0(0x04)
	char pad_2a4[0x4]; // 0x2a4(0x04)
	struct TArray<struct FAISmartObjectTagPrioritySettings> PrioritySettings; // 0x2a8(0x10)
	float LastTimeUsingSmartObject; // 0x2b8(0x04)
	char pad_2bc[0x4]; // 0x2bc(0x04)
};

// ScriptStruct EmbarkAI.AISensingIdentification
// Size: 0x18 (Inherited: 0x00)
struct FAISensingIdentification {
	enum class EAISensingStatusFilter Filter; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<enum class EStimulusSense> Senses; // 0x08(0x10)
};

// ScriptStruct EmbarkAI.AISensingStatusValue
// Size: 0x08 (Inherited: 0x00)
struct FAISensingStatusValue {
	enum class EStimulusSense Sense; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ValueThreshold; // 0x04(0x04)
};

// ScriptStruct EmbarkAI.AISensingStatusTransition
// Size: 0x18 (Inherited: 0x00)
struct FAISensingStatusTransition {
	enum class EAISensingStatusFilter Filter; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FAISensingStatusValue> Values; // 0x08(0x10)
};

// ScriptStruct EmbarkAI.UtilityQueryInfo
// Size: 0x40 (Inherited: 0x00)
struct FUtilityQueryInfo {
	struct UEmbarkAICombatPositionQueryBase* PositionQuery; // 0x00(0x08)
	struct FCombatPositionQueryResults QueryResult; // 0x08(0x28)
	char pad_30[0x10]; // 0x30(0x10)
};

// ScriptStruct EmbarkAI.CombatPositionQueryResults
// Size: 0x28 (Inherited: 0x00)
struct FCombatPositionQueryResults {
	enum class EAICombatPositionQueryState QueryState; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector Position; // 0x08(0x18)
	float QueryTime; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct EmbarkAI.AgentAbilityShotRecord
// Size: 0x48 (Inherited: 0x00)
struct FAgentAbilityShotRecord {
	struct FVector SourceLocation; // 0x00(0x18)
	struct FVector TargetLocation; // 0x18(0x18)
	struct FVector HitLocation; // 0x30(0x18)
};

// ScriptStruct EmbarkAI.AgentSpatialInfoRecord
// Size: 0x38 (Inherited: 0x00)
struct FAgentSpatialInfoRecord {
	float Timestamp; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector WorldLocation; // 0x08(0x18)
	struct FVector WorldVelocity; // 0x20(0x18)
};

// ScriptStruct EmbarkAI.RecentAgentSpatialInfo
// Size: 0x20 (Inherited: 0x00)
struct FRecentAgentSpatialInfo {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct EmbarkAI.AgentInfo
// Size: 0x638 (Inherited: 0x00)
struct FAgentInfo {
	struct AAIController* AIAgent; // 0x00(0x08)
	struct UAITargetComponent* TargetComponent; // 0x08(0x08)
	struct UAIFocusingInterface* AIFocusing; // 0x10(0x08)
	struct UAITargetingInterface* AITargeting; // 0x18(0x08)
	struct UAITemplateDataAsset* TemplateData; // 0x20(0x08)
	struct FVector Location; // 0x28(0x18)
	struct FVector Direction; // 0x40(0x18)
	float SqrDistToClosestPlayer; // 0x58(0x04)
	char pad_5c[0x4]; // 0x5c(0x04)
	struct TMap<struct UAIPerceptionComponent*, struct FPerceptionConfig> BasePerceptionConfigs; // 0x60(0x50)
	enum class EAIAlertness Alertness; // 0xb0(0x01)
	enum class EAIAlertnessSource AlertnessSource; // 0xb1(0x01)
	char pad_b2[0x2]; // 0xb2(0x02)
	float EnteredAlertnessTime; // 0xb4(0x04)
	enum class EAICombatPhase CombatPhase; // 0xb8(0x01)
	enum class EAIEmotionalState EmotionalState; // 0xb9(0x01)
	char pad_ba[0x6]; // 0xba(0x06)
	struct USMInstance* AlertnessStateFSMInstance; // 0xc0(0x08)
	struct USMInstance* AICombatStateFSMInstance; // 0xc8(0x08)
	int32_t SpawnedGroupId; // 0xd0(0x04)
	enum class EAgentGroupRole GroupRole; // 0xd4(0x01)
	enum class EAgentEncounterModifier EncounterModifier; // 0xd5(0x01)
	char pad_d6[0x2]; // 0xd6(0x02)
	struct FFocusTarget SelectedFocusTarget; // 0xd8(0x28)
	struct TArray<struct UAITargetComponent*> SelectedTargets; // 0x100(0x10)
	struct TArray<struct UAITargetComponent*> SelectedFriendlyTargets; // 0x110(0x10)
	struct TArray<struct UAITargetComponent*> SelectedNeutralTargets; // 0x120(0x10)
	struct UAITargetComponent* MostRelevantTargetOverride; // 0x130(0x08)
	struct TMap<struct UAITargetComponent*, struct FAgentTargetInfo> AgentTargetInfos; // 0x138(0x50)
	struct TArray<struct UAITargetComponent*> AgentFriendlyInfos; // 0x188(0x10)
	struct TArray<struct UAITargetComponent*> AgentNeutralInfos; // 0x198(0x10)
	struct TMap<struct UAITargetComponent*, struct FAIAgentStimuliInfo> StimuliInfos; // 0x1a8(0x50)
	int32_t NextLoSUpdateIndex; // 0x1f8(0x04)
	bool bHasTargetsWithinLoS; // 0x1fc(0x01)
	char pad_1fd[0x3]; // 0x1fd(0x03)
	struct UAgentOrder* ActiveAgentOrder; // 0x200(0x08)
	struct TArray<struct UAgentOrder*> ActiveAgentOrdersAsync; // 0x208(0x10)
	struct TArray<struct UAgentOrder*> PendingAgentOrders; // 0x218(0x10)
	struct FAISmartObjectData SmartObjectData; // 0x228(0x2c0)
	struct TMap<struct FName, struct FCombatPositionQueryResults> PositionQueryResults; // 0x4e8(0x50)
	struct TMap<struct UObject*, struct FUtilityQueryInfo> RunningQueries; // 0x538(0x50)
	struct TMap<struct UObject*, char> UtilityBTSelectedChildIndex; // 0x588(0x50)
	char pad_5d8[0x8]; // 0x5d8(0x08)
	struct FRecentDamageTaken RecentDamageTaken; // 0x5e0(0x20)
	struct FRecentAgentSpatialInfo RecentAgentSpatialInformation; // 0x600(0x20)
	char pad_620[0x18]; // 0x620(0x18)
};

// ScriptStruct EmbarkAI.AIKnowledgebaseNativeEvent
// Size: 0x18 (Inherited: 0x00)
struct FAIKnowledgebaseNativeEvent {
	enum class EAIKnowledgebaseNativeEventType Event; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct AAIController* AIAgent; // 0x08(0x08)
	struct UAITargetComponent* Target; // 0x10(0x08)
};

// ScriptStruct EmbarkAI.EmbarkEnvQueryParams
// Size: 0x100 (Inherited: 0x00)
struct FEmbarkEnvQueryParams {
	struct TMap<struct FName, bool> BoolParams; // 0x00(0x50)
	struct TMap<struct FName, int32_t> IntParams; // 0x50(0x50)
	struct TMap<struct FName, float> FloatParams; // 0xa0(0x50)
	struct TArray<struct FEnvNamedValue> NamedParams; // 0xf0(0x10)
};

// ScriptStruct EmbarkAI.FlowHeightMap
// Size: 0x20 (Inherited: 0x00)
struct FFlowHeightMap {
	struct TArray<double> Vertices; // 0x00(0x10)
	int32_t XSize; // 0x10(0x04)
	int32_t YSize; // 0x14(0x04)
	int32_t DistanceBetweenVertices; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkAI.FlowPriorityBucket
// Size: 0x18 (Inherited: 0x00)
struct FFlowPriorityBucket {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct EmbarkAI.PendingOrder
// Size: 0x20 (Inherited: 0x00)
struct FPendingOrder {
	struct UAgentOrder* AgentOrder; // 0x00(0x08)
	struct UAgentOrderContextBase* Context; // 0x08(0x08)
	struct AActor* Instigator; // 0x10(0x08)
	int32_t OrderHandle; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkAI.PendingAgentOrder
// Size: 0x28 (Inherited: 0x00)
struct FPendingAgentOrder {
	struct AAIController* AIAgent; // 0x00(0x08)
	struct FPendingOrder Order; // 0x08(0x20)
};

// ScriptStruct EmbarkAI.PendingGroupOrder
// Size: 0x28 (Inherited: 0x00)
struct FPendingGroupOrder {
	char Roles; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FPendingOrder Order; // 0x08(0x20)
};

// ScriptStruct EmbarkAI.AgentGroupMember
// Size: 0x10 (Inherited: 0x00)
struct FAgentGroupMember {
	struct AAIController* AIController; // 0x00(0x08)
	enum class EAgentGroupRole Role; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkAI.PendingAbortOrder
// Size: 0x10 (Inherited: 0x00)
struct FPendingAbortOrder {
	struct AAIController* AIAgent; // 0x00(0x08)
	int32_t OrderHandle; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
};

// ScriptStruct EmbarkAI.GroupRoleInfo
// Size: 0x28 (Inherited: 0x00)
struct FGroupRoleInfo {
	struct TArray<struct AAIController*> Members; // 0x00(0x10)
	struct FVector Centroid; // 0x10(0x18)
};

// ScriptStruct EmbarkAI.NavMeshCell
// Size: 0x38 (Inherited: 0x00)
struct FNavMeshCell {
	struct TArray<uint64_t> NavPolys; // 0x00(0x10)
	struct TArray<char> BelowHeightMapFraction; // 0x10(0x10)
	struct FVector2D Location; // 0x20(0x10)
	char BelowHeightMapFractionMin; // 0x30(0x01)
	char BelowHeightMapFractionMax; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
};

// ScriptStruct EmbarkAI.NavMeshGrid
// Size: 0x48 (Inherited: 0x00)
struct FNavMeshGrid {
	struct AEmbarkConstructableRecastNavMesh_Base* NavMeshClass; // 0x00(0x08)
	struct TArray<struct FNavMeshCell> NavCells; // 0x08(0x10)
	float CellHalfExtent; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct FVector2D GridMin; // 0x20(0x10)
	struct FVector2D GridMax; // 0x30(0x10)
	int32_t NumColumns; // 0x40(0x04)
	int32_t NumRows; // 0x44(0x04)
};

// ScriptStruct EmbarkAI.AgentGroupInfo
// Size: 0x150 (Inherited: 0x00)
struct FAgentGroupInfo {
	struct TArray<struct FAgentGroupMember> AgentMembers; // 0x00(0x10)
	struct AAIController* GroupLeader; // 0x10(0x08)
	struct TMap<enum class EAgentGroupRole, struct FPendingOrder> GroupOrders; // 0x18(0x50)
	struct TArray<struct UAITargetComponent*> GroupTargets; // 0x68(0x10)
	char pad_78[0x10]; // 0x78(0x10)
	struct TArray<struct FVector> HomePoints; // 0x88(0x10)
	float SearchRadius; // 0x98(0x04)
	char pad_9c[0x4]; // 0x9c(0x04)
	struct TArray<struct FNavMeshGrid> GroundNavigationGrid; // 0xa0(0x10)
	struct FVector GroupLocation; // 0xb0(0x18)
	struct FVector GroupTargetLocation; // 0xc8(0x18)
	struct TArray<struct FPendingAgentOrder> PendingAgentOrders; // 0xe0(0x10)
	struct TArray<struct FPendingAbortOrder> PendingAbortAgentOrders; // 0xf0(0x10)
	struct TMap<enum class EAgentGroupRole, struct FGroupRoleInfo> RoleData; // 0x100(0x50)
};

// ScriptStruct EmbarkAI.AIAlertnessUtilitySet
// Size: 0x14 (Inherited: 0x00)
struct FAIAlertnessUtilitySet {
	float Idle; // 0x00(0x04)
	float Alert; // 0x04(0x04)
	float InCombat; // 0x08(0x04)
	float Dormant; // 0x0c(0x04)
	float Fleeing; // 0x10(0x04)
};

// ScriptStruct EmbarkAI.AgentCallbacks
// Size: 0xe0 (Inherited: 0x00)
struct FAgentCallbacks {
	struct FMulticastInlineDelegate OnAlertnessChanged; // 0x00(0x10)
	struct FMulticastInlineDelegate OnPotentialThreatChanged; // 0x10(0x10)
	struct FMulticastInlineDelegate OnIdentifiedThreatChanged; // 0x20(0x10)
	struct FMulticastInlineDelegate OnEmotionalStateChanged; // 0x30(0x10)
	struct FMulticastInlineDelegate OnCombatPhaseChanged; // 0x40(0x10)
	struct FMulticastInlineDelegate OnUtilityTagChanged; // 0x50(0x10)
	struct FMulticastInlineDelegate OnTargetChanged; // 0x60(0x10)
	struct FMulticastInlineDelegate OnFriendlyTargetChanged; // 0x70(0x10)
	struct FMulticastInlineDelegate OnNeutralTargetChanged; // 0x80(0x10)
	struct FMulticastInlineDelegate OnNewTargetDiscovered; // 0x90(0x10)
	struct FMulticastInlineDelegate OnTargetRemoved; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnAgentOrderStarted; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnAgentOrderEnded; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnSenseConfigured; // 0xd0(0x10)
};

// ScriptStruct EmbarkAI.EmbarkAIPathRequest
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkAIPathRequest {
	struct FVector Destination; // 0x00(0x18)
	enum class EAINavigationCapability NavigationCapability; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float AcceptanceRadius; // 0x1c(0x04)
	bool bUsePathfinding; // 0x20(0x01)
	bool bAllowPartialPath; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
};

// ScriptStruct EmbarkAI.EmbarkAIMoveRequest
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkAIMoveRequest {
	struct FVector Destination; // 0x00(0x18)
	enum class EAINavigationCapability NavigationCapability; // 0x18(0x01)
	enum class EAIMovementSpeed MovementSpeed; // 0x19(0x01)
	char pad_1a[0x2]; // 0x1a(0x02)
	float AcceptanceRadius; // 0x1c(0x04)
	float FacingAngleThreshold; // 0x20(0x04)
	bool bUsePathfinding; // 0x24(0x01)
	bool bAllowPartialPath; // 0x25(0x01)
	char pad_26[0x2]; // 0x26(0x02)
};

// ScriptStruct EmbarkAI.CombatPositionQueryInfo
// Size: 0x30 (Inherited: 0x00)
struct FCombatPositionQueryInfo {
	struct AAIController* AIAgent; // 0x00(0x08)
	float OptimalRange; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FVector TargetLocation; // 0x10(0x18)
	struct UAITargetComponent* TargetComponent; // 0x28(0x08)
};

// ScriptStruct EmbarkAI.EmbarkAIDamageEvent
// Size: 0x58 (Inherited: 0x50)
struct FEmbarkAIDamageEvent : FAIDamageEvent {
	char pad_50[0x8]; // 0x50(0x08)
};

// ScriptStruct EmbarkAI.EmbarkAISoundEvent
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkAISoundEvent {
	char pad_0[0x8]; // 0x00(0x08)
	struct AActor* Instigator; // 0x08(0x08)
	struct FVector NoiseLocation; // 0x10(0x18)
	float Range; // 0x28(0x04)
	struct FName Tag; // 0x2c(0x08)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct EmbarkAI.EmbarkAINetworkEvent
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkAINetworkEvent {
	char pad_0[0x8]; // 0x00(0x08)
	struct AActor* Instigator; // 0x08(0x08)
	struct AActor* Target; // 0x10(0x08)
	struct FVector TargetLastSeenLocation; // 0x18(0x18)
	float MaxRange; // 0x30(0x04)
	struct FName Tag; // 0x34(0x08)
	char pad_3c[0x4]; // 0x3c(0x04)
};

// ScriptStruct EmbarkAI.EmbarkAITouchEvent
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkAITouchEvent {
	char pad_0[0x8]; // 0x00(0x08)
	struct AActor* TouchReceiver; // 0x08(0x08)
	struct AActor* OtherActor; // 0x10(0x08)
	struct FVector Location; // 0x18(0x18)
	struct FGameplayTag SenseTag; // 0x30(0x08)
};

// ScriptStruct EmbarkAI.QueryInstanceItemInput
// Size: 0x68 (Inherited: 0x00)
struct FQueryInstanceItemInput {
	struct UObject* QueryOwner; // 0x00(0x08)
	struct AAIController* OwnerController; // 0x08(0x08)
	struct APawn* OwnerPawn; // 0x10(0x08)
	struct FVector ContextLocation; // 0x18(0x18)
	struct AActor* ContextActor; // 0x30(0x08)
	struct FVector ItemLocation; // 0x38(0x18)
	struct FRotator ItemRotation; // 0x50(0x18)
};

// ScriptStruct EmbarkAI.QueryInstanceItemOutput
// Size: 0x08 (Inherited: 0x00)
struct FQueryInstanceItemOutput {
	float FloatScore; // 0x00(0x04)
	bool bBoolScore; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
};

// ScriptStruct EmbarkAI.EmbarkSmartObjectSlot
// Size: 0x90 (Inherited: 0x00)
struct FEmbarkSmartObjectSlot {
	struct FGameplayTagContainer UserTags; // 0x00(0x20)
	struct FTransform RelativeTransform; // 0x20(0x60)
	struct UAgentOrder* BehaviorOrder; // 0x80(0x08)
	char pad_88[0x8]; // 0x88(0x08)
};

// ScriptStruct EmbarkAI.EmbarkSmartObjectHandle
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkSmartObjectHandle {
	struct UEmbarkSmartObjectComponent* SmartObject; // 0x00(0x08)
};

// ScriptStruct EmbarkAI.EmbarkSmartObjectClaimHandle
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkSmartObjectClaimHandle {
	struct AActor* Querier; // 0x00(0x08)
	struct FEmbarkSmartObjectHandle Handle; // 0x08(0x08)
	int32_t SlotIndex; // 0x10(0x04)
	float ClaimTime; // 0x14(0x04)
};

// ScriptStruct EmbarkAI.EmbarkSmartObjectRequest
// Size: 0x98 (Inherited: 0x00)
struct FEmbarkSmartObjectRequest {
	struct AActor* Querier; // 0x00(0x08)
	struct FBox QueryBox; // 0x08(0x38)
	struct FGameplayTagQuery TagQuery; // 0x40(0x48)
	struct TArray<struct FAISmartObjectTagPrioritySettings> TagPrioritySettings; // 0x88(0x10)
};

