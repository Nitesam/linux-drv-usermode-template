// Enum InterchangeEngine.EInterchangePipelineConfigurationDialogResult
enum class EInterchangePipelineConfigurationDialogResult : uint8_t {
	Cancel = 0,
	Import = 1,
	ImportAll = 2,
	EInterchangePipelineConfigurationDialogResult_MAX = 3
};

// ScriptStruct InterchangeEngine.InterchangeFilePickerParameters
// Size: 0x30 (Inherited: 0x00)
struct FInterchangeFilePickerParameters {
	bool bAllowMultipleFiles; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FText Title; // 0x08(0x18)
	struct FString DefaultPath; // 0x20(0x10)
};

// ScriptStruct InterchangeEngine.InterchangeStackInfo
// Size: 0x18 (Inherited: 0x00)
struct FInterchangeStackInfo {
	struct FName StackName; // 0x00(0x08)
	struct TArray<struct UInterchangePipelineBase*> Pipelines; // 0x08(0x10)
};

// ScriptStruct InterchangeEngine.InterchangeTranslatorPipelines
// Size: 0x38 (Inherited: 0x00)
struct FInterchangeTranslatorPipelines {
	struct TSoftClassPtr<UObject> Translator; // 0x00(0x28)
	struct TArray<struct FSoftObjectPath> Pipelines; // 0x28(0x10)
};

// ScriptStruct InterchangeEngine.InterchangePipelineStack
// Size: 0x20 (Inherited: 0x00)
struct FInterchangePipelineStack {
	struct TArray<struct FSoftObjectPath> Pipelines; // 0x00(0x10)
	struct TArray<struct FInterchangeTranslatorPipelines> PerTranslatorPipelines; // 0x10(0x10)
};

// ScriptStruct InterchangeEngine.InterchangeImportSettings
// Size: 0x88 (Inherited: 0x00)
struct FInterchangeImportSettings {
	struct TMap<struct FName, struct FInterchangePipelineStack> PipelineStacks; // 0x00(0x50)
	struct FName DefaultPipelineStack; // 0x50(0x08)
	struct TSoftClassPtr<UObject> PipelineConfigurationDialogClass; // 0x58(0x28)
	bool bShowPipelineStacksConfigurationDialog; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// ScriptStruct InterchangeEngine.InterchangeContentImportSettings
// Size: 0x128 (Inherited: 0x88)
struct FInterchangeContentImportSettings : FInterchangeImportSettings {
	struct TMap<enum class EInterchangeTranslatorAssetType, struct FName> DefaultPipelineStackOverride; // 0x88(0x50)
	struct TMap<enum class EInterchangeTranslatorAssetType, bool> ShowPipelineStacksConfigurationDialogOverride; // 0xd8(0x50)
};

// ScriptStruct InterchangeEngine.PropertyData
// Size: 0x18 (Inherited: 0x00)
struct FPropertyData {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct InterchangeEngine.ImportAssetParameters
// Size: 0xa0 (Inherited: 0x00)
struct FImportAssetParameters {
	struct UObject* ReimportAsset; // 0x00(0x08)
	int32_t ReimportSourceIndex; // 0x08(0x04)
	bool bIsAutomated; // 0x0c(0x01)
	bool bFollowRedirectors; // 0x0d(0x01)
	char pad_e[0x2]; // 0x0e(0x02)
	struct TArray<struct FSoftObjectPath> OverridePipelines; // 0x10(0x10)
	struct FDelegate OnAssetDone; // 0x20(0x10)
	char pad_30[0x10]; // 0x30(0x10)
	struct FDelegate OnAssetsImportDone; // 0x40(0x10)
	char pad_50[0x10]; // 0x50(0x10)
	struct FDelegate OnSceneObjectDone; // 0x60(0x10)
	char pad_70[0x10]; // 0x70(0x10)
	struct FDelegate OnSceneImportDone; // 0x80(0x10)
	char pad_90[0x10]; // 0x90(0x10)
};

