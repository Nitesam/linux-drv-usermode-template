// Enum EmbarkCloth.EEmbarkClothSimulationType
enum class EEmbarkClothSimulationType : uint8_t {
	None = 0,
	PBD = 1,
	EEmbarkClothSimulationType_MAX = 2
};

// Enum EmbarkCloth.EEmbarkClothDeformerType
enum class EEmbarkClothDeformerType : uint8_t {
	None = 0,
	MorphTargets = 1,
	LinearSkinning = 2,
	ToWorld = 3,
	ToComponent = 4,
	SoftenNormals = 5,
	UnholySkinning = 6,
	OffsetMeshPreSkinning = 7,
	OffsetMeshPostSkinning = 8,
	EEmbarkClothDeformerType_MAX = 9
};

// Enum EmbarkCloth.EEmbarkWeightMapTarget
enum class EEmbarkWeightMapTarget : uint8_t {
	None = 0,
	MaxDistance = 1,
	BackstopDistance = 2,
	BackstopRadius = 3,
	AnimDriveStiffness = 4,
	AnimDriveDamping = 5,
	Mass = 6,
	Damping = 7,
	EdgeStiffness = 8,
	BendingSpringStiffness = 9,
	AreaStiffness = 10,
	VolumeStiffness = 11,
	TetherStiffness = 12,
	TetherScale = 13,
	CollisionThickness = 14,
	CollisionFriction = 15,
	IsBackstopped = 16,
	BackstopFriction = 17,
	CollisionMapping = 18,
	EEmbarkWeightMapTarget_MAX = 19
};

// ScriptStruct EmbarkCloth.EmbarkClothTaggablePhysicsAssets
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkClothTaggablePhysicsAssets {
	struct FGameplayTagContainer Tags; // 0x00(0x20)
	struct UPhysicsAsset* PhysicsAsset; // 0x20(0x08)
	bool bApplyUnholyScaleToTheseColliders; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkCloth.ColliderMaskGroup
// Size: 0x18 (Inherited: 0x00)
struct FColliderMaskGroup {
	struct TArray<struct FName> Colliders; // 0x00(0x10)
	int16_t Index; // 0x10(0x02)
	char pad_12[0x6]; // 0x12(0x06)
};

// ScriptStruct EmbarkCloth.EmbarkClothPBDCollisionSettings
// Size: 0x78 (Inherited: 0x00)
struct FEmbarkClothPBDCollisionSettings {
	struct FVector2f CollisionThickness; // 0x00(0x08)
	struct FVector2f ParticleFriction; // 0x08(0x08)
	struct TArray<struct FEmbarkClothTaggablePhysicsAssets> TaggablePhysicsAssets; // 0x10(0x10)
	struct TMap<struct FName, struct FColliderMaskGroup> CollisionMasks; // 0x20(0x50)
	bool bEnableGroundPlane; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct EmbarkCloth.EmbarkClothPBDConstraintSettings
// Size: 0x5c (Inherited: 0x00)
struct FEmbarkClothPBDConstraintSettings {
	float MaxDistance; // 0x00(0x04)
	struct FVector2f EdgeStiffness; // 0x04(0x08)
	struct FVector2f BendingSpringStiffness; // 0x0c(0x08)
	struct FVector2f AreaStiffness; // 0x14(0x08)
	struct FVector2f VolumeStiffness; // 0x1c(0x08)
	float BackstopThreshold; // 0x24(0x04)
	struct FVector2f BackstopDistance; // 0x28(0x08)
	struct FVector2f BackstopFriction; // 0x30(0x08)
	struct FVector2f TetherStiffness; // 0x38(0x08)
	struct FVector2f TetherScale; // 0x40(0x08)
	bool bUseGeodesicDistance; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	struct FVector2f AnimDriveStiffness; // 0x4c(0x08)
	struct FVector2f AnimDriveDamping; // 0x54(0x08)
};

// ScriptStruct EmbarkCloth.EmbarkClothPBDParticleSettings
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkClothPBDParticleSettings {
	struct FVector2f Mass; // 0x00(0x08)
	struct FVector2f Damping; // 0x08(0x08)
	float WindMultiplier; // 0x10(0x04)
	bool bMassInfluencesWind; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct EmbarkCloth.EmbarkClothPBDSettings
// Size: 0xf0 (Inherited: 0x00)
struct FEmbarkClothPBDSettings {
	bool bUseCustomSimulationSpace; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FEmbarkClothPBDParticleSettings Particles; // 0x04(0x18)
	struct FEmbarkClothPBDConstraintSettings Constraints; // 0x1c(0x5c)
	struct FEmbarkClothPBDCollisionSettings Collision; // 0x78(0x78)
};

