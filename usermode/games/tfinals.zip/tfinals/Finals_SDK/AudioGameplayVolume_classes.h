// Class AudioGameplayVolume.AudioGameplayVolumeMutator
// Size: 0x170 (Inherited: 0x160)
struct UAudioGameplayVolumeMutator : UAudioGameplayComponent {
	int32_t Priority; // 0x160(0x04)
	char pad_164[0xc]; // 0x164(0x0c)

	void SetPriority(int32_t InPriority); // Function AudioGameplayVolume.AudioGameplayVolumeMutator.SetPriority // (Final|Native|Public|BlueprintCallable) // @ game+0x67e0070
};

// Class AudioGameplayVolume.AttenuationVolumeComponent
// Size: 0x180 (Inherited: 0x170)
struct UAttenuationVolumeComponent : UAudioGameplayVolumeMutator {
	float ExteriorVolume; // 0x168(0x04)
	float ExteriorTime; // 0x16c(0x04)
	float InteriorVolume; // 0x170(0x04)
	float InteriorTime; // 0x174(0x04)

	void SetInteriorVolume(float Volume, float InterpolateTime); // Function AudioGameplayVolume.AttenuationVolumeComponent.SetInteriorVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x67dfb90
	void SetExteriorVolume(float Volume, float InterpolateTime); // Function AudioGameplayVolume.AttenuationVolumeComponent.SetExteriorVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x67e4700
};

// Class AudioGameplayVolume.AudioGameplayVolume
// Size: 0x400 (Inherited: 0x3d0)
struct AAudioGameplayVolume : AVolume {
	struct UAudioGameplayVolumeComponent* AGVComponent; // 0x3d0(0x08)
	bool bEnabled; // 0x3d8(0x01)
	char pad_3d9[0x7]; // 0x3d9(0x07)
	struct FMulticastInlineDelegate OnListenerEnterEvent; // 0x3e0(0x10)
	struct FMulticastInlineDelegate OnListenerExitEvent; // 0x3f0(0x10)

	void SetEnabled(bool bEnable); // Function AudioGameplayVolume.AudioGameplayVolume.SetEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x67ea280
	void OnRep_bEnabled(); // Function AudioGameplayVolume.AudioGameplayVolume.OnRep_bEnabled // (Native|Protected) // @ game+0x516b950
	void OnListenerExit(); // Function AudioGameplayVolume.AudioGameplayVolume.OnListenerExit // (Native|Event|Public|BlueprintEvent) // @ game+0x2ed8af0
	void OnListenerEnter(); // Function AudioGameplayVolume.AudioGameplayVolume.OnListenerEnter // (Native|Event|Public|BlueprintEvent) // @ game+0x2c84830
};

// Class AudioGameplayVolume.AudioGameplayVolumeComponent
// Size: 0x190 (Inherited: 0x160)
struct UAudioGameplayVolumeComponent : UAudioGameplayComponent {
	struct FMulticastInlineDelegate OnProxyEnter; // 0x160(0x10)
	struct FMulticastInlineDelegate OnProxyExit; // 0x170(0x10)
	struct UAudioGameplayVolumeProxy* Proxy; // 0x180(0x08)
	char pad_188[0x8]; // 0x188(0x08)
};

// Class AudioGameplayVolume.AudioGameplayVolumeComponentBase
// Size: 0x170 (Inherited: 0x160)
struct UAudioGameplayVolumeComponentBase : UAudioGameplayComponent {
	char pad_160[0x10]; // 0x160(0x10)
};

// Class AudioGameplayVolume.AudioGameplayVolumeProxy
// Size: 0xc0 (Inherited: 0xa0)
struct UAudioGameplayVolumeProxy : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class AudioGameplayVolume.AGVPrimitiveComponentProxy
// Size: 0xc0 (Inherited: 0xc0)
struct UAGVPrimitiveComponentProxy : UAudioGameplayVolumeProxy {
};

// Class AudioGameplayVolume.AGVConditionProxy
// Size: 0xc0 (Inherited: 0xc0)
struct UAGVConditionProxy : UAudioGameplayVolumeProxy {
};

// Class AudioGameplayVolume.AudioGameplayVolumeSubsystem
// Size: 0x1d0 (Inherited: 0xa0)
struct UAudioGameplayVolumeSubsystem : UAudioEngineSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TMap<uint32_t, struct UAudioGameplayVolumeComponent*> AGVComponents; // 0xa8(0x50)
	char pad_f8[0xd8]; // 0xf8(0xd8)
};

// Class AudioGameplayVolume.FilterVolumeComponent
// Size: 0x180 (Inherited: 0x170)
struct UFilterVolumeComponent : UAudioGameplayVolumeMutator {
	float ExteriorLPF; // 0x168(0x04)
	float ExteriorLPFTime; // 0x16c(0x04)
	float InteriorLPF; // 0x170(0x04)
	float InteriorLPFTime; // 0x174(0x04)

	void SetInteriorLPF(float Volume, float InterpolateTime); // Function AudioGameplayVolume.FilterVolumeComponent.SetInteriorLPF // (Final|Native|Public|BlueprintCallable) // @ game+0x67dfb90
	void SetExteriorLPF(float Volume, float InterpolateTime); // Function AudioGameplayVolume.FilterVolumeComponent.SetExteriorLPF // (Final|Native|Public|BlueprintCallable) // @ game+0x67e4700
};

// Class AudioGameplayVolume.ReverbVolumeComponent
// Size: 0x190 (Inherited: 0x170)
struct UReverbVolumeComponent : UAudioGameplayVolumeMutator {
	struct FReverbSettings ReverbSettings; // 0x168(0x20)

	void SetReverbSettings(struct FReverbSettings& NewReverbSettings); // Function AudioGameplayVolume.ReverbVolumeComponent.SetReverbSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67ec0a0
};

// Class AudioGameplayVolume.SubmixOverrideVolumeComponent
// Size: 0x180 (Inherited: 0x170)
struct USubmixOverrideVolumeComponent : UAudioGameplayVolumeMutator {
	struct TArray<struct FAudioVolumeSubmixOverrideSettings> SubmixOverrideSettings; // 0x168(0x10)

	void SetSubmixOverrideSettings(struct TArray<struct FAudioVolumeSubmixOverrideSettings>& NewSubmixOverrideSettings); // Function AudioGameplayVolume.SubmixOverrideVolumeComponent.SetSubmixOverrideSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67eba30
};

// Class AudioGameplayVolume.SubmixSendVolumeComponent
// Size: 0x180 (Inherited: 0x170)
struct USubmixSendVolumeComponent : UAudioGameplayVolumeMutator {
	struct TArray<struct FAudioVolumeSubmixSendSettings> SubmixSendSettings; // 0x168(0x10)

	void SetSubmixSendSettings(struct TArray<struct FAudioVolumeSubmixSendSettings>& NewSubmixSendSettings); // Function AudioGameplayVolume.SubmixSendVolumeComponent.SetSubmixSendSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67e9f60
};

