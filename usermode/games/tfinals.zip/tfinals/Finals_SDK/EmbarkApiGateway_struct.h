// Enum EmbarkApiGateway.EApiGatewayDiscoveryAdminCurrencyType
enum class EApiGatewayDiscoveryAdminCurrencyType : uint8_t {
	CURRENCY_TYPE_MULTIBUCKS = 0,
	CURRENCY_TYPE_ITEM_ACQUISITION = 1,
	CURRENCY_TYPE_BATTLE_PASS = 2,
	CURRENCY_TYPE_HISTORICAL_BATTLE_PASS = 3,
	CURRENCY_TYPE_PLAYSTYLE_TOKEN = 4,
	CURRENCY_TYPE_COLLECTION_EVENT = 5,
	CURRENCY_TYPE_LEAGUE_GOLD = 6,
	CURRENCY_TYPE_LEAGUE_PLATINUM = 7,
	CURRENCY_TYPE_LEAGUE_DIAMOND = 8,
	CURRENCY_TYPE_LEAGUE_RUBY = 9,
	CURRENCY_TYPE_LEAGUE_EMERALD = 10,
	CURRENCY_TYPE_MAX = 11
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryAdminResetResource
enum class EApiGatewayDiscoveryAdminResetResource : uint8_t {
	RESET_ALL = 0,
	RESET_INVENTORY_ITEMS = 1,
	RESET_RANK = 2,
	RESET_ROUND_STATS = 3,
	RESET_ROUND_STAT_SUMMARY = 4,
	RESET_BUCKET_OBJECTS = 5,
	RESET_GAME_STORE_TRANSACTIONS = 6,
	RESET_HARD_CURRENCY_LOG = 7,
	RESET_PLAYER_CAREER = 8,
	RESET_QUEST_PROGRESS = 9,
	RESET_COLLECTION_EVENT = 10,
	RESET_MAX = 11
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerBattlePassKind
enum class EApiGatewayDiscoveryServerBattlePassKind : uint8_t {
	UNKNOWN = 0,
	SEASONAL_LIVE = 1,
	SEASONAL_HISTORICAL = 2,
	EVENT_LIVE = 3,
	EApiGatewayDiscoveryServerBattlePassKind_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryAudioOutputFormat
enum class EApiGatewayDiscoveryServerDynamicCommentaryAudioOutputFormat : uint8_t {
	undefined = 0,
	wav_pcm_16000 = 1,
	wav_pcm_44100 = 2,
	mp3_44100_128 = 3,
	opus_48000_96 = 4,
	opus_48000_64 = 5,
	opus_48000_32 = 6,
	EApiGatewayDiscoveryServerDynamicCommentaryAudioOutputFormat_MAX = 7
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParametersProvider
enum class EApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParametersProvider : uint8_t {
	elevenlabs = 0,
	EApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParametersProvider_MAX = 1
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryTextNormalization
enum class EApiGatewayDiscoveryServerDynamicCommentaryTextNormalization : uint8_t {
	undefined = 0,
	automatic = 1,
	on = 2,
	off = 3,
	EApiGatewayDiscoveryServerDynamicCommentaryTextNormalization_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryOpenAIParametersProvider
enum class EApiGatewayDiscoveryServerDynamicCommentaryOpenAIParametersProvider : uint8_t {
	openai = 0,
	EApiGatewayDiscoveryServerDynamicCommentaryOpenAIParametersProvider_MAX = 1
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryOpenAIReasoningEffort
enum class EApiGatewayDiscoveryServerDynamicCommentaryOpenAIReasoningEffort : uint8_t {
	undefined = 0,
	none = 1,
	minimal = 2,
	low = 3,
	medium = 4,
	high = 5,
	EApiGatewayDiscoveryServerDynamicCommentaryOpenAIReasoningEffort_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryResolveNameType
enum class EApiGatewayDiscoveryServerDynamicCommentaryResolveNameType : uint8_t {
	player = 0,
	anonymous = 1,
	EApiGatewayDiscoveryServerDynamicCommentaryResolveNameType_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerDynamicCommentaryResolveNameStatus
enum class EApiGatewayDiscoveryServerDynamicCommentaryResolveNameStatus : uint8_t {
	undefined = 0,
	ok = 1,
	unpronounceable = 2,
	invalid_input = 3,
	EApiGatewayDiscoveryServerDynamicCommentaryResolveNameStatus_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerGameStoreProvider
enum class EApiGatewayDiscoveryServerGameStoreProvider : uint8_t {
	UNSPECIFIED = 0,
	EMBARK = 1,
	EPIC = 2,
	STEAM = 3,
	MICROSOFT = 4,
	PLAYSTATION = 5,
	EApiGatewayDiscoveryServerGameStoreProvider_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerGameStoreSteamAttributesPackageType
enum class EApiGatewayDiscoveryServerGameStoreSteamAttributesPackageType : uint8_t {
	STEAM_PACKAGE_TYPE_UNSPECIFIED = 0,
	STEAM_PACKAGE_TYPE_INVENTORY = 1,
	STEAM_PACKAGE_TYPE_DLC = 2,
	STEAM_PACKAGE_TYPE_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerSanctionType
enum class EApiGatewayDiscoveryServerSanctionType : uint8_t {
	UNSPECIFIED = 0,
	TOURNAMENT_ABANDON = 1,
	EApiGatewayDiscoveryServerSanctionType_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerQuestActiveOverride
enum class EApiGatewayDiscoveryServerQuestActiveOverride : uint8_t {
	DATES = 0,
	ACTIVE = 1,
	INACTIVE = 2,
	EApiGatewayDiscoveryServerQuestActiveOverride_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerTournamentDifficulty
enum class EApiGatewayDiscoveryServerTournamentDifficulty : uint8_t {
	TOURNAMENT_DIFFICULTY_UNSPECIFIED = 0,
	TOURNAMENT_DIFFICULTY_EASIEST = 1,
	TOURNAMENT_DIFFICULTY_EASY = 2,
	TOURNAMENT_DIFFICULTY_NORMAL = 3,
	TOURNAMENT_DIFFICULTY_HARD = 4,
	TOURNAMENT_DIFFICULTY_HARDEST = 5,
	TOURNAMENT_DIFFICULTY_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryServerTournamentTeamStatus
enum class EApiGatewayDiscoveryServerTournamentTeamStatus : uint8_t {
	MISSING = 0,
	PLAYING = 1,
	KNOCKED_OUT = 2,
	QUALIFIED = 3,
	FINISHED = 4,
	EApiGatewayDiscoveryServerTournamentTeamStatus_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryGameStoreProvider
enum class EApiGatewayDiscoveryGameStoreProvider : uint8_t {
	UNSPECIFIED = 0,
	EMBARK = 1,
	EPIC = 2,
	STEAM = 3,
	MICROSOFT = 4,
	PLAYSTATION = 5,
	EApiGatewayDiscoveryGameStoreProvider_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryGameStoreSteamAttributesPackageType
enum class EApiGatewayDiscoveryGameStoreSteamAttributesPackageType : uint8_t {
	STEAM_PACKAGE_TYPE_UNSPECIFIED = 0,
	STEAM_PACKAGE_TYPE_INVENTORY = 1,
	STEAM_PACKAGE_TYPE_DLC = 2,
	STEAM_PACKAGE_TYPE_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryGameStoreTransactionSource
enum class EApiGatewayDiscoveryGameStoreTransactionSource : uint8_t {
	UNSPECIFIED = 0,
	THIRD_PARTY_SUBSCRIPTION = 1,
	REAL_MONEY_TRANSACTION = 2,
	BATTLEPASS = 3,
	EMBARK_STORE = 4,
	COLLECTION_EVENT = 5,
	EMBARK_STORE_GIFT = 6,
	GIVEAWAY = 7,
	ITEM_RANK = 8,
	TWITCH_DROP = 9,
	OWNERSHIP_VERIFICATION = 10,
	EApiGatewayDiscoveryGameStoreTransactionSource_MAX = 11
};

// Enum EmbarkApiGateway.EApiGatewayDiscoverySanctionType
enum class EApiGatewayDiscoverySanctionType : uint8_t {
	UNSPECIFIED = 0,
	TOURNAMENT_ABANDON = 1,
	COMMUNICATION = 2,
	CHEATING = 3,
	EApiGatewayDiscoverySanctionType_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryInventoryItemType
enum class EApiGatewayDiscoveryInventoryItemType : uint8_t {
	Unspecified = 0,
	LoadoutWrapped = 1,
	SanctionWrapped = 2,
	GameItemWrapped = 3,
	ContestantPackWrapped = 4,
	ArchetypeWrapped = 5,
	CurrencyWrapped = 6,
	WeaponSkinWrapped = 7,
	CustomizationItemWrapped = 8,
	BattlePassWrapped = 9,
	QuestWrapped = 10,
	QuestContextWrapped = 11,
	FameWrapped = 12,
	WeaponCharmWrapped = 13,
	WeaponStickerWrapped = 14,
	SprayWrapped = 15,
	SkillWrapped = 16,
	EmoticonWrapped = 17,
	AnimationCustomizationItemWrapped = 18,
	PlayerCardWrapped = 19,
	PlayerCardCustomizationWrapped = 20,
	WeaponAttachmentWrapped = 21,
	ClansCustomizationWrapped = 22,
	PersistentEntityWrapped = 23,
	EApiGatewayDiscoveryInventoryItemType_MAX = 24
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryInventoryItemChangeActionType
enum class EApiGatewayDiscoveryInventoryItemChangeActionType : uint8_t {
	Unspecified = 0,
	Created = 1,
	Updated = 2,
	Deleted = 3,
	EApiGatewayDiscoveryInventoryItemChangeActionType_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryInventoryItemChangeReason
enum class EApiGatewayDiscoveryInventoryItemChangeReason : uint8_t {
	INVENTORY_ITEM_CHANGE_REASON_UNSPECIFIED = 0,
	INVENTORY_ITEM_CHANGE_REASON_END_OF_SEASON_REWARD = 1,
	INVENTORY_ITEM_CHANGE_REASON_CUSTOM = 2,
	INVENTORY_ITEM_CHANGE_REASON_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryInventoryItemChangeSource
enum class EApiGatewayDiscoveryInventoryItemChangeSource : uint8_t {
	INVENTORY_ITEM_CHANGE_SOURCE_UNSPECIFIED = 0,
	INVENTORY_ITEM_CHANGE_SOURCE_WORLD_TOUR = 1,
	INVENTORY_ITEM_CHANGE_SOURCE_LEAGUE_RANK = 2,
	INVENTORY_ITEM_CHANGE_SOURCE_QUICKPLAY_RANK = 3,
	INVENTORY_ITEM_CHANGE_SOURCE_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryBattlePassKind
enum class EApiGatewayDiscoveryBattlePassKind : uint8_t {
	UNKNOWN = 0,
	SEASONAL_LIVE = 1,
	SEASONAL_HISTORICAL = 2,
	EVENT_LIVE = 3,
	EApiGatewayDiscoveryBattlePassKind_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryBattlePassPageLockType
enum class EApiGatewayDiscoveryBattlePassPageLockType : uint8_t {
	Unspecified = 0,
	NoLock = 1,
	TotalCurrency = 2,
	EApiGatewayDiscoveryBattlePassPageLockType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryCollectionEventItemRewardType
enum class EApiGatewayDiscoveryCollectionEventItemRewardType : uint8_t {
	LIMITED_TIME_REWARD = 0,
	SPECIAL_REWARD = 1,
	NORMAL_REWARD = 2,
	HIGH_VALUE_REWARD = 3,
	EApiGatewayDiscoveryCollectionEventItemRewardType_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryCollectionEventItemState
enum class EApiGatewayDiscoveryCollectionEventItemState : uint8_t {
	CLOSED_ITEM = 0,
	OPEN_ITEM = 1,
	EXPIRED_ITEM = 2,
	EApiGatewayDiscoveryCollectionEventItemState_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryDistributionPlatform
enum class EApiGatewayDiscoveryDistributionPlatform : uint8_t {
	UNSPECIFIED = 0,
	EPIC = 1,
	STEAM = 2,
	XBOX = 3,
	PLAYSTATION = 4,
	EApiGatewayDiscoveryDistributionPlatform_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryRewardItemType
enum class EApiGatewayDiscoveryRewardItemType : uint8_t {
	UNKNOWN = 0,
	SCHEMATIC = 1,
	EApiGatewayDiscoveryRewardItemType_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryGameStoreGiftProvider
enum class EApiGatewayDiscoveryGameStoreGiftProvider : uint8_t {
	TWITCH = 0,
	GIVEAWAY = 1,
	EApiGatewayDiscoveryGameStoreGiftProvider_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryGetGameStoreAccessTokenRequestType
enum class EApiGatewayDiscoveryGetGameStoreAccessTokenRequestType : uint8_t {
	COLLECTION = 0,
	EApiGatewayDiscoveryGetGameStoreAccessTokenRequestType_MAX = 1
};

// Enum EmbarkApiGateway.EApiGatewayDiscoverySponsorTrackRewardType
enum class EApiGatewayDiscoverySponsorTrackRewardType : uint8_t {
	gameAsset = 0,
	product = 1,
	rankBucketXp = 2,
	EApiGatewayDiscoverySponsorTrackRewardType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryProgressiveItemType
enum class EApiGatewayDiscoveryProgressiveItemType : uint8_t {
	PROGRESSION_TYPE_UNSPECIFIED = 0,
	PROGRESSION_TYPE_TOTAL_KILLS = 1,
	PROGRESSION_TYPE_TOTAL_REVIVES = 2,
	PROGRESSION_TYPE_TOTAL_ROUNDS_WON = 3,
	PROGRESSION_TYPE_TOTAL_CASHOUT = 4,
	PROGRESSION_TYPE_TOTAL_WINS_AS_LIGHT = 5,
	PROGRESSION_TYPE_TOTAL_WINS_AS_MEDIUM = 6,
	PROGRESSION_TYPE_TOTAL_WINS_AS_HEAVY = 7,
	PROGRESSION_TYPE_WORLD_TOUR_SEASONAL_BADGE_SCORE = 8,
	PROGRESSION_TYPE_UNRANKED_QUICK_PLAY_SCORE = 9,
	PROGRESSION_TYPE_SPONSOR_LEVEL = 10,
	PROGRESSION_TYPE_LEAGUE_RANK = 11,
	PROGRESSION_TYPE_MAX = 12
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryQuestActiveOverride
enum class EApiGatewayDiscoveryQuestActiveOverride : uint8_t {
	DATES = 0,
	ACTIVE = 1,
	INACTIVE = 2,
	EApiGatewayDiscoveryQuestActiveOverride_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryRewardWheelRewardType
enum class EApiGatewayDiscoveryRewardWheelRewardType : uint8_t {
	LIMITED_TIME = 0,
	SPECIAL = 1,
	NORMAL = 2,
	HIGH_VALUE = 3,
	EApiGatewayDiscoveryRewardWheelRewardType_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryJoinTournamentStatus
enum class EApiGatewayDiscoveryJoinTournamentStatus : uint8_t {
	JOIN_TOURNAMENT_STATUS_UNSPECIFIED = 0,
	JOIN_TOURNAMENT_STATUS_PLAYING = 1,
	JOIN_TOURNAMENT_STATUS_FINISHED = 2,
	JOIN_TOURNAMENT_STATUS_QUEUEING = 3,
	JOIN_TOURNAMENT_STATUS_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryTournamentDifficulty
enum class EApiGatewayDiscoveryTournamentDifficulty : uint8_t {
	TOURNAMENT_DIFFICULTY_UNSPECIFIED = 0,
	TOURNAMENT_DIFFICULTY_EASIEST = 1,
	TOURNAMENT_DIFFICULTY_EASY = 2,
	TOURNAMENT_DIFFICULTY_NORMAL = 3,
	TOURNAMENT_DIFFICULTY_HARD = 4,
	TOURNAMENT_DIFFICULTY_HARDEST = 5,
	TOURNAMENT_DIFFICULTY_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryTournamentSkillRange
enum class EApiGatewayDiscoveryTournamentSkillRange : uint8_t {
	TOURNAMENT_SKILL_RANGE_UNSPECIFIED = 0,
	TOURNAMENT_SKILL_RANGE_IDEAL = 1,
	TOURNAMENT_SKILL_RANGE_MODERATE = 2,
	TOURNAMENT_SKILL_RANGE_WIDE = 3,
	TOURNAMENT_SKILL_RANGE_VERY_WIDE = 4,
	TOURNAMENT_SKILL_RANGE_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryTournamentMatchStatus
enum class EApiGatewayDiscoveryTournamentMatchStatus : uint8_t {
	MATCH_STATUS_UNSPECIFIED = 0,
	MATCH_STATUS_PENDING = 1,
	MATCH_STATUS_CONNECTING = 2,
	MATCH_STATUS_PLAYING = 3,
	MATCH_STATUS_FINISHED = 4,
	MATCH_STATUS_ABANDONED = 5,
	MATCH_STATUS_FAILED = 6,
	MATCH_STATUS_EXPIRED = 7,
	MATCH_STATUS_SKIPPED = 8,
	MATCH_STATUS_MAX = 9
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryTournamentTeamResultValue
enum class EApiGatewayDiscoveryTournamentTeamResultValue : uint8_t {
	TOURNAMENT_TEAM_RESULT_UNSPECIFIED = 0,
	TOURNAMENT_TEAM_RESULT_WIN = 1,
	TOURNAMENT_TEAM_RESULT_LOSS = 2,
	TOURNAMENT_TEAM_RESULT_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewayDiscoveryTournamentTeamStatus
enum class EApiGatewayDiscoveryTournamentTeamStatus : uint8_t {
	MISSING = 0,
	PLAYING = 1,
	KNOCKED_OUT = 2,
	QUALIFIED = 3,
	FINISHED = 4,
	EApiGatewayDiscoveryTournamentTeamStatus_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewaySharedServerSquadManagementStrategy
enum class EApiGatewaySharedServerSquadManagementStrategy : uint8_t {
	STATIC = 0,
	SHRINK_WRAP = 1,
	EApiGatewaySharedServerSquadManagementStrategy_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewaySharedServerPlayerActivityState
enum class EApiGatewaySharedServerPlayerActivityState : uint8_t {
	PLAYER_ACTIVITY_STATE_UNSPECIFIED = 0,
	IDLE = 1,
	MATCHMAKING = 2,
	IN_MATCH = 3,
	IN_TOURNAMENT = 4,
	IN_TOURNAMENT_MATCH = 5,
	IN_PRIVATE_LOBBY = 6,
	EApiGatewaySharedServerPlayerActivityState_MAX = 7
};

// Enum EmbarkApiGateway.EApiGatewaySharedChatMessageType
enum class EApiGatewaySharedChatMessageType : uint8_t {
	UNKNOWN = 0,
	PARTY = 1,
	PRIVATE_LOBBY = 2,
	CLAN = 3,
	WHISPER = 4,
	SQUAD = 5,
	EApiGatewaySharedChatMessageType_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewaySharedClaimClanTimelineMessageRequestPayloadType
enum class EApiGatewaySharedClaimClanTimelineMessageRequestPayloadType : uint8_t {
	Unspecified = 0,
	PartyUp = 1,
	DevMessage = 2,
	EApiGatewaySharedClaimClanTimelineMessageRequestPayloadType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedPartyInvitePermission
enum class EApiGatewaySharedPartyInvitePermission : uint8_t {
	UNSPECIFIED = 0,
	LEADER_ONLY = 1,
	EVERYONE = 2,
	EApiGatewaySharedPartyInvitePermission_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedPartyPrivacy
enum class EApiGatewaySharedPartyPrivacy : uint8_t {
	INVITE_ONLY = 0,
	OPEN = 1,
	EApiGatewaySharedPartyPrivacy_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewaySharedClaimClanTimelineMessageResponsePayloadType
enum class EApiGatewaySharedClaimClanTimelineMessageResponsePayloadType : uint8_t {
	Unspecified = 0,
	PartyUp = 1,
	DevMessage = 2,
	EApiGatewaySharedClaimClanTimelineMessageResponsePayloadType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedClanPrivacyMode
enum class EApiGatewaySharedClanPrivacyMode : uint8_t {
	CLAN_PRIVACY_UNSPECIFIED = 0,
	CLAN_PRIVACY_OPEN = 1,
	CLAN_PRIVACY_PRIVATE = 2,
	CLAN_PRIVACY_REQUEST_ONLY = 3,
	CLAN_PRIVACY_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedClanSearchView
enum class EApiGatewaySharedClanSearchView : uint8_t {
	NEWEST = 0,
	LARGEST = 1,
	RISING = 2,
	EApiGatewaySharedClanSearchView_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedClanTimelineMessagePayloadType
enum class EApiGatewaySharedClanTimelineMessagePayloadType : uint8_t {
	Unspecified = 0,
	PartyUp = 1,
	MemberJoined = 2,
	MemberLeft = 3,
	MemberRoleChanged = 4,
	DevMessage = 5,
	EApiGatewaySharedClanTimelineMessagePayloadType_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewaySharedDiscoveryCommunityUpdateMessageType
enum class EApiGatewaySharedDiscoveryCommunityUpdateMessageType : uint8_t {
	UNSPECIFIED = 0,
	CHRISTMAS_LTM = 1,
	CHRISTMAS_WT = 2,
	EApiGatewaySharedDiscoveryCommunityUpdateMessageType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedDiscoveryRankUpdateMessageReason
enum class EApiGatewaySharedDiscoveryRankUpdateMessageReason : uint8_t {
	RANK_UPDATE_REASON_UNSPECIFIED = 0,
	RANK_UPDATE_WEEKLY_SUMMARY = 1,
	RANK_UPDATE_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewaySharedDiscoveryRewardMessageType
enum class EApiGatewaySharedDiscoveryRewardMessageType : uint8_t {
	REWARD_UNSPECIFIED = 0,
	REWARD_GIVEAWAY = 1,
	REWARD_COLLECTION_EVENT = 2,
	REWARD_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedDisplayNameValidationError
enum class EApiGatewaySharedDisplayNameValidationError : uint8_t {
	UNSPECIFIED = 0,
	LENGTH = 1,
	CHARACTERSET = 2,
	CONSECUTIVE_DIGITS = 3,
	CONSECUTIVE_SYMBOLS = 4,
	SYMBOL_AT_END = 5,
	PROFANITY = 6,
	EApiGatewaySharedDisplayNameValidationError_MAX = 7
};

// Enum EmbarkApiGateway.EApiGatewaySharedFriendListUpdateType
enum class EApiGatewaySharedFriendListUpdateType : uint8_t {
	UNKNOWN = 0,
	FriendListUpdate_ADDED = 1,
	FriendListUpdate_REMOVED = 2,
	EApiGatewaySharedFriendListUpdateType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedFriendshipInfoFriendshipType
enum class EApiGatewaySharedFriendshipInfoFriendshipType : uint8_t {
	UNKNOWN = 0,
	MUTUAL = 1,
	NON_MUTUAL_OUTGOING = 2,
	NON_MUTUAL_INCOMING = 3,
	EApiGatewaySharedFriendshipInfoFriendshipType_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedFrontendPartyExpressionType
enum class EApiGatewaySharedFrontendPartyExpressionType : uint8_t {
	EMOTE = 0,
	EMOTICON = 1,
	GESTURE = 2,
	EApiGatewaySharedFrontendPartyExpressionType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedGameserverState
enum class EApiGatewaySharedGameserverState : uint8_t {
	UNSPECIFIED = 0,
	WAITING = 1,
	AVAILABLE = 2,
	EXPIRED = 3,
	EApiGatewaySharedGameserverState_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedServerInitializationState
enum class EApiGatewaySharedServerInitializationState : uint8_t {
	UNSPECIFIED = 0,
	INITIALIZING = 1,
	READY = 2,
	FAILURE = 3,
	SHUTDOWN = 4,
	EApiGatewaySharedServerInitializationState_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewaySharedGameTitle
enum class EApiGatewaySharedGameTitle : uint8_t {
	Discovery = 0,
	Pioneer = 1,
	EApiGatewaySharedGameTitle_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewaySharedSanctionItem
enum class EApiGatewaySharedSanctionItem : uint8_t {
	UNSPECIFIED = 0,
	RESTRICT_TEXT_CHAT = 1,
	RESTRICT_VOIP = 2,
	RESTRICT_MATCHMAKING = 3,
	RESTRICT_RANKED_MATCHMAKING = 4,
	EApiGatewaySharedSanctionItem_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewaySharedSharedParameterizedMessageAttachmentType
enum class EApiGatewaySharedSharedParameterizedMessageAttachmentType : uint8_t {
	Unspecified = 0,
	ExternalLinkButton = 1,
	DeepLinkButton = 2,
	Compensation = 3,
	EApiGatewaySharedSharedParameterizedMessageAttachmentType_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedSharedPlayerNameSanctionReason
enum class EApiGatewaySharedSharedPlayerNameSanctionReason : uint8_t {
	SHARED_PLAYER_NAME_SANCTION_REASON_UNSPECIFIED = 0,
	SHARED_PLAYER_NAME_SANCTION_REASON_REQUESTED = 1,
	SHARED_PLAYER_NAME_SANCTION_REASON_VIOLATION = 2,
	SHARED_PLAYER_NAME_SANCTION_REASON_VIOLATION_SEVERE = 3,
	SHARED_PLAYER_NAME_SANCTION_REASON_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedInboxMessagePayloadType
enum class EApiGatewaySharedInboxMessagePayloadType : uint8_t {
	Unspecified = 0,
	RawMessage = 1,
	ReportedUserBannedMessage = 2,
	SharedFriendRequestMessage = 3,
	SharedGiftRefundedMessage = 4,
	SharedLinkDiscordAccountMessage = 5,
	SharedMaintenanceAlertMessage = 6,
	SharedMaintenanceCompletedMessage = 7,
	SharedMissingSteamProductOwnershipMessage = 8,
	SharedPlayerConductWarningMessage = 9,
	SharedPlayerNameSanctionMessage = 10,
	SharedPlayerReportFeedbackMessage = 11,
	SharedParameterizedMessage = 12,
	PioneerChargebackProcessedMessage = 13,
	PioneerCheaterCompensationMessage = 14,
	PioneerCompensationMessage = 15,
	PioneerPermanentBanMessage = 16,
	PioneerRefundProcessedMessage = 17,
	PioneerTemporarySuspensionMessage = 18,
	PioneerServerSlamMessage = 19,
	PioneerCrossPromotionMessage = 20,
	PioneerDiscoRewardMessage = 21,
	PioneerPenaltyMessage = 22,
	DiscoveryClanInviteMessage = 23,
	DiscoveryClanNameSanctionMessage = 24,
	DiscoveryClanTagSanctionMessage = 25,
	DiscoveryCommunityUpdateMessage = 26,
	DiscoveryGiftMessage = 27,
	DiscoveryMaintenanceAlertMessage = 28,
	DiscoveryPatchNoteMessage = 29,
	DiscoveryPlaystylesIntroMessage = 30,
	DiscoveryRankDisqualifiedMessage = 31,
	DiscoveryRankUpdateMessage = 32,
	DiscoveryRankWelcomeMessage = 33,
	DiscoveryRewardMessage = 34,
	DiscoveryRookieContractsIntroMessage = 35,
	DiscoverySeasonEightWelcomeMessage = 36,
	DiscoverySeasonFiveWelcomeMessage = 37,
	DiscoverySeasonNineWelcomeMessage = 38,
	DiscoverySeasonTenWelcomeMessage = 39,
	DiscoveryTwitchRewards2Message = 40,
	DiscoverySeasonSevenWelcomeMessage = 41,
	DiscoverySeasonSixWelcomeMessage = 42,
	DiscoverySurveyMessage = 43,
	DiscoveryNameChangeIntroMessage = 44,
	DiscoveryPioPromoMessage = 45,
	DiscoveryCrossPromotionCircuitMessage = 46,
	DiscoveryPromoWithLinkAMessage = 47,
	DiscoveryPromoWithLinkBMessage = 48,
	DiscoveryPromoWithLinkCMessage = 49,
	DiscoveryPromoAMessage = 50,
	DiscoveryPromoBMessage = 51,
	DiscoveryPromoCMessage = 52,
	DiscoveryValentinesGiftMessage = 53,
	DiscoveryGenericAMessage = 54,
	DiscoveryGenericBMessage = 55,
	DiscoveryGenericCMessage = 56,
	DiscoveryGenericDMessage = 57,
	DiscoveryGenericEMessage = 58,
	EApiGatewaySharedInboxMessagePayloadType_MAX = 59
};

// Enum EmbarkApiGateway.EApiGatewaySharedSocialFrontendPartyEffectNotificationPayloadType
enum class EApiGatewaySharedSocialFrontendPartyEffectNotificationPayloadType : uint8_t {
	Unspecified = 0,
	FrontendPartyExpression = 1,
	FrontendPartyExpressionEmpty = 2,
	EApiGatewaySharedSocialFrontendPartyEffectNotificationPayloadType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedNotificationPayloadType
enum class EApiGatewaySharedNotificationPayloadType : uint8_t {
	Unspecified = 0,
	PartyChatMessageNotification = 1,
	ClanChatMessageNotification = 2,
	PrivateLobbyChatMessageNotification = 3,
	WhisperChatMessageNotification = 4,
	SquadChatMessageNotification = 5,
	PrivateLobbyCreateNotification = 6,
	PrivateLobbyMembersChangedNotification = 7,
	PrivateLobbyLeaderChangedNotification = 8,
	PrivateLobbyCurrentPartyJoinNotification = 9,
	PrivateLobbyUpdateNotification = 10,
	PrivateLobbyPlayerLeaveNotification = 11,
	PrivateLobbyMatchStartNotification = 12,
	PrivateLobbyPlayerKickNotification = 13,
	PrivateLobbySquadChangeNotification = 14,
	PrivateLobbyInviteNotification = 15,
	SocialPartyInvitationNotification = 16,
	SocialPlayerJoinNotification = 17,
	SocialPlayerFailsToJoinNotification = 18,
	SocialPlayerLeaveNotification = 19,
	SocialPlayerKickNotification = 20,
	SocialMatchmakingStartNotification = 21,
	SocialMatchmakingCancelNotification = 22,
	SocialMatchmakingCompleteNotification = 23,
	SocialUpdatePartyDataNotification = 24,
	SocialUpdatePartyMemberDataNotification = 25,
	SocialFriendHasNewTenancyUserNotification = 26,
	SocialFriendListUpdateNotification = 27,
	SocialReadyForMatchmakingNotification = 28,
	SocialUserPresenceUpdateNotification = 29,
	SocialPartyArrangeNotification = 30,
	SocialMentorshipInviteNotification = 31,
	SocialAnswerMentorshipInviteNotification = 32,
	SocialMentorshipRemovedNotification = 33,
	PartyPlayerInviteNotification = 34,
	PartyPlayerJoinNotification = 35,
	PartyPlayerKickNotification = 36,
	PartyPlayerLeaveNotification = 37,
	PartyPlayerReadyForMatchmakingNotification = 38,
	PartyPlayerCrossplayEnabledNotification = 39,
	PartyPlayerPlatformSessionIdNotification = 40,
	PartyAttributesChangedNotification = 41,
	SocialFrontendPartyEffectNotification = 42,
	ClanInviteNotification = 43,
	ClanInviteAnswerNotification = 44,
	ClanInviteWithdrawnNotification = 45,
	ClanMemberRoleChangedNotification = 46,
	ClanMemberJoinedNotification = 47,
	ClanMemberLeftNotification = 48,
	ClanMemberKickedNotification = 49,
	ClanApplicationNotification = 50,
	ClanApplicationAnswerNotification = 51,
	ClanApplicationWithdrawnNotification = 52,
	ClanTimelineMessageCreatedNotification = 53,
	ClanTimelineMessageUpdatedNotification = 54,
	ClanUpdatedNotification = 55,
	InboxUpdateNotification = 56,
	ContestantPackUpdatedNotification = 57,
	ProfileDataUpdatedNotification = 58,
	PartyInventoryChangedNotification = 59,
	EApiGatewaySharedNotificationPayloadType_MAX = 60
};

// Enum EmbarkApiGateway.EApiGatewaySharedSurveySettingsType
enum class EApiGatewaySharedSurveySettingsType : uint8_t {
	EARLYFEEDBACK = 0,
	HEALTHPOLL = 1,
	BETAIMPRESSIONS = 2,
	EApiGatewaySharedSurveySettingsType_MAX = 3
};

// Enum EmbarkApiGateway.EApiGatewaySharedMatchmakingMatchState
enum class EApiGatewaySharedMatchmakingMatchState : uint8_t {
	UNSPECIFIED = 0,
	MATCHING = 1,
	COMPLETED = 2,
	FAILED = 3,
	EApiGatewaySharedMatchmakingMatchState_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedMatchmakingPlatform
enum class EApiGatewaySharedMatchmakingPlatform : uint8_t {
	ALL = 0,
	XBOX = 1,
	PLAYSTATION = 2,
	PC = 3,
	CONSOLES = 4,
	XBOX_PC = 5,
	EApiGatewaySharedMatchmakingPlatform_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewaySharedMatchRedirectTarget
enum class EApiGatewaySharedMatchRedirectTarget : uint8_t {
	TOURNAMENTS = 0,
	GAMESERVER = 1,
	EApiGatewaySharedMatchRedirectTarget_MAX = 2
};

// Enum EmbarkApiGateway.EApiGatewaySharedMatchTimeEstimateState
enum class EApiGatewaySharedMatchTimeEstimateState : uint8_t {
	NOT_AVAILABLE = 0,
	VALID = 1,
	FAULTY = 2,
	NO_DATA = 3,
	EApiGatewaySharedMatchTimeEstimateState_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedMatchTimeEstimateStateV2
enum class EApiGatewaySharedMatchTimeEstimateStateV2 : uint8_t {
	NOT_AVAILABLE = 0,
	VALID = 1,
	FAULTY = 2,
	MISSING_DATA = 3,
	EApiGatewaySharedMatchTimeEstimateStateV2_MAX = 4
};

// Enum EmbarkApiGateway.EApiGatewaySharedPlayerActivityState
enum class EApiGatewaySharedPlayerActivityState : uint8_t {
	PLAYER_ACTIVITY_STATE_UNSPECIFIED = 0,
	IDLE = 1,
	MATCHMAKING = 2,
	IN_MATCH = 3,
	IN_TOURNAMENT = 4,
	IN_TOURNAMENT_MATCH = 5,
	IN_PRIVATE_LOBBY = 6,
	EApiGatewaySharedPlayerActivityState_MAX = 7
};

// Enum EmbarkApiGateway.EApiGatewaySharedSendChatMessageRequestName
enum class EApiGatewaySharedSendChatMessageRequestName : uint8_t {
	UNKNOWN = 0,
	PARTY_CHAT_MESSAGE = 1,
	PRIVATE_LOBBY_CHAT_MESSAGE = 2,
	CLAN_CHAT_MESSAGE = 3,
	WHISPER_CHAT_MESSAGE = 4,
	EApiGatewaySharedSendChatMessageRequestName_MAX = 5
};

// Enum EmbarkApiGateway.EApiGatewaySharedSendChatMessageRequestV2Type
enum class EApiGatewaySharedSendChatMessageRequestV2Type : uint8_t {
	Unspecified = 0,
	Party = 1,
	Clan = 2,
	PrivateLobby = 3,
	Whisper = 4,
	Squad = 5,
	EApiGatewaySharedSendChatMessageRequestV2Type_MAX = 6
};

// Enum EmbarkApiGateway.EApiGatewaySharedTriggerFrontendPartyEffectRequestType
enum class EApiGatewaySharedTriggerFrontendPartyEffectRequestType : uint8_t {
	Unspecified = 0,
	FrontendPartyExpression = 1,
	FrontendPartyExpressionEmpty = 2,
	EApiGatewaySharedTriggerFrontendPartyEffectRequestType_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerAdminBonusEffectKind
enum class EPioneerAdminBonusEffectKind : uint8_t {
	UNSPECIFIED = 0,
	ROUND_XP_MULTIPLIER = 1,
	REPAIR_EFFECTIVENESS_MULTIPLIER = 2,
	ROUND_CRAFTING_MULTIPLIER = 3,
	EPioneerAdminBonusEffectKind_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerAdminQuestState
enum class EPioneerAdminQuestState : uint8_t {
	QUEST_STATE_UNSPECIFIED = 0,
	QUEST_STATE_AWAITING = 1,
	QUEST_STATE_ACCEPTED = 2,
	QUEST_STATE_COMPLETED = 3,
	QUEST_STATE_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerAdminPlayerStatScopeType
enum class EPioneerAdminPlayerStatScopeType : uint8_t {
	Unspecified = 0,
	Unknown = 1,
	Global = 2,
	RankSeason = 3,
	RankWindow = 4,
	EPioneerAdminPlayerStatScopeType_MAX = 5
};

// Enum EmbarkApiGateway.EPioneerAdminCrateState
enum class EPioneerAdminCrateState : uint8_t {
	CRATE_STATE_UNKNOWN = 0,
	CRATE_STATE_AVAILABLE = 1,
	CRATE_STATE_OPENED = 2,
	CRATE_STATE_CLAIMED = 3,
	CRATE_STATE_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerAdminMutateInventoryMutationType
enum class EPioneerAdminMutateInventoryMutationType : uint8_t {
	Unspecified = 0,
	Create = 1,
	Update = 2,
	Delete = 3,
	EPioneerAdminMutateInventoryMutationType_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerAdminResetResource
enum class EPioneerAdminResetResource : uint8_t {
	RESET_ALL = 0,
	RESET_INVENTORY_ITEMS = 1,
	RESET_QUESTS = 2,
	RESET_OFFERS = 3,
	RESET_BUCKETS = 4,
	RESET_MASTERY = 5,
	RESET_MAX = 6
};

// Enum EmbarkApiGateway.EPioneerOnlineQuestState
enum class EPioneerOnlineQuestState : uint8_t {
	UNKNOWN = 0,
	AWAITING = 1,
	ACCEPTED = 2,
	COMPLETED = 3,
	EPioneerOnlineQuestState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlinePlayerStatScopeType
enum class EPioneerOnlinePlayerStatScopeType : uint8_t {
	Unspecified = 0,
	Unknown = 1,
	Global = 2,
	RankSeason = 3,
	RankWindow = 4,
	Raider = 5,
	EPioneerOnlinePlayerStatScopeType_MAX = 6
};

// Enum EmbarkApiGateway.EPioneerOnlineProgressionNotificationType
enum class EPioneerOnlineProgressionNotificationType : uint8_t {
	Unspecified = 0,
	CraftingXpGain = 1,
	LevelUp = 2,
	MasteryObjectiveRewardsReceived = 3,
	EPioneerOnlineProgressionNotificationType_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineOperationType
enum class EPioneerOnlineOperationType : uint8_t {
	Unspecified = 0,
	Recycle = 1,
	AcceptOffer = 2,
	EPioneerOnlineOperationType_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineBonusEffectKind
enum class EPioneerOnlineBonusEffectKind : uint8_t {
	UNSPECIFIED = 0,
	ROUND_XP_MULTIPLIER = 1,
	REPAIR_EFFECTIVENESS_MULTIPLIER = 2,
	ROUND_CRAFTING_MULTIPLIER = 3,
	EPioneerOnlineBonusEffectKind_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineBonusSourceKind
enum class EPioneerOnlineBonusSourceKind : uint8_t {
	UNSPECIFIED = 0,
	ADMIN = 1,
	EXPEDITION = 2,
	EPioneerOnlineBonusSourceKind_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineCompensationSourceType
enum class EPioneerOnlineCompensationSourceType : uint8_t {
	COMPENSATION_SOURCE_TYPE_UNSPECIFIED = 0,
	COMPENSATION_SOURCE_TYPE_ANTICHEAT = 1,
	COMPENSATION_SOURCE_TYPE_MAX = 2
};

// Enum EmbarkApiGateway.EPioneerOnlineCrateState
enum class EPioneerOnlineCrateState : uint8_t {
	UNKNOWN = 0,
	AVAILABLE = 1,
	OPENED = 2,
	CLAIMED = 3,
	EPioneerOnlineCrateState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineMasteryMilestoneRewardState
enum class EPioneerOnlineMasteryMilestoneRewardState : uint8_t {
	UNKNOWN = 0,
	LOCKED = 1,
	UNLOCKED = 2,
	CLAIMED = 3,
	EPioneerOnlineMasteryMilestoneRewardState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineMasteryObjectiveStreakState
enum class EPioneerOnlineMasteryObjectiveStreakState : uint8_t {
	UNSPECIFIED = 0,
	NONE = 1,
	INACTIVE = 2,
	ACTIVE = 3,
	EPioneerOnlineMasteryObjectiveStreakState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineCodexQuestUnlockOn
enum class EPioneerOnlineCodexQuestUnlockOn : uint8_t {
	ACCEPT = 0,
	COMPLETE = 1,
	EPioneerOnlineCodexQuestUnlockOn_MAX = 2
};

// Enum EmbarkApiGateway.EPioneerOnlineCommitItemByIdentityType
enum class EPioneerOnlineCommitItemByIdentityType : uint8_t {
	Unspecified = 0,
	CommitItemByAssetId = 1,
	CommitItemByInstanceId = 2,
	EPioneerOnlineCommitItemByIdentityType_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineProjectGoalState
enum class EPioneerOnlineProjectGoalState : uint8_t {
	UNSPECIFIED = 0,
	LOCKED = 1,
	IN_PROGRESS = 2,
	COMPLETED = 3,
	EPioneerOnlineProjectGoalState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineProjectState
enum class EPioneerOnlineProjectState : uint8_t {
	UNSPECIFIED = 0,
	IN_PROGRESS = 1,
	COMPLETED = 2,
	ABANDONED = 3,
	DEPARTED = 4,
	EPioneerOnlineProjectState_MAX = 5
};

// Enum EmbarkApiGateway.EPioneerOnlineDistributionPlatform
enum class EPioneerOnlineDistributionPlatform : uint8_t {
	UNKNOWN = 0,
	STEAM = 1,
	PLAYSTATION = 2,
	XBOX = 3,
	EPIC = 4,
	EPioneerOnlineDistributionPlatform_MAX = 5
};

// Enum EmbarkApiGateway.EPioneerOnlineExpeditionsState
enum class EPioneerOnlineExpeditionsState : uint8_t {
	UNSPECIFIED = 0,
	NOT_STARTED = 1,
	IN_PROGRESS = 2,
	READY = 3,
	COMMITTED = 4,
	DEPART = 5,
	DEPART_LAST_CHANCE = 6,
	EPioneerOnlineExpeditionsState_MAX = 7
};

// Enum EmbarkApiGateway.EPioneerOnlineItemConfigType
enum class EPioneerOnlineItemConfigType : uint8_t {
	Unspecified = 0,
	NoSlot = 1,
	SingleSlot = 2,
	ArraySlot = 3,
	StructuralSlot = 4,
	EPioneerOnlineItemConfigType_MAX = 5
};

// Enum EmbarkApiGateway.EPioneerOnlineQuestCadence
enum class EPioneerOnlineQuestCadence : uint8_t {
	UNKNOWN = 0,
	DAILY = 1,
	WEEKLY = 2,
	NARRATIVE = 3,
	RAID = 4,
	MILESTONE = 5,
	MASTERY = 6,
	EPioneerOnlineQuestCadence_MAX = 7
};

// Enum EmbarkApiGateway.EPioneerOnlineQuestDescriptionState
enum class EPioneerOnlineQuestDescriptionState : uint8_t {
	UNKNOWN = 0,
	ACCEPTED = 1,
	COMPLETED = 2,
	EPioneerOnlineQuestDescriptionState_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineQuestDescriptionObjectiveMusic
enum class EPioneerOnlineQuestDescriptionObjectiveMusic : uint8_t {
	UNSPECIFIED = 0,
	LOW_INTENSITY = 1,
	HIGH_INTENSITY = 2,
	EPioneerOnlineQuestDescriptionObjectiveMusic_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineRaiderProjectGoalType
enum class EPioneerOnlineRaiderProjectGoalType : uint8_t {
	CONTRIBUTE_AMOUNT_OF_ITEMS = 0,
	CONTRIBUTE_VALUE_OF_ITEMS = 1,
	CONTRIBUTE_MAX = 2
};

// Enum EmbarkApiGateway.EPioneerOnlineRaiderProjectType
enum class EPioneerOnlineRaiderProjectType : uint8_t {
	EXPEDITION = 0,
	SEASONAL = 1,
	GENERAL = 2,
	EPioneerOnlineRaiderProjectType_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineRaiderState
enum class EPioneerOnlineRaiderState : uint8_t {
	UNSPECIFIED = 0,
	ACTIVE = 1,
	LEFT = 2,
	EPioneerOnlineRaiderState_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineSteamProductSteamPackageType
enum class EPioneerOnlineSteamProductSteamPackageType : uint8_t {
	STEAM_PACKAGE_TYPE_UNSPECIFIED = 0,
	STEAM_PACKAGE_TYPE_INVENTORY = 1,
	STEAM_PACKAGE_TYPE_DLC = 2,
	STEAM_PACKAGE_TYPE_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerOnlineProductType
enum class EPioneerOnlineProductType : uint8_t {
	Unspecified = 0,
	EmbarkProduct = 1,
	EpicProduct = 2,
	SteamProduct = 3,
	MicrosoftProduct = 4,
	PlayStationProduct = 5,
	TwitchProduct = 6,
	EPioneerOnlineProductType_MAX = 7
};

// Enum EmbarkApiGateway.EPioneerOnlineStoreProvider
enum class EPioneerOnlineStoreProvider : uint8_t {
	UNKNOWN = 0,
	STEAM = 1,
	MICROSOFT = 2,
	PLAYSTATION = 3,
	EMBARK = 4,
	EPIC = 5,
	EPioneerOnlineStoreProvider_MAX = 6
};

// Enum EmbarkApiGateway.EPioneerOnlineSeasonalRewardInnerState
enum class EPioneerOnlineSeasonalRewardInnerState : uint8_t {
	UNKNOWN = 0,
	LOCKED = 1,
	UNLOCKED = 2,
	CLAIMED = 3,
	EPioneerOnlineSeasonalRewardInnerState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerOnlineMutateInventoryMutationType
enum class EPioneerOnlineMutateInventoryMutationType : uint8_t {
	Unspecified = 0,
	Create = 1,
	Update = 2,
	Delete = 3,
	Scrap = 4,
	Recycle = 5,
	Repair = 6,
	EPioneerOnlineMutateInventoryMutationType_MAX = 7
};

// Enum EmbarkApiGateway.EPioneerServerBonusEffectKind
enum class EPioneerServerBonusEffectKind : uint8_t {
	UNSPECIFIED = 0,
	ROUND_XP_MULTIPLIER = 1,
	REPAIR_EFFECTIVENESS_MULTIPLIER = 2,
	ROUND_CRAFTING_MULTIPLIER = 3,
	EPioneerServerBonusEffectKind_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerServerBonusSourceKind
enum class EPioneerServerBonusSourceKind : uint8_t {
	UNSPECIFIED = 0,
	ADMIN = 1,
	EXPEDITION = 2,
	EPioneerServerBonusSourceKind_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerServerCodexQuestUnlockOn
enum class EPioneerServerCodexQuestUnlockOn : uint8_t {
	ACCEPT = 0,
	COMPLETE = 1,
	EPioneerServerCodexQuestUnlockOn_MAX = 2
};

// Enum EmbarkApiGateway.EPioneerServerQuestDescriptionCadence
enum class EPioneerServerQuestDescriptionCadence : uint8_t {
	UNKNOWN = 0,
	DAILY = 1,
	WEEKLY = 2,
	NARRATIVE = 3,
	RAID = 4,
	MILESTONE = 5,
	MASTERY = 6,
	EPioneerServerQuestDescriptionCadence_MAX = 7
};

// Enum EmbarkApiGateway.EPioneerServerQuestDescriptionState
enum class EPioneerServerQuestDescriptionState : uint8_t {
	UNKNOWN = 0,
	ACCEPTED = 1,
	COMPLETED = 2,
	EPioneerServerQuestDescriptionState_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerServerQuestDescriptionObjectiveMusic
enum class EPioneerServerQuestDescriptionObjectiveMusic : uint8_t {
	UNSPECIFIED = 0,
	LOW_INTENSITY = 1,
	HIGH_INTENSITY = 2,
	EPioneerServerQuestDescriptionObjectiveMusic_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerServerItemConfigType
enum class EPioneerServerItemConfigType : uint8_t {
	Unspecified = 0,
	NoSlot = 1,
	SingleSlot = 2,
	ArraySlot = 3,
	StructuralSlot = 4,
	EPioneerServerItemConfigType_MAX = 5
};

// Enum EmbarkApiGateway.EPioneerServerPlayerStatScopeType
enum class EPioneerServerPlayerStatScopeType : uint8_t {
	Unspecified = 0,
	Unknown = 1,
	Global = 2,
	EPioneerServerPlayerStatScopeType_MAX = 3
};

// Enum EmbarkApiGateway.EPioneerServerMasteryMilestoneRewardState
enum class EPioneerServerMasteryMilestoneRewardState : uint8_t {
	UNKNOWN = 0,
	LOCKED = 1,
	UNLOCKED = 2,
	CLAIMED = 3,
	EPioneerServerMasteryMilestoneRewardState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerServerMasteryObjectiveStreakState
enum class EPioneerServerMasteryObjectiveStreakState : uint8_t {
	UNSPECIFIED = 0,
	NONE = 1,
	INACTIVE = 2,
	ACTIVE = 3,
	EPioneerServerMasteryObjectiveStreakState_MAX = 4
};

// Enum EmbarkApiGateway.EPioneerServerMutateInventoryMutationType
enum class EPioneerServerMutateInventoryMutationType : uint8_t {
	Unspecified = 0,
	Create = 1,
	Update = 2,
	Delete = 3,
	EPioneerServerMutateInventoryMutationType_MAX = 4
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityResponse {
	struct TArray<struct FApiGatewaySharedServerPlayerActivityEntry> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityEntry
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityEntry {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	int32_t State; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Etag; // 0x18(0x10)
	struct FString MatchId; // 0x28(0x10)
	struct FString TournamentId; // 0x38(0x10)
	struct FString TicketId; // 0x48(0x10)
	enum class EApiGatewaySharedServerPlayerActivityState CurrentState; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FString LobbyId; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityAbandonMatchResponse
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityAbandonMatchResponse {
	struct TArray<struct FTenancyUserId> ValidationFailed; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> WriteFailed; // 0x10(0x10)
	struct TArray<struct FString> Errors; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityFinishMatchResponse
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityFinishMatchResponse {
	struct TArray<struct FTenancyUserId> ValidationFailed; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> WriteFailed; // 0x10(0x10)
	struct TArray<struct FString> Errors; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedTweakables
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedTweakables {
	struct FString ObjectPathName; // 0x00(0x10)
	struct FString PropertyName; // 0x10(0x10)
	struct FString PropertyValue; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyMember
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedPartyMember {
	struct FApiGatewaySharedProfile Profile; // 0x00(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedProfile
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedProfile {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FEmbarkUserId AccountId; // 0x10(0x10)
	int64_t CreatedAt; // 0x20(0x08)
	struct FApiGatewaySharedDisplayName DisplayName; // 0x28(0x20)
	int64_t DisplayNameCooldownEndsAt; // 0x48(0x08)
	struct FString Email; // 0x50(0x10)
	bool EmailIsVerified; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	int64_t EmailVerifiedAt; // 0x68(0x08)
	struct FString ThirdPartyUserId; // 0x70(0x10)
	struct FString ThirdPartyLastSeenAccountName; // 0x80(0x10)
	struct FString TosVersionSeen; // 0x90(0x10)
	struct FString DateOfBirth; // 0xa0(0x10)
	struct FString CountryCode; // 0xb0(0x10)
	bool IsSpender; // 0xc0(0x01)
	bool VoiceChatModerationConsent; // 0xc1(0x01)
	char pad_c2[0x6]; // 0xc2(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDisplayName
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedDisplayName {
	struct FString Name; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialFrontendPartyEffectNotification
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedSocialFrontendPartyEffectNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedSocialFrontendPartyEffectNotificationPayload Payload; // 0x10(0x38)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialFrontendPartyEffectNotificationPayload
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedSocialFrontendPartyEffectNotificationPayload {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyChatMessageNotification
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewaySharedPartyChatMessageNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	struct FString Message; // 0x20(0x10)
	struct FString PurifiedMessage; // 0x30(0x10)
	bool Flagged; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	int64_t FromTenancyUserId; // 0x48(0x08)
	struct FString CreateTime; // 0x50(0x10)
	int32_t ClientMessageId; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyChatMessageNotification
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyChatMessageNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	struct FString Message; // 0x20(0x10)
	struct FString PurifiedMessage; // 0x30(0x10)
	bool Flagged; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	int64_t FromTenancyUserId; // 0x48(0x08)
	struct FString CreateTime; // 0x50(0x10)
	int32_t ClientMessageId; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquadChatMessageNotification
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedSquadChatMessageNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString Message; // 0x10(0x10)
	struct FString PurifiedMessage; // 0x20(0x10)
	bool Flagged; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	int64_t FromTenancyUserId; // 0x38(0x08)
	struct FString CreateTime; // 0x40(0x10)
	int32_t ClientMessageId; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedWhisperChatMessageNotification
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewaySharedWhisperChatMessageNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString Message; // 0x10(0x10)
	struct FString PurifiedMessage; // 0x20(0x10)
	bool Flagged; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	int64_t FromTenancyUserId; // 0x38(0x08)
	int64_t ToTenancyUserId; // 0x40(0x08)
	struct FString CreateTime; // 0x48(0x10)
	int32_t ClientMessageId; // 0x58(0x04)
	char pad_5c[0x4]; // 0x5c(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerReportServerHeartbeatResponse
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewaySharedServerReportServerHeartbeatResponse {
	struct TArray<struct FTenancyUserId> ExpectedConnectedPlayers; // 0x00(0x10)
	int64_t HeartbeatIntervalSeconds; // 0x10(0x08)
	struct FApiGatewaySharedServerSquadLayout SquadLayout; // 0x18(0x38)
	struct TArray<struct FTenancyUserId> AbandonedPlayers; // 0x50(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerSquadLayout
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedServerSquadLayout {
	int32_t MaxSquads; // 0x00(0x04)
	int32_t MaxSquadSize; // 0x04(0x04)
	int32_t MaxPlayers; // 0x08(0x04)
	enum class EApiGatewaySharedServerSquadManagementStrategy SquadManagementStrategy; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	int32_t MaxPlayerBuffer; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FApiGatewaySharedServerSquadInfo> SquadInfos; // 0x18(0x10)
	struct TArray<struct FApiGatewaySharedServerPlayerInfo> Spectators; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerInfo
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerInfo {
	struct FTenancyUserId PlayerId; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int32_t LeagueRankIndex; // 0x20(0x04)
	int32_t RankPoints; // 0x24(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerSquadInfo
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedServerSquadInfo {
	struct FString SquadId; // 0x00(0x10)
	int32_t SquadSize; // 0x10(0x04)
	int32_t SquadSeed; // 0x14(0x04)
	struct TArray<struct FApiGatewaySharedServerPlayerInfo> PlayerInfos; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerTweakables
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerTweakables {
	struct FString ObjectPathName; // 0x00(0x10)
	struct FString PropertyName; // 0x10(0x10)
	struct FString PropertyValue; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCanPlayerGiftResponse
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryCanPlayerGiftResponse {
	bool CanGift; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t RoundsCompleted; // 0x08(0x08)
	int64_t HardCurrencySpend; // 0x10(0x08)
	int64_t GiftsRemaining; // 0x18(0x08)
	bool OwnsPremiumBattlepass; // 0x20(0x01)
	bool UserCreatedRecently; // 0x21(0x01)
	bool FirstRealMoneyProductPurchasedRecently; // 0x22(0x01)
	char pad_23[0x5]; // 0x23(0x05)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetLeagueRankResponse
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetLeagueRankResponse {
	int64_t LeagueRankIndex; // 0x00(0x08)
	int64_t HighestLeagueRankIndex; // 0x08(0x08)
	int64_t RequiredPlacementRounds; // 0x10(0x08)
	int64_t CompletedRounds; // 0x18(0x08)
	int64_t Progress; // 0x20(0x08)
	int64_t RankScore; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceContestantPack
// Size: 0xf0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceContestantPack {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	int64_t CreatedAt; // 0x28(0x08)
	struct FString Title; // 0x30(0x10)
	struct FString Etag; // 0x40(0x10)
	struct FString ArchetypeInstanceId; // 0x50(0x10)
	struct TArray<struct FString> FirstHandInstanceIds; // 0x60(0x10)
	struct TArray<struct FString> ReservedInstanceIds; // 0x70(0x10)
	struct TArray<struct FString> CustomizationItemInstanceIds; // 0x80(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPackItemAttachment> ItemAttachments; // 0x90(0x10)
	struct FString SprayItemInstanceId; // 0xa0(0x10)
	struct TArray<struct FString> ExpressionItemInstanceIds; // 0xb0(0x10)
	struct TArray<struct FString> SprayWheelItemInstanceIds; // 0xc0(0x10)
	struct TArray<struct FString> EmoteWheelItemInstanceIds; // 0xd0(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPackSlot> Slots; // 0xe0(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceContestantPackSlot
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceContestantPackSlot {
	struct FString SlotName; // 0x00(0x10)
	struct TArray<struct FString> ItemInstanceIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceContestantPackItemAttachment
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceContestantPackItemAttachment {
	struct FString ItemInstanceId; // 0x00(0x10)
	struct TArray<struct FString> AttachedItemInstanceIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCollectionEventItem
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryCollectionEventItem {
	int64_t ID; // 0x00(0x08)
	int64_t RewardGameAssetId; // 0x08(0x08)
	struct TArray<int64_t> RewardProductIds; // 0x10(0x10)
	enum class EApiGatewayDiscoveryCollectionEventItemRewardType RewardType; // 0x20(0x01)
	enum class EApiGatewayDiscoveryCollectionEventItemState State; // 0x21(0x01)
	char pad_22[0x6]; // 0x22(0x06)
	int64_t TransitionedAt; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportMatchProgressResponse
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportMatchProgressResponse {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct TArray<struct FTenancyUserId> ExpectedConnectedPlayers; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSubmitMatchReportResponseV3
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSubmitMatchReportResponseV3 {
	struct TArray<struct FApiGatewayDiscoveryServerMatchReportSquadResponse> Squads; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerTournamentTeam> TournamentTeams; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerTournamentTeam
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerTournamentTeam {
	int32_t TeamIndex; // 0x00(0x04)
	int32_t BrandIndex; // 0x04(0x04)
	int32_t Seed; // 0x08(0x04)
	int32_t TournamentPosition; // 0x0c(0x04)
	int32_t Tier; // 0x10(0x04)
	enum class EApiGatewayDiscoveryServerTournamentTeamStatus Status; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerMatchReportSquadResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerMatchReportSquadResponse {
	struct TArray<struct FApiGatewayDiscoveryServerMatchReportSquadMemberResponse> Members; // 0x00(0x10)
	int64_t RankPointSum; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerMatchReportSquadMemberResponse
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerMatchReportSquadMemberResponse {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	int64_t RankIndexBefore; // 0x10(0x08)
	int64_t RankIndexAfter; // 0x18(0x08)
	int64_t RankPointsBefore; // 0x20(0x08)
	int64_t RankPointsAfter; // 0x28(0x08)
	int64_t TeamRankPointsDelta; // 0x30(0x08)
	int64_t IndividualRankPointsDelta; // 0x38(0x08)
	float TeamPerformanceNormalized; // 0x40(0x04)
	float IndividualPerformanceNormalized; // 0x44(0x04)
	int64_t CompletedMatches; // 0x48(0x08)
	int64_t PlacementMatches; // 0x50(0x08)
	enum class EApiGatewayDiscoveryServerTournamentDifficulty Difficulty; // 0x58(0x01)
	bool PenaltyApplied; // 0x59(0x01)
	bool LossReduced; // 0x5a(0x01)
	char pad_5b[0x5]; // 0x5b(0x05)
	double LossReductionFactor; // 0x60(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameServer
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameServer {
	struct FString Name; // 0x00(0x10)
	struct FString Host; // 0x10(0x10)
	int32_t Port; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString SecretKey; // 0x28(0x10)
	struct FString RoutingToken; // 0x38(0x10)
	bool ProxyEnabled; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrecalculatedTournamentResult
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrecalculatedTournamentResult {
	struct TArray<int64_t> RankScoreDeltas; // 0x00(0x10)
	enum class EApiGatewayDiscoveryTournamentDifficulty Difficulty; // 0x10(0x01)
	enum class EApiGatewayDiscoveryTournamentSkillRange SkillRange; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryTournamentTeam
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryTournamentTeam {
	int32_t TeamIndex; // 0x00(0x04)
	int32_t BrandIndex; // 0x04(0x04)
	struct TArray<struct FApiGatewayDiscoveryTournamentPlayer> Players; // 0x08(0x10)
	int32_t Seed; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	int64_t RankScore; // 0x20(0x08)
	int32_t TournamentPosition; // 0x28(0x04)
	int32_t Tier; // 0x2c(0x04)
	enum class EApiGatewayDiscoveryTournamentTeamStatus Status; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryTournamentPlayer
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryTournamentPlayer {
	struct FString ID; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	int64_t LeagueRankIndex; // 0x20(0x08)
	int64_t RankScore; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryTournamentMatch
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryTournamentMatch {
	int32_t Tier; // 0x00(0x04)
	int32_t Position; // 0x04(0x04)
	struct TArray<int32_t> Teams; // 0x08(0x10)
	struct TArray<struct FApiGatewayDiscoveryTournamentTeamResult> Results; // 0x18(0x10)
	int32_t ExpectedEndTime; // 0x28(0x04)
	int32_t ExpectedWinningTeams; // 0x2c(0x04)
	int32_t ExpectedPlayingTeams; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString ProgressData; // 0x38(0x10)
	enum class EApiGatewayDiscoveryTournamentMatchStatus Status; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryTournamentTeamResult
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoveryTournamentTeamResult {
	enum class EApiGatewayDiscoveryTournamentTeamResultValue Value; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryTournamentTier
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryTournamentTier {
	struct TArray<int32_t> Matches; // 0x00(0x10)
	int32_t Tier; // 0x10(0x04)
	bool IsFirstTier; // 0x14(0x01)
	bool IsFinalTier; // 0x15(0x01)
	bool IsQualifyingTier; // 0x16(0x01)
	char pad_17[0x1]; // 0x17(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRoundStats
// Size: 0x98 (Inherited: 0x00)
struct FApiGatewayDiscoveryRoundStats {
	struct FString TournamentId; // 0x00(0x10)
	struct FString RoundId; // 0x10(0x10)
	struct FString SquadName; // 0x20(0x10)
	int64_t Kills; // 0x30(0x08)
	int64_t Deaths; // 0x38(0x08)
	int64_t Dbnos; // 0x40(0x08)
	int64_t Respawns; // 0x48(0x08)
	float DamageDone; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	int64_t RevivesDone; // 0x58(0x08)
	int64_t RespawnsDone; // 0x60(0x08)
	struct FString MapVariant; // 0x68(0x10)
	bool RoundWon; // 0x78(0x01)
	bool TournamentWon; // 0x79(0x01)
	char pad_7a[0x6]; // 0x7a(0x06)
	int64_t StartTime; // 0x80(0x08)
	int64_t EndTime; // 0x88(0x08)
	int64_t PlacedAt; // 0x90(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetRoundStatSummaryResponse
// Size: 0xaa0 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetRoundStatSummaryResponse {
	struct FApiGatewayDiscoveryRoundStatSummary Casual; // 0x00(0x2a0)
	struct FApiGatewayDiscoveryRoundStatSummary Ranked; // 0x2a0(0x2a0)
	struct FApiGatewayDiscoveryRoundStatSummary Total; // 0x540(0x2a0)
	struct FApiGatewayDiscoveryWorldTourRoundStatSummary WorldTour; // 0x7e0(0x2c0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryWorldTourRoundStatSummary
// Size: 0x2c0 (Inherited: 0x00)
struct FApiGatewayDiscoveryWorldTourRoundStatSummary {
	struct FApiGatewayDiscoveryRoundStatSummary SummaryData; // 0x00(0x2a0)
	struct FApiGatewayDiscoveryWorldTourEventSummary EventData; // 0x2a0(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryWorldTourEventSummary
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryWorldTourEventSummary {
	int64_t TotalEventsParticipated; // 0x00(0x08)
	int64_t LastEventIdentifier; // 0x08(0x08)
	int64_t WorldTourBadgeScore; // 0x10(0x08)
	int64_t WorldTourFinalsWon; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRoundStatSummary
// Size: 0x2a0 (Inherited: 0x00)
struct FApiGatewayDiscoveryRoundStatSummary {
	int64_t Kills; // 0x00(0x08)
	int64_t Deaths; // 0x08(0x08)
	struct TMap<struct FString, int64_t> KillsPerItem; // 0x10(0x50)
	struct TMap<struct FString, float> DamagePerItem; // 0x60(0x50)
	int64_t TimePlayed; // 0xb0(0x08)
	struct TMap<struct FString, int64_t> TimePlayedPerArchetype; // 0xb8(0x50)
	float RoundWinRate; // 0x108(0x04)
	char pad_10c[0x4]; // 0x10c(0x04)
	struct TMap<struct FString, float> RoundWinRatePerArchetype; // 0x110(0x50)
	float TournamentWinRate; // 0x160(0x04)
	char pad_164[0x4]; // 0x164(0x04)
	struct TMap<struct FString, float> TournamentWinRatePerArchetype; // 0x168(0x50)
	int64_t HighestFameAmount; // 0x1b8(0x08)
	int64_t RoundsPlayed; // 0x1c0(0x08)
	int64_t RoundsCompleted; // 0x1c8(0x08)
	int64_t RevivesDone; // 0x1d0(0x08)
	int64_t RoundsWon; // 0x1d8(0x08)
	int64_t RoundsJoined; // 0x1e0(0x08)
	int64_t TotalCashOut; // 0x1e8(0x08)
	struct TMap<struct FString, int64_t> WinsPerMatchmakingScenario; // 0x1f0(0x50)
	struct TMap<struct FString, struct FApiGatewayDiscoveryMatchmakingStreakSummary> WinStreakPerMatchmakingScenario; // 0x240(0x50)
	struct TArray<struct FApiGatewayDiscoveryScorecardSummary> Scorecards; // 0x290(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryScorecardSummary
// Size: 0xb0 (Inherited: 0x00)
struct FApiGatewayDiscoveryScorecardSummary {
	int64_t GameAssetId; // 0x00(0x08)
	struct TMap<struct FString, float> SeasonalAverageScore; // 0x08(0x50)
	struct TMap<struct FString, float> SeasonalBestScore; // 0x58(0x50)
	float CurrentAverageScore; // 0xa8(0x04)
	float CurrentBestScore; // 0xac(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMatchmakingStreakSummary
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryMatchmakingStreakSummary {
	int64_t Streak; // 0x00(0x08)
	struct FString LastWin; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetSurveySettingsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetSurveySettingsResponse {
	struct TArray<struct FApiGatewaySharedSurveySettings> Surveys; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSurveySettings
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSurveySettings {
	struct FString URL; // 0x00(0x10)
	bool IsActive; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	int32_t Rounds; // 0x14(0x04)
	enum class EApiGatewaySharedSurveySettingsType Type; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAdminAddFansRequest
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryAdminAddFansRequest {
	int64_t Fans; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAdminRoundStats
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryAdminRoundStats {
	int64_t Kills; // 0x00(0x08)
	int64_t Deaths; // 0x08(0x08)
	int64_t RevivesDone; // 0x10(0x08)
	bool RoundWon; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAdminAddRoundStatsRequest
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryAdminAddRoundStatsRequest {
	struct FApiGatewayDiscoveryAdminRoundStats RoundDescription; // 0x00(0x20)
	int64_t Amount; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAdminGiveCurrencyRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryAdminGiveCurrencyRequest {
	int64_t Amount; // 0x00(0x08)
	enum class EApiGatewayDiscoveryAdminCurrencyType CurrencyType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAdminResetTenancyUserResourcesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryAdminResetTenancyUserResourcesRequest {
	struct TArray<enum class EApiGatewayDiscoveryAdminResetResource> Resources; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerAbandonPlayerRequest
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerAbandonPlayerRequest {
	struct FTenancyUserId UserId; // 0x00(0x10)
	int64_t TimeOfAbandon; // 0x10(0x08)
	bool ImposeSanction; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString GameServer; // 0x20(0x10)
	bool ForceSanction; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerAbandonPlayerRequestV2
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerAbandonPlayerRequestV2 {
	struct FString TournamentId; // 0x00(0x10)
	struct FTenancyUserId UserId; // 0x10(0x10)
	int64_t TimeOfAbandon; // 0x20(0x08)
	bool ImposeSanction; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString GameServer; // 0x30(0x10)
	bool ForceSanction; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerAbandonPlayerResponse
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerAbandonPlayerResponse {
	int64_t SanctionDuration; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerBattlePassCategory
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerBattlePassCategory {
	int64_t GameAssetId; // 0x00(0x08)
	struct FString Category; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerBattlePassMetadata
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerBattlePassMetadata {
	int64_t PackId; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryServerBattlePassCategory> Categories; // 0x08(0x10)
	int64_t RankBucketAssetId; // 0x18(0x08)
	int64_t SeasonNumber; // 0x20(0x08)
	int64_t EventID; // 0x28(0x08)
	enum class EApiGatewayDiscoveryServerBattlePassKind BattlePassKind; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerClanOverrides
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerClanOverrides {
	struct FString Name; // 0x00(0x10)
	struct FString Tag; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerClansCustomization
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerClansCustomization {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryElevenLabsVoiceSettings
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryElevenLabsVoiceSettings {
	float Stability; // 0x00(0x04)
	float Style; // 0x04(0x04)
	float SimilarityBoost; // 0x08(0x04)
	bool UseSpeakerBoost; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParameters
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParameters {
	enum class EApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParametersProvider Provider; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Model; // 0x08(0x10)
	struct FString VoiceId; // 0x18(0x10)
	struct FApiGatewayDiscoveryServerDynamicCommentaryElevenLabsVoiceSettings VoiceSettings; // 0x28(0x10)
	enum class EApiGatewayDiscoveryServerDynamicCommentaryAudioOutputFormat OutputFormat; // 0x38(0x01)
	enum class EApiGatewayDiscoveryServerDynamicCommentaryTextNormalization ApplyTextNormalization; // 0x39(0x01)
	char pad_3a[0x6]; // 0x3a(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryAudioRequest
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryAudioRequest {
	struct FString Text; // 0x00(0x10)
	struct FApiGatewayDiscoveryServerDynamicCommentaryElevenLabsParameters Params; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryAudioResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryAudioResponse {
	struct FString URL; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryOpenAIParameters
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryOpenAIParameters {
	enum class EApiGatewayDiscoveryServerDynamicCommentaryOpenAIParametersProvider Provider; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Model; // 0x08(0x10)
	float Temperature; // 0x18(0x04)
	enum class EApiGatewayDiscoveryServerDynamicCommentaryOpenAIReasoningEffort ReasoningEffort; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryResolveNameEntry
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryResolveNameEntry {
	enum class EApiGatewayDiscoveryServerDynamicCommentaryResolveNameType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString EmbarkUserId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryResolveNameResult
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryResolveNameResult {
	enum class EApiGatewayDiscoveryServerDynamicCommentaryResolveNameStatus Status; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Output; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryResolveNamesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryResolveNamesRequest {
	struct TArray<struct FApiGatewayDiscoveryServerDynamicCommentaryResolveNameEntry> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryResolveNamesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryResolveNamesResponse {
	struct TArray<struct FApiGatewayDiscoveryServerDynamicCommentaryResolveNameResult> Results; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryTextRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryTextRequest {
	struct FString Prompt; // 0x00(0x10)
	struct FApiGatewayDiscoveryServerDynamicCommentaryOpenAIParameters Params; // 0x10(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerDynamicCommentaryTextResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerDynamicCommentaryTextResponse {
	struct FString Text; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGameStorePackageItem
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGameStorePackageItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	bool Owned; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGameStoreEmbarkAttributes
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGameStoreEmbarkAttributes {
	struct TArray<struct FApiGatewayDiscoveryServerGameStorePackageItem> CostPackageItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGameStoreEpicAttributes
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGameStoreEpicAttributes {
	struct FString ItemId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGameStorePlaystationAttributes
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGameStorePlaystationAttributes {
	struct FString EntitlementLabel; // 0x00(0x10)
	struct FString NpTitleId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGameStoreSteamAttributes
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGameStoreSteamAttributes {
	enum class EApiGatewayDiscoveryServerGameStoreSteamAttributesPackageType PackageType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Currency; // 0x08(0x10)
	int64_t InitialPrice; // 0x18(0x08)
	int64_t FinalPrice; // 0x20(0x08)
	int64_t DiscountPercent; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGameStoreProduct
// Size: 0xd0 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGameStoreProduct {
	enum class EApiGatewayDiscoveryServerGameStoreProvider Provider; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t ProductId; // 0x08(0x08)
	int64_t LayoutId; // 0x10(0x08)
	int64_t ViewId; // 0x18(0x08)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString GameStoreOfferId; // 0x28(0x10)
	bool Acquired; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FApiGatewayDiscoveryServerGameStorePackageItem> EntitlementPackageItems; // 0x40(0x10)
	struct FApiGatewayDiscoveryServerGameStoreEmbarkAttributes EmbarkAttributes; // 0x50(0x10)
	struct FApiGatewayDiscoveryServerGameStoreEpicAttributes EpicAttributes; // 0x60(0x10)
	struct FApiGatewayDiscoveryServerGameStorePlaystationAttributes PlaystationAttributes; // 0x70(0x20)
	struct FApiGatewayDiscoveryServerGameStoreSteamAttributes SteamAttributes; // 0x90(0x30)
	int64_t StartTime; // 0xc0(0x08)
	int64_t EndTime; // 0xc8(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGetActiveBattlePassesMetadataResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGetActiveBattlePassesMetadataResponse {
	struct TArray<struct FApiGatewayDiscoveryServerBattlePassMetadata> BattlePasses; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPersistentEntity
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPersistentEntity {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString RawProperties; // 0x30(0x10)
	int64_t CreatedAt; // 0x40(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceAnimationCustomizationItem
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceAnimationCustomizationItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Amount; // 0x28(0x08)
	bool HasSeen; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceArchetype
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceArchetype {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	struct TArray<struct FString> GameItemInstanceIds; // 0x28(0x10)
	struct TArray<struct FString> SkinInstanceIds; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceBattlePass
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceBattlePass {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	struct TArray<int64_t> ClaimedEntries; // 0x28(0x10)
	int64_t ConsumedLevels; // 0x38(0x08)
	int64_t Amount; // 0x40(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceContestantPackItemAttachment
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceContestantPackItemAttachment {
	struct FString ItemInstanceId; // 0x00(0x10)
	struct TArray<struct FString> AttachedItemInstanceIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceContestantPackSlot
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceContestantPackSlot {
	struct FString SlotName; // 0x00(0x10)
	struct TArray<struct FString> ItemInstanceIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceContestantPack
// Size: 0xe0 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceContestantPack {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Title; // 0x18(0x10)
	struct FString Etag; // 0x28(0x10)
	struct FString ArchetypeInstanceId; // 0x38(0x10)
	struct TArray<struct FString> FirstHandInstanceIds; // 0x48(0x10)
	struct TArray<struct FString> ReservedInstanceIds; // 0x58(0x10)
	struct TArray<struct FString> CustomizationItemInstanceIds; // 0x68(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceContestantPackItemAttachment> ItemAttachments; // 0x78(0x10)
	struct FString SprayItemInstanceId; // 0x88(0x10)
	struct TArray<struct FString> SprayWheelItemInstanceIds; // 0x98(0x10)
	struct TArray<struct FString> EmoteWheelItemInstanceIds; // 0xa8(0x10)
	struct TArray<struct FString> ExpressionItemInstanceIds; // 0xb8(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceContestantPackSlot> Slots; // 0xc8(0x10)
	int64_t CreatedAt; // 0xd8(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceCurrency
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceCurrency {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Amount; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceCustomizationItem
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceCustomizationItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceEmoticon
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceEmoticon {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceFame
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceFame {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceGameItem
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceGameItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Amount; // 0x28(0x08)
	bool HasSeen; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	int64_t CreatedAt; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceLoadout
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceLoadout {
	struct FString InstanceId; // 0x00(0x10)
	struct FString Etag; // 0x10(0x10)
	struct FString SelectedContestantPackInstanceId; // 0x20(0x10)
	int64_t CosmeticNumber; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistencePlayerCardSlot
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistencePlayerCardSlot {
	struct FString SlotName; // 0x00(0x10)
	struct FString ItemInstanceId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistencePlayerCard
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistencePlayerCard {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	struct FString BackgroundInstanceId; // 0x28(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistencePlayerCardSlot> Slots; // 0x38(0x10)
	int64_t UpdatedAt; // 0x48(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistencePlayerCardCustomization
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistencePlayerCardCustomization {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Level; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceQuestReward
// Size: 0xf0 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceQuestReward {
	int64_t RequiredProgress; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	int64_t RankBucketID; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct FApiGatewayDiscoveryServerGameStoreProduct Product; // 0x20(0xd0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceQuest
// Size: 0x150 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceQuest {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Amount; // 0x28(0x08)
	int64_t ExpiresAt; // 0x30(0x08)
	int32_t Week; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
	struct FApiGatewayDiscoveryServerPlayerPersistenceQuestReward Reward; // 0x40(0xf0)
	int64_t SlotId; // 0x130(0x08)
	bool Accepted; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	int64_t CreatedAt; // 0x140(0x08)
	int64_t UpdatedAt; // 0x148(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceQuestStage
// Size: 0x108 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceQuestStage {
	int64_t StartsAt; // 0x00(0x08)
	struct FApiGatewayDiscoveryServerPlayerPersistenceQuestReward Reward; // 0x08(0xf0)
	struct TArray<struct FString> QuestInstanceIds; // 0xf8(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceQuestCircuit
// Size: 0x108 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceQuestCircuit {
	int64_t StartsAt; // 0x00(0x08)
	struct FApiGatewayDiscoveryServerPlayerPersistenceQuestReward Reward; // 0x08(0xf0)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceQuestStage> Stages; // 0xf8(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceQuestContext
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceQuestContext {
	struct TArray<struct FString> DailyquestInstanceIds; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceQuestCircuit> Circuits; // 0x10(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceQuestCircuit> Ftue; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceQuestCircuit> Events; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceSanction
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceSanction {
	struct FString InstanceId; // 0x00(0x10)
	struct FString Etag; // 0x10(0x10)
	enum class EApiGatewayDiscoveryServerSanctionType SanctionType; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t Tier; // 0x24(0x04)
	int64_t TimeOfSanction; // 0x28(0x08)
	int64_t Duration; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceSkill
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceSkill {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Amount; // 0x28(0x08)
	bool HasSeen; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceSpray
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceSpray {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceWeaponAttachment
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponAttachment {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceWeaponCharm
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponCharm {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceWeaponSkin
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponSkin {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerPersistenceWeaponSticker
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponSticker {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	bool HasSeen; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGetInventoryResponse
// Size: 0x218 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGetInventoryResponse {
	struct FApiGatewayDiscoveryServerPlayerPersistenceLoadout Loadout; // 0x00(0x38)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceSanction> Sanctions; // 0x38(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceGameItem> GameItems; // 0x48(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceContestantPack> ContestantPacks; // 0x58(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceArchetype> Archetypes; // 0x68(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceCurrency> Currencies; // 0x78(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponSkin> WeaponSkins; // 0x88(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceCustomizationItem> CustomizationItems; // 0x98(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceBattlePass> BattlePasses; // 0xa8(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceQuest> Quests; // 0xb8(0x10)
	struct FApiGatewayDiscoveryServerPlayerPersistenceQuestContext QuestContext; // 0xc8(0x40)
	struct FApiGatewayDiscoveryServerPlayerPersistenceFame Fame; // 0x108(0x20)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponCharm> WeaponCharms; // 0x128(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponSticker> WeaponStickers; // 0x138(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceSpray> Sprays; // 0x148(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceSkill> Skills; // 0x158(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceEmoticon> Emoticons; // 0x168(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceAnimationCustomizationItem> AnimationCustomizationItems; // 0x178(0x10)
	struct FApiGatewayDiscoveryServerPlayerPersistencePlayerCard PlayerCard; // 0x188(0x50)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistencePlayerCardCustomization> PlayerCardCustomizations; // 0x1d8(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPlayerPersistenceWeaponAttachment> WeaponAttachments; // 0x1e8(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerClansCustomization> ClansCustomizations; // 0x1f8(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerPersistentEntity> PersistentEntities; // 0x208(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGetLiveBattlePassDescriptionResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGetLiveBattlePassDescriptionResponse {
	int64_t SeasonNumber; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryServerBattlePassCategory> Categories; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerCareer
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerCareer {
	int64_t Fans; // 0x00(0x08)
	int64_t SelectedSponsor; // 0x08(0x08)
	int64_t SponsorLevel; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSubscriptions
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSubscriptions {
	bool MicrosoftGamePass; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerWinStreak
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerWinStreak {
	int64_t Streak; // 0x00(0x08)
	struct FString LastWin; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerWorldTourSummary
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerWorldTourSummary {
	struct TMap<struct FString, int64_t> WinsPerScenarioId; // 0x00(0x50)
	int64_t TotalEventsParticipated; // 0x50(0x08)
	float TournamentWinRate; // 0x58(0x04)
	char pad_5c[0x4]; // 0x5c(0x04)
	int64_t WorldTourBadgeScore; // 0x60(0x08)
	int64_t WorldTourFinalsWon; // 0x68(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerPlayerInfo
// Size: 0x1a0 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerPlayerInfo {
	struct FTenancyUserId UserId; // 0x00(0x10)
	int64_t CareerLevel; // 0x10(0x08)
	struct TMap<struct FString, struct FApiGatewayDiscoveryServerWinStreak> WinStreaksPerScenarioId; // 0x18(0x50)
	struct FApiGatewayDiscoveryServerWorldTourSummary WorldTourSummary; // 0x68(0x70)
	int64_t RoundsWon; // 0xd8(0x08)
	int64_t RoundsPlayed; // 0xe0(0x08)
	int64_t RoundsCompleted; // 0xe8(0x08)
	int64_t Kills; // 0xf0(0x08)
	int64_t RevivesDone; // 0xf8(0x08)
	struct FApiGatewayDiscoveryServerPlayerCareer Career; // 0x100(0x18)
	struct FString ClanId; // 0x118(0x10)
	struct FString ClanTag; // 0x128(0x10)
	int64_t ClanLogo; // 0x138(0x08)
	struct FApiGatewayDiscoveryServerClanOverrides ClanOverrides; // 0x140(0x20)
	struct FString AnonymousName; // 0x160(0x10)
	struct FApiGatewayDiscoveryServerSubscriptions Subscriptions; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct FTenancyUserId MentorTenancyUserId; // 0x178(0x10)
	int64_t ReferralXpRank; // 0x188(0x08)
	int64_t ReferralXpRequiredToNextRank; // 0x190(0x08)
	bool HasUltimateBattlePass; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGetPlayerInfoResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGetPlayerInfoResponse {
	struct TArray<struct FApiGatewayDiscoveryServerPlayerInfo> PlayerInfos; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerQuestStage
// Size: 0x128 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerQuestStage {
	int64_t StageId; // 0x00(0x08)
	int64_t StartsAt; // 0x08(0x08)
	int64_t EndsAt; // 0x10(0x08)
	enum class EApiGatewayDiscoveryServerQuestActiveOverride Override; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FApiGatewayDiscoveryServerPlayerPersistenceQuestReward Reward; // 0x20(0xf0)
	int64_t GameAssetId; // 0x110(0x08)
	struct TArray<int64_t> QuestSlotIds; // 0x118(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerQuestCircuit
// Size: 0x120 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerQuestCircuit {
	int64_t CircuitId; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	int64_t StartsAt; // 0x10(0x08)
	int64_t EndsAt; // 0x18(0x08)
	struct FApiGatewayDiscoveryServerPlayerPersistenceQuestReward Reward; // 0x20(0xf0)
	struct TArray<struct FApiGatewayDiscoveryServerQuestStage> Stages; // 0x110(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerGetQuestDescriptionResponse
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerGetQuestDescriptionResponse {
	struct TArray<int64_t> DailyQuestSlotIds; // 0x00(0x10)
	int64_t DailyQuestNextRerollAt; // 0x10(0x08)
	struct TArray<int64_t> DailyClanQuestSlotIds; // 0x18(0x10)
	int64_t DailyClanQuestMaxAccepted; // 0x28(0x08)
	struct TArray<struct FApiGatewayDiscoveryServerQuestCircuit> Circuits; // 0x30(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerQuestCircuit> Ftue; // 0x40(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerQuestCircuit> Events; // 0x50(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerQuestCircuit> WorldTourEvents; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerKeyValuePair
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerKeyValuePair {
	struct FString Key; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportHeartbeatRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportHeartbeatRequest {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct FString GameServer; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportHeartbeatResponse
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportHeartbeatResponse {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportMatchProgressRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportMatchProgressRequest {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct FString MatchProgressData; // 0x20(0x10)
	int32_t ExpectedEndTime; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString GameServer; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportMatchResultRequest
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportMatchResultRequest {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct TArray<int32_t> WinningTeams; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryServerKeyValuePair> TravelData; // 0x30(0x10)
	struct FString GameServer; // 0x40(0x10)
	struct FString GameStateTravelData; // 0x50(0x10)
	bool Cancelled; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportMatchResultResponse
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportMatchResultResponse {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerReportServerKickRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerReportServerKickRequest {
	struct FTenancyUserId UserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerResolveSanctionsRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerResolveSanctionsRequest {
	struct FString TournamentId; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> UserIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerResolveSanctionsResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerResolveSanctionsResponse {
	int32_t ResolvedCount; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FTenancyUserId> FailedUserIds; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSquad
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSquad {
	struct TArray<struct FTenancyUserId> Players; // 0x00(0x10)
	int64_t Cash; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSquadMatchMember
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSquadMatchMember {
	int64_t ConnectionState; // 0x00(0x08)
	struct FTenancyUserId TenancyUserId; // 0x08(0x10)
	bool WasBackfill; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString PartyId; // 0x20(0x10)
	float ConnectionPercentage; // 0x30(0x04)
	bool ApplyPenalty; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	int64_t CombatScore; // 0x38(0x08)
	int64_t SupportScore; // 0x40(0x08)
	int64_t ObjectiveScore; // 0x48(0x08)
	int64_t Kills; // 0x50(0x08)
	int64_t Deaths; // 0x58(0x08)
	int64_t Assists; // 0x60(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSquadMatchInfo
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSquadMatchInfo {
	struct TArray<struct FApiGatewayDiscoveryServerSquadMatchMember> Members; // 0x00(0x10)
	int64_t Cash; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSubmitMatchReportRequest
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSubmitMatchReportRequest {
	struct TArray<struct FApiGatewayDiscoveryServerSquad> Squads; // 0x00(0x10)
	struct FString ScenarioId; // 0x10(0x10)
	struct FString GacMatchId; // 0x20(0x10)
	struct FString RequestID; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSubmitMatchReportRequestV2
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSubmitMatchReportRequestV2 {
	struct TArray<struct FApiGatewayDiscoveryServerSquadMatchInfo> Squads; // 0x00(0x10)
	struct FString ScenarioId; // 0x10(0x10)
	struct FString GacMatchId; // 0x20(0x10)
	bool Cancelled; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString RequestID; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerSubmitMatchReportRequestV3
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerSubmitMatchReportRequestV3 {
	struct TArray<struct FApiGatewayDiscoveryServerSquadMatchInfo> Squads; // 0x00(0x10)
	struct FString ScenarioId; // 0x10(0x10)
	struct FString GacMatchId; // 0x20(0x10)
	bool Cancelled; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString RequestID; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerUserInventory
// Size: 0x228 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerUserInventory {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct FApiGatewayDiscoveryServerGetInventoryResponse Inventory; // 0x10(0x218)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerUserInventories
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerUserInventories {
	struct TArray<struct FApiGatewayDiscoveryServerUserInventory> Items; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryServerUserRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryServerUserRequest {
	struct TArray<struct FTenancyUserId> UserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAbandonPlayerRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryAbandonPlayerRequest {
	struct FString TournamentId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAcceptQuestRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryAcceptQuestRequest {
	struct FString QuestInstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryClansCustomization
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryClansCustomization {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreBundledProduct
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreBundledProduct {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t ProductId; // 0x08(0x08)
	int64_t FinalPrice; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStorePackageItem
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStorePackageItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	bool Owned; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreProductCost
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreProductCost {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreEmbarkAttributes
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreEmbarkAttributes {
	struct TArray<struct FApiGatewayDiscoveryGameStorePackageItem> CostPackageItems; // 0x00(0x10)
	int64_t InitialPrice; // 0x10(0x08)
	struct FApiGatewayDiscoveryGameStoreProductCost UserCost; // 0x18(0x10)
	struct FApiGatewayDiscoveryGameStoreProductCost UserValue; // 0x28(0x10)
	struct FApiGatewayDiscoveryGameStoreProductCost OriginalCost; // 0x38(0x10)
	struct FApiGatewayDiscoveryGameStoreProductCost OriginalValue; // 0x48(0x10)
	struct TArray<struct FApiGatewayDiscoveryGameStoreBundledProduct> BundledProducts; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreEpicAttributes
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreEpicAttributes {
	struct FString ItemId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStorePlaystationAttributes
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStorePlaystationAttributes {
	struct FString EntitlementLabel; // 0x00(0x10)
	struct FString NpTitleId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreSteamAttributes
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreSteamAttributes {
	enum class EApiGatewayDiscoveryGameStoreSteamAttributesPackageType PackageType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Currency; // 0x08(0x10)
	int64_t InitialPrice; // 0x18(0x08)
	int64_t FinalPrice; // 0x20(0x08)
	int64_t DiscountPercent; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreProduct
// Size: 0x130 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreProduct {
	enum class EApiGatewayDiscoveryGameStoreProvider Provider; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t ProductId; // 0x08(0x08)
	int64_t LayoutId; // 0x10(0x08)
	int64_t ViewId; // 0x18(0x08)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString GameStoreOfferId; // 0x28(0x10)
	bool Acquired; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FApiGatewayDiscoveryGameStorePackageItem> EntitlementPackageItems; // 0x40(0x10)
	struct FApiGatewayDiscoveryGameStoreEmbarkAttributes EmbarkAttributes; // 0x50(0x68)
	struct FApiGatewayDiscoveryGameStoreEpicAttributes EpicAttributes; // 0xb8(0x10)
	struct FApiGatewayDiscoveryGameStorePlaystationAttributes PlaystationAttributes; // 0xc8(0x20)
	struct FApiGatewayDiscoveryGameStoreSteamAttributes SteamAttributes; // 0xe8(0x30)
	int64_t StartTime; // 0x118(0x08)
	int64_t EndTime; // 0x120(0x08)
	enum class EApiGatewayDiscoveryGameStoreTransactionSource GameStoreTransactionSource; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPersistentEntity
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPersistentEntity {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct FString RawProperties; // 0x40(0x10)
	int64_t CreatedAt; // 0x50(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItem
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItem {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	int64_t Amount; // 0x38(0x08)
	bool HasSeen; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceArchetype
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceArchetype {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	struct TArray<struct FString> GameItemInstanceIds; // 0x38(0x10)
	struct TArray<struct FString> SkinInstanceIds; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceBattlePass
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceBattlePass {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	struct TArray<int64_t> ClaimedEntries; // 0x38(0x10)
	int64_t ConsumedLevels; // 0x48(0x08)
	int64_t Amount; // 0x50(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceCurrency
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceCurrency {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	int64_t Amount; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceCustomizationItem
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceCustomizationItem {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceEmoticon
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceEmoticon {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceFame
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceFame {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	int64_t Amount; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceGameItem
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceGameItem {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	int64_t Amount; // 0x38(0x08)
	bool HasSeen; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	int64_t CreatedAt; // 0x48(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceLoadout
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceLoadout {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
	struct FString SelectedContestantPackInstanceId; // 0x30(0x10)
	int64_t CosmeticNumber; // 0x40(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistencePlayerCardSlot
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistencePlayerCardSlot {
	struct FString SlotName; // 0x00(0x10)
	struct FString ItemInstanceId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistencePlayerCard
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistencePlayerCard {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	struct FString BackgroundInstanceId; // 0x38(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistencePlayerCardSlot> Slots; // 0x48(0x10)
	int64_t UpdatedAt; // 0x58(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistencePlayerCardCustomization
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistencePlayerCardCustomization {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	int64_t Level; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuestReward
// Size: 0x150 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuestReward {
	int64_t RequiredProgress; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	int64_t RankBucketID; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct FApiGatewayDiscoveryGameStoreProduct Product; // 0x20(0x130)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuest
// Size: 0x1c0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuest {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	int64_t Amount; // 0x38(0x08)
	int64_t CreatedAt; // 0x40(0x08)
	int64_t UpdatedAt; // 0x48(0x08)
	int64_t ExpiresAt; // 0x50(0x08)
	int32_t Week; // 0x58(0x04)
	char pad_5c[0x4]; // 0x5c(0x04)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestReward Reward; // 0x60(0x150)
	int64_t SlotId; // 0x1b0(0x08)
	bool Accepted; // 0x1b8(0x01)
	char pad_1b9[0x7]; // 0x1b9(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuestStage
// Size: 0x168 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuestStage {
	int64_t StartsAt; // 0x00(0x08)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestReward Reward; // 0x08(0x150)
	struct TArray<struct FString> QuestInstanceIds; // 0x158(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuestCircuit
// Size: 0x168 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuestCircuit {
	int64_t StartsAt; // 0x00(0x08)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestReward Reward; // 0x08(0x150)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuestStage> Stages; // 0x158(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuestContext
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuestContext {
	struct FString Kind; // 0x00(0x10)
	struct TArray<struct FString> DailyquestInstanceIds; // 0x10(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuestCircuit> Circuits; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuestCircuit> Ftue; // 0x30(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuestCircuit> Events; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceSanction
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceSanction {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
	enum class EApiGatewayDiscoverySanctionType SanctionType; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t Tier; // 0x34(0x04)
	int64_t TimeOfSanction; // 0x38(0x08)
	int64_t Duration; // 0x40(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceSkill
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceSkill {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	int64_t Amount; // 0x38(0x08)
	bool HasSeen; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceSpray
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceSpray {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponAttachment
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponAttachment {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponCharm
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponCharm {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponSkin
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponSkin {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponSticker
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponSticker {
	struct FString Kind; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FString Etag; // 0x28(0x10)
	bool HasSeen; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItems
// Size: 0x258 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItems {
	struct FApiGatewayDiscoveryPlayerPersistenceLoadout Loadout; // 0x00(0x48)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceSanction> Sanctions; // 0x48(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceGameItem> GameItems; // 0x58(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack> ContestantPacks; // 0x68(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceArchetype> Archetypes; // 0x78(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceCurrency> Currencies; // 0x88(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponSkin> WeaponSkins; // 0x98(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceCustomizationItem> CustomizationItems; // 0xa8(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceBattlePass> BattlePasses; // 0xb8(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuest> Quests; // 0xc8(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestContext QuestContext; // 0xd8(0x50)
	struct FApiGatewayDiscoveryPlayerPersistenceFame Fame; // 0x128(0x30)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponCharm> WeaponCharms; // 0x158(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponSticker> WeaponStickers; // 0x168(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceSpray> Sprays; // 0x178(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceSkill> Skills; // 0x188(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceEmoticon> Emoticons; // 0x198(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItem> AnimationCustomizationItems; // 0x1a8(0x10)
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCard PlayerCard; // 0x1b8(0x60)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistencePlayerCardCustomization> PlayerCardCustomizations; // 0x218(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponAttachment> WeaponAttachments; // 0x228(0x10)
	struct TArray<struct FApiGatewayDiscoveryClansCustomization> ClansCustomizations; // 0x238(0x10)
	struct TArray<struct FApiGatewayDiscoveryPersistentEntity> PersistentEntities; // 0x248(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryChangeset
// Size: 0x4c0 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryChangeset {
	struct FApiGatewayDiscoveryInventoryItems Created; // 0x00(0x258)
	struct FApiGatewayDiscoveryInventoryItems Updated; // 0x258(0x258)
	struct TArray<struct FString> Deleted; // 0x4b0(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryClansCustomizationWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryClansCustomizationWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryClansCustomization Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPersistentEntityWrapped
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryPersistentEntityWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPersistentEntity Item; // 0x10(0x58)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItemWrapped
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItemWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItem Item; // 0x10(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceArchetypeWrapped
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceArchetypeWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceArchetype Item; // 0x10(0x58)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceBattlePassWrapped
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceBattlePassWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceBattlePass Item; // 0x10(0x58)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceContestantPackWrapped
// Size: 0x100 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceContestantPackWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceContestantPack Item; // 0x10(0xf0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceCurrencyWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceCurrencyWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceCurrency Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceCustomizationItemWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceCustomizationItemWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceCustomizationItem Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceEmoticonWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceEmoticonWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceEmoticon Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceFameWrapped
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceFameWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceFame Item; // 0x10(0x30)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceGameItemWrapped
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceGameItemWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceGameItem Item; // 0x10(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceLoadoutWrapped
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceLoadoutWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceLoadout Item; // 0x10(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistencePlayerCardCustomizationWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistencePlayerCardCustomizationWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCardCustomization Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistencePlayerCardWrapped
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistencePlayerCardWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCard Item; // 0x10(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuestContextWrapped
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuestContextWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestContext Item; // 0x10(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceQuestWrapped
// Size: 0x1d0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceQuestWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceQuest Item; // 0x10(0x1c0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceSanctionWrapped
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceSanctionWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceSanction Item; // 0x10(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceSkillWrapped
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceSkillWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceSkill Item; // 0x10(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceSprayWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceSprayWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceSpray Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponAttachmentWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponAttachmentWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceWeaponAttachment Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponCharmWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponCharmWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceWeaponCharm Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponSkinWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponSkinWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceWeaponSkin Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerPersistenceWeaponStickerWrapped
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerPersistenceWeaponStickerWrapped {
	struct FString Kind; // 0x00(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceWeaponSticker Item; // 0x10(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItem
// Size: 0x1d8 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItem {
	char pad_0[0x1d8]; // 0x00(0x1d8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChangeCreated
// Size: 0x1e8 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChangeCreated {
	struct FString Action; // 0x00(0x10)
	struct FApiGatewayDiscoveryInventoryItem Item; // 0x10(0x1d8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChangeDeleted
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChangeDeleted {
	struct FString Action; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChangeUpdated
// Size: 0x1f0 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChangeUpdated {
	struct FString Action; // 0x00(0x10)
	int64_t AmountDelta; // 0x10(0x08)
	struct FApiGatewayDiscoveryInventoryItem Item; // 0x18(0x1d8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChangeAction
// Size: 0x1f8 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChangeAction {
	char pad_0[0x1f8]; // 0x00(0x1f8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChangeDetails
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChangeDetails {
	int64_t SeasonNumber; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLocalizedString
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryLocalizedString {
	struct FString Path; // 0x00(0x10)
	struct FString StringKey; // 0x10(0x10)
	struct TArray<struct FString> Params; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChangeNotification
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChangeNotification {
	struct FApiGatewayDiscoveryLocalizedString Title; // 0x00(0x30)
	struct FApiGatewayDiscoveryLocalizedString Subtitle; // 0x30(0x30)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemChange
// Size: 0x268 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemChange {
	enum class EApiGatewayDiscoveryInventoryItemChangeReason Reason; // 0x00(0x01)
	enum class EApiGatewayDiscoveryInventoryItemChangeSource Source; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FApiGatewayDiscoveryInventoryItemChangeDetails Details; // 0x08(0x08)
	struct FApiGatewayDiscoveryInventoryItemChangeNotification Notification; // 0x10(0x60)
	struct FApiGatewayDiscoveryInventoryItemChangeAction Change; // 0x70(0x1f8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryChangeset
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryChangeset {
	struct FString ID; // 0x00(0x10)
	struct FApiGatewayDiscoveryInventoryChangeset Inventory; // 0x10(0x4c0)
	struct TArray<struct FApiGatewayDiscoveryInventoryItemChange> Items; // 0x4d0(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAcceptQuestResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryAcceptQuestResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryAssignLobbyLeaderRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryAssignLobbyLeaderRequest {
	struct FEmbarkUserId PlayerId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchaseHistoricalBattlePassEntryRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchaseHistoricalBattlePassEntryRequest {
	struct FString RequestID; // 0x00(0x10)
	int64_t PackId; // 0x10(0x08)
	int64_t EntryId; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBatchPurchaseHistoricalBattlePassEntriesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryBatchPurchaseHistoricalBattlePassEntriesRequest {
	struct TArray<struct FApiGatewayDiscoveryPurchaseHistoricalBattlePassEntryRequest> Subrequests; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBatchPurchaseHistoricalBattlePassEntriesResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryBatchPurchaseHistoricalBattlePassEntriesResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBatchUpdateContestantPacksRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryBatchUpdateContestantPacksRequest {
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack> ContestantPacks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBatchUpdateContestantPacksResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryBatchUpdateContestantPacksResponse {
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack> ContestantPacks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassCategory
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassCategory {
	int64_t GameAssetId; // 0x00(0x08)
	struct FString Category; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameItem
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameItem {
	struct FString Kind; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassEntry
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassEntry {
	int64_t EntryId; // 0x00(0x08)
	int64_t ProductId; // 0x08(0x08)
	struct FString Category; // 0x10(0x10)
	struct TArray<struct FApiGatewayDiscoveryGameItem> Rewards; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryGameItem> Cost; // 0x30(0x10)
	int64_t GameAssetId; // 0x40(0x08)
	int64_t Level; // 0x48(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassLevelPurchasePricing
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassLevelPurchasePricing {
	int64_t CostPerLevel; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassPageNoLock
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassPageNoLock {
	struct FString LockType; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassPageTotalCurrencySpentLock
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassPageTotalCurrencySpentLock {
	struct FString LockType; // 0x00(0x10)
	int64_t CurrencyAssetId; // 0x10(0x08)
	int64_t AmountRequired; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassPageLock
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassPageLock {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassPage
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassPage {
	struct TArray<struct FApiGatewayDiscoveryBattlePassEntry> Entries; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	bool IsPurchasable; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FApiGatewayDiscoveryBattlePassPageLock PageLock; // 0x20(0x28)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassDescription
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassDescription {
	int64_t PackId; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryBattlePassPage> Pages; // 0x08(0x10)
	struct TArray<struct FApiGatewayDiscoveryBattlePassCategory> Categories; // 0x18(0x10)
	struct FApiGatewayDiscoveryBattlePassLevelPurchasePricing LevelPurchasePricing; // 0x28(0x08)
	int64_t RankBucketAssetId; // 0x30(0x08)
	struct FString EndDate; // 0x38(0x10)
	int64_t SeasonNumber; // 0x48(0x08)
	bool IsHistorical; // 0x50(0x01)
	bool IsLiveForCurrentSeason; // 0x51(0x01)
	char pad_52[0x6]; // 0x52(0x06)
	int64_t EventID; // 0x58(0x08)
	enum class EApiGatewayDiscoveryBattlePassKind BattlePassKind; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBattlePassState
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryBattlePassState {
	struct TArray<struct FString> ClaimedCategories; // 0x00(0x10)
	struct TArray<int64_t> ClaimedEntries; // 0x10(0x10)
	int64_t Level; // 0x20(0x08)
	int64_t TotalXP; // 0x28(0x08)
	int64_t BankedLevels; // 0x30(0x08)
	int64_t PackId; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBucketRankReward
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryBucketRankReward {
	int64_t AssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBucketRank
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryBucketRank {
	int64_t Rank; // 0x00(0x08)
	int64_t RequiredXp; // 0x08(0x08)
	struct TArray<struct FApiGatewayDiscoveryBucketRankReward> Rewards; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryBucketRankConfig
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryBucketRankConfig {
	int64_t BucketId; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryBucketRank> Ranks; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCardProgression
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryCardProgression {
	struct TArray<int64_t> Levels; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t CurrentAmount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryClaimBattlePassResponse
// Size: 0x530 (Inherited: 0x00)
struct FApiGatewayDiscoveryClaimBattlePassResponse {
	struct FApiGatewayDiscoveryBattlePassState State; // 0x00(0x40)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x40(0x4e0)
	struct TArray<struct FApiGatewayDiscoveryBattlePassState> UpdatedBattlePasses; // 0x520(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryClanStats
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryClanStats {
	int64_t TenancyUserId; // 0x00(0x08)
	int64_t QuestsCompleted; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryClanStatsPerPlayer
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryClanStatsPerPlayer {
	int64_t TenancyUserExternalId; // 0x00(0x08)
	int64_t QuestsCompleted; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCleanSyncChangesetsRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoveryCleanSyncChangesetsRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryConditions
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoveryConditions {
	enum class EApiGatewayDiscoverySanctionType SanctionType; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCreateContestantPackRequest
// Size: 0xb0 (Inherited: 0x00)
struct FApiGatewayDiscoveryCreateContestantPackRequest {
	struct FString Title; // 0x00(0x10)
	struct FString ArchetypeInstanceId; // 0x10(0x10)
	struct TArray<struct FString> FirstHandInstanceIds; // 0x20(0x10)
	struct TArray<struct FString> ReservedInstanceIds; // 0x30(0x10)
	struct TArray<struct FString> CustomizationItemInstanceIds; // 0x40(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPackItemAttachment> ItemAttachments; // 0x50(0x10)
	struct FString SprayItemInstanceId; // 0x60(0x10)
	struct TArray<struct FString> ExpressItemInstanceIds; // 0x70(0x10)
	struct TArray<struct FString> SprayWheelItemInstanceIds; // 0x80(0x10)
	struct TArray<struct FString> EmoteWheelItemInstanceIds; // 0x90(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPackSlot> Slots; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMapSettings
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryMapSettings {
	struct FString Variant; // 0x00(0x10)
	struct FString Condition; // 0x10(0x10)
	struct FString GameShow; // 0x20(0x10)
	struct TArray<struct FString> Decor; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCreatePrivateLobbyRequest
// Size: 0xa0 (Inherited: 0x00)
struct FApiGatewayDiscoveryCreatePrivateLobbyRequest {
	struct FString GameMode; // 0x00(0x10)
	struct FString Region; // 0x10(0x10)
	struct FString MapName; // 0x20(0x10)
	struct FApiGatewayDiscoveryMapSettings MapSettings; // 0x30(0x40)
	struct FString PlatformSessionId; // 0x70(0x10)
	struct FString PreferredRegion; // 0x80(0x10)
	struct TArray<struct FString> DataCenters; // 0x90(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCreditExpiration
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryCreditExpiration {
	struct FString CreditLogId; // 0x00(0x10)
	int64_t Quantity; // 0x10(0x08)
	int64_t ExpiresAt; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCustomSquadOverride
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryCustomSquadOverride {
	int32_t SquadIndex; // 0x00(0x04)
	int32_t BrandIndex; // 0x04(0x04)
	int32_t ColorIndex; // 0x08(0x04)
	int32_t SpectatorColorIndex; // 0x0c(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryCustomizeSquadsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryCustomizeSquadsRequest {
	struct TArray<struct FApiGatewayDiscoveryCustomSquadOverride> Squads; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryDeleteContestantPackRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryDeleteContestantPackRequest {
	struct FString InstanceId; // 0x00(0x10)
	struct FString Etag; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryItemInstance
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryItemInstance {
	struct FString InstanceId; // 0x00(0x10)
	struct FString Etag; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryDeletePersistentEntitiesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryDeletePersistentEntitiesRequest {
	struct TArray<struct FApiGatewayDiscoveryItemInstance> Entities; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryDeletePersistentEntitiesResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryDeletePersistentEntitiesResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMapOverrideRotationSettings
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryMapOverrideRotationSettings {
	int32_t TimeSwitchInterval; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FString> Maps; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMapOverrideSetting
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryMapOverrideSetting {
	struct FString MapIdentifier; // 0x00(0x10)
	struct TArray<struct FString> EnvironmentOverride; // 0x10(0x10)
	struct TArray<struct FString> GameShowTags; // 0x20(0x10)
	struct TArray<struct FString> MapVariantTags; // 0x30(0x10)
	struct TArray<struct FString> OptionalDecorTags; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMapPermutationOverrideSettings
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryMapPermutationOverrideSettings {
	int32_t TimeSwitchInterval; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FApiGatewayDiscoveryMapOverrideSetting> Maps; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMatchmakingParameters
// Size: 0xb8 (Inherited: 0x00)
struct FApiGatewayDiscoveryMatchmakingParameters {
	struct FString GameMode; // 0x00(0x10)
	struct FString MapName; // 0x10(0x10)
	int32_t RoundsRequiredToPlay; // 0x20(0x04)
	int32_t MaxSquadSize; // 0x24(0x04)
	int32_t MaxSquads; // 0x28(0x04)
	int32_t MaxPlayers; // 0x2c(0x04)
	struct TMap<struct FString, bool> FeatureFlags; // 0x30(0x50)
	struct FApiGatewayDiscoveryMapOverrideRotationSettings MapOverrideRotationSettings; // 0x80(0x18)
	struct FApiGatewayDiscoveryMapPermutationOverrideSettings MapPermutationOverrideSettings; // 0x98(0x18)
	bool AllowSplitParties; // 0xb0(0x01)
	char pad_b1[0x7]; // 0xb1(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryVisiblePeriod
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryVisiblePeriod {
	int64_t StartTime; // 0x00(0x08)
	int64_t EndTime; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUISettings
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryUISettings {
	bool Visible; // 0x00(0x01)
	bool Disabled; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<struct FApiGatewayDiscoveryVisiblePeriod> VisiblePeriods; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryDiscoveryScenario
// Size: 0xe8 (Inherited: 0x00)
struct FApiGatewayDiscoveryDiscoveryScenario {
	struct FString Name; // 0x00(0x10)
	struct FApiGatewayDiscoveryUISettings UISettings; // 0x10(0x18)
	struct FApiGatewayDiscoveryConditions Conditions; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FApiGatewayDiscoveryMatchmakingParameters Parameters; // 0x30(0xb8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryDisplayName
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryDisplayName {
	struct FString Name; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryEnhanceItemRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryEnhanceItemRequest {
	struct FString ItemId; // 0x00(0x10)
	int64_t NextRank; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRank
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryRank {
	int64_t TotalXP; // 0x00(0x08)
	int64_t CurrentRank; // 0x08(0x08)
	struct FString BucketId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerRank
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerRank {
	struct FEmbarkUserId AccountId; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryRank> Ranks; // 0x10(0x10)
	struct FString ActiveItemRankBucketId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRewardItem
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryRewardItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	enum class EApiGatewayDiscoveryRewardItemType Type; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryEnhanceItemResponse
// Size: 0x528 (Inherited: 0x00)
struct FApiGatewayDiscoveryEnhanceItemResponse {
	struct FApiGatewayDiscoveryPlayerRank NewRank; // 0x00(0x30)
	struct FApiGatewayDiscoveryRewardItem Cost; // 0x30(0x18)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x48(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryEventFeatureFlag
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryEventFeatureFlag {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryEvent
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryEvent {
	int64_t EventID; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct FString StartDate; // 0x28(0x10)
	struct FString EndDate; // 0x38(0x10)
	struct TArray<struct FApiGatewayDiscoveryEventFeatureFlag> FeatureFlags; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameCurrency
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameCurrency {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStore
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStore {
	enum class EApiGatewayDiscoveryDistributionPlatform DistributionPlatform; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t NextProductReleaseTime; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreGiftProduct
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreGiftProduct {
	enum class EApiGatewayDiscoveryGameStoreGiftProvider Provider; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t ProductId; // 0x08(0x08)
	struct TArray<struct FApiGatewayDiscoveryGameStorePackageItem> EntitlementPackageItems; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreReconciledItem
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreReconciledItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGameStoreReconciledProduct
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryGameStoreReconciledProduct {
	enum class EApiGatewayDiscoveryGameStoreProvider Provider; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t ProductId; // 0x08(0x08)
	int64_t ProductGameAssetId; // 0x10(0x08)
	struct TArray<struct FApiGatewayDiscoveryGameStoreReconciledItem> EntitlementPackageItems; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetBattlePassesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetBattlePassesResponse {
	struct TArray<struct FApiGatewayDiscoveryBattlePassDescription> BattlePasses; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetBucketRanksResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetBucketRanksResponse {
	struct TArray<struct FApiGatewayDiscoveryBucketRankConfig> BucketRankConfigs; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetClanStatsPerPlayerResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetClanStatsPerPlayerResponse {
	struct TArray<struct FApiGatewayDiscoveryClanStatsPerPlayer> ClanStats; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetClanStatsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetClanStatsRequest {
	struct FString ClanId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetClanStatsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetClanStatsResponse {
	struct TArray<struct FApiGatewayDiscoveryClanStats> ClanStats; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetCollectionEventResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetCollectionEventResponse {
	struct TArray<struct FApiGatewayDiscoveryCollectionEventItem> Items; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetContestantPacksResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetContestantPacksResponse {
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack> ContestantPacks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetCurrentEventsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetCurrentEventsResponse {
	struct TArray<struct FApiGatewayDiscoveryEvent> Events; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetDiscoveryScenariosRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetDiscoveryScenariosRequest {
	struct FString Region; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetDiscoveryScenariosResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetDiscoveryScenariosResponse {
	struct TArray<struct FApiGatewayDiscoveryDiscoveryScenario> DiscoveryScenarios; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetGameStoreAccessTokenRequest
// Size: 0x02 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetGameStoreAccessTokenRequest {
	enum class EApiGatewayDiscoveryGameStoreProvider Gamestore; // 0x00(0x01)
	enum class EApiGatewayDiscoveryGetGameStoreAccessTokenRequestType Type; // 0x01(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetGameStoreAccessTokenResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetGameStoreAccessTokenResponse {
	struct FString Raw; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetInventoryResponse
// Size: 0x738 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetInventoryResponse {
	struct FApiGatewayDiscoveryPlayerPersistenceLoadout Loadout; // 0x00(0x48)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceSanction> Sanctions; // 0x48(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceGameItem> GameItems; // 0x58(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack> ContestantPacks; // 0x68(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceArchetype> Archetypes; // 0x78(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceCurrency> Currencies; // 0x88(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponSkin> WeaponSkins; // 0x98(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceCustomizationItem> CustomizationItems; // 0xa8(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceBattlePass> BattlePasses; // 0xb8(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuest> Quests; // 0xc8(0x10)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestContext QuestContext; // 0xd8(0x50)
	struct FApiGatewayDiscoveryPlayerPersistenceFame Fame; // 0x128(0x30)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponCharm> WeaponCharms; // 0x158(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponSticker> WeaponStickers; // 0x168(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceSpray> Sprays; // 0x178(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceSkill> Skills; // 0x188(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceEmoticon> Emoticons; // 0x198(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceAnimationCustomizationItem> AnimationCustomizationItems; // 0x1a8(0x10)
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCard PlayerCard; // 0x1b8(0x60)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistencePlayerCardCustomization> PlayerCardCustomizations; // 0x218(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceWeaponAttachment> WeaponAttachments; // 0x228(0x10)
	struct TArray<struct FApiGatewayDiscoveryClansCustomization> ClansCustomizations; // 0x238(0x10)
	struct TArray<struct FApiGatewayDiscoveryPersistentEntity> PersistentEntities; // 0x248(0x10)
	struct FApiGatewayDiscoveryChangeset SyncChangeset; // 0x258(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryItemLiveMeta
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryItemLiveMeta {
	int64_t ItemId; // 0x00(0x08)
	struct FString LocalisedTitle; // 0x08(0x10)
	struct FString LocalisedDescription; // 0x18(0x10)
	struct FString Rarity; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetItemLiveMetaResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetItemLiveMetaResponse {
	struct TArray<struct FApiGatewayDiscoveryItemLiveMeta> ItemLiveMetaList; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryItemUnlockCost
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryItemUnlockCost {
	int64_t ItemAssetId; // 0x00(0x08)
	int64_t BucketId; // 0x08(0x08)
	int64_t CurrencyAssetId; // 0x10(0x08)
	int64_t CurrencyAmount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetItemUnlockCostsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetItemUnlockCostsResponse {
	struct TArray<struct FApiGatewayDiscoveryItemUnlockCost> GameItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardFilter
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardFilter {
	struct FString Kind; // 0x00(0x10)
	int64_t KeyId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetLeaderboardSpecification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetLeaderboardSpecification {
	struct FString ID; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardFilter> Filters; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetLeaderboardRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetLeaderboardRequest {
	int64_t Limit; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryGetLeaderboardSpecification> Leaderboards; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySeasonalCareerRecord
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoverySeasonalCareerRecord {
	int64_t TotalFans; // 0x00(0x08)
	int64_t SelectedSponsor; // 0x08(0x08)
	int64_t SponsorLevel; // 0x10(0x08)
	int64_t NextLevelProgress; // 0x18(0x08)
	int64_t SeasonId; // 0x20(0x08)
	int64_t TrackSeasonId; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorTrackGameAssetReward
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorTrackGameAssetReward {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorTrackProductReward
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorTrackProductReward {
	int64_t ProductId; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	struct TArray<struct FApiGatewayDiscoveryGameItem> GameItems; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorTrackRankBucketXpReward
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorTrackRankBucketXpReward {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Xp; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorTrackReward
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorTrackReward {
	enum class EApiGatewayDiscoverySponsorTrackRewardType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FApiGatewayDiscoverySponsorTrackGameAssetReward GameAsset; // 0x08(0x10)
	struct FApiGatewayDiscoverySponsorTrackProductReward Product; // 0x18(0x20)
	struct FApiGatewayDiscoverySponsorTrackRankBucketXpReward RankBucketXp; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorTrackItem
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorTrackItem {
	int64_t Level; // 0x00(0x08)
	int64_t UnlockPrice; // 0x08(0x08)
	int64_t OriginalUnlockPrice; // 0x10(0x08)
	int64_t NormalizedUnlockPrice; // 0x18(0x08)
	int64_t NormalizedOriginalUnlockPrice; // 0x20(0x08)
	int64_t TrackSeasonId; // 0x28(0x08)
	struct FApiGatewayDiscoverySponsorTrackReward Reward; // 0x30(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetPlayerCareerResponse
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetPlayerCareerResponse {
	int64_t Fans; // 0x00(0x08)
	int64_t SelectedSponsor; // 0x08(0x08)
	int64_t SponsorLevel; // 0x10(0x08)
	struct TArray<struct FApiGatewayDiscoverySponsorTrackItem> SponsorTrack; // 0x18(0x10)
	struct TArray<struct FApiGatewayDiscoverySeasonalCareerRecord> SeasonalRecords; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorJourneyCircuitFansGains
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorJourneyCircuitFansGains {
	int64_t CircuitId; // 0x00(0x08)
	bool IsCurrent; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	int64_t Fans; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorJourneySeasonalFansGains
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorJourneySeasonalFansGains {
	int64_t SeasonNumber; // 0x00(0x08)
	bool IsCurrent; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TArray<struct FApiGatewayDiscoverySponsorJourneyCircuitFansGains> FansPerCircuit; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorJourneySponsorProgress
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorJourneySponsorProgress {
	int64_t SponsorId; // 0x00(0x08)
	int64_t SponsorLevel; // 0x08(0x08)
	int64_t NextLevelProgress; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetPlayerCareerV2Response
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetPlayerCareerV2Response {
	int64_t SignedSponsorId; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoverySponsorJourneySponsorProgress> SponsorsProgress; // 0x08(0x10)
	struct TArray<struct FApiGatewayDiscoverySponsorJourneySeasonalFansGains> GainedFans; // 0x18(0x10)
	int64_t BufferedFans; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetPlayerLoadoutsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetPlayerLoadoutsRequest {
	struct TArray<struct FTenancyUserId> TenancyUsers; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerLoadout
// Size: 0x748 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerLoadout {
	struct FTenancyUserId TenancyId; // 0x00(0x10)
	struct FApiGatewayDiscoveryGetInventoryResponse Inventory; // 0x10(0x738)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetPlayerLoadoutsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetPlayerLoadoutsResponse {
	struct TArray<struct FApiGatewayDiscoveryPlayerLoadout> Loadouts; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryProgressiveItem
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryProgressiveItem {
	int64_t AssetId; // 0x00(0x08)
	int64_t BucketId; // 0x08(0x08)
	enum class EApiGatewayDiscoveryProgressiveItemType ProgressionType; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t SponsorId; // 0x18(0x08)
	int64_t SeasonId; // 0x20(0x08)
	int64_t SeasonNumber; // 0x28(0x08)
	bool ShouldProgressOnce; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetProgressiveItemsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetProgressiveItemsResponse {
	struct TArray<struct FApiGatewayDiscoveryProgressiveItem> ProgressiveItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryQuestStage
// Size: 0x188 (Inherited: 0x00)
struct FApiGatewayDiscoveryQuestStage {
	int64_t StageId; // 0x00(0x08)
	int64_t StartsAt; // 0x08(0x08)
	int64_t EndsAt; // 0x10(0x08)
	enum class EApiGatewayDiscoveryQuestActiveOverride Override; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestReward Reward; // 0x20(0x150)
	int64_t GameAssetId; // 0x170(0x08)
	struct TArray<int64_t> QuestSlotIds; // 0x178(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryQuestCircuit
// Size: 0x180 (Inherited: 0x00)
struct FApiGatewayDiscoveryQuestCircuit {
	int64_t CircuitId; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	int64_t StartsAt; // 0x10(0x08)
	int64_t EndsAt; // 0x18(0x08)
	struct FApiGatewayDiscoveryPlayerPersistenceQuestReward Reward; // 0x20(0x150)
	struct TArray<struct FApiGatewayDiscoveryQuestStage> Stages; // 0x170(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryQuestRerollCost
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryQuestRerollCost {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetQuestDescriptionResponse
// Size: 0x80 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetQuestDescriptionResponse {
	struct TArray<int64_t> DailyQuestSlotIds; // 0x00(0x10)
	int64_t DailyQuestNextRerollAt; // 0x10(0x08)
	struct TArray<int64_t> DailyClanQuestSlotIds; // 0x18(0x10)
	int64_t DailyClanQuestMaxAccepted; // 0x28(0x08)
	struct TArray<struct FApiGatewayDiscoveryQuestCircuit> Circuits; // 0x30(0x10)
	struct TArray<struct FApiGatewayDiscoveryQuestCircuit> Ftue; // 0x40(0x10)
	struct TArray<struct FApiGatewayDiscoveryQuestCircuit> Events; // 0x50(0x10)
	struct TArray<struct FApiGatewayDiscoveryQuestCircuit> WorldTourEvents; // 0x60(0x10)
	struct FApiGatewayDiscoveryQuestRerollCost RerollCost; // 0x70(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRewardWheelItem
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryRewardWheelItem {
	int64_t RewardGameAssetId; // 0x00(0x08)
	struct TArray<int64_t> RewardProductIds; // 0x08(0x10)
	struct FApiGatewayDiscoveryGameCurrency AlternativeGameCurrency; // 0x18(0x10)
	enum class EApiGatewayDiscoveryRewardWheelRewardType RewardType; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetRewardWheelResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetRewardWheelResponse {
	struct TArray<struct FApiGatewayDiscoveryRewardWheelItem> Items; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetRoundStatsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetRoundStatsResponse {
	struct TArray<struct FApiGatewayDiscoveryRoundStats> RoundStats; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsor
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsor {
	int64_t GameAssetId; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoverySponsorTrackItem> Track; // 0x08(0x10)
	int64_t SeasonId; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetSponsorsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetSponsorsResponse {
	struct TArray<struct FApiGatewayDiscoverySponsor> Sponsors; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetTotalFameResponse
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetTotalFameResponse {
	int64_t TotalFame; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGetTournamentSessionResponse
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryGetTournamentSessionResponse {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	bool PenaltyOnLeave; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryGiftsRemainingResponse
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryGiftsRemainingResponse {
	int64_t Count; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemOwnership
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemOwnership {
	int64_t TenancyUserExternalId; // 0x00(0x08)
	struct TArray<int64_t> GameAssetIds; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryInventoryItemOwnershipResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryInventoryItemOwnershipResponse {
	struct TArray<struct FApiGatewayDiscoveryInventoryItemOwnership> Ownership; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryJoinTournamentRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoveryJoinTournamentRequest {
	bool UseGameServerProxy; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryJoinTournamentResponse
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewayDiscoveryJoinTournamentResponse {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	enum class EApiGatewayDiscoveryJoinTournamentStatus Status; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FApiGatewayDiscoveryGameServer GameServer; // 0x28(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryJoinTournamentResponseV2
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryJoinTournamentResponseV2 {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct FString GacMatchId; // 0x20(0x10)
	enum class EApiGatewayDiscoveryJoinTournamentStatus Status; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardEntry
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardEntry {
	int64_t R; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
	int64_t F; // 0x18(0x08)
	int64_t Of; // 0x20(0x08)
	int64_t OR; // 0x28(0x08)
	int64_t C; // 0x30(0x08)
	struct FString STEAM; // 0x38(0x10)
	struct FString Psn; // 0x48(0x10)
	struct FString Xbox; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboard
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboard {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardEntry> Entries; // 0x00(0x10)
	int64_t PlayerPosition; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardCellValue
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardCellValue {
	struct FString ValueStr; // 0x00(0x10)
	int64_t ValueInt; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardColumnDesc
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardColumnDesc {
	struct FString Name; // 0x00(0x10)
	struct FString ID; // 0x10(0x10)
	struct FString Kind; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardCommunityEventData
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardCommunityEventData {
	int64_t Goal; // 0x00(0x08)
	int64_t CurrentProgress; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardGlobalColumnDesc
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardGlobalColumnDesc {
	struct FString Name; // 0x00(0x10)
	struct FString ID; // 0x10(0x10)
	struct FString Kind; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardGlobalData
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardGlobalData {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardGlobalColumnDesc> Columns; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardCellValue> Values; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardPlayerData
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardPlayerData {
	int64_t ToplistOrdinal; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardColumnDesc> Columns; // 0x08(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardCellValue> Values; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardRowValue
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardRowValue {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardCellValue> Values; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardData
// Size: 0xa8 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardData {
	struct FString ID; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct FString Kind; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardColumnDesc> Columns; // 0x30(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardRowValue> Rows; // 0x40(0x10)
	struct FApiGatewayDiscoveryLeaderboardPlayerData PlayerData; // 0x50(0x28)
	struct FApiGatewayDiscoveryLeaderboardCommunityEventData CommunityEventData; // 0x78(0x10)
	struct FApiGatewayDiscoveryLeaderboardGlobalData GlobalData; // 0x88(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardFilterKeyDesc
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardFilterKeyDesc {
	int64_t KeyId; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardCellValue> Values; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardFilterDesc
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardFilterDesc {
	struct FString Kind; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardColumnDesc> Columns; // 0x10(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardFilterKeyDesc> Keys; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardDescription
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardDescription {
	struct FString ID; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct FString Kind; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardFilterDesc> Filters; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2EventEntry
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2EventEntry {
	int64_t Rank; // 0x00(0x08)
	int64_t Contribution; // 0x08(0x08)
	struct FString Name; // 0x10(0x10)
	struct FString SteamName; // 0x20(0x10)
	struct FString PsnName; // 0x30(0x10)
	struct FString XboxName; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardEventData
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardEventData {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardV2EventEntry> Entries; // 0x00(0x10)
	int64_t TotalTarget; // 0x10(0x08)
	int64_t CurrentProgress; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardEventPlayerData
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardEventPlayerData {
	int64_t Rank; // 0x00(0x08)
	int64_t Contribution; // 0x08(0x08)
	int64_t ToplistOrdinal; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardList
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardList {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardDescription> Leaderboards; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardsWithIdResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardsWithIdResponse {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardData> Leaderboards; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2Event
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2Event {
	struct FApiGatewayDiscoveryLeaderboardEventData EventData; // 0x00(0x20)
	struct FApiGatewayDiscoveryLeaderboardEventPlayerData PlayerData; // 0x20(0x18)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2SeasonalEntry
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2SeasonalEntry {
	int64_t Rank; // 0x00(0x08)
	int64_t RankIndex; // 0x08(0x08)
	int64_t Points; // 0x10(0x08)
	int64_t OldRankIndex; // 0x18(0x08)
	int64_t OldRank; // 0x20(0x08)
	int64_t OldPoints; // 0x28(0x08)
	int64_t TotalCashOut; // 0x30(0x08)
	struct FString Name; // 0x38(0x10)
	struct FString SteamName; // 0x48(0x10)
	struct FString PsnName; // 0x58(0x10)
	struct FString XboxName; // 0x68(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2Seasonal
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2Seasonal {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardV2SeasonalEntry> Entries; // 0x00(0x10)
	int64_t PlayerPosition; // 0x10(0x08)
	int64_t ToplistOrdinal; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2WorldTourEntry
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2WorldTourEntry {
	int64_t Rank; // 0x00(0x08)
	int64_t Points; // 0x08(0x08)
	struct FString Name; // 0x10(0x10)
	struct FString SteamName; // 0x20(0x10)
	struct FString PsnName; // 0x30(0x10)
	struct FString XboxName; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2WorldTourPlayerData
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2WorldTourPlayerData {
	int64_t Rank; // 0x00(0x08)
	int64_t Points; // 0x08(0x08)
	int64_t EntryIndex; // 0x10(0x08)
	int64_t ToplistOrdinal; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2WorldTour
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2WorldTour {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardV2WorldTourEntry> Entries; // 0x00(0x10)
	struct FApiGatewayDiscoveryLeaderboardV2WorldTourPlayerData PlayerData; // 0x10(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLeaderboardV2Response
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewayDiscoveryLeaderboardV2Response {
	struct FApiGatewayDiscoveryLeaderboardV2Seasonal SeasonalLeaderboard; // 0x00(0x20)
	struct FApiGatewayDiscoveryLeaderboardV2Event EventLeaderboard; // 0x20(0x38)
	struct FApiGatewayDiscoveryLeaderboardV2WorldTour WorldTourLeaderboard; // 0x58(0x30)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryListCreditExpirationsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryListCreditExpirationsResponse {
	struct TArray<struct FApiGatewayDiscoveryCreditExpiration> CreditExpirations; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryStoreProduct
// Size: 0x118 (Inherited: 0x00)
struct FApiGatewayDiscoveryStoreProduct {
	int64_t ProductId; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	enum class EApiGatewayDiscoveryGameStoreProvider Provider; // 0x10(0x01)
	bool Acquired; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
	struct FString GameStoreOfferId; // 0x18(0x10)
	struct TArray<struct FApiGatewayDiscoveryGameStorePackageItem> EntitlementPackageItems; // 0x28(0x10)
	struct FApiGatewayDiscoveryGameStoreEmbarkAttributes EmbarkAttributes; // 0x38(0x68)
	struct FApiGatewayDiscoveryGameStoreEpicAttributes EpicAttributes; // 0xa0(0x10)
	struct FApiGatewayDiscoveryGameStorePlaystationAttributes PlaystationAttributes; // 0xb0(0x20)
	struct FApiGatewayDiscoveryGameStoreSteamAttributes SteamAttributes; // 0xd0(0x30)
	int64_t StartTime; // 0x100(0x08)
	int64_t EndTime; // 0x108(0x08)
	enum class EApiGatewayDiscoveryGameStoreTransactionSource GameStoreTransactionSource; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryProductView
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryProductView {
	int64_t ViewId; // 0x00(0x08)
	struct TArray<struct FApiGatewayDiscoveryStoreProduct> Products; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryListGameStoreProductsByViewResponse
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryListGameStoreProductsByViewResponse {
	struct TArray<struct FApiGatewayDiscoveryProductView> StoreViews; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryProductView> NonStoreViews; // 0x10(0x10)
	struct FApiGatewayDiscoveryGameStore Gamestore; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryListGameStoreProductsRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoveryListGameStoreProductsRequest {
	enum class EApiGatewayDiscoveryGameStoreProvider Provider; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryProfile
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewayDiscoveryProfile {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FEmbarkUserId AccountId; // 0x10(0x10)
	int64_t CreatedAt; // 0x20(0x08)
	struct FApiGatewayDiscoveryDisplayName DisplayName; // 0x28(0x20)
	int64_t DisplayNameCooldownEndsAt; // 0x48(0x08)
	struct FString Email; // 0x50(0x10)
	bool EmailIsVerified; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	int64_t EmailVerifiedAt; // 0x68(0x08)
	struct FString ThirdPartyUserId; // 0x70(0x10)
	struct FString ThirdPartyLastSeenAccountName; // 0x80(0x10)
	struct FString TosVersionSeen; // 0x90(0x10)
	struct FString DateOfBirth; // 0xa0(0x10)
	struct FString CountryCode; // 0xb0(0x10)
	bool IsSpender; // 0xc0(0x01)
	char pad_c1[0x7]; // 0xc1(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLobbyMember
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewayDiscoveryLobbyMember {
	struct FApiGatewayDiscoveryProfile Profile; // 0x00(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLobbySquad
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryLobbySquad {
	struct TArray<struct FApiGatewayDiscoveryLobbyMember> Players; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLobbySquadOverride
// Size: 0x0c (Inherited: 0x00)
struct FApiGatewayDiscoveryLobbySquadOverride {
	int32_t BrandIndex; // 0x00(0x04)
	int32_t ColorIndex; // 0x04(0x04)
	int32_t SpectatorColorIndex; // 0x08(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryLobbySquadSettings
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewayDiscoveryLobbySquadSettings {
	struct TMap<struct FString, struct FApiGatewayDiscoveryLobbySquadOverride> SquadOverrides; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMonitorTournamentRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryMonitorTournamentRequest {
	struct FString TournamentId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryMonitorTournamentResponse
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewayDiscoveryMonitorTournamentResponse {
	struct FString TournamentId; // 0x00(0x10)
	int32_t CurrentTier; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FApiGatewayDiscoveryTournamentTier> Tiers; // 0x18(0x10)
	struct TArray<struct FApiGatewayDiscoveryTournamentMatch> Matches; // 0x28(0x10)
	struct TArray<struct FApiGatewayDiscoveryTournamentTeam> Teams; // 0x38(0x10)
	int32_t LocalMatchIndex; // 0x48(0x04)
	int32_t LocalTeamIndex; // 0x4c(0x04)
	struct FApiGatewayDiscoveryPrecalculatedTournamentResult PrecalculatedResult; // 0x50(0x18)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryOpenCollectionEventItemRequest
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryOpenCollectionEventItemRequest {
	int64_t ItemId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryOpenCollectionEventItemResponse
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryOpenCollectionEventItemResponse {
	struct FApiGatewayDiscoveryCollectionEventItem Item; // 0x00(0x30)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPartyMemberLeagueRank
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPartyMemberLeagueRank {
	struct FEmbarkUserId AccountId; // 0x00(0x10)
	int64_t LeagueRankIndex; // 0x10(0x08)
	int64_t RankScore; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPartyLeagueRanksResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPartyLeagueRanksResponse {
	struct TArray<struct FApiGatewayDiscoveryPartyMemberLeagueRank> PartyLeagueRanks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySponsorProgress
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoverySponsorProgress {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t SponsorLevel; // 0x08(0x08)
	int64_t PreviousSponsorLevel; // 0x10(0x08)
	int64_t NextLevelProgress; // 0x18(0x08)
	struct TArray<struct FApiGatewayDiscoverySponsorTrackItem> Track; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPeekSponsorsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPeekSponsorsResponse {
	struct TArray<struct FApiGatewayDiscoverySponsorProgress> Sponsors; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlatformSessionInfo
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlatformSessionInfo {
	struct FString Provider; // 0x00(0x10)
	struct FString SessionId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerCardProgressionsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerCardProgressionsResponse {
	struct TArray<struct FApiGatewayDiscoveryCardProgression> Progressions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerInventory
// Size: 0x748 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerInventory {
	struct FEmbarkUserId AccountId; // 0x00(0x10)
	struct FApiGatewayDiscoveryGetInventoryResponse Inventory; // 0x10(0x738)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerInventories
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerInventories {
	struct TArray<struct FApiGatewayDiscoveryPlayerInventory> Items; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerRequest {
	struct TArray<struct FEmbarkUserId> AccountIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryReward
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryReward {
	int64_t Rank; // 0x00(0x08)
	int64_t RequiredXp; // 0x08(0x08)
	struct TArray<struct FApiGatewayDiscoveryRewardItem> Items; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRewardBucket
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryRewardBucket {
	struct FString ID; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryReward> Rewards; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPlayerReward
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPlayerReward {
	struct FEmbarkUserId AccountId; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryRewardBucket> Buckets; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyGetOrSetPlatformSessionRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyGetOrSetPlatformSessionRequest {
	struct FString LobbyId; // 0x00(0x10)
	struct FString PlatformSessionId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyGetOrSetPlatformSessionResponse
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyGetOrSetPlatformSessionResponse {
	struct FApiGatewayDiscoveryPlatformSessionInfo PlatformSession; // 0x00(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyInvitePlayerRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyInvitePlayerRequest {
	struct FEmbarkUserId PlayerId; // 0x00(0x10)
	struct FString SenderProvider; // 0x10(0x10)
	struct FString SenderPlatformSessionId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyJoinLeaveRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyJoinLeaveRequest {
	struct FString LobbyId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyKickPlayerRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyKickPlayerRequest {
	struct FEmbarkUserId PlayerId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyResponseV2
// Size: 0xb8 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyResponseV2 {
	struct FString LobbyId; // 0x00(0x10)
	struct FString GameMode; // 0x10(0x10)
	struct FEmbarkUserId Leader; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryLobbyMember> Players; // 0x30(0x10)
	struct TArray<struct FApiGatewayDiscoveryLobbyMember> Spectators; // 0x40(0x10)
	struct FString MapName; // 0x50(0x10)
	struct FApiGatewayDiscoveryMapSettings MapSettings; // 0x60(0x40)
	bool GameInProgress; // 0xa0(0x01)
	char pad_a1[0x7]; // 0xa1(0x07)
	struct TArray<struct FApiGatewayDiscoveryPlatformSessionInfo> PlatformSessions; // 0xa8(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyResponseV3
// Size: 0x118 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyResponseV3 {
	struct FString LobbyId; // 0x00(0x10)
	struct FString GameMode; // 0x10(0x10)
	struct FEmbarkUserId Leader; // 0x20(0x10)
	struct TArray<struct FApiGatewayDiscoveryLobbySquad> Squads; // 0x30(0x10)
	struct TArray<struct FApiGatewayDiscoveryLobbyMember> Spectators; // 0x40(0x10)
	struct TArray<struct FApiGatewayDiscoveryLobbyMember> LobbyPlayers; // 0x50(0x10)
	struct FString MapName; // 0x60(0x10)
	struct FApiGatewayDiscoveryMapSettings MapSettings; // 0x70(0x40)
	bool GameInProgress; // 0xb0(0x01)
	char pad_b1[0x7]; // 0xb1(0x07)
	struct TArray<struct FApiGatewayDiscoveryPlatformSessionInfo> PlatformSessions; // 0xb8(0x10)
	struct FApiGatewayDiscoveryLobbySquadSettings SquadSettings; // 0xc8(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbySetSquadRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbySetSquadRequest {
	struct FEmbarkUserId PlayerId; // 0x00(0x10)
	int32_t SquadIndex; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyStartRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyStartRequest {
	struct FString LobbyId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyStartResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyStartResponse {
	struct FString MatchId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPrivateLobbyUnblockPlayerRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryPrivateLobbyUnblockPlayerRequest {
	struct FEmbarkUserId PlayerId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchaseEmbarkProductAsGiftRequest
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchaseEmbarkProductAsGiftRequest {
	int64_t ProductId; // 0x00(0x08)
	struct FTenancyUserId RecipientTenancyUserId; // 0x08(0x10)
	struct FString RequestID; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchaseEmbarkProductAsGiftResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchaseEmbarkProductAsGiftResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchaseGameStoreProductRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchaseGameStoreProductRequest {
	int64_t ProductId; // 0x00(0x08)
	struct FString RequestID; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchaseGameStoreProductResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchaseGameStoreProductResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchaseHistoricalBattlePassEntryResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchaseHistoricalBattlePassEntryResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchasePlaystyleRequest
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchasePlaystyleRequest {
	int64_t PlaystyleId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryPurchasePlaystyleResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoveryPurchasePlaystyleResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryReconcileGameStoreGiftsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryReconcileGameStoreGiftsRequest {
	struct FString Country; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryReconcileGameStoreGiftsResponse
// Size: 0x4f0 (Inherited: 0x00)
struct FApiGatewayDiscoveryReconcileGameStoreGiftsResponse {
	struct TArray<struct FApiGatewayDiscoveryGameStoreGiftProduct> Products; // 0x00(0x10)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x10(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryReconcileGameStoreTransactionsRequest
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewayDiscoveryReconcileGameStoreTransactionsRequest {
	enum class EApiGatewayDiscoveryGameStoreProvider Gamestore; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString PlatformData; // 0x08(0x10)
	struct FString Country; // 0x18(0x10)
	struct FString CurrencyCode; // 0x28(0x10)
	struct FString LocalizedPrice; // 0x38(0x10)
	struct FString RequestID; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryReconcileGameStoreTransactionsResponse
// Size: 0x4f0 (Inherited: 0x00)
struct FApiGatewayDiscoveryReconcileGameStoreTransactionsResponse {
	struct TArray<struct FApiGatewayDiscoveryGameStoreReconciledProduct> Products; // 0x00(0x10)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x10(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRerollQuestsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoveryRerollQuestsRequest {
	struct TArray<struct FString> QuestInstanceIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryRerollQuestsResponse
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewayDiscoveryRerollQuestsResponse {
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceQuest> Quests; // 0x00(0x10)
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceCurrency> Currencies; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryS2LeaderboardEntry
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewayDiscoveryS2LeaderboardEntry {
	int64_t R; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
	int64_t Ri; // 0x18(0x08)
	int64_t P; // 0x20(0x08)
	int64_t Ori; // 0x28(0x08)
	int64_t OR; // 0x30(0x08)
	int64_t Op; // 0x38(0x08)
	int64_t C; // 0x40(0x08)
	struct FString STEAM; // 0x48(0x10)
	struct FString Psn; // 0x58(0x10)
	struct FString Xbox; // 0x68(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryS2Leaderboard
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoveryS2Leaderboard {
	struct TArray<struct FApiGatewayDiscoveryS2LeaderboardEntry> Entries; // 0x00(0x10)
	int64_t PlayerPosition; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySavePersistentEntitiesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewayDiscoverySavePersistentEntitiesRequest {
	struct TArray<struct FApiGatewayDiscoveryPersistentEntity> Entities; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySavePersistentEntitiesResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoverySavePersistentEntitiesResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySignSponsorRequest
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoverySignSponsorRequest {
	int64_t SponsorId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySpinRewardWheelResponse
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoverySpinRewardWheelResponse {
	int64_t RewardGameAssetId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySubmitMinigameScoreRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewayDiscoverySubmitMinigameScoreRequest {
	struct FString MinigameName; // 0x00(0x10)
	float Score; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySubscriptions
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoverySubscriptions {
	bool MicrosoftGamePass; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySubscriptionsResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoverySubscriptionsResponse {
	struct FApiGatewayDiscoverySubscriptions Subscriptions; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySyncBattlePassResponse
// Size: 0x590 (Inherited: 0x00)
struct FApiGatewayDiscoverySyncBattlePassResponse {
	struct FApiGatewayDiscoveryBattlePassDescription Description; // 0x00(0x68)
	struct FApiGatewayDiscoveryBattlePassState State; // 0x68(0x40)
	bool HasNewClaimedEntries; // 0xa8(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0xb0(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySyncTenancyUserRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewayDiscoverySyncTenancyUserRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoverySyncTenancyUserResponse
// Size: 0x4e0 (Inherited: 0x00)
struct FApiGatewayDiscoverySyncTenancyUserResponse {
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x00(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUnlockedItem
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewayDiscoveryUnlockedItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	int64_t Amount; // 0x28(0x08)
	bool HasSeen; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUnlockItemRequest
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewayDiscoveryUnlockItemRequest {
	int64_t ItemAssetId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUnlockItemResponse
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewayDiscoveryUnlockItemResponse {
	struct FApiGatewayDiscoveryUnlockedItem UnlockedItem; // 0x00(0x38)
	struct FApiGatewayDiscoveryPlayerPersistenceCurrency UpdatedCurrencyItem; // 0x38(0x40)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUpdateLoadoutV2Request
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewayDiscoveryUpdateLoadoutV2Request {
	struct FApiGatewayDiscoveryPlayerPersistenceLoadout Loadout; // 0x00(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUpdateLoadoutV2Response
// Size: 0x528 (Inherited: 0x00)
struct FApiGatewayDiscoveryUpdateLoadoutV2Response {
	struct FApiGatewayDiscoveryPlayerPersistenceLoadout Loadout; // 0x00(0x48)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x48(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUpdatePlayerCardRequest
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewayDiscoveryUpdatePlayerCardRequest {
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCard PlayerCard; // 0x00(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUpdatePlayerCardV2Request
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewayDiscoveryUpdatePlayerCardV2Request {
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCard PlayerCard; // 0x00(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUpdatePlayerCardV2Response
// Size: 0x540 (Inherited: 0x00)
struct FApiGatewayDiscoveryUpdatePlayerCardV2Response {
	struct FApiGatewayDiscoveryPlayerPersistencePlayerCard PlayerCard; // 0x00(0x60)
	struct FApiGatewayDiscoveryChangeset Changeset; // 0x60(0x4e0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewayDiscoveryUpdatePrivateLobbyRequest
// Size: 0x80 (Inherited: 0x00)
struct FApiGatewayDiscoveryUpdatePrivateLobbyRequest {
	struct FString LobbyId; // 0x00(0x10)
	struct FString MapName; // 0x10(0x10)
	struct FApiGatewayDiscoveryMapSettings MapSettings; // 0x20(0x40)
	struct TArray<struct FString> DataCenters; // 0x60(0x10)
	struct FString GameMode; // 0x70(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAdminMatchStartEarlyRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedAdminMatchStartEarlyRequest {
	struct FString TicketId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAdminPlayerActivityResetRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedAdminPlayerActivityResetRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAdminResetDistributionPlatformAchievementsRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedAdminResetDistributionPlatformAchievementsRequest {
	struct FString RequestID; // 0x00(0x10)
	struct FString Platform; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerAcknowledgeBackfillRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerAcknowledgeBackfillRequest {
	struct FString MatchId; // 0x00(0x10)
	struct FString BackfillId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerAcknowledgeBackfillResponse
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedServerAcknowledgeBackfillResponse {
	struct FString BackfillId; // 0x00(0x10)
	struct FApiGatewaySharedServerSquadLayout SquadLayout; // 0x10(0x38)
	struct TArray<struct FTenancyUserId> NewPlayerIds; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerAnticheatVerifyDigestsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerAnticheatVerifyDigestsRequest {
	struct TArray<struct FString> Digests; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerAnticheatVerifyDigestsResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedServerAnticheatVerifyDigestsResponse {
	bool IsBlacklisted; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerArrangePartyRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerArrangePartyRequest {
	struct TArray<struct FTenancyUserId> UserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerCreateBackfillRequest
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedServerCreateBackfillRequest {
	struct FString MatchId; // 0x00(0x10)
	struct FString SearchFieldsBlob; // 0x10(0x10)
	struct FApiGatewaySharedServerSquadLayout SquadLayout; // 0x20(0x38)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerCreateBackfillResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerCreateBackfillResponse {
	struct FString BackfillId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerSquad
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerSquad {
	struct FString SquadId; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> Members; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerCreateSquadVoIPChannelRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerCreateSquadVoIPChannelRequest {
	struct FString BaseID; // 0x00(0x10)
	struct FString GameserverIP; // 0x10(0x10)
	struct TArray<struct FApiGatewaySharedServerSquad> Squads; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerVoIPChannel
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerVoIPChannel {
	struct FString RoomId; // 0x00(0x10)
	struct FString AccessToken; // 0x10(0x10)
	struct FString ClientBaseUrl; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerCreateSquadVoIPChannelResponse
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedServerCreateSquadVoIPChannelResponse {
	struct TMap<struct FString, struct FApiGatewaySharedServerVoIPChannel> Channels; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerDeleteBackfillRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerDeleteBackfillRequest {
	struct FString MatchId; // 0x00(0x10)
	struct FString BackfillId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerDeleteBackfillResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerDeleteBackfillResponse {
	struct FString BackfillId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerDisplayName
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerDisplayName {
	struct FString Name; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerFeatureFlag
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerFeatureFlag {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerGameSettingEntry
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerGameSettingEntry {
	struct FString Key; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerGameSettings
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerGameSettings {
	struct TArray<struct FApiGatewaySharedServerGameSettingEntry> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerGetActiveFeatureFlagsRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedServerGetActiveFeatureFlagsRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerGetActiveFeatureFlagsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerGetActiveFeatureFlagsResponse {
	struct TArray<struct FApiGatewaySharedServerFeatureFlag> FeatureFlags; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerIncreaseMatchSizeRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedServerIncreaseMatchSizeRequest {
	struct FString MatchId; // 0x00(0x10)
	int64_t Capacity; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerIncreaseMatchSizeResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedServerIncreaseMatchSizeResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPersistentPlayerKey
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerPersistentPlayerKey {
	struct FString Etag; // 0x00(0x10)
	struct FString Key; // 0x10(0x10)
	struct FString Value; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPersistentPlayerKeysForTenancyUser
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerPersistentPlayerKeysForTenancyUser {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct TArray<struct FApiGatewaySharedServerPersistentPlayerKey> PersistentPlayerKeys; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActionRequired
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActionRequired {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct TArray<struct FString> Actions; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActionRequiredRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActionRequiredRequest {
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActionRequiredResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActionRequiredResponse {
	struct TArray<struct FApiGatewaySharedServerPlayerActionRequired> PlayerActionsRequired; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityVersion
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityVersion {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FString Etag; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityAbandonMatchRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityAbandonMatchRequest {
	struct FString MatchId; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x10(0x10)
	struct TArray<struct FApiGatewaySharedServerPlayerActivityVersion> PlayerActivityVersions; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityFinishMatchRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityFinishMatchRequest {
	struct FString MatchId; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x10(0x10)
	struct TArray<struct FApiGatewaySharedServerPlayerActivityVersion> PlayerActivityVersions; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerPlayerActivityRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerPlayerActivityRequest {
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerThirdPartyUser
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedServerThirdPartyUser {
	int64_t ProviderId; // 0x00(0x08)
	struct FString ProviderName; // 0x08(0x10)
	struct FString UserId; // 0x18(0x10)
	struct FString LastSeenAccountName; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerProfile
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedServerProfile {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FEmbarkUserId AccountId; // 0x10(0x10)
	struct FApiGatewaySharedServerDisplayName DisplayName; // 0x20(0x20)
	struct TArray<struct FApiGatewaySharedServerThirdPartyUser> ThirdPartyUserIds; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerProfileRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedServerProfileRequest {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	bool IncludeThirdPartyProviders; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerProfilesByTenancyUserIdsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerProfilesByTenancyUserIdsRequest {
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerProfilesByTenancyUserIdsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerProfilesByTenancyUserIdsResponse {
	struct TArray<struct FApiGatewaySharedServerProfile> Profiles; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerReportPlayerDisconnectRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedServerReportPlayerDisconnectRequest {
	struct FString MatchId; // 0x00(0x10)
	struct FTenancyUserId TenancyUserId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerReportPlayerDisconnectResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedServerReportPlayerDisconnectResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerReportServerHeartbeatRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerReportServerHeartbeatRequest {
	struct FString MatchId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerSyncPersistentPlayerKeysResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerSyncPersistentPlayerKeysResponse {
	struct TArray<struct FApiGatewaySharedServerPersistentPlayerKeysForTenancyUser> PersistentPlayerKeysByTenancyUser; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerSyncPersistentPlayerRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerSyncPersistentPlayerRequest {
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerTweakablesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerTweakablesRequest {
	struct FString MatchmakingScenarioID; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerTweakablesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerTweakablesResponse {
	struct TArray<struct FApiGatewaySharedServerTweakables> Tweakables; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerUpdateBackfillRequest
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedServerUpdateBackfillRequest {
	struct FString MatchId; // 0x00(0x10)
	struct FString BackfillId; // 0x10(0x10)
	struct FApiGatewaySharedServerSquadLayout SquadLayout; // 0x20(0x38)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerUpdateBackfillResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedServerUpdateBackfillResponse {
	struct FString BackfillId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerUpdateBackfillStateRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedServerUpdateBackfillStateRequest {
	struct FString MatchId; // 0x00(0x10)
	bool AllowBackfill; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedServerUpdateBackfillStateResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedServerUpdateBackfillStateResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAbandonPlayerSessionRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedAbandonPlayerSessionRequest {
	struct FString MatchId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedActivePeriod
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedActivePeriod {
	int64_t StartTime; // 0x00(0x08)
	int64_t EndTime; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCompactPlayerProfile
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewaySharedCompactPlayerProfile {
	struct FEmbarkUserId EmbarkAccountId; // 0x00(0x10)
	struct FTenancyUserId TenancyUserId; // 0x10(0x10)
	struct FApiGatewaySharedDisplayName DisplayName; // 0x20(0x20)
	struct FString ThirdPartyUserId; // 0x40(0x10)
	struct FString ThirdPartyLastSeenAccountName; // 0x50(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedRecentlyPlayedWith
// Size: 0x80 (Inherited: 0x00)
struct FApiGatewaySharedRecentlyPlayedWith {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FString PlayedAt; // 0x10(0x10)
	struct FApiGatewaySharedCompactPlayerProfile Profile; // 0x20(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAddRecentlyPlayedWithRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedAddRecentlyPlayedWithRequest {
	struct TArray<struct FApiGatewaySharedRecentlyPlayedWith> RecentlyPlayedWith; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAddRecentlyPlayedWithResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedAddRecentlyPlayedWithResponse {
	struct TArray<struct FApiGatewaySharedRecentlyPlayedWith> RecentlyPlayedWith; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAnnouncementContent
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedAnnouncementContent {
	struct FString Key; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAnnouncement
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewaySharedAnnouncement {
	int64_t ID; // 0x00(0x08)
	int64_t Order; // 0x08(0x08)
	int64_t ViewId; // 0x10(0x08)
	struct TArray<struct FApiGatewaySharedAnnouncementContent> Contents; // 0x18(0x10)
	bool Active; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString StartAt; // 0x30(0x10)
	struct FString EndAt; // 0x40(0x10)
	int64_t TemplateId; // 0x50(0x08)
	int64_t HookId; // 0x58(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAnswerClanInviteRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedAnswerClanInviteRequest {
	struct FString ClanId; // 0x00(0x10)
	bool Accept; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAnswerJoinClanApplication
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedAnswerJoinClanApplication {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	bool Accept; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAnswerMentorshipInviteRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedAnswerMentorshipInviteRequest {
	struct FTenancyUserId MentorTenancyUserId; // 0x00(0x10)
	bool Accepted; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedAnswerMentorshipInviteResponse
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedAnswerMentorshipInviteResponse {
	struct FApiGatewaySharedProfile MentorProfile; // 0x00(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedApplyToJoinClanRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedApplyToJoinClanRequest {
	struct FString ClanId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedBlockedPlayersResponse
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedBlockedPlayersResponse {
	int64_t MaxNumBlockedUsers; // 0x00(0x08)
	struct TArray<struct FTenancyUserId> PlayerIds; // 0x08(0x10)
	struct TArray<struct FApiGatewaySharedProfile> Profiles; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedBlockPlayerRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedBlockPlayerRequest {
	struct FEmbarkUserId EmbarkUserId; // 0x00(0x10)
	struct FTenancyUserId PlayerId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedBuild
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedBuild {
	struct FString BuildId; // 0x00(0x10)
	bool UpdateAvailable; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCancelMatchRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedCancelMatchRequest {
	struct FString TicketId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCancelMatchResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedCancelMatchResponse {
	struct FString TicketId; // 0x00(0x10)
	bool HasAssignment; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedChangeRoleOfMemberRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedChangeRoleOfMemberRequest {
	struct FTenancyUserId MemberToChangeTenancyUserExternalId; // 0x00(0x10)
	struct FString Role; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedChatMessage
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedChatMessage {
	struct FString Message; // 0x00(0x10)
	struct FString PurifiedMessage; // 0x10(0x10)
	struct FString CreateTime; // 0x20(0x10)
	struct FTenancyUserId SentById; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedWhisperChatMessageDetails
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedWhisperChatMessageDetails {
	struct FTenancyUserId ToTenancyUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedChatMessageDetails
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedChatMessageDetails {
	struct FApiGatewaySharedWhisperChatMessageDetails WhisperDetails; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCheckNameForClanRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedCheckNameForClanRequest {
	struct FString Name; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCheckNameForClanResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedCheckNameForClanResponse {
	bool Valid; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Reason; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCheckTagForClanRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedCheckTagForClanRequest {
	struct FString Tag; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCheckTagForClanResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedCheckTagForClanResponse {
	bool Valid; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Reason; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageRequestPayloadDevMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageRequestPayloadDevMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedJoinPartyRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedJoinPartyRequest {
	struct FString PartyId; // 0x00(0x10)
	bool CanUserCrossPlay; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString CrossPlayPlatform; // 0x18(0x10)
	struct FString PlatformSessionId; // 0x28(0x10)
	struct FString JoinSecret; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageRequestPayloadPartyUp
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageRequestPayloadPartyUp {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedJoinPartyRequest JoinParty; // 0x10(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageRequestPayload
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageRequestPayload {
	char pad_0[0x60]; // 0x00(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageRequest
// Size: 0x80 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageRequest {
	struct FString ClanId; // 0x00(0x10)
	struct FString MessageId; // 0x10(0x10)
	struct FApiGatewaySharedClaimClanTimelineMessageRequestPayload Payload; // 0x20(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageResponsePayloadDevMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageResponsePayloadDevMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyMemberData
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedPartyMemberData {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	bool ReadyForMatchmaking; // 0x10(0x01)
	bool CrossplayEnabled; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
	struct FString PlatformProvider; // 0x18(0x10)
	struct FString PlatformSessionId; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyMemberMatchmakingReadiness
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedPartyMemberMatchmakingReadiness {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	bool IsReadyForMatchmaking; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedParty
// Size: 0xb8 (Inherited: 0x00)
struct FApiGatewaySharedParty {
	struct FString PartyId; // 0x00(0x10)
	struct FTenancyUserId LeaderTenancyUserId; // 0x10(0x10)
	struct TArray<struct FApiGatewaySharedPartyMember> PartyMembers; // 0x20(0x10)
	struct TArray<struct FApiGatewaySharedPartyMemberMatchmakingReadiness> PartyMemberMatchmakingReadiness; // 0x30(0x10)
	struct TArray<struct FApiGatewaySharedPartyMemberData> MembersData; // 0x40(0x10)
	struct TMap<struct FString, struct FString> Attributes; // 0x50(0x50)
	struct FString JoinSecret; // 0xa0(0x10)
	enum class EApiGatewaySharedPartyPrivacy PartyPrivacy; // 0xb0(0x01)
	enum class EApiGatewaySharedPartyInvitePermission InvitePermission; // 0xb1(0x01)
	char pad_b2[0x6]; // 0xb2(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageResponsePayloadPartyUp
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageResponsePayloadPartyUp {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedParty Party; // 0x10(0xb8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageResponsePayload
// Size: 0xd0 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageResponsePayload {
	char pad_0[0xd0]; // 0x00(0xd0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClaimClanTimelineMessageResponse
// Size: 0xd0 (Inherited: 0x00)
struct FApiGatewaySharedClaimClanTimelineMessageResponse {
	struct FApiGatewaySharedClaimClanTimelineMessageResponsePayload Payload; // 0x00(0xd0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanOverrides
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedClanOverrides {
	struct FString Name; // 0x00(0x10)
	struct FString Tag; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClan
// Size: 0x178 (Inherited: 0x00)
struct FApiGatewaySharedClan {
	struct FString ClanId; // 0x00(0x10)
	int64_t TenancyId; // 0x10(0x08)
	struct FApiGatewaySharedProfile LeaderProfile; // 0x18(0xc8)
	struct FString Name; // 0xe0(0x10)
	struct FString Tag; // 0xf0(0x10)
	struct FString Icon; // 0x100(0x10)
	struct TArray<struct FString> SearchTags; // 0x110(0x10)
	int32_t Membership; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct FString CreatedAt; // 0x128(0x10)
	int64_t Logo; // 0x138(0x08)
	int64_t Border; // 0x140(0x08)
	int64_t Background; // 0x148(0x08)
	enum class EApiGatewaySharedClanPrivacyMode PrivacyMode; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct FApiGatewaySharedClanOverrides Overrides; // 0x158(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanApplicationAnswerNotification
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedClanApplicationAnswerNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	bool Accepted; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FTenancyUserId ApplyingTenancyUserId; // 0x28(0x10)
	struct FTenancyUserId AnsweringTenancyUserId; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanApplicationCreateNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedClanApplicationCreateNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FTenancyUserId ApplyingTenancyUserId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanApplicationWithdrawnNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedClanApplicationWithdrawnNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FTenancyUserId WithdrawingTenancyUserId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanChatMessageNotification
// Size: 0x68 (Inherited: 0x00)
struct FApiGatewaySharedClanChatMessageNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FString Message; // 0x20(0x10)
	struct FString PurifiedMessage; // 0x30(0x10)
	bool Flagged; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	int64_t FromTenancyUserId; // 0x48(0x08)
	struct FString CreateTime; // 0x50(0x10)
	int32_t ClientMessageId; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMembershipInfo
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewaySharedClanMembershipInfo {
	struct FString ClanId; // 0x00(0x10)
	struct FString ClanName; // 0x10(0x10)
	struct FString ClanTag; // 0x20(0x10)
	enum class EApiGatewaySharedClanPrivacyMode ClanPrivacyMode; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString Role; // 0x38(0x10)
	int64_t ClanLogo; // 0x48(0x08)
	struct FApiGatewaySharedClanOverrides Overrides; // 0x50(0x20)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanInfoForPlayer
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedClanInfoForPlayer {
	struct FTenancyUserId TenancyUserExternalId; // 0x00(0x10)
	struct TArray<struct FApiGatewaySharedClanMembershipInfo> MemberOf; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanInvite
// Size: 0x1f0 (Inherited: 0x00)
struct FApiGatewaySharedClanInvite {
	struct FString ClanId; // 0x00(0x10)
	struct FString ClanName; // 0x10(0x10)
	struct FString ClanTag; // 0x20(0x10)
	int64_t ClanLogo; // 0x30(0x08)
	int64_t ClanBorder; // 0x38(0x08)
	int64_t ClanBackground; // 0x40(0x08)
	int64_t ClanMembership; // 0x48(0x08)
	struct FApiGatewaySharedProfile ReceiverProfile; // 0x50(0xc8)
	struct FApiGatewaySharedProfile SenderProfile; // 0x118(0xc8)
	struct FString CreatedAt; // 0x1e0(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanInviteAnswerNotification
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedClanInviteAnswerNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FTenancyUserId InvitedTenancyUserId; // 0x20(0x10)
	bool Accepted; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanInviteNotification
// Size: 0x80 (Inherited: 0x00)
struct FApiGatewaySharedClanInviteNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FString ClanName; // 0x20(0x10)
	struct FString ClanTag; // 0x30(0x10)
	int64_t ClanLogo; // 0x40(0x08)
	int64_t ClanBorder; // 0x48(0x08)
	int64_t ClanBackground; // 0x50(0x08)
	int64_t ClanMembership; // 0x58(0x08)
	struct FTenancyUserId InviteeTenancyUserId; // 0x60(0x10)
	struct FTenancyUserId InviterTenancyUserId; // 0x70(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanInviteWithdrawnNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedClanInviteWithdrawnNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FTenancyUserId InviteeTenancyUserId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMember
// Size: 0x118 (Inherited: 0x00)
struct FApiGatewaySharedClanMember {
	struct FTenancyUserId TenancyUserExternalId; // 0x00(0x10)
	struct FString Role; // 0x10(0x10)
	struct FString MembershipId; // 0x20(0x10)
	struct FString LastLoggedInAt; // 0x30(0x10)
	struct FString CreatedAt; // 0x40(0x10)
	struct FApiGatewaySharedProfile Profile; // 0x50(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMemberJoinedNotification
// Size: 0xd8 (Inherited: 0x00)
struct FApiGatewaySharedClanMemberJoinedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedProfile Profile; // 0x10(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMemberKickedNotification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedClanMemberKickedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMemberLeftNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedClanMemberLeftNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FTenancyUserId TenancyUserId; // 0x10(0x10)
	struct FString ClanId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMemberRoleChangedNotification
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedClanMemberRoleChangedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FTenancyUserId TenancyUserId; // 0x20(0x10)
	struct FString Role; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanMessageSendRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedClanMessageSendRequest {
	struct FString Message; // 0x00(0x10)
	struct FString Locale; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
	struct TArray<struct FTenancyUserId> ExcludedReceivers; // 0x30(0x10)
	int32_t ClientMessageId; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineDevMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineDevMessage {
	struct FString Discriminator; // 0x00(0x10)
	struct FString Text; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMemberJoinedMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMemberJoinedMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMemberLeftMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMemberLeftMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMemberRoleChangedMessage
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMemberRoleChangedMessage {
	struct FString Discriminator; // 0x00(0x10)
	struct FString OldRole; // 0x10(0x10)
	struct FString NewRole; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelinePartyUpMessage
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelinePartyUpMessage {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	struct FString ExpireTime; // 0x20(0x10)
	struct FString GameMode; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMessagePayload
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMessagePayload {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMessage
// Size: 0xe8 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMessage {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
	struct FString MessageId; // 0x20(0x10)
	struct FString CreateTime; // 0x30(0x10)
	struct FApiGatewaySharedClanTimelineMessagePayload Payload; // 0x40(0x48)
	struct FApiGatewaySharedCompactPlayerProfile Profile; // 0x88(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMessageCreatedNotification
// Size: 0xf8 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMessageCreatedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedClanTimelineMessage Message; // 0x10(0xe8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanTimelineMessageUpdatedNotification
// Size: 0xf8 (Inherited: 0x00)
struct FApiGatewaySharedClanTimelineMessageUpdatedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedClanTimelineMessage Message; // 0x10(0xe8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedClanUpdatedNotification
// Size: 0x188 (Inherited: 0x00)
struct FApiGatewaySharedClanUpdatedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedClan Clan; // 0x10(0x178)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedConfirmPartyMatchRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedConfirmPartyMatchRequest {
	struct FString TicketId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedContestantPackUpdatedNotification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedContestantPackUpdatedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FTenancyUserId UpdaterTenancyUserId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCreateClanRequest
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedCreateClanRequest {
	struct FString Name; // 0x00(0x10)
	struct FString Tag; // 0x10(0x10)
	enum class EApiGatewaySharedClanPrivacyMode PrivacyMode; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	int64_t Logo; // 0x28(0x08)
	int64_t Border; // 0x30(0x08)
	int64_t Background; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCreateClanTimelineMessageRequest
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedCreateClanTimelineMessageRequest {
	struct FString ClanId; // 0x00(0x10)
	struct FApiGatewaySharedClanTimelineMessagePayload Payload; // 0x10(0x48)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCreatePartyRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedCreatePartyRequest {
	bool CrossplayEnabled; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString PlatformSessionId; // 0x08(0x10)
	enum class EApiGatewaySharedPartyInvitePermission InvitePermission; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCrossplayEnabledRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedCrossplayEnabledRequest {
	bool IsEnabled; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCustomBuildRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedCustomBuildRequest {
	struct FString BuildId; // 0x00(0x10)
	struct FString Signature; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedCustomBuildResponse
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedCustomBuildResponse {
	struct FString URL; // 0x00(0x10)
	bool IsBundled; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString Uid; // 0x18(0x10)
	struct FString Sha256; // 0x28(0x10)
	struct FString Key; // 0x38(0x10)
	struct FString Signature; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDatacenter
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedDatacenter {
	struct FString IcaoCode; // 0x00(0x10)
	int64_t Distance; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDatacenterLatency
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedDatacenterLatency {
	struct FString Icao; // 0x00(0x10)
	int64_t LatencyNs; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDeleteFriendshipRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDeleteFriendshipRequest {
	struct FTenancyUserId TargetTenancyUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDeleteFriendshipResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedDeleteFriendshipResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDeleteInboxMessagesRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedDeleteInboxMessagesRequest {
	struct FString SessionId; // 0x00(0x10)
	struct TArray<int64_t> MessageIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryClanInviteMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryClanInviteMessage {
	struct FString InvitedId; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryClanNameSanctionMessage
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryClanNameSanctionMessage {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PreviousName; // 0x10(0x10)
	struct FString NewName; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryClanTagSanctionMessage
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryClanTagSanctionMessage {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PreviousTag; // 0x10(0x10)
	struct FString NewTag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryCommunityUpdateMessage
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryCommunityUpdateMessage {
	struct FString Image; // 0x00(0x10)
	struct FString URL; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
	enum class EApiGatewaySharedDiscoveryCommunityUpdateMessageType Type; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryCrossPromotionCircuitMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryCrossPromotionCircuitMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryGenericAMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryGenericAMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryGenericBMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryGenericBMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryGenericCMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryGenericCMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryGenericDMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryGenericDMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryGenericEMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryGenericEMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryGiftMessage
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryGiftMessage {
	int64_t GifterTenancyUserId; // 0x00(0x08)
	struct TArray<int64_t> ReceivedGameAssetIds; // 0x08(0x10)
	struct FString Discriminator; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryMaintenanceAlertMessage
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryMaintenanceAlertMessage {
	struct FString Image; // 0x00(0x10)
	struct FString StartTime; // 0x10(0x10)
	struct FString EndTime; // 0x20(0x10)
	struct FString Discriminator; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryNameChangeIntroMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryNameChangeIntroMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPatchNoteMessage
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPatchNoteMessage {
	struct FString Version; // 0x00(0x10)
	struct FString Image; // 0x10(0x10)
	struct FString URL; // 0x20(0x10)
	struct FString Discriminator; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPioPromoMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPioPromoMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPlaystylesIntroMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPlaystylesIntroMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPromoAMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPromoAMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPromoBMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPromoBMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPromoCMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPromoCMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPromoWithLinkAMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPromoWithLinkAMessage {
	struct FString URL; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPromoWithLinkBMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPromoWithLinkBMessage {
	struct FString URL; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryPromoWithLinkCMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryPromoWithLinkCMessage {
	struct FString URL; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryRankDisqualifiedMessage
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryRankDisqualifiedMessage {
	int32_t Season; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Discriminator; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryRankUpdateMessage
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryRankUpdateMessage {
	int64_t SrChange; // 0x00(0x08)
	int64_t RsChange; // 0x08(0x08)
	enum class EApiGatewaySharedDiscoveryRankUpdateMessageReason Reason; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString Discriminator; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryRankWelcomeMessage
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryRankWelcomeMessage {
	int32_t Season; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Discriminator; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryRewardMessage
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryRewardMessage {
	enum class EApiGatewaySharedDiscoveryRewardMessageType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Discriminator; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryRookieContractsIntroMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryRookieContractsIntroMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySeasonEightWelcomeMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySeasonEightWelcomeMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySeasonFiveWelcomeMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySeasonFiveWelcomeMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySeasonNineWelcomeMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySeasonNineWelcomeMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySeasonSevenWelcomeMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySeasonSevenWelcomeMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySeasonSixWelcomeMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySeasonSixWelcomeMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySeasonTenWelcomeMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySeasonTenWelcomeMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoverySurveyMessage
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedDiscoverySurveyMessage {
	struct FString Image; // 0x00(0x10)
	struct FString URL; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryTwitchRewards2Message
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryTwitchRewards2Message {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDiscoveryValentinesGiftMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedDiscoveryValentinesGiftMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedDistributionPlatformAchievement
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedDistributionPlatformAchievement {
	struct FString ID; // 0x00(0x10)
	double Progress; // 0x10(0x08)
	struct FString CompletedTime; // 0x18(0x10)
	struct FString Etag; // 0x28(0x10)
	struct FString Platform; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedFeatureFlag
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedFeatureFlag {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedFriendshipInfo
// Size: 0xe8 (Inherited: 0x00)
struct FApiGatewaySharedFriendshipInfo {
	struct FApiGatewaySharedProfile Profile; // 0x00(0xc8)
	enum class EApiGatewaySharedFriendshipInfoFriendshipType FriendshipType; // 0xc8(0x01)
	char pad_c9[0x7]; // 0xc9(0x07)
	int64_t CreatedAt; // 0xd0(0x08)
	struct FString DiscordUserId; // 0xd8(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedFrontendPartyExpression
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedFrontendPartyExpression {
	struct FString Discriminator; // 0x00(0x10)
	int64_t AssetId; // 0x10(0x08)
	enum class EApiGatewaySharedFrontendPartyExpressionType ExpressionType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FTenancyUserId TenancyUserId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedFrontendPartyExpressionEmpty
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedFrontendPartyExpressionEmpty {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGameServer
// Size: 0x60 (Inherited: 0x00)
struct FApiGatewaySharedGameServer {
	struct FString Name; // 0x00(0x10)
	struct FString Host; // 0x10(0x10)
	int32_t Port; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString SecretKey; // 0x28(0x10)
	struct FString RoutingToken; // 0x38(0x10)
	bool ProxyEnabled; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FString DatacenterIcaoCode; // 0x50(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGameserverStatusRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGameserverStatusRequest {
	struct FString MatchId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGameserverStatusResponse
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewaySharedGameserverStatusResponse {
	enum class EApiGatewaySharedGameserverState State; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString MatchId; // 0x08(0x10)
	double PollingInterval; // 0x18(0x08)
	struct FApiGatewaySharedGameServer GameServer; // 0x20(0x60)
	enum class EApiGatewaySharedServerInitializationState ServerInitializationState; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGameSettingEntry
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedGameSettingEntry {
	struct FString Key; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGameSettings
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGameSettings {
	struct TArray<struct FApiGatewaySharedGameSettingEntry> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetAccessKeyResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedGetAccessKeyResponse {
	struct FString Token; // 0x00(0x10)
	int64_t Expiry; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetActiveFeatureFlagsRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedGetActiveFeatureFlagsRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetActiveFeatureFlagsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetActiveFeatureFlagsResponse {
	struct TArray<struct FApiGatewaySharedFeatureFlag> FeatureFlags; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSanction
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedSanction {
	enum class EApiGatewaySharedSanctionItem Item; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Expiration; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetActiveSanctionsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetActiveSanctionsResponse {
	struct TArray<struct FApiGatewaySharedSanction> Sanctions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetChatMessagesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetChatMessagesResponse {
	struct TArray<struct FApiGatewaySharedChatMessage> Messages; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetClanInfoForPlayersRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetClanInfoForPlayersRequest {
	struct TArray<struct FTenancyUserId> PlayerIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetClanInfoForPlayersResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetClanInfoForPlayersResponse {
	struct TArray<struct FApiGatewaySharedClanInfoForPlayer> PlayerInfos; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetClanInvitesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetClanInvitesResponse {
	struct TArray<struct FApiGatewaySharedClanInvite> Invites; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetClanResponse
// Size: 0x188 (Inherited: 0x00)
struct FApiGatewaySharedGetClanResponse {
	struct FApiGatewaySharedClan Clan; // 0x00(0x178)
	struct TArray<struct FApiGatewaySharedClanMember> Members; // 0x178(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetClanTimelineMessagesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetClanTimelineMessagesResponse {
	struct TArray<struct FApiGatewaySharedClanTimelineMessage> Messages; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetDistributionPlatformAchievementsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetDistributionPlatformAchievementsResponse {
	struct TArray<struct FApiGatewaySharedDistributionPlatformAchievement> Achievements; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetEligibleTraineesRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetEligibleTraineesRequest {
	struct TArray<struct FTenancyUserId> AdditionalUsers; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetEligibleTraineesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetEligibleTraineesResponse {
	struct TArray<struct FTenancyUserId> EligibleTrainees; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetFriendsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetFriendsResponse {
	struct TArray<struct FApiGatewaySharedFriendshipInfo> Friends; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetInboxMessagesRequest
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedGetInboxMessagesRequest {
	struct FString SessionId; // 0x00(0x10)
	bool IncludeSeenMessages; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerChargebackProcessedMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerChargebackProcessedMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerCheaterCompensationMessage
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPioneerCheaterCompensationMessage {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
	struct FString CompensationId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerCompensationMessage
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedPioneerCompensationMessage {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
	struct FString CompensationId; // 0x20(0x10)
	struct FString SourceType; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerCrossPromotionMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerCrossPromotionMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerDiscoRewardMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerDiscoRewardMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerPenaltyMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedPioneerPenaltyMessage {
	struct FString Discriminator; // 0x00(0x10)
	struct FString Source; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerPermanentBanMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerPermanentBanMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerRefundProcessedMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerRefundProcessedMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerServerSlamMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerServerSlamMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerTemporarySuspensionMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPioneerTemporarySuspensionMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedRawInboxMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedRawInboxMessage {
	struct FString Data; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedReportedUserBannedMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedReportedUserBannedMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedFriendRequestMessage
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewaySharedSharedFriendRequestMessage {
	int64_t RequestedByEmbarkUser; // 0x00(0x08)
	struct FApiGatewaySharedCompactPlayerProfile RequestedByProfile; // 0x08(0x60)
	struct FString Discriminator; // 0x68(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedGiftRefundedMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSharedGiftRefundedMessage {
	struct TArray<int64_t> RefundedGameAssetIds; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedLinkDiscordAccountMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSharedLinkDiscordAccountMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedMaintenanceAlertMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSharedMaintenanceAlertMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedMaintenanceCompletedMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSharedMaintenanceCompletedMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedMissingSteamProductOwnershipMessage
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSharedMissingSteamProductOwnershipMessage {
	int64_t RevertedProductId; // 0x00(0x08)
	int64_t UnsettledHardCurrency; // 0x08(0x08)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedParameterizedMessageCompensation
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSharedParameterizedMessageCompensation {
	struct FString ID; // 0x00(0x10)
	struct FString Discriminator; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedParameterizedMessageDeepLinkButton
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSharedParameterizedMessageDeepLinkButton {
	struct FString LabelStringId; // 0x00(0x10)
	struct FString URL; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedParameterizedMessageExternalLinkButton
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSharedParameterizedMessageExternalLinkButton {
	struct FString LabelStringId; // 0x00(0x10)
	struct FString URL; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedParameterizedMessageAttachment
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedSharedParameterizedMessageAttachment {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedParameterizedMessage
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewaySharedSharedParameterizedMessage {
	struct FString TitleStringId; // 0x00(0x10)
	struct FString BodyStringId; // 0x10(0x10)
	struct FString ImageAssetId; // 0x20(0x10)
	struct FString ImageLocation; // 0x30(0x10)
	struct FApiGatewaySharedSharedParameterizedMessageAttachment Attachment; // 0x40(0x38)
	struct FString Discriminator; // 0x78(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedPlayerConductWarningMessage
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSharedPlayerConductWarningMessage {
	struct FString Reason; // 0x00(0x10)
	struct FString EndsAt; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedPlayerNameSanctionMessage
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedSharedPlayerNameSanctionMessage {
	enum class EApiGatewaySharedSharedPlayerNameSanctionReason Reason; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString PreviousName; // 0x08(0x10)
	struct FString NewName; // 0x18(0x10)
	struct FString Discriminator; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSharedPlayerReportFeedbackMessage
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSharedPlayerReportFeedbackMessage {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedInboxMessagePayload
// Size: 0x90 (Inherited: 0x00)
struct FApiGatewaySharedInboxMessagePayload {
	char pad_0[0x90]; // 0x00(0x90)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedInboxMessage
// Size: 0xc0 (Inherited: 0x00)
struct FApiGatewaySharedInboxMessage {
	int64_t MessageId; // 0x00(0x08)
	struct FString MessageName; // 0x08(0x10)
	struct FApiGatewaySharedInboxMessagePayload Payload; // 0x18(0x90)
	bool Seen; // 0xa8(0x01)
	bool Favorited; // 0xa9(0x01)
	char pad_aa[0x6]; // 0xaa(0x06)
	struct FString SentAt; // 0xb0(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetInboxMessagesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetInboxMessagesResponse {
	struct TArray<struct FApiGatewaySharedInboxMessage> Messages; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetInboxMessageStatsRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedGetInboxMessageStatsRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetInboxMessageStatsResponse
// Size: 0x08 (Inherited: 0x00)
struct FApiGatewaySharedGetInboxMessageStatsResponse {
	int64_t UnseenMessagesCount; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedJoinClanApplication
// Size: 0x108 (Inherited: 0x00)
struct FApiGatewaySharedJoinClanApplication {
	struct FApiGatewaySharedProfile Profile; // 0x00(0xc8)
	struct FString CreatedAt; // 0xc8(0x10)
	struct FString ClanId; // 0xd8(0x10)
	struct FString ClanName; // 0xe8(0x10)
	struct FString ClanTag; // 0xf8(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetJoinClanApplicationsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetJoinClanApplicationsResponse {
	struct TArray<struct FApiGatewaySharedJoinClanApplication> Applications; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetLatestBuildRequestV2
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedGetLatestBuildRequestV2 {
	struct FString AppId; // 0x00(0x10)
	struct FString BuildId; // 0x10(0x10)
	struct FString StoreDeploymentTarget; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetManifestRequest
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedGetManifestRequest {
	struct FString BuildId; // 0x00(0x10)
	int64_t PlaytestId; // 0x10(0x08)
	struct FString ArtifactId; // 0x18(0x10)
	struct FString StoreDeploymentTarget; // 0x28(0x10)
	int64_t ManifestId; // 0x38(0x08)
	struct FString AppId; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetMatchmakingScenariosRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetMatchmakingScenariosRequest {
	struct FString Region; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchmakingParameters
// Size: 0x80 (Inherited: 0x00)
struct FApiGatewaySharedMatchmakingParameters {
	struct FString GameMode; // 0x00(0x10)
	struct FString MapName; // 0x10(0x10)
	int32_t RoundsRequiredToPlay; // 0x20(0x04)
	int32_t CharacterLevelRequiredToPlay; // 0x24(0x04)
	int32_t MaxSquadSize; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
	struct TMap<struct FString, bool> FeatureFlags; // 0x30(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerMatchmakingMapConditionSettings
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedPioneerMatchmakingMapConditionSettings {
	struct FString Condition; // 0x00(0x10)
	int64_t StartTime; // 0x10(0x08)
	int64_t DurationInSecond; // 0x18(0x08)
	int64_t ConditionAssetId; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerMatchmakingMapConditions
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedPioneerMatchmakingMapConditions {
	bool IsOptIn; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FApiGatewaySharedPioneerMatchmakingMapConditionSettings> ConditionSettings; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPioneerMatchmakingSettings
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedPioneerMatchmakingSettings {
	struct FApiGatewaySharedPioneerMatchmakingMapConditions MapConditions; // 0x00(0x18)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedVisiblePeriod
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedVisiblePeriod {
	int64_t StartTime; // 0x00(0x08)
	int64_t EndTime; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUISettings
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedUISettings {
	bool Visible; // 0x00(0x01)
	bool Disabled; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<struct FApiGatewaySharedVisiblePeriod> VisiblePeriods; // 0x08(0x10)
	bool Active; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FApiGatewaySharedActivePeriod> ActivePeriods; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchmakingScenario
// Size: 0xd8 (Inherited: 0x00)
struct FApiGatewaySharedMatchmakingScenario {
	struct FString Name; // 0x00(0x10)
	struct FApiGatewaySharedUISettings UISettings; // 0x10(0x30)
	struct FApiGatewaySharedMatchmakingParameters Parameters; // 0x40(0x80)
	struct FApiGatewaySharedPioneerMatchmakingSettings PioneerSettings; // 0xc0(0x18)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetMatchmakingScenariosResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetMatchmakingScenariosResponse {
	struct TArray<struct FApiGatewaySharedMatchmakingScenario> MatchmakingScenarios; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMentorshipInvite
// Size: 0x1a8 (Inherited: 0x00)
struct FApiGatewaySharedMentorshipInvite {
	struct FApiGatewaySharedProfile MentorProfile; // 0x00(0xc8)
	struct FApiGatewaySharedProfile TraineeProfile; // 0xc8(0xc8)
	bool Accepted; // 0x190(0x01)
	char pad_191[0x7]; // 0x191(0x07)
	struct FString CreatedAt; // 0x198(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetMentorshipInvitesReceivedResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetMentorshipInvitesReceivedResponse {
	struct TArray<struct FApiGatewaySharedMentorshipInvite> Invites; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetMentorshipInvitesSentResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetMentorshipInvitesSentResponse {
	struct TArray<struct FApiGatewaySharedMentorshipInvite> Invites; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetNotificationsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetNotificationsRequest {
	struct FString FromNotificationId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedInboxUpdateNotification
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedInboxUpdateNotification {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyAttributesChangedNotification
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedPartyAttributesChangedNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t TenancyUserId; // 0x10(0x08)
	struct FString PartyId; // 0x18(0x10)
	struct TMap<struct FString, struct FString> Modified; // 0x28(0x50)
	struct TMap<struct FString, struct FString> Current; // 0x78(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyInventoryChangedNotification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedPartyInventoryChangedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FTenancyUserId TenancyUserId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerCrossplayEnabledNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerCrossplayEnabledNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t TenancyUserId; // 0x10(0x08)
	struct FString PartyId; // 0x18(0x10)
	bool CrossplayEnabled; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerInviteNotification
// Size: 0xa8 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerInviteNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t SenderTenancyUserId; // 0x20(0x08)
	struct FString SenderProvider; // 0x28(0x10)
	struct FString SenderPlatformData; // 0x38(0x10)
	struct FApiGatewaySharedCompactPlayerProfile SenderProfile; // 0x48(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerJoinNotification
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerJoinNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t JoinedTenancyUserId; // 0x20(0x08)
	struct FApiGatewaySharedCompactPlayerProfile MemberProfile; // 0x28(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerKickNotification
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerKickNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t KickedTenancyUserId; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerLeaveNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerLeaveNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t LeavingTenancyUserId; // 0x20(0x08)
	int64_t PartyLeaderTenancyUserId; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerPlatformSessionIdNotification
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerPlatformSessionIdNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t TenancyUserId; // 0x10(0x08)
	struct FString PartyId; // 0x18(0x10)
	struct FString PlatformSessionId; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyPlayerReadyForMatchmakingNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPartyPlayerReadyForMatchmakingNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t TenancyUserId; // 0x10(0x08)
	struct FString PartyId; // 0x18(0x10)
	bool IsReadyForMatchmaking; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLobbyMember
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedLobbyMember {
	struct FApiGatewaySharedProfile Profile; // 0x00(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLobbySquad
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedLobbySquad {
	struct TArray<struct FApiGatewaySharedLobbyMember> Players; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMapSettings
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedMapSettings {
	struct FString Variant; // 0x00(0x10)
	struct FString Condition; // 0x10(0x10)
	struct FString GameShow; // 0x20(0x10)
	struct TArray<struct FString> Decor; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlatformSessionInfo
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedPlatformSessionInfo {
	struct FString Provider; // 0x00(0x10)
	struct FString SessionId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyCreateNotification
// Size: 0xd8 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyCreateNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	struct FString GameMode; // 0x20(0x10)
	struct FApiGatewaySharedMapSettings MapSettings; // 0x30(0x40)
	struct TArray<struct FApiGatewaySharedLobbySquad> Squads; // 0x70(0x10)
	struct TArray<int64_t> EmbarkUserIds; // 0x80(0x10)
	int64_t LeaderEmbarkUserId; // 0x90(0x08)
	struct FString MapName; // 0x98(0x10)
	struct TArray<int64_t> Spectators; // 0xa8(0x10)
	struct TArray<struct FApiGatewaySharedPlatformSessionInfo> PlatformSessions; // 0xb8(0x10)
	struct TArray<struct FApiGatewaySharedCompactPlayerProfile> Profiles; // 0xc8(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLobbySquadOverride
// Size: 0x0c (Inherited: 0x00)
struct FApiGatewaySharedLobbySquadOverride {
	int32_t BrandIndex; // 0x00(0x04)
	int32_t ColorIndex; // 0x04(0x04)
	int32_t SpectatorColorIndex; // 0x08(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLobbyCustomSquadSettings
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedLobbyCustomSquadSettings {
	struct TMap<struct FString, struct FApiGatewaySharedLobbySquadOverride> SquadOverrides; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyCurrentPartyJoinNotification
// Size: 0x130 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyCurrentPartyJoinNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	struct FString GameMode; // 0x20(0x10)
	struct TArray<struct FApiGatewaySharedLobbySquad> Squads; // 0x30(0x10)
	struct TArray<int64_t> EmbarkUserIds; // 0x40(0x10)
	int64_t LeaderEmbarkUserId; // 0x50(0x08)
	struct FString MapName; // 0x58(0x10)
	struct FApiGatewaySharedMapSettings MapSettings; // 0x68(0x40)
	bool GameInProgress; // 0xa8(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
	struct TArray<int64_t> Spectators; // 0xb0(0x10)
	struct TArray<struct FApiGatewaySharedPlatformSessionInfo> PlatformSessions; // 0xc0(0x10)
	struct FApiGatewaySharedLobbyCustomSquadSettings CustomSquadSettings; // 0xd0(0x50)
	struct TArray<struct FApiGatewaySharedCompactPlayerProfile> Profiles; // 0x120(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyInviteNotification
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyInviteNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	int64_t SenderEmbarkUserId; // 0x20(0x08)
	struct FApiGatewaySharedCompactPlayerProfile SenderProfile; // 0x28(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyLeaderChangedNotification
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyLeaderChangedNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t NewLeaderEmbarkUserId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyMatchStartNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyMatchStartNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct FString LobbyId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyMembersChangedNotification
// Size: 0x130 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyMembersChangedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	struct FString GameMode; // 0x20(0x10)
	struct TArray<struct FApiGatewaySharedLobbySquad> Squads; // 0x30(0x10)
	struct TArray<int64_t> EmbarkUserIds; // 0x40(0x10)
	int64_t LeaderEmbarkUserId; // 0x50(0x08)
	struct FString MapName; // 0x58(0x10)
	struct FApiGatewaySharedMapSettings MapSettings; // 0x68(0x40)
	bool GameInProgress; // 0xa8(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
	struct TArray<int64_t> Spectators; // 0xb0(0x10)
	struct TArray<struct FApiGatewaySharedPlatformSessionInfo> PlatformSessions; // 0xc0(0x10)
	struct FApiGatewaySharedLobbyCustomSquadSettings CustomSquadSettings; // 0xd0(0x50)
	struct TArray<struct FApiGatewaySharedCompactPlayerProfile> Profiles; // 0x120(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyPlayerKickNotification
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyPlayerKickNotification {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyPlayerLeaveNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyPlayerLeaveNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	int64_t EmbarkUserId; // 0x20(0x08)
	int64_t LeaderEmbarkUserId; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbySquadChangeNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbySquadChangeNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	int64_t EmbarkUserId; // 0x20(0x08)
	int32_t FromSquad; // 0x28(0x04)
	int32_t ToSquad; // 0x2c(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyUpdateNotification
// Size: 0xe8 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyUpdateNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString LobbyId; // 0x10(0x10)
	bool GameInProgress; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FString MapName; // 0x28(0x10)
	struct FString GameMode; // 0x38(0x10)
	struct FApiGatewaySharedMapSettings MapSettings; // 0x48(0x40)
	struct TArray<struct FApiGatewaySharedLobbySquad> Squads; // 0x88(0x10)
	struct FApiGatewaySharedLobbyCustomSquadSettings CustomSquadSettings; // 0x98(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedProfileDataUpdatedNotification
// Size: 0xd8 (Inherited: 0x00)
struct FApiGatewaySharedProfileDataUpdatedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedProfile Profile; // 0x10(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialFriendHasNewTenancyUserNotification
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewaySharedSocialFriendHasNewTenancyUserNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t TenancyUserId; // 0x10(0x08)
	int64_t EmbarkUserId; // 0x18(0x08)
	int64_t TenancyId; // 0x20(0x08)
	struct FApiGatewaySharedCompactPlayerProfile FriendProfile; // 0x28(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedListUpdateFriendshipInfo
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedListUpdateFriendshipInfo {
	enum class EApiGatewaySharedFriendshipInfoFriendshipType Type; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialFriendListUpdateNotification
// Size: 0x90 (Inherited: 0x00)
struct FApiGatewaySharedSocialFriendListUpdateNotification {
	struct FString Discriminator; // 0x00(0x10)
	enum class EApiGatewaySharedFriendListUpdateType Type; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t EmbarkID; // 0x18(0x08)
	int64_t FriendId; // 0x20(0x08)
	struct FApiGatewaySharedListUpdateFriendshipInfo Info; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FApiGatewaySharedCompactPlayerProfile FriendProfile; // 0x30(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialMatchmakingCancelNotification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSocialMatchmakingCancelNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialMatchmakingCompleteNotification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSocialMatchmakingCompleteNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialMatchmakingStartNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSocialMatchmakingStartNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString Region; // 0x10(0x10)
	struct FString MatchId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialMentorshipInviteAnswerNotification
// Size: 0x1a8 (Inherited: 0x00)
struct FApiGatewaySharedSocialMentorshipInviteAnswerNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedProfile MentorProfile; // 0x10(0xc8)
	struct FApiGatewaySharedProfile TraineeProfile; // 0xd8(0xc8)
	bool Accepted; // 0x1a0(0x01)
	char pad_1a1[0x7]; // 0x1a1(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialMentorshipInviteNotification
// Size: 0x1a0 (Inherited: 0x00)
struct FApiGatewaySharedSocialMentorshipInviteNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FApiGatewaySharedProfile MentorProfile; // 0x10(0xc8)
	struct FApiGatewaySharedProfile TraineeProfile; // 0xd8(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialMentorshipRemovedNotification
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSocialMentorshipRemovedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FTenancyUserId TenancyUserId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPartyArrangedNotificationMemberData
// Size: 0x98 (Inherited: 0x00)
struct FApiGatewaySharedSocialPartyArrangedNotificationMemberData {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PlatformProvider; // 0x10(0x10)
	struct FString PlatformSessionId; // 0x20(0x10)
	bool CrossplayEnabled; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FApiGatewaySharedCompactPlayerProfile MemberProfile; // 0x38(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPartyArrangedNotification
// Size: 0x168 (Inherited: 0x00)
struct FApiGatewaySharedSocialPartyArrangedNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	struct FTenancyUserId LeaderTenancyUserId; // 0x20(0x10)
	struct TArray<struct FTenancyUserId> PartyMembersIds; // 0x30(0x10)
	struct TArray<struct FApiGatewaySharedSocialPartyArrangedNotificationMemberData> PartyMembersData; // 0x40(0x10)
	struct FApiGatewaySharedCompactPlayerProfile LeaderProfile; // 0x50(0x60)
	struct FApiGatewaySharedParty Party; // 0xb0(0xb8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPartyInvitationNotification
// Size: 0xb0 (Inherited: 0x00)
struct FApiGatewaySharedSocialPartyInvitationNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t InviterEmbarkId; // 0x20(0x08)
	int64_t TenancyId; // 0x28(0x08)
	struct FString InviterProvider; // 0x30(0x10)
	struct FString InviterPlatformData; // 0x40(0x10)
	struct FApiGatewaySharedCompactPlayerProfile InviterProfile; // 0x50(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPlayerFailsToJoinNotification
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedSocialPlayerFailsToJoinNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t EmbarkID; // 0x10(0x08)
	struct FString Reason; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPlayerJoinNotification
// Size: 0x90 (Inherited: 0x00)
struct FApiGatewaySharedSocialPlayerJoinNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t MemberEmbarkId; // 0x20(0x08)
	int64_t MemberTenancyUserId; // 0x28(0x08)
	struct FApiGatewaySharedCompactPlayerProfile MemberProfile; // 0x30(0x60)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPlayerKickNotification
// Size: 0x28 (Inherited: 0x00)
struct FApiGatewaySharedSocialPlayerKickNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t EmbarkID; // 0x10(0x08)
	struct FString PartyId; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialPlayerLeaveNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSocialPlayerLeaveNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t EmbarkID; // 0x20(0x08)
	int64_t LeaderId; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialReadyForMatchmakingNotification
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSocialReadyForMatchmakingNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t TenancyUserId; // 0x10(0x08)
	struct FString PartyId; // 0x18(0x10)
	bool IsReadyForMatchmaking; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialUpdatePartyDataNotification
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedSocialUpdatePartyDataNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	struct FString PlatformSessions; // 0x20(0x10)
	struct FString PrivacySettings; // 0x30(0x10)
	enum class EApiGatewaySharedPartyPrivacy PartyPrivacy; // 0x40(0x01)
	enum class EApiGatewaySharedPartyInvitePermission InvitePermission; // 0x41(0x01)
	char pad_42[0x6]; // 0x42(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialUpdatePartyMemberDataNotification
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewaySharedSocialUpdatePartyMemberDataNotification {
	struct FString Discriminator; // 0x00(0x10)
	struct FString PartyId; // 0x10(0x10)
	int64_t UpdatedMemberTenancyUserId; // 0x20(0x08)
	struct FString PlatformData; // 0x28(0x10)
	struct FString CrossplayPreference; // 0x38(0x10)
	struct FString PlatformProvider; // 0x48(0x10)
	struct FString PlatformSessionId; // 0x58(0x10)
	bool CrossplayEnabled; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSocialUserPresenceUpdateNotification
// Size: 0xa0 (Inherited: 0x00)
struct FApiGatewaySharedSocialUserPresenceUpdateNotification {
	struct FString Discriminator; // 0x00(0x10)
	int64_t EmbarkID; // 0x10(0x08)
	int64_t TenancyUserId; // 0x18(0x08)
	bool IsOnline; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FString RichPresence; // 0x28(0x10)
	struct FString Platform; // 0x38(0x10)
	struct TMap<struct FString, struct FString> Attributes; // 0x48(0x50)
	int64_t UpdatedAt; // 0x98(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedNotificationPayload
// Size: 0x1b0 (Inherited: 0x00)
struct FApiGatewaySharedNotificationPayload {
	char pad_0[0x1b0]; // 0x00(0x1b0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedNotification
// Size: 0x1d0 (Inherited: 0x00)
struct FApiGatewaySharedNotification {
	struct FString ID; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct FApiGatewaySharedNotificationPayload Payload; // 0x20(0x1b0)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetNotificationsResponse
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedGetNotificationsResponse {
	struct FString NextFromNotificationId; // 0x00(0x10)
	struct TArray<struct FApiGatewaySharedNotification> Notifications; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedOfficialClanInfo
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedOfficialClanInfo {
	struct FString ClanId; // 0x00(0x10)
	struct FString Name; // 0x10(0x10)
	struct FString Tag; // 0x20(0x10)
	int64_t Logo; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetOfficialClansResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetOfficialClansResponse {
	struct TArray<struct FApiGatewaySharedOfficialClanInfo> Clans; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetPersistentPlayerKeysRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedGetPersistentPlayerKeysRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPersistentPlayerKey
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedPersistentPlayerKey {
	struct FString Key; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetPersistentPlayerKeysResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetPersistentPlayerKeysResponse {
	struct TArray<struct FApiGatewaySharedPersistentPlayerKey> PersistentPlayerKeys; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetPlayerSessionResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetPlayerSessionResponse {
	struct FString MatchId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetPresenceRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetPresenceRequest {
	struct TArray<struct FTenancyUserId> TenancyUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPresence
// Size: 0xa0 (Inherited: 0x00)
struct FApiGatewaySharedPresence {
	struct FTenancyUserId TenancyUserId; // 0x00(0x10)
	struct FEmbarkUserId EmbarkUserId; // 0x10(0x10)
	bool IsOnline; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FString RichPresence; // 0x28(0x10)
	struct FString Platform; // 0x38(0x10)
	struct TMap<struct FString, struct FString> Attributes; // 0x48(0x50)
	int64_t UpdatedAt; // 0x98(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetPresenceResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetPresenceResponse {
	struct TArray<struct FApiGatewaySharedPresence> UsersRichPresence; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetRecentlyPlayedWithResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetRecentlyPlayedWithResponse {
	struct TArray<struct FApiGatewaySharedRecentlyPlayedWith> RecentlyPlayedWith; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetSurveySettingsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetSurveySettingsRequest {
	struct FString Locale; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetVoiceModerationTokenRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedGetVoiceModerationTokenRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedGetVoiceModerationTokenResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedGetVoiceModerationTokenResponse {
	struct FString Token; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedHeartBeatRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedHeartBeatRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedInviteToClanRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedInviteToClanRequest {
	struct FTenancyUserId ToTenancyUserExternalId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedInviteToPartyRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedInviteToPartyRequest {
	struct FTenancyUserId TargetTenancyUserId; // 0x00(0x10)
	struct FString Provider; // 0x10(0x10)
	struct FString PlatformData; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedInviteToPartyResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedInviteToPartyResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedJoinPartyResponse
// Size: 0xe0 (Inherited: 0x00)
struct FApiGatewaySharedJoinPartyResponse {
	struct FApiGatewaySharedParty Party; // 0x00(0xb8)
	struct TArray<struct FApiGatewaySharedPartyMemberMatchmakingReadiness> MatchmakingReadiness; // 0xb8(0x10)
	struct TArray<struct FApiGatewaySharedPartyMemberData> MembersData; // 0xc8(0x10)
	int32_t MaxPartySize; // 0xd8(0x04)
	char pad_dc[0x4]; // 0xdc(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedKickFromClanRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedKickFromClanRequest {
	struct FTenancyUserId MemberToKickTenancyUserExternalId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedKickFromPartyRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedKickFromPartyRequest {
	struct FTenancyUserId TargetTenancyUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedKickFromPartyResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedKickFromPartyResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLeavePartyResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedLeavePartyResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedListAnnouncementsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedListAnnouncementsResponse {
	struct TArray<struct FApiGatewaySharedAnnouncement> Announcements; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedListDistributionPlatformAchievementsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedListDistributionPlatformAchievementsRequest {
	struct FString Platform; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLocalizationEntry
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedLocalizationEntry {
	struct FString Namespace; // 0x00(0x10)
	struct FString Key; // 0x10(0x10)
	struct FString Value; // 0x20(0x10)
	struct FString Source; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLocalizationRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedLocalizationRequest {
	struct FString Locale; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedLocalizationResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedLocalizationResponse {
	struct TArray<struct FApiGatewaySharedLocalizationEntry> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedManifest
// Size: 0xf8 (Inherited: 0x00)
struct FApiGatewaySharedManifest {
	int64_t ID; // 0x00(0x08)
	struct FString BuildId; // 0x08(0x10)
	int64_t PlaytestId; // 0x18(0x08)
	struct FString PartitioningHash; // 0x20(0x10)
	struct FString NonPartitioningHash; // 0x30(0x10)
	struct TMap<struct FString, struct FString> PartitioningBody; // 0x40(0x50)
	struct TMap<struct FString, struct FString> NonPartitioningBody; // 0x90(0x50)
	int64_t RetrievedAt; // 0xe0(0x08)
	int64_t ValidUntil; // 0xe8(0x08)
	int64_t ValidFrom; // 0xf0(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMarkInboxMessageFavoriteRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedMarkInboxMessageFavoriteRequest {
	struct FString SessionId; // 0x00(0x10)
	int64_t MessageId; // 0x10(0x08)
	bool Favorited; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMarkInboxMessagesSeenRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedMarkInboxMessagesSeenRequest {
	struct FString SessionId; // 0x00(0x10)
	struct TArray<int64_t> MessageIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchRedirectInfo
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedMatchRedirectInfo {
	enum class EApiGatewaySharedMatchRedirectTarget Target; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString MatchId; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchStatusRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedMatchStatusRequest {
	struct FString TicketId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchStatusResponse
// Size: 0xa0 (Inherited: 0x00)
struct FApiGatewaySharedMatchStatusResponse {
	struct FString TicketId; // 0x00(0x10)
	double PollingInterval; // 0x10(0x08)
	struct FString SelectedRegion; // 0x18(0x10)
	enum class EApiGatewaySharedMatchmakingMatchState MatchState; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	int64_t MatchTimeEstimate; // 0x30(0x08)
	struct FApiGatewaySharedMatchRedirectInfo RedirectInfo; // 0x38(0x18)
	struct TArray<int64_t> PartyMemberIds; // 0x50(0x10)
	struct TArray<int64_t> ConfirmedPartyMemberIds; // 0x60(0x10)
	int64_t CancellingPartyMemberId; // 0x70(0x08)
	int64_t FailedRoundsCheckPartyMemberId; // 0x78(0x08)
	int64_t FailedRankLimitCheckPartyMemberId; // 0x80(0x08)
	int64_t FailedRankLimitCheckDuoPartyMemberId; // 0x88(0x08)
	struct FString ScenarioName; // 0x90(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchTimeEstimateEntry
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedMatchTimeEstimateEntry {
	int64_t Estimate; // 0x00(0x08)
	enum class EApiGatewaySharedMatchTimeEstimateState Status; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchTimeEstimateEntryV2
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedMatchTimeEstimateEntryV2 {
	int64_t Estimate; // 0x00(0x08)
	enum class EApiGatewaySharedMatchTimeEstimateStateV2 Status; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchTimeEstimatesRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedMatchTimeEstimatesRequest {
	struct FString Region; // 0x00(0x10)
	struct TArray<struct FString> Scenarios; // 0x10(0x10)
	struct TArray<enum class EApiGatewaySharedMatchmakingPlatform> Platforms; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchTimeEstimatesRequestV2
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedMatchTimeEstimatesRequestV2 {
	struct FString Region; // 0x00(0x10)
	struct TArray<struct FString> Scenarios; // 0x10(0x10)
	struct TArray<enum class EApiGatewaySharedMatchmakingPlatform> Platforms; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchTimeEstimatesResponse
// Size: 0xa8 (Inherited: 0x00)
struct FApiGatewaySharedMatchTimeEstimatesResponse {
	enum class EApiGatewaySharedMatchTimeEstimateState Status; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<struct FString, int64_t> Estimates; // 0x08(0x50)
	struct TMap<struct FString, struct FApiGatewaySharedMatchTimeEstimateEntry> Entries; // 0x58(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedMatchTimeEstimatesResponseV2
// Size: 0x58 (Inherited: 0x00)
struct FApiGatewaySharedMatchTimeEstimatesResponseV2 {
	enum class EApiGatewaySharedMatchTimeEstimateStateV2 Status; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<struct FString, struct FApiGatewaySharedMatchTimeEstimateEntryV2> Entries; // 0x08(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyMessageSendRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedPartyMessageSendRequest {
	struct FString Message; // 0x00(0x10)
	struct FString Locale; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
	int32_t ClientMessageId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TArray<struct FTenancyUserId> ExcludedReceivers; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPartyResponse
// Size: 0xc0 (Inherited: 0x00)
struct FApiGatewaySharedPartyResponse {
	struct FApiGatewaySharedParty Party; // 0x00(0xb8)
	int32_t MaxPartySize; // 0xb8(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlatformSessionIdRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPlatformSessionIdRequest {
	struct FString SessionId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityAbandonMatchRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityAbandonMatchRequest {
	struct FString Etag; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityAbandonMatchResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityAbandonMatchResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityCancelMatchmakingRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityCancelMatchmakingRequest {
	struct FString Etag; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityCancelMatchmakingResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityCancelMatchmakingResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityScenarioMetaData
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityScenarioMetaData {
	struct FString ScenarioName; // 0x00(0x10)
	bool AllowReconnects; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPlayerActivityResponse
// Size: 0x78 (Inherited: 0x00)
struct FApiGatewaySharedPlayerActivityResponse {
	int32_t State; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Etag; // 0x08(0x10)
	struct FString TicketId; // 0x18(0x10)
	struct FString MatchId; // 0x28(0x10)
	struct FString TournamentId; // 0x38(0x10)
	enum class EApiGatewaySharedPlayerActivityState CurrentState; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FApiGatewaySharedPlayerActivityScenarioMetaData ScenarioMetadata; // 0x50(0x18)
	struct FString LobbyId; // 0x68(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedPrivateLobbyMessageSendRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedPrivateLobbyMessageSendRequest {
	struct FString Message; // 0x00(0x10)
	struct FString Locale; // 0x10(0x10)
	struct FString Discriminator; // 0x20(0x10)
	int32_t ClientMessageId; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TArray<struct FTenancyUserId> ExcludedReceivers; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedProfilesByThirdPartyId
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedProfilesByThirdPartyId {
	struct TMap<struct FString, struct FApiGatewaySharedProfile> Profiles; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedProxy
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedProxy {
	struct FString Host; // 0x00(0x10)
	int32_t TrafficPort; // 0x10(0x04)
	int32_t QcmpPort; // 0x14(0x04)
	struct FString Region; // 0x18(0x10)
	struct TArray<struct FApiGatewaySharedDatacenterLatency> DatacenterLatencies; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedProxies
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedProxies {
	struct TArray<struct FApiGatewaySharedProxy> Endpoints; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedProximityVoIPCredentialsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedProximityVoIPCredentialsRequest {
	struct FString GameServerName; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedQuilkinSettings
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedQuilkinSettings {
	int32_t FailoverCooldownDurationSecs; // 0x00(0x04)
	int32_t InitialCooldownDurationSecs; // 0x04(0x04)
	int32_t PacketJitterThresholdDurationSecs; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	double PacketLossThresholdPercent; // 0x10(0x08)
	int32_t PacketLossThresholdDurationSecs; // 0x18(0x04)
	bool ProxyFailover; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedReadyForMatchmakingRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedReadyForMatchmakingRequest {
	bool IsReady; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedRemoveMentorshipRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedRemoveMentorshipRequest {
	struct FTenancyUserId OtherTenancyUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedReportClanRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedReportClanRequest {
	struct FString ClanId; // 0x00(0x10)
	struct FString Reason; // 0x10(0x10)
	struct FString Message; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedReportPlayerRequest
// Size: 0x40 (Inherited: 0x00)
struct FApiGatewaySharedReportPlayerRequest {
	struct FTenancyUserId ReportedUserId; // 0x00(0x10)
	struct FString Reason; // 0x10(0x10)
	struct FString Message; // 0x20(0x10)
	struct FString LastRoundId; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedRequestFriendshipRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedRequestFriendshipRequest {
	struct FTenancyUserId TargetTenancyUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedRequestFriendshipResponse
// Size: 0xd0 (Inherited: 0x00)
struct FApiGatewaySharedRequestFriendshipResponse {
	bool IsMutual; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FApiGatewaySharedProfile Profile; // 0x08(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSearchClanRequest
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedSearchClanRequest {
	struct FString NameQuery; // 0x00(0x10)
	struct TArray<struct FString> SearchTags; // 0x10(0x10)
	enum class EApiGatewaySharedClanSearchView View; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t Limit; // 0x24(0x04)
	bool ExcludeFull; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSearchClanResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSearchClanResponse {
	struct TArray<struct FApiGatewaySharedClan> Clans; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSendChatMessageRequest
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedSendChatMessageRequest {
	struct FString Message; // 0x00(0x10)
	enum class EApiGatewaySharedSendChatMessageRequestName Name; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString Locale; // 0x18(0x10)
	struct FApiGatewaySharedChatMessageDetails ChatMessageDetails; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquadMessageSendRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedSquadMessageSendRequest {
	struct FString Message; // 0x00(0x10)
	struct FString SquadId; // 0x10(0x10)
	struct TArray<struct FTenancyUserId> ToPlayers; // 0x20(0x10)
	struct FString Discriminator; // 0x30(0x10)
	int32_t ClientMessageId; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedWhisperMessageSendRequest
// Size: 0x48 (Inherited: 0x00)
struct FApiGatewaySharedWhisperMessageSendRequest {
	struct FString Message; // 0x00(0x10)
	struct FString Locale; // 0x10(0x10)
	struct FTenancyUserId ToTenancyUserId; // 0x20(0x10)
	struct FString Discriminator; // 0x30(0x10)
	int32_t ClientMessageId; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSendChatMessageRequestV2
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedSendChatMessageRequestV2 {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSendMentorshipInviteRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSendMentorshipInviteRequest {
	struct FTenancyUserId TraineeTenancyUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSendMentorshipInviteResponse
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedSendMentorshipInviteResponse {
	struct FApiGatewaySharedProfile TraineeProfile; // 0x00(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSetPersistentPlayerKeysRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSetPersistentPlayerKeysRequest {
	struct TArray<struct FApiGatewaySharedPersistentPlayerKey> PersistentPlayerKeys; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSetPersistentPlayerKeysResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSetPersistentPlayerKeysResponse {
	struct TArray<struct FApiGatewaySharedPersistentPlayerKey> PersistentPlayerKeys; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSetRichPresenceRequest
// Size: 0x88 (Inherited: 0x00)
struct FApiGatewaySharedSetRichPresenceRequest {
	struct FString RichPresence; // 0x00(0x10)
	struct FString Platform; // 0x10(0x10)
	struct TArray<struct FTenancyUserId> AdditionalRecipients; // 0x20(0x10)
	struct TMap<struct FString, struct FString> Attributes; // 0x30(0x50)
	bool HideEmbarkPresence; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSetRichPresenceResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedSetRichPresenceResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquadMember
// Size: 0xc8 (Inherited: 0x00)
struct FApiGatewaySharedSquadMember {
	struct FApiGatewaySharedProfile Profile; // 0x00(0xc8)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquad
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSquad {
	struct FString SquadId; // 0x00(0x10)
	struct TArray<struct FApiGatewaySharedSquadMember> SquadMembers; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquadLayoutRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSquadLayoutRequest {
	struct FString TicketId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquadLayoutResponse
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedSquadLayoutResponse {
	struct TArray<struct FApiGatewaySharedSquad> Squads; // 0x00(0x10)
	int32_t MaxPlayers; // 0x10(0x04)
	int32_t MaxSquadSize; // 0x14(0x04)
	int32_t MaxSquads; // 0x18(0x04)
	int32_t CurrentPlayerCount; // 0x1c(0x04)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSquadVoIPCredentialsRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSquadVoIPCredentialsRequest {
	struct FString GameServerName; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedStartMatchRequest
// Size: 0xd0 (Inherited: 0x00)
struct FApiGatewaySharedStartMatchRequest {
	struct FString GameMode; // 0x00(0x10)
	struct FString MatchmakingScenario; // 0x10(0x10)
	struct TMap<struct FString, struct FString> Tags; // 0x20(0x50)
	struct TArray<struct FApiGatewaySharedDatacenter> DataCenters; // 0x70(0x10)
	struct FString PreferredRegion; // 0x80(0x10)
	struct FString Region; // 0x90(0x10)
	int32_t PreferredSquadSize; // 0xa0(0x04)
	char pad_a4[0x4]; // 0xa4(0x04)
	struct TArray<enum class EApiGatewaySharedMatchmakingPlatform> Platforms; // 0xa8(0x10)
	struct TArray<int64_t> PartyMemberIds; // 0xb8(0x10)
	bool StreamerMode; // 0xc8(0x01)
	bool IsLonewolf; // 0xc9(0x01)
	char pad_ca[0x6]; // 0xca(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedSubmitRichPresenceAllowlistRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedSubmitRichPresenceAllowlistRequest {
	struct TArray<struct FTenancyUserId> AllowListPlayerIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedThirdPartyAccessTokenResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedThirdPartyAccessTokenResponse {
	struct FString Token; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedThirdPartyUserIds
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedThirdPartyUserIds {
	struct FString Provider; // 0x00(0x10)
	struct TArray<struct FString> IDs; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedTriggerFrontendPartyEffectRequest
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedTriggerFrontendPartyEffectRequest {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedTweakablesRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedTweakablesRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedTweakablesResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedTweakablesResponse {
	struct TArray<struct FApiGatewaySharedTweakables> Tweakables; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUnblockPlayerRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedUnblockPlayerRequest {
	struct FEmbarkUserId EmbarkUserId; // 0x00(0x10)
	struct FTenancyUserId PlayerId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateClanRequest
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedUpdateClanRequest {
	struct FString Name; // 0x00(0x10)
	struct FString Tag; // 0x10(0x10)
	enum class EApiGatewaySharedClanPrivacyMode PrivacyMode; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct TArray<struct FString> SearchTags; // 0x28(0x10)
	int64_t Logo; // 0x38(0x08)
	int64_t Border; // 0x40(0x08)
	int64_t Background; // 0x48(0x08)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateDistributionPlatformAchievementItem
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedUpdateDistributionPlatformAchievementItem {
	struct FString ID; // 0x00(0x10)
	double Progress; // 0x10(0x08)
	struct FString Etag; // 0x18(0x10)
	struct FString Platform; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateDistributionPlatformAchievementsRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedUpdateDistributionPlatformAchievementsRequest {
	struct TArray<struct FApiGatewaySharedUpdateDistributionPlatformAchievementItem> Achievements; // 0x00(0x10)
	struct FString RequestID; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateDistributionPlatformAchievementsResponse
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedUpdateDistributionPlatformAchievementsResponse {
	struct TArray<struct FApiGatewaySharedDistributionPlatformAchievement> Achievements; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdatePartyAttributesRequest
// Size: 0x70 (Inherited: 0x00)
struct FApiGatewaySharedUpdatePartyAttributesRequest {
	struct FString PartyId; // 0x00(0x10)
	struct FTenancyUserId TenancyUserId; // 0x10(0x10)
	struct TMap<struct FString, struct FString> Attributes; // 0x20(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdatePartyAttributesResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedUpdatePartyAttributesResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdatePartyDataRequest
// Size: 0x38 (Inherited: 0x00)
struct FApiGatewaySharedUpdatePartyDataRequest {
	struct FString PartyId; // 0x00(0x10)
	struct FString PlatformSessions; // 0x10(0x10)
	struct FString PrivacySettings; // 0x20(0x10)
	enum class EApiGatewaySharedPartyPrivacy PartyPrivacy; // 0x30(0x01)
	enum class EApiGatewaySharedPartyInvitePermission InvitePermission; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdatePartyDataResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedUpdatePartyDataResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdatePartyMemberDataRequestV2
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedUpdatePartyMemberDataRequestV2 {
	struct FString PartyId; // 0x00(0x10)
	int64_t UpdatedMemberTenancyUserId; // 0x10(0x08)
	struct FString PlatformSessionId; // 0x18(0x10)
	bool CrossplayEnabled; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdatePartyMemberDataResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedUpdatePartyMemberDataResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateProfileDisplayNameRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedUpdateProfileDisplayNameRequest {
	struct FString DisplayName; // 0x00(0x10)
	struct TArray<struct FTenancyUserId> AdditionalRecipients; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateProfileRequest
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedUpdateProfileRequest {
	struct FString DisplayName; // 0x00(0x10)
	struct FString Email; // 0x10(0x10)
	struct FString TosVersionSeen; // 0x20(0x10)
	struct FString DateOfBirth; // 0x30(0x10)
	struct FString CountryCode; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateProfileVoiceChatModerationConsentRequest
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedUpdateProfileVoiceChatModerationConsentRequest {
	bool VoiceChatModerationConsent; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUpdateProfileVoiceChatModerationConsentResponse
// Size: 0x01 (Inherited: 0x00)
struct FApiGatewaySharedUpdateProfileVoiceChatModerationConsentResponse {
	bool VoiceChatModerationConsent; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUserRestriction
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedUserRestriction {
	bool IsBanned; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString EndsAt; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedUserRestrictions
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedUserRestrictions {
	struct TArray<struct FApiGatewaySharedUserRestriction> Restrictions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedValidateProfileDisplayNameRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedValidateProfileDisplayNameRequest {
	struct FString DisplayName; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedValidateProfileDisplayNameResponse
// Size: 0x18 (Inherited: 0x00)
struct FApiGatewaySharedValidateProfileDisplayNameResponse {
	bool Valid; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<enum class EApiGatewaySharedDisplayNameValidationError> Errors; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedVideoEncryptionKeys
// Size: 0x50 (Inherited: 0x00)
struct FApiGatewaySharedVideoEncryptionKeys {
	struct TMap<struct FString, struct FString> Videos; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedVoiceChannel
// Size: 0x30 (Inherited: 0x00)
struct FApiGatewaySharedVoiceChannel {
	struct FString RoomId; // 0x00(0x10)
	struct FString AccessToken; // 0x10(0x10)
	struct FString ClientBaseUrl; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedWithdrawClanInviteRequest
// Size: 0x20 (Inherited: 0x00)
struct FApiGatewaySharedWithdrawClanInviteRequest {
	struct FTenancyUserId InviteeTenancyUserExternalId; // 0x00(0x10)
	struct FString ClanId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.ApiGatewaySharedWithdrawJoinClanApplicationRequest
// Size: 0x10 (Inherited: 0x00)
struct FApiGatewaySharedWithdrawJoinClanApplicationRequest {
	struct FString ClanId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminApplyBonusRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminApplyBonusRequest {
	enum class EPioneerAdminBonusEffectKind Kind; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	double Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminApplyPlaytestProfilesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminApplyPlaytestProfilesRequest {
	struct TArray<int64_t> ProfileIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminInventoryItem
// Size: 0x68 (Inherited: 0x00)
struct FPioneerAdminInventoryItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct TArray<struct FString> Slots; // 0x20(0x10)
	double Durability; // 0x30(0x08)
	double MaxDurability; // 0x38(0x08)
	struct FString LockedInRound; // 0x40(0x10)
	struct FString Etag; // 0x50(0x10)
	int64_t UpdatedAt; // 0x60(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminMutatedInventoryItems
// Size: 0x30 (Inherited: 0x00)
struct FPioneerAdminMutatedInventoryItems {
	struct TArray<struct FPioneerAdminInventoryItem> Created; // 0x00(0x10)
	struct TArray<struct FPioneerAdminInventoryItem> Updated; // 0x10(0x10)
	struct TArray<struct FString> Deleted; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCreatedQuest
// Size: 0x40 (Inherited: 0x00)
struct FPioneerAdminCreatedQuest {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t QuestGameAssetId; // 0x10(0x08)
	enum class EPioneerAdminQuestState QuestState; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString QuestEtag; // 0x20(0x10)
	int64_t ExpiresAt; // 0x30(0x08)
	int64_t UpdatedAt; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCreatedQuestObjective
// Size: 0x20 (Inherited: 0x00)
struct FPioneerAdminCreatedQuestObjective {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t Amount; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdatedQuest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerAdminUpdatedQuest {
	struct FString QuestInstanceId; // 0x00(0x10)
	enum class EPioneerAdminQuestState QuestState; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString QuestEtag; // 0x18(0x10)
	int64_t UpdatedAt; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdatedQuestObjective
// Size: 0x20 (Inherited: 0x00)
struct FPioneerAdminUpdatedQuestObjective {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t Amount; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminMutatedQuests
// Size: 0x40 (Inherited: 0x00)
struct FPioneerAdminMutatedQuests {
	struct TArray<struct FPioneerAdminCreatedQuest> Created; // 0x00(0x10)
	struct TArray<struct FPioneerAdminUpdatedQuest> Updated; // 0x10(0x10)
	struct TArray<struct FPioneerAdminCreatedQuestObjective> CreatedObjectives; // 0x20(0x10)
	struct TArray<struct FPioneerAdminUpdatedQuestObjective> UpdatedObjectives; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminPlayerStat
// Size: 0x18 (Inherited: 0x00)
struct FPioneerAdminPlayerStat {
	int64_t EventID; // 0x00(0x08)
	int64_t TargetId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminGlobalPlayerStatScope
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminGlobalPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminRankSeasonPlayerStatScope
// Size: 0x18 (Inherited: 0x00)
struct FPioneerAdminRankSeasonPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	int64_t RankSeasonId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminRankWindowPlayerStatScope
// Size: 0x18 (Inherited: 0x00)
struct FPioneerAdminRankWindowPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	int64_t RankWindowId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUnknownPlayerStatScope
// Size: 0x20 (Inherited: 0x00)
struct FPioneerAdminUnknownPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	struct FString ScopeName; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminPlayerStatScope
// Size: 0x28 (Inherited: 0x00)
struct FPioneerAdminPlayerStatScope {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminScopedPlayerStats
// Size: 0x38 (Inherited: 0x00)
struct FPioneerAdminScopedPlayerStats {
	struct FPioneerAdminPlayerStatScope Scope; // 0x00(0x28)
	struct TArray<struct FPioneerAdminPlayerStat> PlayerStats; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminMutatedStats
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminMutatedStats {
	struct TArray<struct FPioneerAdminScopedPlayerStats> ScopedPlayerStats; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminChangeset
// Size: 0x80 (Inherited: 0x00)
struct FPioneerAdminChangeset {
	struct FPioneerAdminMutatedInventoryItems Items; // 0x00(0x30)
	struct FPioneerAdminMutatedQuests Quests; // 0x30(0x40)
	struct FPioneerAdminMutatedStats Stats; // 0x70(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminApplyPlaytestProfilesResponse
// Size: 0x80 (Inherited: 0x00)
struct FPioneerAdminApplyPlaytestProfilesResponse {
	struct FPioneerAdminChangeset Changeset; // 0x00(0x80)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCodexEntryState
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminCodexEntryState {
	int64_t EntryAssetId; // 0x00(0x08)
	bool Unlocked; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCodexEntryUpdate
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminCodexEntryUpdate {
	int64_t EntryAssetId; // 0x00(0x08)
	bool Unlocked; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCompleteProjectStepRequest
// Size: 0x18 (Inherited: 0x00)
struct FPioneerAdminCompleteProjectStepRequest {
	struct FString ProjectID; // 0x00(0x10)
	int64_t StepAssetId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCompleteProjectStepResponse
// Size: 0x80 (Inherited: 0x00)
struct FPioneerAdminCompleteProjectStepResponse {
	struct FPioneerAdminChangeset Changeset; // 0x00(0x80)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCompleteTimedOfferRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminCompleteTimedOfferRequest {
	struct FString OfferTransactionId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCompleteTimedOfferResponse
// Size: 0x80 (Inherited: 0x00)
struct FPioneerAdminCompleteTimedOfferResponse {
	struct FPioneerAdminChangeset Changeset; // 0x00(0x80)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminRewardedItem
// Size: 0x38 (Inherited: 0x00)
struct FPioneerAdminRewardedItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
	struct TArray<struct FString> Slots; // 0x18(0x10)
	struct FString AliasInstanceId; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminRewardPackage
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminRewardPackage {
	struct TArray<struct FPioneerAdminRewardedItem> RewardedItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCrate
// Size: 0x50 (Inherited: 0x00)
struct FPioneerAdminCrate {
	struct FString Name; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FPioneerAdminRewardPackage ClaimRewardPackage; // 0x28(0x10)
	struct FString Etag; // 0x38(0x10)
	enum class EPioneerAdminCrateState State; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCreateCrateRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerAdminCreateCrateRequest {
	int64_t GameAssetId; // 0x00(0x08)
	enum class EPioneerAdminCrateState State; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FString ExpiresAt; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCreateCrateResponse
// Size: 0x50 (Inherited: 0x00)
struct FPioneerAdminCreateCrateResponse {
	struct FPioneerAdminCrate Crate; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCreateInventoryItemMutation
// Size: 0x60 (Inherited: 0x00)
struct FPioneerAdminCreateInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	int64_t Amount; // 0x28(0x08)
	double Durability; // 0x30(0x08)
	double MaxDurability; // 0x38(0x08)
	struct FString LockedInRound; // 0x40(0x10)
	struct TArray<struct FString> Slots; // 0x50(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminCreateLeaguePlacementRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminCreateLeaguePlacementRequest {
	int64_t RankId; // 0x00(0x08)
	int64_t Points; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminDeleteInventoryItemMutation
// Size: 0x30 (Inherited: 0x00)
struct FPioneerAdminDeleteInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminElapseTimedOfferRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminElapseTimedOfferRequest {
	struct FString OfferTransactionId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminTimedOfferTransaction
// Size: 0x38 (Inherited: 0x00)
struct FPioneerAdminTimedOfferTransaction {
	int64_t OfferId; // 0x00(0x08)
	struct FString TransactionId; // 0x08(0x10)
	struct FString OwnerInstanceId; // 0x18(0x10)
	int64_t StartTime; // 0x28(0x08)
	int64_t DurationInSeconds; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminElapseTimedOfferResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminElapseTimedOfferResponse {
	struct TArray<struct FPioneerAdminTimedOfferTransaction> TimedOfferTransactions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdateInventoryItemMutation
// Size: 0x68 (Inherited: 0x00)
struct FPioneerAdminUpdateInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t Amount; // 0x20(0x08)
	struct TArray<struct FString> Slots; // 0x28(0x10)
	double Durability; // 0x38(0x08)
	double MaxDurability; // 0x40(0x08)
	struct FString LockedInRound; // 0x48(0x10)
	struct FString Etag; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminMutateInventoryMutation
// Size: 0x70 (Inherited: 0x00)
struct FPioneerAdminMutateInventoryMutation {
	char pad_0[0x70]; // 0x00(0x70)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminMutateInventoryRequest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerAdminMutateInventoryRequest {
	struct TArray<struct FPioneerAdminMutateInventoryMutation> Mutations; // 0x00(0x10)
	struct FString AllowBypassLockedInRound; // 0x10(0x10)
	struct FString RequestID; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminMutateInventoryResponse
// Size: 0x80 (Inherited: 0x00)
struct FPioneerAdminMutateInventoryResponse {
	struct FPioneerAdminChangeset Changeset; // 0x00(0x80)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminQuestObjective
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminQuestObjective {
	int64_t Amount; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminQuest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerAdminQuest {
	struct FString InstanceId; // 0x00(0x10)
	enum class EPioneerAdminQuestState State; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t UpdatedAt; // 0x18(0x08)
	struct TArray<struct FPioneerAdminQuestObjective> Objectives; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminResetRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminResetRequest {
	struct TArray<enum class EPioneerAdminResetResource> Resources; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdateCodexEntriesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminUpdateCodexEntriesRequest {
	struct TArray<struct FPioneerAdminCodexEntryUpdate> Updates; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdateCodexEntriesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminUpdateCodexEntriesResponse {
	struct TArray<struct FPioneerAdminCodexEntryState> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdateQuestsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminUpdateQuestsRequest {
	struct TArray<struct FPioneerAdminQuest> Quests; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerAdminUpdateQuestsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerAdminUpdateQuestsResponse {
	struct TArray<struct FPioneerAdminQuest> Quests; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineInventoryItem
// Size: 0x68 (Inherited: 0x00)
struct FPioneerOnlineInventoryItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct TArray<struct FString> Slots; // 0x20(0x10)
	double Durability; // 0x30(0x08)
	double MaxDurability; // 0x38(0x08)
	struct FString LockedInRound; // 0x40(0x10)
	struct FString Etag; // 0x50(0x10)
	int64_t UpdatedAt; // 0x60(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptBuildOfferRequest
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineAcceptBuildOfferRequest {
	int64_t OfferId; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineInventoryItem> ItemsToConsume; // 0x08(0x10)
	struct FString SlotInstanceId; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutatedInventoryItems
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineMutatedInventoryItems {
	struct TArray<struct FPioneerOnlineInventoryItem> Created; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineInventoryItem> Updated; // 0x10(0x10)
	struct TArray<struct FString> Deleted; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOfferTransaction
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineOfferTransaction {
	struct FString ID; // 0x00(0x10)
	int64_t OfferId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutatedOffers
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineMutatedOffers {
	struct TArray<struct FPioneerOnlineOfferTransaction> TransactionsUpdated; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCreatedQuest
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineCreatedQuest {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t QuestGameAssetId; // 0x10(0x08)
	enum class EPioneerOnlineQuestState QuestState; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FString QuestEtag; // 0x20(0x10)
	int64_t ExpiresAt; // 0x30(0x08)
	int64_t UpdatedAt; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCreatedQuestObjective
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineCreatedQuestObjective {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t Amount; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpdatedQuest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineUpdatedQuest {
	struct FString QuestInstanceId; // 0x00(0x10)
	enum class EPioneerOnlineQuestState QuestState; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FString QuestEtag; // 0x18(0x10)
	int64_t UpdatedAt; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpdatedQuestObjective
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineUpdatedQuestObjective {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t Amount; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutatedQuests
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineMutatedQuests {
	struct TArray<struct FPioneerOnlineCreatedQuest> Created; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineUpdatedQuest> Updated; // 0x10(0x10)
	struct TArray<struct FPioneerOnlineCreatedQuestObjective> CreatedObjectives; // 0x20(0x10)
	struct TArray<struct FPioneerOnlineUpdatedQuestObjective> UpdatedObjectives; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePlayerStat
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlinePlayerStat {
	int64_t EventID; // 0x00(0x08)
	int64_t TargetId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGlobalPlayerStatScope
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGlobalPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderPlayerStatScope
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineRaiderPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	struct FString RaiderId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRankSeasonPlayerStatScope
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineRankSeasonPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	int64_t RankSeasonId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRankWindowPlayerStatScope
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineRankWindowPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	int64_t RankWindowId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUnknownPlayerStatScope
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineUnknownPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	struct FString ScopeName; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePlayerStatScope
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlinePlayerStatScope {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineScopedPlayerStats
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineScopedPlayerStats {
	struct FPioneerOnlinePlayerStatScope Scope; // 0x00(0x28)
	struct TArray<struct FPioneerOnlinePlayerStat> PlayerStats; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutatedStats
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineMutatedStats {
	struct TArray<struct FPioneerOnlineScopedPlayerStats> ScopedPlayerStats; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProgressionNotificationCraftingXPGain
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineProgressionNotificationCraftingXPGain {
	struct FString Discriminant; // 0x00(0x10)
	int64_t CraftedItemGameAssetId; // 0x10(0x08)
	int64_t XpAmount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProgressionNotificationLevelUp
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineProgressionNotificationLevelUp {
	struct FString Discriminant; // 0x00(0x10)
	int64_t LevelGroupId; // 0x10(0x08)
	int64_t Level; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRewardedItem
// Size: 0x48 (Inherited: 0x00)
struct FPioneerOnlineRewardedItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
	struct TArray<struct FString> Slots; // 0x18(0x10)
	struct FString AliasInstanceId; // 0x28(0x10)
	int64_t MaxAmount; // 0x38(0x08)
	bool HideInUi; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProgressionNotificationRewards
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineProgressionNotificationRewards {
	struct TArray<struct FPioneerOnlineRewardedItem> RewardItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProgressionNotificationMasteryObjectiveRewardsReceived
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineProgressionNotificationMasteryObjectiveRewardsReceived {
	struct FString Discriminant; // 0x00(0x10)
	int64_t ObjectiveId; // 0x10(0x08)
	int64_t Milestone; // 0x18(0x08)
	struct FPioneerOnlineProgressionNotificationRewards Rewards; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProgressionNotification
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineProgressionNotification {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineChangeset
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineChangeset {
	struct FPioneerOnlineMutatedInventoryItems Items; // 0x00(0x30)
	struct FPioneerOnlineMutatedQuests Quests; // 0x30(0x40)
	struct FPioneerOnlineMutatedStats Stats; // 0x70(0x10)
	struct FPioneerOnlineMutatedOffers Offers; // 0x80(0x10)
	struct TArray<struct FPioneerOnlineProgressionNotification> Notifications; // 0x90(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptBuildOfferResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineAcceptBuildOfferResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FString BuiltItem; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptCommunityEventOfferRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineAcceptCommunityEventOfferRequest {
	int64_t OfferId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	struct TArray<struct FPioneerOnlineInventoryItem> ItemsToConsume; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineTimedOfferTransaction
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineTimedOfferTransaction {
	int64_t OfferId; // 0x00(0x08)
	struct FString TransactionId; // 0x08(0x10)
	struct FString OwnerInstanceId; // 0x18(0x10)
	int64_t StartTime; // 0x28(0x08)
	int64_t DurationInSeconds; // 0x30(0x08)
	int64_t Amount; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptCommunityEventOfferResponse
// Size: 0xe0 (Inherited: 0x00)
struct FPioneerOnlineAcceptCommunityEventOfferResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FPioneerOnlineTimedOfferTransaction Transaction; // 0xa0(0x40)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptLimitedOffersRequest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineAcceptLimitedOffersRequest {
	int64_t OfferId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	struct TArray<struct FPioneerOnlineInventoryItem> ItemsToConsume; // 0x10(0x10)
	struct FString OwnerInstanceId; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptLimitedOffersResponse
// Size: 0xe0 (Inherited: 0x00)
struct FPioneerOnlineAcceptLimitedOffersResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FPioneerOnlineTimedOfferTransaction LimitedOfferTransaction; // 0xa0(0x40)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptOffersRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineAcceptOffersRequest {
	int64_t OfferId; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineInventoryItem> ItemsToConsume; // 0x08(0x10)
	int64_t Amount; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptOffersResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineAcceptOffersResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptQuestRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineAcceptQuestRequest {
	struct FString InstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptQuestResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineAcceptQuestResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptTimedOfferRequest
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineAcceptTimedOfferRequest {
	int64_t OfferId; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineInventoryItem> ItemsToConsume; // 0x08(0x10)
	struct FString OwnerInstanceId; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAcceptTimedOfferResponse
// Size: 0xe0 (Inherited: 0x00)
struct FPioneerOnlineAcceptTimedOfferResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FPioneerOnlineTimedOfferTransaction TimedOfferTransaction; // 0xa0(0x40)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAutoClaimLevelsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineAutoClaimLevelsRequest {
	struct TArray<int64_t> GroupIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineWeightedRewardItem
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineWeightedRewardItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
	double Weight; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRewardPool
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineRewardPool {
	int64_t Amount; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineWeightedRewardItem> Items; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRandomRewards
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineRandomRewards {
	int64_t MaxAmount; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineRewardPool> Pools; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRewardPackage
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineRewardPackage {
	struct TArray<struct FPioneerOnlineRewardedItem> RewardedItems; // 0x00(0x10)
	struct FPioneerOnlineRandomRewards RandomRewards; // 0x10(0x18)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUnclaimedLevelRewards
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineUnclaimedLevelRewards {
	int64_t Level; // 0x00(0x08)
	struct FPioneerOnlineRewardPackage Rewards; // 0x08(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineLevelState
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineLevelState {
	int64_t GroupId; // 0x00(0x08)
	int64_t CurrentLevel; // 0x08(0x08)
	int64_t CurrentXp; // 0x10(0x08)
	struct TArray<struct FPioneerOnlineUnclaimedLevelRewards> UnclaimedRewards; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAutoClaimLevelsResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineAutoClaimLevelsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct TArray<struct FPioneerOnlineLevelState> Levels; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineAvailableExpeditionsCatchUpBonuses
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineAvailableExpeditionsCatchUpBonuses {
	int64_t ProjectAssetId; // 0x00(0x08)
	int64_t BonusItemAssetId; // 0x08(0x08)
	int64_t AmountClaimed; // 0x10(0x08)
	int64_t AmountTotalClaimable; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOperationAcceptOffer
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineOperationAcceptOffer {
	struct FString Discriminator; // 0x00(0x10)
	int64_t OfferId; // 0x10(0x08)
	int64_t Times; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOperationRecycle
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineOperationRecycle {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t Amount; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOperation
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineOperation {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBatchOperationRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineBatchOperationRequest {
	struct TArray<struct FPioneerOnlineOperation> Operations; // 0x00(0x10)
	struct FString RequestID; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBatchOperationResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineBatchOperationResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBattlePassEntryLayout
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineBattlePassEntryLayout {
	int64_t Row; // 0x00(0x08)
	int64_t RowSpan; // 0x08(0x08)
	int64_t Column; // 0x10(0x08)
	int64_t ColumnSpan; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCostItem
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineCostItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCostPackage
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCostPackage {
	struct TArray<struct FPioneerOnlineCostItem> CostItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBattlePassEntry
// Size: 0x68 (Inherited: 0x00)
struct FPioneerOnlineBattlePassEntry {
	int64_t EntryId; // 0x00(0x08)
	int64_t StyleAssetID; // 0x08(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x10(0x28)
	struct FPioneerOnlineCostPackage Cost; // 0x38(0x10)
	struct FPioneerOnlineBattlePassEntryLayout Layout; // 0x48(0x20)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBattlePassPage
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineBattlePassPage {
	int64_t PageID; // 0x00(0x08)
	struct FPioneerOnlineCostPackage RequiredSpendAmount; // 0x08(0x10)
	struct TArray<struct FPioneerOnlineBattlePassEntry> Entries; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBattlePass
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineBattlePass {
	int64_t BattlePassID; // 0x00(0x08)
	int64_t AssetId; // 0x08(0x08)
	int64_t StartAt; // 0x10(0x08)
	int64_t EndAt; // 0x18(0x08)
	struct FPioneerOnlineCostPackage Cost; // 0x20(0x10)
	struct TArray<struct FPioneerOnlineBattlePassPage> Pages; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBattlePassDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineBattlePassDescription {
	struct TArray<struct FPioneerOnlineBattlePass> BattlePasses; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBattlePassState
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineBattlePassState {
	int64_t BattlePassID; // 0x00(0x08)
	bool IsOwned; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TArray<int64_t> ClaimedPages; // 0x10(0x10)
	struct TArray<int64_t> ClaimedEntries; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBonusSource
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineBonusSource {
	enum class EPioneerOnlineBonusSourceKind Kind; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t AssetId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBonusEffect
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineBonusEffect {
	struct FString BonusId; // 0x00(0x10)
	enum class EPioneerOnlineBonusEffectKind Kind; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	double Amount; // 0x18(0x08)
	bool IsPending; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FPioneerOnlineBonusSource Source; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBonusEffectDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineBonusEffectDescription {
	enum class EPioneerOnlineBonusEffectKind Kind; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	double Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineBonusItem
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineBonusItem {
	struct FString BonusId; // 0x00(0x10)
	int64_t ItemAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	bool IsPending; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FPioneerOnlineBonusSource Source; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCancelPendingInventoryItemUpgradeRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCancelPendingInventoryItemUpgradeRequest {
	struct FString InstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCancelPendingInventoryItemUpgradeResponse
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineCancelPendingInventoryItemUpgradeResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCancelQueuedTimedOfferRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCancelQueuedTimedOfferRequest {
	struct FString OfferTransactionId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCancelQueuedTimedOfferResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCancelQueuedTimedOfferResponse {
	struct TArray<struct FPioneerOnlineTimedOfferTransaction> TimedOfferTransactions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCancelTimedOfferRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCancelTimedOfferRequest {
	struct FString OfferTransactionId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimBattlePassEntryRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineClaimBattlePassEntryRequest {
	int64_t BattlePassID; // 0x00(0x08)
	int64_t EntryId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimBattlePassEntryResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineClaimBattlePassEntryResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct TArray<struct FPioneerOnlineBattlePassState> BattlePassStates; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimCompensationsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineClaimCompensationsRequest {
	struct TArray<struct FString> CompensationIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSubCompensationItem
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineSubCompensationItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompensationItem
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineCompensationItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	struct TArray<struct FPioneerOnlineSubCompensationItem> SubItems; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompensationContent
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCompensationContent {
	struct TArray<struct FPioneerOnlineCompensationItem> Items; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompensation
// Size: 0x48 (Inherited: 0x00)
struct FPioneerOnlineCompensation {
	struct FString ID; // 0x00(0x10)
	bool Claimed; // 0x10(0x01)
	enum class EPioneerOnlineCompensationSourceType Source; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
	struct FString SourceType; // 0x18(0x10)
	struct FPioneerOnlineCompensationContent Content; // 0x28(0x10)
	int64_t CreatedAt; // 0x38(0x08)
	int64_t UpdatedAt; // 0x40(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimCompensationsResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineClaimCompensationsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct TArray<struct FPioneerOnlineCompensation> Compensations; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimCrateRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineClaimCrateRequest {
	struct FString InstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCrate
// Size: 0x68 (Inherited: 0x00)
struct FPioneerOnlineCrate {
	struct FString Name; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	struct FPioneerOnlineRewardPackage ClaimRewardPackage; // 0x28(0x28)
	struct FString Etag; // 0x50(0x10)
	enum class EPioneerOnlineCrateState State; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimCrateResponse
// Size: 0x108 (Inherited: 0x00)
struct FPioneerOnlineClaimCrateResponse {
	struct FPioneerOnlineCrate Crate; // 0x00(0x68)
	struct FPioneerOnlineChangeset Changeset; // 0x68(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimMasteryObjectiveRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineClaimMasteryObjectiveRequest {
	int64_t RankWindowId; // 0x00(0x08)
	int64_t ObjectiveId; // 0x08(0x08)
	struct TArray<int64_t> MilestoneIndexes; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimMasteryObjectivesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineClaimMasteryObjectivesRequest {
	struct TArray<struct FPioneerOnlineClaimMasteryObjectiveRequest> Objectives; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMasteryObjectiveState
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineMasteryObjectiveState {
	int64_t RankWindowId; // 0x00(0x08)
	int64_t ObjectiveId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
	struct TArray<enum class EPioneerOnlineMasteryMilestoneRewardState> MilestoneRewardStates; // 0x18(0x10)
	enum class EPioneerOnlineMasteryObjectiveStreakState StreakState; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	int64_t StreakPoints; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimMasteryObjectivesResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineClaimMasteryObjectivesResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct TArray<struct FPioneerOnlineMasteryObjectiveState> Objectives; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimRoundCraftingOffersResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineClaimRoundCraftingOffersResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct TArray<struct FPioneerOnlineTimedOfferTransaction> Transactions; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimSeasonalRewardsRequest
// Size: 0x08 (Inherited: 0x00)
struct FPioneerOnlineClaimSeasonalRewardsRequest {
	int64_t RankSeasonId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineClaimSeasonalRewardsResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineClaimSeasonalRewardsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestDescriptionObjectiveParameter
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineQuestDescriptionObjectiveParameter {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexEntryUnlockObjective
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineCodexEntryUnlockObjective {
	struct FString Type; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineQuestDescriptionObjectiveParameter> Parameters; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexEntryUnlockQuest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCodexEntryUnlockQuest {
	int64_t QuestId; // 0x00(0x08)
	enum class EPioneerOnlineCodexQuestUnlockOn UnlockOn; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexEntryTextEntry
// Size: 0x48 (Inherited: 0x00)
struct FPioneerOnlineCodexEntryTextEntry {
	int64_t ID; // 0x00(0x08)
	struct FString Text; // 0x08(0x10)
	struct FPioneerOnlineCodexEntryUnlockObjective UnlockObjective; // 0x18(0x20)
	struct FPioneerOnlineCodexEntryUnlockQuest UnlockQuest; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexEntryBlock
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineCodexEntryBlock {
	int64_t ID; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineCodexEntryTextEntry> TextEntries; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexEntry
// Size: 0x98 (Inherited: 0x00)
struct FPioneerOnlineCodexEntry {
	int64_t ID; // 0x00(0x08)
	struct FString HumanId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	struct TArray<int64_t> RelatedEntries; // 0x28(0x10)
	int64_t ImageAssetId; // 0x38(0x08)
	int64_t SecondaryImageAssetId; // 0x40(0x08)
	struct TArray<int64_t> MediaAssetIds; // 0x48(0x10)
	struct FString PreviewText; // 0x58(0x10)
	struct FString Quote; // 0x68(0x10)
	struct FString Title; // 0x78(0x10)
	struct TArray<struct FPioneerOnlineCodexEntryBlock> Blocks; // 0x88(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexSubcategory
// Size: 0x58 (Inherited: 0x00)
struct FPioneerOnlineCodexSubcategory {
	int64_t ID; // 0x00(0x08)
	struct FString HumanId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	struct FString PreviewText; // 0x28(0x10)
	struct FString Title; // 0x38(0x10)
	struct TArray<struct FPioneerOnlineCodexEntry> Entries; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexCategory
// Size: 0x68 (Inherited: 0x00)
struct FPioneerOnlineCodexCategory {
	int64_t ID; // 0x00(0x08)
	struct FString HumanId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	int64_t SortIndex; // 0x28(0x08)
	int64_t ImageAssetId; // 0x30(0x08)
	struct FString PreviewText; // 0x38(0x10)
	struct FString Title; // 0x48(0x10)
	struct TArray<struct FPioneerOnlineCodexSubcategory> SubCategories; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCodexDescription {
	struct TArray<struct FPioneerOnlineCodexCategory> Categories; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCodexDescriptionResponse {
	struct FPioneerOnlineCodexDescription CodexDescription; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCodexEntryState
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCodexEntryState {
	int64_t EntryAssetId; // 0x00(0x08)
	bool Unlocked; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommitItemByAssetId
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineCommitItemByAssetId {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ItemAssetId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommitItemByInstanceId
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineCommitItemByInstanceId {
	struct FString Discriminator; // 0x00(0x10)
	struct FString ItemInstanceId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommitItemByIdentity
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineCommitItemByIdentity {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemToCommit
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineItemToCommit {
	struct FPioneerOnlineCommitItemByIdentity Identity; // 0x00(0x28)
	int64_t Amount; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommitItemsToProjectRequest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineCommitItemsToProjectRequest {
	struct FString ProjectID; // 0x00(0x10)
	int64_t GoalAssetId; // 0x10(0x08)
	bool StashOnly; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FPioneerOnlineItemToCommit> ItemsToCommit; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProjectGoal
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineProjectGoal {
	struct FString GoalId; // 0x00(0x10)
	int64_t GoalAssetId; // 0x10(0x08)
	enum class EPioneerOnlineProjectGoalState State; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	int64_t Amount; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProject
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineProject {
	struct FString ProjectID; // 0x00(0x10)
	int64_t ProjectAssetId; // 0x10(0x08)
	enum class EPioneerOnlineProjectState State; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FPioneerOnlineProjectGoal> Goals; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommitItemsToProjectResponse
// Size: 0xd0 (Inherited: 0x00)
struct FPioneerOnlineCommitItemsToProjectResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FPioneerOnlineProject Project; // 0xa0(0x30)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventContributor
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventContributor {
	int64_t TenancyUserExternalId; // 0x00(0x08)
	int64_t Contribution; // 0x08(0x08)
	int64_t Rank; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventInGameRewardDescription
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventInGameRewardDescription {
	int64_t BaseItemId; // 0x00(0x08)
	double Multiplier; // 0x08(0x08)
	struct FPioneerOnlineRewardPackage RewardPackage; // 0x10(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventStageDescription
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventStageDescription {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct FString LongDescription; // 0x28(0x10)
	struct FString StatusDescription; // 0x38(0x10)
	struct FString AdditionalInfo; // 0x48(0x10)
	bool IsActive; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	int64_t Goal; // 0x60(0x08)
	struct TArray<int64_t> Offers; // 0x68(0x10)
	int64_t LevelGroup; // 0x78(0x08)
	struct TArray<struct FPioneerOnlineCommunityEventInGameRewardDescription> InGameRewards; // 0x80(0x10)
	int64_t Map; // 0x90(0x08)
	int64_t Image; // 0x98(0x08)
	int64_t Project; // 0xa0(0x08)
	int64_t MapCondition; // 0xa8(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventDescription
// Size: 0x70 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventDescription {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct FString EndTitle; // 0x28(0x10)
	struct FString EndDescription; // 0x38(0x10)
	int64_t EndImage; // 0x48(0x08)
	int64_t StartDate; // 0x50(0x08)
	int64_t EndDate; // 0x58(0x08)
	struct TArray<struct FPioneerOnlineCommunityEventStageDescription> Stages; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventsDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventsDescription {
	struct TArray<struct FPioneerOnlineCommunityEventDescription> Events; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventsDescriptionResponse {
	struct TArray<struct FPioneerOnlineCommunityEventDescription> Events; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventState
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventState {
	int64_t CommunityEventId; // 0x00(0x08)
	int64_t TotalContribution; // 0x08(0x08)
	struct TArray<struct FPioneerOnlineCommunityEventContributor> TopContributors; // 0x10(0x10)
	struct TArray<struct FPioneerOnlineCommunityEventContributor> NearContributors; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCommunityEventTT1Response
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineCommunityEventTT1Response {
	int64_t Goal; // 0x00(0x08)
	int64_t Progress; // 0x08(0x08)
	int64_t PlayerContribution; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompactPlayerProfile
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineCompactPlayerProfile {
	int64_t TenancyUserId; // 0x00(0x08)
	struct FString DisplayName; // 0x08(0x10)
	struct FString ThirdPartyUserId; // 0x18(0x10)
	struct FString ThirdPartyLastSeenAccountName; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompletePendingInventoryItemUpgradeRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCompletePendingInventoryItemUpgradeRequest {
	struct FString InstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompletePendingInventoryItemUpgradeResponse
// Size: 0x108 (Inherited: 0x00)
struct FPioneerOnlineCompletePendingInventoryItemUpgradeResponse {
	struct FPioneerOnlineInventoryItem UpgradedItem; // 0x00(0x68)
	struct FPioneerOnlineChangeset Changeset; // 0x68(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompleteProjectStepRequest
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineCompleteProjectStepRequest {
	struct FString ProjectID; // 0x00(0x10)
	int64_t StepAssetId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompleteProjectStepResponse
// Size: 0xd0 (Inherited: 0x00)
struct FPioneerOnlineCompleteProjectStepResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FPioneerOnlineProject Project; // 0xa0(0x30)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompleteQuestRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCompleteQuestRequest {
	struct FString InstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompleteQuestResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineCompleteQuestResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompleteTimedOfferRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineCompleteTimedOfferRequest {
	struct FString OfferTransactionId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCompleteTimedOfferResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineCompleteTimedOfferResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineConsumeInventoryItem
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineConsumeInventoryItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t Amount; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineCreateInventoryItemMutation
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineCreateInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	int64_t Amount; // 0x28(0x08)
	struct TArray<struct FString> Slots; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineDeleteInventoryItemMutation
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineDeleteInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineDepartExpeditionResponse
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineDepartExpeditionResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineEmbarkProduct
// Size: 0x68 (Inherited: 0x00)
struct FPioneerOnlineEmbarkProduct {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ProductId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
	struct FPioneerOnlineCostPackage Cost; // 0x48(0x10)
	struct TArray<int64_t> ChildProductIds; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineEmbarkUserInventory
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineEmbarkUserInventory {
	struct FEmbarkUserId EmbarkUserId; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineInventoryItem> Items; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineEpicProduct
// Size: 0x70 (Inherited: 0x00)
struct FPioneerOnlineEpicProduct {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ProductId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
	double PricePoint; // 0x48(0x08)
	struct FString EpicEntitlementName; // 0x50(0x10)
	struct FString EpicOfferId; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineExpeditionValueRewardsDescription
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineExpeditionValueRewardsDescription {
	int64_t ThresholdAmount; // 0x00(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x08(0x28)
	int64_t MaxPerExpedition; // 0x30(0x08)
	int64_t MaxOverall; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineExpeditionRewardTier
// Size: 0x88 (Inherited: 0x00)
struct FPioneerOnlineExpeditionRewardTier {
	int64_t TierID; // 0x00(0x08)
	int64_t OrderIdx; // 0x08(0x08)
	struct TArray<struct FPioneerOnlineBonusEffectDescription> BonusEffects; // 0x10(0x10)
	struct FPioneerOnlineExpeditionValueRewardsDescription ValueRewards; // 0x20(0x40)
	struct FPioneerOnlineRewardPackage Rewards; // 0x60(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineExpeditionsConfig
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineExpeditionsConfig {
	struct TArray<struct FPioneerOnlineExpeditionRewardTier> RewardTiers; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineExpeditionsDepartedCount
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineExpeditionsDepartedCount {
	int64_t TenancyUserIds; // 0x00(0x08)
	int64_t Count; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineExpeditionsStatus
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineExpeditionsStatus {
	enum class EPioneerOnlineExpeditionsState State; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t CompletedExpeditions; // 0x08(0x08)
	struct FString RaiderId; // 0x10(0x10)
	int64_t RaiderJoinedAt; // 0x20(0x08)
	int64_t CurrentTier; // 0x28(0x08)
	int64_t NextTier; // 0x30(0x08)
	int64_t LastChanceWindowId; // 0x38(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineExpeditionWindow
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineExpeditionWindow {
	int64_t SeasonId; // 0x00(0x08)
	int64_t StartDate; // 0x08(0x08)
	int64_t EndDate; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemConfigArraySlot
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineItemConfigArraySlot {
	struct FString Discriminator; // 0x00(0x10)
	int64_t SlotAssetId; // 0x10(0x08)
	int64_t NumberOfSlots; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemConfigNoSlot
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineItemConfigNoSlot {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemConfigSingleSlot
// Size: 0x70 (Inherited: 0x00)
struct FPioneerOnlineItemConfigSingleSlot {
	struct FString Discriminator; // 0x00(0x10)
	struct TSet<int64_t> AllowedSlotAssetIds; // 0x10(0x50)
	bool IsRequired; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	int64_t DefaultSlotAssetId; // 0x68(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemConfigStructuralSlot
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineItemConfigStructuralSlot {
	struct FString Discriminator; // 0x00(0x10)
	struct TArray<int64_t> SlotAssetIDs; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemConfig
// Size: 0x78 (Inherited: 0x00)
struct FPioneerOnlineItemConfig {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemRepairDescription
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineItemRepairDescription {
	struct FPioneerOnlineCostPackage CostPackage; // 0x00(0x10)
	double DurabilityReward; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemScrapDescription
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineItemScrapDescription {
	struct FPioneerOnlineRewardPackage RewardPackage; // 0x00(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemUpgradeDescription
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineItemUpgradeDescription {
	int64_t NextItemGameAssetId; // 0x00(0x08)
	struct FPioneerOnlineCostPackage CostPackage; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemDescription
// Size: 0x1d0 (Inherited: 0x00)
struct FPioneerOnlineItemDescription {
	int64_t GameAssetId; // 0x00(0x08)
	struct FString ItemType; // 0x08(0x10)
	bool Stackable; // 0x18(0x01)
	bool Unique; // 0x19(0x01)
	char pad_1a[0x6]; // 0x1a(0x06)
	int64_t MaxAmount; // 0x20(0x08)
	int64_t BaseGameAssetId; // 0x28(0x08)
	int64_t QualityLevel; // 0x30(0x08)
	struct FPioneerOnlineItemConfig SlotConfig; // 0x38(0x78)
	struct FPioneerOnlineItemScrapDescription Scrap; // 0xb0(0x28)
	struct FPioneerOnlineItemRepairDescription Repair; // 0xd8(0x18)
	struct FPioneerOnlineItemUpgradeDescription Upgrade; // 0xf0(0x18)
	struct FPioneerOnlineRewardPackage Recycle; // 0x108(0x28)
	struct TSet<int64_t> GroupIds; // 0x130(0x50)
	struct TSet<struct FString> Tags; // 0x180(0x50)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemsDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineItemsDescription {
	struct TArray<struct FPioneerOnlineItemDescription> ItemDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineLevel
// Size: 0x48 (Inherited: 0x00)
struct FPioneerOnlineLevel {
	int64_t Level; // 0x00(0x08)
	int64_t GroupId; // 0x08(0x08)
	int64_t AbsoluteAmountRequired; // 0x10(0x08)
	int64_t RelativeAmountRequired; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePlayerStatId
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlinePlayerStatId {
	struct FPioneerOnlinePlayerStatScope Scope; // 0x00(0x28)
	int64_t EventID; // 0x28(0x08)
	int64_t TargetId; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineLevelGroup
// Size: 0x70 (Inherited: 0x00)
struct FPioneerOnlineLevelGroup {
	int64_t GroupId; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
	int64_t XpItemGameAssetId; // 0x18(0x08)
	int64_t TrackingItemId; // 0x20(0x08)
	struct FPioneerOnlinePlayerStatId TrackingPlayerStat; // 0x28(0x38)
	struct TArray<struct FPioneerOnlineLevel> Levels; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineLevelGroups
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineLevelGroups {
	struct TArray<struct FPioneerOnlineLevelGroup> Groups; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMasteryObjectiveMilestone
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineMasteryObjectiveMilestone {
	int64_t Points; // 0x00(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x08(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMasteryObjective
// Size: 0x98 (Inherited: 0x00)
struct FPioneerOnlineMasteryObjective {
	int64_t ID; // 0x00(0x08)
	int64_t RankWindowId; // 0x08(0x08)
	struct FString Title; // 0x10(0x10)
	struct FString Description; // 0x20(0x10)
	struct FString LongDescription; // 0x30(0x10)
	int64_t ImageId; // 0x40(0x08)
	struct FString Type; // 0x48(0x10)
	struct TArray<struct FPioneerOnlineQuestDescriptionObjectiveParameter> Parameters; // 0x58(0x10)
	struct TArray<int64_t> MapIds; // 0x68(0x10)
	int64_t MapCondition; // 0x78(0x08)
	double Multiplier; // 0x80(0x08)
	struct TArray<struct FPioneerOnlineMasteryObjectiveMilestone> Milestones; // 0x88(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMasteryObjectivesDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineMasteryObjectivesDescription {
	struct TArray<struct FPioneerOnlineMasteryObjective> Objectives; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOfferLimit
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineOfferLimit {
	int64_t RefreshInterval; // 0x00(0x08)
	int64_t MaxAmount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOfferRequirement
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineOfferRequirement {
	int64_t ItemGameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOfferDescription
// Size: 0xc0 (Inherited: 0x00)
struct FPioneerOnlineOfferDescription {
	int64_t OfferId; // 0x00(0x08)
	struct FString OfferType; // 0x08(0x10)
	struct FString Title; // 0x18(0x10)
	struct FString LocalizedDescription; // 0x28(0x10)
	int64_t OwnerGameAssetId; // 0x38(0x08)
	int64_t DurationInSeconds; // 0x40(0x08)
	bool IsVisible; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct FPioneerOnlineOfferRequirement> RequiredItems; // 0x50(0x10)
	struct FPioneerOnlineCostPackage CostPackage; // 0x60(0x10)
	struct FPioneerOnlineRewardPackage RewardPackage; // 0x70(0x28)
	int64_t OrderIndex; // 0x98(0x08)
	int64_t StartDate; // 0xa0(0x08)
	int64_t EndDate; // 0xa8(0x08)
	struct FPioneerOnlineOfferLimit Limited; // 0xb0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOfferDescriptions
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineOfferDescriptions {
	struct TArray<struct FPioneerOnlineOfferDescription> OfferDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestDescriptionEdge
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineQuestDescriptionEdge {
	enum class EPioneerOnlineQuestDescriptionState RequiredState; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t QuestGameAssetId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestDescriptionObjective
// Size: 0x70 (Inherited: 0x00)
struct FPioneerOnlineQuestDescriptionObjective {
	struct FString Type; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct TArray<struct FPioneerOnlineQuestDescriptionObjectiveParameter> Parameters; // 0x20(0x10)
	struct FString Description; // 0x30(0x10)
	struct FString VoiceOver; // 0x40(0x10)
	struct TArray<int64_t> ParentObjectiveIds; // 0x50(0x10)
	int64_t GroupId; // 0x60(0x08)
	bool Optional; // 0x68(0x01)
	bool Hidden; // 0x69(0x01)
	enum class EPioneerOnlineQuestDescriptionObjectiveMusic Music; // 0x6a(0x01)
	char pad_6b[0x5]; // 0x6b(0x05)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestDescription
// Size: 0x138 (Inherited: 0x00)
struct FPioneerOnlineQuestDescription {
	int64_t GameAssetId; // 0x00(0x08)
	enum class EPioneerOnlineQuestCadence Cadence; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	int64_t OwnerGameAssetId; // 0x10(0x08)
	struct FString Title; // 0x18(0x10)
	struct FString Description; // 0x28(0x10)
	struct TArray<struct FString> Tags; // 0x38(0x10)
	int64_t ImageId; // 0x48(0x08)
	struct FString ToolTip; // 0x50(0x10)
	struct FPioneerOnlineRewardPackage AcceptRewardPackage; // 0x60(0x28)
	struct FPioneerOnlineRewardPackage CompleteRewardPackage; // 0x88(0x28)
	struct TArray<struct FPioneerOnlineQuestDescriptionEdge> QuestEdges; // 0xb0(0x10)
	struct TArray<struct FPioneerOnlineQuestDescriptionObjective> QuestObjectives; // 0xc0(0x10)
	struct FString VoiceOver; // 0xd0(0x10)
	struct FString VideoTag; // 0xe0(0x10)
	struct FString OnOpenVideoTag; // 0xf0(0x10)
	struct FString OnClaimVideoTag; // 0x100(0x10)
	struct FString Map; // 0x110(0x10)
	struct TArray<int64_t> MapIds; // 0x120(0x10)
	bool Hidden; // 0x130(0x01)
	bool AutoAccept; // 0x131(0x01)
	bool AutoComplete; // 0x132(0x01)
	char pad_133[0x5]; // 0x133(0x05)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestsDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineQuestsDescription {
	struct TArray<struct FPioneerOnlineQuestDescription> QuestDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderProjectGoalDescription
// Size: 0x80 (Inherited: 0x00)
struct FPioneerOnlineRaiderProjectGoalDescription {
	int64_t ID; // 0x00(0x08)
	enum class EPioneerOnlineRaiderProjectGoalType GoalType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FString Title; // 0x10(0x10)
	struct TArray<int64_t> TargetIds; // 0x20(0x10)
	struct TArray<struct FString> TargetTags; // 0x30(0x10)
	int64_t Amount; // 0x40(0x08)
	bool Required; // 0x48(0x01)
	bool CanRepeat; // 0x49(0x01)
	char pad_4a[0x6]; // 0x4a(0x06)
	struct FPioneerOnlineRewardPackage RewardPackage; // 0x50(0x28)
	int64_t MaxRewards; // 0x78(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderProjectPhaseStepDescription
// Size: 0x60 (Inherited: 0x00)
struct FPioneerOnlineRaiderProjectPhaseStepDescription {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct TArray<struct FPioneerOnlineRaiderProjectGoalDescription> Goals; // 0x28(0x10)
	struct FPioneerOnlineRewardPackage RewardPackage; // 0x38(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderProjectPhaseDescription
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlineRaiderProjectPhaseDescription {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct TArray<struct FPioneerOnlineRaiderProjectPhaseStepDescription> Steps; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderProjectDescription
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineRaiderProjectDescription {
	int64_t ID; // 0x00(0x08)
	enum class EPioneerOnlineRaiderProjectType ProjectType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FString Title; // 0x10(0x10)
	struct FString Description; // 0x20(0x10)
	struct FString LongDescription; // 0x30(0x10)
	struct FString CompletedTitle; // 0x40(0x10)
	struct FString CompletedDescription; // 0x50(0x10)
	int64_t DataAssetId; // 0x60(0x08)
	int64_t StartDate; // 0x68(0x08)
	int64_t EndDate; // 0x70(0x08)
	struct TArray<struct FPioneerOnlineRaiderProjectPhaseDescription> Phases; // 0x78(0x10)
	struct FPioneerOnlineRewardPackage Rewards; // 0x88(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderProjectsDescription
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineRaiderProjectsDescription {
	struct TArray<struct FPioneerOnlineRaiderProjectDescription> Projects; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineExpeditionWindow> ExpeditionWindows; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRankThreshold
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineRankThreshold {
	double Percentile; // 0x00(0x08)
	int64_t Transition; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRank
// Size: 0x98 (Inherited: 0x00)
struct FPioneerOnlineRank {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	int64_t IconAssetId; // 0x28(0x08)
	struct FString Color; // 0x30(0x10)
	int64_t RankSeasonId; // 0x40(0x08)
	int64_t Size; // 0x48(0x08)
	bool TopN; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
	struct TArray<struct FPioneerOnlineRankThreshold> Thresholds; // 0x58(0x10)
	struct FPioneerOnlineRewardPackage Reward; // 0x68(0x28)
	int64_t Index; // 0x90(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRanksDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineRanksDescription {
	struct TArray<struct FPioneerOnlineRank> Ranks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRankWindow
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineRankWindow {
	int64_t ID; // 0x00(0x08)
	int64_t StartDate; // 0x08(0x08)
	int64_t EndDate; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRankSeason
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineRankSeason {
	int64_t ID; // 0x00(0x08)
	int64_t StartDate; // 0x08(0x08)
	int64_t EndDate; // 0x10(0x08)
	struct TArray<struct FPioneerOnlineRankWindow> Windows; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSeasonsDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineSeasonsDescription {
	struct TArray<struct FPioneerOnlineRankSeason> Seasons; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSkillTreeNode
// Size: 0x58 (Inherited: 0x00)
struct FPioneerOnlineSkillTreeNode {
	int64_t NodeId; // 0x00(0x08)
	int64_t CharacterSkillId; // 0x08(0x08)
	int64_t MaxLevel; // 0x10(0x08)
	int64_t MinTotalInvestment; // 0x18(0x08)
	bool RequireAllParents; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FString Category; // 0x28(0x10)
	struct TArray<int64_t> ParentNodeIds; // 0x38(0x10)
	struct TArray<int64_t> ChildNodeIds; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSkillTrees
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineSkillTrees {
	struct TArray<int64_t> RootNodeIds; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineSkillTreeNode> Nodes; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGameDataResponse
// Size: 0xf0 (Inherited: 0x00)
struct FPioneerOnlineGameDataResponse {
	struct FPioneerOnlineBattlePassDescription BattlepassDescription; // 0x00(0x10)
	struct FPioneerOnlineItemsDescription ItemsDescription; // 0x10(0x10)
	struct FPioneerOnlineOfferDescriptions OfferDescriptions; // 0x20(0x10)
	struct FPioneerOnlineSkillTrees SkillTrees; // 0x30(0x20)
	struct FPioneerOnlineLevelGroups LevelGroups; // 0x50(0x10)
	struct FPioneerOnlineSeasonsDescription Seasons; // 0x60(0x10)
	struct FPioneerOnlineRanksDescription Ranks; // 0x70(0x10)
	struct FPioneerOnlineMasteryObjectivesDescription MasteryObjectives; // 0x80(0x10)
	struct FPioneerOnlineCommunityEventsDescription CommunityEvents; // 0x90(0x10)
	struct FPioneerOnlineRaiderProjectsDescription Projects; // 0xa0(0x20)
	struct FPioneerOnlineExpeditionsConfig ExpeditionsConfig; // 0xc0(0x10)
	struct FPioneerOnlineCodexDescription Codex; // 0xd0(0x10)
	struct FPioneerOnlineQuestsDescription QuestDescriptions; // 0xe0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetBonusesResponse
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineGetBonusesResponse {
	struct TArray<struct FPioneerOnlineBonusItem> Items; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineBonusEffect> Effects; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetCommunityEventStateResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetCommunityEventStateResponse {
	struct TArray<struct FPioneerOnlineCommunityEventState> Events; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetExpeditionsCatchUpBonusesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetExpeditionsCatchUpBonusesResponse {
	struct TArray<struct FPioneerOnlineAvailableExpeditionsCatchUpBonuses> AvailableBonuses; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetExpeditionsDepartedCountsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetExpeditionsDepartedCountsRequest {
	struct TArray<int64_t> TenancyUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetExpeditionsDepartedCountsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetExpeditionsDepartedCountsResponse {
	struct TArray<struct FPioneerOnlineExpeditionsDepartedCount> Counts; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetExpeditionsStatusResponse
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineGetExpeditionsStatusResponse {
	struct FPioneerOnlineExpeditionsStatus Status; // 0x00(0x40)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetInventoryItemsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetInventoryItemsResponse {
	struct TArray<struct FPioneerOnlineInventoryItem> Items; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineLeagueMember
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineLeagueMember {
	int64_t TenancyUserExternalId; // 0x00(0x08)
	int64_t Points; // 0x08(0x08)
	int64_t Position; // 0x10(0x08)
	int64_t Transition; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetLeagueResponse
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineGetLeagueResponse {
	int64_t RankId; // 0x00(0x08)
	int64_t RankWindowId; // 0x08(0x08)
	struct TArray<struct FPioneerOnlineLeagueMember> Members; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetMicrosoftStoreAccessTokenResponse
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineGetMicrosoftStoreAccessTokenResponse {
	struct FString Raw; // 0x00(0x10)
	int64_t ExpiresIn; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetQuestsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetQuestsDescriptionResponse {
	struct TArray<struct FPioneerOnlineQuestDescription> QuestDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaider
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineRaider {
	struct FString RaiderId; // 0x00(0x10)
	enum class EPioneerOnlineRaiderState State; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t CreatedAt; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetRaidersResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineGetRaidersResponse {
	struct TArray<struct FPioneerOnlineRaider> Raiders; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineGetSkillTreesResponse
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineGetSkillTreesResponse {
	struct FPioneerOnlineSkillTrees SkillTrees; // 0x00(0x20)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineItemsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineItemsDescriptionResponse {
	struct TArray<struct FPioneerOnlineItemDescription> ItemDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListBattlePassesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListBattlePassesResponse {
	struct TArray<struct FPioneerOnlineBattlePassState> BattlePassStates; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListCodexEntriesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListCodexEntriesResponse {
	struct TArray<struct FPioneerOnlineCodexEntryState> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListCompensationsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListCompensationsResponse {
	struct TArray<struct FPioneerOnlineCompensation> Compensations; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListCratesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListCratesResponse {
	struct TArray<struct FPioneerOnlineCrate> Crates; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListInventoriesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListInventoriesRequest {
	struct TArray<struct FEmbarkUserId> EmbarkUserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListInventoriesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListInventoriesResponse {
	struct TArray<struct FPioneerOnlineEmbarkUserInventory> Inventories; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListLeagueProfilesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListLeagueProfilesResponse {
	struct TArray<struct FPioneerOnlineCompactPlayerProfile> Profiles; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListLevelGroupsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListLevelGroupsResponse {
	struct TArray<struct FPioneerOnlineLevelGroup> Groups; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListLevelsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListLevelsResponse {
	struct TArray<struct FPioneerOnlineLevelState> Levels; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListMasteryObjectivesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListMasteryObjectivesResponse {
	struct TArray<struct FPioneerOnlineMasteryObjectiveState> Objectives; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePendingUpgrade
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlinePendingUpgrade {
	struct FString UpgradingItemInstanceID; // 0x00(0x10)
	int64_t StartTime; // 0x10(0x08)
	int64_t DurationInSeconds; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListPendingInventoryItemUpgradesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListPendingInventoryItemUpgradesResponse {
	struct TArray<struct FPioneerOnlinePendingUpgrade> PendingUpgrades; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListPlayerStatsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListPlayerStatsResponse {
	struct TArray<struct FPioneerOnlineScopedPlayerStats> ScopedPlayerStats; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListPlayerStatsV2Request
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListPlayerStatsV2Request {
	struct TArray<struct FPioneerOnlinePlayerStatScope> Scopes; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListProductsRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineListProductsRequest {
	enum class EPioneerOnlineDistributionPlatform Platform; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMicrosoftProduct
// Size: 0x60 (Inherited: 0x00)
struct FPioneerOnlineMicrosoftProduct {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ProductId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
	double PricePoint; // 0x48(0x08)
	struct FString MicrosoftProductId; // 0x50(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePlayStationProduct
// Size: 0x70 (Inherited: 0x00)
struct FPioneerOnlinePlayStationProduct {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ProductId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
	double PricePoint; // 0x48(0x08)
	struct FString PlayStationEntitlementLabel; // 0x50(0x10)
	struct FString PlayStationProductId; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSteamProduct
// Size: 0x98 (Inherited: 0x00)
struct FPioneerOnlineSteamProduct {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ProductId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
	double PricePoint; // 0x48(0x08)
	struct FString SteamItemDefId; // 0x50(0x10)
	struct FString SteamAppId; // 0x60(0x10)
	enum class EPioneerOnlineSteamProductSteamPackageType SteamPackageType; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	int64_t SteamAppInitialPrice; // 0x78(0x08)
	int64_t SteamAppFinalPrice; // 0x80(0x08)
	struct FString SteamAppCurrency; // 0x88(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineTwitchProduct
// Size: 0x58 (Inherited: 0x00)
struct FPioneerOnlineTwitchProduct {
	struct FString Discriminator; // 0x00(0x10)
	int64_t ProductId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	struct FPioneerOnlineRewardPackage Reward; // 0x20(0x28)
	struct FString TwitchBenefitId; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProduct
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineProduct {
	char pad_0[0xa0]; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListProductsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListProductsResponse {
	struct TArray<struct FPioneerOnlineProduct> Products; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListProductsViewsRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineListProductsViewsRequest {
	enum class EPioneerOnlineDistributionPlatform Platform; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProductsViewEntry
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineProductsViewEntry {
	int64_t EntryId; // 0x00(0x08)
	int64_t ProductId; // 0x08(0x08)
	enum class EPioneerOnlineStoreProvider StoreProvider; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProductsView
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineProductsView {
	int64_t ViewId; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineProductsViewEntry> Entries; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListProductsViewsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListProductsViewsResponse {
	struct TArray<struct FPioneerOnlineProductsView> Views; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListProjectsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListProjectsRequest {
	struct TArray<enum class EPioneerOnlineProjectState> States; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListProjectsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListProjectsResponse {
	struct TArray<struct FPioneerOnlineProject> Projects; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestEdge
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineQuestEdge {
	struct FString QuestInstanceId; // 0x00(0x10)
	enum class EPioneerOnlineQuestState RequiredState; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestObjective
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineQuestObjective {
	int64_t Amount; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuest
// Size: 0x60 (Inherited: 0x00)
struct FPioneerOnlineQuest {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	enum class EPioneerOnlineQuestState State; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct TArray<struct FPioneerOnlineQuestObjective> Objectives; // 0x20(0x10)
	struct TArray<struct FPioneerOnlineQuestEdge> Edges; // 0x30(0x10)
	struct FString Etag; // 0x40(0x10)
	int64_t ExpiresAt; // 0x50(0x08)
	int64_t UpdatedAt; // 0x58(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListQuestsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListQuestsResponse {
	struct TArray<struct FPioneerOnlineQuest> Quests; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListRanksRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListRanksRequest {
	struct TArray<int64_t> TenancyUserExternalIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUserRank
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineUserRank {
	int64_t TenancyUserExternalId; // 0x00(0x08)
	int64_t RankId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListRanksResponse
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineListRanksResponse {
	int64_t RankWindowId; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineUserRank> UserRanks; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRoundStats
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineRoundStats {
	struct FString RoundId; // 0x00(0x10)
	struct TArray<struct FPioneerOnlinePlayerStat> Stats; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListRoundStatsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListRoundStatsResponse {
	struct TArray<struct FPioneerOnlineRoundStats> Rounds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSeasonalRewardState
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineSeasonalRewardState {
	int64_t RankSeasonId; // 0x00(0x08)
	enum class EPioneerOnlineSeasonalRewardInnerState State; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	int64_t RankId; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListSeasonalRewardsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListSeasonalRewardsResponse {
	struct TArray<struct FPioneerOnlineSeasonalRewardState> States; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListStoreViewsRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineListStoreViewsRequest {
	enum class EPioneerOnlineDistributionPlatform Platform; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStoreSectionProductEntry
// Size: 0x28 (Inherited: 0x00)
struct FPioneerOnlineStoreSectionProductEntry {
	int64_t EntryId; // 0x00(0x08)
	int64_t ProductId; // 0x08(0x08)
	enum class EPioneerOnlineStoreProvider StoreProvider; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t StartDate; // 0x18(0x08)
	int64_t EndDate; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStoreViewSection
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineStoreViewSection {
	int64_t SectionID; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineStoreSectionProductEntry> Entries; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStoreView
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineStoreView {
	int64_t ViewId; // 0x00(0x08)
	struct TArray<struct FPioneerOnlineStoreViewSection> Sections; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListStoreViewsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListStoreViewsResponse {
	struct TArray<struct FPioneerOnlineStoreView> Views; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListTimedOfferTransactionsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListTimedOfferTransactionsResponse {
	struct TArray<struct FPioneerOnlineTimedOfferTransaction> TimedOfferTransactions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListTransactionExpirationsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListTransactionExpirationsRequest {
	struct FString Country; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineTransactionExpiration
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineTransactionExpiration {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	int64_t ExpiresAt; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineListTransactionExpirationsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineListTransactionExpirationsResponse {
	struct TArray<struct FPioneerOnlineTransactionExpiration> Expirations; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMasteryObjectivesDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineMasteryObjectivesDescriptionResponse {
	struct TArray<struct FPioneerOnlineMasteryObjective> Objectives; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRecycleInventoryItemMutation
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineRecycleInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRepairInventoryItemMutation
// Size: 0x48 (Inherited: 0x00)
struct FPioneerOnlineRepairInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct TArray<struct FPioneerOnlineInventoryItem> ItemsToConsume; // 0x20(0x10)
	int64_t TimesToApply; // 0x30(0x08)
	struct FString Etag; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineScrapInventoryItemMutation
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineScrapInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpdateInventoryItemMutation
// Size: 0x48 (Inherited: 0x00)
struct FPioneerOnlineUpdateInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t Amount; // 0x20(0x08)
	struct TArray<struct FString> Slots; // 0x28(0x10)
	struct FString Etag; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutateInventoryMutation
// Size: 0x50 (Inherited: 0x00)
struct FPioneerOnlineMutateInventoryMutation {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutateInventoryRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineMutateInventoryRequest {
	struct TArray<struct FPioneerOnlineMutateInventoryMutation> Mutations; // 0x00(0x10)
	struct FString RequestID; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineMutateInventoryResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineMutateInventoryResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOfferDescriptionsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineOfferDescriptionsResponse {
	struct TArray<struct FPioneerOnlineOfferDescription> OfferDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOpenCrateRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineOpenCrateRequest {
	struct FString InstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineOpenCrateResponse
// Size: 0x68 (Inherited: 0x00)
struct FPioneerOnlineOpenCrateResponse {
	struct FPioneerOnlineCrate Crate; // 0x00(0x68)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineProducts
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineProducts {
	struct TArray<struct FPioneerOnlineProduct> Products; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePublishPartyInventoryChangedRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlinePublishPartyInventoryChangedRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseBattlePassRequest
// Size: 0x08 (Inherited: 0x00)
struct FPioneerOnlinePurchaseBattlePassRequest {
	int64_t BattlePassID; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseBattlePassResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlinePurchaseBattlePassResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct TArray<struct FPioneerOnlineBattlePassState> BattlePassStates; // 0xa0(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseCheck
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlinePurchaseCheck {
	struct TArray<struct FPioneerOnlineCostItem> CostItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseEmbarkProductRequest
// Size: 0x08 (Inherited: 0x00)
struct FPioneerOnlinePurchaseEmbarkProductRequest {
	int64_t ProductId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseEmbarkProductResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlinePurchaseEmbarkProductResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseEmbarkProductsRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlinePurchaseEmbarkProductsRequest {
	struct TArray<int64_t> ProductIds; // 0x00(0x10)
	struct FPioneerOnlinePurchaseCheck PurchaseCheck; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseEmbarkProductsResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlinePurchaseEmbarkProductsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlinePurchaseOrigin
// Size: 0x38 (Inherited: 0x00)
struct FPioneerOnlinePurchaseOrigin {
	int64_t ProductId; // 0x00(0x08)
	struct FString Country; // 0x08(0x10)
	struct FString CurrencyCode; // 0x18(0x10)
	struct FString LocalizedPrice; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineQuestRerollCost
// Size: 0x18 (Inherited: 0x00)
struct FPioneerOnlineQuestRerollCost {
	int64_t RerollsRemainingToday; // 0x00(0x08)
	int64_t CostGameAssetId; // 0x08(0x08)
	int64_t CostAmount; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRaiderProjectsDescriptionResponse
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineRaiderProjectsDescriptionResponse {
	struct TArray<struct FPioneerOnlineRaiderProjectDescription> Projects; // 0x00(0x10)
	struct TArray<struct FPioneerOnlineExpeditionWindow> ExpeditionWindows; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRanksDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineRanksDescriptionResponse {
	struct TArray<struct FPioneerOnlineRank> Ranks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineReconcileQuestsResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineReconcileQuestsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineReconcileStoresRequest
// Size: 0x50 (Inherited: 0x00)
struct FPioneerOnlineReconcileStoresRequest {
	enum class EPioneerOnlineDistributionPlatform Platform; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString PlatformData; // 0x08(0x10)
	struct FPioneerOnlinePurchaseOrigin PurchaseOrigin; // 0x18(0x38)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineReconcileStoresResponse
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerOnlineReconcileStoresResponse {
	struct TArray<int64_t> ProductIds; // 0x00(0x10)
	struct FPioneerOnlineChangeset Changeset; // 0x10(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineReconcileTransactionExpirationsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineReconcileTransactionExpirationsRequest {
	struct FString Country; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineReconcileTransactionExpirationsResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineReconcileTransactionExpirationsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRefundSkillsResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineRefundSkillsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRerollQuestRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineRerollQuestRequest {
	struct FString QuestInstanceId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRerollQuestResponse
// Size: 0xb8 (Inherited: 0x00)
struct FPioneerOnlineRerollQuestResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
	struct FPioneerOnlineQuestRerollCost NextCost; // 0xa0(0x18)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRestoreRoundLockedItemsRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineRestoreRoundLockedItemsRequest {
	struct FString RoundId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineRestoreRoundLockedItemsResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineRestoreRoundLockedItemsResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSeasonsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineSeasonsDescriptionResponse {
	struct TArray<struct FPioneerOnlineRankSeason> Seasons; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStartProjectRequest
// Size: 0x08 (Inherited: 0x00)
struct FPioneerOnlineStartProjectRequest {
	int64_t ProjectAssetId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStartProjectResponse
// Size: 0x30 (Inherited: 0x00)
struct FPioneerOnlineStartProjectResponse {
	struct FPioneerOnlineProject Project; // 0x00(0x30)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStoreGameDataRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineStoreGameDataRequest {
	enum class EPioneerOnlineDistributionPlatform Platform; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStoreViews
// Size: 0x10 (Inherited: 0x00)
struct FPioneerOnlineStoreViews {
	struct TArray<struct FPioneerOnlineStoreView> Views; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineStoreGameDataResponse
// Size: 0x20 (Inherited: 0x00)
struct FPioneerOnlineStoreGameDataResponse {
	struct FPioneerOnlineStoreViews StoreViews; // 0x00(0x10)
	struct FPioneerOnlineProducts Products; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSyncTenancyUserRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineSyncTenancyUserRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineSyncTenancyUserResponse
// Size: 0x01 (Inherited: 0x00)
struct FPioneerOnlineSyncTenancyUserResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpgradeInventoryItemRequest
// Size: 0x40 (Inherited: 0x00)
struct FPioneerOnlineUpgradeInventoryItemRequest {
	struct FString InstanceId; // 0x00(0x10)
	struct FString Etag; // 0x10(0x10)
	struct TArray<struct FPioneerOnlineConsumeInventoryItem> ItemsToConsume; // 0x20(0x10)
	struct FString RequestID; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpgradeInventoryItemResponse
// Size: 0x128 (Inherited: 0x00)
struct FPioneerOnlineUpgradeInventoryItemResponse {
	struct FPioneerOnlineInventoryItem UpgradedItem; // 0x00(0x68)
	struct FPioneerOnlineChangeset Changeset; // 0x68(0xa0)
	struct FPioneerOnlinePendingUpgrade PendingUpgrade; // 0x108(0x20)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpgradeSkillRequest
// Size: 0x08 (Inherited: 0x00)
struct FPioneerOnlineUpgradeSkillRequest {
	int64_t NodeId; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerOnlineUpgradeSkillResponse
// Size: 0xa0 (Inherited: 0x00)
struct FPioneerOnlineUpgradeSkillResponse {
	struct FPioneerOnlineChangeset Changeset; // 0x00(0xa0)
};

// ScriptStruct EmbarkApiGateway.PioneerServerArrangePartyRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerArrangePartyRequest {
	struct TArray<struct FTenancyUserId> UserIds; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerBonusSource
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerBonusSource {
	enum class EPioneerServerBonusSourceKind Kind; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t AssetId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerBonusEffect
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerBonusEffect {
	struct FString BonusId; // 0x00(0x10)
	enum class EPioneerServerBonusEffectKind Kind; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	double Amount; // 0x18(0x08)
	bool IsPending; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FPioneerServerBonusSource Source; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerBonusItem
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerBonusItem {
	struct FString BonusId; // 0x00(0x10)
	int64_t ItemAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	bool IsPending; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FPioneerServerBonusSource Source; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerQuestDescriptionObjectiveParameter
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerQuestDescriptionObjectiveParameter {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntryUnlockObjective
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerCodexEntryUnlockObjective {
	struct FString Type; // 0x00(0x10)
	struct TArray<struct FPioneerServerQuestDescriptionObjectiveParameter> Parameters; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntryUnlockQuest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCodexEntryUnlockQuest {
	int64_t QuestId; // 0x00(0x08)
	enum class EPioneerServerCodexQuestUnlockOn UnlockOn; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntryTextEntry
// Size: 0x48 (Inherited: 0x00)
struct FPioneerServerCodexEntryTextEntry {
	int64_t ID; // 0x00(0x08)
	struct FString Text; // 0x08(0x10)
	struct FPioneerServerCodexEntryUnlockObjective UnlockObjective; // 0x18(0x20)
	struct FPioneerServerCodexEntryUnlockQuest UnlockQuest; // 0x38(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntryBlock
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerCodexEntryBlock {
	int64_t ID; // 0x00(0x08)
	struct TArray<struct FPioneerServerCodexEntryTextEntry> TextEntries; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntry
// Size: 0x90 (Inherited: 0x00)
struct FPioneerServerCodexEntry {
	int64_t ID; // 0x00(0x08)
	struct FString HumanId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	struct TArray<int64_t> RelatedEntries; // 0x28(0x10)
	int64_t ImageAssetId; // 0x38(0x08)
	struct TArray<int64_t> MediaAssetIds; // 0x40(0x10)
	struct FString PreviewText; // 0x50(0x10)
	struct FString Quote; // 0x60(0x10)
	struct FString Title; // 0x70(0x10)
	struct TArray<struct FPioneerServerCodexEntryBlock> Blocks; // 0x80(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexSubcategory
// Size: 0x58 (Inherited: 0x00)
struct FPioneerServerCodexSubcategory {
	int64_t ID; // 0x00(0x08)
	struct FString HumanId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	struct FString PreviewText; // 0x28(0x10)
	struct FString Title; // 0x38(0x10)
	struct TArray<struct FPioneerServerCodexEntry> Entries; // 0x48(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexCategory
// Size: 0x68 (Inherited: 0x00)
struct FPioneerServerCodexCategory {
	int64_t ID; // 0x00(0x08)
	struct FString HumanId; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	int64_t SortIndex; // 0x28(0x08)
	int64_t ImageAssetId; // 0x30(0x08)
	struct FString PreviewText; // 0x38(0x10)
	struct FString Title; // 0x48(0x10)
	struct TArray<struct FPioneerServerCodexSubcategory> SubCategories; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexDescription
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCodexDescription {
	struct TArray<struct FPioneerServerCodexCategory> Categories; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCodexDescriptionResponse {
	struct FPioneerServerCodexDescription CodexDescription; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntryState
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCodexEntryState {
	int64_t EntryAssetId; // 0x00(0x08)
	bool Unlocked; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCodexEntryUpdate
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCodexEntryUpdate {
	int64_t EntryAssetId; // 0x00(0x08)
	bool Unlocked; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRewardedItem
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerRewardedItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
	struct TArray<struct FString> Slots; // 0x18(0x10)
	struct FString AliasInstanceId; // 0x28(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRewardPackage
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerRewardPackage {
	struct TArray<struct FPioneerServerRewardedItem> RewardedItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCommunityEventInGameRewardDescription
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerCommunityEventInGameRewardDescription {
	int64_t BaseItemId; // 0x00(0x08)
	double Multiplier; // 0x08(0x08)
	struct FPioneerServerRewardPackage RewardPackage; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCommunityEventStageDescription
// Size: 0xb0 (Inherited: 0x00)
struct FPioneerServerCommunityEventStageDescription {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct FString LongDescription; // 0x28(0x10)
	struct FString StatusDescription; // 0x38(0x10)
	struct FString AdditionalInfo; // 0x48(0x10)
	bool IsActive; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	int64_t Goal; // 0x60(0x08)
	struct TArray<int64_t> Offers; // 0x68(0x10)
	int64_t LevelGroup; // 0x78(0x08)
	struct TArray<struct FPioneerServerCommunityEventInGameRewardDescription> InGameRewards; // 0x80(0x10)
	int64_t Map; // 0x90(0x08)
	int64_t Image; // 0x98(0x08)
	int64_t Project; // 0xa0(0x08)
	int64_t MapCondition; // 0xa8(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCommunityEventDescription
// Size: 0x70 (Inherited: 0x00)
struct FPioneerServerCommunityEventDescription {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	struct FString EndTitle; // 0x28(0x10)
	struct FString EndDescription; // 0x38(0x10)
	int64_t EndImage; // 0x48(0x08)
	int64_t StartDate; // 0x50(0x08)
	int64_t EndDate; // 0x58(0x08)
	struct TArray<struct FPioneerServerCommunityEventStageDescription> Stages; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCommunityEventsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCommunityEventsDescriptionResponse {
	struct TArray<struct FPioneerServerCommunityEventDescription> Events; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCostItem
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerCostItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCostPackage
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerCostPackage {
	struct TArray<struct FPioneerServerCostItem> CostItems; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerCreateInventoryItemMutation
// Size: 0x60 (Inherited: 0x00)
struct FPioneerServerCreateInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	int64_t Amount; // 0x28(0x08)
	double Durability; // 0x30(0x08)
	double MaxDurability; // 0x38(0x08)
	struct TArray<struct FString> Slots; // 0x40(0x10)
	struct FString LockedInRound; // 0x50(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerDeleteInventoryItemMutation
// Size: 0x30 (Inherited: 0x00)
struct FPioneerServerDeleteInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Etag; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerEnemyGroup
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerEnemyGroup {
	struct FString Identifier; // 0x00(0x10)
	struct FString GroupList; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPlayerOnboardingIntroLevelData
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerPlayerOnboardingIntroLevelData {
	double RoundDurationSeconds; // 0x00(0x08)
	double AverageTtkSeconds; // 0x08(0x08)
	int64_t PlayerKills; // 0x10(0x08)
	int64_t PlayerDeaths; // 0x18(0x08)
	double AverageRaidersTtkSeconds; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerEvaluatePlayerOnboardingRequest
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerEvaluatePlayerOnboardingRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
	struct FPioneerServerPlayerOnboardingIntroLevelData IntroLevelData; // 0x10(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerServerEvaluatePlayerOnboardingResponse
// Size: 0x01 (Inherited: 0x00)
struct FPioneerServerEvaluatePlayerOnboardingResponse {
	bool GraduatedFtue; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGameSettingEntry
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerGameSettingEntry {
	struct FString Key; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGameSettingsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGameSettingsResponse {
	struct TArray<struct FPioneerServerGameSettingEntry> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGeneratedLoadoutItem
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerGeneratedLoadoutItem {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
	double Durability; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGeneratedLoadout
// Size: 0x30 (Inherited: 0x00)
struct FPioneerServerGeneratedLoadout {
	int64_t LoadoutId; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
	double Probability; // 0x18(0x08)
	struct TArray<struct FPioneerServerGeneratedLoadoutItem> Items; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGeneratedLoadoutResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGeneratedLoadoutResponse {
	struct TArray<struct FPioneerServerGeneratedLoadout> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetBonusesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetBonusesRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetBonusesResponse
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerGetBonusesResponse {
	struct TArray<struct FPioneerServerBonusItem> Items; // 0x00(0x10)
	struct TArray<struct FPioneerServerBonusEffect> Effects; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetEnemyGroupsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetEnemyGroupsResponse {
	struct TArray<struct FPioneerServerEnemyGroup> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetInventoriesRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerGetInventoriesRequest {
	struct TArray<struct FTenancyUserId> UserIds; // 0x00(0x10)
	struct FString RoundId; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerInventoryItem
// Size: 0x68 (Inherited: 0x00)
struct FPioneerServerInventoryItem {
	struct FString InstanceId; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct TArray<struct FString> Slots; // 0x20(0x10)
	double Durability; // 0x30(0x08)
	double MaxDurability; // 0x38(0x08)
	struct FString LockedInRound; // 0x40(0x10)
	struct FString Etag; // 0x50(0x10)
	int64_t UpdatedAt; // 0x60(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUserInventory
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerUserInventory {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct TArray<struct FPioneerServerInventoryItem> Items; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetInventoriesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetInventoriesResponse {
	struct TArray<struct FPioneerServerUserInventory> Inventories; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetPioneerScenariosRequest
// Size: 0x01 (Inherited: 0x00)
struct FPioneerServerGetPioneerScenariosRequest {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPioneerMatchmakingMapConditionSettings
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerPioneerMatchmakingMapConditionSettings {
	struct FString Condition; // 0x00(0x10)
	int64_t StartTime; // 0x10(0x08)
	int64_t DurationInSecond; // 0x18(0x08)
	int64_t ConditionAssetId; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPioneerMatchmakingMapConditions
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerPioneerMatchmakingMapConditions {
	bool IsOptIn; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FPioneerServerPioneerMatchmakingMapConditionSettings> ConditionSettings; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPioneerMatchmakingSettings
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerPioneerMatchmakingSettings {
	struct FPioneerServerPioneerMatchmakingMapConditions MapConditions; // 0x00(0x18)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPioneerScenario
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerPioneerScenario {
	struct FString Name; // 0x00(0x10)
	struct FPioneerServerPioneerMatchmakingSettings PioneerSettings; // 0x10(0x18)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetPioneerScenariosResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetPioneerScenariosResponse {
	struct TArray<struct FPioneerServerPioneerScenario> PioneerScenarios; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerQuestDescriptionEdge
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerQuestDescriptionEdge {
	enum class EPioneerServerQuestDescriptionState RequiredState; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t QuestGameAssetId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerQuestDescriptionObjective
// Size: 0x50 (Inherited: 0x00)
struct FPioneerServerQuestDescriptionObjective {
	struct FString Type; // 0x00(0x10)
	int64_t GameAssetId; // 0x10(0x08)
	int64_t Amount; // 0x18(0x08)
	struct TArray<struct FPioneerServerQuestDescriptionObjectiveParameter> Parameters; // 0x20(0x10)
	struct TArray<int64_t> ParentObjectiveIds; // 0x30(0x10)
	int64_t GroupId; // 0x40(0x08)
	bool Optional; // 0x48(0x01)
	bool Hidden; // 0x49(0x01)
	enum class EPioneerServerQuestDescriptionObjectiveMusic Music; // 0x4a(0x01)
	char pad_4b[0x5]; // 0x4b(0x05)
};

// ScriptStruct EmbarkApiGateway.PioneerServerQuestDescription
// Size: 0xb8 (Inherited: 0x00)
struct FPioneerServerQuestDescription {
	int64_t GameAssetId; // 0x00(0x08)
	enum class EPioneerServerQuestDescriptionCadence Cadence; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	int64_t OwnerGameAssetId; // 0x10(0x08)
	struct FString Title; // 0x18(0x10)
	struct FString Description; // 0x28(0x10)
	struct TArray<struct FString> Tags; // 0x38(0x10)
	int64_t ImageId; // 0x48(0x08)
	struct FString ToolTip; // 0x50(0x10)
	struct FPioneerServerRewardPackage AcceptRewardPackage; // 0x60(0x10)
	struct FPioneerServerRewardPackage CompleteRewardPackage; // 0x70(0x10)
	struct TArray<struct FPioneerServerQuestDescriptionEdge> QuestEdges; // 0x80(0x10)
	struct TArray<struct FPioneerServerQuestDescriptionObjective> QuestObjectives; // 0x90(0x10)
	struct TArray<int64_t> MapIds; // 0xa0(0x10)
	bool Hidden; // 0xb0(0x01)
	bool AutoAccept; // 0xb1(0x01)
	bool AutoComplete; // 0xb2(0x01)
	char pad_b3[0x5]; // 0xb3(0x05)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetQuestsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetQuestsDescriptionResponse {
	struct TArray<struct FPioneerServerQuestDescription> QuestDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetRankRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetRankRequest {
	struct FTenancyUserId TenancyUserExternalId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGetRankResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGetRankResponse {
	int64_t RankId; // 0x00(0x08)
	int64_t RankWindowId; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerGlobalPlayerStatScope
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerGlobalPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemConfigArraySlot
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerItemConfigArraySlot {
	struct FString Discriminator; // 0x00(0x10)
	int64_t SlotAssetId; // 0x10(0x08)
	int64_t NumberOfSlots; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemConfigNoSlot
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerItemConfigNoSlot {
	struct FString Discriminator; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemConfigSingleSlot
// Size: 0x30 (Inherited: 0x00)
struct FPioneerServerItemConfigSingleSlot {
	struct FString Discriminator; // 0x00(0x10)
	struct TArray<int64_t> AllowedSlotAssetIds; // 0x10(0x10)
	bool IsRequired; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	int64_t DefaultSlotAssetId; // 0x28(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemConfigStructuralSlot
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerItemConfigStructuralSlot {
	struct FString Discriminator; // 0x00(0x10)
	struct TArray<int64_t> SlotAssetIDs; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemConfig
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerItemConfig {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemEconomy
// Size: 0x08 (Inherited: 0x00)
struct FPioneerServerItemEconomy {
	int64_t Score; // 0x00(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemDescription
// Size: 0x90 (Inherited: 0x00)
struct FPioneerServerItemDescription {
	int64_t GameAssetId; // 0x00(0x08)
	struct FString ItemType; // 0x08(0x10)
	bool Stackable; // 0x18(0x01)
	bool Unique; // 0x19(0x01)
	char pad_1a[0x6]; // 0x1a(0x06)
	int64_t MaxAmount; // 0x20(0x08)
	int64_t MaxChildCount; // 0x28(0x08)
	struct FPioneerServerItemEconomy Economy; // 0x30(0x08)
	struct FPioneerServerItemConfig SlotConfig; // 0x38(0x38)
	struct FPioneerServerRewardPackage Scrap; // 0x70(0x10)
	struct FString Category; // 0x80(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerItemsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerItemsDescriptionResponse {
	struct TArray<struct FPioneerServerItemDescription> ItemDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerLevel
// Size: 0x30 (Inherited: 0x00)
struct FPioneerServerLevel {
	int64_t Level; // 0x00(0x08)
	int64_t GroupId; // 0x08(0x08)
	int64_t AbsoluteAmountRequired; // 0x10(0x08)
	int64_t RelativeAmountRequired; // 0x18(0x08)
	struct FPioneerServerRewardPackage Reward; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUnknownPlayerStatScope
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerUnknownPlayerStatScope {
	struct FString Discriminant; // 0x00(0x10)
	struct FString ScopeName; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPlayerStatScope
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerPlayerStatScope {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkApiGateway.PioneerServerPlayerStatId
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerPlayerStatId {
	struct FPioneerServerPlayerStatScope Scope; // 0x00(0x28)
	int64_t EventID; // 0x28(0x08)
	int64_t TargetId; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerLevelGroup
// Size: 0x70 (Inherited: 0x00)
struct FPioneerServerLevelGroup {
	int64_t GroupId; // 0x00(0x08)
	int64_t XpItemGameAssetId; // 0x08(0x08)
	int64_t TrackingItemId; // 0x10(0x08)
	struct FPioneerServerPlayerStatId TrackingPlayerStat; // 0x18(0x38)
	struct FString Name; // 0x50(0x10)
	struct TArray<struct FPioneerServerLevel> Levels; // 0x60(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUnclaimedLevelRewards
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerUnclaimedLevelRewards {
	int64_t Level; // 0x00(0x08)
	struct FPioneerServerRewardPackage Rewards; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerLevelState
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerLevelState {
	int64_t GroupId; // 0x00(0x08)
	int64_t CurrentLevel; // 0x08(0x08)
	int64_t CurrentXp; // 0x10(0x08)
	struct TArray<struct FPioneerServerUnclaimedLevelRewards> UnclaimedRewards; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListCodexEntriesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListCodexEntriesRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListCodexEntriesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListCodexEntriesResponse {
	struct TArray<struct FPioneerServerCodexEntryState> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListLevelGroupsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListLevelGroupsResponse {
	struct TArray<struct FPioneerServerLevelGroup> Groups; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerQuestObjective
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerQuestObjective {
	struct FString QuestInstanceId; // 0x00(0x10)
	int64_t QuestGameAssetId; // 0x10(0x08)
	int64_t GameAssetId; // 0x18(0x08)
	int64_t Amount; // 0x20(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUserQuestObjectives
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerUserQuestObjectives {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct TArray<struct FPioneerServerQuestObjective> QuestObjectives; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListQuestObjectivesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListQuestObjectivesResponse {
	struct TArray<struct FPioneerServerUserQuestObjectives> UserQuestObjectivesSet; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUserLevel
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerUserLevel {
	int64_t UserId; // 0x00(0x08)
	struct TArray<struct FPioneerServerLevelState> Levels; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListUserLevelsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListUserLevelsResponse {
	struct TArray<struct FPioneerServerUserLevel> UserLevels; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListUserMasteryObjectivesRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerListUserMasteryObjectivesRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
	struct TArray<int64_t> RankWindowIds; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMasteryObjectiveState
// Size: 0x38 (Inherited: 0x00)
struct FPioneerServerMasteryObjectiveState {
	int64_t RankWindowId; // 0x00(0x08)
	int64_t ObjectiveId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
	struct TArray<enum class EPioneerServerMasteryMilestoneRewardState> MilestoneRewardStates; // 0x18(0x10)
	enum class EPioneerServerMasteryObjectiveStreakState StreakState; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	int64_t StreakPoints; // 0x30(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListUserMasteryObjectivesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListUserMasteryObjectivesResponse {
	struct TArray<struct FPioneerServerMasteryObjectiveState> Objectives; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerXpEventParameter
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerXpEventParameter {
	struct FString Name; // 0x00(0x10)
	struct FString Value; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerXpEventReward
// Size: 0x48 (Inherited: 0x00)
struct FPioneerServerXpEventReward {
	int64_t EventID; // 0x00(0x08)
	int64_t EventCategoryID; // 0x08(0x08)
	struct FString EventName; // 0x10(0x10)
	struct FString EventType; // 0x20(0x10)
	struct TArray<struct FPioneerServerXpEventParameter> EventParameters; // 0x30(0x10)
	int64_t XpRewardAmount; // 0x40(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerListXpEventRewardsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerListXpEventRewardsResponse {
	struct TArray<struct FPioneerServerXpEventReward> UserXpEventRewardsSet; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMasteryObjectiveMilestone
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerMasteryObjectiveMilestone {
	int64_t Points; // 0x00(0x08)
	struct FPioneerServerRewardPackage Reward; // 0x08(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMasteryObjective
// Size: 0x98 (Inherited: 0x00)
struct FPioneerServerMasteryObjective {
	int64_t ID; // 0x00(0x08)
	int64_t RankWindowId; // 0x08(0x08)
	struct FString Title; // 0x10(0x10)
	struct FString Description; // 0x20(0x10)
	struct FString LongDescription; // 0x30(0x10)
	int64_t ImageId; // 0x40(0x08)
	struct FString Type; // 0x48(0x10)
	struct TArray<struct FPioneerServerQuestDescriptionObjectiveParameter> Parameters; // 0x58(0x10)
	struct TArray<int64_t> MapIds; // 0x68(0x10)
	int64_t MapCondition; // 0x78(0x08)
	double Multiplier; // 0x80(0x08)
	struct TArray<struct FPioneerServerMasteryObjectiveMilestone> Milestones; // 0x88(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMasteryObjectivesDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerMasteryObjectivesDescriptionResponse {
	struct TArray<struct FPioneerServerMasteryObjective> Objectives; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMasteryObjectiveUpdate
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerMasteryObjectiveUpdate {
	int64_t RankWindowId; // 0x00(0x08)
	int64_t ObjectiveId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
	int64_t StreakPoints; // 0x18(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMutatedInventoryItems
// Size: 0x30 (Inherited: 0x00)
struct FPioneerServerMutatedInventoryItems {
	struct TArray<struct FPioneerServerInventoryItem> Created; // 0x00(0x10)
	struct TArray<struct FPioneerServerInventoryItem> Updated; // 0x10(0x10)
	struct TArray<struct FString> Deleted; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateInventoryItemMutation
// Size: 0x68 (Inherited: 0x00)
struct FPioneerServerUpdateInventoryItemMutation {
	struct FString Discriminator; // 0x00(0x10)
	struct FString InstanceId; // 0x10(0x10)
	int64_t Amount; // 0x20(0x08)
	double Durability; // 0x28(0x08)
	double MaxDurability; // 0x30(0x08)
	struct TArray<struct FString> Slots; // 0x38(0x10)
	struct FString LockedInRound; // 0x48(0x10)
	struct FString Etag; // 0x58(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMutateInventoryMutation
// Size: 0x70 (Inherited: 0x00)
struct FPioneerServerMutateInventoryMutation {
	char pad_0[0x70]; // 0x00(0x70)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMutateInventoryRequest
// Size: 0x40 (Inherited: 0x00)
struct FPioneerServerMutateInventoryRequest {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct TArray<struct FPioneerServerMutateInventoryMutation> Mutations; // 0x10(0x10)
	struct FString RequestID; // 0x20(0x10)
	struct FString RoundId; // 0x30(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerMutateInventoryResponse
// Size: 0x40 (Inherited: 0x00)
struct FPioneerServerMutateInventoryResponse {
	struct FTenancyUserId UserId; // 0x00(0x10)
	struct FPioneerServerMutatedInventoryItems MutatedItems; // 0x10(0x30)
};

// ScriptStruct EmbarkApiGateway.PioneerServerOfferRequirement
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerOfferRequirement {
	int64_t ItemGameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerOfferDescription
// Size: 0x88 (Inherited: 0x00)
struct FPioneerServerOfferDescription {
	int64_t OfferId; // 0x00(0x08)
	struct FString OfferType; // 0x08(0x10)
	struct FString Title; // 0x18(0x10)
	int64_t OwnerGameAssetId; // 0x28(0x08)
	int64_t DurationInSeconds; // 0x30(0x08)
	bool IsVisible; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<struct FPioneerServerOfferRequirement> RequiredItems; // 0x40(0x10)
	struct FPioneerServerCostPackage CostPackage; // 0x50(0x10)
	struct FPioneerServerRewardPackage RewardPackage; // 0x60(0x10)
	int64_t OrderIndex; // 0x70(0x08)
	int64_t StartDate; // 0x78(0x08)
	int64_t EndDate; // 0x80(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerOfferDescriptionsResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerOfferDescriptionsResponse {
	struct TArray<struct FPioneerServerOfferDescription> OfferDescriptions; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRankThreshold
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerRankThreshold {
	double Percentile; // 0x00(0x08)
	int64_t Transition; // 0x08(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRank
// Size: 0x50 (Inherited: 0x00)
struct FPioneerServerRank {
	int64_t ID; // 0x00(0x08)
	struct FString Title; // 0x08(0x10)
	int64_t RankSeasonId; // 0x18(0x08)
	int64_t Size; // 0x20(0x08)
	bool TopN; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<struct FPioneerServerRankThreshold> Thresholds; // 0x30(0x10)
	struct FPioneerServerRewardPackage Reward; // 0x40(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRanksDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerRanksDescriptionResponse {
	struct TArray<struct FPioneerServerRank> Ranks; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRankWindow
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerRankWindow {
	int64_t ID; // 0x00(0x08)
	int64_t StartDate; // 0x08(0x08)
	int64_t EndDate; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerRankSeason
// Size: 0x28 (Inherited: 0x00)
struct FPioneerServerRankSeason {
	int64_t ID; // 0x00(0x08)
	int64_t StartDate; // 0x08(0x08)
	int64_t EndDate; // 0x10(0x08)
	struct TArray<struct FPioneerServerRankWindow> Windows; // 0x18(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerSeasonsDescriptionResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerSeasonsDescriptionResponse {
	struct TArray<struct FPioneerServerRankSeason> Seasons; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerStat
// Size: 0x18 (Inherited: 0x00)
struct FPioneerServerStat {
	int64_t EventID; // 0x00(0x08)
	int64_t TargetId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateCodexEntriesRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerUpdateCodexEntriesRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
	struct TArray<struct FPioneerServerCodexEntryUpdate> Updates; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateCodexEntriesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerUpdateCodexEntriesResponse {
	struct TArray<struct FPioneerServerCodexEntryState> Entries; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateMasteryObjectivesRequest
// Size: 0x20 (Inherited: 0x00)
struct FPioneerServerUpdateMasteryObjectivesRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
	struct TArray<struct FPioneerServerMasteryObjectiveUpdate> Updates; // 0x10(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateMasteryObjectivesResponse
// Size: 0x01 (Inherited: 0x00)
struct FPioneerServerUpdateMasteryObjectivesResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateQuestObjectivesRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerUpdateQuestObjectivesRequest {
	struct TArray<struct FPioneerServerUserQuestObjectives> UserQuestObjectivesCollection; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateQuestObjectivesResponse
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerUpdateQuestObjectivesResponse {
	struct TArray<struct FPioneerServerUserQuestObjectives> UserQuestObjectivesSet; // 0x00(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateStatsForEndOfRoundRequest
// Size: 0x30 (Inherited: 0x00)
struct FPioneerServerUpdateStatsForEndOfRoundRequest {
	struct FTenancyUserId ExternalUserId; // 0x00(0x10)
	struct FString RoundId; // 0x10(0x10)
	struct TArray<struct FPioneerServerStat> RoundStats; // 0x20(0x10)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUpdateStatsForEndOfRoundResponse
// Size: 0x01 (Inherited: 0x00)
struct FPioneerServerUpdateStatsForEndOfRoundResponse {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkApiGateway.PioneerServerUserRequest
// Size: 0x10 (Inherited: 0x00)
struct FPioneerServerUserRequest {
	struct TArray<struct FTenancyUserId> UserIds; // 0x00(0x10)
};

