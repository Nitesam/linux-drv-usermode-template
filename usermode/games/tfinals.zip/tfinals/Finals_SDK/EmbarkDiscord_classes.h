// Class EmbarkDiscord.EmbarkDiscordSubsystem
// Size: 0x1e0 (Inherited: 0xa0)
struct UEmbarkDiscordSubsystem : UEngineSubsystem {
	char pad_a0[0x140]; // 0xa0(0x140)
};

