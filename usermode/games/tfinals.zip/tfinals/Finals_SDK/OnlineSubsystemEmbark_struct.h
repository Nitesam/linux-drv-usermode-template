// Enum OnlineSubsystemEmbark.EUpdatePartyDataCompletionResult
enum class EUpdatePartyDataCompletionResult : uint8_t {
	Ok = 0,
	Unknown = 1,
	EUpdatePartyDataCompletionResult_MAX = 2
};

// Enum OnlineSubsystemEmbark.EUpdatePartyAttributesCompletionResult
enum class EUpdatePartyAttributesCompletionResult : uint8_t {
	Ok = 0,
	TooManyAttributes = 1,
	Unknown = 2,
	EUpdatePartyAttributesCompletionResult_MAX = 3
};

// Enum OnlineSubsystemEmbark.EPartyServiceErrors
enum class EPartyServiceErrors : uint8_t {
	PARTY_CREATE_FAILED = 0,
	CURRENT_PARTY_NOT_FOUND = 1,
	PARTY_INVITE_NOT_FOUND = 2,
	NOT_PARTY_LEADER = 3,
	NOT_PARTY_MEMBER = 4,
	CROSS_PLAY_INCOMPATIBLE = 5,
	INTERNAL_STORAGE_ERROR = 6,
	RECORD_NOT_FOUND = 7,
	PARTY_LEAVE_FAILED = 8,
	PARTY_NOTIFICATION_SEND_FAILED = 9,
	VOICE_PROVIDER_NOT_INITIALIZED = 10,
	VOICE_CHAT_TOKEN_REQUEST_FAILED = 11,
	VOICE_CHAT_USER_REMOVE_FAILED = 12,
	DELETE_PARTY_MEMBER_FAILED = 13,
	USER_ACTIVITY_FETCH_FAILED = 14,
	PLAYSTATION_TOKEN = 15,
	INVALID_PLATFORM_PROVIDER = 16,
	INTERNAL_ERROR = 17,
	PARTY_JOIN_FAILED = 18,
	PARTY_ALREADY_MEMBER = 19,
	EPartyServiceErrors_MAX = 20
};

// ScriptStruct OnlineSubsystemEmbark.EmbarkLinkingCode
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkLinkingCode {
	struct FString Code; // 0x00(0x10)
	struct FDateTime ExpiresAt; // 0x10(0x08)
};

// ScriptStruct OnlineSubsystemEmbark.EmbarkRegionInfo
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkRegionInfo {
	struct FString OnlineName; // 0x00(0x10)
	struct FText DisplayName; // 0x10(0x18)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct OnlineSubsystemEmbark.EmbarkUserRestriction
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkUserRestriction {
	bool bIsPermanentlyRestriced; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FDateTime RestrictionEndsAt; // 0x08(0x08)
};

