// Class MoviePlayer.MoviePlayerSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UMoviePlayerSettings : UObject {
	bool bWaitForMoviesToComplete; // 0x98(0x01)
	bool bMoviesAreSkippable; // 0x99(0x01)
	struct TArray<struct FString> StartupMovies; // 0xa0(0x10)
};

