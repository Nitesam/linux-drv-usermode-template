// Enum NiagaraShader.ENiagaraMipMapGenerationType
enum class ENiagaraMipMapGenerationType : uint8_t {
	Unfiltered = 0,
	Linear = 1,
	Blur1 = 2,
	Blur2 = 3,
	Blur3 = 4,
	Blur4 = 5,
	ENiagaraMipMapGenerationType_MAX = 6
};

// Enum NiagaraShader.ENiagaraGpuDispatchType
enum class ENiagaraGpuDispatchType : uint8_t {
	OneD = 0,
	TwoD = 1,
	ThreeD = 2,
	Custom = 3,
	ENiagaraGpuDispatchType_MAX = 4
};

// Enum NiagaraShader.ENiagaraDirectDispatchElementType
enum class ENiagaraDirectDispatchElementType : uint8_t {
	NumThreads = 0,
	NumThreadsNoClipping = 1,
	NumGroups = 2,
	ENiagaraDirectDispatchElementType_MAX = 3
};

// Enum NiagaraShader.ENiagaraSimStageExecuteBehavior
enum class ENiagaraSimStageExecuteBehavior : uint8_t {
	Always = 0,
	OnSimulationReset = 1,
	NotOnSimulationReset = 2,
	ENiagaraSimStageExecuteBehavior_MAX = 3
};

// Enum NiagaraShader.FNiagaraCompileEventSeverity
enum class FNiagaraCompileEventSeverity : uint8_t {
	Log = 0,
	Display = 1,
	Warning = 2,
	Error = 3,
	FNiagaraCompileEventSeverity_MAX = 4
};

// Enum NiagaraShader.FNiagaraCompileEventSource
enum class FNiagaraCompileEventSource : uint8_t {
	Unset = 0,
	ScriptDependency = 1,
	FNiagaraCompileEventSource_MAX = 2
};

// ScriptStruct NiagaraShader.SimulationStageMetaData
// Size: 0xa8 (Inherited: 0x00)
struct FSimulationStageMetaData {
	struct FName SimulationStageName; // 0x00(0x08)
	struct FName EnabledBinding; // 0x08(0x08)
	struct FIntVector ElementCount; // 0x10(0x0c)
	struct FName ElementCountXBinding; // 0x1c(0x08)
	struct FName ElementCountYBinding; // 0x24(0x08)
	struct FName ElementCountZBinding; // 0x2c(0x08)
	enum class ENiagaraIterationSource IterationSourceType; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FName IterationDataInterface; // 0x38(0x08)
	struct FName IterationDirectBinding; // 0x40(0x08)
	enum class ENiagaraSimStageExecuteBehavior ExecuteBehavior; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	char bWritesParticles : 1; // 0x4c(0x01)
	char bPartialParticleUpdate : 1; // 0x4c(0x01)
	char bParticleIterationStateEnabled : 1; // 0x4c(0x01)
	char bGpuIndirectDispatch : 1; // 0x4c(0x01)
	char pad_4c_4 : 4; // 0x4c(0x01)
	char pad_4d[0x3]; // 0x4d(0x03)
	struct FName ParticleIterationStateBinding; // 0x50(0x08)
	char pad_58[0x4]; // 0x58(0x04)
	struct FIntPoint ParticleIterationStateRange; // 0x5c(0x08)
	char pad_64[0x4]; // 0x64(0x04)
	struct TArray<struct FName> OutputDestinations; // 0x68(0x10)
	struct TArray<struct FName> InputDataInterfaces; // 0x78(0x10)
	int32_t NumIterations; // 0x88(0x04)
	struct FName NumIterationsBinding; // 0x8c(0x08)
	enum class ENiagaraGpuDispatchType GpuDispatchType; // 0x94(0x01)
	enum class ENiagaraDirectDispatchElementType GpuDirectDispatchElementType; // 0x95(0x01)
	char pad_96[0x2]; // 0x96(0x02)
	struct FIntVector GpuDispatchNumThreads; // 0x98(0x0c)
	char pad_a4[0x4]; // 0xa4(0x04)
};

// ScriptStruct NiagaraShader.NiagaraCompileEvent
// Size: 0x60 (Inherited: 0x00)
struct FNiagaraCompileEvent {
	enum class FNiagaraCompileEventSeverity Severity; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Message; // 0x08(0x10)
	struct FString ShortDescription; // 0x18(0x10)
	struct FGuid NodeGuid; // 0x28(0x10)
	struct FGuid PinGuid; // 0x38(0x10)
	struct TArray<struct FGuid> StackGuids; // 0x48(0x10)
	enum class FNiagaraCompileEventSource Source; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
};

// ScriptStruct NiagaraShader.NiagaraDataInterfaceGeneratedFunction
// Size: 0x50 (Inherited: 0x00)
struct FNiagaraDataInterfaceGeneratedFunction {
	char pad_0[0x30]; // 0x00(0x30)
	struct TArray<struct FNiagaraVariableCommonReference> VariadicInputs; // 0x30(0x10)
	struct TArray<struct FNiagaraVariableCommonReference> VariadicOutputs; // 0x40(0x10)
};

// ScriptStruct NiagaraShader.NiagaraDataInterfaceGPUParamInfo
// Size: 0x38 (Inherited: 0x00)
struct FNiagaraDataInterfaceGPUParamInfo {
	struct FString DataInterfaceHLSLSymbol; // 0x00(0x10)
	struct FString DIClassName; // 0x10(0x10)
	uint32_t ShaderParametersOffset; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<struct FNiagaraDataInterfaceGeneratedFunction> GeneratedFunctions; // 0x28(0x10)
};

// ScriptStruct NiagaraShader.NiagaraShaderScriptExternalConstant
// Size: 0x18 (Inherited: 0x00)
struct FNiagaraShaderScriptExternalConstant {
	struct FName Type; // 0x00(0x08)
	struct FString Name; // 0x08(0x10)
};

// ScriptStruct NiagaraShader.NiagaraShaderScriptParametersMetadata
// Size: 0x58 (Inherited: 0x00)
struct FNiagaraShaderScriptParametersMetadata {
	struct TArray<struct FNiagaraDataInterfaceGPUParamInfo> DataInterfaceParamInfo; // 0x00(0x10)
	struct TArray<struct FString> LooseMetadataNames; // 0x10(0x10)
	bool bExternalConstantsInterpolated; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct TArray<struct FNiagaraShaderScriptExternalConstant> ExternalConstants; // 0x28(0x10)
	char pad_38[0x20]; // 0x38(0x20)
};

