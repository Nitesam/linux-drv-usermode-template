// Class PropertyPath.PropertyPathTestObject
// Size: 0x1c0 (Inherited: 0xa0)
struct UPropertyPathTestObject : UObject {
	bool bool; // 0x98(0x01)
	enum class EPropertyPathTestEnum EnumOne; // 0x99(0x01)
	enum class EPropertyPathTestEnum EnumTwo; // 0x9a(0x01)
	enum class EPropertyPathTestEnum EnumThree; // 0x9b(0x01)
	enum class EPropertyPathTestEnum EnumFour; // 0x9c(0x01)
	int32_t Integer; // 0xa0(0x04)
	struct FString String; // 0xa8(0x10)
	float float; // 0xb8(0x04)
	char pad_bd[0x3]; // 0xbd(0x03)
	struct FPropertyPathTestStruct Struct; // 0xc0(0x50)
	struct FPropertyPathTestStruct StructRef; // 0x110(0x50)
	struct FPropertyPathTestStruct StructConstRef; // 0x160(0x50)
	struct UPropertyPathTestObject* InnerObject; // 0x1b0(0x08)
	char pad_1b8[0x8]; // 0x1b8(0x08)

	void SetStructRef(struct FPropertyPathTestStruct InStruct); // Function PropertyPath.PropertyPathTestObject.SetStructRef // (Final|Native|Public) // @ game+0x14a8860
	void SetStructConstRef(struct FPropertyPathTestStruct InStruct); // Function PropertyPath.PropertyPathTestObject.SetStructConstRef // (Final|Native|Public) // @ game+0x14a2cc0
	void SetStruct(struct FPropertyPathTestStruct InStruct); // Function PropertyPath.PropertyPathTestObject.SetStruct // (Final|Native|Public) // @ game+0x14a2740
	void SetFloat(float InFloat); // Function PropertyPath.PropertyPathTestObject.SetFloat // (Final|Native|Public) // @ game+0x14a4d20
	struct FPropertyPathTestStruct GetStructRef(); // Function PropertyPath.PropertyPathTestObject.GetStructRef // (Final|Native|Public|Const) // @ game+0x14a45c0
	struct FPropertyPathTestStruct GetStructConstRef(); // Function PropertyPath.PropertyPathTestObject.GetStructConstRef // (Final|Native|Public|Const) // @ game+0x14a6e20
	struct FPropertyPathTestStruct GetStruct(); // Function PropertyPath.PropertyPathTestObject.GetStruct // (Final|Native|Public|Const) // @ game+0x14a9080
	float GetFloat(); // Function PropertyPath.PropertyPathTestObject.GetFloat // (Final|Native|Public|Const) // @ game+0x14a4120
};

