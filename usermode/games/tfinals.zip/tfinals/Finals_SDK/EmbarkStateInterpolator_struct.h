// Enum EmbarkStateInterpolator.EStateInterpolatorDebugMode
enum class EStateInterpolatorDebugMode : uint8_t {
	None = 0,
	Simple = 1,
	Detailed = 2,
	Verbose = 3,
	NUM = 4,
	LAST = 3,
	EStateInterpolatorDebugMode_MAX = 5
};

// ScriptStruct EmbarkStateInterpolator.TransformInterpolatorData
// Size: 0x80 (Inherited: 0x00)
struct FTransformInterpolatorData {
	struct FVector Location; // 0x00(0x18)
	char pad_18[0x8]; // 0x18(0x08)
	struct FQuat Rotation; // 0x20(0x20)
	struct FVector LinearVelocity; // 0x40(0x18)
	struct FVector AngularVelocity; // 0x58(0x18)
	bool bDormantLinearVelocity; // 0x70(0x01)
	bool bDormantAngularVelocity; // 0x71(0x01)
	bool bTeleported; // 0x72(0x01)
	char pad_73[0xd]; // 0x73(0x0d)
};

// ScriptStruct EmbarkStateInterpolator.ObjectInterpolatorStateObjQueue
// Size: 0x10 (Inherited: 0x00)
struct FObjectInterpolatorStateObjQueue {
	struct TArray<struct UObject*> Queue; // 0x00(0x10)
};

// ScriptStruct EmbarkStateInterpolator.StateInstanceId
// Size: 0x10 (Inherited: 0x00)
struct FStateInstanceId {
	struct AActor* Actor; // 0x00(0x08)
	int32_t Key; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
};

// ScriptStruct EmbarkStateInterpolator.StateDependency
// Size: 0x10 (Inherited: 0x00)
struct FStateDependency {
	struct UStateInterpolator* StateInterpolatorClass; // 0x00(0x08)
	bool bCreateDefaultActorInstance; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkStateInterpolator.ActorStateInterpolatorSettings
// Size: 0x28 (Inherited: 0x00)
struct FActorStateInterpolatorSettings {
	float InterpolationBufferTarget; // 0x00(0x04)
	float InterpolationDelayCorrectionSpeed; // 0x04(0x04)
	float MaxInterpolationDelayCorrectionDelta; // 0x08(0x04)
	float DefaultStateUpdateFrequencyEstimation; // 0x0c(0x04)
	float MinStateUpdateFrequencyMultiplier; // 0x10(0x04)
	float DormancyDetectUpdateTimeMultiplier; // 0x14(0x04)
	float MaxExtrapolationTimeMultiplier; // 0x18(0x04)
	float MinInterpolationReplicationDelay; // 0x1c(0x04)
	bool bIgnoreGlobalMinInterpolationReplicationDelayOverride; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	float TeleportSpeedLimit; // 0x24(0x04)
};

// ScriptStruct EmbarkStateInterpolator.SubsystemOwnedStateInterpolator
// Size: 0x10 (Inherited: 0x00)
struct FSubsystemOwnedStateInterpolator {
	struct UStateInterpolator* Interpolator; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

