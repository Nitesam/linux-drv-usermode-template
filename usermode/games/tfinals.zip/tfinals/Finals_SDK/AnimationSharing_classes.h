// Class AnimationSharing.AnimationSharingStateProcessor
// Size: 0xc0 (Inherited: 0xa0)
struct UAnimationSharingStateProcessor : UObject {
	struct TSoftObjectPtr<UEnum> AnimationStateEnum; // 0x98(0x28)

	void ProcessActorState(int32_t& OutState, struct AActor* InActor, char CurrentState, char OnDemandState, bool& bShouldProcess); // Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x97a0a70
	struct UEnum* GetAnimationStateEnum(); // Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum // (Native|Event|Public|BlueprintEvent) // @ game+0x5374580
};

// Class AnimationSharing.AnimSharingStateInstance
// Size: 0x410 (Inherited: 0x3f0)
struct UAnimSharingStateInstance : UAnimInstance {
	struct UAnimSequence* AnimationToPlay; // 0x3f0(0x08)
	float PermutationTimeOffset; // 0x3f8(0x04)
	float PlayRate; // 0x3fc(0x04)
	bool bStateBool; // 0x400(0x01)
	char pad_401[0x7]; // 0x401(0x07)
	struct UAnimSharingInstance* Instance; // 0x408(0x08)

	void GetInstancedActors(struct TArray<struct AActor*>& Actors); // Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x97a6ed0
};

// Class AnimationSharing.AnimSharingTransitionInstance
// Size: 0x410 (Inherited: 0x3f0)
struct UAnimSharingTransitionInstance : UAnimInstance {
	struct TWeakObjectPtr<struct USkeletalMeshComponent> FromComponent; // 0x3f0(0x08)
	struct TWeakObjectPtr<struct USkeletalMeshComponent> ToComponent; // 0x3f8(0x08)
	float BlendTime; // 0x400(0x04)
	bool bBlendBool; // 0x404(0x01)
	char pad_405[0xb]; // 0x405(0x0b)
};

// Class AnimationSharing.AnimSharingAdditiveInstance
// Size: 0x410 (Inherited: 0x3f0)
struct UAnimSharingAdditiveInstance : UAnimInstance {
	struct TWeakObjectPtr<struct USkeletalMeshComponent> BaseComponent; // 0x3f0(0x08)
	struct TWeakObjectPtr<struct UAnimSequence> AdditiveAnimation; // 0x3f8(0x08)
	float Alpha; // 0x400(0x04)
	bool bStateBool; // 0x404(0x01)
	char pad_405[0xb]; // 0x405(0x0b)
};

// Class AnimationSharing.AnimSharingInstance
// Size: 0x190 (Inherited: 0xa0)
struct UAnimSharingInstance : UObject {
	struct TArray<struct AActor*> RegisteredActors; // 0x98(0x10)
	char pad_b0[0x48]; // 0xb0(0x48)
	struct UAnimationSharingStateProcessor* StateProcessor; // 0xf8(0x08)
	char pad_100[0x38]; // 0x100(0x38)
	struct TArray<struct UAnimSequence*> UsedAnimationSequences; // 0x138(0x10)
	char pad_148[0x10]; // 0x148(0x10)
	struct UEnum* StateEnum; // 0x158(0x08)
	struct AActor* SharingActor; // 0x160(0x08)
	char pad_168[0x28]; // 0x168(0x28)
};

// Class AnimationSharing.AnimationSharingManager
// Size: 0x110 (Inherited: 0xa0)
struct UAnimationSharingManager : UObject {
	struct TArray<struct USkeleton*> Skeletons; // 0x98(0x10)
	struct TArray<struct UAnimSharingInstance*> PerSkeletonData; // 0xa8(0x10)
	char pad_c0[0x50]; // 0xc0(0x50)

	void RegisterActorWithSkeletonBP(struct AActor* InActor, struct USkeleton* SharingSkeleton); // Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP // (Final|Native|Public|BlueprintCallable) // @ game+0x97a4200
	struct UAnimationSharingManager* GetAnimationSharingManager(struct UObject* WorldContextObject); // Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x97a6020
	bool CreateAnimationSharingManager(struct UObject* WorldContextObject, struct UAnimationSharingSetup* Setup); // Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x97a3a00
	bool AnimationSharingEnabled(); // Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x979eb80
};

// Class AnimationSharing.AnimationSharingSetup
// Size: 0xc0 (Inherited: 0xa0)
struct UAnimationSharingSetup : UObject {
	struct TArray<struct FPerSkeletonAnimationSharingSetup> SkeletonSetups; // 0x98(0x10)
	struct FAnimationSharingScalability ScalabilitySettings; // 0xa8(0x10)
};

