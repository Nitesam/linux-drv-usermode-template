// ScriptStruct EmbarkGameplayDebugger.EmbarkGameplayDebuggerCategoryContents
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkGameplayDebuggerCategoryContents {
	struct TArray<struct UEmbarkGameplayDebuggerPage*> Pages; // 0x00(0x10)
	struct TArray<struct UEmbarkGameplayDebuggerGlobalCategoryObject*> GlobalObjects; // 0x10(0x10)
};

// ScriptStruct EmbarkGameplayDebugger.EmbarkGameplayDebuggerCategoryConfig
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkGameplayDebuggerCategoryConfig {
	struct TArray<struct UEmbarkGameplayDebuggerPage*> DebuggerPageClasses; // 0x00(0x10)
	struct TArray<struct UEmbarkGameplayDebuggerGlobalCategoryObject*> GlobalDebuggerObjects; // 0x10(0x10)
	bool bEnabledByDefault; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

