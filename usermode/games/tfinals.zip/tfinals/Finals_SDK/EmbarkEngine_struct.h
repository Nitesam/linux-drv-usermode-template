// Enum EmbarkEngine.ECurveTRTrack
enum class ECurveTRTrack : uint8_t {
	TX = 0,
	TY = 1,
	TZ = 2,
	RX = 3,
	RY = 4,
	RZ = 5,
	ECurveTRTrack_MAX = 6
};

// Enum EmbarkEngine.EEmbarkTestASPerfType
enum class EEmbarkTestASPerfType : uint8_t {
	IterativeFib = 0,
	RecursiveFib = 1,
	Trigonometry = 2,
	SortFloatArray = 3,
	SortObjectArray = 4,
	EmptyCall = 5,
	EmptyForeignCall = 6,
	BlueprintNativeEvent = 7,
	DynamicMulticastDelegateWithParams = 8,
	MemcpyFloatArray = 9,
	MemcpyObjectArray = 10,
	EEmbarkTestASPerfType_MAX = 11
};

// Enum EmbarkEngine.EEmbarkVertexSpace
enum class EEmbarkVertexSpace : uint8_t {
	Local = 0,
	World = 1,
	EEmbarkVertexSpace_MAX = 2
};

// ScriptStruct EmbarkEngine.EmbarkRigidBodyContactInfo
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkRigidBodyContactInfo {
	struct FVector ContactPosition; // 0x00(0x18)
	struct FVector ContactNormal; // 0x18(0x18)
	float ContactPenetration; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct UPhysicalMaterial* PhysMaterial0; // 0x38(0x08)
	struct UPhysicalMaterial* PhysMaterial1; // 0x40(0x08)
};

// ScriptStruct EmbarkEngine.EmbarkCollisionImpactData
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkCollisionImpactData {
	struct TArray<struct FEmbarkRigidBodyContactInfo> ContactInfos; // 0x00(0x10)
	struct FVector TotalNormalImpulse; // 0x10(0x18)
	struct FVector TotalFrictionImpulse; // 0x28(0x18)
	bool bIsVelocityDeltaUnderThreshold; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct EmbarkEngine.EmbarkRigidBodyCollisionInfo
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkRigidBodyCollisionInfo {
	struct AActor* Actor; // 0x00(0x08)
	struct UPrimitiveComponent* Component; // 0x08(0x08)
	int32_t BodyIndex; // 0x10(0x04)
	struct FName BoneName; // 0x14(0x08)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkEngine.EmbarkCollisionNotifyInfo
// Size: 0x90 (Inherited: 0x00)
struct FEmbarkCollisionNotifyInfo {
	bool bCallEvent0; // 0x00(0x01)
	bool bCallEvent1; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FEmbarkRigidBodyCollisionInfo Info0; // 0x08(0x20)
	struct FEmbarkRigidBodyCollisionInfo Info1; // 0x28(0x20)
	struct FEmbarkCollisionImpactData RigidCollisionData; // 0x48(0x48)
};

// ScriptStruct EmbarkEngine.ScriptSubsystemCollectionBase
// Size: 0x08 (Inherited: 0x00)
struct FScriptSubsystemCollectionBase {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct EmbarkEngine.EmbarkWorldPartitionGridSelector
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkWorldPartitionGridSelector {
	bool Enabled; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName GridName; // 0x04(0x08)
	float MaximumSize; // 0x0c(0x04)
	struct TArray<struct AActor*> RequiredActorClasses; // 0x10(0x10)
	struct TArray<struct UActorComponent*> RequiredComponentClasses; // 0x20(0x10)
	struct TArray<struct UActorComponent*> DisallowedComponentClasses; // 0x30(0x10)
};

// ScriptStruct EmbarkEngine.EmbarkHttpParameter
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkHttpParameter {
	struct FString ParameterKey; // 0x00(0x10)
	struct FString ParameterValue; // 0x10(0x10)
};

// ScriptStruct EmbarkEngine.CookInfo
// Size: 0x01 (Inherited: 0x00)
struct FCookInfo {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkEngine.CookResult
// Size: 0x01 (Inherited: 0x00)
struct FCookResult {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkEngine.EmbarkLayerBlendInput
// Size: 0x90 (Inherited: 0x00)
struct FEmbarkLayerBlendInput {
	struct FName LayerName; // 0x00(0x08)
	struct FExpressionInput LayerInput; // 0x08(0x28)
	struct FExpressionInput HeightInput; // 0x30(0x28)
	struct FExpressionInput BlendSharpnessInput; // 0x58(0x28)
	float PreviewWeight; // 0x80(0x04)
	float ConstHeightInput; // 0x84(0x04)
	float ConstBlendSharpness; // 0x88(0x04)
	char pad_8c[0x4]; // 0x8c(0x04)
};

// ScriptStruct EmbarkEngine.PhysicalSkinnedMeshComponentEndPhysicsTickFunction
// Size: 0x40 (Inherited: 0x38)
struct FPhysicalSkinnedMeshComponentEndPhysicsTickFunction : FTickFunction {
	char pad_38[0x8]; // 0x38(0x08)
};

