// Class Slate.ToolMenuBase
// Size: 0xa0 (Inherited: 0xa0)
struct UToolMenuBase : UObject {
};

// Class Slate.SlateSettings
// Size: 0xa0 (Inherited: 0xa0)
struct USlateSettings : UObject {
	bool bExplicitCanvasChildZOrder; // 0x98(0x01)
};

// Class Slate.ButtonWidgetStyle
// Size: 0x490 (Inherited: 0xa0)
struct UButtonWidgetStyle : USlateWidgetStyleContainerBase {
	struct FButtonStyle ButtonStyle; // 0xa0(0x3f0)
};

// Class Slate.CheckBoxWidgetStyle
// Size: 0xb70 (Inherited: 0xa0)
struct UCheckBoxWidgetStyle : USlateWidgetStyleContainerBase {
	struct FCheckBoxStyle CheckBoxStyle; // 0xa0(0xad0)
};

// Class Slate.ComboBoxWidgetStyle
// Size: 0x700 (Inherited: 0xa0)
struct UComboBoxWidgetStyle : USlateWidgetStyleContainerBase {
	struct FComboBoxStyle ComboBoxStyle; // 0xa0(0x660)
};

// Class Slate.ComboButtonWidgetStyle
// Size: 0x6a0 (Inherited: 0xa0)
struct UComboButtonWidgetStyle : USlateWidgetStyleContainerBase {
	struct FComboButtonStyle ComboButtonStyle; // 0xa0(0x600)
};

// Class Slate.EditableTextBoxWidgetStyle
// Size: 0xf20 (Inherited: 0xa0)
struct UEditableTextBoxWidgetStyle : USlateWidgetStyleContainerBase {
	struct FEditableTextBoxStyle EditableTextBoxStyle; // 0xa0(0xe80)
};

// Class Slate.EditableTextWidgetStyle
// Size: 0x390 (Inherited: 0xa0)
struct UEditableTextWidgetStyle : USlateWidgetStyleContainerBase {
	struct FEditableTextStyle EditableTextStyle; // 0xa0(0x2f0)
};

// Class Slate.ProgressWidgetStyle
// Size: 0x330 (Inherited: 0xa0)
struct UProgressWidgetStyle : USlateWidgetStyleContainerBase {
	struct FProgressBarStyle ProgressBarStyle; // 0xa0(0x290)
};

// Class Slate.ScrollBarWidgetStyle
// Size: 0x810 (Inherited: 0xa0)
struct UScrollBarWidgetStyle : USlateWidgetStyleContainerBase {
	struct FScrollBarStyle ScrollBarStyle; // 0xa0(0x770)
};

// Class Slate.ScrollBoxWidgetStyle
// Size: 0x410 (Inherited: 0xa0)
struct UScrollBoxWidgetStyle : USlateWidgetStyleContainerBase {
	struct FScrollBoxStyle ScrollBoxStyle; // 0xa0(0x370)
};

// Class Slate.SpinBoxWidgetStyle
// Size: 0x6a0 (Inherited: 0xa0)
struct USpinBoxWidgetStyle : USlateWidgetStyleContainerBase {
	struct FSpinBoxStyle SpinBoxStyle; // 0xa0(0x600)
};

// Class Slate.TextBlockWidgetStyle
// Size: 0x3e0 (Inherited: 0xa0)
struct UTextBlockWidgetStyle : USlateWidgetStyleContainerBase {
	struct FTextBlockStyle TextBlockStyle; // 0xa0(0x340)
};

