// Class CableComponent.CableActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct ACableActor : AActor {
	struct UCableComponent* CableComponent; // 0x398(0x08)
};

// Class CableComponent.CableComponent
// Size: 0x7a0 (Inherited: 0x6f0)
struct UCableComponent : UMeshComponent {
	bool bAttachStart; // 0x6f0(0x01)
	bool bAttachEnd; // 0x6f1(0x01)
	char pad_6f2[0x6]; // 0x6f2(0x06)
	struct FComponentReference AttachEndTo; // 0x6f8(0x28)
	struct FName AttachEndToSocketName; // 0x720(0x08)
	struct FVector EndLocation; // 0x728(0x18)
	float CableLength; // 0x740(0x04)
	int32_t NumSegments; // 0x744(0x04)
	float SubstepTime; // 0x748(0x04)
	int32_t SolverIterations; // 0x74c(0x04)
	bool bEnableStiffness; // 0x750(0x01)
	bool bUseSubstepping; // 0x751(0x01)
	bool bSkipCableUpdateWhenNotVisible; // 0x752(0x01)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered; // 0x753(0x01)
	bool bEnableCollision; // 0x754(0x01)
	char pad_755[0x3]; // 0x755(0x03)
	float CollisionFriction; // 0x758(0x04)
	char pad_75c[0x4]; // 0x75c(0x04)
	struct FVector CableForce; // 0x760(0x18)
	float CableGravityScale; // 0x778(0x04)
	float CableWidth; // 0x77c(0x04)
	int32_t NumSides; // 0x780(0x04)
	float TileMaterial; // 0x784(0x04)
	char pad_788[0x18]; // 0x788(0x18)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x682af90
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo // (Final|Native|Public|BlueprintCallable) // @ game+0x682d0c0
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x682c9b0
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6826c70
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x682b100
};

