// Class EmbarkUtilities.TestRoot
// Size: 0xb0 (Inherited: 0xa0)
struct UTestRoot : UObject {
	bool Boolean0; // 0x98(0x01)
	struct UTestItemBase* Item; // 0xa0(0x08)
	char pad_a9[0x7]; // 0xa9(0x07)
};

// Class EmbarkUtilities.TestItemBase
// Size: 0xa0 (Inherited: 0xa0)
struct UTestItemBase : UObject {
};

// Class EmbarkUtilities.TestItemA
// Size: 0xa0 (Inherited: 0xa0)
struct UTestItemA : UTestItemBase {
	int32_t Integer0; // 0x98(0x04)
	int32_t Integer1; // 0x9c(0x04)
};

// Class EmbarkUtilities.TestItemB
// Size: 0xb0 (Inherited: 0xa0)
struct UTestItemB : UTestItemBase {
	float Float0; // 0x98(0x04)
	struct TArray<int32_t> IntegerArray0; // 0xa0(0x10)
};

// Class EmbarkUtilities.EmbarkJsonLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkJsonLibrary : UBlueprintFunctionLibrary {

	bool UClassToJsonSerialization(struct UObject* Object, struct FString& Result, struct FEncodeSettings& Settings); // Function EmbarkUtilities.EmbarkJsonLibrary.UClassToJsonSerialization // (Final|Native|Static|Public|HasOutParms) // @ game+0x44b1c90
	bool UClassToJsonObjectString(struct UObject* Object, struct FString& Result, int32_t CheckFlags, int32_t SkipFlags, int32_t Indent, bool bPrettyPrint, bool bEncodeSubclassWithTypeWrap, bool bNormalizeCase); // Function EmbarkUtilities.EmbarkJsonLibrary.UClassToJsonObjectString // (Final|Native|Static|Public|HasOutParms) // @ game+0x44a9150
	bool JsonObjectStringToUClass(struct FString& JsonString, struct UObject* OutObject, int32_t CheckFlags, int32_t SkipFlags); // Function EmbarkUtilities.EmbarkJsonLibrary.JsonObjectStringToUClass // (Final|Native|Static|Public|HasOutParms) // @ game+0x44ac820
};

