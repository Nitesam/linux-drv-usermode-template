// Class SignificanceManager.SignificanceManager
// Size: 0x1b0 (Inherited: 0xa0)
struct USignificanceManager : UObject {
	char pad_a0[0xf0]; // 0xa0(0xf0)
	struct FSoftClassPath SignificanceManagerClassName; // 0x190(0x20)
};

