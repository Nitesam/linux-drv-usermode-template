// Enum EmbarkPropertyBag.EPropertyBagItemType
enum class EPropertyBagItemType : uint8_t {
	Bool = 0,
	Int = 1,
	Float = 2,
	Vector = 3,
	Quat = 4,
	EPropertyBagItemType_MAX = 5
};

// ScriptStruct EmbarkPropertyBag.PropertyBagItem
// Size: 0x0c (Inherited: 0x00)
struct FPropertyBagItem {
	char pad_0[0xc]; // 0x00(0x0c)
};

