// Class EmbarkAmortizedReplication.EmbarkAmortizedReplicationBucket
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAmortizedReplicationBucket : UObject {
	bool bShouldBeInstanced; // 0x98(0x01)
};

// Class EmbarkAmortizedReplication.EmbarkAmortizedReplicationConnectionSortingBucket
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkAmortizedReplicationConnectionSortingBucket : UEmbarkAmortizedReplicationBucket {
	int32_t ActorConnectionReplicationsPerFrame; // 0xa0(0x04)
	enum class EConnectionSortingMethod SortingMethod; // 0xa4(0x01)
	char pad_a5[0xb]; // 0xa5(0x0b)
};

// Class EmbarkAmortizedReplication.EmbarkAmortizedReplicationDebugPrintBucket
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAmortizedReplicationDebugPrintBucket : UEmbarkAmortizedReplicationBucket {
};

// Class EmbarkAmortizedReplication.EmbarkAmortizedReplicationSubsystem
// Size: 0x27f0 (Inherited: 0xa0)
struct UEmbarkAmortizedReplicationSubsystem : UWorldSubsystem {
	char pad_a0[0x2750]; // 0xa0(0x2750)

	void QueueActorGroup(struct TArray<struct AActor*>& Actors, struct UEmbarkAmortizedReplicationBucket* BucketClass); // Function EmbarkAmortizedReplication.EmbarkAmortizedReplicationSubsystem.QueueActorGroup // (Final|Native|Public|HasOutParms) // @ game+0x5f6ea50
	void QueueActor(struct AActor* Actor, struct UEmbarkAmortizedReplicationBucket* BucketClass); // Function EmbarkAmortizedReplication.EmbarkAmortizedReplicationSubsystem.QueueActor // (Final|Native|Public) // @ game+0x5f72b60
};

