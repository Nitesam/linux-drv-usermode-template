// Enum EmbarkScatter.ESnapAlignmentMethod
enum class ESnapAlignmentMethod : uint8_t {
	None = 0,
	Origin = 1,
	Bounds = 2,
	ESnapAlignmentMethod_MAX = 3
};

// Enum EmbarkScatter.EScatterMethod
enum class EScatterMethod : uint8_t {
	Circle = 0,
	Square = 1,
	Volume = 2,
	OnActor = 3,
	NearActor = 4,
	OnAndNearActor = 5,
	EScatterMethod_MAX = 6
};

// Enum EmbarkScatter.EScatterOnSurfaceTypeMethod
enum class EScatterOnSurfaceTypeMethod : uint8_t {
	LimitedTo = 0,
	AllExcept = 1,
	EScatterOnSurfaceTypeMethod_MAX = 2
};

// Enum EmbarkScatter.EOcclusionMethod
enum class EOcclusionMethod : uint8_t {
	Simple = 0,
	Hemispherical = 1,
	EOcclusionMethod_MAX = 2
};

// Enum EmbarkScatter.ECurveSampleMethod
enum class ECurveSampleMethod : uint8_t {
	RelativeHeightDifference = 0,
	FixedHeightFromLowest = 1,
	SlopeAngle = 2,
	DistanceFromCenter = 3,
	ECurveSampleMethod_MAX = 4
};

// ScriptStruct EmbarkScatter.ScatterAffectingActorData
// Size: 0x70 (Inherited: 0x00)
struct FScatterAffectingActorData {
	struct FName ActorFullName; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform LastTransform; // 0x10(0x60)
};

// ScriptStruct EmbarkScatter.ScatterTransformSettings
// Size: 0x48 (Inherited: 0x00)
struct FScatterTransformSettings {
	float OffsetZMin; // 0x00(0x04)
	float OffsetZMax; // 0x04(0x04)
	struct FRotator RandomRotation; // 0x08(0x18)
	float RandomScaleMin; // 0x20(0x04)
	float RandomScaleMax; // 0x24(0x04)
	bool bPreventInterpenetration; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float InterpenetrationBoundingScale; // 0x2c(0x04)
	enum class ESnapAlignmentMethod SnapAlignmentMethod; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float BoundsRadiusScale; // 0x34(0x04)
	bool bRemoveFailedChecks; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float TraceDistance; // 0x3c(0x04)
	bool bComplexTrace; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct EmbarkScatter.ScatterMeshSettings
// Size: 0x38 (Inherited: 0x00)
struct FScatterMeshSettings {
	struct UStaticMesh* Mesh; // 0x00(0x08)
	struct UMaterialInterface* MaterialOverride; // 0x08(0x08)
	struct TArray<struct UMaterialInterface*> MaterialOverrides; // 0x10(0x10)
	float Weight; // 0x20(0x04)
	bool bAffectedByExclusionVolumes; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	int32_t StartCullDistance; // 0x28(0x04)
	int32_t EndCullDistance; // 0x2c(0x04)
	float LODDistanceScale; // 0x30(0x04)
	bool bEnableDensityScaling; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct EmbarkScatter.ObjectScatterCurveInput
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterCurveInput {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectScatterOverrideSettings
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterOverrideSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectScatterPlacementSettings
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterPlacementSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectScatterOcclusionSettings
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterOcclusionSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectScatterSlopeSettings
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterSlopeSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectSCatterCurvatureSettings
// Size: 0x01 (Inherited: 0x00)
struct FObjectSCatterCurvatureSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectScatterSettings
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterSettings {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkScatter.ObjectScatterLayer
// Size: 0x01 (Inherited: 0x00)
struct FObjectScatterLayer {
	char pad_0[0x1]; // 0x00(0x01)
};

