// Class GeometryCollectionEngine.GeometryCollectionExternalRenderInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UGeometryCollectionExternalRenderInterface : UInterface {
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolSubSystem
// Size: 0xb0 (Inherited: 0xa0)
struct UGeometryCollectionISMPoolSubSystem : UWorldSubsystem {
	struct AGeometryCollectionISMPoolActor* ISMPoolActor; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class GeometryCollectionEngine.ChaosDestructionListener
// Size: 0x670 (Inherited: 0x3c0)
struct UChaosDestructionListener : USceneComponent {
	char bIsCollisionEventListeningEnabled : 1; // 0x3c0(0x01)
	char bIsBreakingEventListeningEnabled : 1; // 0x3c0(0x01)
	char bIsTrailingEventListeningEnabled : 1; // 0x3c0(0x01)
	char bIsRemovalEventListeningEnabled : 1; // 0x3c0(0x01)
	char pad_3c0_4 : 4; // 0x3c0(0x01)
	char pad_3c1[0x3]; // 0x3c1(0x03)
	struct FChaosCollisionEventRequestSettings CollisionEventRequestSettings; // 0x3c4(0x18)
	struct FChaosBreakingEventRequestSettings BreakingEventRequestSettings; // 0x3dc(0x18)
	struct FChaosTrailingEventRequestSettings TrailingEventRequestSettings; // 0x3f4(0x18)
	struct FChaosRemovalEventRequestSettings RemovalEventRequestSettings; // 0x40c(0x10)
	char pad_41c[0x4]; // 0x41c(0x04)
	struct TSet<struct AChaosSolverActor*> ChaosSolverActors; // 0x420(0x50)
	struct TSet<struct AGeometryCollectionActor*> GeometryCollectionActors; // 0x470(0x50)
	struct FMulticastInlineDelegate OnCollisionEvents; // 0x4c0(0x10)
	struct FMulticastInlineDelegate OnBreakingEvents; // 0x4d0(0x10)
	struct FMulticastInlineDelegate OnTrailingEvents; // 0x4e0(0x10)
	struct FMulticastInlineDelegate OnRemovalEvents; // 0x4f0(0x10)
	char pad_500[0x170]; // 0x500(0x170)

	void SortTrailingEvents(struct TArray<struct FChaosTrailingEventData>& TrailingEvents, enum class EChaosTrailingSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x25a6980
	void SortRemovalEvents(struct TArray<struct FChaosRemovalEventData>& RemovalEvents, enum class EChaosRemovalSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortRemovalEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x25a54f0
	void SortCollisionEvents(struct TArray<struct FChaosCollisionEventData>& CollisionEvents, enum class EChaosCollisionSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2596780
	void SortBreakingEvents(struct TArray<struct FChaosBreakingEventData>& BreakingEvents, enum class EChaosBreakingSortMethod SortMethod); // Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2593e10
	void SetTrailingEventRequestSettings(struct FChaosTrailingEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2576090
	void SetTrailingEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2584b60
	void SetRemovalEventRequestSettings(struct FChaosRemovalEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x259a4c0
	void SetRemovalEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2590f00
	void SetCollisionEventRequestSettings(struct FChaosCollisionEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2593610
	void SetCollisionEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25ae960
	void SetBreakingEventRequestSettings(struct FChaosBreakingEventRequestSettings& InSettings); // Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2570070
	void SetBreakingEventEnabled(bool bIsEnabled); // Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2593f30
	void RemoveGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2594be0
	void RemoveChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x257bb60
	bool IsEventListening(); // Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x256c670
	void AddGeometryCollectionActor(struct AGeometryCollectionActor* GeometryCollectionActor); // Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x258d1a0
	void AddChaosSolverActor(struct AChaosSolverActor* ChaosSolverActor); // Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x257bb60
};

// Class GeometryCollectionEngine.GeometryCollectionActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct AGeometryCollectionActor : AActor {
	struct UGeometryCollectionComponent* GeometryCollectionComponent; // 0x398(0x08)
	struct UGeometryCollectionDebugDrawComponent* GeometryCollectionDebugDrawComponent; // 0x3a0(0x08)

	bool RaycastSingle(struct FVector Start, struct FVector End, struct FHitResult& OutHit); // Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x258bf80
};

// Class GeometryCollectionEngine.GeometryCollectionCache
// Size: 0xc0 (Inherited: 0xa0)
struct UGeometryCollectionCache : UObject {
	struct FRecordedTransformTrack RecordedData; // 0x98(0x10)
	struct UGeometryCollection* SupportedCollection; // 0xa8(0x08)
	struct FGuid CompatibleCollectionState; // 0xb0(0x10)
};

// Class GeometryCollectionEngine.GeometryCollectionComponent
// Size: 0xd20 (Inherited: 0x6f0)
struct UGeometryCollectionComponent : UMeshComponent {
	char pad_6f0[0x8]; // 0x6f0(0x08)
	struct AChaosSolverActor* ChaosSolverActor; // 0x6f8(0x08)
	char pad_700[0xe8]; // 0x700(0xe8)
	struct UGeometryCollection* RestCollection; // 0x7e8(0x08)
	struct TArray<struct AFieldSystemActor*> InitializationFields; // 0x7f0(0x10)
	bool Simulating; // 0x800(0x01)
	char pad_801[0x1]; // 0x801(0x01)
	enum class EObjectStateTypeEnum ObjectType; // 0x802(0x01)
	char pad_803[0x1]; // 0x803(0x01)
	int32_t GravityGroupIndex; // 0x804(0x04)
	bool bForceMotionBlur; // 0x808(0x01)
	bool EnableClustering; // 0x809(0x01)
	char pad_80a[0x2]; // 0x80a(0x02)
	int32_t ClusterGroupIndex; // 0x80c(0x04)
	int32_t MaxClusterLevel; // 0x810(0x04)
	int32_t MaxSimulatedLevel; // 0x814(0x04)
	enum class EDamageModelTypeEnum DamageModel; // 0x818(0x01)
	char pad_819[0x7]; // 0x819(0x07)
	struct TArray<float> DamageThreshold; // 0x820(0x10)
	bool bUseSizeSpecificDamageThreshold; // 0x830(0x01)
	char pad_831[0x3]; // 0x831(0x03)
	struct FGeometryCollectionDamagePropagationData DamagePropagationData; // 0x834(0x0c)
	bool bEnableDamageFromCollision; // 0x840(0x01)
	bool bAllowRemovalOnSleep; // 0x841(0x01)
	bool bAllowRemovalOnBreak; // 0x842(0x01)
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // 0x843(0x01)
	int32_t CollisionGroup; // 0x844(0x04)
	float CollisionSampleFraction; // 0x848(0x04)
	float LinearEtherDrag; // 0x84c(0x04)
	float AngularEtherDrag; // 0x850(0x04)
	char pad_854[0x4]; // 0x854(0x04)
	struct UChaosPhysicalMaterial* PhysicalMaterial; // 0x858(0x08)
	enum class EInitialVelocityTypeEnum InitialVelocityType; // 0x860(0x01)
	char pad_861[0x7]; // 0x861(0x07)
	struct FVector InitialLinearVelocity; // 0x868(0x18)
	struct FVector InitialAngularVelocity; // 0x880(0x18)
	struct UPhysicalMaterial* PhysicalMaterialOverride; // 0x898(0x08)
	struct FGeomComponentCacheParameters CacheParameters; // 0x8a0(0x50)
	struct TArray<struct FTransform> RestTransforms; // 0x8f0(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsStateChange; // 0x900(0x10)
	struct FMulticastInlineDelegate NotifyGeometryCollectionPhysicsLoadingStateChange; // 0x910(0x10)
	char pad_920[0x18]; // 0x920(0x18)
	struct FMulticastInlineDelegate OnChaosBreakEvent; // 0x938(0x10)
	struct FMulticastInlineDelegate OnChaosRemovalEvent; // 0x948(0x10)
	struct FMulticastInlineDelegate OnChaosCrumblingEvent; // 0x958(0x10)
	char pad_968[0x10]; // 0x968(0x10)
	float DesiredCacheTime; // 0x978(0x04)
	bool CachePlayback; // 0x97c(0x01)
	char pad_97d[0x3]; // 0x97d(0x03)
	struct FMulticastInlineDelegate OnChaosPhysicsCollision; // 0x980(0x10)
	bool bNotifyBreaks; // 0x990(0x01)
	bool bNotifyCollisions; // 0x991(0x01)
	bool bNotifyTrailing; // 0x992(0x01)
	bool bNotifyRemovals; // 0x993(0x01)
	bool bNotifyCrumblings; // 0x994(0x01)
	bool bCrumblingEventIncludesChildren; // 0x995(0x01)
	bool bNotifyGlobalBreaks; // 0x996(0x01)
	bool bNotifyGlobalCollisions; // 0x997(0x01)
	bool bNotifyGlobalRemovals; // 0x998(0x01)
	bool bNotifyGlobalCrumblings; // 0x999(0x01)
	bool bGlobalCrumblingEventIncludesChildren; // 0x99a(0x01)
	bool bStoreVelocities; // 0x99b(0x01)
	bool bShowBoneColors; // 0x99c(0x01)
	bool bUseRootProxyForNavigation; // 0x99d(0x01)
	bool bUpdateNavigationInTick; // 0x99e(0x01)
	char pad_99f[0x1]; // 0x99f(0x01)
	struct AGeometryCollectionISMPoolActor* ISMPool; // 0x9a0(0x08)
	bool bAutoAssignISMPool; // 0x9a8(0x01)
	bool bOverrideCustomRenderer; // 0x9a9(0x01)
	char pad_9aa[0x6]; // 0x9aa(0x06)
	ClassPtrProperty CustomRendererType; // 0x9b0(0x08)
	struct UGeometryCollectionExternalRenderInterface* CustomRenderer; // 0x9b8(0x08)
	bool bEnableReplication; // 0x9c0(0x01)
	bool bEnableAbandonAfterLevel; // 0x9c1(0x01)
	char pad_9c2[0x2]; // 0x9c2(0x02)
	struct FName AbandonedCollisionProfileName; // 0x9c4(0x08)
	char pad_9cc[0x4]; // 0x9cc(0x04)
	struct TArray<struct FName> CollisionProfilePerLevel; // 0x9d0(0x10)
	char pad_9e0[0x10]; // 0x9e0(0x10)
	int32_t ReplicationAbandonClusterLevel; // 0x9f0(0x04)
	int32_t ReplicationAbandonAfterLevel; // 0x9f4(0x04)
	int32_t ReplicationMaxPositionAndVelocityCorrectionLevel; // 0x9f8(0x04)
	char pad_9fc[0x4]; // 0x9fc(0x04)
	struct FGeometryCollectionRepData RepData; // 0xa00(0x38)
	char pad_a38[0x2a8]; // 0xa38(0x2a8)
	struct UBodySetup* DummyBodySetup; // 0xce0(0x08)
	struct UChaosGameplayEventDispatcher* EventDispatcher; // 0xce8(0x08)
	struct TArray<struct UInstancedStaticMeshComponent*> EmbeddedGeometryComponents; // 0xcf0(0x10)
	char pad_d00[0x20]; // 0xd00(0x20)

	void SetRestCollection(struct UGeometryCollection* RestCollectionIn, bool bApplyAssetDefaults); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetRestCollection // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2586700
	void SetPerParticleCollisionProfileName(struct TArray<int32_t>& BoneIds, struct FName ProfileName); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetPerParticleCollisionProfileName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x25971b0
	void SetPerLevelCollisionProfileNames(struct TArray<struct FName>& ProfileNames); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetPerLevelCollisionProfileNames // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2584410
	void SetNotifyRemovals(bool bNewNotifyRemovals); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyRemovals // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a64d0
	void SetNotifyGlobalRemovals(bool bNewNotifyGlobalRemovals); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalRemovals // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x259e2e0
	void SetNotifyGlobalCrumblings(bool bNewNotifyGlobalCrumblings, bool bGlobalNewCrumblingEventIncludesChildren); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalCrumblings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x259d5f0
	void SetNotifyGlobalCollision(bool bNewNotifyGlobalCollisions); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalCollision // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a3db0
	void SetNotifyGlobalBreaks(bool bNewNotifyGlobalBreaks); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyGlobalBreaks // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a2df0
	void SetNotifyCrumblings(bool bNewNotifyCrumblings, bool bNewCrumblingEventIncludesChildren); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyCrumblings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x257edc0
	void SetNotifyBreaks(bool bNewNotifyBreaks); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x258d900
	void SetLocalRestTransforms(struct TArray<struct FTransform>& Transforms, bool bOnlyLeaves); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetLocalRestTransforms // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2584970
	void SetEnableDamageFromCollision(bool bValue); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetEnableDamageFromCollision // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a52c0
	void SetDamageThreshold(struct TArray<float>& InDamageThreshold); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetDamageThreshold // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x258d560
	void SetAnchoredByTransformedBox(struct FBox Box, struct FTransform Transform, bool bAnchored, int32_t MaxLevel); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAnchoredByTransformedBox // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x256fa30
	void SetAnchoredByIndex(int32_t Index, bool bAnchored); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAnchoredByIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2576720
	void SetAnchoredByBox(struct FBox WorldSpaceBox, bool bAnchored, int32_t MaxLevel); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAnchoredByBox // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x256cea0
	void SetAbandonedParticleCollisionProfileName(struct FName CollisionProfile); // Function GeometryCollectionEngine.GeometryCollectionComponent.SetAbandonedParticleCollisionProfileName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a20d0
	void RemoveAllAnchors(); // Function GeometryCollectionEngine.GeometryCollectionComponent.RemoveAllAnchors // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x256c7b0
	void ReceivePhysicsCollision(struct FChaosPhysicsCollisionInfo& CollisionInfo); // Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnRep_RepData(); // Function GeometryCollectionEngine.GeometryCollectionComponent.OnRep_RepData // (Final|RequiredAPI|Native|Protected) // @ game+0x2575370
	void NotifyGeometryCollectionPhysicsStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature(struct UGeometryCollectionComponent* FracturedComponent); // DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	bool IsRootBroken(); // Function GeometryCollectionEngine.GeometryCollectionComponent.IsRootBroken // (Final|RequiredAPI|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x258e1d0
	struct FTransform GetRootInitialTransform(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetRootInitialTransform // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2595520
	int32_t GetRootIndex(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetRootIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25704a0
	struct FTransform GetRootCurrentTransform(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetRootCurrentTransform // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2595140
	void GetMassAndExtents(int32_t ItemIndex, float& OutMass, struct FBox& OutExtents); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetMassAndExtents // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x25979e0
	struct FBox GetLocalBounds(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetLocalBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x257d3b0
	struct TArray<struct FTransform> GetInitialLocalRestTransforms(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetInitialLocalRestTransforms // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2573170
	int32_t GetInitialLevel(int32_t ItemIndex); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetInitialLevel // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25761d0
	struct FString GetDebugInfo(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetDebugInfo // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a2350
	struct TArray<float> GetDamageThreshold(); // Function GeometryCollectionEngine.GeometryCollectionComponent.GetDamageThreshold // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2594050
	void CrumbleCluster(int32_t ItemIndex); // Function GeometryCollectionEngine.GeometryCollectionComponent.CrumbleCluster // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2589b60
	void CrumbleActiveClusters(); // Function GeometryCollectionEngine.GeometryCollectionComponent.CrumbleActiveClusters // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25779e0
	void ApplyPhysicsField(bool Enabled, enum class EGeometryCollectionPhysicsTypeEnum Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2589c50
	void ApplyLinearVelocity(int32_t ItemIndex, struct FVector& LinearVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyLinearVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x258a3b0
	void ApplyKinematicField(float Radius, struct FVector Position); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2570210
	void ApplyInternalStrain(int32_t ItemIndex, struct FVector& Location, float Radius, int32_t PropagationDepth, float PropagationFactor, float Strain); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyInternalStrain // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x25a1e20
	void ApplyExternalStrain(int32_t ItemIndex, struct FVector& Location, float Radius, int32_t PropagationDepth, float PropagationFactor, float Strain); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyExternalStrain // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2589e20
	void ApplyBreakingLinearVelocity(int32_t ItemIndex, struct FVector& LinearVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyBreakingLinearVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x258a6d0
	void ApplyBreakingAngularVelocity(int32_t ItemIndex, struct FVector& AngularVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyBreakingAngularVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x258a6d0
	void ApplyAssetDefaults(); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyAssetDefaults // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x258ab60
	void ApplyAngularVelocity(int32_t ItemIndex, struct FVector& AngularVelocity); // Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyAngularVelocity // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x25afd90
};

// Class GeometryCollectionEngine.GeometryCollectionDebugDrawActor
// Size: 0x460 (Inherited: 0x3a0)
struct AGeometryCollectionDebugDrawActor : AActor {
	struct FGeometryCollectionDebugDrawWarningMessage WarningMessage; // 0x398(0x01)
	struct FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // 0x3a0(0x18)
	bool bDebugDrawWholeCollection; // 0x3b8(0x01)
	bool bDebugDrawHierarchy; // 0x3b9(0x01)
	bool bDebugDrawClustering; // 0x3ba(0x01)
	enum class EGeometryCollectionDebugDrawActorHideGeometry HideGeometry; // 0x3bb(0x01)
	bool bShowRigidBodyId; // 0x3bc(0x01)
	bool bShowRigidBodyCollision; // 0x3bd(0x01)
	bool bCollisionAtOrigin; // 0x3be(0x01)
	bool bShowRigidBodyTransform; // 0x3bf(0x01)
	bool bShowRigidBodyInertia; // 0x3c0(0x01)
	bool bShowRigidBodyVelocity; // 0x3c1(0x01)
	bool bShowRigidBodyForce; // 0x3c2(0x01)
	bool bShowRigidBodyInfos; // 0x3c3(0x01)
	bool bShowTransformIndex; // 0x3c4(0x01)
	bool bShowTransform; // 0x3c5(0x01)
	bool bShowParent; // 0x3c6(0x01)
	bool bShowLevel; // 0x3c7(0x01)
	bool bShowConnectivityEdges; // 0x3c8(0x01)
	bool bShowGeometryIndex; // 0x3c9(0x01)
	bool bShowGeometryTransform; // 0x3ca(0x01)
	bool bShowBoundingBox; // 0x3cb(0x01)
	bool bShowFaces; // 0x3cc(0x01)
	bool bShowFaceIndices; // 0x3cd(0x01)
	bool bShowFaceNormals; // 0x3ce(0x01)
	bool bShowSingleFace; // 0x3cf(0x01)
	int32_t SingleFaceIndex; // 0x3d0(0x04)
	bool bShowVertices; // 0x3d4(0x01)
	bool bShowVertexIndices; // 0x3d5(0x01)
	bool bShowVertexNormals; // 0x3d6(0x01)
	bool bUseActiveVisualization; // 0x3d7(0x01)
	float PointThickness; // 0x3d8(0x04)
	float LineThickness; // 0x3dc(0x04)
	bool bTextShadow; // 0x3e0(0x01)
	char pad_3e2[0x2]; // 0x3e2(0x02)
	float TextScale; // 0x3e4(0x04)
	float NormalScale; // 0x3e8(0x04)
	float AxisScale; // 0x3ec(0x04)
	float ArrowScale; // 0x3f0(0x04)
	struct FColor RigidBodyIdColor; // 0x3f4(0x04)
	float RigidBodyTransformScale; // 0x3f8(0x04)
	struct FColor RigidBodyCollisionColor; // 0x3fc(0x04)
	struct FColor RigidBodyInertiaColor; // 0x400(0x04)
	struct FColor RigidBodyVelocityColor; // 0x404(0x04)
	struct FColor RigidBodyForceColor; // 0x408(0x04)
	struct FColor RigidBodyInfoColor; // 0x40c(0x04)
	struct FColor TransformIndexColor; // 0x410(0x04)
	float TransformScale; // 0x414(0x04)
	struct FColor LevelColor; // 0x418(0x04)
	struct FColor ParentColor; // 0x41c(0x04)
	float ConnectivityEdgeThickness; // 0x420(0x04)
	struct FColor GeometryIndexColor; // 0x424(0x04)
	float GeometryTransformScale; // 0x428(0x04)
	struct FColor BoundingBoxColor; // 0x42c(0x04)
	struct FColor FaceColor; // 0x430(0x04)
	struct FColor FaceIndexColor; // 0x434(0x04)
	struct FColor FaceNormalColor; // 0x438(0x04)
	struct FColor SingleFaceColor; // 0x43c(0x04)
	struct FColor VertexColor; // 0x440(0x04)
	struct FColor VertexIndexColor; // 0x444(0x04)
	struct FColor VertexNormalColor; // 0x448(0x04)
	char pad_44c[0x4]; // 0x44c(0x04)
	struct UBillboardComponent* SpriteComponent; // 0x450(0x08)
	char pad_458[0x8]; // 0x458(0x08)
};

// Class GeometryCollectionEngine.GeometryCollectionDebugDrawComponent
// Size: 0x170 (Inherited: 0x160)
struct UGeometryCollectionDebugDrawComponent : UActorComponent {
	struct AGeometryCollectionDebugDrawActor* GeometryCollectionDebugDrawActor; // 0x158(0x08)
	struct AGeometryCollectionRenderLevelSetActor* GeometryCollectionRenderLevelSetActor; // 0x160(0x08)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct AGeometryCollectionISMPoolActor : AActor {
	struct UGeometryCollectionISMPoolComponent* ISMPoolComp; // 0x398(0x08)
	struct UGeometryCollectionISMPoolDebugDrawComponent* ISMPoolDebugDrawComp; // 0x3a0(0x08)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolComponent
// Size: 0x490 (Inherited: 0x3c0)
struct UGeometryCollectionISMPoolComponent : USceneComponent {
	char pad_3c0[0xd0]; // 0x3c0(0xd0)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolRenderer
// Size: 0x140 (Inherited: 0xa0)
struct UGeometryCollectionISMPoolRenderer : UObject {
	struct AGeometryCollectionISMPoolActor* ISMPoolActor; // 0xa0(0x08)
	char pad_a8[0x98]; // 0xa8(0x98)
};

// Class GeometryCollectionEngine.GeometryCollection
// Size: 0x260 (Inherited: 0xa0)
struct UGeometryCollection : UObject {
	char pad_a0[0x8]; // 0xa0(0x08)
	bool EnableClustering; // 0xa8(0x01)
	char pad_a9[0x3]; // 0xa9(0x03)
	int32_t ClusterGroupIndex; // 0xac(0x04)
	int32_t MaxClusterLevel; // 0xb0(0x04)
	enum class EDamageModelTypeEnum DamageModel; // 0xb4(0x01)
	char pad_b5[0x3]; // 0xb5(0x03)
	struct TArray<float> DamageThreshold; // 0xb8(0x10)
	bool bUseSizeSpecificDamageThreshold; // 0xc8(0x01)
	bool PerClusterOnlyDamageThreshold; // 0xc9(0x01)
	char pad_ca[0x2]; // 0xca(0x02)
	struct FGeometryCollectionDamagePropagationData DamagePropagationData; // 0xcc(0x0c)
	enum class EClusterConnectionTypeEnum ClusterConnectionType; // 0xd8(0x01)
	char pad_d9[0x3]; // 0xd9(0x03)
	float ConnectionGraphBoundsFilteringMargin; // 0xdc(0x04)
	struct TArray<struct UMaterialInterface*> Materials; // 0xe0(0x10)
	struct TArray<struct FGeometryCollectionEmbeddedExemplar> EmbeddedGeometryExemplar; // 0xf0(0x10)
	bool bUseFullPrecisionUVs; // 0x100(0x01)
	bool bStripOnCook; // 0x101(0x01)
	bool bStripRenderDataOnCook; // 0x102(0x01)
	char pad_103[0x5]; // 0x103(0x05)
	ClassPtrProperty CustomRendererType; // 0x108(0x08)
	struct FGeometryCollectionProxyMeshData RootProxyData; // 0x110(0x10)
	struct TArray<struct FGeometryCollectionAutoInstanceMesh> AutoInstanceMeshes; // 0x120(0x10)
	bool EnableNanite; // 0x130(0x01)
	bool bConvertVertexColorsToSRGB; // 0x131(0x01)
	char pad_132[0x6]; // 0x132(0x06)
	struct UPhysicalMaterial* PhysicsMaterial; // 0x138(0x08)
	bool bDensityFromPhysicsMaterial; // 0x140(0x01)
	bool bMassAsDensity; // 0x141(0x01)
	char pad_142[0x2]; // 0x142(0x02)
	float Mass; // 0x144(0x04)
	float MinimumMassClamp; // 0x148(0x04)
	bool bImportCollisionFromSource; // 0x14c(0x01)
	bool bScaleOnRemoval; // 0x14d(0x01)
	bool bRemoveOnMaxSleep; // 0x14e(0x01)
	char pad_14f[0x1]; // 0x14f(0x01)
	struct FVector2D MaximumSleepTime; // 0x150(0x10)
	struct FVector2D RemovalDuration; // 0x160(0x10)
	bool bSlowMovingAsSleeping; // 0x170(0x01)
	char pad_171[0x3]; // 0x171(0x03)
	float SlowMovingVelocityThreshold; // 0x174(0x04)
	struct TArray<struct FGeometryCollectionSizeSpecificData> SizeSpecificData; // 0x178(0x10)
	bool EnableRemovePiecesOnFracture; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	struct TArray<struct UMaterialInterface*> RemoveOnFractureMaterials; // 0x190(0x10)
	struct UDataflow* DataflowAsset; // 0x1a0(0x08)
	struct FString DataflowTerminal; // 0x1a8(0x10)
	struct TMap<struct FString, struct FString> Overrides; // 0x1b8(0x50)
	struct FGuid PersistentGuid; // 0x208(0x10)
	struct FGuid StateGuid; // 0x218(0x10)
	int32_t RootIndex; // 0x228(0x04)
	int32_t BoneSelectedMaterialIndex; // 0x22c(0x04)
	struct UMaterialInterface* BoneSelectedMaterial; // 0x230(0x08)
	char pad_238[0x10]; // 0x238(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x248(0x10)
	char pad_258[0x8]; // 0x258(0x08)

	void SetEnableNanite(bool bValue); // Function GeometryCollectionEngine.GeometryCollection.SetEnableNanite // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a1190
	void SetConvertVertexColorsToSRGB(bool bValue); // Function GeometryCollectionEngine.GeometryCollection.SetConvertVertexColorsToSRGB // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25a6790
};

// Class GeometryCollectionEngine.GeometryCollectionRenderLevelSetActor
// Size: 0x490 (Inherited: 0x3a0)
struct AGeometryCollectionRenderLevelSetActor : AActor {
	struct UVolumeTexture* TargetVolumeTexture; // 0x398(0x08)
	struct UMaterial* RayMarchMaterial; // 0x3a0(0x08)
	float SurfaceTolerance; // 0x3a8(0x04)
	float Isovalue; // 0x3ac(0x04)
	bool Enabled; // 0x3b0(0x01)
	bool RenderVolumeBoundingBox; // 0x3b1(0x01)
	char pad_3ba[0xd6]; // 0x3ba(0xd6)
};

// Class GeometryCollectionEngine.GeometryCollectionISMPoolDebugDrawComponent
// Size: 0x720 (Inherited: 0x710)
struct UGeometryCollectionISMPoolDebugDrawComponent : UDebugDrawComponent {
	bool bShowGlobalStats; // 0x708(0x01)
	bool bShowStats; // 0x709(0x01)
	bool bShowBounds; // 0x70a(0x01)
	struct UInstancedStaticMeshComponent* SelectedComponent; // 0x710(0x08)
	char pad_71b[0x5]; // 0x71b(0x05)
};

