// Class EmbarkApiGateway.EmbarkApiFunctions
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkApiFunctions : UObject {

	int64_t FromUserHandleToInt64(struct FTenancyUserId& InHandle); // Function EmbarkApiGateway.EmbarkApiFunctions.FromUserHandleToInt64 // (Final|Native|Static|Public|HasOutParms) // @ game+0x4538d40
	struct FTenancyUserId FromIntToUserHandle(int64_t& inInt); // Function EmbarkApiGateway.EmbarkApiFunctions.FromIntToUserHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x4536110
};

