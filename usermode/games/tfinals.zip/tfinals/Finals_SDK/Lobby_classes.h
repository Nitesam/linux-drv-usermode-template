// Class Lobby.LobbyBeaconClient
// Size: 0x4b0 (Inherited: 0x430)
struct ALobbyBeaconClient : AOnlineBeaconClient {
	struct ALobbyBeaconState* LobbyState; // 0x428(0x08)
	struct ALobbyBeaconPlayerState* PlayerState; // 0x430(0x08)
	enum class ELobbyBeaconJoinState LobbyJoinServerState; // 0x439(0x01)
	char pad_441[0x6f]; // 0x441(0x6f)

	void ServerSetPartyOwner(struct FUniqueNetIdRepl InUniqueId, struct FUniqueNetIdRepl InPartyOwnerId); // Function Lobby.LobbyBeaconClient.ServerSetPartyOwner // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x8cfa3f0
	void ServerNotifyJoiningServer(); // Function Lobby.LobbyBeaconClient.ServerNotifyJoiningServer // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x8cfc510
	void ServerLoginPlayer(struct FString InSessionId, struct FUniqueNetIdRepl InUniqueId, struct FString UrlString); // Function Lobby.LobbyBeaconClient.ServerLoginPlayer // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x8d04cd0
	void ServerKickPlayer(struct FUniqueNetIdRepl PlayerToKick, struct FText Reason); // Function Lobby.LobbyBeaconClient.ServerKickPlayer // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x8d07b00
	void ServerDisconnectFromLobby(); // Function Lobby.LobbyBeaconClient.ServerDisconnectFromLobby // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x8d0afb0
	void ServerCheat(struct FString Msg); // Function Lobby.LobbyBeaconClient.ServerCheat // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x8d04530
	void ClientWasKicked(struct FText KickReason); // Function Lobby.LobbyBeaconClient.ClientWasKicked // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x8d02900
	void ClientSetInviteFlags(struct FJoinabilitySettings Settings); // Function Lobby.LobbyBeaconClient.ClientSetInviteFlags // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x8cfe2f0
	void ClientPlayerLeft(struct FUniqueNetIdRepl InUniqueId); // Function Lobby.LobbyBeaconClient.ClientPlayerLeft // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x8cfc410
	void ClientPlayerJoined(struct FText NewPlayerName, struct FUniqueNetIdRepl InUniqueId); // Function Lobby.LobbyBeaconClient.ClientPlayerJoined // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x8d043c0
	void ClientLoginComplete(struct FUniqueNetIdRepl InUniqueId, bool bWasSuccessful); // Function Lobby.LobbyBeaconClient.ClientLoginComplete // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x8cfbd10
	void ClientJoinGame(); // Function Lobby.LobbyBeaconClient.ClientJoinGame // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x3290d80
	void ClientAckJoiningServer(); // Function Lobby.LobbyBeaconClient.ClientAckJoiningServer // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x2fb6f90
};

// Class Lobby.LobbyBeaconHost
// Size: 0x400 (Inherited: 0x3c0)
struct ALobbyBeaconHost : AOnlineBeaconHostObject {
	char pad_3c0[0x8]; // 0x3c0(0x08)
	struct TSoftClassPtr<UObject> LobbyStateClass; // 0x3c8(0x28)
	struct ALobbyBeaconState* LobbyState; // 0x3f0(0x08)
	char pad_3f8[0x8]; // 0x3f8(0x08)
};

// Class Lobby.LobbyBeaconPlayerState
// Size: 0x470 (Inherited: 0x3a0)
struct ALobbyBeaconPlayerState : AInfo {
	struct FText DisplayName; // 0x398(0x18)
	struct FUniqueNetIdRepl UniqueID; // 0x3b0(0x30)
	struct FUniqueNetIdRepl PartyOwnerUniqueId; // 0x3e0(0x30)
	bool bInLobby; // 0x410(0x01)
	struct AOnlineBeaconClient* ClientActor; // 0x418(0x08)
	char pad_421[0x4f]; // 0x421(0x4f)

	void OnRep_UniqueId(); // Function Lobby.LobbyBeaconPlayerState.OnRep_UniqueId // (Final|Native|Protected) // @ game+0x8d08e50
	void OnRep_PartyOwner(); // Function Lobby.LobbyBeaconPlayerState.OnRep_PartyOwner // (Final|Native|Protected) // @ game+0x8d07030
	void OnRep_InLobby(); // Function Lobby.LobbyBeaconPlayerState.OnRep_InLobby // (Final|Native|Protected) // @ game+0x8d08250
};

// Class Lobby.LobbyBeaconState
// Size: 0x550 (Inherited: 0x3a0)
struct ALobbyBeaconState : AInfo {
	int32_t MaxPlayers; // 0x398(0x04)
	struct ALobbyBeaconPlayerState* LobbyBeaconPlayerStateClass; // 0x3a0(0x08)
	char pad_3ac[0x4]; // 0x3ac(0x04)
	bool bLobbyStarted; // 0x3b0(0x01)
	char pad_3b1[0x3]; // 0x3b1(0x03)
	float WaitForPlayersTimeRemaining; // 0x3b4(0x04)
	struct FLobbyPlayerStateInfoArray Players; // 0x3b8(0x128)
	char pad_4e0[0x70]; // 0x4e0(0x70)

	void OnRep_WaitForPlayersTimeRemaining(); // Function Lobby.LobbyBeaconState.OnRep_WaitForPlayersTimeRemaining // (Final|Native|Protected) // @ game+0x8d02f60
	void OnRep_LobbyStarted(); // Function Lobby.LobbyBeaconState.OnRep_LobbyStarted // (Final|Native|Protected) // @ game+0x8cfd910
};

