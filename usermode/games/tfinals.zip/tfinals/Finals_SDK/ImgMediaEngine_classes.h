// Class ImgMediaEngine.ImgMediaPlaybackComponent
// Size: 0x180 (Inherited: 0x160)
struct UImgMediaPlaybackComponent : UActorComponent {
	float LODBias; // 0x158(0x04)
	char pad_164[0x1c]; // 0x164(0x1c)
};

