// ScriptStruct EmbarkServerEvents.FieldTypeRankInfo2
// Size: 0x28 (Inherited: 0x00)
struct FFieldTypeRankInfo2 {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t TotalXP; // 0x08(0x08)
	int64_t CurrentRank; // 0x10(0x08)
	struct FString BucketId; // 0x18(0x10)
};

// ScriptStruct EmbarkServerEvents.FieldTypePlayerItem
// Size: 0x20 (Inherited: 0x00)
struct FFieldTypePlayerItem {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString ItemId; // 0x08(0x10)
	int64_t GameAssetId; // 0x18(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeRankBucketDelta2
// Size: 0x30 (Inherited: 0x00)
struct FFieldTypeRankBucketDelta2 {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString BucketId; // 0x08(0x10)
	int64_t Delta; // 0x18(0x08)
	int64_t Total; // 0x20(0x08)
	int64_t ActivityId; // 0x28(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypePosition
// Size: 0x28 (Inherited: 0x00)
struct FFieldTypePosition {
	char pad_0[0x8]; // 0x00(0x08)
	float X; // 0x08(0x04)
	float Y; // 0x0c(0x04)
	float Z; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	int64_t TimeMs; // 0x18(0x08)
	int64_t Frame; // 0x20(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeKillsByItemId
// Size: 0x18 (Inherited: 0x00)
struct FFieldTypeKillsByItemId {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t ItemAssetId; // 0x08(0x08)
	int64_t Kills; // 0x10(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeDamageByItemId
// Size: 0x18 (Inherited: 0x00)
struct FFieldTypeDamageByItemId {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t ItemAssetId; // 0x08(0x08)
	float Damage; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkServerEvents.FieldTypeAssetIdAmount
// Size: 0x18 (Inherited: 0x00)
struct FFieldTypeAssetIdAmount {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	int64_t Amount; // 0x10(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeIntPair
// Size: 0x18 (Inherited: 0x00)
struct FFieldTypeIntPair {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t Key; // 0x08(0x08)
	int64_t Value; // 0x10(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeAssetInstanceAmount
// Size: 0x28 (Inherited: 0x00)
struct FFieldTypeAssetInstanceAmount {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	struct FString InstanceId; // 0x10(0x10)
	int64_t Amount; // 0x20(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeNetworkConnectionData
// Size: 0x70 (Inherited: 0x00)
struct FFieldTypeNetworkConnectionData {
	char pad_0[0x8]; // 0x00(0x08)
	float ConnectionTimeout; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	double LastReceiveTime; // 0x10(0x08)
	double LastGoodPackageTime; // 0x18(0x08)
	double LastSendTime; // 0x20(0x08)
	double LastTickTime; // 0x28(0x08)
	double LastReceiveAckTime; // 0x30(0x08)
	int64_t SendBufferBits; // 0x38(0x08)
	int64_t OutTotalBytes; // 0x40(0x08)
	int64_t InTotalBytes; // 0x48(0x08)
	int64_t OutTotalPackets; // 0x50(0x08)
	int32_t InTotalPackages; // 0x58(0x04)
	int32_t QueuedBits; // 0x5c(0x04)
	int32_t LastProcessedFrame; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	int64_t ServerTime; // 0x68(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeNetConnectionData
// Size: 0x70 (Inherited: 0x00)
struct FFieldTypeNetConnectionData {
	char pad_0[0x8]; // 0x00(0x08)
	float ConnectionTimeout; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	double LastReceiveTime; // 0x10(0x08)
	double LastGoodPackageTime; // 0x18(0x08)
	double LastSendTime; // 0x20(0x08)
	double LastTickTime; // 0x28(0x08)
	double LastReceiveAckTime; // 0x30(0x08)
	int64_t SendBufferBits; // 0x38(0x08)
	int64_t OutTotalBytes; // 0x40(0x08)
	int64_t InTotalBytes; // 0x48(0x08)
	int64_t OutTotalPackets; // 0x50(0x08)
	int32_t InTotalPackages; // 0x58(0x04)
	int32_t QueuedBits; // 0x5c(0x04)
	int32_t LastProcessedFrame; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	double ServerTimeS; // 0x68(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeScorecardScoreLevelByAssetId
// Size: 0x18 (Inherited: 0x00)
struct FFieldTypeScorecardScoreLevelByAssetId {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t ScorecardScoreAssetId; // 0x08(0x08)
	int64_t ScorecardScoreLevel; // 0x10(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeAssetInstanceAmounts
// Size: 0x30 (Inherited: 0x00)
struct FFieldTypeAssetInstanceAmounts {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	struct FString InstanceId; // 0x10(0x10)
	int64_t AmountBefore; // 0x20(0x08)
	int64_t AmountAfter; // 0x28(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeStringPair
// Size: 0x28 (Inherited: 0x00)
struct FFieldTypeStringPair {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString Key; // 0x08(0x10)
	struct FString Value; // 0x18(0x10)
};

// ScriptStruct EmbarkServerEvents.FieldTypeRoundItemChange
// Size: 0x40 (Inherited: 0x00)
struct FFieldTypeRoundItemChange {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	struct FString InstanceId; // 0x10(0x10)
	struct FString Source; // 0x20(0x10)
	int64_t Gained; // 0x30(0x08)
	int64_t Lost; // 0x38(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeProximityPosition
// Size: 0x38 (Inherited: 0x00)
struct FFieldTypeProximityPosition {
	char pad_0[0x8]; // 0x00(0x08)
	float E1X; // 0x08(0x04)
	float E1Y; // 0x0c(0x04)
	float E1Z; // 0x10(0x04)
	float E2X; // 0x14(0x04)
	float E2Y; // 0x18(0x04)
	float E2Z; // 0x1c(0x04)
	float Distance; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	int64_t TimeMs; // 0x28(0x08)
	int64_t Frame; // 0x30(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeAssetInstanceAmountDurability
// Size: 0x30 (Inherited: 0x00)
struct FFieldTypeAssetInstanceAmountDurability {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t GameAssetId; // 0x08(0x08)
	struct FString InstanceId; // 0x10(0x10)
	int64_t Amount; // 0x20(0x08)
	float Durability; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
};

// ScriptStruct EmbarkServerEvents.FieldTypeStringToInt
// Size: 0x20 (Inherited: 0x00)
struct FFieldTypeStringToInt {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString Key; // 0x08(0x10)
	int64_t Value; // 0x18(0x08)
};

// ScriptStruct EmbarkServerEvents.FieldTypeIntToFloat
// Size: 0x18 (Inherited: 0x00)
struct FFieldTypeIntToFloat {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t Key; // 0x08(0x08)
	float Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkServerEvents.FieldTypeWeaponDamageData
// Size: 0x38 (Inherited: 0x00)
struct FFieldTypeWeaponDamageData {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t PlayerId; // 0x08(0x08)
	struct FString InstanceId; // 0x10(0x10)
	int64_t GameAssetId; // 0x20(0x08)
	int64_t TotalHits; // 0x28(0x08)
	float TotalDamage; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct EmbarkServerEvents.FieldTypeScorecardScore
// Size: 0x20 (Inherited: 0x00)
struct FFieldTypeScorecardScore {
	char pad_0[0x8]; // 0x00(0x08)
	int64_t ScorecardAssetId; // 0x08(0x08)
	int64_t ScorecardLevel; // 0x10(0x08)
	float ScorecardScore; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

