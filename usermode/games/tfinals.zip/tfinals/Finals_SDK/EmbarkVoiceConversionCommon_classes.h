// Class EmbarkVoiceConversionCommon.VoiceConversionSpeakerData
// Size: 0xc0 (Inherited: 0xa0)
struct UVoiceConversionSpeakerData : UDataAsset {
	struct FVoiceConversionSpeakerAudioData AudioData; // 0xa0(0x20)
};

// Class EmbarkVoiceConversionCommon.VoiceConversionSpeakerAsset
// Size: 0x110 (Inherited: 0xa0)
struct UVoiceConversionSpeakerAsset : UDataAsset {
	struct FName SpeakerId; // 0xa0(0x08)
	struct FText DisplayName; // 0xa8(0x18)
	struct TSoftObjectPtr<UVoiceConversionSpeakerData> SpeakerData; // 0xc0(0x28)
	struct TSoftObjectPtr<USoundBase> PreviewSound; // 0xe8(0x28)
};

// Class EmbarkVoiceConversionCommon.VoiceConversionModelAsset
// Size: 0xd0 (Inherited: 0xa0)
struct UVoiceConversionModelAsset : UDataAsset {
	struct TSoftObjectPtr<UObject> Data; // 0xa0(0x28)
	int32_t InputSampleRate; // 0xc8(0x04)
	int32_t OutputSampleRate; // 0xcc(0x04)
};

// Class EmbarkVoiceConversionCommon.VoiceConversionDataAsset
// Size: 0xc0 (Inherited: 0xa0)
struct UVoiceConversionDataAsset : UPrimaryDataAsset {
	struct UVoiceConversionModelAsset* Model; // 0xa0(0x08)
	struct TArray<struct UVoiceConversionSpeakerAsset*> Speakers; // 0xa8(0x10)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class EmbarkVoiceConversionCommon.VoiceConversionSettings
// Size: 0xd0 (Inherited: 0xb0)
struct UVoiceConversionSettings : UDeveloperSettings {
	struct FString Path; // 0xa8(0x10)
	struct FString DataAssetPath; // 0xb8(0x10)
};

// Class EmbarkVoiceConversionCommon.VoiceConversionSpeakerAssetFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UVoiceConversionSpeakerAssetFactory : UBlueprintFunctionLibrary {
};

// Class EmbarkVoiceConversionCommon.VoiceConversionSpeakerDynamicEnum
// Size: 0xd0 (Inherited: 0xb0)
struct UVoiceConversionSpeakerDynamicEnum : UIEmbarkDynamicEnum {
	struct FText DisplayName; // 0xa8(0x18)
	struct UVoiceConversionDataAsset* VoiceConversionDataAsset; // 0xc0(0x08)
};

