// Enum EmbarkSoundCueNodes.EEmbarkModulatorParameterOperation
enum class EEmbarkModulatorParameterOperation : uint8_t {
	Multiply = 0,
	Add = 1,
	Min = 2,
	Max = 3
};

// Enum EmbarkSoundCueNodes.EEmbarkModulatorParameterMode
enum class EEmbarkModulatorParameterMode : uint8_t {
	Name = 0,
	GameplayTag = 1,
	Distance = 2,
	Velocity = 3,
	Azimuth = 4,
	IsOccluded = 5,
	RotationTowardsListener = 6,
	EEmbarkModulatorParameterMode_MAX = 7
};

// ScriptStruct EmbarkSoundCueNodes.EmbarkModulatorParams
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkModulatorParams {
	enum class EEmbarkModulatorParameterOperation Operation; // 0x00(0x01)
	enum class EEmbarkModulatorParameterMode Mode; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	struct FName ParameterName; // 0x04(0x08)
	struct FGameplayTag ParameterTag; // 0x0c(0x08)
	float Default; // 0x14(0x04)
	struct FVector2D InputRange; // 0x18(0x10)
	struct FVector2D OutputRange; // 0x28(0x10)
	enum class EMapRangeCurve Curve; // 0x38(0x01)
	bool bInvertCurve; // 0x39(0x01)
	char pad_3a[0x6]; // 0x3a(0x06)
};

