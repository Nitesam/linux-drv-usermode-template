// ScriptStruct EmbarkReplay.EmbarkInstantReplayWorldPackages
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkInstantReplayWorldPackages {
	struct TArray<struct UPackage*> Packages; // 0x00(0x10)
};

