// Class EmbarkFracturedDestructible.EmbarkClusterEdgeMeshSystem
// Size: 0x1b0 (Inherited: 0xb0)
struct UEmbarkClusterEdgeMeshSystem : UTickableWorldSubsystem {
	struct UEmbarkDestructionClusterSubsystem* DestructionClusterSubsystem; // 0xb0(0x08)
	struct TMap<struct FEmbarkClusterMeshComponentKey, struct UEmbarkClusterMeshComponent*> EdgeMeshComponents; // 0xb8(0x50)
	char pad_108[0xa8]; // 0x108(0xa8)
};

// Class EmbarkFracturedDestructible.EmbarkCracksSystem
// Size: 0x210 (Inherited: 0xb0)
struct UEmbarkCracksSystem : UTickableWorldSubsystem {
	char pad_b0[0x18]; // 0xb0(0x18)
	struct UEmbarkDestructionClusterSubsystem* DestructionClusterSubsystem; // 0xc8(0x08)
	struct TMap<struct UStaticMesh*, struct UEmbarkClusterMeshComponent*> EdgeMeshComponents; // 0xd0(0x50)
	char pad_120[0xf0]; // 0x120(0xf0)
};

// Class EmbarkFracturedDestructible.EmbarkDestructiblePhysXSyncSubsystem
// Size: 0x110 (Inherited: 0xa0)
struct UEmbarkDestructiblePhysXSyncSubsystem : UWorldSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct TSet<struct AEmbarkDestructionGraphActor*> ActiveGraphActors; // 0xb0(0x50)
	struct UEmbarkDestructionClusterSubsystem* DestructionClusterSubsystem; // 0x100(0x08)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionBudgetSubsystem
// Size: 0x140 (Inherited: 0xb0)
struct UEmbarkDestructionBudgetSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x88]; // 0xb0(0x88)
	struct UEmbarkDestructionBudgetSettingsAsset* DestructionBudgetSettings; // 0x138(0x08)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionClusterSubsystem
// Size: 0x350 (Inherited: 0xa0)
struct UEmbarkDestructionClusterSubsystem : UWorldSubsystem {
	char pad_a0[0x110]; // 0xa0(0x110)
	struct UEmbarkClusterEdgeMeshSystem* EdgeMeshClusterSystem; // 0x1b0(0x08)
	struct UEmbarkCracksSystem* CracksMeshClusterSystem; // 0x1b8(0x08)
	struct UEmbarkDestructionBudgetSubsystem* DestructionBudgetSubsystem; // 0x1c0(0x08)
	struct UEmbarkDestructionConstraintSubsystem* ConstraintSubsystem; // 0x1c8(0x08)
	char pad_1d0[0x18]; // 0x1d0(0x18)
	struct FEmbarkDestructionClusterSystemTickFunction TickFunction; // 0x1e8(0x40)
	char pad_228[0x128]; // 0x228(0x128)

	void SetNavmeshDirtyingEnabled(bool bEnabled); // Function EmbarkFracturedDestructible.EmbarkDestructionClusterSubsystem.SetNavmeshDirtyingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5bc83c0
};

// Class EmbarkFracturedDestructible.EmbarkDestructionListenerVolumeComponent
// Size: 0x170 (Inherited: 0x160)
struct UEmbarkDestructionListenerVolumeComponent : UActorComponent {
	struct FMulticastInlineDelegate OnDestructionEvent; // 0x158(0x10)
	int32_t InterestedEventType; // 0x168(0x04)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionCollectorSubsystem
// Size: 0x210 (Inherited: 0xb0)
struct UEmbarkDestructionCollectorSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct FEmbarkFXParticleParams GridEffect; // 0xb8(0x18)
	char pad_d0[0x128]; // 0xd0(0x128)
	struct UEmbarkFireClientSubsystem* ClientFireSubsystem; // 0x1f8(0x08)
	char pad_200[0x10]; // 0x200(0x10)

	void RegisterListener(struct UEmbarkDestructionListenerVolumeComponent* Listener); // Function EmbarkFracturedDestructible.EmbarkDestructionCollectorSubsystem.RegisterListener // (Final|Native|Public|BlueprintCallable) // @ game+0x5bc8790
	void AddDestructionEvent(struct FVector Location, struct FBoxSphereBounds BoxSphereBounds, enum class EDestructionEventType EventType, struct UPrimitiveComponent* Component, int32_t BoneIndex, struct FVector InitialLocation); // Function EmbarkFracturedDestructible.EmbarkDestructionCollectorSubsystem.AddDestructionEvent // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5bc9280
};

// Class EmbarkFracturedDestructible.EmbarkDestructionCollisionHandlerSubsystem
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkDestructionCollisionHandlerSubsystem : UWorldSubsystem {
	char pad_a0[0x50]; // 0xa0(0x50)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionConstraintSubsystem
// Size: 0x2d210 (Inherited: 0xa0)
struct UEmbarkDestructionConstraintSubsystem : UWorldSubsystem {
	char pad_a0[0x2d170]; // 0xa0(0x2d170)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionContactModificationSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDestructionContactModificationSubsystem : UEngineSubsystem {
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGraphActor
// Size: 0xac0 (Inherited: 0x3a0)
struct AEmbarkDestructionGraphActor : AActor {
	struct UStateInterpolatorComponent* StateInterpolatorComponent; // 0x398(0x08)
	struct UTransformInterpolator* TransformInterpolator; // 0x3a0(0x08)
	struct UEmbarkDestructionBudgetSubsystem* DestructionBudgetSubsystem; // 0x3b0(0x08)
	struct UEmbarkDestructionClusterSubsystem* DestructionClusterSubsystem; // 0x3b8(0x08)
	char pad_3c0[0x1a0]; // 0x3c0(0x1a0)
	struct FFracturedDestructionReplicationSettings ReplicationSettings; // 0x560(0x50)
	struct TMap<struct FDestructibleBoneHandle, struct FFracturedDestructibleRuntimeData> DestructiblesRuntimeData; // 0x5b0(0x50)
	struct TMap<struct FSimpleDestructibleHandle, struct FSimpleDestructibleRuntimeData> SimpleDestructiblesRuntimeData; // 0x600(0x50)
	struct TSet<struct AActor*> ExecutedDestructionListenerEventActors; // 0x650(0x50)
	struct FEmbarkDestructionGraphData DestructionGraphData_Cooked; // 0x6a0(0x248)
	char pad_8e8[0x8]; // 0x8e8(0x08)
	struct FBlackBoardDeltaCompressionPtr BlackBoardReplicationPtr; // 0x8f0(0x78)
	struct FBlackBoardDeltaCompressionPtr ConnectivityReplicationPtr; // 0x968(0x78)
	char pad_9e0[0x4]; // 0x9e0(0x04)
	int32_t DestructionGraphHash; // 0x9e4(0x04)
	char pad_9e8[0xd8]; // 0x9e8(0xd8)

	bool TryGetBoneLevelData(struct UEmbarkFracturedDestructibleMeshComponent* InFracturedDestructibleMeshComponent, int32_t InBoneIndex, struct FFracturedDestructibleBoneLevelData& OutBoneLevelData); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.TryGetBoneLevelData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcfcc0
	bool TryGetBoneHandle(struct UEmbarkFracturedDestructibleMeshComponent* InFracturedDestructibleMeshComponent, int32_t InBoneIndex, struct FDestructibleBoneHandle& OutBoneHandle); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.TryGetBoneHandle // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcb020
	void SetBoneFlags(struct FDestructibleBoneHandle InBoneHandle, char Flags); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.SetBoneFlags // (Final|Native|Public|BlueprintCallable) // @ game+0x5bcbd30
	void ResetDestruction_Server(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.ResetDestruction_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5bcb640
	void OnRep_DestructionGraphHash(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.OnRep_DestructionGraphHash // (Final|Native|Private) // @ game+0x5bcb1b0
	void OnRep_ConnectivityReplicationPtr(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.OnRep_ConnectivityReplicationPtr // (Final|Native|Private) // @ game+0x5bcc280
	void OnRep_BlackBoardReplicationPtr(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.OnRep_BlackBoardReplicationPtr // (Final|Native|Private) // @ game+0x5bcd430
	bool IsValidBoneLink(struct FDestructibleBoneHandle InBoneHandle, int32_t LinkIndex); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.IsValidBoneLink // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcdd00
	bool IsValidBoneConnection(struct FDestructibleBoneHandle InBoneHandle1, struct FDestructibleBoneHandle InBoneHandle2); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.IsValidBoneConnection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcf480
	bool HasBoneFlags(struct FDestructibleBoneHandle InBoneHandle, char Flags); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.HasBoneFlags // (Final|Native|Public|BlueprintCallable) // @ game+0x5bcccb0
	struct TArray<struct FFracturedDestructibleStrainBone> GetStrainBonesLevelData(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetStrainBonesLevelData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bce740
	struct TArray<struct FSimpleDestructibleLevelData> GetSimpleDestructiblesLevelData(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetSimpleDestructiblesLevelData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcc760
	struct AEmbarkDestructionGraphActor* GetFromLevel(struct ULevel* InLevelContext); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetFromLevel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5bccdf0
	struct AEmbarkDestructionGraphActor* GetFromComponent(struct UActorComponent* InComponentContext); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetFromComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5bd0d40
	struct AEmbarkDestructionGraphActor* GetFromActor(struct AActor* InActorContext); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetFromActor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5bcc6c0
	struct TArray<struct FFracturedDestructibleBoneLevelData> GetBonesLevelData(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetBonesLevelData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcef20
	float GetBoneHealth(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetBoneHealth // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcca30
	struct UEmbarkFracturedDestructibleMeshComponent* GetBoneFracturedDestructibleComponent(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.GetBoneFracturedDestructibleComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcf1e0
	void FindAllConnectedBones(struct FDestructibleBoneHandle InBoneHandle, struct FEmbarkBoneSearchResult& OutResult, struct FEmbarkBoneSearchParams& Params); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.FindAllConnectedBones // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bcbe30
	void DumpDestructionGraph(bool bDumpToLog, bool bDumpToFile, bool bPrettyPrint, bool bHashStableGraph); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.DumpDestructionGraph // (Final|Native|Public|BlueprintCallable) // @ game+0x5bcffa0
	void ClearBoneFlags(struct FDestructibleBoneHandle InBoneHandle, char Flags); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.ClearBoneFlags // (Final|Native|Public|BlueprintCallable) // @ game+0x5bcd330
	bool BoneHasAnyValidConnections(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphActor.BoneHasAnyValidConnections // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bce520
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGraphActorSubsystem
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkDestructionGraphActorSubsystem : UWorldSubsystem {
	struct TMap<struct ULevel*, struct AEmbarkDestructionGraphActor*> DestructionGraphs; // 0xa0(0x50)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGraphBuildUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDestructionGraphBuildUtils : UObject {

	struct AEmbarkDestructionGraphActor* GetOrCreateGraphActor(struct ULevel* Level, bool bCreateIfNotFound, bool bDeferConstruction); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphBuildUtils.GetOrCreateGraphActor // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5bd19c0
	bool BuildDestructionGraphAtRuntime(struct UWorld* World); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphBuildUtils.BuildDestructionGraphAtRuntime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5bd1780
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGraphSubsystem
// Size: 0x3e0 (Inherited: 0xa0)
struct UEmbarkDestructionGraphSubsystem : UWorldSubsystem {
	struct TMap<struct APlayerController*, bool> PlayerReceivedDestructionGraph; // 0xa0(0x50)
	char pad_f0[0x8]; // 0xf0(0x08)
	struct TSet<struct AEmbarkDestructionGraphActor*> GraphActorsInitialized; // 0xf8(0x50)
	char pad_148[0x298]; // 0x148(0x298)

	bool HasPlayerReceivedDestructionGraph(struct APlayerController* PlayerController); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphSubsystem.HasPlayerReceivedDestructionGraph // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bd5040
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGraphVolume
// Size: 0x710 (Inherited: 0x700)
struct UEmbarkDestructionGraphVolume : UBoxComponent {
	int32_t VolumeIndex; // 0x6f8(0x04)
	int32_t VolumePriority; // 0x6fc(0x04)
	bool bRemoveConnectionsOutsideStrainGraph; // 0x700(0x01)
	char pad_709[0x7]; // 0x709(0x07)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGraphVolumeActor
// Size: 0x580 (Inherited: 0x3a0)
struct AEmbarkDestructionGraphVolumeActor : AActor {
	struct UEmbarkDestructionGraphVolume* DestructionGraphVolume; // 0x398(0x08)
	bool bRuntimeAffecting; // 0x3a0(0x01)
	int32_t VolumePriority; // 0x3a4(0x04)
	bool bForceOverrideDestructionSettings; // 0x3a8(0x01)
	char pad_3ae[0x2]; // 0x3ae(0x02)
	struct FString EnableOnlyWithFeatureFlag; // 0x3b0(0x10)
	struct FBoneDestructionSettings DestructionSettings; // 0x3c0(0x78)
	struct FFracturedMaterialGameplayOverrides MaterialGameplaySettings; // 0x438(0x138)
	char pad_570[0x10]; // 0x570(0x10)

	struct TArray<struct FString> GetFeatureFlags(); // Function EmbarkFracturedDestructible.EmbarkDestructionGraphVolumeActor.GetFeatureFlags // (Final|Native|Public|Const) // @ game+0x5bd5670
};

// Class EmbarkFracturedDestructible.EmbarkDestructionStrainPointVolumeActor
// Size: 0x3c0 (Inherited: 0x3a0)
struct AEmbarkDestructionStrainPointVolumeActor : AActor {
	struct UBoxComponent* Volume; // 0x398(0x08)
	struct FVector GridSize; // 0x3a0(0x18)
};

// Class EmbarkFracturedDestructible.StrainPointVisualizerComponent
// Size: 0x6c0 (Inherited: 0x6c0)
struct UStrainPointVisualizerComponent : UPrimitiveComponent {
};

// Class EmbarkFracturedDestructible.DestructionConstraintEffects
// Size: 0x180 (Inherited: 0xa0)
struct UDestructionConstraintEffects : UDataAsset {
	struct FEmbarkFXParticleParams LingeringEffect; // 0xa0(0x18)
	struct FEmbarkFXAudioParams LingeringSound; // 0xb8(0x58)
	struct FEmbarkFXParticleParams BreakEffect; // 0x110(0x18)
	struct FEmbarkFXAudioParams BreakSound; // 0x128(0x58)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionGeneralSettingsAsset
// Size: 0x260 (Inherited: 0xa0)
struct UEmbarkDestructionGeneralSettingsAsset : UDataAsset {
	struct TMap<struct FName, struct UFracturedMaterialAsset*> DefaultMaterialMapping; // 0xa0(0x50)
	struct UFracturedMaterialGameplay* GameplayFallback; // 0xf0(0x08)
	struct FEmbarkFXParticleParams LingeringSmokeEffect; // 0xf8(0x18)
	struct FDamageCracksSettings DamageCracksSettings; // 0x110(0x18)
	struct FDestructionCollectorSettings CollectorSettings; // 0x128(0x10)
	struct TMap<struct UStaticMesh*, struct FEdgeMeshMaterialOverride> EdgeMeshOverrideMaterials; // 0x138(0x50)
	struct TSet<struct TSoftClassPtr<UObject>> NoCollisionDamageTypes; // 0x188(0x50)
	struct FSmoothImpactDestruction SmoothImpactDestruction; // 0x1d8(0x10)
	struct FDestructionPhysicsConstraintsSettings PhysicsConstraintsSettings; // 0x1e8(0x70)
	char pad_258[0x8]; // 0x258(0x08)

	struct FString GetMaxNumNoCollisionViolationMsg(); // Function EmbarkFracturedDestructible.EmbarkDestructionGeneralSettingsAsset.GetMaxNumNoCollisionViolationMsg // (Final|Native|Static|Public) // @ game+0x5bda7f0
	int32_t GetMaxNumNoCollisionDamageTypes(); // Function EmbarkFracturedDestructible.EmbarkDestructionGeneralSettingsAsset.GetMaxNumNoCollisionDamageTypes // (Final|Native|Static|Public) // @ game+0x5bd8bf0
};

// Class EmbarkFracturedDestructible.StrainSettingsAsset
// Size: 0x100 (Inherited: 0xa0)
struct UStrainSettingsAsset : UDataAsset {
	struct FStrainSettings StrainSettings; // 0xa0(0x60)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionBudgetSettingsAsset
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkDestructionBudgetSettingsAsset : UDataAsset {
	float RemovalHzExponent; // 0xa0(0x04)
	float MaxSimulationCost; // 0xa4(0x04)
	float AwakeFracturedDestructibleBaseCost; // 0xa8(0x04)
	float AwakeFracturedDestructibleSizeCostMultiplier; // 0xac(0x04)
	float BaseAwakePriority; // 0xb0(0x04)
	float SizePriorityMultiplier; // 0xb4(0x04)
	float ReducedGeneralPriorityPerSecond; // 0xb8(0x04)
	float TimeUntilExponentiallyReduceAwakePriority; // 0xbc(0x04)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionLevelSettings
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkDestructionLevelSettings : UDataAsset {
	struct UEmbarkDestructionBudgetSettingsAsset* BudgetSettings; // 0xa0(0x08)
	struct UStrainSettingsAsset* StrainSettings; // 0xa8(0x08)
	struct UEmbarkDestructionGeneralSettingsAsset* GeneralSettings; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionWorldSettingsExtension
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkDestructionWorldSettingsExtension : UEmbarkWorldSettingsExtension {
	struct TSoftObjectPtr<UEmbarkDestructionLevelSettings> DestructionLevelSettings; // 0x98(0x28)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionSettings
// Size: 0x140 (Inherited: 0xb0)
struct UEmbarkDestructionSettings : UDeveloperSettings {
	char pad_b0[0x50]; // 0xb0(0x50)
	struct TSoftObjectPtr<UEmbarkDestructionLevelSettings> DefaultDestructionLevelSettings; // 0x100(0x28)
	struct TArray<struct FDestructionLevelSettings> DestructionLevelSettings; // 0x128(0x10)
	char pad_138[0x8]; // 0x138(0x08)
};

// Class EmbarkFracturedDestructible.EmbarkDelayedDestructionEffects
// Size: 0x110 (Inherited: 0xa0)
struct UEmbarkDelayedDestructionEffects : UDataAsset {
	struct FEmbarkFXParticleParams Effect; // 0xa0(0x18)
	struct FEmbarkFXAudioParams Sound; // 0xb8(0x58)
};

// Class EmbarkFracturedDestructible.FracturedMaterialEffects
// Size: 0x120 (Inherited: 0xa0)
struct UFracturedMaterialEffects : UDataAsset {
	struct FEmbarkFXParticleParams BreakEffect; // 0xa0(0x18)
	enum class EAttachLocation AttachMode; // 0xb8(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
	struct FEmbarkFXAudioParams BreakSound; // 0xc0(0x58)
	bool bUseBoundsForLocation; // 0x118(0x01)
	bool bPropagateToEnvironment; // 0x119(0x01)
	bool bShowDematerializedEdgemeshes; // 0x11a(0x01)
	char pad_11b[0x5]; // 0x11b(0x05)
};

// Class EmbarkFracturedDestructible.FracturedMaterialGameplay
// Size: 0x1d0 (Inherited: 0xa0)
struct UFracturedMaterialGameplay : UDataAsset {
	float Health; // 0xa0(0x04)
	struct FGameplayTag MaterialTag; // 0xa4(0x08)
	char pad_ac[0x4]; // 0xac(0x04)
	struct FStrainMaterialSettings StrainSettings; // 0xb0(0x40)
	struct FEmbarkFireObjectSettings FireSettings; // 0xf0(0x68)
	float BreakAtPercent; // 0x158(0x04)
	float StrainBreakDamagePercent; // 0x15c(0x04)
	float StrainBreakMaxHealthReductionPercent; // 0x160(0x04)
	float StrainPostBreakImpulseScale; // 0x164(0x04)
	float ImpactImpulseLimit; // 0x168(0x04)
	float StrainImpactImpulseScale; // 0x16c(0x04)
	float ImpactDamageMultiplier; // 0x170(0x04)
	float ImpactBreakAtPercent; // 0x174(0x04)
	float ImpactSizeDamageThreshold; // 0x178(0x04)
	float CrushingCoefficient; // 0x17c(0x04)
	enum class ECrushingCombineMode CrushingCoefficientCombineMode; // 0x180(0x01)
	bool bDelayDestruction; // 0x181(0x01)
	char pad_182[0x6]; // 0x182(0x06)
	double DestructionDelayDuration; // 0x188(0x08)
	bool EnableDestructionDislodgeEffect; // 0x190(0x01)
	char pad_191[0x3]; // 0x191(0x03)
	float DislodgeEffectDuration; // 0x194(0x04)
	float DislodgeEffectDynamicFriction; // 0x198(0x04)
	float DislodgeEffectStaticFriction; // 0x19c(0x04)
	float DislodgeEffectSeparationOffset; // 0x1a0(0x04)
	float DislodgeEffectCooldown; // 0x1a4(0x04)
	float SmoothDestructionImpulseLimitScale; // 0x1a8(0x04)
	float SmoothDestructionLimitMulOnStaticCollision; // 0x1ac(0x04)
	float SmoothDestructionVelocityDampingScale; // 0x1b0(0x04)
	float SmoothDestructionVelocityLimit; // 0x1b4(0x04)
	float SmoothDestructionImpactDamageMultiplier; // 0x1b8(0x04)
	float MaxDepenetrationVelocity; // 0x1bc(0x04)
	struct FName ConstraintsPreset; // 0x1c0(0x08)
	float ConstraintsProbability; // 0x1c8(0x04)
	float ConstraintsDamageToBreak; // 0x1cc(0x04)
};

// Class EmbarkFracturedDestructible.FracturedEdgeMaterial
// Size: 0x1a0 (Inherited: 0xa0)
struct UFracturedEdgeMaterial : UDataAsset {
	struct TMap<enum class EEdgeMeshSize, struct FMeshArray> EdgeMeshesMap; // 0xa0(0x50)
	struct UFracturedMaterialEffects* BreakMaterial; // 0xf0(0x08)
	struct TMap<enum class EEdgeMeshSize, struct FMeshArray> CracksMeshesMap; // 0xf8(0x50)
	struct TMap<struct UMaterialInterface*, struct UMaterialInterface*> OverrideMaterials; // 0x148(0x50)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class EmbarkFracturedDestructible.FracturedMaterialAsset
// Size: 0xd0 (Inherited: 0xa0)
struct UFracturedMaterialAsset : UDataAsset {
	struct UFracturedMaterialEffects* EffectMaterial; // 0xa0(0x08)
	struct UEmbarkDelayedDestructionEffects* DelayedDestructionEffectMaterial; // 0xa8(0x08)
	struct UFracturedMaterialGameplay* GameplayMaterial; // 0xb0(0x08)
	struct UFracturedEdgeMaterial* EdgeMaterial; // 0xb8(0x08)
	struct UFracturedEdgeMaterial* HiddenEdgeMaterial; // 0xc0(0x08)
	struct UPhysicalMaterial* PhysicalMaterial; // 0xc8(0x08)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionSettingsSubsystem
// Size: 0x100 (Inherited: 0xb0)
struct UEmbarkDestructionSettingsSubsystem : UScriptGameInstanceSubsystem {
	struct TSet<struct UObject*> LoadedAssets; // 0xb0(0x50)

	void OnMappingLoaded(); // Function EmbarkFracturedDestructible.EmbarkDestructionSettingsSubsystem.OnMappingLoaded // (Final|Native|Public) // @ game+0x5bd8ee0
};

// Class EmbarkFracturedDestructible.EmbarkDestructionStrainGraphSubsystem
// Size: 0x140 (Inherited: 0xb0)
struct UEmbarkDestructionStrainGraphSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x90]; // 0xb0(0x90)
};

// Class EmbarkFracturedDestructible.EmbarkDestructionUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDestructionUtils : UObject {

	void NotifyMatchEnd(struct UObject* WorldContextObject); // Function EmbarkFracturedDestructible.EmbarkDestructionUtils.NotifyMatchEnd // (Final|Native|Static|Public) // @ game+0x5bdad60
	struct FName GetPrimitiveBoneNameFromBoneIndex(struct UPrimitiveComponent* PrimitiveComponent, int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkDestructionUtils.GetPrimitiveBoneNameFromBoneIndex // (Final|Native|Static|Public) // @ game+0x5bdb3b0
	int32_t GetPrimitiveBoneIndexFromBoneName(struct UPrimitiveComponent* PrimitiveComponent, struct FName BoneName); // Function EmbarkFracturedDestructible.EmbarkDestructionUtils.GetPrimitiveBoneIndexFromBoneName // (Final|Native|Static|Public) // @ game+0x5bdb2b0
	struct AEmbarkDestructionGraphActor* FindDestructionGraphActorInlevel(struct ULevel* InLevel); // Function EmbarkFracturedDestructible.EmbarkDestructionUtils.FindDestructionGraphActorInlevel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5bdb040
};

// Class EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshAssetUserData
// Size: 0x110 (Inherited: 0xa0)
struct UEmbarkFracturedDestructibleMeshAssetUserData : UAssetUserData {
	struct TArray<struct FEmbarkDestructibleBoneAssetData> Bones; // 0xa0(0x10)
	struct TMap<struct FName, int32_t> BoneNameToIndexLookup; // 0xb0(0x50)
	int32_t JsonHash; // 0x100(0x04)
	int32_t Version; // 0x104(0x04)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent
// Size: 0xb20 (Inherited: 0x810)
struct UEmbarkFracturedDestructibleMeshComponent : UEmbarkCompositeMeshComponent {
	struct TArray<struct FEmbarkDestructibleBoneData> BonesData; // 0x810(0x10)
	struct TMap<struct FName, struct UFracturedMaterialAsset*> RuntimeMaterialSettings; // 0x820(0x50)
	struct UFracturedMaterialGameplay* GameplayFallback; // 0x870(0x08)
	struct UEmbarkClusterEdgeMeshSystem* ClusterEdgeMeshSystem; // 0x878(0x08)
	struct UEmbarkDestructionClusterSubsystem* ClusterSubsystem; // 0x880(0x08)
	struct UEmbarkCracksSystem* CracksMeshClusterSystem; // 0x888(0x08)
	struct AEmbarkDestructionGraphActor* OwningDestructionGraphActor; // 0x890(0x08)
	char pad_898[0x110]; // 0x898(0x110)
	struct FDamageCracksSettings DamageCracksSettings; // 0x9a8(0x18)
	struct TMap<struct FName, struct UFracturedMaterialAsset*> MaterialSettingsOverrides; // 0x9c0(0x50)
	struct UFracturedMaterialEffects* BreakMaterialOverride; // 0xa10(0x08)
	struct FBoneDestructionSettings DefaultBoneSettings; // 0xa18(0x78)
	struct TMap<struct FName, struct FBoneDestructionSettings> BonesSettingsOverride; // 0xa90(0x50)
	struct FMulticastInlineDelegate OnBoneDamaged; // 0xae0(0x10)
	double PostFractureImpulseScale; // 0xaf0(0x08)
	bool bReduceLODsWhenBroken; // 0xaf8(0x01)
	bool bEnableEncodeBoneHealthInPrimitiveCustomData; // 0xaf9(0x01)
	char pad_afa[0x2]; // 0xafa(0x02)
	int32_t CustomDataBoneDamageStateStartIndex; // 0xafc(0x04)
	struct FMulticastInlineDelegate OnBoneBeginSimulate; // 0xb00(0x10)
	struct FMulticastInlineDelegate OnSimulationChanged; // 0xb10(0x10)

	void StartSimulateFractured(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.StartSimulateFractured // (Final|Native|Public|BlueprintCallable) // @ game+0x33aadf0
	void ShowBone(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.ShowBone // (Final|Native|Public|BlueprintCallable) // @ game+0x5be2e00
	void SetBoneFlags(int32_t BoneIndex, char Flags); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.SetBoneFlags // (Final|Native|Public|Const) // @ game+0x5be1fd0
	void SetBoneCollisionProfile(int32_t BoneIndex, struct FName CollisionProfile); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.SetBoneCollisionProfile // (Final|Native|Public|BlueprintCallable) // @ game+0x5bdd100
	void ResetBoneCollisionProfile(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.ResetBoneCollisionProfile // (Final|Native|Public|BlueprintCallable) // @ game+0x5be3370
	void OnFireObjectStateChanged(struct FEmbarkFireOnStateChangedData& ChangedData); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.OnFireObjectStateChanged // (Final|Native|Private|HasOutParms) // @ game+0x5be1530
	void OnBoneDamagedCallback(struct FBoneDamageEventType& Damage); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.OnBoneDamagedCallback // (Final|Native|Private|HasOutParms) // @ game+0x5bdda70
	void MarkBoneForDestruction(int32_t BoneIndex, bool bDestroyConnected); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.MarkBoneForDestruction // (Final|Native|Public|BlueprintCallable) // @ game+0x5bde790
	bool IsBoneHidden(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.IsBoneHidden // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be2180
	bool IsBoneDestroyed(int32_t InBoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.IsBoneDestroyed // (Final|Native|Public|Const) // @ game+0x5bdd280
	void HideBone(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.HideBone // (Final|Native|Public|BlueprintCallable) // @ game+0x5be2c90
	bool HasBoneFlags(int32_t BoneIndex, char Flags); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.HasBoneFlags // (Final|Native|Public|Const) // @ game+0x5bdf530
	struct FTransform GetWeldedBoneTransform(struct FName BoneName); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetWeldedBoneTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be0300
	int32_t GetStrainBoneBoneCount(struct FName ConnectedBone); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetStrainBoneBoneCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bde520
	struct AEmbarkDestructionGraphActor* GetOwningDestructionGraphActor(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetOwningDestructionGraphActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be2f80
	int32_t GetNumConnectedBones(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetNumConnectedBones // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be20d0
	int32_t GetNumBones(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetNumBones // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdf200
	struct UFracturedMaterialAsset* GetMaterialSettings(struct FName Material); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetMaterialSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bddcb0
	int32_t GetGraphBoneCount(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetGraphBoneCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdd440
	struct UEmbarkFracturedDestructibleMeshAssetUserData* GetDestructibleMeshAssetData(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetDestructibleMeshAssetData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be1a10
	struct FTransform GetBoneTransform(int32_t BoneIndex, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bde060
	bool GetBoneSimulatePhysics(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneSimulatePhysics // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdf6a0
	struct FTransform GetBoneRenderTransform(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneRenderTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bde610
	struct FVector GetBonePhysicsLinearVelocity(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBonePhysicsLinearVelocity // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be2600
	bool GetBoneNameSimulatePhysics(struct FName BoneName); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneNameSimulatePhysics // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be3020
	struct FName GetBoneName(int32_t InBoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdcd70
	struct UFracturedMaterialAsset* GetBoneMaterialSettings(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneMaterialSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be0140
	float GetBoneMass(int32_t BoneIndex, bool bGetWelded); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneMass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be3630
	int32_t GetBoneIndex(struct FName BoneName); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdfb60
	float GetBoneHealth(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneHealth // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be27f0
	struct FGameplayTag GetBoneGameplayTag(struct FName BoneName); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneGameplayTag // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be16b0
	struct FFracturedMaterialGameplayData GetBoneGameplayMaterialData(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneGameplayMaterialData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdd490
	struct TSet<struct USceneComponent*> GetBoneChildren(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneChildren // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bde890
	struct UFracturedMaterialEffects* GetBoneBreakMaterial(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneBreakMaterial // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be2510
	struct FBoxSphereBounds GetBoneBounds(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetBoneBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5be29e0
	struct TArray<struct UEmbarkSimpleDestructibleMeshComponent*> GetAttachedSimpleDestructibles(int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.GetAttachedSimpleDestructibles // (Final|Native|Public|Const) // @ game+0x5be2ea0
	void DamageBone(struct FBoneDamage& InDamage); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.DamageBone // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5be3880
	void ClearBoneFlags(int32_t BoneIndex, char Flags); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.ClearBoneFlags // (Final|Native|Public|Const) // @ game+0x5be1e50
	struct FBoxSphereBounds CalcBoneBounds(int32_t BoneIndex, struct FTransform& LocalToWorld); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.CalcBoneBounds // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bdf9b0
	void BoneFireDamageTimer(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.BoneFireDamageTimer // (Final|Native|Private) // @ game+0x5bdf8d0
	void AddHeatToBone_Server(int32_t BoneIndex, float HeatToAdd, struct FInstigator& Instigator); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructibleMeshComponent.AddHeatToBone_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5be0400
};

// Class EmbarkFracturedDestructible.DestructibleBoneHandleLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDestructibleBoneHandleLibrary : UBlueprintFunctionLibrary {

	int32_t IsSet(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.DestructibleBoneHandleLibrary.IsSet // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5be3cd0
	int32_t GetRootBoneGraphIndex(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.DestructibleBoneHandleLibrary.GetRootBoneGraphIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5be5490
	int32_t GetBoneIndex(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.DestructibleBoneHandleLibrary.GetBoneIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5be49d0
	int32_t GetBoneGraphIndex(struct FDestructibleBoneHandle InBoneHandle); // Function EmbarkFracturedDestructible.DestructibleBoneHandleLibrary.GetBoneGraphIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5be5dc0
};

// Class EmbarkFracturedDestructible.EmbarkDestructionRuntimeRegisterSubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkDestructionRuntimeRegisterSubsystem : UWorldSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct TSet<struct UEmbarkFracturedDestructionListenerComponent*> RegisteredListenerComponents; // 0xb0(0x50)

	void TriggerDestructionRuntimeRegistration(); // Function EmbarkFracturedDestructible.EmbarkDestructionRuntimeRegisterSubsystem.TriggerDestructionRuntimeRegistration // (Final|Native|Public) // @ game+0x5be7d20
};

// Class EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent
// Size: 0x2c0 (Inherited: 0x160)
struct UEmbarkFracturedDestructionListenerComponent : UActorComponent {
	struct FMulticastInlineDelegate OnDestructibleBoneDestroyed; // 0x158(0x10)
	struct FMulticastInlineDelegate OnDestructibleBoneBeginSimulate; // 0x168(0x10)
	char pad_180[0xb8]; // 0x180(0xb8)
	bool bExecuteOncePerActor; // 0x238(0x01)
	bool bRuntimeRegistered; // 0x239(0x01)
	bool bIncludeHiddenComponents; // 0x23a(0x01)
	bool bRuntimeRegisterToSimpleDestruction; // 0x23b(0x01)
	bool bUseBoundsOverlap; // 0x23c(0x01)
	char pad_23d[0x3]; // 0x23d(0x03)
	struct TArray<struct UPrimitiveComponent*> ComponentBoundsBlacklist; // 0x240(0x10)
	struct FVector BoundsInflateAmount; // 0x250(0x18)
	bool bDebugDrawBoundsOverlap; // 0x268(0x01)
	char pad_269[0x3]; // 0x269(0x03)
	float DebugDrawBoundsTime; // 0x26c(0x04)
	struct TSet<struct TWeakObjectPtr<struct AEmbarkDestructionGraphActor>> ValidDestructionGraphActors; // 0x270(0x50)

	void UnregisterOnDestructibleBoneDestroyed(struct UObject* InObject); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.UnregisterOnDestructibleBoneDestroyed // (Final|Native|Public) // @ game+0x5be7090
	void UnregisterOnDestructibleBoneBeginSimulate(struct UObject* InObject); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.UnregisterOnDestructibleBoneBeginSimulate // (Final|Native|Public) // @ game+0x5be7b00
	void RegisterOnDestructibleBoneDestroyed(struct FDelegate InDelegate); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.RegisterOnDestructibleBoneDestroyed // (Final|Native|Public) // @ game+0x5be7710
	void RegisterOnDestructibleBoneBeginSimulate(struct FDelegate InDelegate); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.RegisterOnDestructibleBoneBeginSimulate // (Final|Native|Public) // @ game+0x5be80d0
	void OnLevelDestructionReset(struct ULevel* InLevel); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.OnLevelDestructionReset // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5be7c10
	void DebugDrawBoundsOverlap(); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.DebugDrawBoundsOverlap // (Final|Native|Public) // @ game+0x5be7940
	void CalcDestructionListenerBounds(struct FVector& OutBoundsLocation, struct FQuat& OutBoundsRotation, struct FVector& OutBoundsExtent); // Function EmbarkFracturedDestructible.EmbarkFracturedDestructionListenerComponent.CalcDestructionListenerBounds // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5be79a0
};

// Class EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent
// Size: 0x810 (Inherited: 0x790)
struct UEmbarkSimpleDestructibleMeshComponent : UStaticMeshComponent {
	struct AEmbarkDestructionGraphActor* DestructionGraphActor; // 0x788(0x08)
	struct FSimpleDestructibleDestructionSettings DestructionSettings; // 0x798(0x48)
	bool bCanRecieveImpactDamage; // 0x7e0(0x01)
	char pad_7e1[0x3]; // 0x7e1(0x03)
	float ImpactSizeDamageThreshold; // 0x7e4(0x04)
	float ImpactDamageMultiplier; // 0x7e8(0x04)
	bool bEnableSmoothImpactDestruction; // 0x7ec(0x01)
	bool bEnableStaticCollisionSmoothDestruction; // 0x7ed(0x01)
	char pad_7ee[0x2]; // 0x7ee(0x02)
	float SmoothDestructionImpulseLimitScale; // 0x7f0(0x04)
	float SmoothDestructionLimitMulOnStaticCollision; // 0x7f4(0x04)
	float SmoothDestructionVelocityDampingScale; // 0x7f8(0x04)
	float SmoothDestructionVelocityLimit; // 0x7fc(0x04)
	float SmoothDestructionImpactDamageMultiplier; // 0x800(0x04)
	bool bAllowAttachToParentOnSimulate; // 0x804(0x01)
	char pad_805[0xb]; // 0x805(0x0b)

	void SetPhysicsDisabled(bool bSetPhysicsDisabled); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.SetPhysicsDisabled // (Final|Native|Public) // @ game+0x5be8b20
	void Reset(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.Reset // (Final|Native|Public) // @ game+0x5be96b0
	void ReceiveOnReset(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.ReceiveOnReset // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnDestroyComponentFromDestruction_Server(struct UEmbarkSimpleDestructibleMeshComponent* SimpleDestructibleMeshComponent, struct UEmbarkFracturedDestructibleMeshComponent* FracturedDestructibleMeshComponent, int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.ReceiveOnDestroyComponentFromDestruction_Server // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnDestroyComponentFromDestruction_Deterministic(struct UEmbarkSimpleDestructibleMeshComponent* SimpleDestructibleMeshComponent, struct UEmbarkFracturedDestructibleMeshComponent* FracturedDestructibleMeshComponent, int32_t BoneIndex); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.ReceiveOnDestroyComponentFromDestruction_Deterministic // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnDamagedFromImpact_Server(struct UPrimitiveComponent* ImpactComponent, int32_t ItemIndex, float Damage, struct FVector& HitLocation, struct FVector& HitDirection); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.ReceiveOnDamagedFromImpact_Server // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveIsDestroyed(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.ReceiveIsDestroyed // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void NotifyDestructionGraphComponentDestroyed(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.NotifyDestructionGraphComponentDestroyed // (Final|Native|Public) // @ game+0x5be9080
	bool IsPhysicsDisabled(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.IsPhysicsDisabled // (Final|Native|Public|Const) // @ game+0x5be8cb0
	bool IsPartOfDestructionGraph(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.IsPartOfDestructionGraph // (Final|Native|Public|Const) // @ game+0x5be87e0
	bool HasBroken(); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.HasBroken // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void CalcDestructionBounds(struct FVector& OutBoundsLocation, struct FQuat& OutBoundsRotation, struct FVector& OutBoundsExtent); // Function EmbarkFracturedDestructible.EmbarkSimpleDestructibleMeshComponent.CalcDestructionBounds // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5be8e20
};

