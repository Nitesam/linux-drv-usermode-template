// Class MovieScene.MovieSceneBlenderSystemSupport
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneBlenderSystemSupport : UInterface {
};

// Class MovieScene.MovieSceneBoundObjectProxy
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneBoundObjectProxy : UInterface {

	struct UObject* BP_GetBoundObjectForSequencer(struct UObject* ResolvedObject); // Function MovieScene.MovieSceneBoundObjectProxy.BP_GetBoundObjectForSequencer // (RequiredAPI|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x4abfe0
};

// Class MovieScene.MovieSceneChannelOverrideProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneChannelOverrideProvider : UInterface {
};

// Class MovieScene.MovieSceneDeterminismSource
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneDeterminismSource : UInterface {
};

// Class MovieScene.MovieSceneEvaluationHook
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneEvaluationHook : UInterface {
};

// Class MovieScene.MovieSceneMetaDataInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneMetaDataInterface : UInterface {
};

// Class MovieScene.MovieScenePlaybackClient
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieScenePlaybackClient : UInterface {
};

// Class MovieScene.MovieSceneSequencePlayerObserver
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneSequencePlayerObserver : UInterface {
};

// Class MovieScene.MovieSceneBindingOwnerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneBindingOwnerInterface : UInterface {
};

// Class MovieScene.MovieSceneCachedTrack
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneCachedTrack : UInterface {
};

// Class MovieScene.MovieSceneEasingFunction
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneEasingFunction : UInterface {

	float OnEvaluate(float Interp); // Function MovieScene.MovieSceneEasingFunction.OnEvaluate // (RequiredAPI|Event|Protected|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x4abfe0
};

// Class MovieScene.MovieSceneKeyProxy
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneKeyProxy : UInterface {
};

// Class MovieScene.MovieSceneSequenceTickManagerClient
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneSequenceTickManagerClient : UInterface {
};

// Class MovieScene.MovieSceneSignedObject
// Size: 0xd0 (Inherited: 0xa0)
struct UMovieSceneSignedObject : UObject {
	struct FGuid Signature; // 0x9c(0x10)
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class MovieScene.MovieSceneChannelOverrideContainer
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneChannelOverrideContainer : UMovieSceneSignedObject {
};

// Class MovieScene.MovieSceneSectionChannelOverrideRegistry
// Size: 0xf0 (Inherited: 0xa0)
struct UMovieSceneSectionChannelOverrideRegistry : UObject {
	struct TMap<struct FName, struct UMovieSceneChannelOverrideContainer*> Overrides; // 0x98(0x50)
};

// Class MovieScene.MovieSceneTrackTemplateProducer
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneTrackTemplateProducer : UInterface {
};

// Class MovieScene.MovieSceneCompiledData
// Size: 0x470 (Inherited: 0xa0)
struct UMovieSceneCompiledData : UObject {
	struct FMovieSceneEvaluationTemplate EvaluationTemplate; // 0x98(0x160)
	struct FMovieSceneSequenceHierarchy Hierarchy; // 0x1f8(0x118)
	struct FMovieSceneEntityComponentField EntityComponentField; // 0x310(0xf0)
	struct FMovieSceneEvaluationField TrackTemplateField; // 0x400(0x30)
	struct TArray<struct FFrameTime> DeterminismFences; // 0x430(0x10)
	struct FGuid CompiledSignature; // 0x440(0x10)
	struct FGuid CompilerVersion; // 0x450(0x10)
	struct FMovieSceneSequenceCompilerMaskStruct AccumulatedMask; // 0x460(0x01)
	struct FMovieSceneSequenceCompilerMaskStruct AllocatedMask; // 0x461(0x01)
	enum class EMovieSceneSequenceFlags AccumulatedFlags; // 0x462(0x01)
	char pad_46b[0x5]; // 0x46b(0x05)
};

// Class MovieScene.MovieSceneCompiledDataManager
// Size: 0x2a0 (Inherited: 0xa0)
struct UMovieSceneCompiledDataManager : UObject {
	char pad_a0[0xa8]; // 0xa0(0xa8)
	struct TMap<int32_t, struct FMovieSceneSequenceHierarchy> Hierarchies; // 0x148(0x50)
	struct TMap<int32_t, struct FMovieSceneEvaluationTemplate> TrackTemplates; // 0x198(0x50)
	struct TMap<int32_t, struct FMovieSceneEvaluationField> TrackTemplateFields; // 0x1e8(0x50)
	struct TMap<int32_t, struct FMovieSceneEntityComponentField> EntityComponentFields; // 0x238(0x50)
	char pad_288[0x18]; // 0x288(0x18)
};

// Class MovieScene.MovieSceneEntityProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneEntityProvider : UInterface {
};

// Class MovieScene.MovieSceneEntitySystem
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieSceneEntitySystem : UObject {
	struct UMovieSceneEntitySystemLinker* Linker; // 0x98(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MovieScene.MovieSceneBlenderSystem
// Size: 0xe0 (Inherited: 0xb0)
struct UMovieSceneBlenderSystem : UMovieSceneEntitySystem {
	char pad_b0[0x30]; // 0xb0(0x30)
};

// Class MovieScene.MovieSceneEntityInstantiatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneEntityInstantiatorSystem : UMovieSceneEntitySystem {
};

// Class MovieScene.MovieSceneGenericBoundObjectInstantiator
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneGenericBoundObjectInstantiator : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieScene.MovieSceneBoundSceneComponentInstantiator
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneBoundSceneComponentInstantiator : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieScene.MovieSceneValueDecomposer
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneValueDecomposer : UInterface {
};

// Class MovieScene.MovieSceneEntitySystemLinker
// Size: 0x7b0 (Inherited: 0xa0)
struct UMovieSceneEntitySystemLinker : UObject {
	char pad_a0[0x270]; // 0xa0(0x270)
	struct FMovieSceneEntitySystemGraph SystemGraph; // 0x310(0x190)
	char pad_4a0[0x310]; // 0x4a0(0x310)
};

// Class MovieScene.MovieSceneEvalTimeSystem
// Size: 0x220 (Inherited: 0xb0)
struct UMovieSceneEvalTimeSystem : UMovieSceneEntitySystem {
	char pad_b0[0x170]; // 0xb0(0x170)
};

// Class MovieScene.MovieSceneEvaluationHookSystem
// Size: 0x100 (Inherited: 0xb0)
struct UMovieSceneEvaluationHookSystem : UMovieSceneEntitySystem {
	struct TMap<struct FMovieSceneEvaluationInstanceKey, struct FMovieSceneEvaluationHookEventContainer> PendingEventsByRootInstance; // 0xb0(0x50)
};

// Class MovieScene.MovieScenePreAnimatedStateSystemInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieScenePreAnimatedStateSystemInterface : UInterface {
};

// Class MovieScene.MovieSceneCachePreAnimatedStateSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneCachePreAnimatedStateSystem : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieScene.MovieSceneRestorePreAnimatedStateSystem
// Size: 0xc0 (Inherited: 0xb0)
struct UMovieSceneRestorePreAnimatedStateSystem : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class MovieScene.MovieSceneRootInstantiatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneRootInstantiatorSystem : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieScene.MovieSceneSpawnablesSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneSpawnablesSystem : UMovieSceneEntitySystem {
};

// Class MovieScene.MovieSceneTrackInstance
// Size: 0xc0 (Inherited: 0xa0)
struct UMovieSceneTrackInstance : UObject {
	struct TWeakObjectPtr<struct UObject> WeakAnimatedObject; // 0x98(0x08)
	bool bIsRootTrackInstance; // 0xa0(0x01)
	struct UMovieSceneEntitySystemLinker* PrivateLinker; // 0xa8(0x08)
	struct TArray<struct FMovieSceneTrackInstanceInput> Inputs; // 0xb0(0x10)
};

// Class MovieScene.MovieSceneTrackInstanceInstantiator
// Size: 0x160 (Inherited: 0xb0)
struct UMovieSceneTrackInstanceInstantiator : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0xb0]; // 0xb0(0xb0)
};

// Class MovieScene.MovieSceneTrackInstanceSystem
// Size: 0xc0 (Inherited: 0xb0)
struct UMovieSceneTrackInstanceSystem : UMovieSceneEntitySystem {
	struct UMovieSceneTrackInstanceInstantiator* Instantiator; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class MovieScene.MovieSceneCustomClockSource
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneCustomClockSource : UInterface {

	void OnTick(float DeltaSeconds, float InPlayRate); // Function MovieScene.MovieSceneCustomClockSource.OnTick // (Native|Public) // @ game+0x24c1990
	void OnStopPlaying(struct FQualifiedFrameTime& InStopTime); // Function MovieScene.MovieSceneCustomClockSource.OnStopPlaying // (Native|Public|HasOutParms) // @ game+0x24b9a10
	void OnStartPlaying(struct FQualifiedFrameTime& InStartTime); // Function MovieScene.MovieSceneCustomClockSource.OnStartPlaying // (Native|Public|HasOutParms) // @ game+0x24de200
	struct FFrameTime OnRequestCurrentTime(struct FQualifiedFrameTime& InCurrentTime, float InPlayRate); // Function MovieScene.MovieSceneCustomClockSource.OnRequestCurrentTime // (Native|Public|HasOutParms) // @ game+0x25080f0
};

// Class MovieScene.MovieSceneBuiltInEasingFunction
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieSceneBuiltInEasingFunction : UObject {
	enum class EMovieSceneBuiltInEasing Type; // 0xa0(0x01)
	char pad_a1[0xf]; // 0xa1(0x0f)
};

// Class MovieScene.MovieSceneEasingExternalCurve
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieSceneEasingExternalCurve : UObject {
	struct UCurveFloat* Curve; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MovieScene.NodeAndChannelMappings
// Size: 0xa0 (Inherited: 0xa0)
struct UNodeAndChannelMappings : UInterface {
};

// Class MovieScene.MovieSceneNodeGroup
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneNodeGroup : UObject {
};

// Class MovieScene.MovieSceneNodeGroupCollection
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneNodeGroupCollection : UObject {
};

// Class MovieScene.MovieScene
// Size: 0x1d0 (Inherited: 0xd0)
struct UMovieScene : UMovieSceneSignedObject {
	struct TArray<struct FMovieSceneSpawnable> Spawnables; // 0xd0(0x10)
	struct TArray<struct FMovieScenePossessable> Possessables; // 0xe0(0x10)
	struct TArray<struct FMovieSceneBinding> ObjectBindings; // 0xf0(0x10)
	struct TMap<struct FName, struct FMovieSceneObjectBindingIDs> BindingGroups; // 0x100(0x50)
	struct TArray<struct UMovieSceneTrack*> Tracks; // 0x150(0x10)
	struct UMovieSceneTrack* CameraCutTrack; // 0x160(0x08)
	struct FMovieSceneFrameRange SelectionRange; // 0x168(0x10)
	struct FMovieSceneFrameRange PlaybackRange; // 0x178(0x10)
	struct FFrameRate TickResolution; // 0x188(0x08)
	struct FFrameRate DisplayRate; // 0x190(0x08)
	enum class EMovieSceneEvaluationType EvaluationType; // 0x198(0x01)
	enum class EUpdateClockSource ClockSource; // 0x199(0x01)
	char pad_19a[0x6]; // 0x19a(0x06)
	struct FSoftObjectPath CustomClockSourcePath; // 0x1a0(0x20)
	struct TArray<struct FMovieSceneMarkedFrame> MarkedFrames; // 0x1c0(0x10)
};

// Class MovieScene.MovieSceneBindingOverrides
// Size: 0x100 (Inherited: 0xa0)
struct UMovieSceneBindingOverrides : UObject {
	struct TArray<struct FMovieSceneBindingOverrideData> BindingData; // 0x98(0x10)
	char pad_b0[0x50]; // 0xb0(0x50)
};

// Class MovieScene.BuiltInDynamicBindingResolverLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UBuiltInDynamicBindingResolverLibrary : UBlueprintFunctionLibrary {

	struct FMovieSceneDynamicBindingResolveResult ResolveToPlayerPawn(struct UObject* WorldContextObject, int32_t PlayerControllerIndex); // Function MovieScene.BuiltInDynamicBindingResolverLibrary.ResolveToPlayerPawn // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2538fe0
};

// Class MovieScene.MovieSceneFolder
// Size: 0xf0 (Inherited: 0xa0)
struct UMovieSceneFolder : UObject {
	struct FName FolderName; // 0x9c(0x08)
	struct TArray<struct UMovieSceneFolder*> ChildFolders; // 0xa8(0x10)
	struct TArray<struct UMovieSceneTrack*> ChildTracks; // 0xb8(0x10)
	struct TArray<struct FString> ChildObjectBindingStrings; // 0xc8(0x10)
	char pad_d8[0x18]; // 0xd8(0x18)
};

// Class MovieScene.MovieSceneMetaData
// Size: 0xd0 (Inherited: 0xa0)
struct UMovieSceneMetaData : UObject {
	struct FString Author; // 0xa0(0x10)
	struct FDateTime Created; // 0xb0(0x08)
	struct FString Notes; // 0xb8(0x10)
	char pad_c8[0x8]; // 0xc8(0x08)

	void SetNotes(struct FString InNotes); // Function MovieScene.MovieSceneMetaData.SetNotes // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2533440
	void SetCreated(struct FDateTime InCreated); // Function MovieScene.MovieSceneMetaData.SetCreated // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2523c00
	void SetAuthor(struct FString InAuthor); // Function MovieScene.MovieSceneMetaData.SetAuthor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252fc50
	struct FString GetNotes(); // Function MovieScene.MovieSceneMetaData.GetNotes // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2538ec0
	struct FDateTime GetCreated(); // Function MovieScene.MovieSceneMetaData.GetCreated // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2534ea0
	struct FString GetAuthor(); // Function MovieScene.MovieSceneMetaData.GetAuthor // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25387e0
};

// Class MovieScene.MovieSceneTrack
// Size: 0x110 (Inherited: 0xd0)
struct UMovieSceneTrack : UMovieSceneSignedObject {
	struct FMovieSceneTrackEvalOptions EvalOptions; // 0xc8(0x04)
	bool bIsEvalDisabled; // 0xcd(0x01)
	struct TArray<int32_t> RowsDisabled; // 0xd0(0x10)
	struct FGuid EvaluationFieldGuid; // 0xe4(0x10)
	char pad_f5[0x3]; // 0xf5(0x03)
	struct FMovieSceneTrackEvaluationField EvaluationField; // 0xf8(0x10)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class MovieScene.MovieSceneNameableTrack
// Size: 0x110 (Inherited: 0x110)
struct UMovieSceneNameableTrack : UMovieSceneTrack {
};

// Class MovieScene.MovieSceneSection
// Size: 0x160 (Inherited: 0xd0)
struct UMovieSceneSection : UMovieSceneSignedObject {
	struct FMovieSceneSectionEvalOptions EvalOptions; // 0xc8(0x02)
	struct FMovieSceneEasingSettings Easing; // 0xd0(0x38)
	struct FMovieSceneFrameRange SectionRange; // 0x108(0x10)
	struct FFrameNumber PreRollFrames; // 0x118(0x04)
	struct FFrameNumber PostRollFrames; // 0x11c(0x04)
	int32_t RowIndex; // 0x120(0x04)
	int32_t OverlapPriority; // 0x124(0x04)
	char bIsActive : 1; // 0x128(0x01)
	char bIsLocked : 1; // 0x128(0x01)
	char pad_12a_2 : 6; // 0x12a(0x01)
	char pad_12b[0x1]; // 0x12b(0x01)
	float StartTime; // 0x12c(0x04)
	float EndTime; // 0x130(0x04)
	float PrerollTime; // 0x134(0x04)
	float PostrollTime; // 0x138(0x04)
	char bIsInfinite : 1; // 0x13c(0x01)
	char pad_13c_1 : 7; // 0x13c(0x01)
	char pad_13d[0x3]; // 0x13d(0x03)
	bool bSupportsInfiniteRange; // 0x140(0x01)
	struct FOptionalMovieSceneBlendType BlendType; // 0x141(0x02)
	char pad_143[0x1d]; // 0x143(0x1d)

	void SetRowIndex(int32_t NewRowIndex); // Function MovieScene.MovieSceneSection.SetRowIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2532e00
	void SetPreRollFrames(int32_t InPreRollFrames); // Function MovieScene.MovieSceneSection.SetPreRollFrames // (Final|Native|Public|BlueprintCallable) // @ game+0x2542cb0
	void SetPostRollFrames(int32_t InPostRollFrames); // Function MovieScene.MovieSceneSection.SetPostRollFrames // (Final|Native|Public|BlueprintCallable) // @ game+0x2524790
	void SetOverlapPriority(int32_t NewPriority); // Function MovieScene.MovieSceneSection.SetOverlapPriority // (Final|Native|Public|BlueprintCallable) // @ game+0x2511740
	void SetIsLocked(bool bInIsLocked); // Function MovieScene.MovieSceneSection.SetIsLocked // (Final|Native|Public|BlueprintCallable) // @ game+0x251c660
	void SetIsActive(bool bInIsActive); // Function MovieScene.MovieSceneSection.SetIsActive // (Final|Native|Public|BlueprintCallable) // @ game+0x253ba20
	void SetCompletionMode(enum class EMovieSceneCompletionMode InCompletionMode); // Function MovieScene.MovieSceneSection.SetCompletionMode // (Final|Native|Public|BlueprintCallable) // @ game+0x253ded0
	void SetColorTint(struct FColor& InColorTint); // Function MovieScene.MovieSceneSection.SetColorTint // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x252f230
	void SetBlendType(enum class EMovieSceneBlendType InBlendType); // Function MovieScene.MovieSceneSection.SetBlendType // (Native|Public|BlueprintCallable) // @ game+0x2522b30
	bool IsLocked(); // Function MovieScene.MovieSceneSection.IsLocked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x252e5a0
	bool IsActive(); // Function MovieScene.MovieSceneSection.IsActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2533200
	int32_t GetRowIndex(); // Function MovieScene.MovieSceneSection.GetRowIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2545700
	int32_t GetPreRollFrames(); // Function MovieScene.MovieSceneSection.GetPreRollFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2544590
	int32_t GetPostRollFrames(); // Function MovieScene.MovieSceneSection.GetPostRollFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25326a0
	int32_t GetOverlapPriority(); // Function MovieScene.MovieSceneSection.GetOverlapPriority // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2541590
	enum class EMovieSceneCompletionMode GetCompletionMode(); // Function MovieScene.MovieSceneSection.GetCompletionMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25372f0
	struct FColor GetColorTint(); // Function MovieScene.MovieSceneSection.GetColorTint // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x252dab0
	struct FOptionalMovieSceneBlendType GetBlendType(); // Function MovieScene.MovieSceneSection.GetBlendType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2526b10
};

// Class MovieScene.MovieSceneSequence
// Size: 0xe0 (Inherited: 0xd0)
struct UMovieSceneSequence : UMovieSceneSignedObject {
	struct UMovieSceneCompiledData* CompiledData; // 0xc8(0x08)
	enum class EMovieSceneCompletionMode DefaultCompletionMode; // 0xd0(0x01)
	bool bParentContextsAreSignificant; // 0xd1(0x01)
	bool bPlayableDirectly; // 0xd2(0x01)
	enum class EMovieSceneSequenceFlags SequenceFlags; // 0xd3(0x01)
	char pad_dc[0x4]; // 0xdc(0x04)

	struct FMovieSceneTimecodeSource GetEarliestTimecodeSource(); // Function MovieScene.MovieSceneSequence.GetEarliestTimecodeSource // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x251d860
	struct TArray<struct FMovieSceneObjectBindingID> FindBindingsByTag(struct FName InBindingName); // Function MovieScene.MovieSceneSequence.FindBindingsByTag // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2541fa0
	struct FMovieSceneObjectBindingID FindBindingByTag(struct FName InBindingName); // Function MovieScene.MovieSceneSequence.FindBindingByTag // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x251d650
};

// Class MovieScene.MovieSceneSequencePlayer
// Size: 0x540 (Inherited: 0xa0)
struct UMovieSceneSequencePlayer : UObject {
	char pad_a0[0x1f8]; // 0xa0(0x1f8)
	struct TScriptInterface<IMovieSceneSequencePlayerObserver> Observer; // 0x298(0x10)
	struct FMulticastInlineDelegate OnPlay; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnPlayReverse; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnStop; // 0x2c8(0x10)
	struct FMulticastInlineDelegate OnPause; // 0x2d8(0x10)
	struct FMulticastInlineDelegate OnFinished; // 0x2e8(0x10)
	enum class EMovieScenePlayerStatus Status; // 0x2f8(0x01)
	char pad_2f9[0x3]; // 0x2f9(0x03)
	char bReversePlayback : 1; // 0x2fc(0x01)
	char pad_2fc_1 : 7; // 0x2fc(0x01)
	char pad_2fd[0x3]; // 0x2fd(0x03)
	struct UMovieSceneSequence* Sequence; // 0x300(0x08)
	struct FFrameNumber StartTime; // 0x308(0x04)
	int32_t DurationFrames; // 0x30c(0x04)
	float DurationSubFrames; // 0x310(0x04)
	int32_t CurrentNumLoops; // 0x314(0x04)
	int32_t SerialNumber; // 0x318(0x04)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x31c(0x20)
	char pad_33c[0x4]; // 0x33c(0x04)
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance; // 0x340(0x88)
	char pad_3c8[0x90]; // 0x3c8(0x90)
	struct FMovieSceneSequenceReplProperties NetSyncProps; // 0x458(0x14)
	char pad_46c[0x4]; // 0x46c(0x04)
	struct TScriptInterface<IMovieScenePlaybackClient> PlaybackClient; // 0x470(0x10)
	struct UMovieSceneSequenceTickManager* TickManager; // 0x480(0x08)
	char pad_488[0xb8]; // 0x488(0xb8)

	void StopAtCurrentTime(); // Function MovieScene.MovieSceneSequencePlayer.StopAtCurrentTime // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252d3c0
	void Stop(); // Function MovieScene.MovieSceneSequencePlayer.Stop // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252ca40
	void SetWeight(double InWeight); // Function MovieScene.MovieSceneSequencePlayer.SetWeight // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2532d50
	void SetTimeRange(float StartTime, float Duration); // Function MovieScene.MovieSceneSequencePlayer.SetTimeRange // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252c7f0
	void SetPlayRate(float PlayRate); // Function MovieScene.MovieSceneSequencePlayer.SetPlayRate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25438e0
	void SetPlaybackPosition(struct FMovieSceneSequencePlaybackParams PlaybackParams); // Function MovieScene.MovieSceneSequencePlayer.SetPlaybackPosition // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25132e0
	void SetFrameRate(struct FFrameRate FrameRate); // Function MovieScene.MovieSceneSequencePlayer.SetFrameRate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252f2c0
	void SetFrameRange(int32_t StartFrame, int32_t Duration, float SubFrames); // Function MovieScene.MovieSceneSequencePlayer.SetFrameRange // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2543c80
	void SetDisableCameraCuts(bool bInDisableCameraCuts); // Function MovieScene.MovieSceneSequencePlayer.SetDisableCameraCuts // (Final|Native|Public|BlueprintCallable) // @ game+0x2545120
	void Scrub(); // Function MovieScene.MovieSceneSequencePlayer.Scrub // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x253daf0
	void RPC_OnStopEvent(struct FFrameTime StoppedTime, int32_t NewSerialNumber); // Function MovieScene.MovieSceneSequencePlayer.RPC_OnStopEvent // (Final|RequiredAPI|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x2531760
	void RPC_OnFinishPlaybackEvent(struct FFrameTime StoppedTime, int32_t NewSerialNumber); // Function MovieScene.MovieSceneSequencePlayer.RPC_OnFinishPlaybackEvent // (Final|RequiredAPI|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x253fe30
	void RPC_ExplicitServerUpdateEvent(enum class EUpdatePositionMethod Method, struct FFrameTime RelevantTime, int32_t NewSerialNumber); // Function MovieScene.MovieSceneSequencePlayer.RPC_ExplicitServerUpdateEvent // (Final|RequiredAPI|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x25488a0
	void RestoreState(); // Function MovieScene.MovieSceneSequencePlayer.RestoreState // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2534da0
	void RemoveWeight(); // Function MovieScene.MovieSceneSequencePlayer.RemoveWeight // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x251bdb0
	void PlayTo(struct FMovieSceneSequencePlaybackParams PlaybackParams, struct FMovieSceneSequencePlayToParams PlayToParams); // Function MovieScene.MovieSceneSequencePlayer.PlayTo // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x254a530
	void PlayReverse(); // Function MovieScene.MovieSceneSequencePlayer.PlayReverse // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2545ae0
	void PlayLooping(int32_t NumLoops); // Function MovieScene.MovieSceneSequencePlayer.PlayLooping // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2520b30
	void Play(); // Function MovieScene.MovieSceneSequencePlayer.Play // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x253a240
	void Pause(); // Function MovieScene.MovieSceneSequencePlayer.Pause // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2548880
	bool IsReversed(); // Function MovieScene.MovieSceneSequencePlayer.IsReversed // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2529750
	bool IsPlaying(); // Function MovieScene.MovieSceneSequencePlayer.IsPlaying // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2547760
	bool IsPaused(); // Function MovieScene.MovieSceneSequencePlayer.IsPaused // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2535870
	void GoToEndAndStop(); // Function MovieScene.MovieSceneSequencePlayer.GoToEndAndStop // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2530880
	struct FQualifiedFrameTime GetStartTime(); // Function MovieScene.MovieSceneSequencePlayer.GetStartTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x254a750
	struct FString GetSequenceName(bool bAddClientInfo); // Function MovieScene.MovieSceneSequencePlayer.GetSequenceName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x253bd50
	struct UMovieSceneSequence* GetSequence(); // Function MovieScene.MovieSceneSequencePlayer.GetSequence // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x252b270
	float GetPlayRate(); // Function MovieScene.MovieSceneSequencePlayer.GetPlayRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2535910
	struct TArray<struct FMovieSceneObjectBindingID> GetObjectBindings(struct UObject* InObject); // Function MovieScene.MovieSceneSequencePlayer.GetObjectBindings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2531860
	struct FFrameRate GetFrameRate(); // Function MovieScene.MovieSceneSequencePlayer.GetFrameRate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2534e00
	int32_t GetFrameDuration(); // Function MovieScene.MovieSceneSequencePlayer.GetFrameDuration // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x252e660
	struct FQualifiedFrameTime GetEndTime(); // Function MovieScene.MovieSceneSequencePlayer.GetEndTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x252ca00
	struct FQualifiedFrameTime GetDuration(); // Function MovieScene.MovieSceneSequencePlayer.GetDuration // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2543840
	bool GetDisableCameraCuts(); // Function MovieScene.MovieSceneSequencePlayer.GetDisableCameraCuts // (Final|Native|Public|BlueprintCallable) // @ game+0x252f0e0
	struct FQualifiedFrameTime GetCurrentTime(); // Function MovieScene.MovieSceneSequencePlayer.GetCurrentTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2531a90
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Function MovieScene.MovieSceneSequencePlayer.GetBoundObjects // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252dd20
	void ChangePlaybackDirection(); // Function MovieScene.MovieSceneSequencePlayer.ChangePlaybackDirection // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x251bd70
};

// Class MovieScene.MovieSceneSequenceTickManager
// Size: 0x110 (Inherited: 0xa0)
struct UMovieSceneSequenceTickManager : UObject {
	char pad_a0[0x70]; // 0xa0(0x70)
};

// Class MovieScene.MovieSceneBoolSection
// Size: 0x270 (Inherited: 0x160)
struct UMovieSceneBoolSection : UMovieSceneSection {
	bool DefaultValue; // 0x160(0x01)
	char pad_161[0x7]; // 0x161(0x07)
	struct FMovieSceneBoolChannel BoolCurve; // 0x168(0x100)
	char pad_268[0x8]; // 0x268(0x08)
};

// Class MovieScene.MovieSceneHookSection
// Size: 0x180 (Inherited: 0x160)
struct UMovieSceneHookSection : UMovieSceneSection {
	char pad_160[0x10]; // 0x160(0x10)
	char bRequiresRangedHook : 1; // 0x170(0x01)
	char bRequiresTriggerHooks : 1; // 0x170(0x01)
	char pad_170_2 : 6; // 0x170(0x01)
	char pad_171[0xf]; // 0x171(0x0f)
};

// Class MovieScene.MovieSceneSpawnSection
// Size: 0x270 (Inherited: 0x270)
struct UMovieSceneSpawnSection : UMovieSceneBoolSection {
};

// Class MovieScene.MovieSceneSubSection
// Size: 0x1b0 (Inherited: 0x160)
struct UMovieSceneSubSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneSectionParameters Parameters; // 0x168(0x28)
	float StartOffset; // 0x190(0x04)
	float TimeScale; // 0x194(0x04)
	float PrerollTime; // 0x198(0x04)
	char NetworkMask; // 0x19c(0x01)
	char pad_19d[0x3]; // 0x19d(0x03)
	struct UMovieSceneSequence* SubSequence; // 0x1a0(0x08)
	char pad_1a8[0x8]; // 0x1a8(0x08)

	void SetSequence(struct UMovieSceneSequence* Sequence); // Function MovieScene.MovieSceneSubSection.SetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25303e0
	struct UMovieSceneSequence* GetSequence(); // Function MovieScene.MovieSceneSubSection.GetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2517770
};

// Class MovieScene.TestMovieSceneTrack
// Size: 0x130 (Inherited: 0x110)
struct UTestMovieSceneTrack : UMovieSceneTrack {
	bool bHighPassFilter; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct TArray<struct UMovieSceneSection*> SectionArray; // 0x118(0x10)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class MovieScene.TestMovieSceneSection
// Size: 0x160 (Inherited: 0x160)
struct UTestMovieSceneSection : UMovieSceneSection {
};

// Class MovieScene.TestMovieSceneSequence
// Size: 0xe0 (Inherited: 0xe0)
struct UTestMovieSceneSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0xd8(0x08)
};

// Class MovieScene.MovieSceneSubTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneSubTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
};

// Class MovieScene.TestMovieSceneSubTrack
// Size: 0x130 (Inherited: 0x120)
struct UTestMovieSceneSubTrack : UMovieSceneSubTrack {
	struct TArray<struct UMovieSceneSection*> SectionArray; // 0x118(0x10)
};

// Class MovieScene.TestMovieSceneSubSection
// Size: 0x1b0 (Inherited: 0x1b0)
struct UTestMovieSceneSubSection : UMovieSceneSubSection {
};

// Class MovieScene.TestMovieSceneEvalHookTrack
// Size: 0x120 (Inherited: 0x110)
struct UTestMovieSceneEvalHookTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> SectionArray; // 0x108(0x10)
};

// Class MovieScene.TestMovieSceneEvalHookSection
// Size: 0x190 (Inherited: 0x180)
struct UTestMovieSceneEvalHookSection : UMovieSceneHookSection {
	char pad_180[0x10]; // 0x180(0x10)
};

// Class MovieScene.MovieSceneSpawnTrack
// Size: 0x130 (Inherited: 0x110)
struct UMovieSceneSpawnTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
	struct FGuid ObjectGuid; // 0x118(0x10)
};

