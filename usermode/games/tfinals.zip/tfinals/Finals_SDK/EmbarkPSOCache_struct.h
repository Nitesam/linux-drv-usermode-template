// Enum EmbarkPSOCache.EPSOPrecompilationBatchMode
enum class EPSOPrecompilationBatchMode : uint8_t {
	Background = 0,
	Fast = 1,
	Precompile = 2,
	EPSOPrecompilationBatchMode_MAX = 3
};

// ScriptStruct EmbarkPSOCache.PSOTimingStats
// Size: 0x08 (Inherited: 0x00)
struct FPSOTimingStats {
	float TimeSinceLastWaitingForPSO; // 0x00(0x04)
	float TimeSinceLastCompilingCachedPSO; // 0x04(0x04)
};

