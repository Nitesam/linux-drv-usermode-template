// Class ComponentAssembler.ComponentAssemblerComponentBase
// Size: 0x430 (Inherited: 0x3c0)
struct UComponentAssemblerComponentBase : USceneComponent {
	struct UComponentAssembler_ApprovedClasses* ApprovedClasses; // 0x3c0(0x08)
	enum class EAssemblyNetworkMode NetworkMode; // 0x3c8(0x04)
	enum class EAttachmentRule AttachmentRule; // 0x3cc(0x01)
	bool bReplaceAssemblerWithAssembly; // 0x3cd(0x01)
	char pad_3ce[0x62]; // 0x3ce(0x62)

	struct UObject* GetAssemblyType(); // Function ComponentAssembler.ComponentAssemblerComponentBase.GetAssemblyType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50bfcc0
	struct FName GetAssemblyPropertyName(); // Function ComponentAssembler.ComponentAssemblerComponentBase.GetAssemblyPropertyName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50c1b80
	void DisassembleComponents(); // Function ComponentAssembler.ComponentAssemblerComponentBase.DisassembleComponents // (Final|Native|Public|BlueprintCallable) // @ game+0x2ffdb70
	void AssembleComponents(); // Function ComponentAssembler.ComponentAssemblerComponentBase.AssembleComponents // (Final|Native|Public|BlueprintCallable) // @ game+0x36c1b60
};

// Class ComponentAssembler.DefaultComponentAssemblerComponent
// Size: 0x430 (Inherited: 0x430)
struct UDefaultComponentAssemblerComponent : UComponentAssemblerComponentBase {
	struct AActor* Assembly; // 0x428(0x08)
};

// Class ComponentAssembler.ComponentAssembler_ApprovedClasses
// Size: 0xe0 (Inherited: 0xa0)
struct UComponentAssembler_ApprovedClasses : UObject {
	struct TArray<struct UActorComponent*> ApprovedComponentBaseTypes_Server; // 0x98(0x10)
	struct TArray<struct UActorComponent*> ApprovedComponentBaseTypes_Client; // 0xa8(0x10)
	struct TArray<struct UActorComponent*> Native_ApprovedComponentBaseTypes_Server; // 0xb8(0x10)
	struct TArray<struct UActorComponent*> Native_ApprovedComponentBaseTypes_Client; // 0xc8(0x10)
};

