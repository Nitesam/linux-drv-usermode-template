// ScriptStruct SMExtendedRuntime.SMTextSerializer
// Size: 0x18 (Inherited: 0x00)
struct FSMTextSerializer {
	struct FName ToTextDynamicFunctionName; // 0x00(0x08)
	struct TArray<struct FName> ToTextFunctionNames; // 0x08(0x10)
};

// ScriptStruct SMExtendedRuntime.SMTextGraphProperty_Runtime
// Size: 0x78 (Inherited: 0x48)
struct FSMTextGraphProperty_Runtime : FSMGraphProperty_Base_Runtime {
	struct FText Result; // 0x48(0x18)
	struct FSMTextSerializer TextSerializer; // 0x60(0x18)
};

// ScriptStruct SMExtendedRuntime.SMTextGraphProperty
// Size: 0x1340 (Inherited: 0x108)
struct FSMTextGraphProperty : FSMGraphProperty_Base {
	struct FText Result; // 0x108(0x18)
	struct FSMTextSerializer TextSerializer; // 0x120(0x18)
	char pad_138[0x8]; // 0x138(0x08)
	struct FSMTextNodeWidgetInfo WidgetInfo; // 0x140(0x11e0)
	struct FSMTextNodeRichTextInfo RichTextInfo; // 0x1320(0x18)
	char pad_1338[0x8]; // 0x1338(0x08)
};

// ScriptStruct SMExtendedRuntime.SMTextNodeRichTextInfo
// Size: 0x18 (Inherited: 0x00)
struct FSMTextNodeRichTextInfo {
	struct UDataTable* RichTextStyleSet; // 0x00(0x08)
	struct TArray<struct URichTextBlockDecorator*> RichTextDecoratorClasses; // 0x08(0x10)
};

// ScriptStruct SMExtendedRuntime.SMTextNodeWidgetInfo
// Size: 0x11e0 (Inherited: 0x01)
struct FSMTextNodeWidgetInfo : FSMTextDisplayWidgetInfo {
	struct FInlineEditableTextBlockStyle EditableTextStyle; // 0x00(0x11d0)
	float WrapTextAt; // 0x11d0(0x04)
	char pad_11d5[0xb]; // 0x11d5(0x0b)
};

