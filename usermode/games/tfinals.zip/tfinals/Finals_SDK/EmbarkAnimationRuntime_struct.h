// Enum EmbarkAnimationRuntime.EPSMExpressionType
enum class EPSMExpressionType : uint8_t {
	ET_INVALID = 0,
	ET_IntMatch = 1,
	ET_IntRange = 2,
	ET_FloatRange = 3,
	ET_GameplayTagMatch = 4,
	ET_BoolMatch = 5,
	ET_EnumMatch = 6,
	ET_MAX = 7
};

// Enum EmbarkAnimationRuntime.EAuxRootBakeOptions
enum class EAuxRootBakeOptions : uint8_t {
	UseAnimationNormal = 0,
	UseNextAnimationFirstFrame_InWorld = 1,
	UsePreviousAnimationLastFrame_InWorld = 2,
	EAuxRootBakeOptions_MAX = 3
};

// Enum EmbarkAnimationRuntime.EPlantedStatus
enum class EPlantedStatus : uint8_t {
	Planted = 0,
	Unplanted = 1,
	Replanting = 2,
	PlantedThisFrame = 3,
	UnplantedThisFrame = 4,
	StartedReplantingThisFrame = 5,
	WentFromReplantingToUnplanted = 6,
	EPlantedStatus_MAX = 7
};

// Enum EmbarkAnimationRuntime.EUnplantStatus
enum class EUnplantStatus : uint8_t {
	PlantingAllowed = 0,
	AnimWantsToUnplant = 1,
	SystemWantsToUnplant = 2,
	EUnplantStatus_MAX = 3
};

// ScriptStruct EmbarkAnimationRuntime.TagMapping
// Size: 0x28 (Inherited: 0x00)
struct FTagMapping {
	struct FGameplayTagContainer TagContainer; // 0x00(0x20)
	bool bExactMatching; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_BlendListByGameplayTag
// Size: 0xb0 (Inherited: 0x80)
struct FAnimNode_BlendListByGameplayTag : FAnimNode_BlendListBase {
	struct FGameplayTagContainer GameplayTagContainerInput; // 0x80(0x20)
	struct TArray<struct FTagMapping> TagToPoseIndexMappings; // 0xa0(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_CurveMask
// Size: 0x70 (Inherited: 0x48)
struct FAnimNode_CurveMask : FAnimNode_Base {
	struct FPoseLink InputPose; // 0x48(0x10)
	struct TArray<struct FName> CurveNamesToMaskOut; // 0x58(0x10)
	bool bEnableMasking; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// ScriptStruct EmbarkAnimationRuntime.CurveNameToMaskOutData
// Size: 0x10 (Inherited: 0x00)
struct FCurveNameToMaskOutData {
	struct FName CurveName; // 0x00(0x08)
	float DisabledCurveValue; // 0x08(0x04)
	bool bNoBlend; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_CurveMask_Blendable
// Size: 0x78 (Inherited: 0x48)
struct FAnimNode_CurveMask_Blendable : FAnimNode_Base {
	struct FPoseLink InputPose; // 0x48(0x10)
	struct TArray<struct FCurveNameToMaskOutData> CurveNamesToMaskOut; // 0x58(0x10)
	bool bEnableMasking; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float BlendDuration; // 0x6c(0x04)
	char pad_70[0x8]; // 0x70(0x08)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_DynamicPoseBlendSpace
// Size: 0x88 (Inherited: 0x48)
struct FAnimNode_DynamicPoseBlendSpace : FAnimNode_Base {
	struct TArray<struct FPoseLink> InputPoses; // 0x48(0x10)
	float X; // 0x58(0x04)
	float Y; // 0x5c(0x04)
	struct UBlendSpace* TemplateBlendSpace; // 0x60(0x08)
	char pad_68[0x20]; // 0x68(0x20)
};

// ScriptStruct EmbarkAnimationRuntime.BlendingOutSequenceData
// Size: 0x40 (Inherited: 0x00)
struct FBlendingOutSequenceData {
	struct UAnimSequenceBase* SequenceBase; // 0x00(0x08)
	char pad_8[0x38]; // 0x08(0x38)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_EmbarkSequencePlayer
// Size: 0xb0 (Inherited: 0x80)
struct FAnimNode_EmbarkSequencePlayer : FAnimNode_SequencePlayer {
	struct TArray<struct FBlendingOutSequenceData> ActiveBlendingOutSequences; // 0x80(0x10)
	float BlendDuration; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	enum class EAlphaBlendOption BlendType; // 0x98(0x01)
	char pad_99[0x1]; // 0x99(0x01)
	bool bResetTimeWhenChangingSequence; // 0x9a(0x01)
	bool bDriveWithExternalTime; // 0x9b(0x01)
	float ExternalTime; // 0x9c(0x04)
	char pad_a0[0x10]; // 0xa0(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.LODGate_LODDriver
// Size: 0x38 (Inherited: 0x00)
struct FLODGate_LODDriver {
	struct FName LodGateStateMachineID; // 0x00(0x08)
	struct TArray<struct FName> LodGateStateNames; // 0x08(0x10)
	struct TWeakObjectPtr<struct UAnimInstance> DriverInstance; // 0x18(0x08)
	char pad_20[0x10]; // 0x20(0x10)
	int32_t StateMachineNodeIndex; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.LODGate_DriverCollection
// Size: 0x20 (Inherited: 0x00)
struct FLODGate_DriverCollection {
	struct TArray<struct FLODGate_LODDriver> LODDrivers; // 0x00(0x10)
	struct TArray<struct FAnimInstanceProxy> TransitionProxies; // 0x10(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.LinkedAnimGraphPath
// Size: 0x10 (Inherited: 0x00)
struct FLinkedAnimGraphPath {
	struct TArray<struct FName> Path; // 0x00(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_LODGate
// Size: 0xe8 (Inherited: 0x48)
struct FAnimNode_LODGate : FAnimNode_Base {
	struct FPoseLink InputPose; // 0x48(0x10)
	int32_t CollectionToUse; // 0x58(0x04)
	char pad_5c[0x4]; // 0x5c(0x04)
	struct TArray<struct FLODGate_DriverCollection> LODDriverCollections; // 0x60(0x10)
	bool bUsePassthroughLinkedAnimGraphInPose; // 0x70(0x01)
	char pad_71[0x67]; // 0x71(0x67)
	struct TArray<struct FLinkedAnimGraphPath> LinkedAnimGraphPaths; // 0xd8(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.BoneWeightsAssetBlendArrayData
// Size: 0x58 (Inherited: 0x00)
struct FBoneWeightsAssetBlendArrayData {
	struct TArray<struct UBoneWeightsAsset*> BoneWeightsAssets; // 0x00(0x10)
	char pad_10[0x30]; // 0x10(0x30)
	float BlendDuration; // 0x40(0x04)
	char pad_44[0x14]; // 0x44(0x14)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_PoseMask
// Size: 0x120 (Inherited: 0x48)
struct FAnimNode_PoseMask : FAnimNode_Base {
	struct FPoseLink InputPose; // 0x48(0x10)
	struct UBoneWeightsAsset* BoneWeightsAsset; // 0x58(0x08)
	int32_t SelectedAssetIndex; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct FBoneWeightsAssetBlendArrayData BWABlendArrayData; // 0x68(0x58)
	char pad_c0[0x60]; // 0xc0(0x60)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_PoseMaskBlendArray
// Size: 0x100 (Inherited: 0x48)
struct FAnimNode_PoseMaskBlendArray : FAnimNode_Base {
	struct FPoseLink InputPose; // 0x48(0x10)
	struct UBoneWeightsBlendArrayAsset* BoneWeightsBlendArrayAsset; // 0x58(0x08)
	float Input; // 0x60(0x04)
	char pad_64[0x9c]; // 0x64(0x9c)
};

// ScriptStruct EmbarkAnimationRuntime.ReferencedInput
// Size: 0x08 (Inherited: 0x00)
struct FReferencedInput {
	enum class EPSMExpressionType InputType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t InternalArrayIndex; // 0x04(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.FloatRangeValues
// Size: 0x08 (Inherited: 0x00)
struct FFloatRangeValues {
	float MinValue; // 0x00(0x04)
	float MaxValue; // 0x04(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.FloatRangeEvaluator
// Size: 0x18 (Inherited: 0x00)
struct FFloatRangeEvaluator {
	struct FReferencedInput ReferencedInput; // 0x00(0x08)
	struct TArray<struct FFloatRangeValues> PerPoseValues; // 0x08(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.IntValueRange
// Size: 0x08 (Inherited: 0x00)
struct FIntValueRange {
	int32_t MinValue; // 0x00(0x04)
	int32_t MaxValue; // 0x04(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.IntRangeEvaluator
// Size: 0x18 (Inherited: 0x00)
struct FIntRangeEvaluator {
	struct FReferencedInput ReferencedInput; // 0x00(0x08)
	struct TArray<struct FIntValueRange> PerPoseValues; // 0x08(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.BoolMatchingEvaluator
// Size: 0x18 (Inherited: 0x00)
struct FBoolMatchingEvaluator {
	struct FReferencedInput ReferencedInput; // 0x00(0x08)
	struct TArray<bool> PerPoseValue; // 0x08(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.GameplayTagEvalInfo
// Size: 0x28 (Inherited: 0x00)
struct FGameplayTagEvalInfo {
	struct FGameplayTagContainer TagContainer; // 0x00(0x20)
	bool bExactMatch; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EmbarkAnimationRuntime.GameplayTagMatchingEvaluator
// Size: 0x28 (Inherited: 0x00)
struct FGameplayTagMatchingEvaluator {
	struct FReferencedInput ReferencedInput; // 0x00(0x08)
	struct TArray<struct FGameplayTagContainer> PerPoseValue; // 0x08(0x10)
	struct TArray<struct FGameplayTagEvalInfo> PerPoseValueInfo; // 0x18(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.IntMatchingEvaluator
// Size: 0x18 (Inherited: 0x00)
struct FIntMatchingEvaluator {
	struct FReferencedInput ReferencedInput; // 0x00(0x08)
	struct TArray<int32_t> PerPoseValue; // 0x08(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.MatchingEnumEntries
// Size: 0x10 (Inherited: 0x00)
struct FMatchingEnumEntries {
	struct TArray<char> EnumValues; // 0x00(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.EnumMatchingEvaluator
// Size: 0x18 (Inherited: 0x00)
struct FEnumMatchingEvaluator {
	struct FReferencedInput ReferencedInput; // 0x00(0x08)
	struct TArray<struct FMatchingEnumEntries> PerPoseValues; // 0x08(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_PoseSelectionMatrix
// Size: 0x178 (Inherited: 0x48)
struct FAnimNode_PoseSelectionMatrix : FAnimNode_Base {
	struct TArray<struct FPoseLink> InputPoses; // 0x48(0x10)
	struct TArray<struct FName> InputPosesNames; // 0x58(0x10)
	float BlendTime; // 0x68(0x04)
	enum class EAlphaBlendOption BlendType; // 0x6c(0x01)
	char pad_6d[0x3]; // 0x6d(0x03)
	struct UCurveFloat* CustomBlendCurve; // 0x70(0x08)
	bool bChooseOnce; // 0x78(0x01)
	bool bResetChildOnActivation; // 0x79(0x01)
	char pad_7a[0x6]; // 0x7a(0x06)
	struct TArray<int32_t> IntInputs; // 0x80(0x10)
	struct TArray<float> FloatInputs; // 0x90(0x10)
	struct TArray<bool> BoolInputs; // 0xa0(0x10)
	struct TArray<struct FGameplayTagContainer> TagInputs; // 0xb0(0x10)
	struct TArray<char> EnumInputs; // 0xc0(0x10)
	struct TArray<struct FFloatRangeEvaluator> FloatRangeEvaluators; // 0xd0(0x10)
	struct TArray<struct FBoolMatchingEvaluator> BoolMatchingEvaluators; // 0xe0(0x10)
	struct TArray<struct FIntRangeEvaluator> IntRangeEvaluators; // 0xf0(0x10)
	struct TArray<struct FIntMatchingEvaluator> IntMatchingEvaluators; // 0x100(0x10)
	struct TArray<struct FGameplayTagMatchingEvaluator> GameplayTagMatchingEvaluators; // 0x110(0x10)
	struct TArray<struct FEnumMatchingEvaluator> EnumMatchingEvaluators; // 0x120(0x10)
	char pad_130[0x48]; // 0x130(0x48)
};

// ScriptStruct EmbarkAnimationRuntime.CenterOfMassDynamicsConfig
// Size: 0x18 (Inherited: 0x00)
struct FCenterOfMassDynamicsConfig {
	float LeanSmoothness; // 0x00(0x04)
	float LeanFactor; // 0x04(0x04)
	float DipSmoothness; // 0x08(0x04)
	float DipFactor; // 0x0c(0x04)
	float LegLiftSmoothness; // 0x10(0x04)
	float LegLiftFactor; // 0x14(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_ProceduralCreatureCrawl
// Size: 0x610 (Inherited: 0x48)
struct FAnimNode_ProceduralCreatureCrawl : FAnimNode_Base {
	struct FComponentSpacePoseLink ComponentPose; // 0x48(0x10)
	float ComponentMaxSpeed; // 0x58(0x04)
	float ComponentMinMovingSpeed; // 0x5c(0x04)
	struct FBoneReference RootBone; // 0x60(0x10)
	struct FSecondOrderDynamicParameters RootLocationParams; // 0x70(0x0c)
	struct FSecondOrderDynamicParameters RootForwardParams; // 0x7c(0x0c)
	struct FBoneReference CenterOfMassBone; // 0x88(0x10)
	float MinDipHeight; // 0x98(0x04)
	float LeanTargetHeight; // 0x9c(0x04)
	struct FCenterOfMassDynamicsConfig CenterOfMassMovingParams; // 0xa0(0x18)
	struct FCenterOfMassDynamicsConfig CenterOfMassStoppingParams; // 0xb8(0x18)
	struct TArray<struct FProceduralLeg> Legs; // 0xd0(0x10)
	struct FProceduralStrideConfig StrideParams; // 0xe0(0x78)
	char pad_158[0x4b8]; // 0x158(0x4b8)
};

// ScriptStruct EmbarkAnimationRuntime.ProceduralStrideConfig
// Size: 0x78 (Inherited: 0x00)
struct FProceduralStrideConfig {
	float MinCorrectionalStepPlantedTime; // 0x00(0x04)
	float MinCorrectionalStepDistance; // 0x04(0x04)
	float StepOnDistance; // 0x08(0x04)
	float StepOnLegExtension; // 0x0c(0x04)
	float ForceStepOnLegExtension; // 0x10(0x04)
	float PlantOnLegExtension; // 0x14(0x04)
	float ForceStepOnBodyVelocityDifference; // 0x18(0x04)
	float OnVelocitySmoothness; // 0x1c(0x04)
	float ForwardOnVelocityFactor; // 0x20(0x04)
	float SidesOnVelocityFactor; // 0x24(0x04)
	float OnAccelerationSmoothness; // 0x28(0x04)
	float ForwardOnAccelerationFactor; // 0x2c(0x04)
	float BackwardOnAccelerationFactor; // 0x30(0x04)
	float SidesOnAccelerationFactor; // 0x34(0x04)
	float RequiredSupportLegStepProgress; // 0x38(0x04)
	float StepTime; // 0x3c(0x04)
	float ForcedStepTime; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FVector2D FootStepCircularTrajectory; // 0x48(0x10)
	float PoleVectorOnAccelerationSmoothness; // 0x58(0x04)
	float FrontLegsPullOnAcceleration; // 0x5c(0x04)
	float BackLegsPushOnAcceleration; // 0x60(0x04)
	float SideLegsTiltOnAcceleration; // 0x64(0x04)
	struct FVector2D PoleVectorStepCircularTrajectory; // 0x68(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.ProceduralLeg
// Size: 0x108 (Inherited: 0x00)
struct FProceduralLeg {
	struct FBoneReference StartBone; // 0x00(0x10)
	struct FBoneReference EndBone; // 0x10(0x10)
	struct FBoneReference EndEffector; // 0x20(0x10)
	struct FBoneReference PoleVector; // 0x30(0x10)
	struct TArray<struct FBoneReference> EndEffectorsOfSupportingLegs; // 0x40(0x10)
	char pad_50[0xb8]; // 0x50(0xb8)
};

// ScriptStruct EmbarkAnimationRuntime.AnimNode_ProceduralLegCrawl
// Size: 0x278 (Inherited: 0x48)
struct FAnimNode_ProceduralLegCrawl : FAnimNode_Base {
	struct FComponentSpacePoseLink ComponentPose; // 0x48(0x10)
	struct FVector GroundOrigin; // 0x58(0x18)
	struct FVector GroundUpDirection; // 0x70(0x18)
	struct FVector CurrentVelocity; // 0x88(0x18)
	struct FVector CurrentDesiredVelocity; // 0xa0(0x18)
	float MaxDesiredSpeed; // 0xb8(0x04)
	struct FBoneReference GroundAlignmentBone; // 0xbc(0x10)
	char pad_cc[0x4]; // 0xcc(0x04)
	struct TArray<struct FProceduralLeg> Legs; // 0xd0(0x10)
	struct FProceduralStrideConfig StrideParams; // 0xe0(0x78)
	char pad_158[0x120]; // 0x158(0x120)
};

// ScriptStruct EmbarkAnimationRuntime.MixerEntryEditorModifications
// Size: 0x70 (Inherited: 0x00)
struct FMixerEntryEditorModifications {
	struct FTransform RootOffset; // 0x00(0x60)
	enum class EAuxRootBakeOptions AuxRootBakeOption; // 0x60(0x01)
	char pad_61[0xf]; // 0x61(0x0f)
};

// ScriptStruct EmbarkAnimationRuntime.SequenceMixerSettings
// Size: 0x10 (Inherited: 0x00)
struct FSequenceMixerSettings {
	struct FName RootBoneName; // 0x00(0x08)
	struct FName AuxRootBoneName; // 0x08(0x08)
};

// ScriptStruct EmbarkAnimationRuntime.SequenceMixerEntry
// Size: 0x10 (Inherited: 0x00)
struct FSequenceMixerEntry {
	float StartTime; // 0x00(0x04)
	float Length; // 0x04(0x04)
	float TrimStart; // 0x08(0x04)
	float TrimEnd; // 0x0c(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.AnimSubsystem_CompiledPinExpressions
// Size: 0x08 (Inherited: 0x08)
struct FAnimSubsystem_CompiledPinExpressions : FAnimSubsystem {
};

// ScriptStruct EmbarkAnimationRuntime.BoneWeightsBlendArrayEntry
// Size: 0x10 (Inherited: 0x00)
struct FBoneWeightsBlendArrayEntry {
	struct UBoneWeightsAsset* BoneWeightsAsset; // 0x00(0x08)
	float EntryPlacementValue; // 0x08(0x04)
	int32_t IndexIntoUniqueAssetArray; // 0x0c(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkAnimInstanceProxy_Base
// Size: 0x760 (Inherited: 0x700)
struct FEmbarkAnimInstanceProxy_Base : FAnimInstanceProxy {
	char pad_700[0x60]; // 0x700(0x60)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkAnimStateUpdateRegistrationData
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkAnimStateUpdateRegistrationData {
	struct UEmbarkAnimStateUpdaterComponent* StateUpdaterComponent; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkAim
// Size: 0x1d0 (Inherited: 0x160)
struct FRigUnit_EmbarkAim : FRigUnit_HighlevelBaseMutable {
	struct FVector Point; // 0x160(0x18)
	struct FVector Target; // 0x178(0x18)
	struct FVector UpTarget; // 0x190(0x18)
	bool bDebugDrawing; // 0x1a8(0x01)
	char pad_1a9[0x7]; // 0x1a9(0x07)
	struct FQuat Result; // 0x1b0(0x20)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkSphericalAim
// Size: 0x200 (Inherited: 0x160)
struct FRigUnit_EmbarkSphericalAim : FRigUnit_HighlevelBaseMutable {
	struct FTransform Origin; // 0x160(0x60)
	struct FVector Target; // 0x1c0(0x18)
	bool bDebugDrawing; // 0x1d8(0x01)
	char pad_1d9[0x7]; // 0x1d9(0x07)
	struct FQuat Result; // 0x1e0(0x20)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkAntiHyperExtension_IKChainUserData
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkAntiHyperExtension_IKChainUserData {
	struct TArray<struct FRigElementKey> ItemChain; // 0x00(0x10)
	struct FRigElementKey Effector; // 0x10(0x0c)
	float Priority; // 0x1c(0x04)
	float IKWeight; // 0x20(0x04)
	float HyperExtensionEasingStart; // 0x24(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkAntiHyperExtension_IKChainsWorker
// Size: 0x238 (Inherited: 0x00)
struct FEmbarkAntiHyperExtension_IKChainsWorker {
	char pad_0[0x238]; // 0x00(0x238)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkAntiHyperExtension
// Size: 0x4c0 (Inherited: 0x160)
struct FRigUnit_EmbarkAntiHyperExtension : FRigUnit_HighlevelBaseMutable {
	struct FRuntimeFloatCurve DistanceCurve; // 0x160(0x88)
	float SmoothChainSwitchWeight; // 0x1e8(0x04)
	float SmoothChainSwitchExponent; // 0x1ec(0x04)
	struct TArray<struct FEmbarkAntiHyperExtension_IKChainUserData> ChainsUserData; // 0x1f0(0x10)
	struct FEmbarkAntiHyperExtension_IKChainsWorker ChainsWorker; // 0x200(0x238)
	bool bEnableDebugDrawing; // 0x438(0x01)
	char pad_439[0x7]; // 0x439(0x07)
	struct FTransform DebugDrawingWorldOffset; // 0x440(0x60)
	struct FVector DeltaForIKTargets; // 0x4a0(0x18)
	char pad_4b8[0x8]; // 0x4b8(0x08)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkCircleIK_DebugSettings
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkCircleIK_DebugSettings {
	bool bEnabled; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FLinearColor ColorTint; // 0x04(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.StartMidEndIndexes
// Size: 0x0c (Inherited: 0x00)
struct FStartMidEndIndexes {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkCircleIK_SolveParams
// Size: 0xa0 (Inherited: 0x00)
struct FEmbarkCircleIK_SolveParams {
	struct FVector IKStartLocation; // 0x00(0x18)
	struct FVector IKPoleVectorLocation; // 0x18(0x18)
	struct FTransform IKEndTransform; // 0x30(0x60)
	float MaxStretchDistance; // 0x90(0x04)
	float Limb1Length; // 0x94(0x04)
	float Limb2Length; // 0x98(0x04)
	char pad_9c[0x4]; // 0x9c(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.StartMidEndTransforms
// Size: 0x120 (Inherited: 0x00)
struct FStartMidEndTransforms {
	char pad_0[0x120]; // 0x00(0x120)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkCircleIK
// Size: 0x380 (Inherited: 0x160)
struct FRigUnit_EmbarkCircleIK : FRigUnit_HighlevelBaseMutable {
	struct FName StartBone; // 0x160(0x08)
	struct FName MidBone; // 0x168(0x08)
	struct FName EndBone; // 0x170(0x08)
	char pad_178[0x8]; // 0x178(0x08)
	struct FEmbarkCircleIK_SolveParams IKSolveParams; // 0x180(0xa0)
	float Weight; // 0x220(0x04)
	struct FEmbarkCircleIK_DebugSettings DebugSettings; // 0x224(0x14)
	struct FStartMidEndIndexes CachedBoneIndexes; // 0x238(0x0c)
	char pad_244[0xc]; // 0x244(0x0c)
	struct FStartMidEndTransforms InitialBoneOffsets; // 0x250(0x120)
	bool bNeedsInit; // 0x370(0x01)
	char pad_371[0xf]; // 0x371(0x0f)
};

// ScriptStruct EmbarkAnimationRuntime.FootPlantBoundaries
// Size: 0x1c (Inherited: 0x00)
struct FFootPlantBoundaries {
	float AllowPlantVelocityThreshold; // 0x00(0x04)
	float AllowPlantDistanceToAnimThreshold; // 0x04(0x04)
	float AllowReplantDistanceToAnimThreshold; // 0x08(0x04)
	float UnplantBlendoutDuration; // 0x0c(0x04)
	float MaxSystemHyperExtensionDistance; // 0x10(0x04)
	float MaxSystemPlantDistance; // 0x14(0x04)
	bool bForceUnplanted; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkFootPlanting_FootState
// Size: 0xf0 (Inherited: 0x00)
struct FEmbarkFootPlanting_FootState {
	struct FTransform FloorTransform; // 0x00(0x60)
	struct FTransform BlendedFootTransform; // 0x60(0x60)
	enum class EPlantedStatus PlantedStatus; // 0xc0(0x01)
	char pad_c1[0x3]; // 0xc1(0x03)
	float CurrentBlendoutTime; // 0xc4(0x04)
	float FootVelocity; // 0xc8(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)
	struct FVector CachedToeLocationInFloorSpace; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// ScriptStruct EmbarkAnimationRuntime.LegIndexes
// Size: 0x0c (Inherited: 0x00)
struct FLegIndexes {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkFootPlanting
// Size: 0x370 (Inherited: 0x160)
struct FRigUnit_EmbarkFootPlanting : FRigUnit_HighlevelBaseMutable {
	struct FName HipBone; // 0x160(0x08)
	struct FName FootBone; // 0x168(0x08)
	struct FName ToeBone; // 0x170(0x08)
	float FootVelocityCurve; // 0x178(0x04)
	bool bSpaceSwitchToNewFloor; // 0x17c(0x01)
	bool bResetFootplantStates; // 0x17d(0x01)
	char pad_17e[0x2]; // 0x17e(0x02)
	struct FTransform FloorTransform; // 0x180(0x60)
	struct FFootPlantBoundaries Boundaries; // 0x1e0(0x1c)
	char pad_1fc[0x4]; // 0x1fc(0x04)
	struct FTransform FootIKTransform; // 0x200(0x60)
	float PlantStatus; // 0x260(0x04)
	struct FLegIndexes CachedLegIndexes; // 0x264(0x0c)
	struct FEmbarkFootPlanting_FootState FootState; // 0x270(0xf0)
	bool bNeedsInit; // 0x360(0x01)
	char pad_361[0xf]; // 0x361(0x0f)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkMultiLinkIK_ChainItem
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkMultiLinkIK_ChainItem {
	struct FRigElementKey Item; // 0x00(0x0c)
	float TransformWeight; // 0x0c(0x04)
	float Mass; // 0x10(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkMultiLinkIK
// Size: 0x200 (Inherited: 0x160)
struct FRigUnit_EmbarkMultiLinkIK : FRigUnit_HighlevelBaseMutable {
	struct FRigElementKey ChainStart; // 0x160(0x0c)
	struct FRigElementKey ChainMid; // 0x16c(0x0c)
	struct FRigElementKey ChainEnd; // 0x178(0x0c)
	char pad_184[0x4]; // 0x184(0x04)
	struct TArray<struct FEmbarkMultiLinkIK_ChainItem> ChainLinks; // 0x188(0x10)
	struct FRigElementKey EndEffector; // 0x198(0x0c)
	struct FRigElementKey PoleVector; // 0x1a4(0x0c)
	float DistanceSolvingPrecision; // 0x1b0(0x04)
	int32_t MaxDistanceSolvingIterations; // 0x1b4(0x04)
	bool bFlipForward; // 0x1b8(0x01)
	bool bReevaluateDistances; // 0x1b9(0x01)
	char pad_1ba[0x6]; // 0x1ba(0x06)
	struct TArray<struct FVector> SolvedLocations; // 0x1c0(0x10)
	struct TArray<struct FVector> SolvedUpDirections; // 0x1d0(0x10)
	struct TArray<struct FTransform> UnsolvedTransforms; // 0x1e0(0x10)
	struct TArray<float> JointDistances; // 0x1f0(0x10)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkSOD_DebugSettings
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkSOD_DebugSettings {
	bool bEnabled; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float LineThickness; // 0x04(0x04)
	float GraphSize; // 0x08(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.EmbarkSOD_DebugGraph
// Size: 0xe5c (Inherited: 0x00)
struct FEmbarkSOD_DebugGraph {
	char pad_0[0xe5c]; // 0x00(0xe5c)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkSOD
// Size: 0x1120 (Inherited: 0x160)
struct FRigUnit_EmbarkSOD : FRigUnit_HighlevelBaseMutable {
	float Frequency; // 0x160(0x04)
	float Damping; // 0x164(0x04)
	float Response; // 0x168(0x04)
	float IntermediateSpeed; // 0x16c(0x04)
	float PastIntermediateSpeed; // 0x170(0x04)
	bool HasIntermediate; // 0x174(0x01)
	char pad_175[0x3]; // 0x175(0x03)
	struct FVector ClampIntermedatePosiviteAxes; // 0x178(0x18)
	struct FVector ClampIntermedateNegativeAxes; // 0x190(0x18)
	struct FVector Target; // 0x1a8(0x18)
	struct FVector IntermediateTarget; // 0x1c0(0x18)
	struct FEmbarkSOD_DebugSettings DebugSettings; // 0x1d8(0x0c)
	struct FEmbarkSOD_DebugGraph DebugGraph; // 0x1e4(0xe5c)
	struct FVector Result; // 0x1040(0x18)
	struct FVector Velocity; // 0x1058(0x18)
	struct FVector Acceleration; // 0x1070(0x18)
	struct FSODSpringVector SODVector; // 0x1088(0x88)
	bool bNeedsInit; // 0x1110(0x01)
	char pad_1111[0xf]; // 0x1111(0x0f)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkVectorDeltaAimBones_GlobalOrientation
// Size: 0x30 (Inherited: 0x00)
struct FRigUnit_EmbarkVectorDeltaAimBones_GlobalOrientation {
	struct FVector Forward; // 0x00(0x18)
	struct FVector Up; // 0x18(0x18)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkVectorDeltaAimBones_BoneSettings
// Size: 0x0c (Inherited: 0x00)
struct FRigUnit_EmbarkVectorDeltaAimBones_BoneSettings {
	struct FName Name; // 0x00(0x08)
	float Weight; // 0x08(0x04)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkVectorDeltaAimBones_CachedBones
// Size: 0x20 (Inherited: 0x00)
struct FRigUnit_EmbarkVectorDeltaAimBones_CachedBones {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct EmbarkAnimationRuntime.RigUnit_EmbarkVectorDeltaAimBones
// Size: 0x220 (Inherited: 0x160)
struct FRigUnit_EmbarkVectorDeltaAimBones : FRigUnit_HighlevelBaseMutable {
	float MaxAngle; // 0x160(0x04)
	bool bSmoothBlendOffWhenOutsideMaxAngle; // 0x164(0x01)
	char pad_165[0x3]; // 0x165(0x03)
	struct FVector ReferencePoint; // 0x168(0x18)
	struct FVector AnimatedTarget; // 0x180(0x18)
	struct FVector ProceduralTarget; // 0x198(0x18)
	float Weight; // 0x1b0(0x04)
	char pad_1b4[0x4]; // 0x1b4(0x04)
	struct FRigUnit_EmbarkVectorDeltaAimBones_GlobalOrientation GlobalOrientation; // 0x1b8(0x30)
	struct TArray<struct FRigUnit_EmbarkVectorDeltaAimBones_BoneSettings> Bones; // 0x1e8(0x10)
	struct FRigUnit_EmbarkVectorDeltaAimBones_CachedBones CachedBones; // 0x1f8(0x20)
	char pad_218[0x8]; // 0x218(0x08)
};

