// Class EmbarkOptionSystem.EmbarkOptionBase
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkOptionBase : UObject {
	struct FGameplayTag OptionTag; // 0x98(0x08)
	bool bRestartRequired; // 0xa0(0x01)
	char pad_a9[0x17]; // 0xa9(0x17)

	void UnbindValidator(struct UObject* Owner); // Function EmbarkOptionSystem.EmbarkOptionBase.UnbindValidator // (Native|Event|Public|BlueprintEvent) // @ game+0x48db230
	struct FString Store(); // Function EmbarkOptionSystem.EmbarkOptionBase.Store // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48e7a80
	void SendOptionChangeTelemetry(struct FString OldValue, struct FString NewValue); // Function EmbarkOptionSystem.EmbarkOptionBase.SendOptionChangeTelemetry // (Native|Event|Public|BlueprintEvent) // @ game+0x48ddc60
	void Restore(struct FString String); // Function EmbarkOptionSystem.EmbarkOptionBase.Restore // (Native|Event|Public|BlueprintEvent) // @ game+0x48d0f10
	void ResetToPreviousValue(struct FString InValue); // Function EmbarkOptionSystem.EmbarkOptionBase.ResetToPreviousValue // (Native|Event|Public|BlueprintEvent) // @ game+0x48cfc20
	void ResetToDefault(); // Function EmbarkOptionSystem.EmbarkOptionBase.ResetToDefault // (Native|Event|Public|BlueprintEvent) // @ game+0x2d0aea0
	void RegisterValidator(struct UObject* Owner, struct FName FunctionName); // Function EmbarkOptionSystem.EmbarkOptionBase.RegisterValidator // (Native|Event|Public|BlueprintEvent) // @ game+0x48cd800
	void PreSaveData(); // Function EmbarkOptionSystem.EmbarkOptionBase.PreSaveData // (Native|Event|Public|BlueprintEvent) // @ game+0x2f78920
	void NotifyOnExternalEvent(enum class EEmbarkOptionExternalEvent Event); // Function EmbarkOptionSystem.EmbarkOptionBase.NotifyOnExternalEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x2522b30
	bool IsDefault(); // Function EmbarkOptionSystem.EmbarkOptionBase.IsDefault // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x15c6d40
	bool IsAvailable(); // Function EmbarkOptionSystem.EmbarkOptionBase.IsAvailable // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2cd3930
	void Initialize(struct FString InValue); // Function EmbarkOptionSystem.EmbarkOptionBase.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x48ebd70
	bool CanChange(); // Function EmbarkOptionSystem.EmbarkOptionBase.CanChange // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d40b0
	void BroadcastOnOptionChangedInteral(); // Function EmbarkOptionSystem.EmbarkOptionBase.BroadcastOnOptionChangedInteral // (Native|Event|Public|BlueprintEvent) // @ game+0x17031b0
};

// Class EmbarkOptionSystem.IEmbarkOptionBool
// Size: 0xd0 (Inherited: 0xc0)
struct UIEmbarkOptionBool : UEmbarkOptionBase {
	struct FMulticastInlineDelegate OnOptionChanged; // 0xc0(0x10)

	void SetValue(bool bNewValue); // Function EmbarkOptionSystem.IEmbarkOptionBool.SetValue // (Native|Event|Public|BlueprintEvent) // @ game+0x48d79b0
	bool GetValue(); // Function EmbarkOptionSystem.IEmbarkOptionBool.GetValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3235920
};

// Class EmbarkOptionSystem.EmbarkOptionBool
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionBool : UIEmbarkOptionBool {
	bool bDefaultValue; // 0xd0(0x01)
	char pad_d1[0x1f]; // 0xd1(0x1f)
};

// Class EmbarkOptionSystem.EmbarkOptionConsoleBool
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionConsoleBool : UIEmbarkOptionBool {
	struct FString VariableName; // 0xd0(0x10)
	bool bDefaultValue; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class EmbarkOptionSystem.IEmbarkOptionFloat
// Size: 0xd0 (Inherited: 0xc0)
struct UIEmbarkOptionFloat : UEmbarkOptionBase {
	struct FMulticastInlineDelegate OnOptionChanged; // 0xc0(0x10)

	void SetValue(float NewValue); // Function EmbarkOptionSystem.IEmbarkOptionFloat.SetValue // (Native|Event|Public|BlueprintEvent) // @ game+0x48e2c30
	void SetNormalizedValue(float NewValue); // Function EmbarkOptionSystem.IEmbarkOptionFloat.SetNormalizedValue // (Native|Event|Public|BlueprintEvent) // @ game+0x2900240
	float GetValue(); // Function EmbarkOptionSystem.IEmbarkOptionFloat.GetValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48dc4f0
	float GetNormalizedValue(); // Function EmbarkOptionSystem.IEmbarkOptionFloat.GetNormalizedValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3285780
	float GetMinValue(); // Function EmbarkOptionSystem.IEmbarkOptionFloat.GetMinValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48df100
	float GetMaxValue(); // Function EmbarkOptionSystem.IEmbarkOptionFloat.GetMaxValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d23a0
	struct FText GetCustomDisplayText(float Value); // Function EmbarkOptionSystem.IEmbarkOptionFloat.GetCustomDisplayText // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d40e0
};

// Class EmbarkOptionSystem.EmbarkOptionConsoleFloat
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionConsoleFloat : UIEmbarkOptionFloat {
	struct FString VariableName; // 0xd0(0x10)
	float DefaultValue; // 0xe0(0x04)
	float MinValue; // 0xe4(0x04)
	float MaxValue; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// Class EmbarkOptionSystem.IEmbarkOptionInt
// Size: 0xd0 (Inherited: 0xc0)
struct UIEmbarkOptionInt : UEmbarkOptionBase {
	struct FMulticastInlineDelegate OnOptionChanged; // 0xc0(0x10)

	void SetValue(int32_t NewValue); // Function EmbarkOptionSystem.IEmbarkOptionInt.SetValue // (Native|Event|Public|BlueprintEvent) // @ game+0x48d2440
	int32_t GetValue(); // Function EmbarkOptionSystem.IEmbarkOptionInt.GetValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d3600
};

// Class EmbarkOptionSystem.EmbarkOptionConsoleInt
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionConsoleInt : UIEmbarkOptionInt {
	struct FString VariableName; // 0xd0(0x10)
	int32_t DefaultValue; // 0xe0(0x04)
	int32_t MinValue; // 0xe4(0x04)
	int32_t MaxValue; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// Class EmbarkOptionSystem.IEmbarkOptionString
// Size: 0xd0 (Inherited: 0xc0)
struct UIEmbarkOptionString : UEmbarkOptionBase {
	struct FMulticastInlineDelegate OnOptionChanged; // 0xc0(0x10)

	void SetValue(struct FString NewValue); // Function EmbarkOptionSystem.IEmbarkOptionString.SetValue // (Native|Event|Public|BlueprintEvent) // @ game+0x2f4d430
	struct FString GetValue(); // Function EmbarkOptionSystem.IEmbarkOptionString.GetValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d81e0
};

// Class EmbarkOptionSystem.EmbarkOptionConsoleString
// Size: 0x100 (Inherited: 0xd0)
struct UEmbarkOptionConsoleString : UIEmbarkOptionString {
	struct FString VariableName; // 0xd0(0x10)
	struct FString DefaultValue; // 0xe0(0x10)
	char pad_f0[0x10]; // 0xf0(0x10)
};

// Class EmbarkOptionSystem.IEmbarkOptionEnum
// Size: 0xd0 (Inherited: 0xc0)
struct UIEmbarkOptionEnum : UEmbarkOptionBase {
	struct FMulticastInlineDelegate OnOptionChanged; // 0xc0(0x10)

	void SetIndex(int32_t NewIndex, bool bForceUpdateIndex); // Function EmbarkOptionSystem.IEmbarkOptionEnum.SetIndex // (Native|Event|Public|BlueprintEvent) // @ game+0x48cd5e0
	int32_t GetMaxIndexInclusive(); // Function EmbarkOptionSystem.IEmbarkOptionEnum.GetMaxIndexInclusive // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48dbfa0
	int32_t GetIndex(); // Function EmbarkOptionSystem.IEmbarkOptionEnum.GetIndex // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48eba70
	struct FText GetDisplayText(); // Function EmbarkOptionSystem.IEmbarkOptionEnum.GetDisplayText // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48e6290
};

// Class EmbarkOptionSystem.EmbarkOptionDynamicEnum
// Size: 0x110 (Inherited: 0xd0)
struct UEmbarkOptionDynamicEnum : UIEmbarkOptionEnum {
	struct UIEmbarkDynamicEnum* Enum; // 0xd0(0x08)
	char pad_d8[0x38]; // 0xd8(0x38)

	void AttemptRestore(); // Function EmbarkOptionSystem.EmbarkOptionDynamicEnum.AttemptRestore // (Final|Native|Private) // @ game+0x48d35e0
};

// Class EmbarkOptionSystem.EmbarkOptionEnum
// Size: 0x120 (Inherited: 0xd0)
struct UEmbarkOptionEnum : UIEmbarkOptionEnum {
	struct UEnum* Enum; // 0xd0(0x08)
	struct UStringTable* StringTable; // 0xd8(0x08)
	struct FString Prefix; // 0xe0(0x10)
	struct FString EnumFullName; // 0xf0(0x10)
	int32_t DefaultIndex; // 0x100(0x04)
	char pad_104[0x1c]; // 0x104(0x1c)
};

// Class EmbarkOptionSystem.EmbarkOptionFloat
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionFloat : UIEmbarkOptionFloat {
	float DefaultValue; // 0xd0(0x04)
	float MinValue; // 0xd4(0x04)
	float MaxValue; // 0xd8(0x04)
	char pad_dc[0x14]; // 0xdc(0x14)
};

// Class EmbarkOptionSystem.IEmbarkOptionGameplayTag
// Size: 0xd0 (Inherited: 0xc0)
struct UIEmbarkOptionGameplayTag : UEmbarkOptionBase {
	struct FMulticastInlineDelegate OnOptionChanged; // 0xc0(0x10)

	void SetValue(struct FGameplayTag& NewValue); // Function EmbarkOptionSystem.IEmbarkOptionGameplayTag.SetValue // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x48d27a0
	struct FGameplayTag GetValue(); // Function EmbarkOptionSystem.IEmbarkOptionGameplayTag.GetValue // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48e7ba0
};

// Class EmbarkOptionSystem.EmbarkOptionGameplayTag
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionGameplayTag : UIEmbarkOptionGameplayTag {
	struct FGameplayTag DefaultValue; // 0xd0(0x08)
	char pad_d8[0x18]; // 0xd8(0x18)
};

// Class EmbarkOptionSystem.EmbarkOptionInt
// Size: 0xf0 (Inherited: 0xd0)
struct UEmbarkOptionInt : UIEmbarkOptionInt {
	int32_t DefaultValue; // 0xd0(0x04)
	int32_t MinValue; // 0xd4(0x04)
	int32_t MaxValue; // 0xd8(0x04)
	char pad_dc[0x14]; // 0xdc(0x14)
};

// Class EmbarkOptionSystem.EmbarkOptionManager
// Size: 0x190 (Inherited: 0xa0)
struct UEmbarkOptionManager : UGameInstanceSubsystem {
	struct FMulticastInlineDelegate OnSaveStarted; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnSaveCompleted; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnAnyOptionChanged; // 0xc0(0x10)
	struct TMap<struct FGameplayTag, struct UEmbarkOptionBase*> Options; // 0xd0(0x50)
	struct UEmbarkOptionSaveGameV1* SaveGame; // 0x120(0x08)
	char pad_128[0x68]; // 0x128(0x68)

	bool SetOptionString(struct FGameplayTag& OptionTag, struct FString NewString); // Function EmbarkOptionSystem.EmbarkOptionManager.SetOptionString // (Final|Native|Public|HasOutParms) // @ game+0x48df150
	bool SetOptionInt(struct FGameplayTag& OptionTag, int32_t NewValue); // Function EmbarkOptionSystem.EmbarkOptionManager.SetOptionInt // (Final|Native|Public|HasOutParms) // @ game+0x48e0490
	bool SetOptionGameplayTag(struct FGameplayTag& OptionTag, struct FGameplayTag& NewValue); // Function EmbarkOptionSystem.EmbarkOptionManager.SetOptionGameplayTag // (Final|Native|Public|HasOutParms) // @ game+0x48dadc0
	bool SetOptionFloat(struct FGameplayTag& OptionTag, float NewValue); // Function EmbarkOptionSystem.EmbarkOptionManager.SetOptionFloat // (Final|Native|Public|HasOutParms) // @ game+0x48cfa10
	bool SetOptionEnum(struct FGameplayTag& OptionTag, int32_t NewIndex); // Function EmbarkOptionSystem.EmbarkOptionManager.SetOptionEnum // (Final|Native|Public|HasOutParms) // @ game+0x48d68a0
	bool SetOptionBool(struct FGameplayTag& OptionTag, bool bNewValue); // Function EmbarkOptionSystem.EmbarkOptionManager.SetOptionBool // (Final|Native|Public|HasOutParms) // @ game+0x48eab00
	void SaveAll(); // Function EmbarkOptionSystem.EmbarkOptionManager.SaveAll // (Final|Native|Public) // @ game+0x48dde00
	void Save(struct FGameplayTag& TagCategory); // Function EmbarkOptionSystem.EmbarkOptionManager.Save // (Final|Native|Public|HasOutParms) // @ game+0x48ce6b0
	bool RestartRequiredToTakeEffect(); // Function EmbarkOptionSystem.EmbarkOptionManager.RestartRequiredToTakeEffect // (Final|Native|Public) // @ game+0x48d6d10
	void ResetUnsavedOptions(); // Function EmbarkOptionSystem.EmbarkOptionManager.ResetUnsavedOptions // (Final|Native|Public) // @ game+0x48e8ad0
	void ResetOptionsToDefault(struct FGameplayTag& TagCategory); // Function EmbarkOptionSystem.EmbarkOptionManager.ResetOptionsToDefault // (Final|Native|Public|HasOutParms) // @ game+0x48d2850
	bool HasUnsavedOptions(); // Function EmbarkOptionSystem.EmbarkOptionManager.HasUnsavedOptions // (Final|Native|Public) // @ game+0x48e48b0
	struct UIEmbarkOptionString* GetOptionString(struct UEmbarkOptionManager* Manager, struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.GetOptionString // (Final|Native|Static|Public|HasOutParms) // @ game+0x48dd1e0
	struct UIEmbarkOptionInt* GetOptionInt(struct UEmbarkOptionManager* Manager, struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.GetOptionInt // (Final|Native|Static|Public|HasOutParms) // @ game+0x48d2d30
	struct UIEmbarkOptionGameplayTag* GetOptionGameplayTag(struct UEmbarkOptionManager* Manager, struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.GetOptionGameplayTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x48e88f0
	struct UIEmbarkOptionFloat* GetOptionFloat(struct UEmbarkOptionManager* Manager, struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.GetOptionFloat // (Final|Native|Static|Public|HasOutParms) // @ game+0x48dcd10
	struct UIEmbarkOptionEnum* GetOptionEnum(struct UEmbarkOptionManager* Manager, struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.GetOptionEnum // (Final|Native|Static|Public|HasOutParms) // @ game+0x48e8c80
	struct UIEmbarkOptionBool* GetOptionBool(struct UEmbarkOptionManager* Manager, struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.GetOptionBool // (Final|Native|Static|Public|HasOutParms) // @ game+0x48d4210
	struct UIEmbarkOptionString* FindOptionString(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOptionString // (Final|Native|Public|HasOutParms|Const) // @ game+0x48dbc20
	struct UIEmbarkOptionInt* FindOptionInt(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOptionInt // (Final|Native|Public|HasOutParms|Const) // @ game+0x48e0990
	struct UIEmbarkOptionGameplayTag* FindOptionGameplayTag(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOptionGameplayTag // (Final|Native|Public|HasOutParms|Const) // @ game+0x48e7de0
	struct UIEmbarkOptionFloat* FindOptionFloat(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOptionFloat // (Final|Native|Public|HasOutParms|Const) // @ game+0x48d7710
	struct UIEmbarkOptionEnum* FindOptionEnum(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOptionEnum // (Final|Native|Public|HasOutParms|Const) // @ game+0x48dbae0
	struct UIEmbarkOptionBool* FindOptionBool(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOptionBool // (Final|Native|Public|HasOutParms|Const) // @ game+0x48d05b0
	struct UEmbarkOptionBase* FindOption(struct FGameplayTag& OptionTag); // Function EmbarkOptionSystem.EmbarkOptionManager.FindOption // (Final|Native|Public|HasOutParms|Const) // @ game+0x48e76b0
	void AddOption(struct UEmbarkOptionBase* Option); // Function EmbarkOptionSystem.EmbarkOptionManager.AddOption // (Final|Native|Public) // @ game+0x48d7540
};

// Class EmbarkOptionSystem.EmbarkOptionRepository
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkOptionRepository : UPrimaryDataAsset {
	struct TArray<struct UEmbarkOptionBase*> Options; // 0xa0(0x10)
};

// Class EmbarkOptionSystem.EmbarkOptionSaveGameV1
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkOptionSaveGameV1 : USaveGame {
	int32_t Version; // 0x98(0x04)
	struct TMap<struct FName, struct FString> Properties; // 0xa0(0x50)
	struct TArray<char> AdditionalData; // 0xf0(0x10)
};

// Class EmbarkOptionSystem.EmbarkOptionString
// Size: 0x100 (Inherited: 0xd0)
struct UEmbarkOptionString : UIEmbarkOptionString {
	struct FString DefaultValue; // 0xd0(0x10)
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class EmbarkOptionSystem.EmbarkOptionUserSetting
// Size: 0xe0 (Inherited: 0xd0)
struct UEmbarkOptionUserSetting : UIEmbarkOptionEnum {
	struct UIEmbarkUserSetting* UserSetting; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class EmbarkOptionSystem.IEmbarkDynamicEnum
// Size: 0xb0 (Inherited: 0xa0)
struct UIEmbarkDynamicEnum : UObject {
	struct FMulticastInlineDelegate OnOptionsChanged; // 0x98(0x10)

	bool IsInitialized(); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.IsInitialized // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b5ca40
	void Initialize(); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x2b95cb0
	int32_t GetNumOptions(); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.GetNumOptions // (Native|Event|Public|BlueprintEvent) // @ game+0x2cba6c0
	struct FString GetNameByIndex(int32_t Index); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.GetNameByIndex // (Native|Event|Public|BlueprintEvent) // @ game+0x48d1c30
	int32_t GetIndexByName(struct FString Value); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.GetIndexByName // (Native|Event|Public|BlueprintEvent) // @ game+0x48e7820
	struct FString GetDisplayName(int32_t Index); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.GetDisplayName // (Native|Event|Public|BlueprintEvent) // @ game+0x48cefc0
	int32_t GetDefaultIndex(); // Function EmbarkOptionSystem.IEmbarkDynamicEnum.GetDefaultIndex // (Native|Event|Public|BlueprintEvent) // @ game+0x2cb7e20
};

// Class EmbarkOptionSystem.IEmbarkUserSetting
// Size: 0xb0 (Inherited: 0xa0)
struct UIEmbarkUserSetting : UObject {
	struct FText InvalidDisplayText; // 0x98(0x18)

	void SetValue(int32_t Index); // Function EmbarkOptionSystem.IEmbarkUserSetting.SetValue // (Native|Event|Public|BlueprintEvent) // @ game+0x1703300
	bool IsDefault(); // Function EmbarkOptionSystem.IEmbarkUserSetting.IsDefault // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2cd3930
	bool IsAvailable(); // Function EmbarkOptionSystem.IEmbarkUserSetting.IsAvailable // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b5ca40
	void Initialize(); // Function EmbarkOptionSystem.IEmbarkUserSetting.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	int32_t GetValueIndex(); // Function EmbarkOptionSystem.IEmbarkUserSetting.GetValueIndex // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2ccfe30
	int32_t GetNumOptions(); // Function EmbarkOptionSystem.IEmbarkUserSetting.GetNumOptions // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2cba6c0
	struct FText GetDisplayText(int32_t Index); // Function EmbarkOptionSystem.IEmbarkUserSetting.GetDisplayText // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d6b30
	int32_t GetDefaultIndex(); // Function EmbarkOptionSystem.IEmbarkUserSetting.GetDefaultIndex // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2cb7ed0
	bool CanChange(); // Function EmbarkOptionSystem.IEmbarkUserSetting.CanChange // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3acf850
};

