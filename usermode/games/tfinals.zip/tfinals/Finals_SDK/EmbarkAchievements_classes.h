// Class EmbarkAchievements.AchievementAsset
// Size: 0xe0 (Inherited: 0xa0)
struct UAchievementAsset : UPrimaryDataAsset {
	struct FString AchievementID; // 0xa0(0x10)
	struct FGameplayTag TriggerEvent; // 0xb0(0x08)
	int32_t RequiredValueToUnlock; // 0xb8(0x04)
	struct FName SteamStatName; // 0xbc(0x08)
	int32_t SteamMaxStatProgress; // 0xc4(0x04)
	struct FGuid IdEmbark; // 0xc8(0x10)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class EmbarkAchievements.AchievementTaskManager
// Size: 0xc0 (Inherited: 0xa0)
struct UAchievementTaskManager : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class EmbarkAchievements.SteamAchievementTaskManager
// Size: 0xf0 (Inherited: 0xc0)
struct USteamAchievementTaskManager : UAchievementTaskManager {
	char pad_c0[0x20]; // 0xc0(0x20)
	struct TArray<struct USteamAchievementsHelperTask*> SteamAchievementsHelperTasks; // 0xe0(0x10)
};

// Class EmbarkAchievements.SteamAchievementsHelperTask
// Size: 0xe0 (Inherited: 0xa0)
struct USteamAchievementsHelperTask : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct UAchievementAsset* AchievementAsset; // 0xc0(0x08)
	char pad_c8[0x18]; // 0xc8(0x18)
};

// Class EmbarkAchievements.AchievementSubsystem
// Size: 0xe0 (Inherited: 0xa0)
struct UAchievementSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct TArray<struct UAchievementAsset*> AchievementsList; // 0xb0(0x10)
	char pad_c0[0x8]; // 0xc0(0x08)
	struct UAchievementTaskManager* AchievementManager; // 0xc8(0x08)
	char pad_d0[0x10]; // 0xd0(0x10)

	void SetAchievementProgress(struct FGameplayTag& TriggerEvent, int32_t ProgressToWrite); // Function EmbarkAchievements.AchievementSubsystem.SetAchievementProgress // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x52df320
	float GetAchievementProgress(struct FGameplayTag& TriggerEvent); // Function EmbarkAchievements.AchievementSubsystem.GetAchievementProgress // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x52e0cf0
	bool FlushAchievementProgress(); // Function EmbarkAchievements.AchievementSubsystem.FlushAchievementProgress // (Native|Event|Public|BlueprintEvent) // @ game+0x29eeb30
	void AddAchievementProgress(struct FGameplayTag& TriggerEvent, int32_t TimesToTrigger); // Function EmbarkAchievements.AchievementSubsystem.AddAchievementProgress // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x52e5230
};

