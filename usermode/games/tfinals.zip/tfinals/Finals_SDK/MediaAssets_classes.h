// Class MediaAssets.MediaSourceRendererInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMediaSourceRendererInterface : UInterface {
};

// Class MediaAssets.MediaTexture
// Size: 0x390 (Inherited: 0x2a0)
struct UMediaTexture : UTexture {
	enum class TextureAddress AddressX; // 0x2a0(0x01)
	enum class TextureAddress AddressY; // 0x2a1(0x01)
	bool AutoClear; // 0x2a2(0x01)
	char pad_2a3[0x1]; // 0x2a3(0x01)
	struct FLinearColor ClearColor; // 0x2a4(0x10)
	bool EnableGenMips; // 0x2b4(0x01)
	char NumMips; // 0x2b5(0x01)
	bool NewStyleOutput; // 0x2b6(0x01)
	enum class MediaTextureOutputFormat OutputFormat; // 0x2b7(0x01)
	float CurrentAspectRatio; // 0x2b8(0x04)
	enum class MediaTextureOrientation CurrentOrientation; // 0x2bc(0x01)
	char pad_2bd[0x3]; // 0x2bd(0x03)
	struct UMediaPlayer* MediaPlayer; // 0x2c0(0x08)
	char pad_2c8[0xc8]; // 0x2c8(0xc8)

	void UpdateResource(); // Function MediaAssets.MediaTexture.UpdateResource // (Native|Public|BlueprintCallable) // @ game+0x2b63d50
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Function MediaAssets.MediaTexture.SetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5ced0
	int32_t GetWidth(); // Function MediaAssets.MediaTexture.GetWidth // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b58b70
	int32_t GetTextureNumMips(); // Function MediaAssets.MediaTexture.GetTextureNumMips // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b4c630
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaTexture.GetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b55890
	int32_t GetHeight(); // Function MediaAssets.MediaTexture.GetHeight // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b67e60
	float GetAspectRatio(); // Function MediaAssets.MediaTexture.GetAspectRatio // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b53930
};

// Class MediaAssets.MediaSource
// Size: 0xf0 (Inherited: 0xa0)
struct UMediaSource : UObject {
	char pad_a0[0x50]; // 0xa0(0x50)

	bool Validate(); // Function MediaAssets.MediaSource.Validate // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5ca40
	void SetMediaOptionString(struct FName& Key, struct FString Value); // Function MediaAssets.MediaSource.SetMediaOptionString // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b558c0
	void SetMediaOptionInt64(struct FName& Key, int64_t Value); // Function MediaAssets.MediaSource.SetMediaOptionInt64 // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b6d430
	void SetMediaOptionFloat(struct FName& Key, float Value); // Function MediaAssets.MediaSource.SetMediaOptionFloat // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b6dcd0
	void SetMediaOptionBool(struct FName& Key, bool Value); // Function MediaAssets.MediaSource.SetMediaOptionBool // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b5e430
	struct FString GetUrl(); // Function MediaAssets.MediaSource.GetUrl // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5beb0
};

// Class MediaAssets.BaseMediaSource
// Size: 0x100 (Inherited: 0xf0)
struct UBaseMediaSource : UMediaSource {
	struct FName PlayerName; // 0xf0(0x08)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class MediaAssets.FileMediaSource
// Size: 0x120 (Inherited: 0x100)
struct UFileMediaSource : UBaseMediaSource {
	struct FString FilePath; // 0xf8(0x10)
	bool PrecacheFile; // 0x108(0x01)
	char pad_111[0xf]; // 0x111(0x0f)

	void SetFilePath(struct FString Path); // Function MediaAssets.FileMediaSource.SetFilePath // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5d8b0
};

// Class MediaAssets.MediaComponent
// Size: 0x170 (Inherited: 0x160)
struct UMediaComponent : UActorComponent {
	struct UMediaTexture* MediaTexture; // 0x158(0x08)
	struct UMediaPlayer* MediaPlayer; // 0x160(0x08)

	struct UMediaTexture* GetMediaTexture(); // Function MediaAssets.MediaComponent.GetMediaTexture // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6d1f0
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaComponent.GetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b49d50
};

// Class MediaAssets.MediaTimeStampInfo
// Size: 0xb0 (Inherited: 0xa0)
struct UMediaTimeStampInfo : UObject {
	struct FTimespan Time; // 0x98(0x08)
	int64_t SequenceIndex; // 0xa0(0x08)
};

// Class MediaAssets.MediaPlayer
// Size: 0x1e0 (Inherited: 0xa0)
struct UMediaPlayer : UObject {
	struct FMulticastInlineDelegate OnEndReached; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnMediaClosed; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnMediaOpened; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnMediaOpenFailed; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnPlaybackResumed; // 0xe0(0x10)
	struct FMulticastInlineDelegate OnPlaybackSuspended; // 0xf0(0x10)
	struct FMulticastInlineDelegate OnSeekCompleted; // 0x100(0x10)
	struct FMulticastInlineDelegate OnTracksChanged; // 0x110(0x10)
	struct FMulticastInlineDelegate OnMetadataChanged; // 0x120(0x10)
	struct FTimespan CacheAhead; // 0x130(0x08)
	struct FTimespan CacheBehind; // 0x138(0x08)
	struct FTimespan CacheBehindGame; // 0x140(0x08)
	bool NativeAudioOut; // 0x148(0x01)
	bool PlayOnOpen; // 0x149(0x01)
	char pad_14a[0x2]; // 0x14a(0x02)
	char Shuffle : 1; // 0x14c(0x01)
	char Loop : 1; // 0x14c(0x01)
	char pad_14c_2 : 6; // 0x14c(0x01)
	char pad_14d[0x3]; // 0x14d(0x03)
	struct UMediaPlaylist* Playlist; // 0x150(0x08)
	int32_t PlaylistIndex; // 0x158(0x04)
	char pad_15c[0x4]; // 0x15c(0x04)
	struct FTimespan TimeDelay; // 0x160(0x08)
	float HorizontalFieldOfView; // 0x168(0x04)
	float VerticalFieldOfView; // 0x16c(0x04)
	struct FRotator ViewRotation; // 0x170(0x18)
	char pad_188[0x28]; // 0x188(0x28)
	struct FGuid PlayerGuid; // 0x1b0(0x10)
	char pad_1c0[0x20]; // 0x1c0(0x20)

	bool SupportsSeeking(); // Function MediaAssets.MediaPlayer.SupportsSeeking // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b46b30
	bool SupportsScrubbing(); // Function MediaAssets.MediaPlayer.SupportsScrubbing // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b57590
	bool SupportsRate(float Rate, bool Unthinned); // Function MediaAssets.MediaPlayer.SupportsRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b4d510
	bool SetViewRotation(struct FRotator& Rotation, bool Absolute); // Function MediaAssets.MediaPlayer.SetViewRotation // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2b5b6a0
	bool SetViewField(float Horizontal, float Vertical, bool Absolute); // Function MediaAssets.MediaPlayer.SetViewField // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6cec0
	bool SetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex, float FrameRate); // Function MediaAssets.MediaPlayer.SetVideoTrackFrameRate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6f180
	bool SetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.SetTrackFormat // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b66230
	void SetTimeDelay(struct FTimespan TimeDelay); // Function MediaAssets.MediaPlayer.SetTimeDelay // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2b68650
	bool SetRate(float Rate); // Function MediaAssets.MediaPlayer.SetRate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6fda0
	bool SetNativeVolume(float Volume); // Function MediaAssets.MediaPlayer.SetNativeVolume // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b67130
	void SetMediaOptions(struct UMediaSource* Options); // Function MediaAssets.MediaPlayer.SetMediaOptions // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6a0d0
	bool SetLooping(bool Looping); // Function MediaAssets.MediaPlayer.SetLooping // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b4b260
	void SetDesiredPlayerName(struct FName PlayerName); // Function MediaAssets.MediaPlayer.SetDesiredPlayerName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b60e00
	void SetBlockOnTime(struct FTimespan& Time); // Function MediaAssets.MediaPlayer.SetBlockOnTime // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2b57bb0
	bool SelectTrack(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.SelectTrack // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b46ec0
	bool Seek(struct FTimespan& Time); // Function MediaAssets.MediaPlayer.Seek // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2b46a00
	bool Rewind(); // Function MediaAssets.MediaPlayer.Rewind // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6f970
	bool Reopen(); // Function MediaAssets.MediaPlayer.Reopen // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6fbe0
	bool Previous(); // Function MediaAssets.MediaPlayer.Previous // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b644b0
	void PlayAndSeek(); // Function MediaAssets.MediaPlayer.PlayAndSeek // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b68d50
	bool Play(); // Function MediaAssets.MediaPlayer.Play // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b54320
	bool Pause(); // Function MediaAssets.MediaPlayer.Pause // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b4d8d0
	bool OpenUrl(struct FString URL); // Function MediaAssets.MediaPlayer.OpenUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6dc00
	bool OpenSourceWithOptions(struct UMediaSource* MediaSource, struct FMediaPlayerOptions& Options); // Function MediaAssets.MediaPlayer.OpenSourceWithOptions // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b472f0
	void OpenSourceLatent(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UMediaSource* MediaSource, struct FMediaPlayerOptions& Options, bool& bSuccess); // Function MediaAssets.MediaPlayer.OpenSourceLatent // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b67b60
	bool OpenSource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.OpenSource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b64e50
	bool OpenPlaylistIndex(struct UMediaPlaylist* InPlaylist, int32_t Index); // Function MediaAssets.MediaPlayer.OpenPlaylistIndex // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6d0e0
	bool OpenPlaylist(struct UMediaPlaylist* InPlaylist); // Function MediaAssets.MediaPlayer.OpenPlaylist // (Final|Native|Public|BlueprintCallable) // @ game+0x2b52460
	bool OpenFile(struct FString FilePath); // Function MediaAssets.MediaPlayer.OpenFile // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b4b0a0
	bool Next(); // Function MediaAssets.MediaPlayer.Next // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5cd00
	bool IsReady(); // Function MediaAssets.MediaPlayer.IsReady // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b60fd0
	bool IsPreparing(); // Function MediaAssets.MediaPlayer.IsPreparing // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b563a0
	bool IsPlaying(); // Function MediaAssets.MediaPlayer.IsPlaying // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5e3f0
	bool IsPaused(); // Function MediaAssets.MediaPlayer.IsPaused // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6d570
	bool IsLooping(); // Function MediaAssets.MediaPlayer.IsLooping // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b51960
	bool IsConnecting(); // Function MediaAssets.MediaPlayer.IsConnecting // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b590a0
	bool IsClosed(); // Function MediaAssets.MediaPlayer.IsClosed // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b51fc0
	bool IsBuffering(); // Function MediaAssets.MediaPlayer.IsBuffering // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b69a80
	bool HasError(); // Function MediaAssets.MediaPlayer.HasError // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b451e0
	struct FRotator GetViewRotation(); // Function MediaAssets.MediaPlayer.GetViewRotation // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b54820
	struct FString GetVideoTrackType(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6c870
	struct FFloatRange GetVideoTrackFrameRates(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackFrameRates // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5a7d0
	float GetVideoTrackFrameRate(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackFrameRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b68320
	struct FIntPoint GetVideoTrackDimensions(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackDimensions // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b70590
	float GetVideoTrackAspectRatio(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetVideoTrackAspectRatio // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5d460
	float GetVerticalFieldOfView(); // Function MediaAssets.MediaPlayer.GetVerticalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b68bb0
	struct FString GetUrl(); // Function MediaAssets.MediaPlayer.GetUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6a1d0
	struct FString GetTrackLanguage(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackLanguage // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b4f560
	int32_t GetTrackFormat(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackFormat // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b612b0
	struct FText GetTrackDisplayName(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetTrackDisplayName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6f000
	struct UMediaTimeStampInfo* GetTimeStamp(); // Function MediaAssets.MediaPlayer.GetTimeStamp // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5c210
	struct FTimespan GetTimeDelay(); // Function MediaAssets.MediaPlayer.GetTimeDelay // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b590d0
	struct FTimespan GetTime(); // Function MediaAssets.MediaPlayer.GetTime // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b57ab0
	void GetSupportedRates(struct TArray<struct FFloatRange>& OutRates, bool Unthinned); // Function MediaAssets.MediaPlayer.GetSupportedRates // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b578e0
	int32_t GetSelectedTrack(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetSelectedTrack // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b4d190
	float GetRate(); // Function MediaAssets.MediaPlayer.GetRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b52220
	int32_t GetPlaylistIndex(); // Function MediaAssets.MediaPlayer.GetPlaylistIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5b580
	struct UMediaPlaylist* GetPlaylist(); // Function MediaAssets.MediaPlayer.GetPlaylist // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5e750
	struct FName GetPlayerName(); // Function MediaAssets.MediaPlayer.GetPlayerName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6a060
	int32_t GetNumTracks(enum class EMediaPlayerTrack TrackType); // Function MediaAssets.MediaPlayer.GetNumTracks // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b45a20
	int32_t GetNumTrackFormats(enum class EMediaPlayerTrack TrackType, int32_t TrackIndex); // Function MediaAssets.MediaPlayer.GetNumTrackFormats // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b55c60
	struct FText GetMediaName(); // Function MediaAssets.MediaPlayer.GetMediaName // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b64a50
	struct TMap<struct FString, struct FMediaMetadataItemsBPT> GetMediaMetadataItems(); // Function MediaAssets.MediaPlayer.GetMediaMetadataItems // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b61f50
	float GetHorizontalFieldOfView(); // Function MediaAssets.MediaPlayer.GetHorizontalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b648b0
	struct FTimespan GetDuration(); // Function MediaAssets.MediaPlayer.GetDuration // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b53a70
	struct UMediaTimeStampInfo* GetDisplayTimeStamp(); // Function MediaAssets.MediaPlayer.GetDisplayTimeStamp // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b63430
	struct FTimespan GetDisplayTime(); // Function MediaAssets.MediaPlayer.GetDisplayTime // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b51f50
	struct FName GetDesiredPlayerName(); // Function MediaAssets.MediaPlayer.GetDesiredPlayerName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b65180
	struct FString GetAudioTrackType(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b52250
	int32_t GetAudioTrackSampleRate(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackSampleRate // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b4bc00
	int32_t GetAudioTrackChannels(int32_t TrackIndex, int32_t FormatIndex); // Function MediaAssets.MediaPlayer.GetAudioTrackChannels // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b60190
	void Close(); // Function MediaAssets.MediaPlayer.Close // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5d240
	bool CanPlayUrl(struct FString URL); // Function MediaAssets.MediaPlayer.CanPlayUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b59100
	bool CanPlaySource(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlayer.CanPlaySource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b4d010
	bool CanPause(); // Function MediaAssets.MediaPlayer.CanPause // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b69a50
};

// Class MediaAssets.MediaPlayerProxyInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMediaPlayerProxyInterface : UInterface {
};

// Class MediaAssets.MediaPlaylist
// Size: 0xb0 (Inherited: 0xa0)
struct UMediaPlaylist : UObject {
	struct TArray<struct UMediaSource*> Items; // 0x98(0x10)

	bool Replace(int32_t Index, struct UMediaSource* Replacement); // Function MediaAssets.MediaPlaylist.Replace // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b6e0d0
	bool RemoveAt(int32_t Index); // Function MediaAssets.MediaPlaylist.RemoveAt // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5b440
	bool Remove(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Remove // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5a8e0
	int32_t Num(); // Function MediaAssets.MediaPlaylist.Num // (Final|Native|Public|BlueprintCallable) // @ game+0x2b6c4f0
	void Insert(struct UMediaSource* MediaSource, int32_t Index); // Function MediaAssets.MediaPlaylist.Insert // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b69c40
	struct UMediaSource* GetRandom(int32_t& OutIndex); // Function MediaAssets.MediaPlaylist.GetRandom // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b68c40
	struct UMediaSource* GetPrevious(int32_t& InOutIndex); // Function MediaAssets.MediaPlaylist.GetPrevious // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b66010
	struct UMediaSource* GetNext(int32_t& InOutIndex); // Function MediaAssets.MediaPlaylist.GetNext // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b61080
	struct UMediaSource* Get(int32_t Index); // Function MediaAssets.MediaPlaylist.Get // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b69090
	bool AddUrl(struct FString URL); // Function MediaAssets.MediaPlaylist.AddUrl // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b46cf0
	bool AddFile(struct FString FilePath); // Function MediaAssets.MediaPlaylist.AddFile // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b4b160
	bool Add(struct UMediaSource* MediaSource); // Function MediaAssets.MediaPlaylist.Add // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5cf80
};

// Class MediaAssets.MediaSoundComponent
// Size: 0xb00 (Inherited: 0xa20)
struct UMediaSoundComponent : USynthComponent {
	enum class EMediaSoundChannels Channels; // 0xa20(0x04)
	bool DynamicRateAdjustment; // 0xa24(0x01)
	char pad_a25[0x3]; // 0xa25(0x03)
	float RateAdjustmentFactor; // 0xa28(0x04)
	struct FFloatRange RateAdjustmentRange; // 0xa2c(0x10)
	char pad_a3c[0x4]; // 0xa3c(0x04)
	struct UMediaPlayer* MediaPlayer; // 0xa40(0x08)
	char pad_a48[0xb8]; // 0xa48(0xb8)

	void SetSpectralAnalysisSettings(struct TArray<float> InFrequenciesToAnalyze, enum class EMediaSoundComponentFFTSize InFFTSize); // Function MediaAssets.MediaSoundComponent.SetSpectralAnalysisSettings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b552b0
	void SetMediaPlayer(struct UMediaPlayer* NewMediaPlayer); // Function MediaAssets.MediaSoundComponent.SetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b67040
	void SetEnvelopeFollowingsettings(int32_t AttackTimeMsec, int32_t ReleaseTimeMsec); // Function MediaAssets.MediaSoundComponent.SetEnvelopeFollowingsettings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5e0a0
	void SetEnableSpectralAnalysis(bool bInSpectralAnalysisEnabled); // Function MediaAssets.MediaSoundComponent.SetEnableSpectralAnalysis // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b5e1e0
	void SetEnableEnvelopeFollowing(bool bInEnvelopeFollowing); // Function MediaAssets.MediaSoundComponent.SetEnableEnvelopeFollowing // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b57470
	struct TArray<struct FMediaSoundComponentSpectralData> GetSpectralData(); // Function MediaAssets.MediaSoundComponent.GetSpectralData // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b4d940
	struct TArray<struct FMediaSoundComponentSpectralData> GetNormalizedSpectralData(); // Function MediaAssets.MediaSoundComponent.GetNormalizedSpectralData // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b53970
	struct UMediaPlayer* GetMediaPlayer(); // Function MediaAssets.MediaSoundComponent.GetMediaPlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5da50
	float GetEnvelopeValue(); // Function MediaAssets.MediaSoundComponent.GetEnvelopeValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b53a30
	bool BP_GetAttenuationSettingsToApply(struct FSoundAttenuationSettings& OutAttenuationSettings); // Function MediaAssets.MediaSoundComponent.BP_GetAttenuationSettingsToApply // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b46db0
};

// Class MediaAssets.PlatformMediaSource
// Size: 0x100 (Inherited: 0xf0)
struct UPlatformMediaSource : UMediaSource {
	struct UMediaSource* MediaSource; // 0xf0(0x08)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class MediaAssets.StreamMediaSource
// Size: 0x110 (Inherited: 0x100)
struct UStreamMediaSource : UBaseMediaSource {
	struct FString StreamUrl; // 0xf8(0x10)
};

// Class MediaAssets.TimeSynchronizableMediaSource
// Size: 0x110 (Inherited: 0x100)
struct UTimeSynchronizableMediaSource : UBaseMediaSource {
	bool bUseTimeSynchronization; // 0xf8(0x01)
	int32_t FrameDelay; // 0xfc(0x04)
	double TimeDelay; // 0x100(0x08)
	bool bAutoDetectInput; // 0x108(0x01)
	char pad_10e[0x2]; // 0x10e(0x02)
};

// Class MediaAssets.MediaBlueprintFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMediaBlueprintFunctionLibrary : UBlueprintFunctionLibrary {

	void EnumerateWebcamCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateWebcamCaptureDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2b4c4c0
	void EnumerateVideoCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateVideoCaptureDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2b585d0
	void EnumerateAudioCaptureDevices(struct TArray<struct FMediaCaptureDevice>& OutDevices, int32_t Filter); // Function MediaAssets.MediaBlueprintFunctionLibrary.EnumerateAudioCaptureDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2b64c30
};

