// Class EngineSettings.ConsoleSettings
// Size: 0xe0 (Inherited: 0xa0)
struct UConsoleSettings : UObject {
	int32_t MaxScrollbackSize; // 0x98(0x04)
	struct TArray<struct FAutoCompleteCommand> ManualAutoCompleteList; // 0xa0(0x10)
	struct TArray<struct FString> AutoCompleteMapPaths; // 0xb0(0x10)
	float BackgroundOpacityPercentage; // 0xc0(0x04)
	bool bOrderTopToBottom; // 0xc4(0x01)
	bool bDisplayHelpInAutoComplete; // 0xc5(0x01)
	struct FColor InputColor; // 0xc8(0x04)
	struct FColor HistoryColor; // 0xcc(0x04)
	struct FColor AutoCompleteCommandColor; // 0xd0(0x04)
	struct FColor AutoCompleteCVarColor; // 0xd4(0x04)
	struct FColor AutoCompleteFadedColor; // 0xd8(0x04)
	char pad_de[0x2]; // 0xde(0x02)
};

// Class EngineSettings.GameMapsSettings
// Size: 0x190 (Inherited: 0xa0)
struct UGameMapsSettings : UObject {
	struct FString LocalMapOptions; // 0x98(0x10)
	struct FSoftObjectPath TransitionMap; // 0xa8(0x20)
	bool bUseSplitscreen; // 0xc8(0x01)
	enum class ETwoPlayerSplitScreenType TwoPlayerSplitscreenLayout; // 0xc9(0x01)
	enum class EThreePlayerSplitScreenType ThreePlayerSplitscreenLayout; // 0xca(0x01)
	enum class EFourPlayerSplitScreenType FourPlayerSplitscreenLayout; // 0xcb(0x01)
	bool bOffsetPlayerGamepadIds; // 0xcc(0x01)
	struct FSoftClassPath GameInstanceClass; // 0xd0(0x20)
	struct FSoftObjectPath GameDefaultMap; // 0xf0(0x20)
	struct FSoftObjectPath ServerDefaultMap; // 0x110(0x20)
	struct FSoftClassPath GlobalDefaultGameMode; // 0x130(0x20)
	struct FSoftClassPath GlobalDefaultServerGameMode; // 0x150(0x20)
	struct TArray<struct FGameModeName> GameModeMapPrefixes; // 0x170(0x10)
	struct TArray<struct FGameModeName> GameModeClassAliases; // 0x180(0x10)

	void SetSkipAssigningGamepadToPlayer1(bool bSkipFirstPlayer); // Function EngineSettings.GameMapsSettings.SetSkipAssigningGamepadToPlayer1 // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x9de210
	bool GetSkipAssigningGamepadToPlayer1(); // Function EngineSettings.GameMapsSettings.GetSkipAssigningGamepadToPlayer1 // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9e1820
	struct UGameMapsSettings* GetGameMapsSettings(); // Function EngineSettings.GameMapsSettings.GetGameMapsSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9e18d0
};

// Class EngineSettings.GameNetworkManagerSettings
// Size: 0xd0 (Inherited: 0xa0)
struct UGameNetworkManagerSettings : UObject {
	int32_t MinDynamicBandwidth; // 0x98(0x04)
	int32_t MaxDynamicBandwidth; // 0x9c(0x04)
	int32_t TotalNetBandwidth; // 0xa0(0x04)
	int32_t BadPingThreshold; // 0xa4(0x04)
	char bIsStandbyCheckingEnabled : 1; // 0xa8(0x01)
	float StandbyRxCheatTime; // 0xac(0x04)
	float StandbyTxCheatTime; // 0xb0(0x04)
	float PercentMissingForRxStandby; // 0xb4(0x04)
	float PercentMissingForTxStandby; // 0xb8(0x04)
	float PercentForBadPing; // 0xbc(0x04)
	float JoinInProgressStandbyWaitTime; // 0xc0(0x04)
	char pad_c8_1 : 7; // 0xc8(0x01)
	char pad_c9[0x7]; // 0xc9(0x07)
};

// Class EngineSettings.GameSessionSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UGameSessionSettings : UObject {
	int32_t MaxSpectators; // 0x98(0x04)
	int32_t MaxPlayers; // 0x9c(0x04)
	char bRequiresPushToTalk : 1; // 0xa0(0x01)
	char pad_a8_1 : 7; // 0xa8(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
};

// Class EngineSettings.GeneralEngineSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UGeneralEngineSettings : UObject {
};

// Class EngineSettings.GeneralProjectSettings
// Size: 0x190 (Inherited: 0xa0)
struct UGeneralProjectSettings : UObject {
	struct FString CompanyName; // 0x98(0x10)
	struct FString CompanyDistinguishedName; // 0xa8(0x10)
	struct FString CopyrightNotice; // 0xb8(0x10)
	struct FString Description; // 0xc8(0x10)
	struct FString Homepage; // 0xd8(0x10)
	struct FString LicensingTerms; // 0xe8(0x10)
	struct FString PrivacyPolicy; // 0xf8(0x10)
	struct FGuid ProjectID; // 0x108(0x10)
	struct FString ProjectName; // 0x118(0x10)
	struct FString ProjectVersion; // 0x128(0x10)
	struct FString SupportContact; // 0x138(0x10)
	struct FText ProjectDisplayedTitle; // 0x148(0x18)
	struct FText ProjectDebugTitleInfo; // 0x160(0x18)
	bool bShouldWindowPreserveAspectRatio; // 0x178(0x01)
	bool bUseBorderlessWindow; // 0x179(0x01)
	bool bStartInVR; // 0x17a(0x01)
	bool bAllowWindowResize; // 0x17b(0x01)
	bool bAllowClose; // 0x17c(0x01)
	bool bAllowMaximize; // 0x17d(0x01)
	bool bAllowMinimize; // 0x17e(0x01)
	float EyeOffsetForFakeStereoRenderingDevice; // 0x180(0x04)
	float FOVForFakeStereoRenderingDevice; // 0x184(0x04)
	char pad_18f[0x1]; // 0x18f(0x01)
};

// Class EngineSettings.HudSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UHudSettings : UObject {
	char bShowHUD : 1; // 0x98(0x01)
	struct TArray<struct FName> DebugDisplay; // 0xa0(0x10)
};

