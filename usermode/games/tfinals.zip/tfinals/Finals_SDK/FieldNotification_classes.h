// Class FieldNotification.NotifyFieldValueChanged
// Size: 0xa0 (Inherited: 0xa0)
struct UNotifyFieldValueChanged : UInterface {
};

