// Class ClothingSystemRuntimeNv.ClothConfigNv
// Size: 0x210 (Inherited: 0xa0)
struct UClothConfigNv : UClothConfigCommon {
	enum class EClothingWindMethodNv ClothingWindMethod; // 0x98(0x01)
	struct FClothConstraintSetupNv VerticalConstraint; // 0x9c(0x10)
	struct FClothConstraintSetupNv HorizontalConstraint; // 0xac(0x10)
	struct FClothConstraintSetupNv BendConstraint; // 0xbc(0x10)
	struct FClothConstraintSetupNv ShearConstraint; // 0xcc(0x10)
	float SelfCollisionRadius; // 0xdc(0x04)
	float SelfCollisionStiffness; // 0xe0(0x04)
	float SelfCollisionCullScale; // 0xe4(0x04)
	struct FVector Damping; // 0xe8(0x18)
	float Friction; // 0x100(0x04)
	float WindDragCoefficient; // 0x104(0x04)
	float WindLiftCoefficient; // 0x108(0x04)
	struct FVector LinearDrag; // 0x110(0x18)
	struct FVector AngularDrag; // 0x128(0x18)
	struct FVector LinearInertiaScale; // 0x140(0x18)
	struct FVector AngularInertiaScale; // 0x158(0x18)
	struct FVector CentrifugalInertiaScale; // 0x170(0x18)
	float SolverFrequency; // 0x188(0x04)
	float StiffnessFrequency; // 0x18c(0x04)
	float GravityScale; // 0x190(0x04)
	char pad_195[0x3]; // 0x195(0x03)
	struct FVector GravityOverride; // 0x198(0x18)
	bool bUseGravityOverride; // 0x1b0(0x01)
	char pad_1b1[0x3]; // 0x1b1(0x03)
	float TetherStiffness; // 0x1b4(0x04)
	float TetherLimit; // 0x1b8(0x04)
	float CollisionThickness; // 0x1bc(0x04)
	float AnimDriveSpringStiffness; // 0x1c0(0x04)
	float AnimDriveDamperStiffness; // 0x1c4(0x04)
	enum class EClothingWindMethod_Legacy WindMethod; // 0x1c8(0x01)
	char pad_1c9[0x3]; // 0x1c9(0x03)
	struct FClothConstraintSetup_Legacy VerticalConstraintConfig; // 0x1cc(0x10)
	struct FClothConstraintSetup_Legacy HorizontalConstraintConfig; // 0x1dc(0x10)
	struct FClothConstraintSetup_Legacy BendConstraintConfig; // 0x1ec(0x10)
	struct FClothConstraintSetup_Legacy ShearConstraintConfig; // 0x1fc(0x10)
	char pad_20c[0x4]; // 0x20c(0x04)
};

// Class ClothingSystemRuntimeNv.ClothingSimulationFactoryNv
// Size: 0xa0 (Inherited: 0xa0)
struct UClothingSimulationFactoryNv : UClothingSimulationFactory {
};

// Class ClothingSystemRuntimeNv.ClothingSimulationInteractorNv
// Size: 0x100 (Inherited: 0x100)
struct UClothingSimulationInteractorNv : UClothingSimulationInteractor {

	void SetAnimDriveDamperStiffness(float InStiffness); // Function ClothingSystemRuntimeNv.ClothingSimulationInteractorNv.SetAnimDriveDamperStiffness // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2e7fe30
};

// Class ClothingSystemRuntimeNv.ClothPhysicalMeshDataNv_Legacy
// Size: 0x190 (Inherited: 0x150)
struct UClothPhysicalMeshDataNv_Legacy : UClothPhysicalMeshDataBase_Legacy {
	struct TArray<float> MaxDistances; // 0x150(0x10)
	struct TArray<float> BackstopDistances; // 0x160(0x10)
	struct TArray<float> BackstopRadiuses; // 0x170(0x10)
	struct TArray<float> AnimDriveMultipliers; // 0x180(0x10)
};

