// Class AudioMixer.AudioBusSubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UAudioBusSubsystem : UAudioEngineSubsystem {
	char pad_a0[0x60]; // 0xa0(0x60)
};

// Class AudioMixer.AudioDeviceNotificationSubsystem
// Size: 0x1a0 (Inherited: 0xa0)
struct UAudioDeviceNotificationSubsystem : UEngineSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct FMulticastInlineDelegate DefaultCaptureDeviceChanged; // 0xa8(0x10)
	char pad_b8[0x18]; // 0xb8(0x18)
	struct FMulticastInlineDelegate DefaultRenderDeviceChanged; // 0xd0(0x10)
	char pad_e0[0x18]; // 0xe0(0x18)
	struct FMulticastInlineDelegate DeviceAdded; // 0xf8(0x10)
	char pad_108[0x18]; // 0x108(0x18)
	struct FMulticastInlineDelegate DeviceRemoved; // 0x120(0x10)
	char pad_130[0x18]; // 0x130(0x18)
	struct FMulticastInlineDelegate DeviceStateChanged; // 0x148(0x10)
	char pad_158[0x18]; // 0x158(0x18)
	struct FMulticastInlineDelegate DeviceSwitched; // 0x170(0x10)
	char pad_180[0x20]; // 0x180(0x20)
};

// Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {

	float TrimAudioCache(float InMegabytesToFree); // Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2abd430
	void SwapAudioOutputDevice(struct UObject* WorldContextObject, struct FString NewDeviceId, struct FDelegate& OnCompletedDeviceSwap); // Function AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2aa3dd0
	struct USoundWave* StopRecordingOutput(struct UObject* WorldContextObject, enum class EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite); // Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab1590
	void StopAudioBus(struct UObject* WorldContextObject, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab2310
	void StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing); // Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aa37b0
	void StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord); // Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a9b4c0
	void StartAudioBus(struct UObject* WorldContextObject, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aa1e50
	void StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, enum class EFFTSize FFTSize, enum class EFFTPeakInterpolationMethod InterpolationMethod, enum class EFFTWindowType WindowType, float HopSize, enum class EAudioSpectrumType SpectrumType); // Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a8a7a0
	void SetSubmixEffectChainOverride(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct TArray<struct USoundEffectSubmixPreset*> SubmixEffectPresetChain, float FadeTimeSec); // Function AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a9cde0
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed); // Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a98490
	void ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aaa0c0
	void ReplaceSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a93f90
	void ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a93f90
	void RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a94460
	void RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aa1690
	void RemoveSubmixEffectAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a94460
	void RemoveSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aa1690
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab7380
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2abc970
	void PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion); // Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab6780
	void PrimeSoundCueForPlayback(struct USoundCue* SoundCue); // Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a8f720
	void PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a8c790
	struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> MakePresetSpectralAnalysisBandSettings(enum class EAudioSpectrumBandPresetType InBandPresetType, int32_t InNumBands, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec); // Function AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2aad1e0
	struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> MakeMusicalSpectralAnalysisBandSettings(int32_t InNumSemitones, enum class EMusicalNoteName InStartingMusicalNote, int32_t InStartingOctave, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec); // Function AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a95130
	struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> MakeFullSpectrumSpectralAnalysisBandSettings(int32_t InNumBands, float InMinimumFrequency, float InMaximumFrequency, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec); // Function AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2ab6e30
	bool IsAudioBusActive(struct UObject* WorldContextObject, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab0640
	void GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze); // Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2aa34b0
	int32_t GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain); // Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a96cb0
	void GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze); // Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a99e80
	void GetCurrentAudioOutputDeviceName(struct UObject* WorldContextObject, struct FDelegate& OnObtainCurrentDeviceEvent); // Function AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2ab1490
	void GetAvailableAudioOutputDevices(struct UObject* WorldContextObject, struct FDelegate& OnObtainDevicesEvent); // Function AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2a970a0
	struct FString Conv_AudioOutputDeviceInfoToString(struct FAudioOutputDeviceInfo& Info); // Function AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2aac1d0
	void ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a91ef0
	void ClearSubmixEffectChainOverride(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, float FadeTimeSec); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aa1cd0
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2aacd50
	int32_t AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2abd280
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab4e90
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2ab7f00
};

// Class AudioMixer.SynthSound
// Size: 0x510 (Inherited: 0x4f0)
struct USynthSound : USoundWaveProcedural {
	struct TWeakObjectPtr<struct USynthComponent> OwningSynthComponent; // 0x4f0(0x08)
	char pad_4f8[0x18]; // 0x4f8(0x18)
};

// Class AudioMixer.SynthComponent
// Size: 0xa20 (Inherited: 0x3c0)
struct USynthComponent : USceneComponent {
	char bAutoDestroy : 1; // 0x3c0(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x3c0(0x01)
	char bAllowSpatialization : 1; // 0x3c0(0x01)
	char bOverrideAttenuation : 1; // 0x3c0(0x01)
	char pad_3c0_4 : 4; // 0x3c0(0x01)
	char pad_3c1[0x3]; // 0x3c1(0x03)
	char bEnableBusSends : 1; // 0x3c4(0x01)
	char bEnableBaseSubmix : 1; // 0x3c4(0x01)
	char bEnableSubmixSends : 1; // 0x3c4(0x01)
	char pad_3c4_3 : 5; // 0x3c4(0x01)
	char pad_3c5[0x3]; // 0x3c5(0x03)
	struct USoundAttenuation* AttenuationSettings; // 0x3c8(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x3d0(0x3d0)
	struct USoundConcurrency* ConcurrencySettings; // 0x7a0(0x08)
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // 0x7a8(0x50)
	struct FSoundModulationDefaultRoutingSettings ModulationRouting; // 0x7f8(0x168)
	struct USoundClass* SoundClass; // 0x960(0x08)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x968(0x08)
	struct USoundSubmixBase* SoundSubmix; // 0x970(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x978(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x988(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x998(0x10)
	char bIsUISound : 1; // 0x9a8(0x01)
	char bIsPreviewSound : 1; // 0x9a8(0x01)
	char pad_9a8_2 : 6; // 0x9a8(0x01)
	char pad_9a9[0x3]; // 0x9a9(0x03)
	int32_t EnvelopeFollowerAttackTime; // 0x9ac(0x04)
	int32_t EnvelopeFollowerReleaseTime; // 0x9b0(0x04)
	char pad_9b4[0x4]; // 0x9b4(0x04)
	struct FMulticastInlineDelegate OnAudioEnvelopeValue; // 0x9b8(0x10)
	char pad_9c8[0x20]; // 0x9c8(0x20)
	struct USynthSound* Synth; // 0x9e8(0x08)
	struct UAudioComponent* AudioComponent; // 0x9f0(0x08)
	char pad_9f8[0x28]; // 0x9f8(0x28)

	void Stop(); // Function AudioMixer.SynthComponent.Stop // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2acd650
	void Start(); // Function AudioMixer.SynthComponent.Start // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2add3c0
	void SetVolumeMultiplier(float VolumeMultiplier); // Function AudioMixer.SynthComponent.SetVolumeMultiplier // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2acc500
	void SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel); // Function AudioMixer.SynthComponent.SetSubmixSend // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ac9ef0
	void SetSourceBusSendPreEffect(struct USoundSourceBus* SoundSourceBus, float SourceBusSendLevel); // Function AudioMixer.SynthComponent.SetSourceBusSendPreEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2abf200
	void SetSourceBusSendPostEffect(struct USoundSourceBus* SoundSourceBus, float SourceBusSendLevel); // Function AudioMixer.SynthComponent.SetSourceBusSendPostEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ac2cb0
	void SetOutputToBusOnly(bool bInOutputToBusOnly); // Function AudioMixer.SynthComponent.SetOutputToBusOnly // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ac8cf0
	void SetModulationRouting(struct TSet<struct USoundModulatorBase*>& Modulators, enum class EModulationDestination Destination, enum class EModulationRouting RoutingMethod); // Function AudioMixer.SynthComponent.SetModulationRouting // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ae4c50
	void SetLowPassFilterFrequency(float InLowPassFilterFrequency); // Function AudioMixer.SynthComponent.SetLowPassFilterFrequency // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2adec20
	void SetLowPassFilterEnabled(bool InLowPassFilterEnabled); // Function AudioMixer.SynthComponent.SetLowPassFilterEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2aef770
	void SetAudioBusSendPreEffect(struct UAudioBus* AudioBus, float AudioBusSendLevel); // Function AudioMixer.SynthComponent.SetAudioBusSendPreEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2abe870
	void SetAudioBusSendPostEffect(struct UAudioBus* AudioBus, float AudioBusSendLevel); // Function AudioMixer.SynthComponent.SetAudioBusSendPostEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ac7980
	bool IsPlaying(); // Function AudioMixer.SynthComponent.IsPlaying // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2add000
	struct TSet<struct USoundModulatorBase*> GetModulators(enum class EModulationDestination Destination); // Function AudioMixer.SynthComponent.GetModulators // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2ad6990
	void FadeOut(float FadeOutDuration, float FadeVolumeLevel, enum class EAudioFaderCurve FadeCurve); // Function AudioMixer.SynthComponent.FadeOut // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x2ac5820
	void FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime, enum class EAudioFaderCurve FadeCurve); // Function AudioMixer.SynthComponent.FadeIn // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x2ac8fb0
	void AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel, enum class EAudioFaderCurve FadeCurve); // Function AudioMixer.SynthComponent.AdjustVolume // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x2ace500
};

// Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0x1c0 (Inherited: 0xe0)
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	char pad_e0[0x80]; // 0xe0(0x80)
	struct FSubmixEffectDynamicsProcessorSettings Settings; // 0x160(0x60)

	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad06d0
	void SetExternalSubmix(struct USoundSubmix* Submix); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2accef0
	void SetAudioBus(struct UAudioBus* AudioBus); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ae6bf0
	void ResetKey(); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2abff40
};

// Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0x120 (Inherited: 0xe0)
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSubmixEffectSubmixEQSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings); // Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad84d0
};

// Class AudioMixer.SubmixEffectReverbPreset
// Size: 0x180 (Inherited: 0xe0)
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	char pad_e0[0x60]; // 0xe0(0x60)
	struct FSubmixEffectReverbSettings Settings; // 0x140(0x40)

	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2acc0c0
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings); // Function AudioMixer.SubmixEffectReverbPreset.SetSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ae23e0
};

// Class AudioMixer.AudioGenerator
// Size: 0x120 (Inherited: 0xa0)
struct UAudioGenerator : UObject {
	char pad_a0[0x80]; // 0xa0(0x80)
};

// Class AudioMixer.QuartzClockHandle
// Size: 0x260 (Inherited: 0xa0)
struct UQuartzClockHandle : UObject {
	char pad_a0[0x1c0]; // 0xa0(0x1c0)

	void UnsubscribeFromTimeDivision(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization InQuantizationBoundary, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2acfa10
	void UnsubscribeFromAllTimeDivisions(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad5660
	void SubscribeToQuantizationEvent(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization InQuantizationBoundary, struct FDelegate& OnQuantizationEvent, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ae07f0
	void SubscribeToAllQuantizationEvents(struct UObject* WorldContextObject, struct FDelegate& OnQuantizationEvent, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2adf030
	void StopClock(struct UObject* WorldContextObject, bool CancelPendingEvents, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.StopClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2add200
	void StartOtherClock(struct UObject* WorldContextObject, struct FName OtherClockName, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate); // Function AudioMixer.QuartzClockHandle.StartOtherClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad80c0
	void StartClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.StartClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ac7020
	void SetTicksPerSecond(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float TicksPerSecond); // Function AudioMixer.QuartzClockHandle.SetTicksPerSecond // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ac1b90
	void SetThirtySecondNotesPerMinute(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float ThirtySecondsNotesPerMinute); // Function AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ac0720
	void SetSecondsPerTick(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float SecondsPerTick); // Function AudioMixer.QuartzClockHandle.SetSecondsPerTick // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2abf310
	void SetMillisecondsPerTick(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float MillisecondsPerTick); // Function AudioMixer.QuartzClockHandle.SetMillisecondsPerTick // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad8b30
	void SetBeatsPerMinute(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float BeatsPerMinute); // Function AudioMixer.QuartzClockHandle.SetBeatsPerMinute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad3bf0
	void ResumeClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.ResumeClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ac7020
	void ResetTransportQuantized(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.ResetTransportQuantized // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ae33b0
	void ResetTransport(struct UObject* WorldContextObject, struct FDelegate& InDelegate); // Function AudioMixer.QuartzClockHandle.ResetTransport // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2acd410
	void PauseClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.PauseClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2adfc70
	void NotifyOnQuantizationBoundary(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate, float InMsOffset); // Function AudioMixer.QuartzClockHandle.NotifyOnQuantizationBoundary // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ada470
	bool IsClockRunning(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.IsClockRunning // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ae7090
	float GetTicksPerSecond(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetTicksPerSecond // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ac8c40
	float GetThirtySecondNotesPerMinute(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ae7230
	float GetSecondsPerTick(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetSecondsPerTick // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2acd520
	float GetMillisecondsPerTick(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetMillisecondsPerTick // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ada080
	float GetEstimatedRunTime(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetEstimatedRunTime // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad3960
	float GetDurationOfQuantizationTypeInSeconds(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization& QuantizationType, float Multiplier); // Function AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ad6630
	struct FQuartzTransportTimeStamp GetCurrentTimestamp(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetCurrentTimestamp // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2aeddd0
	float GetBeatsPerMinute(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetBeatsPerMinute // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2aebe70
	float GetBeatProgressPercent(enum class EQuartzCommandQuantization QuantizationBoundary, float PhaseOffset, float MsOffset); // Function AudioMixer.QuartzClockHandle.GetBeatProgressPercent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2add3e0
};

// Class AudioMixer.QuartzSubsystem
// Size: 0xd0 (Inherited: 0xb0)
struct UQuartzSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x20]; // 0xb0(0x20)

	bool IsQuartzEnabled(); // Function AudioMixer.QuartzSubsystem.IsQuartzEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ae8f50
	bool IsClockRunning(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.IsClockRunning // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ac91c0
	float GetRoundTripMinLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetRoundTripMinLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad53c0
	float GetRoundTripMaxLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad2760
	float GetRoundTripAverageLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ac4a90
	struct UQuartzClockHandle* GetHandleForClock(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.GetHandleForClock // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2aec3d0
	float GetGameThreadToAudioRenderThreadMinLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad8420
	float GetGameThreadToAudioRenderThreadMaxLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad8420
	float GetGameThreadToAudioRenderThreadAverageLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ae3d10
	float GetEstimatedClockRunTime(struct UObject* WorldContextObject, struct FName& InClockName); // Function AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2aefdf0
	float GetDurationOfQuantizationTypeInSeconds(struct UObject* WorldContextObject, struct FName ClockName, enum class EQuartzCommandQuantization& QuantizationType, float Multiplier); // Function AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ae12b0
	struct FQuartzTransportTimeStamp GetCurrentClockTimestamp(struct UObject* WorldContextObject, struct FName& InClockName); // Function AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ae8da0
	float GetAudioRenderThreadToGameThreadMinLatency(); // Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2aeb3f0
	float GetAudioRenderThreadToGameThreadMaxLatency(); // Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad5950
	float GetAudioRenderThreadToGameThreadAverageLatency(); // Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2acc750
	bool DoesClockExist(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.DoesClockExist // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ae51a0
	void DeleteClockByName(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.DeleteClockByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ae31a0
	void DeleteClockByHandle(struct UObject* WorldContextObject, struct UQuartzClockHandle*& InClockHandle); // Function AudioMixer.QuartzSubsystem.DeleteClockByHandle // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2ac7590
	struct UQuartzClockHandle* CreateNewClock(struct UObject* WorldContextObject, struct FName ClockName, struct FQuartzClockSettings InSettings, bool bOverrideSettingsIfClockExists, bool bUseAudioEngineClockManager); // Function AudioMixer.QuartzSubsystem.CreateNewClock // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2ad11b0
};

