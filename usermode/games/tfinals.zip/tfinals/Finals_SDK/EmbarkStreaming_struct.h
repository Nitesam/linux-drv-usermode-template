// Enum EmbarkStreaming.EEmbarkStreamingFilter
enum class EEmbarkStreamingFilter : uint8_t {
	None = 0,
	Server = 1,
	Editor = 2,
	Commandlet = 4,
	EEmbarkStreamingFilter_MAX = 5
};

// Enum EmbarkStreaming.EEmbarkStreamingFlushMode
enum class EEmbarkStreamingFlushMode : uint8_t {
	KickRequests = 0,
	RunCallbacks = 1,
	EEmbarkStreamingFlushMode_MAX = 2
};

// ScriptStruct EmbarkStreaming.EmbarkStreamingBlockOnLoadScope
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkStreamingBlockOnLoadScope {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkStreaming.EmbarkStreamingDontBlockOnLoadScope
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkStreamingDontBlockOnLoadScope {
	char pad_0[0x10]; // 0x00(0x10)
};

