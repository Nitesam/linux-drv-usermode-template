// Class EmbarkAntiCheat.EmbarkStatManagerWorker
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkStatManagerWorker : UObject {
	struct TArray<struct FEmbarkStatManagerData> AllPlayerHistory; // 0x98(0x10)
};

// Class EmbarkAntiCheat.EmbarkStatManagerDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStatManagerDataMixinLibrary : UObject {

	struct FEmbarkStatManagerSnapshot RequestNextMutableSnapshot(struct FEmbarkStatManagerData& TelemetryData); // Function EmbarkAntiCheat.EmbarkStatManagerDataMixinLibrary.RequestNextMutableSnapshot // (Final|Native|Static|Public|HasOutParms) // @ game+0x8cbd0c0
};

// Class EmbarkAntiCheat.EmbarkStatManagerBase
// Size: 0x4f0 (Inherited: 0x3a0)
struct AEmbarkStatManagerBase : AEmbarkGlobalActor {
	char pad_3a0[0x130]; // 0x3a0(0x130)
	struct UEmbarkStatManagerWorker* TelemetryWorkerData; // 0x4d0(0x08)
	struct TArray<struct APlayerController*> RegisteredControllers; // 0x4d8(0x10)
	char pad_4e8[0x8]; // 0x4e8(0x08)

	bool RequestKillDumpPio(struct APlayerController* Killer, struct APlayerController* Victim); // Function EmbarkAntiCheat.EmbarkStatManagerBase.RequestKillDumpPio // (Final|Native|Public) // @ game+0x8cbd810
	bool RequestKillDump(struct APlayerController* Killer, struct APlayerController* Victim); // Function EmbarkAntiCheat.EmbarkStatManagerBase.RequestKillDump // (Final|Native|Public) // @ game+0x8cbd2e0
	void RegisterController(struct APlayerController* Controller); // Function EmbarkAntiCheat.EmbarkStatManagerBase.RegisterController // (Final|Native|Public) // @ game+0x8cbd480
	void ReceiveUpdatePerPlayerSnapshotData(float DeltaSeconds, struct TArray<struct APlayerController*>& AllRegisteredControllers, struct UEmbarkStatManagerWorker* AllWorkerData); // Function EmbarkAntiCheat.EmbarkStatManagerBase.ReceiveUpdatePerPlayerSnapshotData // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnControllerRegistered(struct APlayerController* Controller, int32_t ControllerIdx); // Function EmbarkAntiCheat.EmbarkStatManagerBase.ReceiveOnControllerRegistered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnControllerDeregistered(struct APlayerController* Controller, int32_t ControllerIdx); // Function EmbarkAntiCheat.EmbarkStatManagerBase.ReceiveOnControllerDeregistered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool GetStatManagerDataForController(struct APlayerController* Controller, struct FEmbarkStatManagerData& KillTelemetry); // Function EmbarkAntiCheat.EmbarkStatManagerBase.GetStatManagerDataForController // (Final|Native|Public|HasOutParms|Const) // @ game+0x8cbda50
	struct TArray<struct FEmbarkStatManagerData> GetMutableTelemetryData(); // Function EmbarkAntiCheat.EmbarkStatManagerBase.GetMutableTelemetryData // (Final|Native|Protected) // @ game+0x8cbf0b0
	float GetLatency(struct APlayerController* Controller); // Function EmbarkAntiCheat.EmbarkStatManagerBase.GetLatency // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8cbeef0
	int32_t GetControllerIndex(struct APlayerController* Controller); // Function EmbarkAntiCheat.EmbarkStatManagerBase.GetControllerIndex // (Final|Native|Protected|Const) // @ game+0x8cba9b0
	void DeregisterController(struct APlayerController* Controller); // Function EmbarkAntiCheat.EmbarkStatManagerBase.DeregisterController // (Final|Native|Public) // @ game+0x8cbf3e0
};

// Class EmbarkAntiCheat.MockEmbarkAntiCheatTelemetryDumper
// Size: 0x4f0 (Inherited: 0x4f0)
struct AMockEmbarkAntiCheatTelemetryDumper : AEmbarkStatManagerBase {
};

