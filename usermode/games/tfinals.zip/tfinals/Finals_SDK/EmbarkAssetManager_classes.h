// Class EmbarkAssetManager.EmbarkAssetManager
// Size: 0x540 (Inherited: 0x540)
struct UEmbarkAssetManager : UAssetManager {
};

// Class EmbarkAssetManager.EmbarkAssetManagerSettings
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkAssetManagerSettings : UDeveloperSettings {
};

