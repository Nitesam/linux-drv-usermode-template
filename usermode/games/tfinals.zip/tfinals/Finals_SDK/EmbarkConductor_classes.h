// Class EmbarkConductor.EmbarkConductor_TickCohort_PrePhysics
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConductor_TickCohort_PrePhysics : UObject {
};

// Class EmbarkConductor.EmbarkConductor_TickCohort_DuringPhysics
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConductor_TickCohort_DuringPhysics : UObject {
};

// Class EmbarkConductor.EmbarkConductor_TickCohort_PostPhysics
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConductor_TickCohort_PostPhysics : UObject {
};

// Class EmbarkConductor.EmbarkConductor_TickCohort_PostUpdateWork
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConductor_TickCohort_PostUpdateWork : UObject {
};

// Class EmbarkConductor.EmbarkConductor_TickCohort_LastDemotable
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConductor_TickCohort_LastDemotable : UObject {
};

// Class EmbarkConductor.EmbarkConductor
// Size: 0x2550 (Inherited: 0xa0)
struct UEmbarkConductor : UWorldSubsystem {
	struct FEmbarkConductorRequestedTickCohorts RequestedTickCohortsPerGroup[0x8]; // 0xa0(0x80)
	struct TMap<struct FName, int32_t> RequestedTickDependencyLookup; // 0x120(0x50)
	int32_t RequestedTickDependencyCount; // 0x170(0x04)
	int32_t RequestedTickDependencySlots[0x40]; // 0x174(0x100)
	char pad_274[0x22dc]; // 0x274(0x22dc)

	void RemoveFromTickGroup(enum class ETickingGroup TickGroup, struct FEmbarkConductorTickHandle& Handle, struct UObject* ContextObject); // Function EmbarkConductor.EmbarkConductor.RemoveFromTickGroup // (Final|Native|Static|Public|HasOutParms) // @ game+0x683dbb0
	void RemoveFromTickCohort(struct UObject* Cohort, struct FEmbarkConductorTickHandle& Handle, struct UObject* ContextObject); // Function EmbarkConductor.EmbarkConductor.RemoveFromTickCohort // (Final|Native|Static|Public|HasOutParms) // @ game+0x6844f00
	void EndSequence(); // Function EmbarkConductor.EmbarkConductor.EndSequence // (Final|Native|Protected) // @ game+0x6843250
	void EndParallel(); // Function EmbarkConductor.EmbarkConductor.EndParallel // (Final|Native|Protected) // @ game+0x6843900
	void EndGroup(); // Function EmbarkConductor.EmbarkConductor.EndGroup // (Final|Native|Protected) // @ game+0x683e5e0
	void BeginSequence(); // Function EmbarkConductor.EmbarkConductor.BeginSequence // (Final|Native|Protected) // @ game+0x6843890
	void BeginParallel(); // Function EmbarkConductor.EmbarkConductor.BeginParallel // (Final|Native|Protected) // @ game+0x6843870
	void BeginGroup(enum class ETickingGroup TickGroup, struct FName Dependency); // Function EmbarkConductor.EmbarkConductor.BeginGroup // (Final|Native|Protected) // @ game+0x6841ea0
	struct FEmbarkConductorTickHandle AddToTickGroup(enum class ETickingGroup TickGroup, struct FDelegate& Delegate, struct UObject* ContextObject, float Interval); // Function EmbarkConductor.EmbarkConductor.AddToTickGroup // (Final|Native|Static|Public|HasOutParms) // @ game+0x68441d0
	struct FEmbarkConductorTickHandle AddToTickCohort(struct UObject* Cohort, struct FDelegate& Delegate, struct UObject* ContextObject, float Interval); // Function EmbarkConductor.EmbarkConductor.AddToTickCohort // (Final|Native|Static|Public|HasOutParms) // @ game+0x683d240
	void AddCohort(struct UObject* Cohort); // Function EmbarkConductor.EmbarkConductor.AddCohort // (Final|Native|Protected) // @ game+0x683ea90
};

