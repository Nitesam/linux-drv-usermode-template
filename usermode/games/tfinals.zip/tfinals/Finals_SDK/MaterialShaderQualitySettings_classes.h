// Class MaterialShaderQualitySettings.ShaderPlatformQualitySettings
// Size: 0xd0 (Inherited: 0xa0)
struct UShaderPlatformQualitySettings : UObject {
	struct FMaterialQualityOverrides QualityOverrides[0x4]; // 0x98(0x20)
	char pad_c0[0x10]; // 0xc0(0x10)
};

// Class MaterialShaderQualitySettings.MaterialShaderQualitySettings
// Size: 0xf0 (Inherited: 0xa0)
struct UMaterialShaderQualitySettings : UObject {
	struct TMap<struct FName, struct UShaderPlatformQualitySettings*> ForwardSettingMap; // 0x98(0x50)
};

