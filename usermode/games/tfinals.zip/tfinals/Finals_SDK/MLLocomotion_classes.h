// Class MLLocomotion.FloatImage
// Size: 0x3d0 (Inherited: 0x350)
struct UFloatImage : UImage {
	struct FLinearColor LowColor; // 0x348(0x10)
	struct FLinearColor HighColor; // 0x358(0x10)
	struct FLinearColor LowGradient; // 0x368(0x10)
	struct FLinearColor HighGradient; // 0x378(0x10)
	struct FVector2D Range; // 0x388(0x10)
	struct UTexture2D* Texture; // 0x398(0x08)
	struct TArray<float> Values; // 0x3a0(0x10)
	char pad_3b8[0x18]; // 0x3b8(0x18)

	void UpdateData(struct TArray<float>& Values, int32_t Stride, int32_t Offset); // Function MLLocomotion.FloatImage.UpdateData // (Final|Native|Public|HasOutParms) // @ game+0x90439e0
	void SetSize(int32_t Width, int32_t Height); // Function MLLocomotion.FloatImage.SetSize // (Final|Native|Public) // @ game+0x903ccb0
};

// Class MLLocomotion.MLObservationDebugConfig
// Size: 0x110 (Inherited: 0xc0)
struct UMLObservationDebugConfig : UMLModuleConfiguration {
	struct FLinearColor LowRangeColor; // 0xb8(0x10)
	struct FLinearColor HighRangeColor; // 0xc8(0x10)
	struct FLinearColor LowColor; // 0xd8(0x10)
	struct FLinearColor HighColor; // 0xe8(0x10)
	struct FVector2D Range; // 0xf8(0x10)
};

// Class MLLocomotion.MLObservationDebugModule
// Size: 0x100 (Inherited: 0xd0)
struct UMLObservationDebugModule : UMLModule {
	struct FDelegate ObservationSetDelegate; // 0xd0(0x10)
	char pad_e0[0x8]; // 0xe0(0x08)
	struct FMLObsDebugReplication ReplicationBuffer; // 0xe8(0x18)
};

// Class MLLocomotion.MLSphericalHarmonicSensorConfig
// Size: 0x100 (Inherited: 0xc0)
struct UMLSphericalHarmonicSensorConfig : UMLModuleConfiguration {
	int32_t LatitudeCount; // 0xb8(0x04)
	int32_t MinLongitudeCount; // 0xbc(0x04)
	int32_t MaxLongitudeCount; // 0xc0(0x04)
	int32_t RaysPerFrame; // 0xc4(0x04)
	float MaxRayDistanceAU; // 0xc8(0x04)
	float PriorityRaysFactor; // 0xcc(0x04)
	bool bUseJitteredRays; // 0xd0(0x01)
	float JitterStrength; // 0xd4(0x04)
	float DecayFactor; // 0xd8(0x04)
	float VerticalOffsetAU; // 0xdc(0x04)
	int32_t SphericalHarmonicDegree; // 0xe0(0x04)
	struct FString ObservationKey; // 0xe8(0x10)
	char pad_f9[0x7]; // 0xf9(0x07)
};

// Class MLLocomotion.MLSphericalHarmonicSensorModule
// Size: 0x1b0 (Inherited: 0xd0)
struct UMLSphericalHarmonicSensorModule : UMLModule {
	char pad_d0[0xe0]; // 0xd0(0xe0)
};

// Class MLLocomotion.MLVisionSensorConfig
// Size: 0x120 (Inherited: 0xc0)
struct UMLVisionSensorConfig : UMLModuleConfiguration {
	struct FName ComponentTag; // 0xb8(0x08)
	int32_t GridSize; // 0xc0(0x04)
	float GridRange; // 0xc4(0x04)
	float HorizontalVisionRange; // 0xc8(0x04)
	float VerticalVisionRange; // 0xcc(0x04)
	float DebugLineThickness; // 0xd0(0x04)
	float DebugNormalLength; // 0xd4(0x04)
	bool bUseSqrt; // 0xd8(0x01)
	bool bUseDictObservation; // 0xd9(0x01)
	bool bUseSecondaryComponentGridObs; // 0xda(0x01)
	bool bUseSecondaryComponentFeatureObs; // 0xdb(0x01)
	bool bUseBilinearFilter; // 0xdc(0x01)
	int32_t PerFrameRayLimit; // 0xe0(0x04)
	float CacheScaleRatio; // 0xe4(0x04)
	float InternalResolutionRatio; // 0xe8(0x04)
	struct FVector ActorBounds; // 0xf0(0x18)
	enum class ETraceTypeQuery TraceChannel; // 0x108(0x01)
	char pad_10a[0x2]; // 0x10a(0x02)
	struct FName VisionTraceChannel; // 0x10c(0x08)
	bool bTraceComplex; // 0x114(0x01)
	char pad_115[0x3]; // 0x115(0x03)
	float TraceHeight; // 0x118(0x04)
	bool bUseBackToFront; // 0x11c(0x01)
	char pad_11d[0x3]; // 0x11d(0x03)
};

// Class MLLocomotion.MLVisionSensorModule
// Size: 0x220 (Inherited: 0xd0)
struct UMLVisionSensorModule : UMLModule {
	struct TArray<struct FVisionChannel> SecondaryChannels; // 0xd0(0x10)
	struct UEmbarkGridQueryBuffer* GridBuffer; // 0xe0(0x08)
	struct FMLVisionDebug ReplicationBuffer; // 0xe8(0x88)
	char pad_170[0xb0]; // 0x170(0xb0)

	void SetSamplingType(enum class EMLVisionSamplingType Mode); // Function MLLocomotion.MLVisionSensorModule.SetSamplingType // (Final|Native|Public|BlueprintCallable) // @ game+0x9049cb0
	void SetSamplingPattern(struct TArray<struct FVector>& Points); // Function MLLocomotion.MLVisionSensorModule.SetSamplingPattern // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9049bc0
	void ReceiveUpdateSecondaryChannels(); // Function MLLocomotion.MLVisionSensorModule.ReceiveUpdateSecondaryChannels // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct FTransform CalculateVisionTransform(); // Function MLLocomotion.MLVisionSensorModule.CalculateVisionTransform // (Native|Event|Public|HasDefaults|BlueprintEvent) // @ game+0x904df80
};

// Class MLLocomotion.ObservationImageTooltipWidget
// Size: 0x390 (Inherited: 0x350)
struct UObservationImageTooltipWidget : UUserWidget {
	struct UTextBlock* FeatureNameTextBlock; // 0x348(0x08)
	struct UTextBlock* ValueTextBlock; // 0x350(0x08)
	struct UTextBlock* IndexTextBlock; // 0x358(0x08)
	char pad_368[0x28]; // 0x368(0x28)
};

// Class MLLocomotion.ObservationWidget
// Size: 0x4f0 (Inherited: 0x350)
struct UObservationWidget : UUserWidget {
	struct UVerticalBox* VerticalContainer; // 0x348(0x08)
	struct TMap<struct FString, struct UHorizontalBox*> FeatureBoxes; // 0x350(0x50)
	struct TMap<char, struct UButton*> ColorButtons; // 0x3a0(0x50)
	struct TMap<struct FString, struct UFloatImage*> Images; // 0x3f0(0x50)
	char pad_448[0x48]; // 0x448(0x48)
	struct UMLObservationDebugModule* CurrentModule; // 0x490(0x08)
	struct UObservationImageTooltipWidget* ImageToolTipWidget; // 0x498(0x08)
	char pad_4a0[0x50]; // 0x4a0(0x50)

	void UpdateObservation(struct TArray<struct FObservationSetEntry>& Entries); // Function MLLocomotion.ObservationWidget.UpdateObservation // (Final|Native|Public|HasOutParms) // @ game+0x904a4c0
	void Setup(struct UMLObservationDebugModule* Module); // Function MLLocomotion.ObservationWidget.Setup // (Final|Native|Public) // @ game+0x9048280
	void OnUnderClicked(); // Function MLLocomotion.ObservationWidget.OnUnderClicked // (Final|Native|Private) // @ game+0x904d420
	void OnOverClicked(); // Function MLLocomotion.ObservationWidget.OnOverClicked // (Final|Native|Private) // @ game+0x9044d00
	void OnLowClicked(); // Function MLLocomotion.ObservationWidget.OnLowClicked // (Final|Native|Private) // @ game+0x90495d0
	void OnHighClicked(); // Function MLLocomotion.ObservationWidget.OnHighClicked // (Final|Native|Private) // @ game+0x904b6c0
};

