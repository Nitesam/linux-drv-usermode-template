// Class ImgMediaFactory.ImgMediaSettings
// Size: 0xe0 (Inherited: 0xa0)
struct UImgMediaSettings : UObject {
	struct FFrameRate DefaultFrameRate; // 0x98(0x08)
	bool BandwidthThrottlingEnabled; // 0xa0(0x01)
	float CacheBehindPercentage; // 0xa4(0x04)
	float CacheSizeGB; // 0xa8(0x04)
	int32_t CacheThreads; // 0xac(0x04)
	int32_t CacheThreadStackSizeKB; // 0xb0(0x04)
	float GlobalCacheSizeGB; // 0xb4(0x04)
	bool UseGlobalCache; // 0xb8(0x01)
	uint32_t ExrDecoderThreads; // 0xbc(0x04)
	struct FString DefaultProxy; // 0xc0(0x10)
	bool UseDefaultProxy; // 0xd0(0x01)
	char pad_d3[0xd]; // 0xd3(0x0d)
};

