// Class EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent
// Size: 0x250 (Inherited: 0x160)
struct UEmbarkPerformanceRecorderComponent : UActorComponent {
	char pad_160[0x8]; // 0x160(0x08)
	float BadFrameTelemetryThresholdMS; // 0x168(0x04)
	bool bAutoStart; // 0x16c(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
	float TargetFrameRate; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	uint64_t RollingWindowSize; // 0x178(0x08)
	uint64_t FrameCountHint; // 0x180(0x08)
	struct TArray<char> FrameTimeData; // 0x188(0x10)
	struct TMap<struct UNetDriver*, struct FEmbarkNetDriverPerformanceRecording> NetDriverFlushTimeData; // 0x198(0x50)
	struct TArray<char> TotalSaturatedConnectionsData; // 0x1e8(0x10)
	int32_t FirstFrame; // 0x1f8(0x04)
	int32_t RollingBadFrames; // 0x1fc(0x04)
	int32_t TotalBadFrames; // 0x200(0x04)
	float SpikeDecayHalfLifeSec; // 0x204(0x04)
	char pad_208[0x48]; // 0x208(0x48)

	void StopRecording(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.StopRecording // (Final|Native|Public|BlueprintCallable) // @ game+0x5d30a20
	void StartRecording(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.StartRecording // (Final|Native|Public|BlueprintCallable) // @ game+0x5d30af0
	void SendServerPerformanceTelemetryEvent(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.SendServerPerformanceTelemetryEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x29fb8f0
	bool IsUsingPerformanceRatios(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.IsUsingPerformanceRatios // (Final|Native|Public|Const) // @ game+0x5d33330
	float GetServerSpikeRatio(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.GetServerSpikeRatio // (Final|Native|Public|Const) // @ game+0x5d2fea0
	float GetServerP95Ratio(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.GetServerP95Ratio // (Final|Native|Public|Const) // @ game+0x5d31160
	float GetServerMeanRatio(); // Function EmbarkPerformanceRecorder.EmbarkPerformanceRecorderComponent.GetServerMeanRatio // (Final|Native|Public|Const) // @ game+0x5d30a60
};

