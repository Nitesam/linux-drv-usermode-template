// Class CommonUI.CommonBoundActionButtonInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonBoundActionButtonInterface : UInterface {
};

// Class CommonUI.AnalogSlider
// Size: 0x7c0 (Inherited: 0x7a0)
struct UAnalogSlider : USlider {
	struct FMulticastInlineDelegate OnAnalogCapture; // 0x7a0(0x10)
	char pad_7b0[0x10]; // 0x7b0(0x10)
};

// Class CommonUI.CommonActionHandlerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonActionHandlerInterface : UInterface {
};

// Class CommonUI.CommonActionWidget
// Size: 0x500 (Inherited: 0x1f0)
struct UCommonActionWidget : UWidget {
	struct FMulticastInlineDelegate OnInputMethodChanged; // 0x1f0(0x10)
	struct FSlateBrush ProgressMaterialBrush; // 0x200(0xd0)
	struct FName ProgressMaterialParam; // 0x2d0(0x08)
	char pad_2d8[0x8]; // 0x2d8(0x08)
	struct FSlateBrush IconRimBrush; // 0x2e0(0xd0)
	struct TArray<struct FDataTableRowHandle> InputActions; // 0x3b0(0x10)
	struct UInputAction* EnhancedInputAction; // 0x3c0(0x08)
	char pad_3c8[0x8]; // 0x3c8(0x08)
	struct UMaterialInstanceDynamic* ProgressDynamicMaterial; // 0x3d0(0x08)
	char pad_3d8[0x128]; // 0x3d8(0x128)

	void SetInputActions(struct TArray<struct FDataTableRowHandle> NewInputActions); // Function CommonUI.CommonActionWidget.SetInputActions // (Final|Native|Public|BlueprintCallable) // @ game+0x5085b40
	void SetInputAction(struct FDataTableRowHandle InputActionRow); // Function CommonUI.CommonActionWidget.SetInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x5072c10
	void SetIconRimBrush(struct FSlateBrush InIconRimBrush); // Function CommonUI.CommonActionWidget.SetIconRimBrush // (Final|Native|Public|BlueprintCallable) // @ game+0x506c180
	void SetEnhancedInputAction(struct UInputAction* InInputAction); // Function CommonUI.CommonActionWidget.SetEnhancedInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x50bb3c0
	void OnInputMethodChanged__DelegateSignature(bool bUsingGamepad); // DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	bool IsHeldAction(); // Function CommonUI.CommonActionWidget.IsHeldAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5089d50
	struct FSlateBrush GetIcon(); // Function CommonUI.CommonActionWidget.GetIcon // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50387e0
	struct FText GetDisplayText(); // Function CommonUI.CommonActionWidget.GetDisplayText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5083720
};

// Class CommonUI.CommonUserWidget
// Size: 0x370 (Inherited: 0x350)
struct UCommonUserWidget : UUserWidget {
	bool bDisplayInActionBar; // 0x348(0x01)
	bool bConsumePointerInput; // 0x349(0x01)
	char pad_352[0x1e]; // 0x352(0x1e)

	void SetConsumePointerInput(bool bInConsumePointerInput); // Function CommonUI.CommonUserWidget.SetConsumePointerInput // (Final|Native|Public|BlueprintCallable) // @ game+0x509abe0
};

// Class CommonUI.CommonActivatableWidget
// Size: 0x4a0 (Inherited: 0x370)
struct UCommonActivatableWidget : UCommonUserWidget {
	bool bIsBackHandler; // 0x370(0x01)
	bool bIsBackActionDisplayedInActionBar; // 0x371(0x01)
	bool bAutoActivate; // 0x372(0x01)
	bool bSupportsActivationFocus; // 0x373(0x01)
	bool bIsModal; // 0x374(0x01)
	bool bAutoRestoreFocus; // 0x375(0x01)
	bool bOverrideActionDomain; // 0x376(0x01)
	char pad_377[0x1]; // 0x377(0x01)
	struct UInputMappingContext* InputMapping; // 0x378(0x08)
	int32_t InputMappingPriority; // 0x380(0x04)
	char pad_384[0x4]; // 0x384(0x04)
	struct TSoftObjectPtr<UCommonInputActionDomain> ActionDomainOverride; // 0x388(0x28)
	struct FMulticastInlineDelegate BP_OnWidgetActivated; // 0x3b0(0x10)
	struct FMulticastInlineDelegate BP_OnWidgetDeactivated; // 0x3c0(0x10)
	bool bIsActive; // 0x3d0(0x01)
	char pad_3d1[0x7]; // 0x3d1(0x07)
	struct TArray<struct TWeakObjectPtr<struct UCommonActivatableWidget>> VisibilityBoundWidgets; // 0x3d8(0x10)
	char pad_3e8[0xa8]; // 0x3e8(0xa8)
	bool bSetVisibilityOnActivated; // 0x490(0x01)
	enum class ESlateVisibility ActivatedVisibility; // 0x491(0x01)
	bool bSetVisibilityOnDeactivated; // 0x492(0x01)
	enum class ESlateVisibility DeactivatedVisibility; // 0x493(0x01)
	char pad_494[0xc]; // 0x494(0x0c)

	void SetBindVisibilities(enum class ESlateVisibility OnActivatedVisibility, enum class ESlateVisibility OnDeactivatedVisibility, bool bInAllActive); // Function CommonUI.CommonActivatableWidget.SetBindVisibilities // (Final|Native|Public|BlueprintCallable) // @ game+0x50af350
	bool IsActivated(); // Function CommonUI.CommonActivatableWidget.IsActivated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x505a690
	struct UWidget* GetDesiredFocusTarget(); // Function CommonUI.CommonActivatableWidget.GetDesiredFocusTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5078ba0
	void DeactivateWidget(); // Function CommonUI.CommonActivatableWidget.DeactivateWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x504d7b0
	bool BP_OnHandleBackAction(); // Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnDeactivated(); // Function CommonUI.CommonActivatableWidget.BP_OnDeactivated // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnActivated(); // Function CommonUI.CommonActivatableWidget.BP_OnActivated // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	struct FUIInputConfig BP_GetDesiredInputConfig(); // Function CommonUI.CommonActivatableWidget.BP_GetDesiredInputConfig // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	struct UWidget* BP_GetDesiredFocusTarget(); // Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	void BindVisibilityToActivation(struct UCommonActivatableWidget* ActivatableWidget); // Function CommonUI.CommonActivatableWidget.BindVisibilityToActivation // (Final|Native|Public|BlueprintCallable) // @ game+0x507e450
	void ActivateWidget(); // Function CommonUI.CommonActivatableWidget.ActivateWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x5070850
};

// Class CommonUI.CommonAnimatedSwitcher
// Size: 0x290 (Inherited: 0x220)
struct UCommonAnimatedSwitcher : UWidgetSwitcher {
	char pad_220[0x30]; // 0x220(0x30)
	enum class ECommonSwitcherTransition TransitionType; // 0x250(0x01)
	enum class ETransitionCurve TransitionCurveType; // 0x251(0x01)
	char pad_252[0x2]; // 0x252(0x02)
	float TransitionDuration; // 0x254(0x04)
	char pad_258[0x38]; // 0x258(0x38)

	void SetDisableTransitionAnimation(bool bDisableAnimation); // Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x505b380
	bool IsTransitionPlaying(); // Function CommonUI.CommonAnimatedSwitcher.IsTransitionPlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b6380
	bool IsCurrentlySwitching(); // Function CommonUI.CommonAnimatedSwitcher.IsCurrentlySwitching // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5036d70
	bool HasWidgets(); // Function CommonUI.CommonAnimatedSwitcher.HasWidgets // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x29e05b0
	void ActivatePreviousWidget(bool bCanWrap); // Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x50519b0
	void ActivateNextWidget(bool bCanWrap); // Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x508aca0
};

// Class CommonUI.CommonActivatableWidgetSwitcher
// Size: 0x2a0 (Inherited: 0x290)
struct UCommonActivatableWidgetSwitcher : UCommonAnimatedSwitcher {
	char pad_290[0x10]; // 0x290(0x10)
};

// Class CommonUI.CommonBorderStyle
// Size: 0x170 (Inherited: 0xa0)
struct UCommonBorderStyle : UObject {
	struct FSlateBrush Background; // 0xa0(0xd0)

	void GetBackgroundBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonBorderStyle.GetBackgroundBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x506fd10
};

// Class CommonUI.CommonBorder
// Size: 0x3d0 (Inherited: 0x3b0)
struct UCommonBorder : UBorder {
	struct UCommonBorderStyle* Style; // 0x3a8(0x08)
	bool bReducePaddingBySafezone; // 0x3b0(0x01)
	struct FMargin MinimumPadding; // 0x3b4(0x10)
	char pad_3c9[0x7]; // 0x3c9(0x07)

	void SetStyle(struct UCommonBorderStyle* InStyle); // Function CommonUI.CommonBorder.SetStyle // (Final|Native|Public|BlueprintCallable) // @ game+0x5095af0
};

// Class CommonUI.CommonButtonStyle
// Size: 0x820 (Inherited: 0xa0)
struct UCommonButtonStyle : UObject {
	bool bSingleMaterial; // 0x98(0x01)
	struct FSlateBrush SingleMaterialBrush; // 0xa0(0xd0)
	struct FSlateBrush NormalBase; // 0x170(0xd0)
	struct FSlateBrush NormalHovered; // 0x240(0xd0)
	struct FSlateBrush NormalPressed; // 0x310(0xd0)
	struct FSlateBrush SelectedBase; // 0x3e0(0xd0)
	struct FSlateBrush SelectedHovered; // 0x4b0(0xd0)
	struct FSlateBrush SelectedPressed; // 0x580(0xd0)
	struct FSlateBrush Disabled; // 0x650(0xd0)
	struct FMargin ButtonPadding; // 0x720(0x10)
	struct FMargin CustomPadding; // 0x730(0x10)
	int32_t MinWidth; // 0x740(0x04)
	int32_t MinHeight; // 0x744(0x04)
	struct UCommonTextStyle* NormalTextStyle; // 0x748(0x08)
	struct UCommonTextStyle* NormalHoveredTextStyle; // 0x750(0x08)
	struct UCommonTextStyle* SelectedTextStyle; // 0x758(0x08)
	struct UCommonTextStyle* SelectedHoveredTextStyle; // 0x760(0x08)
	struct UCommonTextStyle* DisabledTextStyle; // 0x768(0x08)
	struct FSlateSound PressedSlateSound; // 0x770(0x18)
	struct FCommonButtonStyleOptionalSlateSound SelectedPressedSlateSound; // 0x788(0x20)
	struct FCommonButtonStyleOptionalSlateSound LockedPressedSlateSound; // 0x7a8(0x20)
	struct FSlateSound HoveredSlateSound; // 0x7c8(0x18)
	struct FCommonButtonStyleOptionalSlateSound SelectedHoveredSlateSound; // 0x7e0(0x20)
	struct FCommonButtonStyleOptionalSlateSound LockedHoveredSlateSound; // 0x800(0x20)

	struct UCommonTextStyle* GetSelectedTextStyle(); // Function CommonUI.CommonButtonStyle.GetSelectedTextStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b9a30
	void GetSelectedPressedBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5055fb0
	struct UCommonTextStyle* GetSelectedHoveredTextStyle(); // Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b8c70
	void GetSelectedHoveredBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x509c230
	void GetSelectedBaseBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5056a10
	struct UCommonTextStyle* GetNormalTextStyle(); // Function CommonUI.CommonButtonStyle.GetNormalTextStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50adfc0
	void GetNormalPressedBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetNormalPressedBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5079e10
	struct UCommonTextStyle* GetNormalHoveredTextStyle(); // Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5061310
	void GetNormalHoveredBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5087c90
	void GetNormalBaseBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetNormalBaseBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x505d5d0
	void GetMaterialBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetMaterialBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x506fd10
	struct UCommonTextStyle* GetDisabledTextStyle(); // Function CommonUI.CommonButtonStyle.GetDisabledTextStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5044850
	void GetDisabledBrush(struct FSlateBrush& Brush); // Function CommonUI.CommonButtonStyle.GetDisabledBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x50ac360
	void GetCustomPadding(struct FMargin& OutCustomPadding); // Function CommonUI.CommonButtonStyle.GetCustomPadding // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x508a490
	void GetButtonPadding(struct FMargin& OutButtonPadding); // Function CommonUI.CommonButtonStyle.GetButtonPadding // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x503ccc0
};

// Class CommonUI.CommonButtonInternalBase
// Size: 0x700 (Inherited: 0x690)
struct UCommonButtonInternalBase : UButton {
	char pad_690[0x8]; // 0x690(0x08)
	struct FMulticastInlineDelegate OnDoubleClicked; // 0x698(0x10)
	char pad_6a8[0x20]; // 0x6a8(0x20)
	int32_t MinWidth; // 0x6c8(0x04)
	int32_t MinHeight; // 0x6cc(0x04)
	bool bButtonEnabled; // 0x6d0(0x01)
	bool bInteractionEnabled; // 0x6d1(0x01)
	char pad_6d2[0x2e]; // 0x6d2(0x2e)
};

// Class CommonUI.CommonButtonBase
// Size: 0x1610 (Inherited: 0x370)
struct UCommonButtonBase : UCommonUserWidget {
	struct FWidgetEventField ClickEvent; // 0x370(0x01)
	char pad_371[0x3]; // 0x371(0x03)
	int32_t MinWidth; // 0x374(0x04)
	int32_t MinHeight; // 0x378(0x04)
	char pad_37c[0x4]; // 0x37c(0x04)
	struct UCommonButtonStyle* Style; // 0x380(0x08)
	bool bHideInputAction; // 0x388(0x01)
	char pad_389[0x7]; // 0x389(0x07)
	struct FSlateSound PressedSlateSoundOverride; // 0x390(0x18)
	struct FSlateSound HoveredSlateSoundOverride; // 0x3a8(0x18)
	struct FSlateSound SelectedPressedSlateSoundOverride; // 0x3c0(0x18)
	struct FSlateSound SelectedHoveredSlateSoundOverride; // 0x3d8(0x18)
	struct FSlateSound LockedPressedSlateSoundOverride; // 0x3f0(0x18)
	struct FSlateSound LockedHoveredSlateSoundOverride; // 0x408(0x18)
	char bApplyAlphaOnDisable : 1; // 0x420(0x01)
	char bLocked : 1; // 0x420(0x01)
	char bSelectable : 1; // 0x420(0x01)
	char bShouldSelectUponReceivingFocus : 1; // 0x420(0x01)
	char bInteractableWhenSelected : 1; // 0x420(0x01)
	char bToggleable : 1; // 0x420(0x01)
	char bTriggerClickedAfterSelection : 1; // 0x420(0x01)
	char bDisplayInputActionWhenNotInteractable : 1; // 0x420(0x01)
	char bHideInputActionWithKeyboard : 1; // 0x421(0x01)
	char bShouldUseFallbackDefaultInputAction : 1; // 0x421(0x01)
	char bRequiresHold : 1; // 0x421(0x01)
	char pad_421_3 : 5; // 0x421(0x01)
	char pad_422[0x6]; // 0x422(0x06)
	struct UCommonUIHoldData* HoldData; // 0x428(0x08)
	bool bSimulateHoverOnTouchInput; // 0x430(0x01)
	char pad_431[0x1]; // 0x431(0x01)
	enum class EButtonClickMethod ClickMethod; // 0x432(0x01)
	enum class EButtonTouchMethod TouchMethod; // 0x433(0x01)
	enum class EButtonPressMethod PressMethod; // 0x434(0x01)
	char pad_435[0x3]; // 0x435(0x03)
	int32_t InputPriority; // 0x438(0x04)
	char pad_43c[0x4]; // 0x43c(0x04)
	struct FDataTableRowHandle TriggeringInputAction; // 0x440(0x10)
	struct UInputAction* TriggeringEnhancedInputAction; // 0x450(0x08)
	char pad_458[0x10]; // 0x458(0x10)
	struct FMulticastInlineDelegate OnSelectedChangedBase; // 0x468(0x10)
	struct FMulticastInlineDelegate OnButtonBaseClicked; // 0x478(0x10)
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // 0x488(0x10)
	struct FMulticastInlineDelegate OnButtonBaseHovered; // 0x498(0x10)
	struct FMulticastInlineDelegate OnButtonBaseUnhovered; // 0x4a8(0x10)
	char pad_4b8[0x38]; // 0x4b8(0x38)
	bool bIsPersistentBinding; // 0x4f0(0x01)
	enum class ECommonInputMode InputModeOverride; // 0x4f1(0x01)
	char pad_4f2[0x36]; // 0x4f2(0x36)
	struct UMaterialInstanceDynamic* SingleMaterialStyleMID; // 0x528(0x08)
	struct FButtonStyle NormalStyle; // 0x530(0x3f0)
	struct FButtonStyle SelectedStyle; // 0x920(0x3f0)
	struct FButtonStyle DisabledStyle; // 0xd10(0x3f0)
	struct FButtonStyle LockedStyle; // 0x1100(0x3f0)
	char bStopDoubleClickPropagation : 1; // 0x14f0(0x01)
	char pad_14f0_1 : 7; // 0x14f0(0x01)
	char pad_14f1[0x117]; // 0x14f1(0x117)
	struct UCommonActionWidget* InputActionWidget; // 0x1608(0x08)

	void UpdateHoldData(enum class ECommonInputType CurrentInputType); // Function CommonUI.CommonButtonBase.UpdateHoldData // (Native|Protected) // @ game+0x505d0d0
	void StopDoubleClickPropagation(); // Function CommonUI.CommonButtonBase.StopDoubleClickPropagation // (Final|Native|Protected|BlueprintCallable) // @ game+0x5066b60
	void SetTriggeringInputAction(struct FDataTableRowHandle& InputActionRow); // Function CommonUI.CommonButtonBase.SetTriggeringInputAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50999e0
	void SetTriggeringEnhancedInputAction(struct UInputAction* InInputAction); // Function CommonUI.CommonButtonBase.SetTriggeringEnhancedInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x5079390
	void SetTriggeredInputAction(struct FDataTableRowHandle& InputActionRow); // Function CommonUI.CommonButtonBase.SetTriggeredInputAction // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5092290
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Function CommonUI.CommonButtonBase.SetTouchMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x5068850
	void SetStyle(struct UCommonButtonStyle* InStyle); // Function CommonUI.CommonButtonBase.SetStyle // (Final|Native|Public|BlueprintCallable) // @ game+0x5074d70
	void SetShouldUseFallbackDefaultInputAction(bool bInShouldUseFallbackDefaultInputAction); // Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x504c620
	void SetShouldSelectUponReceivingFocus(bool bInShouldSelectUponReceivingFocus); // Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x5097bf0
	void SetSelectedPressedSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetSelectedPressedSoundOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x50a4d30
	void SetSelectedInternal(bool bInSelected, bool bAllowSound, bool bBroadcast); // Function CommonUI.CommonButtonBase.SetSelectedInternal // (Final|Native|Protected|BlueprintCallable) // @ game+0x50736b0
	void SetSelectedHoveredSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetSelectedHoveredSoundOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x509ed80
	void SetPressMethod(enum class EButtonPressMethod InPressMethod); // Function CommonUI.CommonButtonBase.SetPressMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x5066510
	void SetPressedSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetPressedSoundOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x504e6f0
	void SetMinDimensions(int32_t InMinWidth, int32_t InMinHeight); // Function CommonUI.CommonButtonBase.SetMinDimensions // (Final|Native|Public|BlueprintCallable) // @ game+0x50bf700
	void SetLockedPressedSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetLockedPressedSoundOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x5055640
	void SetLockedHoveredSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetLockedHoveredSoundOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x50b2e60
	void SetIsToggleable(bool bInIsToggleable); // Function CommonUI.CommonButtonBase.SetIsToggleable // (Final|Native|Public|BlueprintCallable) // @ game+0x509ab40
	void SetIsSelected(bool InSelected, bool bGiveClickFeedback); // Function CommonUI.CommonButtonBase.SetIsSelected // (Final|Native|Public|BlueprintCallable) // @ game+0x50a2030
	void SetIsSelectable(bool bInIsSelectable); // Function CommonUI.CommonButtonBase.SetIsSelectable // (Final|Native|Public|BlueprintCallable) // @ game+0x50b7060
	void SetIsLocked(bool bInIsLocked); // Function CommonUI.CommonButtonBase.SetIsLocked // (Final|Native|Public|BlueprintCallable) // @ game+0x50ae060
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled); // Function CommonUI.CommonButtonBase.SetIsInteractionEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x50bf160
	void SetIsInteractableWhenSelected(bool bInInteractableWhenSelected); // Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected // (Final|Native|Public|BlueprintCallable) // @ game+0x504dcd0
	void SetIsFocusable(bool bInIsFocusable); // Function CommonUI.CommonButtonBase.SetIsFocusable // (Final|Native|Public|BlueprintCallable) // @ game+0x503d4c0
	void SetInputActionProgressMaterial(struct FSlateBrush& InProgressMaterialBrush, struct FName& InProgressMaterialParam); // Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5074b60
	void SetHoveredSoundOverride(struct USoundBase* Sound); // Function CommonUI.CommonButtonBase.SetHoveredSoundOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x5078bd0
	void SetHideInputAction(bool bInHideInputAction); // Function CommonUI.CommonButtonBase.SetHideInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x50602d0
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Function CommonUI.CommonButtonBase.SetClickMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x50ac5a0
	void OnTriggeringInputActionChanged(struct FDataTableRowHandle& NewTriggeredAction); // Function CommonUI.CommonButtonBase.OnTriggeringInputActionChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnTriggeringEnhancedInputActionChanged(struct UInputAction* InInputAction); // Function CommonUI.CommonButtonBase.OnTriggeringEnhancedInputActionChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnTriggeredInputActionChanged(struct FDataTableRowHandle& NewTriggeredAction); // Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnInputMethodChanged(enum class ECommonInputType CurrentInputType); // Function CommonUI.CommonButtonBase.OnInputMethodChanged // (Native|Protected) // @ game+0x5097650
	void OnCurrentTextStyleChanged(); // Function CommonUI.CommonButtonBase.OnCurrentTextStyleChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnActionProgress(float HeldPercent); // Function CommonUI.CommonButtonBase.OnActionProgress // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnActionComplete(); // Function CommonUI.CommonButtonBase.OnActionComplete // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool NativeOnHoldProgressRollback(float DeltaTime); // Function CommonUI.CommonButtonBase.NativeOnHoldProgressRollback // (Native|Protected) // @ game+0x50800b0
	bool NativeOnHoldProgress(float DeltaTime); // Function CommonUI.CommonButtonBase.NativeOnHoldProgress // (Native|Protected) // @ game+0x50b9ad0
	void NativeOnActionProgress(float HeldPercent); // Function CommonUI.CommonButtonBase.NativeOnActionProgress // (Native|Protected) // @ game+0x504ddc0
	void NativeOnActionComplete(); // Function CommonUI.CommonButtonBase.NativeOnActionComplete // (Native|Protected) // @ game+0x509ef80
	bool IsPressed(); // Function CommonUI.CommonButtonBase.IsPressed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5057c60
	bool IsInteractionEnabled(); // Function CommonUI.CommonButtonBase.IsInteractionEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50aa710
	void HoldReset(); // Function CommonUI.CommonButtonBase.HoldReset // (Native|Protected) // @ game+0x503ad80
	void HandleTriggeringActionCommited(bool& bPassThrough); // Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited // (Native|Protected|HasOutParms) // @ game+0x50a1e50
	void HandleFocusReceived(); // Function CommonUI.CommonButtonBase.HandleFocusReceived // (Native|Protected) // @ game+0x508ad90
	void HandleFocusLost(); // Function CommonUI.CommonButtonBase.HandleFocusLost // (Native|Protected) // @ game+0x50bd660
	void HandleButtonReleased(); // Function CommonUI.CommonButtonBase.HandleButtonReleased // (Final|Native|Protected) // @ game+0x50befe0
	void HandleButtonPressed(); // Function CommonUI.CommonButtonBase.HandleButtonPressed // (Final|Native|Protected) // @ game+0x5074160
	void HandleButtonClicked(); // Function CommonUI.CommonButtonBase.HandleButtonClicked // (Final|Native|Protected) // @ game+0x5051d20
	struct UCommonButtonStyle* GetStyle(); // Function CommonUI.CommonButtonBase.GetStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b7e20
	struct UMaterialInstanceDynamic* GetSingleMaterialStyleMID(); // Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5094770
	bool GetShouldSelectUponReceivingFocus(); // Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b7d20
	bool GetSelected(); // Function CommonUI.CommonButtonBase.GetSelected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x506cf20
	bool GetLocked(); // Function CommonUI.CommonButtonBase.GetLocked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50555d0
	bool GetIsFocusable(); // Function CommonUI.CommonButtonBase.GetIsFocusable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50664e0
	bool GetInputAction(struct FDataTableRowHandle& InputActionRow); // Function CommonUI.CommonButtonBase.GetInputAction // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x507bdd0
	struct UInputAction* GetEnhancedInputAction(); // Function CommonUI.CommonButtonBase.GetEnhancedInputAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50609b0
	struct UCommonTextStyle* GetCurrentTextStyleClass(); // Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50a3e30
	struct UCommonTextStyle* GetCurrentTextStyle(); // Function CommonUI.CommonButtonBase.GetCurrentTextStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x505a560
	void GetCurrentCustomPadding(struct FMargin& OutCustomPadding); // Function CommonUI.CommonButtonBase.GetCurrentCustomPadding // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b3710
	void GetCurrentButtonPadding(struct FMargin& OutButtonPadding); // Function CommonUI.CommonButtonBase.GetCurrentButtonPadding // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x506c950
	bool GetConvertInputActionToHold(); // Function CommonUI.CommonButtonBase.GetConvertInputActionToHold // (Native|Protected) // @ game+0x50b96d0
	void DisableButtonWithReason(struct FText& DisabledReason); // Function CommonUI.CommonButtonBase.DisableButtonWithReason // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x504ad30
	void ClearSelection(); // Function CommonUI.CommonButtonBase.ClearSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x509eae0
	void BP_OnUnhovered(); // Function CommonUI.CommonButtonBase.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnSelected(); // Function CommonUI.CommonButtonBase.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnReleased(); // Function CommonUI.CommonButtonBase.BP_OnReleased // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnPressed(); // Function CommonUI.CommonButtonBase.BP_OnPressed // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnLockedChanged(bool bIsLocked); // Function CommonUI.CommonButtonBase.BP_OnLockedChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnLockDoubleClicked(); // Function CommonUI.CommonButtonBase.BP_OnLockDoubleClicked // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnLockClicked(); // Function CommonUI.CommonButtonBase.BP_OnLockClicked // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnInputMethodChanged(enum class ECommonInputType CurrentInputType); // Function CommonUI.CommonButtonBase.BP_OnInputMethodChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnInputActionTriggered(); // Function CommonUI.CommonButtonBase.BP_OnInputActionTriggered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnHovered(); // Function CommonUI.CommonButtonBase.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnFocusReceived(); // Function CommonUI.CommonButtonBase.BP_OnFocusReceived // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnFocusLost(); // Function CommonUI.CommonButtonBase.BP_OnFocusLost // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnEnabled(); // Function CommonUI.CommonButtonBase.BP_OnEnabled // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnDoubleClicked(); // Function CommonUI.CommonButtonBase.BP_OnDoubleClicked // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnDisabled(); // Function CommonUI.CommonButtonBase.BP_OnDisabled // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnDeselected(); // Function CommonUI.CommonButtonBase.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnClicked(); // Function CommonUI.CommonButtonBase.BP_OnClicked // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class CommonUI.WidgetLockedStateRegistration
// Size: 0xa0 (Inherited: 0xa0)
struct UWidgetLockedStateRegistration : UWidgetBinaryStateRegistration {
};

// Class CommonUI.CommonCustomNavigation
// Size: 0x3c0 (Inherited: 0x3b0)
struct UCommonCustomNavigation : UBorder {
	struct FDelegate OnNavigationEvent; // 0x3a8(0x10)
};

// Class CommonUI.CommonTextBlock
// Size: 0x410 (Inherited: 0x3e0)
struct UCommonTextBlock : UTextBlock {
	float MobileFontSizeMultiplier; // 0x3d8(0x04)
	struct UCommonTextStyle* Style; // 0x3e0(0x08)
	struct UCommonTextScrollStyle* ScrollStyle; // 0x3e8(0x08)
	bool bIsScrollingEnabled; // 0x3f0(0x01)
	bool bDisplayAllCaps; // 0x3f1(0x01)
	bool bAutoCollapseWithEmptyText; // 0x3f2(0x01)
	char pad_3f7[0x19]; // 0x3f7(0x19)

	void SetWrapTextWidth(int32_t InWrapTextAt); // Function CommonUI.CommonTextBlock.SetWrapTextWidth // (Final|Native|Public|BlueprintCallable) // @ game+0x5079fa0
	void SetTextCase(bool bUseAllCaps); // Function CommonUI.CommonTextBlock.SetTextCase // (Final|Native|Public|BlueprintCallable) // @ game+0x50adc10
	void SetStyle(struct UCommonTextStyle* InStyle); // Function CommonUI.CommonTextBlock.SetStyle // (Final|Native|Public|BlueprintCallable) // @ game+0x50ba7d0
	void SetScrollingEnabled(bool bInIsScrollingEnabled); // Function CommonUI.CommonTextBlock.SetScrollingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x50b0300
	void SetMobileFontSizeMultiplier(float InMobileFontSizeMultiplier); // Function CommonUI.CommonTextBlock.SetMobileFontSizeMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x50b2040
	void SetMargin(struct FMargin& InMargin); // Function CommonUI.CommonTextBlock.SetMargin // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5089380
	void SetLineHeightPercentage(float InLineHeightPercentage); // Function CommonUI.CommonTextBlock.SetLineHeightPercentage // (Final|Native|Public|BlueprintCallable) // @ game+0x50616c0
	void ResetScrollState(); // Function CommonUI.CommonTextBlock.ResetScrollState // (Final|Native|Public|BlueprintCallable) // @ game+0x5069350
	float GetMobileFontSizeMultiplier(); // Function CommonUI.CommonTextBlock.GetMobileFontSizeMultiplier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2fe7af0
	struct FMargin GetMargin(); // Function CommonUI.CommonTextBlock.GetMargin // (Final|Native|Public|BlueprintCallable) // @ game+0x507d640
};

// Class CommonUI.CommonDateTimeTextBlock
// Size: 0x460 (Inherited: 0x410)
struct UCommonDateTimeTextBlock : UCommonTextBlock {
	char pad_410[0x50]; // 0x410(0x50)

	void SetTimespanValue(struct FTimespan InTimespan); // Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x50bac70
	void SetDateTimeValue(struct FDateTime InDateTime, bool bShowAsCountdown, float InRefreshDelay); // Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x50a4040
	void SetCountDownCompletionText(struct FText InCompletionText); // Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText // (Final|Native|Public|BlueprintCallable) // @ game+0x5066330
	struct FDateTime GetDateTime(); // Function CommonUI.CommonDateTimeTextBlock.GetDateTime // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3653fc0
};

// Class CommonUI.CommonGameViewportClient
// Size: 0x740 (Inherited: 0x700)
struct UCommonGameViewportClient : UGameViewportClient {
	char pad_700[0x40]; // 0x700(0x40)
};

// Class CommonUI.CommonHardwareVisibilityBorder
// Size: 0x420 (Inherited: 0x3d0)
struct UCommonHardwareVisibilityBorder : UCommonBorder {
	struct FGameplayTagQuery VisibilityQuery; // 0x3c8(0x48)
	enum class ESlateVisibility VisibleType; // 0x410(0x01)
	enum class ESlateVisibility HiddenType; // 0x411(0x01)
	char pad_41a[0x6]; // 0x41a(0x06)
};

// Class CommonUI.CommonHierarchicalScrollBox
// Size: 0xd60 (Inherited: 0xd60)
struct UCommonHierarchicalScrollBox : UScrollBox {
};

// Class CommonUI.CommonLazyImage
// Size: 0x460 (Inherited: 0x350)
struct UCommonLazyImage : UImage {
	struct FSlateBrush LoadingBackgroundBrush; // 0x350(0xd0)
	struct FName MaterialTextureParamName; // 0x420(0x08)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // 0x428(0x10)
	char pad_438[0x28]; // 0x438(0x28)

	void SetMaterialTextureParamName(struct FName TextureParamName); // Function CommonUI.CommonLazyImage.SetMaterialTextureParamName // (Final|Native|Public|BlueprintCallable) // @ game+0x506c350
	void SetBrushFromLazyTexture(struct TSoftObjectPtr<UTexture2D>& LazyTexture, bool bMatchSize); // Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5053f70
	void SetBrushFromLazyMaterial(struct TSoftObjectPtr<UMaterialInterface>& LazyMaterial); // Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50a7ed0
	void SetBrushFromLazyDisplayAsset(struct TSoftObjectPtr<UObject>& LazyObject, bool bMatchTextureSize); // Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x504b640
	bool IsLoading(); // Function CommonUI.CommonLazyImage.IsLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5065ef0
};

// Class CommonUI.CommonLazyWidget
// Size: 0x350 (Inherited: 0x1f0)
struct UCommonLazyWidget : UWidget {
	struct FSlateBrush LoadingBackgroundBrush; // 0x1f0(0xd0)
	struct UUserWidget* Content; // 0x2c0(0x08)
	char pad_2c8[0x30]; // 0x2c8(0x30)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // 0x2f8(0x10)
	char pad_308[0x48]; // 0x308(0x48)

	void SetLazyContent(struct TSoftClassPtr<UObject> SoftWidget); // Function CommonUI.CommonLazyWidget.SetLazyContent // (Final|Native|Public|BlueprintCallable) // @ game+0x5095ed0
	bool IsLoading(); // Function CommonUI.CommonLazyWidget.IsLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x509b720
	struct UUserWidget* GetContent(); // Function CommonUI.CommonLazyWidget.GetContent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5036920
};

// Class CommonUI.CommonListView
// Size: 0xcf0 (Inherited: 0xcf0)
struct UCommonListView : UListView {

	void SetEntrySpacing(float InEntrySpacing); // Function CommonUI.CommonListView.SetEntrySpacing // (Final|Native|Public|BlueprintCallable) // @ game+0x5085190
};

// Class CommonUI.LoadGuardSlot
// Size: 0xd0 (Inherited: 0xb0)
struct ULoadGuardSlot : UPanelSlot {
	struct FMargin Padding; // 0xa8(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0xb8(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0xb9(0x01)
	char pad_c2[0xe]; // 0xc2(0x0e)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function CommonUI.LoadGuardSlot.SetVerticalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x50ab360
	void SetPadding(struct FMargin InPadding); // Function CommonUI.LoadGuardSlot.SetPadding // (Final|Native|Public|BlueprintCallable) // @ game+0x50b9620
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function CommonUI.LoadGuardSlot.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x504fe60
};

// Class CommonUI.CommonLoadGuard
// Size: 0x370 (Inherited: 0x210)
struct UCommonLoadGuard : UContentWidget {
	struct FSlateBrush LoadingBackgroundBrush; // 0x210(0xd0)
	enum class EHorizontalAlignment ThrobberAlignment; // 0x2e0(0x01)
	char pad_2e1[0x3]; // 0x2e1(0x03)
	struct FMargin ThrobberPadding; // 0x2e4(0x10)
	char pad_2f4[0x4]; // 0x2f4(0x04)
	struct FText LoadingText; // 0x2f8(0x18)
	struct UCommonTextStyle* TextStyle; // 0x310(0x08)
	struct FMulticastInlineDelegate BP_OnLoadingStateChanged; // 0x318(0x10)
	struct FSoftObjectPath SpinnerMaterialPath; // 0x328(0x20)
	char pad_348[0x28]; // 0x348(0x28)

	void SetLoadingText(struct FText& InLoadingText); // Function CommonUI.CommonLoadGuard.SetLoadingText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50b03d0
	void SetIsLoading(bool bInIsLoading); // Function CommonUI.CommonLoadGuard.SetIsLoading // (Final|Native|Public|BlueprintCallable) // @ game+0x506bf30
	void OnAssetLoaded__DelegateSignature(struct UObject* Object); // DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature // (Public|Delegate) // @ game+0x4abfe0
	bool IsLoading(); // Function CommonUI.CommonLoadGuard.IsLoading // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50446d0
	void BP_GuardAndLoadAsset(struct TSoftObjectPtr<UObject>& InLazyAsset, struct FDelegate& OnAssetLoaded); // Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x5041da0
};

// Class CommonUI.CommonNumericTextBlock
// Size: 0x4b0 (Inherited: 0x410)
struct UCommonNumericTextBlock : UCommonTextBlock {
	struct FMulticastInlineDelegate OnInterpolationStartedEvent; // 0x408(0x10)
	struct FMulticastInlineDelegate OnInterpolationUpdatedEvent; // 0x418(0x10)
	struct FMulticastInlineDelegate OnOutroEvent; // 0x428(0x10)
	struct FMulticastInlineDelegate OnInterpolationEndedEvent; // 0x438(0x10)
	float CurrentNumericValue; // 0x448(0x04)
	enum class ECommonNumericType NumericType; // 0x44c(0x01)
	struct FCommonNumberFormattingOptions FormattingSpecification; // 0x450(0x14)
	float EaseOutInterpolationExponent; // 0x464(0x04)
	float InterpolationUpdateInterval; // 0x468(0x04)
	float PostInterpolationShrinkDuration; // 0x46c(0x04)
	bool PerformSizeInterpolation; // 0x470(0x01)
	bool IsPercentage; // 0x471(0x01)
	char pad_477[0x39]; // 0x477(0x39)

	void SetNumericType(enum class ECommonNumericType InNumericType); // Function CommonUI.CommonNumericTextBlock.SetNumericType // (Final|Native|Public|BlueprintCallable) // @ game+0x5053b60
	void SetCurrentValue(float NewValue); // Function CommonUI.CommonNumericTextBlock.SetCurrentValue // (Final|Native|Public|BlueprintCallable) // @ game+0x50af290
	void OnOutro__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock); // DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnInterpolationUpdated__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, float LastValue, float NewValue); // DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnInterpolationStarted__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock); // DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnInterpolationEnded__DelegateSignature(struct UCommonNumericTextBlock* NumericTextBlock, bool HadCompleted); // DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	bool IsInterpolatingNumericValue(); // Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b03b0
	void InterpolateToValue(float TargetValue, float MaximumInterpolationDuration, float MinimumChangeRate, float OutroOffset); // Function CommonUI.CommonNumericTextBlock.InterpolateToValue // (Final|Native|Public|BlueprintCallable) // @ game+0x507f9d0
	float GetTargetValue(); // Function CommonUI.CommonNumericTextBlock.GetTargetValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50bebe0
};

// Class CommonUI.CommonPoolableWidgetInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonPoolableWidgetInterface : UInterface {

	void OnReleaseToPool(); // Function CommonUI.CommonPoolableWidgetInterface.OnReleaseToPool // (Native|Event|Protected|BlueprintEvent) // @ game+0x5088b50
	void OnAcquireFromPool(); // Function CommonUI.CommonPoolableWidgetInterface.OnAcquireFromPool // (Native|Event|Protected|BlueprintEvent) // @ game+0x504dcb0
};

// Class CommonUI.CommonRichTextBlock
// Size: 0x950 (Inherited: 0x910)
struct UCommonRichTextBlock : URichTextBlock {
	enum class ERichTextInlineIconDisplayMode InlineIconDisplayMode; // 0x910(0x01)
	bool bTintInlineIcon; // 0x911(0x01)
	char pad_912[0x6]; // 0x912(0x06)
	struct UCommonTextStyle* DefaultTextStyleOverrideClass; // 0x918(0x08)
	float MobileTextBlockScale; // 0x920(0x04)
	char pad_924[0x4]; // 0x924(0x04)
	struct UCommonTextScrollStyle* ScrollStyle; // 0x928(0x08)
	bool bIsScrollingEnabled; // 0x930(0x01)
	bool bDisplayAllCaps; // 0x931(0x01)
	bool bAutoCollapseWithEmptyText; // 0x932(0x01)
	char pad_933[0x1d]; // 0x933(0x1d)

	void SetScrollingEnabled(bool bInIsScrollingEnabled); // Function CommonUI.CommonRichTextBlock.SetScrollingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x504c100
};

// Class CommonUI.CommonRotator
// Size: 0x1670 (Inherited: 0x1610)
struct UCommonRotator : UCommonButtonBase {
	char pad_1610[0x10]; // 0x1610(0x10)
	struct FMulticastInlineDelegate OnRotated; // 0x1620(0x10)
	char pad_1630[0x18]; // 0x1630(0x18)
	struct UCommonTextBlock* MyText; // 0x1648(0x08)
	char pad_1650[0x20]; // 0x1650(0x20)

	void ShiftTextRight(); // Function CommonUI.CommonRotator.ShiftTextRight // (Final|Native|Public|BlueprintCallable) // @ game+0x505ce00
	void ShiftTextLeft(); // Function CommonUI.CommonRotator.ShiftTextLeft // (Final|Native|Public|BlueprintCallable) // @ game+0x503b530
	void SetSelectedItem(int32_t InValue); // Function CommonUI.CommonRotator.SetSelectedItem // (Native|Public|BlueprintCallable) // @ game+0x50855d0
	void PopulateTextLabels(struct TArray<struct FText> Labels); // Function CommonUI.CommonRotator.PopulateTextLabels // (Final|Native|Public|BlueprintCallable) // @ game+0x5065a20
	struct FText GetSelectedText(); // Function CommonUI.CommonRotator.GetSelectedText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50ae5e0
	int32_t GetSelectedIndex(); // Function CommonUI.CommonRotator.GetSelectedIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50bddb0
	void BP_OnOptionsPopulated(int32_t Count); // Function CommonUI.CommonRotator.BP_OnOptionsPopulated // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnOptionSelected(int32_t Index); // Function CommonUI.CommonRotator.BP_OnOptionSelected // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class CommonUI.CommonTabListWidgetBase
// Size: 0x480 (Inherited: 0x370)
struct UCommonTabListWidgetBase : UCommonUserWidget {
	struct FMulticastInlineDelegate OnTabSelected; // 0x370(0x10)
	struct FMulticastInlineDelegate OnTabButtonCreation; // 0x380(0x10)
	struct FMulticastInlineDelegate OnTabButtonRemoval; // 0x390(0x10)
	struct FMulticastInlineDelegate OnTabListRebuilt; // 0x3a0(0x10)
	struct FMulticastInlineDelegate OnTabListInteracted; // 0x3b0(0x10)
	struct FDataTableRowHandle NextTabInputActionData; // 0x3c0(0x10)
	struct FDataTableRowHandle PreviousTabInputActionData; // 0x3d0(0x10)
	struct UInputAction* NextTabEnhancedInputAction; // 0x3e0(0x08)
	struct UInputAction* PreviousTabEnhancedInputAction; // 0x3e8(0x08)
	bool bAutoListenForInput; // 0x3f0(0x01)
	bool bAutoSelectTabButton; // 0x3f1(0x01)
	bool bDeferRebuildingTabList; // 0x3f2(0x01)
	char pad_3f3[0x1]; // 0x3f3(0x01)
	struct TWeakObjectPtr<struct UCommonAnimatedSwitcher> LinkedSwitcher; // 0x3f4(0x08)
	char pad_3fc[0x4]; // 0x3fc(0x04)
	struct UCommonButtonGroupBase* TabButtonGroup; // 0x400(0x08)
	char pad_408[0x8]; // 0x408(0x08)
	struct TMap<struct FName, struct FCommonRegisteredTabInfo> RegisteredTabsByID; // 0x410(0x50)
	char pad_460[0x20]; // 0x460(0x20)

	void SetTabVisibility(struct FName TabNameID, enum class ESlateVisibility NewVisibility); // Function CommonUI.CommonTabListWidgetBase.SetTabVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x50653e0
	void SetTabInteractionEnabled(struct FName TabNameID, bool bEnable); // Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x50b3220
	void SetTabEnabled(struct FName TabNameID, bool bEnable); // Function CommonUI.CommonTabListWidgetBase.SetTabEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x503a580
	void SetListeningForInput(bool bShouldListen); // Function CommonUI.CommonTabListWidgetBase.SetListeningForInput // (Native|Public|BlueprintCallable) // @ game+0x5057140
	void SetLinkedSwitcher(struct UCommonAnimatedSwitcher* CommonSwitcher); // Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher // (Native|Public|BlueprintCallable) // @ game+0x4fac960
	bool SelectTabByID(struct FName TabNameID, bool bSuppressClickFeedback); // Function CommonUI.CommonTabListWidgetBase.SelectTabByID // (Final|Native|Public|BlueprintCallable) // @ game+0x50a2a70
	bool RemoveTab(struct FName TabNameID); // Function CommonUI.CommonTabListWidgetBase.RemoveTab // (Final|Native|Public|BlueprintCallable) // @ game+0x50418c0
	void RemoveAllTabs(); // Function CommonUI.CommonTabListWidgetBase.RemoveAllTabs // (Final|Native|Public|BlueprintCallable) // @ game+0x50b5ac0
	bool RegisterTab(struct FName TabNameID, struct UCommonButtonBase* ButtonWidgetType, struct UWidget* ContentWidget, int32_t TabIndex); // Function CommonUI.CommonTabListWidgetBase.RegisterTab // (Final|Native|Public|BlueprintCallable) // @ game+0x506fef0
	void OnTabSelected__DelegateSignature(struct FName TabId); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnTabListRebuilt__DelegateSignature(); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabListRebuilt__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnTabListInteracted__DelegateSignature(); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabListInteracted__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnTabButtonRemoval__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnTabButtonCreation__DelegateSignature(struct FName TabId, struct UCommonButtonBase* TabButton); // DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void HandleTabSelection(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Function CommonUI.CommonTabListWidgetBase.HandleTabSelection // (Native|Event|Protected|BlueprintEvent) // @ game+0x508a540
	void HandleTabRemoval(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval // (Native|Event|Protected|BlueprintEvent) // @ game+0x507e6e0
	void HandleTabCreation(struct FName TabNameID, struct UCommonButtonBase* TabButton); // Function CommonUI.CommonTabListWidgetBase.HandleTabCreation // (Native|Event|Protected|BlueprintEvent) // @ game+0x50a9090
	void HandleTabButtonSelected(struct UCommonButtonBase* SelectedTabButton, int32_t ButtonIndex); // Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected // (Final|Native|Protected) // @ game+0x507f540
	void HandleTabButtonInteracted(struct UCommonButtonBase* SelectedTabButton, int32_t ButtonIndex); // Function CommonUI.CommonTabListWidgetBase.HandleTabButtonInteracted // (Final|Native|Protected) // @ game+0x50ad770
	void HandlePreviousTabInputAction(bool& bPassThrough); // Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction // (Final|Native|Protected|HasOutParms) // @ game+0x5052f90
	void HandlePreLinkedSwitcherChanged_BP(); // Function CommonUI.CommonTabListWidgetBase.HandlePreLinkedSwitcherChanged_BP // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void HandlePostLinkedSwitcherChanged_BP(); // Function CommonUI.CommonTabListWidgetBase.HandlePostLinkedSwitcherChanged_BP // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void HandleNextTabInputAction(bool& bPassThrough); // Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction // (Final|Native|Protected|HasOutParms) // @ game+0x506a0e0
	struct UWidget* GetTabWidgetBaseByID(struct FName TabNameID); // Function CommonUI.CommonTabListWidgetBase.GetTabWidgetBaseByID // (Final|Native|Public|BlueprintCallable) // @ game+0x5098250
	struct FName GetTabIdAtIndex(int32_t Index); // Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50aa480
	int32_t GetTabCount(); // Function CommonUI.CommonTabListWidgetBase.GetTabCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50b5970
	struct UCommonButtonBase* GetTabButtonBaseByID(struct FName TabNameID); // Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5079c70
	struct FName GetSelectedTabId(); // Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50bf100
	struct UCommonAnimatedSwitcher* GetLinkedSwitcher(); // Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50be7b0
	struct FName GetActiveTab(); // Function CommonUI.CommonTabListWidgetBase.GetActiveTab // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5068440
	void DisableTabWithReason(struct FName TabNameID, struct FText& Reason); // Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50571f0
};

// Class CommonUI.CommonTextStyle
// Size: 0x220 (Inherited: 0xa0)
struct UCommonTextStyle : UObject {
	struct FSlateFontInfo Font; // 0x98(0x58)
	struct FLinearColor Color; // 0xf0(0x10)
	bool bUsesDropShadow; // 0x100(0x01)
	struct FVector2D ShadowOffset; // 0x108(0x10)
	struct FLinearColor ShadowColor; // 0x118(0x10)
	struct FMargin Margin; // 0x128(0x10)
	char pad_139[0x7]; // 0x139(0x07)
	struct FSlateBrush StrikeBrush; // 0x140(0xd0)
	float LineHeightPercentage; // 0x210(0x04)
	char pad_214[0xc]; // 0x214(0x0c)

	void GetStrikeBrush(struct FSlateBrush& OutStrikeBrush); // Function CommonUI.CommonTextStyle.GetStrikeBrush // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x50aa8a0
	void GetShadowOffset(struct FVector2D& OutShadowOffset); // Function CommonUI.CommonTextStyle.GetShadowOffset // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5043090
	void GetShadowColor(struct FLinearColor& OutColor); // Function CommonUI.CommonTextStyle.GetShadowColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x50a0300
	void GetMargin(struct FMargin& OutMargin); // Function CommonUI.CommonTextStyle.GetMargin // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5064720
	float GetLineHeightPercentage(); // Function CommonUI.CommonTextStyle.GetLineHeightPercentage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5051680
	void GetFont(struct FSlateFontInfo& OutFont); // Function CommonUI.CommonTextStyle.GetFont // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x50848b0
	void GetColor(struct FLinearColor& OutColor); // Function CommonUI.CommonTextStyle.GetColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5044cf0
};

// Class CommonUI.CommonTextScrollStyle
// Size: 0xb0 (Inherited: 0xa0)
struct UCommonTextScrollStyle : UObject {
	float Speed; // 0x98(0x04)
	float StartDelay; // 0x9c(0x04)
	float EndDelay; // 0xa0(0x04)
	float FadeInDelay; // 0xa4(0x04)
	float FadeOutDelay; // 0xa8(0x04)
};

// Class CommonUI.CommonTileView
// Size: 0xd20 (Inherited: 0xd20)
struct UCommonTileView : UTileView {
};

// Class CommonUI.CommonTreeView
// Size: 0xd50 (Inherited: 0xd50)
struct UCommonTreeView : UTreeView {
};

// Class CommonUI.CommonUIEditorSettings
// Size: 0x120 (Inherited: 0xa0)
struct UCommonUIEditorSettings : UObject {
	struct TSoftClassPtr<UObject> TemplateTextStyle; // 0x98(0x28)
	struct TSoftClassPtr<UObject> TemplateButtonStyle; // 0xc0(0x28)
	struct TSoftClassPtr<UObject> TemplateBorderStyle; // 0xe8(0x28)
	char pad_118[0x8]; // 0x118(0x08)
};

// Class CommonUI.CommonUILibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonUILibrary : UBlueprintFunctionLibrary {

	struct UWidget* FindParentWidgetOfType(struct UWidget* StartingWidget, struct UWidget* Type); // Function CommonUI.CommonUILibrary.FindParentWidgetOfType // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x509d160
};

// Class CommonUI.CommonUIRichTextData
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonUIRichTextData : UObject {
	struct UDataTable* InlineIconSet; // 0x98(0x08)
};

// Class CommonUI.CommonUISettings
// Size: 0x240 (Inherited: 0xa0)
struct UCommonUISettings : UObject {
	bool bAutoLoadData; // 0x98(0x01)
	struct TSoftObjectPtr<UObject> DefaultImageResourceObject; // 0xa0(0x28)
	struct TSoftObjectPtr<UMaterialInterface> DefaultThrobberMaterial; // 0xc8(0x28)
	struct TSoftClassPtr<UObject> DefaultRichTextDataClass; // 0xf0(0x28)
	struct TArray<struct FGameplayTag> PlatformTraits; // 0x118(0x10)
	char pad_129[0x27]; // 0x129(0x27)
	struct UObject* DefaultImageResourceObjectInstance; // 0x150(0x08)
	struct UMaterialInterface* DefaultThrobberMaterialInstance; // 0x158(0x08)
	struct FSlateBrush DefaultThrobberBrush; // 0x160(0xd0)
	struct UCommonUIRichTextData* RichTextDataInstance; // 0x230(0x08)
	char pad_238[0x8]; // 0x238(0x08)
};

// Class CommonUI.CommonUISubsystemBase
// Size: 0xb0 (Inherited: 0xa0)
struct UCommonUISubsystemBase : UGameInstanceSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)

	struct FSlateBrush GetInputActionButtonIcon(struct FDataTableRowHandle& InputActionRowHandle, enum class ECommonInputType InputType, struct FName& GamepadName); // Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x50497e0
	struct FSlateBrush GetEnhancedInputActionButtonIcon(struct UInputAction* InputAction, struct ULocalPlayer* LocalPlayer); // Function CommonUI.CommonUISubsystemBase.GetEnhancedInputActionButtonIcon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x507a4d0
};

// Class CommonUI.CommonInputMetadata
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonInputMetadata : UObject {
	int32_t NavBarPriority; // 0x98(0x04)
	bool bIsGenericInputAction; // 0x9c(0x01)
};

// Class CommonUI.CommonMappingContextMetadataInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonMappingContextMetadataInterface : UInterface {
};

// Class CommonUI.CommonMappingContextMetadata
// Size: 0x100 (Inherited: 0xa0)
struct UCommonMappingContextMetadata : UDataAsset {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct UCommonInputMetadata* EnhancedInputMetadata; // 0xa8(0x08)
	struct TMap<struct UInputAction*, struct UCommonInputMetadata*> PerActionEnhancedInputMetadata; // 0xb0(0x50)
};

// Class CommonUI.CommonUIVisibilitySubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UCommonUIVisibilitySubsystem : ULocalPlayerSubsystem {
	char pad_a0[0x60]; // 0xa0(0x60)
};

// Class CommonUI.CommonVideoPlayer
// Size: 0x350 (Inherited: 0x1f0)
struct UCommonVideoPlayer : UWidget {
	struct UMediaSource* Video; // 0x1f0(0x08)
	struct UMediaPlayer* MediaPlayer; // 0x1f8(0x08)
	struct UMediaTexture* MediaTexture; // 0x200(0x08)
	struct UMaterial* VideoMaterial; // 0x208(0x08)
	struct UMediaSoundComponent* SoundComponent; // 0x210(0x08)
	char pad_218[0x8]; // 0x218(0x08)
	struct FSlateBrush VideoBrush; // 0x220(0xd0)
	char pad_2f0[0x60]; // 0x2f0(0x60)
};

// Class CommonUI.CommonVisibilitySwitcher
// Size: 0x240 (Inherited: 0x220)
struct UCommonVisibilitySwitcher : UOverlay {
	enum class ESlateVisibility ShownVisibility; // 0x218(0x01)
	int32_t ActiveWidgetIndex; // 0x21c(0x04)
	bool bAutoActivateSlot; // 0x220(0x01)
	bool bActivateFirstSlotOnAdding; // 0x221(0x01)
	char pad_227[0x19]; // 0x227(0x19)

	void SetActiveWidgetIndex(int32_t Index); // Function CommonUI.CommonVisibilitySwitcher.SetActiveWidgetIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x508a3e0
	void SetActiveWidget(struct UWidget* Widget); // Function CommonUI.CommonVisibilitySwitcher.SetActiveWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x507d380
	void IncrementActiveWidgetIndex(bool bAllowWrapping); // Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x50ab4f0
	int32_t GetActiveWidgetIndex(); // Function CommonUI.CommonVisibilitySwitcher.GetActiveWidgetIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x504c230
	struct UWidget* GetActiveWidget(); // Function CommonUI.CommonVisibilitySwitcher.GetActiveWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50a02d0
	void DecrementActiveWidgetIndex(bool bAllowWrapping); // Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x506f1c0
	void DeactivateVisibleSlot(); // Function CommonUI.CommonVisibilitySwitcher.DeactivateVisibleSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x5097400
	void ActivateVisibleSlot(); // Function CommonUI.CommonVisibilitySwitcher.ActivateVisibleSlot // (Final|Native|Public|BlueprintCallable) // @ game+0x50b6de0
};

// Class CommonUI.CommonVisibilitySwitcherSlot
// Size: 0xe0 (Inherited: 0xd0)
struct UCommonVisibilitySwitcherSlot : UOverlaySlot {
	char pad_d0[0x10]; // 0xd0(0x10)
};

// Class CommonUI.UCommonVisibilityWidgetBase
// Size: 0x420 (Inherited: 0x3d0)
struct UUCommonVisibilityWidgetBase : UCommonBorder {
	struct TMap<struct FName, bool> VisibilityControls; // 0x3c8(0x50)
	bool bShowForGamepad; // 0x418(0x01)
	bool bShowForMouseAndKeyboard; // 0x419(0x01)
	bool bShowForTouch; // 0x41a(0x01)
	enum class ESlateVisibility VisibleType; // 0x41b(0x01)
	enum class ESlateVisibility HiddenType; // 0x41c(0x01)

	struct TArray<struct FName> GetRegisteredPlatforms(); // Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms // (Final|Native|Static|Protected) // @ game+0x505b2c0
};

// Class CommonUI.CommonVisualAttachment
// Size: 0x260 (Inherited: 0x240)
struct UCommonVisualAttachment : USizeBox {
	struct FVector2D ContentAnchor; // 0x240(0x10)
	char pad_250[0x10]; // 0x250(0x10)
};

// Class CommonUI.CommonWidgetCarousel
// Size: 0x250 (Inherited: 0x210)
struct UCommonWidgetCarousel : UPanelWidget {
	int32_t ActiveWidgetIndex; // 0x208(0x04)
	struct FMulticastInlineDelegate OnCurrentPageIndexChanged; // 0x210(0x10)
	char pad_224[0x2c]; // 0x224(0x2c)

	void SetActiveWidgetIndex(int32_t Index); // Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex // (Native|Public|BlueprintCallable) // @ game+0x2a5c390
	void SetActiveWidget(struct UWidget* Widget); // Function CommonUI.CommonWidgetCarousel.SetActiveWidget // (Native|Public|BlueprintCallable) // @ game+0x2976d50
	void PreviousPage(); // Function CommonUI.CommonWidgetCarousel.PreviousPage // (Final|Native|Public|BlueprintCallable) // @ game+0x50445c0
	void NextPage(); // Function CommonUI.CommonWidgetCarousel.NextPage // (Final|Native|Public|BlueprintCallable) // @ game+0x5060d40
	struct UWidget* GetWidgetAtIndex(int32_t Index); // Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a2b6b0
	int32_t GetActiveWidgetIndex(); // Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x509fb50
	void EndAutoScrolling(); // Function CommonUI.CommonWidgetCarousel.EndAutoScrolling // (Final|Native|Public|BlueprintCallable) // @ game+0x50a1690
	void BeginAutoScrolling(float ScrollInterval); // Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling // (Final|Native|Public|BlueprintCallable) // @ game+0x5043140
};

// Class CommonUI.CommonWidgetCarouselNavBar
// Size: 0x240 (Inherited: 0x1f0)
struct UCommonWidgetCarouselNavBar : UWidget {
	struct UCommonButtonBase* ButtonWidgetType; // 0x1f0(0x08)
	struct FMargin ButtonPadding; // 0x1f8(0x10)
	char pad_208[0x10]; // 0x208(0x10)
	struct UCommonWidgetCarousel* LinkedCarousel; // 0x218(0x08)
	struct UCommonButtonGroupBase* ButtonGroup; // 0x220(0x08)
	struct TArray<struct UCommonButtonBase*> Buttons; // 0x228(0x10)
	char pad_238[0x8]; // 0x238(0x08)

	void SetLinkedCarousel(struct UCommonWidgetCarousel* CommonCarousel); // Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel // (Final|Native|Public|BlueprintCallable) // @ game+0x504b4f0
	void HandlePageChanged(struct UCommonWidgetCarousel* CommonCarousel, int32_t PageIndex); // Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged // (Final|Native|Protected) // @ game+0x5069240
	void HandleButtonClicked(struct UCommonButtonBase* AssociatedButton, int32_t ButtonIndex); // Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked // (Final|Native|Protected) // @ game+0x5052d80
};

// Class CommonUI.CommonWidgetGroupBase
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonWidgetGroupBase : UObject {

	void RemoveWidget(struct UWidget* InWidget); // Function CommonUI.CommonWidgetGroupBase.RemoveWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x507dd00
	void RemoveAll(); // Function CommonUI.CommonWidgetGroupBase.RemoveAll // (Final|Native|Public|BlueprintCallable) // @ game+0x16fe8b0
	void AddWidget(struct UWidget* InWidget); // Function CommonUI.CommonWidgetGroupBase.AddWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x5051d40
};

// Class CommonUI.CommonButtonGroupBase
// Size: 0x180 (Inherited: 0xa0)
struct UCommonButtonGroupBase : UCommonWidgetGroupBase {
	struct FMulticastInlineDelegate OnSelectedButtonBaseChanged; // 0x98(0x10)
	char pad_b0[0x10]; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnHoveredButtonBaseChanged; // 0xc0(0x10)
	char pad_d0[0x18]; // 0xd0(0x18)
	struct FMulticastInlineDelegate OnButtonBaseClicked; // 0xe8(0x10)
	char pad_f8[0x18]; // 0xf8(0x18)
	struct FMulticastInlineDelegate OnButtonBaseDoubleClicked; // 0x110(0x10)
	char pad_120[0x18]; // 0x120(0x18)
	struct FMulticastInlineDelegate OnSelectionCleared; // 0x138(0x10)
	char pad_148[0x18]; // 0x148(0x18)
	bool bSelectionRequired; // 0x160(0x01)
	char pad_161[0x1f]; // 0x161(0x1f)

	void SetSelectionRequired(bool bRequireSelection); // Function CommonUI.CommonButtonGroupBase.SetSelectionRequired // (Final|Native|Public|BlueprintCallable) // @ game+0x507e4f0
	void SelectPreviousButton(bool bAllowWrap); // Function CommonUI.CommonButtonGroupBase.SelectPreviousButton // (Final|Native|Public|BlueprintCallable) // @ game+0x504e960
	void SelectNextButton(bool bAllowWrap); // Function CommonUI.CommonButtonGroupBase.SelectNextButton // (Final|Native|Public|BlueprintCallable) // @ game+0x5085680
	void SelectButtonAtIndex(int32_t ButtonIndex, bool bAllowSound); // Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x50402c0
	void OnSelectionStateChangedBase(struct UCommonButtonBase* BaseButton, bool bIsSelected); // Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase // (Native|Protected) // @ game+0x508cc00
	void OnHandleButtonBaseDoubleClicked(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked // (Native|Protected) // @ game+0x2de1e30
	void OnHandleButtonBaseClicked(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked // (Native|Protected) // @ game+0x2b8dcf0
	void OnButtonBaseUnhovered(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered // (Native|Protected) // @ game+0x4fad190
	void OnButtonBaseHovered(struct UCommonButtonBase* BaseButton); // Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered // (Native|Protected) // @ game+0x5084090
	bool HasAnyButtons(); // Function CommonUI.CommonButtonGroupBase.HasAnyButtons // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x508c130
	int32_t GetSelectedButtonIndex(); // Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50a87c0
	struct UCommonButtonBase* GetSelectedButtonBase(); // Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x507f4f0
	int32_t GetHoveredButtonIndex(); // Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x505f1e0
	int32_t GetButtonCount(); // Function CommonUI.CommonButtonGroupBase.GetButtonCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x273b610
	struct UCommonButtonBase* GetButtonBaseAtIndex(int32_t Index); // Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5064ac0
	int32_t FindButtonIndex(struct UCommonButtonBase* ButtonToFind); // Function CommonUI.CommonButtonGroupBase.FindButtonIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x505cbe0
	void DeselectAll(); // Function CommonUI.CommonButtonGroupBase.DeselectAll // (Final|Native|Public|BlueprintCallable) // @ game+0x508cfd0
};

// Class CommonUI.CommonBoundActionBar
// Size: 0x2f0 (Inherited: 0x2d0)
struct UCommonBoundActionBar : UDynamicEntryBoxBase {
	char pad_2d0[0x8]; // 0x2d0(0x08)
	struct UCommonButtonBase* ActionButtonClass; // 0x2d8(0x08)
	bool bDisplayOwningPlayerActionsOnly; // 0x2e0(0x01)
	bool bIgnoreDuplicateActions; // 0x2e1(0x01)
	char pad_2e2[0xe]; // 0x2e2(0x0e)

	void SetDisplayOwningPlayerActionsOnly(bool bShouldOnlyDisplayOwningPlayerActions); // Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x503eff0
};

// Class CommonUI.CommonBoundActionButton
// Size: 0x1630 (Inherited: 0x1610)
struct UCommonBoundActionButton : UCommonButtonBase {
	char pad_1610[0x8]; // 0x1610(0x08)
	struct UCommonTextBlock* Text_ActionName; // 0x1618(0x08)
	char pad_1620[0x10]; // 0x1620(0x10)

	void OnUpdateInputAction(struct FText& ActionName); // Function CommonUI.CommonBoundActionButton.OnUpdateInputAction // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class CommonUI.CommonGenericInputActionDataTable
// Size: 0x120 (Inherited: 0x120)
struct UCommonGenericInputActionDataTable : UDataTable {
};

// Class CommonUI.CommonInputActionDataProcessor
// Size: 0xa0 (Inherited: 0xa0)
struct UCommonInputActionDataProcessor : UObject {
};

// Class CommonUI.CommonUIActionRouterBase
// Size: 0x1e0 (Inherited: 0xa0)
struct UCommonUIActionRouterBase : ULocalPlayerSubsystem {
	char pad_a0[0x140]; // 0xa0(0x140)
};

// Class CommonUI.CommonUIInputSettings
// Size: 0xf0 (Inherited: 0xa0)
struct UCommonUIInputSettings : UObject {
	bool bLinkCursorToGamepadFocus; // 0x98(0x01)
	int32_t UIActionProcessingPriority; // 0x9c(0x04)
	struct TArray<struct FUIInputAction> InputActions; // 0xa0(0x10)
	struct TArray<struct FUIInputAction> ActionOverrides; // 0xb0(0x10)
	struct FCommonAnalogCursorSettings AnalogCursorSettings; // 0xc0(0x24)
	char pad_e9[0x7]; // 0xe9(0x07)
};

// Class CommonUI.CommonActivatableWidgetContainerBase
// Size: 0x310 (Inherited: 0x1f0)
struct UCommonActivatableWidgetContainerBase : UWidget {
	char pad_1f0[0x19]; // 0x1f0(0x19)
	enum class ECommonSwitcherTransition TransitionType; // 0x209(0x01)
	enum class ETransitionCurve TransitionCurveType; // 0x20a(0x01)
	char pad_20b[0x1]; // 0x20b(0x01)
	float TransitionDuration; // 0x20c(0x04)
	struct TArray<struct UCommonActivatableWidget*> WidgetList; // 0x210(0x10)
	struct UCommonActivatableWidget* DisplayedWidget; // 0x220(0x08)
	struct FUserWidgetPool GeneratedWidgetsPool; // 0x228(0x88)
	char pad_2b0[0x60]; // 0x2b0(0x60)

	void SetTransitionDuration(float Duration); // Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration // (Final|Native|Public|BlueprintCallable) // @ game+0x5051de0
	void SetSkipTransitionIn(bool bInSkipTransitionIn); // Function CommonUI.CommonActivatableWidgetContainerBase.SetSkipTransitionIn // (Final|Native|Protected|BlueprintCallable) // @ game+0x50b4100
	void RemoveWidget(struct UCommonActivatableWidget* WidgetToRemove); // Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget // (Final|Native|Private|BlueprintCallable) // @ game+0x509a360
	float GetTransitionDuration(); // Function CommonUI.CommonActivatableWidgetContainerBase.GetTransitionDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5052070
	struct UCommonActivatableWidget* GetActiveWidget(); // Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5038420
	void ClearWidgets(); // Function CommonUI.CommonActivatableWidgetContainerBase.ClearWidgets // (Native|Public|BlueprintCallable) // @ game+0x2f78920
	struct UCommonActivatableWidget* BP_AddWidgetWithCallback(struct UCommonActivatableWidget* ActivatableWidgetClass, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName); // Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidgetWithCallback // (Final|Native|Private|BlueprintCallable) // @ game+0x503cd90
	struct UCommonActivatableWidget* BP_AddWidget(struct UCommonActivatableWidget* ActivatableWidgetClass); // Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget // (Final|Native|Private|BlueprintCallable) // @ game+0x5048d50
};

// Class CommonUI.CommonActivatableWidgetStack
// Size: 0x320 (Inherited: 0x310)
struct UCommonActivatableWidgetStack : UCommonActivatableWidgetContainerBase {
	struct UCommonActivatableWidget* RootContentWidgetClass; // 0x310(0x08)
	struct UCommonActivatableWidget* RootContentWidget; // 0x318(0x08)
};

// Class CommonUI.CommonActivatableWidgetQueue
// Size: 0x310 (Inherited: 0x310)
struct UCommonActivatableWidgetQueue : UCommonActivatableWidgetContainerBase {
};

