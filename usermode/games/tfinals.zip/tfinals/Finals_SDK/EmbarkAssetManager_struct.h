// Enum EmbarkAssetManager.ECookStatus
enum class ECookStatus : uint8_t {
	Unknown = 0,
	NeverCook = 1,
	Cook = 2,
	ECookStatus_MAX = 3
};

// ScriptStruct EmbarkAssetManager.BranchCookConfiguration
// Size: 0x01 (Inherited: 0x00)
struct FBranchCookConfiguration {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkAssetManager.ReleaseList
// Size: 0x01 (Inherited: 0x00)
struct FReleaseList {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkAssetManager.CookSettings
// Size: 0x02 (Inherited: 0x00)
struct FCookSettings {
	bool bOnlyCookProductionAssets; // 0x00(0x01)
	bool bTargetPlatformsAllowDevelopmentObjects; // 0x01(0x01)
};

// ScriptStruct EmbarkAssetManager.Releases
// Size: 0x01 (Inherited: 0x00)
struct FReleases {
	char pad_0[0x1]; // 0x00(0x01)
};

