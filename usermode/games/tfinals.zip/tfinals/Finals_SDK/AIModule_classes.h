// Class AIModule.AIAsyncTaskBlueprintProxy
// Size: 0xe0 (Inherited: 0xa0)
struct UAIAsyncTaskBlueprintProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFail; // 0xa8(0x10)
	char pad_c0[0x20]; // 0xc0(0x20)

	void OnMoveCompleted(struct FAIRequestID RequestID, enum class EPathFollowingResult MovementResult); // Function AIModule.AIAsyncTaskBlueprintProxy.OnMoveCompleted // (Final|RequiredAPI|Native|Public) // @ game+0x3e8a710
};

// Class AIModule.AIResourceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UAIResourceInterface : UInterface {
};

// Class AIModule.AISenseBlueprintListener
// Size: 0x180 (Inherited: 0x180)
struct UAISenseBlueprintListener : UUserDefinedStruct {
};

// Class AIModule.AISenseConfig
// Size: 0xc0 (Inherited: 0xa0)
struct UAISenseConfig : UObject {
	struct FColor DebugColor; // 0x98(0x04)
	float MaxAge; // 0x9c(0x04)
	char bStartsEnabled : 1; // 0xa0(0x01)
	char pad_a8_1 : 7; // 0xa8(0x01)
	char pad_a9[0x17]; // 0xa9(0x17)
};

// Class AIModule.AISenseConfig_Blueprint
// Size: 0xc0 (Inherited: 0xc0)
struct UAISenseConfig_Blueprint : UAISenseConfig {
	struct UAISense_Blueprint* Implementation; // 0xb8(0x08)
};

// Class AIModule.AISenseConfig_Hearing
// Size: 0xd0 (Inherited: 0xc0)
struct UAISenseConfig_Hearing : UAISenseConfig {
	struct UAISense_Hearing* Implementation; // 0xb8(0x08)
	float HearingRange; // 0xc0(0x04)
	float LoSHearingRange; // 0xc4(0x04)
	char bUseLoSHearing : 1; // 0xc8(0x01)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0xcc(0x04)
};

// Class AIModule.AISenseConfig_Prediction
// Size: 0xc0 (Inherited: 0xc0)
struct UAISenseConfig_Prediction : UAISenseConfig {
};

// Class AIModule.AISenseConfig_Sight
// Size: 0xe0 (Inherited: 0xc0)
struct UAISenseConfig_Sight : UAISenseConfig {
	struct UAISense_Sight* Implementation; // 0xb8(0x08)
	float SightRadius; // 0xc0(0x04)
	float LoseSightRadius; // 0xc4(0x04)
	float PeripheralVisionAngleDegrees; // 0xc8(0x04)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0xcc(0x04)
	float AutoSuccessRangeFromLastSeenLocation; // 0xd0(0x04)
	float PointOfViewBackwardOffset; // 0xd4(0x04)
	float NearClippingRadius; // 0xd8(0x04)
};

// Class AIModule.AISenseConfig_Team
// Size: 0xc0 (Inherited: 0xc0)
struct UAISenseConfig_Team : UAISenseConfig {
};

// Class AIModule.AISenseConfig_Touch
// Size: 0xc0 (Inherited: 0xc0)
struct UAISenseConfig_Touch : UAISenseConfig {
};

// Class AIModule.AISenseEvent
// Size: 0xa0 (Inherited: 0xa0)
struct UAISenseEvent : UObject {
};

// Class AIModule.AISenseEvent_Damage
// Size: 0xf0 (Inherited: 0xa0)
struct UAISenseEvent_Damage : UAISenseEvent {
	struct FAIDamageEvent Event; // 0x98(0x50)
};

// Class AIModule.AISenseEvent_Hearing
// Size: 0xe0 (Inherited: 0xa0)
struct UAISenseEvent_Hearing : UAISenseEvent {
	struct FAINoiseEvent Event; // 0x98(0x40)
};

// Class AIModule.CrowdAgentInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UCrowdAgentInterface : UInterface {
};

// Class AIModule.EnvQueryTypes
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryTypes : UObject {
};

// Class AIModule.EQSQueryResultSourceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEQSQueryResultSourceInterface : UInterface {
};

// Class AIModule.GenericTeamAgentInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UGenericTeamAgentInterface : UInterface {
};

// Class AIModule.PawnAction
// Size: 0x100 (Inherited: 0xa0)
struct UPawnAction : UObject {
	struct UPawnAction* ChildAction; // 0x98(0x08)
	struct UPawnAction* ParentAction; // 0xa0(0x08)
	struct UPawnActionsComponent* OwnerComponent; // 0xa8(0x08)
	struct UObject* Instigator; // 0xb0(0x08)
	struct UBrainComponent* BrainComp; // 0xb8(0x08)
	char pad_c8[0x28]; // 0xc8(0x28)
	char bAllowNewSameClassInstance : 1; // 0xf0(0x01)
	char bReplaceActiveSameClassInstance : 1; // 0xf0(0x01)
	char bShouldPauseMovement : 1; // 0xf0(0x01)
	char bAlwaysNotifyOnFinished : 1; // 0xf0(0x01)
	char pad_f0_4 : 4; // 0xf0(0x01)
	char pad_f1[0xf]; // 0xf1(0x0f)

	enum class EAIRequestPriority GetActionPriority(); // Function AIModule.PawnAction.GetActionPriority // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x3e860c0
	void Finish(enum class EPawnActionResult WithResult); // Function AIModule.PawnAction.Finish // (RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x3e887d0
	struct UPawnAction* CreateActionInstance(struct UObject* WorldContextObject, struct UPawnAction* ActionClass); // Function AIModule.PawnAction.CreateActionInstance // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3e8b430
};

// Class AIModule.PawnActionsComponent
// Size: 0x190 (Inherited: 0x160)
struct UPawnActionsComponent : UActorComponent {
	struct APawn* ControlledPawn; // 0x158(0x08)
	struct TArray<struct FPawnActionStack> ActionStacks; // 0x160(0x10)
	struct TArray<struct FPawnActionEvent> ActionEvents; // 0x170(0x10)
	struct UPawnAction* CurrentAction; // 0x180(0x08)

	bool K2_PushAction(struct UPawnAction* NewAction, enum class EAIRequestPriority Priority, struct UObject* Instigator); // Function AIModule.PawnActionsComponent.K2_PushAction // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3eb95e0
	bool K2_PerformAction(struct APawn* Pawn, struct UPawnAction* Action, enum class EAIRequestPriority Priority); // Function AIModule.PawnActionsComponent.K2_PerformAction // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3eabd40
	enum class EPawnActionAbortState K2_ForceAbortAction(struct UPawnAction* ActionToAbort); // Function AIModule.PawnActionsComponent.K2_ForceAbortAction // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3ebf370
	enum class EPawnActionAbortState K2_AbortAction(struct UPawnAction* ActionToAbort); // Function AIModule.PawnActionsComponent.K2_AbortAction // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3eaba60
};

// Class AIModule.PawnAction_BlueprintBase
// Size: 0x100 (Inherited: 0x100)
struct UPawnAction_BlueprintBase : UPawnAction {

	void ActionTick(struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.PawnAction_BlueprintBase.ActionTick // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ActionStart(struct APawn* ControlledPawn); // Function AIModule.PawnAction_BlueprintBase.ActionStart // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ActionResume(struct APawn* ControlledPawn); // Function AIModule.PawnAction_BlueprintBase.ActionResume // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ActionPause(struct APawn* ControlledPawn); // Function AIModule.PawnAction_BlueprintBase.ActionPause // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ActionFinished(struct APawn* ControlledPawn, enum class EPawnActionResult WithResult); // Function AIModule.PawnAction_BlueprintBase.ActionFinished // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AIModule.PawnAction_Move
// Size: 0x160 (Inherited: 0x100)
struct UPawnAction_Move : UPawnAction {
	struct AActor* GoalActor; // 0x100(0x08)
	struct FVector GoalLocation; // 0x108(0x18)
	float AcceptableRadius; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0x128(0x08)
	char bAllowStrafe : 1; // 0x130(0x01)
	char bFinishOnOverlap : 1; // 0x130(0x01)
	char bUsePathfinding : 1; // 0x130(0x01)
	char bAllowPartialPath : 1; // 0x130(0x01)
	char bProjectGoalToNavigation : 1; // 0x130(0x01)
	char bUpdatePathToGoal : 1; // 0x130(0x01)
	char bAbortSubActionOnPathChange : 1; // 0x130(0x01)
	char pad_130_7 : 1; // 0x130(0x01)
	char pad_131[0x2f]; // 0x131(0x2f)
};

// Class AIModule.PawnAction_Repeat
// Size: 0x120 (Inherited: 0x100)
struct UPawnAction_Repeat : UPawnAction {
	struct UPawnAction* ActionToRepeat; // 0x100(0x08)
	struct UPawnAction* RecentActionCopy; // 0x108(0x08)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0x110(0x01)
	char pad_111[0xf]; // 0x111(0x0f)
};

// Class AIModule.PawnAction_Sequence
// Size: 0x130 (Inherited: 0x100)
struct UPawnAction_Sequence : UPawnAction {
	struct TArray<struct UPawnAction*> ActionSequence; // 0x100(0x10)
	enum class EPawnActionFailHandling ChildFailureHandlingMode; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct UPawnAction* RecentActionCopy; // 0x118(0x08)
	char pad_120[0x10]; // 0x120(0x10)
};

// Class AIModule.PawnAction_Wait
// Size: 0x110 (Inherited: 0x100)
struct UPawnAction_Wait : UPawnAction {
	float TimeToWait; // 0x100(0x04)
	char pad_104[0xc]; // 0x104(0x0c)
};

// Class AIModule.AIController
// Size: 0x4c0 (Inherited: 0x430)
struct AAIController : AController {
	char pad_430[0x38]; // 0x430(0x38)
	char bStartAILogicOnPossess : 1; // 0x468(0x01)
	char bStopAILogicOnUnposses : 1; // 0x468(0x01)
	char bLOSflag : 1; // 0x468(0x01)
	char bSkipExtraLOSChecks : 1; // 0x468(0x01)
	char bAllowStrafe : 1; // 0x468(0x01)
	char bWantsPlayerState : 1; // 0x468(0x01)
	char bSetControlRotationFromPawnOrientation : 1; // 0x468(0x01)
	char pad_468_7 : 1; // 0x468(0x01)
	char pad_469[0x7]; // 0x469(0x07)
	struct UPathFollowingComponent* PathFollowingComponent; // 0x470(0x08)
	struct UBrainComponent* BrainComponent; // 0x478(0x08)
	struct UAIPerceptionComponent* PerceptionComponent; // 0x480(0x08)
	struct UPawnActionsComponent* ActionsComp; // 0x488(0x08)
	struct UBlackboardComponent* Blackboard; // 0x490(0x08)
	struct UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x498(0x08)
	struct UNavigationQueryFilter* DefaultNavigationFilterClass; // 0x4a0(0x08)
	struct FMulticastInlineDelegate ReceiveMoveCompleted; // 0x4a8(0x10)
	char pad_4b8[0x8]; // 0x4b8(0x08)

	bool UseBlackboard(struct UBlackboardData* BlackboardAsset, struct UBlackboardComponent*& BlackboardComponent); // Function AIModule.AIController.UseBlackboard // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea8a00
	void UnclaimTaskResource(struct UGameplayTaskResource* ResourceClass); // Function AIModule.AIController.UnclaimTaskResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e90750
	void SetPathFollowingComponent(struct UPathFollowingComponent* NewPFComponent); // Function AIModule.AIController.SetPathFollowingComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e9c3e0
	void SetMoveBlockDetection(bool bEnable); // Function AIModule.AIController.SetMoveBlockDetection // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e9ac40
	bool RunBehaviorTree(struct UBehaviorTree* BTAsset); // Function AIModule.AIController.RunBehaviorTree // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e91780
	void OnUsingBlackBoard(struct UBlackboardComponent* BlackboardComp, struct UBlackboardData* BlackboardAsset); // Function AIModule.AIController.OnUsingBlackBoard // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnGameplayTaskResourcesClaimed(struct FGameplayResourceSet NewlyClaimed, struct FGameplayResourceSet FreshlyReleased); // Function AIModule.AIController.OnGameplayTaskResourcesClaimed // (RequiredAPI|Native|Public) // @ game+0x3e99330
	enum class EPathFollowingRequestResult MoveToLocation(struct FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath); // Function AIModule.AIController.MoveToLocation // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3ec3c50
	enum class EPathFollowingRequestResult MoveToActor(struct AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, struct UNavigationQueryFilter* FilterClass, bool bAllowPartialPath); // Function AIModule.AIController.MoveToActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3ebf6b0
	void K2_SetFocus(struct AActor* NewFocus); // Function AIModule.AIController.K2_SetFocus // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e8c2d0
	void K2_SetFocalPoint(struct FVector FP); // Function AIModule.AIController.K2_SetFocalPoint // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3e9bb20
	void K2_ClearFocus(); // Function AIModule.AIController.K2_ClearFocus // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e8cfc0
	bool HasPartialPath(); // Function AIModule.AIController.HasPartialPath // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e97790
	struct UPathFollowingComponent* GetPathFollowingComponent(); // Function AIModule.AIController.GetPathFollowingComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3eb2f90
	enum class EPathFollowingStatus GetMoveStatus(); // Function AIModule.AIController.GetMoveStatus // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ead9b0
	struct FVector GetImmediateMoveDestination(); // Function AIModule.AIController.GetImmediateMoveDestination // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e92ae0
	struct AActor* GetFocusActor(); // Function AIModule.AIController.GetFocusActor // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ea9850
	struct FVector GetFocalPointOnActor(struct AActor* Actor); // Function AIModule.AIController.GetFocalPointOnActor // (RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e95110
	struct FVector GetFocalPoint(); // Function AIModule.AIController.GetFocalPoint // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e934e0
	struct UPawnActionsComponent* GetDeprecatedActionsComponent(); // Function AIModule.AIController.GetDeprecatedActionsComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e933e0
	struct UAIPerceptionComponent* GetAIPerceptionComponent(); // Function AIModule.AIController.GetAIPerceptionComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x3ec5050
	void ClaimTaskResource(struct UGameplayTaskResource* ResourceClass); // Function AIModule.AIController.ClaimTaskResource // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3eb6310
};

// Class AIModule.AIResource_Movement
// Size: 0xb0 (Inherited: 0xb0)
struct UAIResource_Movement : UGameplayTaskResource {
};

// Class AIModule.AIResource_Logic
// Size: 0xb0 (Inherited: 0xb0)
struct UAIResource_Logic : UGameplayTaskResource {
};

// Class AIModule.AISubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UAISubsystem : UObject {
	struct UAISystem* AISystem; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class AIModule.AISystem
// Size: 0x210 (Inherited: 0xd0)
struct UAISystem : UAISystemBase {
	struct FSoftClassPath PerceptionSystemClassName; // 0xd0(0x20)
	struct FSoftClassPath HotSpotManagerClassName; // 0xf0(0x20)
	struct FSoftClassPath EnvQueryManagerClassName; // 0x110(0x20)
	float AcceptanceRadius; // 0x130(0x04)
	float PathfollowingRegularPathPointAcceptanceRadius; // 0x134(0x04)
	float PathfollowingNavLinkAcceptanceRadius; // 0x138(0x04)
	bool bFinishMoveOnGoalOverlap; // 0x13c(0x01)
	bool bAcceptPartialPaths; // 0x13d(0x01)
	bool bAllowStrafing; // 0x13e(0x01)
	bool bAllowControllersAsEQSQuerier; // 0x13f(0x01)
	bool bEnableDebuggerPlugin; // 0x140(0x01)
	bool bForgetStaleActors; // 0x141(0x01)
	bool bAddBlackboardSelfKey; // 0x142(0x01)
	bool bClearBBEntryOnBTEQSFail; // 0x143(0x01)
	bool bBlackboardKeyDecoratorAllowsNoneAsValue; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	struct TSoftObjectPtr<UBlackboardData> DefaultBlackboard; // 0x148(0x28)
	enum class ECollisionChannel DefaultSightCollisionChannel; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct UBehaviorTreeManager* BehaviorTreeManager; // 0x178(0x08)
	struct UEnvQueryManager* EnvironmentQueryManager; // 0x180(0x08)
	struct UAIPerceptionSystem* PerceptionSystem; // 0x188(0x08)
	struct TArray<struct UAIAsyncTaskBlueprintProxy*> AllProxyObjects; // 0x190(0x10)
	struct UAIHotSpotManager* HotSpotManager; // 0x1a0(0x08)
	struct UNavLocalGridManager* NavLocalGrids; // 0x1a8(0x08)
	char pad_1b0[0x60]; // 0x1b0(0x60)

	void AILoggingVerbose(); // Function AIModule.AISystem.AILoggingVerbose // (RequiredAPI|Exec|Native|Public) // @ game+0x2d0aea0
	void AIIgnorePlayers(); // Function AIModule.AISystem.AIIgnorePlayers // (RequiredAPI|Exec|Native|Public) // @ game+0x16fe6f0
};

// Class AIModule.BehaviorTree
// Size: 0xe0 (Inherited: 0xa0)
struct UBehaviorTree : UObject {
	struct UBTCompositeNode* RootNode; // 0xa0(0x08)
	struct UBlackboardData* BlackboardAsset; // 0xa8(0x08)
	struct TArray<struct UBTDecorator*> RootDecorators; // 0xb0(0x10)
	struct TArray<struct FBTDecoratorLogic> RootDecoratorOps; // 0xc0(0x10)
	char pad_d0[0x10]; // 0xd0(0x10)
};

// Class AIModule.BrainComponent
// Size: 0x1b0 (Inherited: 0x160)
struct UBrainComponent : UActorComponent {
	struct UBlackboardComponent* BlackboardComp; // 0x160(0x08)
	struct AAIController* AIOwner; // 0x168(0x08)
	char pad_170[0x40]; // 0x170(0x40)

	void StopLogic(struct FString Reason); // Function AIModule.BrainComponent.StopLogic // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f03ce0
	void StartLogic(); // Function AIModule.BrainComponent.StartLogic // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x36ad7d0
	void RestartLogic(); // Function AIModule.BrainComponent.RestartLogic // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3edb670
	bool IsRunning(); // Function AIModule.BrainComponent.IsRunning // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ed8730
	bool IsPaused(); // Function AIModule.BrainComponent.IsPaused // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ee9ce0
};

// Class AIModule.BehaviorTreeComponent
// Size: 0x350 (Inherited: 0x1b0)
struct UBehaviorTreeComponent : UBrainComponent {
	char pad_1b0[0x20]; // 0x1b0(0x20)
	struct TArray<struct UBTNode*> NodeInstances; // 0x1d0(0x10)
	char pad_1e0[0x148]; // 0x1e0(0x148)
	struct UBehaviorTree* DefaultBehaviorTreeAsset; // 0x328(0x08)
	char pad_330[0x20]; // 0x330(0x20)

	void SetDynamicSubtree(struct FGameplayTag InjectTag, struct UBehaviorTree* BehaviorAsset); // Function AIModule.BehaviorTreeComponent.SetDynamicSubtree // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e972d0
	double GetTagCooldownEndTime(struct FGameplayTag CooldownTag); // Function AIModule.BehaviorTreeComponent.GetTagCooldownEndTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ebf250
	void AddCooldownTagDuration(struct FGameplayTag CooldownTag, float CooldownDuration, bool bAddToExistingDuration); // Function AIModule.BehaviorTreeComponent.AddCooldownTagDuration // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3eb7ed0
};

// Class AIModule.BehaviorTreeManager
// Size: 0xc0 (Inherited: 0xa0)
struct UBehaviorTreeManager : UObject {
	int32_t MaxDebuggerSteps; // 0x98(0x04)
	struct TArray<struct FBehaviorTreeTemplateInfo> LoadedTemplates; // 0xa0(0x10)
	struct TArray<struct UBehaviorTreeComponent*> ActiveComponents; // 0xb0(0x10)
};

// Class AIModule.BehaviorTreeTypes
// Size: 0xa0 (Inherited: 0xa0)
struct UBehaviorTreeTypes : UObject {
};

// Class AIModule.BlackboardAssetProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardAssetProvider : UInterface {

	struct UBlackboardData* GetBlackboardAsset(); // Function AIModule.BlackboardAssetProvider.GetBlackboardAsset // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e8faf0
};

// Class AIModule.BlackboardComponent
// Size: 0x260 (Inherited: 0x160)
struct UBlackboardComponent : UActorComponent {
	struct UBrainComponent* BrainComp; // 0x158(0x08)
	struct UBlackboardData* DefaultBlackboardAsset; // 0x160(0x08)
	struct UBlackboardData* BlackboardAsset; // 0x168(0x08)
	char pad_178[0x18]; // 0x178(0x18)
	struct TArray<struct UBlackboardKeyType*> KeyInstances; // 0x190(0x10)
	char pad_1a0[0xc0]; // 0x1a0(0xc0)

	void SetValueAsVector(struct FName& KeyName, struct FVector VectorValue); // Function AIModule.BlackboardComponent.SetValueAsVector // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3e93bd0
	void SetValueAsString(struct FName& KeyName, struct FString StringValue); // Function AIModule.BlackboardComponent.SetValueAsString // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3e94430
	void SetValueAsRotator(struct FName& KeyName, struct FRotator VectorValue); // Function AIModule.BlackboardComponent.SetValueAsRotator // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3e8ecf0
	void SetValueAsObject(struct FName& KeyName, struct UObject* ObjectValue); // Function AIModule.BlackboardComponent.SetValueAsObject // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ec2850
	void SetValueAsName(struct FName& KeyName, struct FName NameValue); // Function AIModule.BlackboardComponent.SetValueAsName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3eb2090
	void SetValueAsInt(struct FName& KeyName, int32_t IntValue); // Function AIModule.BlackboardComponent.SetValueAsInt // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3e9e6f0
	void SetValueAsFloat(struct FName& KeyName, float FloatValue); // Function AIModule.BlackboardComponent.SetValueAsFloat // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3e9e9d0
	void SetValueAsEnum(struct FName& KeyName, char EnumValue); // Function AIModule.BlackboardComponent.SetValueAsEnum // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3e904c0
	void SetValueAsClass(struct FName& KeyName, struct UObject* ClassValue); // Function AIModule.BlackboardComponent.SetValueAsClass // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea36b0
	void SetValueAsBool(struct FName& KeyName, bool BoolValue); // Function AIModule.BlackboardComponent.SetValueAsBool // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3e8fbe0
	bool IsVectorValueSet(struct FName& KeyName); // Function AIModule.BlackboardComponent.IsVectorValueSet // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e9c4e0
	struct FVector GetValueAsVector(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsVector // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3eabfb0
	struct FString GetValueAsString(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsString // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3eb9400
	struct FRotator GetValueAsRotator(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsRotator // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e97660
	struct UObject* GetValueAsObject(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsObject // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e8ee60
	struct FName GetValueAsName(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ea7130
	int32_t GetValueAsInt(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsInt // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ebe330
	float GetValueAsFloat(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsFloat // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e8cfe0
	char GetValueAsEnum(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsEnum // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e93d40
	struct UObject* GetValueAsClass(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsClass // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e9b7b0
	bool GetValueAsBool(struct FName& KeyName); // Function AIModule.BlackboardComponent.GetValueAsBool // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e93040
	bool GetRotationFromEntry(struct FName& KeyName, struct FRotator& ResultRotation); // Function AIModule.BlackboardComponent.GetRotationFromEntry // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e94100
	bool GetLocationFromEntry(struct FName& KeyName, struct FVector& ResultLocation); // Function AIModule.BlackboardComponent.GetLocationFromEntry // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e8ef80
	void ClearValue(struct FName& KeyName); // Function AIModule.BlackboardComponent.ClearValue // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3ea0bd0
};

// Class AIModule.BlackboardData
// Size: 0xc0 (Inherited: 0xa0)
struct UBlackboardData : UDataAsset {
	struct UBlackboardData* Parent; // 0xa0(0x08)
	struct TArray<struct FBlackboardEntry> Keys; // 0xa8(0x10)
	char bHasSynchronizedKeys : 1; // 0xb8(0x01)
	char pad_b8_1 : 7; // 0xb8(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
};

// Class AIModule.BlackboardKeyType
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType : UObject {
};

// Class AIModule.BlackboardKeyType_Bool
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType_Bool : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Class
// Size: 0xb0 (Inherited: 0xa0)
struct UBlackboardKeyType_Class : UBlackboardKeyType {
	ClassPtrProperty BaseClass; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class AIModule.BlackboardKeyType_Enum
// Size: 0xc0 (Inherited: 0xa0)
struct UBlackboardKeyType_Enum : UBlackboardKeyType {
	struct UEnum* EnumType; // 0xa0(0x08)
	struct FString EnumName; // 0xa8(0x10)
	char bIsEnumNameValid : 1; // 0xb8(0x01)
	char pad_b8_1 : 7; // 0xb8(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
};

// Class AIModule.BlackboardKeyType_Float
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType_Float : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Int
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType_Int : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_Name
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType_Name : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_NativeEnum
// Size: 0xc0 (Inherited: 0xa0)
struct UBlackboardKeyType_NativeEnum : UBlackboardKeyType {
	struct FString EnumName; // 0xa0(0x10)
	struct UEnum* EnumType; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class AIModule.BlackboardKeyType_Object
// Size: 0xb0 (Inherited: 0xa0)
struct UBlackboardKeyType_Object : UBlackboardKeyType {
	ClassPtrProperty BaseClass; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class AIModule.BlackboardKeyType_Rotator
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType_Rotator : UBlackboardKeyType {
};

// Class AIModule.BlackboardKeyType_String
// Size: 0xb0 (Inherited: 0xa0)
struct UBlackboardKeyType_String : UBlackboardKeyType {
	struct FString StringValue; // 0xa0(0x10)
};

// Class AIModule.BlackboardKeyType_Vector
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardKeyType_Vector : UBlackboardKeyType {
};

// Class AIModule.BTNode
// Size: 0xd0 (Inherited: 0xa0)
struct UBTNode : UObject {
	struct FString NodeName; // 0xa0(0x10)
	struct UBehaviorTree* TreeAsset; // 0xb0(0x08)
	struct UBTCompositeNode* ParentNode; // 0xb8(0x08)
	char pad_c0[0x10]; // 0xc0(0x10)
};

// Class AIModule.BTAuxiliaryNode
// Size: 0xd0 (Inherited: 0xd0)
struct UBTAuxiliaryNode : UBTNode {
};

// Class AIModule.BTCompositeNode
// Size: 0xf0 (Inherited: 0xd0)
struct UBTCompositeNode : UBTNode {
	struct TArray<struct FBTCompositeChild> Children; // 0xc8(0x10)
	struct TArray<struct UBTService*> Services; // 0xd8(0x10)
	char bApplyDecoratorScope : 1; // 0xe8(0x01)
};

// Class AIModule.BTDecorator
// Size: 0xe0 (Inherited: 0xd0)
struct UBTDecorator : UBTAuxiliaryNode {
	char pad_d0_0 : 7; // 0xd0(0x01)
	char bInverseCondition : 1; // 0xd0(0x01)
	char pad_d1[0x3]; // 0xd1(0x03)
	enum class EBTFlowAbortMode FlowAbortMode; // 0xd4(0x01)
	char pad_d5[0xb]; // 0xd5(0x0b)
};

// Class AIModule.BTFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UBTFunctionLibrary : UBlueprintFunctionLibrary {

	void StopUsingExternalEvent(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.StopUsingExternalEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x257bb60
	void StartUsingExternalEvent(struct UBTNode* NodeOwner, struct AActor* OwningActor); // Function AIModule.BTFunctionLibrary.StartUsingExternalEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3a51060
	void SetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FVector Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3ec5a00
	void SetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FString Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ece320
	void SetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FRotator Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsRotator // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3ee51e0
	void SetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsObject // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3f06ee0
	void SetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct FName Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsName // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ee63f0
	void SetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, int32_t Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsInt // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ef7010
	void SetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, float Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsFloat // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ee0c00
	void SetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, char Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsEnum // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ed0d10
	void SetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, struct UObject* Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsClass // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3efc290
	void SetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key, bool Value); // Function AIModule.BTFunctionLibrary.SetBlackboardValueAsBool // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3efe580
	struct UBlackboardComponent* GetOwnersBlackboard(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.GetOwnersBlackboard // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3ecb970
	struct UBehaviorTreeComponent* GetOwnerComponent(struct UBTNode* NodeOwner); // Function AIModule.BTFunctionLibrary.GetOwnerComponent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3edf4e0
	struct FVector GetBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3eee0e0
	struct FString GetBlackboardValueAsString(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3ee6070
	struct FRotator GetBlackboardValueAsRotator(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsRotator // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3f0b420
	struct UObject* GetBlackboardValueAsObject(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsObject // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3ed4550
	struct FName GetBlackboardValueAsName(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsName // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3eff2c0
	int32_t GetBlackboardValueAsInt(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsInt // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3f03500
	float GetBlackboardValueAsFloat(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsFloat // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3ee2c30
	char GetBlackboardValueAsEnum(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsEnum // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3efbe10
	struct UObject* GetBlackboardValueAsClass(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsClass // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3f04230
	bool GetBlackboardValueAsBool(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsBool // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3eda290
	struct AActor* GetBlackboardValueAsActor(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.GetBlackboardValueAsActor // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x3ee3850
	void ClearBlackboardValueAsVector(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.ClearBlackboardValueAsVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ecc7c0
	void ClearBlackboardValue(struct UBTNode* NodeOwner, struct FBlackboardKeySelector& Key); // Function AIModule.BTFunctionLibrary.ClearBlackboardValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3ecc7c0
};

// Class AIModule.BTService
// Size: 0xe0 (Inherited: 0xd0)
struct UBTService : UBTAuxiliaryNode {
	float Interval; // 0xd0(0x04)
	float RandomDeviation; // 0xd4(0x04)
	char bCallTickOnSearchStart : 1; // 0xd8(0x01)
	char bRestartTimerOnEachActivation : 1; // 0xd8(0x01)
	char pad_d8_2 : 6; // 0xd8(0x01)
	char pad_d9[0x7]; // 0xd9(0x07)
};

// Class AIModule.BTTaskNode
// Size: 0xe0 (Inherited: 0xd0)
struct UBTTaskNode : UBTNode {
	struct TArray<struct UBTService*> Services; // 0xc8(0x10)
	char bIgnoreRestartSelf : 1; // 0xd8(0x01)
};

// Class AIModule.BTComposite_Selector
// Size: 0xf0 (Inherited: 0xf0)
struct UBTComposite_Selector : UBTCompositeNode {
};

// Class AIModule.BTComposite_Sequence
// Size: 0xf0 (Inherited: 0xf0)
struct UBTComposite_Sequence : UBTCompositeNode {
};

// Class AIModule.BTComposite_SimpleParallel
// Size: 0x100 (Inherited: 0xf0)
struct UBTComposite_SimpleParallel : UBTCompositeNode {
	enum class EBTParallelMode FinishMode; // 0xf0(0x01)
	char pad_f1[0xf]; // 0xf1(0x0f)
};

// Class AIModule.BTDecorator_BlackboardBase
// Size: 0x100 (Inherited: 0xe0)
struct UBTDecorator_BlackboardBase : UBTDecorator {
	struct FBlackboardKeySelector BlackboardKey; // 0xd8(0x28)
};

// Class AIModule.BTDecorator_Blackboard
// Size: 0x130 (Inherited: 0x100)
struct UBTDecorator_Blackboard : UBTDecorator_BlackboardBase {
	int32_t IntValue; // 0x100(0x04)
	float FloatValue; // 0x104(0x04)
	struct FString StringValue; // 0x108(0x10)
	struct FString CachedDescription; // 0x118(0x10)
	char OperationType; // 0x128(0x01)
	enum class EBTBlackboardRestart NotifyObserver; // 0x129(0x01)
	char pad_12a[0x6]; // 0x12a(0x06)
};

// Class AIModule.BTDecorator_BlueprintBase
// Size: 0x110 (Inherited: 0xe0)
struct UBTDecorator_BlueprintBase : UBTDecorator {
	struct AAIController* AIOwner; // 0xd8(0x08)
	struct AActor* ActorOwner; // 0xe0(0x08)
	struct TArray<struct FName> ObservedKeyNames; // 0xe8(0x10)
	char pad_100[0x8]; // 0x100(0x08)
	char bShowPropertyDetails : 1; // 0x108(0x01)
	char bCheckConditionOnlyBlackBoardChanges : 1; // 0x108(0x01)
	char pad_108_2 : 6; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTDecorator_BlueprintBase.ReceiveTickAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function AIModule.BTDecorator_BlueprintBase.ReceiveTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveObserverDeactivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivatedAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveObserverDeactivated(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverDeactivated // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveObserverActivatedAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivatedAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveObserverActivated(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.ReceiveObserverActivated // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExecutionStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStartAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExecutionStart(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionStart // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExecutionFinishAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, enum class EBTNodeResult NodeResult); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinishAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExecutionFinish(struct AActor* OwnerActor, enum class EBTNodeResult NodeResult); // Function AIModule.BTDecorator_BlueprintBase.ReceiveExecutionFinish // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheckAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool PerformConditionCheck(struct AActor* OwnerActor); // Function AIModule.BTDecorator_BlueprintBase.PerformConditionCheck // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool IsDecoratorObserverActive(); // Function AIModule.BTDecorator_BlueprintBase.IsDecoratorObserverActive // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3efc0a0
	bool IsDecoratorExecutionActive(); // Function AIModule.BTDecorator_BlueprintBase.IsDecoratorExecutionActive // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f05b40
};

// Class AIModule.BTDecorator_CheckGameplayTagsOnActor
// Size: 0x140 (Inherited: 0xe0)
struct UBTDecorator_CheckGameplayTagsOnActor : UBTDecorator {
	struct FBlackboardKeySelector ActorToCheck; // 0xd8(0x28)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x100(0x01)
	struct FGameplayTagContainer GameplayTags; // 0x108(0x20)
	struct FString CachedDescription; // 0x128(0x10)
	char pad_139[0x7]; // 0x139(0x07)
};

// Class AIModule.BTDecorator_CompareBBEntries
// Size: 0x130 (Inherited: 0xe0)
struct UBTDecorator_CompareBBEntries : UBTDecorator {
	enum class EBlackBoardEntryComparison Operator; // 0xd8(0x01)
	struct FBlackboardKeySelector BlackboardKeyA; // 0xe0(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x108(0x28)
};

// Class AIModule.BTDecorator_ConditionalLoop
// Size: 0x130 (Inherited: 0x130)
struct UBTDecorator_ConditionalLoop : UBTDecorator_Blackboard {
};

// Class AIModule.BTDecorator_ConeCheck
// Size: 0x160 (Inherited: 0xe0)
struct UBTDecorator_ConeCheck : UBTDecorator {
	float ConeHalfAngle; // 0xd8(0x04)
	struct FBlackboardKeySelector ConeOrigin; // 0xe0(0x28)
	struct FBlackboardKeySelector ConeDirection; // 0x108(0x28)
	struct FBlackboardKeySelector Observed; // 0x130(0x28)
	char pad_15c[0x4]; // 0x15c(0x04)
};

// Class AIModule.BTDecorator_Cooldown
// Size: 0xe0 (Inherited: 0xe0)
struct UBTDecorator_Cooldown : UBTDecorator {
	float CoolDownTime; // 0xd8(0x04)
};

// Class AIModule.BTDecorator_DoesPathExist
// Size: 0x140 (Inherited: 0xe0)
struct UBTDecorator_DoesPathExist : UBTDecorator {
	struct FBlackboardKeySelector BlackboardKeyA; // 0xd8(0x28)
	struct FBlackboardKeySelector BlackboardKeyB; // 0x100(0x28)
	char bUseSelf : 1; // 0x128(0x01)
	enum class EPathExistanceQueryType PathQueryType; // 0x12c(0x01)
	struct UNavigationQueryFilter* FilterClass; // 0x130(0x08)
	char pad_139_1 : 7; // 0x139(0x01)
	char pad_13a[0x6]; // 0x13a(0x06)
};

// Class AIModule.BTDecorator_ForceSuccess
// Size: 0xe0 (Inherited: 0xe0)
struct UBTDecorator_ForceSuccess : UBTDecorator {
};

// Class AIModule.BTDecorator_IsAtLocation
// Size: 0x150 (Inherited: 0x100)
struct UBTDecorator_IsAtLocation : UBTDecorator_BlackboardBase {
	float AcceptableRadius; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FAIDataProviderFloatValue ParametrizedAcceptableRadius; // 0x108(0x38)
	enum class FAIDistanceType GeometricDistanceType; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	char bUseParametrizedRadius : 1; // 0x144(0x01)
	char bUseNavAgentGoalLocation : 1; // 0x144(0x01)
	char bPathFindingBasedTest : 1; // 0x144(0x01)
	char pad_144_3 : 5; // 0x144(0x01)
	char pad_145[0xb]; // 0x145(0x0b)
};

// Class AIModule.BTDecorator_IsBBEntryOfClass
// Size: 0x110 (Inherited: 0x100)
struct UBTDecorator_IsBBEntryOfClass : UBTDecorator_BlackboardBase {
	struct UObject* TestClass; // 0x100(0x08)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class AIModule.BTDecorator_KeepInCone
// Size: 0x140 (Inherited: 0xe0)
struct UBTDecorator_KeepInCone : UBTDecorator {
	float ConeHalfAngle; // 0xd8(0x04)
	struct FBlackboardKeySelector ConeOrigin; // 0xe0(0x28)
	struct FBlackboardKeySelector Observed; // 0x108(0x28)
	char bUseSelfAsOrigin : 1; // 0x130(0x01)
	char bUseSelfAsObserved : 1; // 0x130(0x01)
	char pad_134_2 : 6; // 0x134(0x01)
	char pad_135[0xb]; // 0x135(0x0b)
};

// Class AIModule.BTDecorator_Loop
// Size: 0xf0 (Inherited: 0xe0)
struct UBTDecorator_Loop : UBTDecorator {
	int32_t NumLoops; // 0xd8(0x04)
	bool bInfiniteLoop; // 0xdc(0x01)
	float InfiniteLoopTimeoutTime; // 0xe0(0x04)
	char pad_e9[0x7]; // 0xe9(0x07)
};

// Class AIModule.BTDecorator_ReachedMoveGoal
// Size: 0xe0 (Inherited: 0xe0)
struct UBTDecorator_ReachedMoveGoal : UBTDecorator {
};

// Class AIModule.BTDecorator_SetTagCooldown
// Size: 0xf0 (Inherited: 0xe0)
struct UBTDecorator_SetTagCooldown : UBTDecorator {
	struct FGameplayTag CooldownTag; // 0xd8(0x08)
	float CooldownDuration; // 0xe0(0x04)
	bool bAddToExistingDuration; // 0xe4(0x01)
	char pad_ed[0x3]; // 0xed(0x03)
};

// Class AIModule.BTDecorator_TagCooldown
// Size: 0xf0 (Inherited: 0xe0)
struct UBTDecorator_TagCooldown : UBTDecorator {
	struct FGameplayTag CooldownTag; // 0xd8(0x08)
	float CooldownDuration; // 0xe0(0x04)
	bool bAddToExistingDuration; // 0xe4(0x01)
	bool bActivatesCooldown; // 0xe5(0x01)
	char pad_ee[0x2]; // 0xee(0x02)
};

// Class AIModule.BTDecorator_TimeLimit
// Size: 0xe0 (Inherited: 0xe0)
struct UBTDecorator_TimeLimit : UBTDecorator {
	float TimeLimit; // 0xd8(0x04)
};

// Class AIModule.BTService_BlackboardBase
// Size: 0x110 (Inherited: 0xe0)
struct UBTService_BlackboardBase : UBTService {
	struct FBlackboardKeySelector BlackboardKey; // 0xe0(0x28)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class AIModule.BTService_BlueprintBase
// Size: 0x110 (Inherited: 0xe0)
struct UBTService_BlueprintBase : UBTService {
	struct AAIController* AIOwner; // 0xe0(0x08)
	struct AActor* ActorOwner; // 0xe8(0x08)
	char pad_f0[0x10]; // 0xf0(0x10)
	char bShowPropertyDetails : 1; // 0x100(0x01)
	char bShowEventDetails : 1; // 0x100(0x01)
	char pad_100_2 : 6; // 0x100(0x01)
	char pad_101[0xf]; // 0x101(0x0f)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTService_BlueprintBase.ReceiveTickAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function AIModule.BTService_BlueprintBase.ReceiveTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTService_BlueprintBase.ReceiveSearchStartAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveSearchStart(struct AActor* OwnerActor); // Function AIModule.BTService_BlueprintBase.ReceiveSearchStart // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTService_BlueprintBase.ReceiveDeactivationAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveDeactivation(struct AActor* OwnerActor); // Function AIModule.BTService_BlueprintBase.ReceiveDeactivation // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTService_BlueprintBase.ReceiveActivationAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveActivation(struct AActor* OwnerActor); // Function AIModule.BTService_BlueprintBase.ReceiveActivation // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool IsServiceActive(); // Function AIModule.BTService_BlueprintBase.IsServiceActive // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ec76b0
};

// Class AIModule.BTService_DefaultFocus
// Size: 0x110 (Inherited: 0x110)
struct UBTService_DefaultFocus : UBTService_BlackboardBase {
	char FocusPriority; // 0x108(0x01)
};

// Class AIModule.BTService_RunEQS
// Size: 0x170 (Inherited: 0x110)
struct UBTService_RunEQS : UBTService_BlackboardBase {
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x108(0x48)
	bool bUpdateBBOnFail; // 0x150(0x01)
	char pad_159[0x17]; // 0x159(0x17)
};

// Class AIModule.BTTask_BlackboardBase
// Size: 0x110 (Inherited: 0xe0)
struct UBTTask_BlackboardBase : UBTTaskNode {
	struct FBlackboardKeySelector BlackboardKey; // 0xe0(0x28)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class AIModule.BTTask_BlueprintBase
// Size: 0x120 (Inherited: 0xe0)
struct UBTTask_BlueprintBase : UBTTaskNode {
	struct AAIController* AIOwner; // 0xe0(0x08)
	struct AActor* ActorOwner; // 0xe8(0x08)
	struct FIntervalCountdown TickInterval; // 0xf0(0x08)
	char pad_f8[0x18]; // 0xf8(0x18)
	char bShowPropertyDetails : 1; // 0x110(0x01)
	char pad_110_1 : 7; // 0x110(0x01)
	char pad_111[0xf]; // 0x111(0x0f)

	void SetFinishOnMessageWithId(struct FName MessageName, int32_t RequestID); // Function AIModule.BTTask_BlueprintBase.SetFinishOnMessageWithId // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x3efea70
	void SetFinishOnMessage(struct FName MessageName); // Function AIModule.BTTask_BlueprintBase.SetFinishOnMessage // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x3ee30b0
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function AIModule.BTTask_BlueprintBase.ReceiveTickAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function AIModule.BTTask_BlueprintBase.ReceiveTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTTask_BlueprintBase.ReceiveExecuteAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExecute(struct AActor* OwnerActor); // Function AIModule.BTTask_BlueprintBase.ReceiveExecute // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function AIModule.BTTask_BlueprintBase.ReceiveAbortAI // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveAbort(struct AActor* OwnerActor); // Function AIModule.BTTask_BlueprintBase.ReceiveAbort // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool IsTaskExecuting(); // Function AIModule.BTTask_BlueprintBase.IsTaskExecuting // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ee3700
	bool IsTaskAborting(); // Function AIModule.BTTask_BlueprintBase.IsTaskAborting // (Final|RequiredAPI|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x3eff1a0
	void FinishExecute(bool bSuccess); // Function AIModule.BTTask_BlueprintBase.FinishExecute // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x3ecb310
	void FinishAbort(); // Function AIModule.BTTask_BlueprintBase.FinishAbort // (Final|RequiredAPI|Native|Protected|BlueprintCallable) // @ game+0x3ef96f0
};

// Class AIModule.BTTask_FinishWithResult
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_FinishWithResult : UBTTaskNode {
	enum class EBTNodeResult Result; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class AIModule.BTTask_GameplayTaskBase
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_GameplayTaskBase : UBTTaskNode {
	char bWaitForGameplayTask : 1; // 0xe0(0x01)
	char pad_e0_1 : 7; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class AIModule.BTTask_MakeNoise
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_MakeNoise : UBTTaskNode {
	float Loudnes; // 0xe0(0x04)
	char pad_e4[0xc]; // 0xe4(0x0c)
};

// Class AIModule.BTTask_MoveTo
// Size: 0x120 (Inherited: 0x110)
struct UBTTask_MoveTo : UBTTask_BlackboardBase {
	float AcceptableRadius; // 0x108(0x04)
	struct UNavigationQueryFilter* FilterClass; // 0x110(0x08)
	float ObservedBlackboardValueTolerance; // 0x118(0x04)
	char bObserveBlackboardValue : 1; // 0x11c(0x01)
	char bAllowStrafe : 1; // 0x11c(0x01)
	char bAllowPartialPath : 1; // 0x11c(0x01)
	char bTrackMovingGoal : 1; // 0x11c(0x01)
	char bRequireNavigableEndLocation : 1; // 0x11c(0x01)
	char bProjectGoalLocation : 1; // 0x11c(0x01)
	char bReachTestIncludesAgentRadius : 1; // 0x11c(0x01)
	char bReachTestIncludesGoalRadius : 1; // 0x11c(0x01)
	char bStopOnOverlap : 1; // 0x11d(0x01)
	char bStopOnOverlapNeedsUpdate : 1; // 0x11d(0x01)
};

// Class AIModule.BTTask_MoveDirectlyToward
// Size: 0x130 (Inherited: 0x120)
struct UBTTask_MoveDirectlyToward : UBTTask_MoveTo {
	char bDisablePathUpdateOnGoalLocationChange : 1; // 0x120(0x01)
	char bProjectVectorGoalToNavigation : 1; // 0x120(0x01)
	char bUpdatedDeprecatedProperties : 1; // 0x120(0x01)
	char pad_120_3 : 5; // 0x120(0x01)
	char pad_121[0xf]; // 0x121(0x0f)
};

// Class AIModule.BTTask_PawnActionBase
// Size: 0xe0 (Inherited: 0xe0)
struct UBTTask_PawnActionBase : UBTTaskNode {
};

// Class AIModule.BTTask_PlayAnimation
// Size: 0x120 (Inherited: 0xe0)
struct UBTTask_PlayAnimation : UBTTaskNode {
	struct UAnimationAsset* AnimationToPlay; // 0xe0(0x08)
	char bLooping : 1; // 0xe8(0x01)
	char bNonBlocking : 1; // 0xe8(0x01)
	char pad_e8_2 : 6; // 0xe8(0x01)
	char pad_e9[0x7]; // 0xe9(0x07)
	struct UBehaviorTreeComponent* MyOwnerComp; // 0xf0(0x08)
	struct USkeletalMeshComponent* CachedSkelMesh; // 0xf8(0x08)
	char pad_100[0x20]; // 0x100(0x20)
};

// Class AIModule.BTTask_PlaySound
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_PlaySound : UBTTaskNode {
	struct USoundCue* SoundToPlay; // 0xe0(0x08)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class AIModule.BTTask_PushPawnAction
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_PushPawnAction : UBTTask_PawnActionBase {
	struct UPawnAction* Action; // 0xe0(0x08)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class AIModule.BTTask_RotateToFaceBBEntry
// Size: 0x110 (Inherited: 0x110)
struct UBTTask_RotateToFaceBBEntry : UBTTask_BlackboardBase {
	float Precision; // 0x108(0x04)
};

// Class AIModule.BTTask_RunBehavior
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_RunBehavior : UBTTaskNode {
	struct UBehaviorTree* BehaviorAsset; // 0xe0(0x08)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class AIModule.BTTask_RunBehaviorDynamic
// Size: 0x100 (Inherited: 0xe0)
struct UBTTask_RunBehaviorDynamic : UBTTaskNode {
	struct FGameplayTag InjectionTag; // 0xe0(0x08)
	struct UBehaviorTree* DefaultBehaviorAsset; // 0xe8(0x08)
	struct UBehaviorTree* BehaviorAsset; // 0xf0(0x08)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class AIModule.BTTask_RunEQSQuery
// Size: 0x1d0 (Inherited: 0x110)
struct UBTTask_RunEQSQuery : UBTTask_BlackboardBase {
	struct UEnvQuery* QueryTemplate; // 0x108(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0x110(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x120(0x10)
	enum class EEnvQueryRunMode RunMode; // 0x130(0x01)
	struct FBlackboardKeySelector EQSQueryBlackboardKey; // 0x138(0x28)
	bool bUseBBKey; // 0x160(0x01)
	char pad_162[0x6]; // 0x162(0x06)
	struct FEQSParametrizedQueryExecutionRequest EQSRequest; // 0x168(0x48)
	bool bUpdateBBOnFail; // 0x1b0(0x01)
	char pad_1b1[0x1f]; // 0x1b1(0x1f)
};

// Class AIModule.BTTask_SetTagCooldown
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_SetTagCooldown : UBTTaskNode {
	struct FGameplayTag CooldownTag; // 0xe0(0x08)
	bool bAddToExistingDuration; // 0xe8(0x01)
	char pad_e9[0x3]; // 0xe9(0x03)
	float CooldownDuration; // 0xec(0x04)
};

// Class AIModule.BTTask_Wait
// Size: 0xf0 (Inherited: 0xe0)
struct UBTTask_Wait : UBTTaskNode {
	float WaitTime; // 0xe0(0x04)
	float RandomDeviation; // 0xe4(0x04)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class AIModule.BTTask_WaitBlackboardTime
// Size: 0x110 (Inherited: 0xf0)
struct UBTTask_WaitBlackboardTime : UBTTask_Wait {
	struct FBlackboardKeySelector BlackboardKey; // 0xe8(0x28)
};

// Class AIModule.AIBlueprintHelperLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIBlueprintHelperLibrary : UBlueprintFunctionLibrary {

	void UnlockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bUnlockMovement, bool UnlockAILogic); // Function AIModule.AIBlueprintHelperLibrary.UnlockAIResourcesWithAnimation // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x3ede330
	struct APawn* SpawnAIFromClass(struct UObject* WorldContextObject, struct APawn* PawnClass, struct UBehaviorTree* BehaviorTree, struct FVector Location, struct FRotator Rotation, bool bNoCollisionFail, struct AActor* Owner); // Function AIModule.AIBlueprintHelperLibrary.SpawnAIFromClass // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3eea6b0
	void SimpleMoveToLocation(struct AController* Controller, struct FVector& Goal); // Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToLocation // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3ecdd00
	void SimpleMoveToActor(struct AController* Controller, struct AActor* Goal); // Function AIModule.AIBlueprintHelperLibrary.SimpleMoveToActor // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3eda6f0
	void SendAIMessage(struct APawn* Target, struct FName Message, struct UObject* MessageSource, bool bSuccess); // Function AIModule.AIBlueprintHelperLibrary.SendAIMessage // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3ed5f90
	void LockAIResourcesWithAnimation(struct UAnimInstance* AnimInstance, bool bLockMovement, bool LockAILogic); // Function AIModule.AIBlueprintHelperLibrary.LockAIResourcesWithAnimation // (Final|RequiredAPI|BlueprintAuthorityOnly|Native|Static|Public|BlueprintCallable) // @ game+0x3f092e0
	bool IsValidAIRotation(struct FRotator Rotation); // Function AIModule.AIBlueprintHelperLibrary.IsValidAIRotation // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3ecce70
	bool IsValidAILocation(struct FVector Location); // Function AIModule.AIBlueprintHelperLibrary.IsValidAILocation // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3eefcb0
	bool IsValidAIDirection(struct FVector DirectionVector); // Function AIModule.AIBlueprintHelperLibrary.IsValidAIDirection // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3f03d90
	int32_t GetNextNavLinkIndex(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetNextNavLinkIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3ec6920
	struct TArray<struct FVector> GetCurrentPathPoints(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathPoints // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3ee6e50
	int32_t GetCurrentPathIndex(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetCurrentPathIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3edfa10
	struct UNavigationPath* GetCurrentPath(struct AController* Controller); // Function AIModule.AIBlueprintHelperLibrary.GetCurrentPath // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3ed3b20
	struct UBlackboardComponent* GetBlackboard(struct AActor* Target); // Function AIModule.AIBlueprintHelperLibrary.GetBlackboard // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3f01330
	struct AAIController* GetAIController(struct AActor* ControlledActor); // Function AIModule.AIBlueprintHelperLibrary.GetAIController // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3edcdd0
	struct UAIAsyncTaskBlueprintProxy* CreateMoveToProxyObject(struct UObject* WorldContextObject, struct APawn* Pawn, struct FVector Destination, struct AActor* TargetActor, float AcceptanceRadius, bool bStopOnOverlap); // Function AIModule.AIBlueprintHelperLibrary.CreateMoveToProxyObject // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3f07480
};

// Class AIModule.AIDataProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UAIDataProvider : UObject {
};

// Class AIModule.AIDataProvider_QueryParams
// Size: 0xb0 (Inherited: 0xa0)
struct UAIDataProvider_QueryParams : UAIDataProvider {
	struct FName ParamName; // 0x98(0x08)
	float FloatValue; // 0xa0(0x04)
	int32_t IntValue; // 0xa4(0x04)
	bool BoolValue; // 0xa8(0x01)
};

// Class AIModule.AIDataProvider_Random
// Size: 0xc0 (Inherited: 0xb0)
struct UAIDataProvider_Random : UAIDataProvider_QueryParams {
	float Min; // 0xb0(0x04)
	float Max; // 0xb4(0x04)
	char bInteger : 1; // 0xb8(0x01)
	char pad_b8_1 : 7; // 0xb8(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
};

// Class AIModule.DetourCrowdAIController
// Size: 0x4c0 (Inherited: 0x4c0)
struct ADetourCrowdAIController : AAIController {
};

// Class AIModule.EnvQueryContext
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryContext : UObject {
};

// Class AIModule.EnvQueryContext_BlueprintBase
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryContext_BlueprintBase : UEnvQueryContext {

	void ProvideSingleLocation(struct UObject* QuerierObject, struct AActor* QuerierActor, struct FVector& ResultingLocation); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleLocation // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x4abfe0
	void ProvideSingleActor(struct UObject* QuerierObject, struct AActor* QuerierActor, struct AActor*& ResultingActor); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideSingleActor // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ProvideLocationsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct FVector>& ResultingLocationSet); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideLocationsSet // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ProvideActorsSet(struct UObject* QuerierObject, struct AActor* QuerierActor, struct TArray<struct AActor*>& ResultingActorsSet); // Function AIModule.EnvQueryContext_BlueprintBase.ProvideActorsSet // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class AIModule.EnvQueryContext_Item
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryContext_Item : UEnvQueryContext {
};

// Class AIModule.EnvQueryContext_Querier
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryContext_Querier : UEnvQueryContext {
};

// Class AIModule.EnvQuery
// Size: 0xc0 (Inherited: 0xa0)
struct UEnvQuery : UDataAsset {
	struct FName QueryName; // 0xa0(0x08)
	struct TArray<struct UEnvQueryOption*> Options; // 0xa8(0x10)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class AIModule.EnvQueryDebugHelpers
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryDebugHelpers : UObject {
};

// Class AIModule.EnvQueryNode
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryNode : UObject {
	int32_t VerNum; // 0x98(0x04)
};

// Class AIModule.EnvQueryGenerator
// Size: 0xc0 (Inherited: 0xa0)
struct UEnvQueryGenerator : UEnvQueryNode {
	struct FString OptionName; // 0xa0(0x10)
	struct UEnvQueryItemType* ItemType; // 0xb0(0x08)
	char bAutoSortTests : 1; // 0xb8(0x01)
	char pad_b8_1 : 7; // 0xb8(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
};

// Class AIModule.EnvQueryInstanceBlueprintWrapper
// Size: 0xf0 (Inherited: 0xa0)
struct UEnvQueryInstanceBlueprintWrapper : UObject {
	int32_t QueryID; // 0xa0(0x04)
	char pad_a4[0x24]; // 0xa4(0x24)
	struct UEnvQueryItemType* ItemType; // 0xc8(0x08)
	int32_t OptionIndex; // 0xd0(0x04)
	char pad_d4[0x4]; // 0xd4(0x04)
	struct FMulticastInlineDelegate OnQueryFinishedEvent; // 0xd8(0x10)
	char pad_e8[0x8]; // 0xe8(0x08)

	void SetNamedParam(struct FName ParamName, float Value); // Function AIModule.EnvQueryInstanceBlueprintWrapper.SetNamedParam // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3ed85b0
	struct TArray<struct FVector> GetResultsAsLocations(); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsLocations // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ee2f90
	struct TArray<struct AActor*> GetResultsAsActors(); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetResultsAsActors // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3eee840
	bool GetQueryResultsAsLocations(struct TArray<struct FVector>& ResultLocations); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsLocations // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x3ecd5b0
	bool GetQueryResultsAsActors(struct TArray<struct AActor*>& ResultActors); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetQueryResultsAsActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|Const) // @ game+0x3f055c0
	float GetItemScore(int32_t ItemIndex); // Function AIModule.EnvQueryInstanceBlueprintWrapper.GetItemScore // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ef2cf0
	void EQSQueryDoneSignature__DelegateSignature(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, enum class EEnvQueryStatus QueryStatus); // DelegateFunction AIModule.EnvQueryInstanceBlueprintWrapper.EQSQueryDoneSignature__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
};

// Class AIModule.EnvQueryManager
// Size: 0x1d0 (Inherited: 0xb0)
struct UEnvQueryManager : UAISubsystem {
	char pad_b0[0x68]; // 0xb0(0x68)
	struct TArray<struct FEnvQueryInstanceCache> InstanceCache; // 0x118(0x10)
	struct TArray<struct UEnvQueryContext*> LocalContexts; // 0x128(0x10)
	struct TArray<struct UEnvQueryInstanceBlueprintWrapper*> GCShieldedWrappers; // 0x138(0x10)
	char pad_148[0x54]; // 0x148(0x54)
	float MaxAllowedTestingTime; // 0x19c(0x04)
	bool bTestQueriesUsingBreadth; // 0x1a0(0x01)
	char pad_1a1[0x3]; // 0x1a1(0x03)
	int32_t QueryCountWarningThreshold; // 0x1a4(0x04)
	double QueryCountWarningInterval; // 0x1a8(0x08)
	double ExecutionTimeWarningSeconds; // 0x1b0(0x08)
	double HandlingResultTimeWarningSeconds; // 0x1b8(0x08)
	double GenerationTimeWarningSeconds; // 0x1c0(0x08)
	char pad_1c8[0x8]; // 0x1c8(0x08)

	struct UEnvQueryInstanceBlueprintWrapper* RunEQSQuery(struct UObject* WorldContextObject, struct UEnvQuery* QueryTemplate, struct UObject* Querier, enum class EEnvQueryRunMode RunMode, struct UEnvQueryInstanceBlueprintWrapper* WrapperClass); // Function AIModule.EnvQueryManager.RunEQSQuery // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3efba10
};

// Class AIModule.EnvQueryOption
// Size: 0xb0 (Inherited: 0xa0)
struct UEnvQueryOption : UObject {
	struct UEnvQueryGenerator* Generator; // 0x98(0x08)
	struct TArray<struct UEnvQueryTest*> Tests; // 0xa0(0x10)
};

// Class AIModule.EnvQueryTest
// Size: 0x270 (Inherited: 0xa0)
struct UEnvQueryTest : UEnvQueryNode {
	int32_t TestOrder; // 0xa0(0x04)
	enum class EEnvTestPurpose TestPurpose; // 0xa4(0x01)
	char pad_a5[0x3]; // 0xa5(0x03)
	struct FString TestComment; // 0xa8(0x10)
	enum class EEnvTestFilterOperator MultipleContextFilterOp; // 0xb8(0x01)
	enum class EEnvTestScoreOperator MultipleContextScoreOp; // 0xb9(0x01)
	enum class EEnvTestFilterType FilterType; // 0xba(0x01)
	char pad_bb[0x5]; // 0xbb(0x05)
	struct FAIDataProviderBoolValue BoolValue; // 0xc0(0x38)
	struct FAIDataProviderFloatValue FloatValueMin; // 0xf8(0x38)
	struct FAIDataProviderFloatValue FloatValueMax; // 0x130(0x38)
	char pad_168[0x1]; // 0x168(0x01)
	enum class EEnvTestScoreEquation ScoringEquation; // 0x169(0x01)
	enum class EEnvQueryTestClamping ClampMinType; // 0x16a(0x01)
	enum class EEnvQueryTestClamping ClampMaxType; // 0x16b(0x01)
	enum class EEQSNormalizationType NormalizationType; // 0x16c(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
	struct FAIDataProviderFloatValue ScoreClampMin; // 0x170(0x38)
	struct FAIDataProviderFloatValue ScoreClampMax; // 0x1a8(0x38)
	struct FAIDataProviderFloatValue ScoringFactor; // 0x1e0(0x38)
	struct FAIDataProviderFloatValue ReferenceValue; // 0x218(0x38)
	bool bDefineReferenceValue; // 0x250(0x01)
	char pad_251[0xf]; // 0x251(0x0f)
	char bWorkOnFloatValues : 1; // 0x260(0x01)
	char pad_260_1 : 7; // 0x260(0x01)
	char pad_261[0xf]; // 0x261(0x0f)
};

// Class AIModule.EQSRenderingComponent
// Size: 0x740 (Inherited: 0x710)
struct UEQSRenderingComponent : UDebugDrawComponent {
	char pad_710[0x30]; // 0x710(0x30)
};

// Class AIModule.EQSTestingPawn
// Size: 0x820 (Inherited: 0x780)
struct AEQSTestingPawn : ACharacter {
	struct UEnvQuery* QueryTemplate; // 0x780(0x08)
	struct TArray<struct FEnvNamedValue> QueryParams; // 0x788(0x10)
	struct TArray<struct FAIDynamicParam> QueryConfig; // 0x798(0x10)
	float TimeLimitPerStep; // 0x7a8(0x04)
	int32_t StepToDebugDraw; // 0x7ac(0x04)
	enum class EEnvQueryHightlightMode HighlightMode; // 0x7b0(0x01)
	char pad_7b1[0x3]; // 0x7b1(0x03)
	char bDrawLabels : 1; // 0x7b4(0x01)
	char bDrawFailedItems : 1; // 0x7b4(0x01)
	char bReRunQueryOnlyOnFinishedMove : 1; // 0x7b4(0x01)
	char bShouldBeVisibleInGame : 1; // 0x7b4(0x01)
	char bTickDuringGame : 1; // 0x7b4(0x01)
	char pad_7b4_5 : 3; // 0x7b4(0x01)
	char pad_7b5[0x3]; // 0x7b5(0x03)
	enum class EEnvQueryRunMode QueryingMode; // 0x7b8(0x01)
	char pad_7b9[0x7]; // 0x7b9(0x07)
	struct FNavAgentProperties NavAgentProperties; // 0x7c0(0x38)
	char pad_7f8[0x28]; // 0x7f8(0x28)
};

// Class AIModule.EnvQueryGenerator_ActorsOfClass
// Size: 0x140 (Inherited: 0xc0)
struct UEnvQueryGenerator_ActorsOfClass : UEnvQueryGenerator {
	struct AActor* SearchedActorClass; // 0xc0(0x08)
	struct FAIDataProviderBoolValue GenerateOnlyActorsInRadius; // 0xc8(0x38)
	struct FAIDataProviderFloatValue SearchRadius; // 0x100(0x38)
	struct UEnvQueryContext* SearchCenter; // 0x138(0x08)
};

// Class AIModule.EnvQueryGenerator_BlueprintBase
// Size: 0x100 (Inherited: 0xc0)
struct UEnvQueryGenerator_BlueprintBase : UEnvQueryGenerator {
	struct FText GeneratorsActionDescription; // 0xc0(0x18)
	struct UEnvQueryContext* Context; // 0xd8(0x08)
	struct UEnvQueryItemType* GeneratedItemType; // 0xe0(0x08)
	char pad_e8[0x18]; // 0xe8(0x18)

	struct UObject* GetQuerier(); // Function AIModule.EnvQueryGenerator_BlueprintBase.GetQuerier // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f46700
	void DoItemGenerationFromActors(struct TArray<struct AActor*>& ContextActors); // Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGenerationFromActors // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void DoItemGeneration(struct TArray<struct FVector>& ContextLocations); // Function AIModule.EnvQueryGenerator_BlueprintBase.DoItemGeneration // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void AddGeneratedVector(struct FVector GeneratedVector); // Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedVector // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|Const) // @ game+0x3f1c060
	void AddGeneratedActor(struct AActor* GeneratedActor); // Function AIModule.EnvQueryGenerator_BlueprintBase.AddGeneratedActor // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x3f3a860
};

// Class AIModule.EnvQueryGenerator_Composite
// Size: 0xe0 (Inherited: 0xc0)
struct UEnvQueryGenerator_Composite : UEnvQueryGenerator {
	struct TArray<struct UEnvQueryGenerator*> Generators; // 0xc0(0x10)
	char bAllowDifferentItemTypes : 1; // 0xd0(0x01)
	char bHasMatchingItemType : 1; // 0xd0(0x01)
	char pad_d0_2 : 6; // 0xd0(0x01)
	char pad_d1[0x7]; // 0xd1(0x07)
	struct UEnvQueryItemType* ForcedItemType; // 0xd8(0x08)
};

// Class AIModule.EnvQueryGenerator_ProjectedPoints
// Size: 0x100 (Inherited: 0xc0)
struct UEnvQueryGenerator_ProjectedPoints : UEnvQueryGenerator {
	struct FEnvTraceData ProjectionData; // 0xc0(0x40)
};

// Class AIModule.EnvQueryGenerator_Cone
// Size: 0x1f0 (Inherited: 0x100)
struct UEnvQueryGenerator_Cone : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue AlignedPointsDistance; // 0x100(0x38)
	struct FAIDataProviderFloatValue ConeDegrees; // 0x138(0x38)
	struct FAIDataProviderFloatValue AngleStep; // 0x170(0x38)
	struct FAIDataProviderFloatValue Range; // 0x1a8(0x38)
	struct UEnvQueryContext* CenterActor; // 0x1e0(0x08)
	char bIncludeContextLocation : 1; // 0x1e8(0x01)
	char pad_1e8_1 : 7; // 0x1e8(0x01)
	char pad_1e9[0x7]; // 0x1e9(0x07)
};

// Class AIModule.EnvQueryGenerator_CurrentLocation
// Size: 0xd0 (Inherited: 0xc0)
struct UEnvQueryGenerator_CurrentLocation : UEnvQueryGenerator {
	struct UEnvQueryContext* QueryContext; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)
};

// Class AIModule.EnvQueryGenerator_Donut
// Size: 0x250 (Inherited: 0x100)
struct UEnvQueryGenerator_Donut : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue InnerRadius; // 0x100(0x38)
	struct FAIDataProviderFloatValue OuterRadius; // 0x138(0x38)
	struct FAIDataProviderIntValue NumberOfRings; // 0x170(0x38)
	struct FAIDataProviderIntValue PointsPerRing; // 0x1a8(0x38)
	struct FEnvDirection ArcDirection; // 0x1e0(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x200(0x38)
	bool bUseSpiralPattern; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct UEnvQueryContext* Center; // 0x240(0x08)
	char bDefineArc : 1; // 0x248(0x01)
	char pad_248_1 : 7; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)
};

// Class AIModule.EnvQueryGenerator_OnCircle
// Size: 0x2a0 (Inherited: 0x100)
struct UEnvQueryGenerator_OnCircle : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue CircleRadius; // 0x100(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0x138(0x38)
	struct FAIDataProviderIntValue NumberOfPoints; // 0x170(0x38)
	enum class EPointOnCircleSpacingMethod PointOnCircleSpacingMethod; // 0x1a8(0x01)
	char pad_1a9[0x7]; // 0x1a9(0x07)
	struct FEnvDirection ArcDirection; // 0x1b0(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x1d0(0x38)
	float AngleRadians; // 0x208(0x04)
	char pad_20c[0x4]; // 0x20c(0x04)
	struct UEnvQueryContext* CircleCenter; // 0x210(0x08)
	bool bIgnoreAnyContextActorsWhenGeneratingCircle; // 0x218(0x01)
	char pad_219[0x7]; // 0x219(0x07)
	struct FAIDataProviderFloatValue CircleCenterZOffset; // 0x220(0x38)
	struct FEnvTraceData TraceData; // 0x258(0x40)
	char bDefineArc : 1; // 0x298(0x01)
	char pad_298_1 : 7; // 0x298(0x01)
	char pad_299[0x7]; // 0x299(0x07)
};

// Class AIModule.EnvQueryGenerator_SimpleGrid
// Size: 0x180 (Inherited: 0x100)
struct UEnvQueryGenerator_SimpleGrid : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue GridSize; // 0x100(0x38)
	struct FAIDataProviderFloatValue SpaceBetween; // 0x138(0x38)
	struct UEnvQueryContext* GenerateAround; // 0x170(0x08)
	char pad_178[0x8]; // 0x178(0x08)
};

// Class AIModule.EnvQueryGenerator_PathingGrid
// Size: 0x1f0 (Inherited: 0x180)
struct UEnvQueryGenerator_PathingGrid : UEnvQueryGenerator_SimpleGrid {
	struct FAIDataProviderBoolValue PathToItem; // 0x178(0x38)
	struct UNavigationQueryFilter* NavigationFilter; // 0x1b0(0x08)
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x1b8(0x38)
};

// Class AIModule.EnvQueryGenerator_PerceivedActors
// Size: 0x120 (Inherited: 0xc0)
struct UEnvQueryGenerator_PerceivedActors : UEnvQueryGenerator {
	struct AActor* AllowedActorClass; // 0xc0(0x08)
	struct FAIDataProviderFloatValue SearchRadius; // 0xc8(0x38)
	struct UEnvQueryContext* ListenerContext; // 0x100(0x08)
	struct UAISense* SenseToUse; // 0x108(0x08)
	bool bIncludeKnownActors; // 0x110(0x01)
	char pad_111[0xf]; // 0x111(0x0f)
};

// Class AIModule.EnvQueryItemType
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryItemType : UObject {
};

// Class AIModule.EnvQueryItemType_VectorBase
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryItemType_VectorBase : UEnvQueryItemType {
};

// Class AIModule.EnvQueryItemType_ActorBase
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryItemType_ActorBase : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryItemType_Actor
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryItemType_Actor : UEnvQueryItemType_ActorBase {
};

// Class AIModule.EnvQueryItemType_Direction
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryItemType_Direction : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryItemType_Point
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryItemType_Point : UEnvQueryItemType_VectorBase {
};

// Class AIModule.EnvQueryTest_Distance
// Size: 0x280 (Inherited: 0x270)
struct UEnvQueryTest_Distance : UEnvQueryTest {
	enum class EEnvTestDistance TestMode; // 0x268(0x01)
	struct UEnvQueryContext* DistanceTo; // 0x270(0x08)
	char pad_279[0x7]; // 0x279(0x07)
};

// Class AIModule.EnvQueryTest_Dot
// Size: 0x2b0 (Inherited: 0x270)
struct UEnvQueryTest_Dot : UEnvQueryTest {
	struct FEnvDirection LineA; // 0x268(0x20)
	struct FEnvDirection LineB; // 0x288(0x20)
	enum class EEnvTestDot TestMode; // 0x2a8(0x01)
	bool bAbsoluteValue; // 0x2a9(0x01)
};

// Class AIModule.EnvQueryTest_GameplayTags
// Size: 0x2e0 (Inherited: 0x270)
struct UEnvQueryTest_GameplayTags : UEnvQueryTest {
	struct FGameplayTagQuery TagQueryToMatch; // 0x268(0x48)
	bool bRejectIncompatibleItems; // 0x2b0(0x01)
	bool bUpdatedToUseQuery; // 0x2b1(0x01)
	enum class EGameplayContainerMatchType TagsToMatch; // 0x2b2(0x01)
	struct FGameplayTagContainer GameplayTags; // 0x2b8(0x20)
	char pad_2db[0x5]; // 0x2db(0x05)
};

// Class AIModule.EnvQueryTest_Overlap
// Size: 0x2a0 (Inherited: 0x270)
struct UEnvQueryTest_Overlap : UEnvQueryTest {
	struct FEnvOverlapData OverlapData; // 0x268(0x30)
};

// Class AIModule.EnvQueryTest_Pathfinding
// Size: 0x2f0 (Inherited: 0x270)
struct UEnvQueryTest_Pathfinding : UEnvQueryTest {
	enum class EEnvTestPathfinding TestMode; // 0x268(0x01)
	struct UEnvQueryContext* Context; // 0x270(0x08)
	struct FAIDataProviderBoolValue PathFromContext; // 0x278(0x38)
	struct FAIDataProviderBoolValue SkipUnreachable; // 0x2b0(0x38)
	struct UNavigationQueryFilter* FilterClass; // 0x2e8(0x08)
};

// Class AIModule.EnvQueryTest_PathfindingBatch
// Size: 0x330 (Inherited: 0x2f0)
struct UEnvQueryTest_PathfindingBatch : UEnvQueryTest_Pathfinding {
	struct FAIDataProviderFloatValue ScanRangeMultiplier; // 0x2f0(0x38)
	char pad_328[0x8]; // 0x328(0x08)
};

// Class AIModule.EnvQueryTest_Project
// Size: 0x2b0 (Inherited: 0x270)
struct UEnvQueryTest_Project : UEnvQueryTest {
	struct FEnvTraceData ProjectionData; // 0x268(0x40)
};

// Class AIModule.EnvQueryTest_Random
// Size: 0x270 (Inherited: 0x270)
struct UEnvQueryTest_Random : UEnvQueryTest {
};

// Class AIModule.EnvQueryTest_Trace
// Size: 0x360 (Inherited: 0x270)
struct UEnvQueryTest_Trace : UEnvQueryTest {
	struct FEnvTraceData TraceData; // 0x268(0x40)
	struct FAIDataProviderBoolValue TraceFromContext; // 0x2a8(0x38)
	struct FAIDataProviderFloatValue ItemHeightOffset; // 0x2e0(0x38)
	struct FAIDataProviderFloatValue ContextHeightOffset; // 0x318(0x38)
	struct UEnvQueryContext* Context; // 0x350(0x08)
};

// Class AIModule.EnvQueryTest_Volume
// Size: 0x280 (Inherited: 0x270)
struct UEnvQueryTest_Volume : UEnvQueryTest {
	struct UEnvQueryContext* VolumeContext; // 0x268(0x08)
	struct AVolume* VolumeClass; // 0x270(0x08)
	char bDoComplexVolumeTest : 1; // 0x278(0x01)
	char bSkipTestIfNoVolumes : 1; // 0x278(0x01)
};

// Class AIModule.GridPathAIController
// Size: 0x4c0 (Inherited: 0x4c0)
struct AGridPathAIController : AAIController {
};

// Class AIModule.AIHotSpotManager
// Size: 0xa0 (Inherited: 0xa0)
struct UAIHotSpotManager : UObject {
};

// Class AIModule.PathFollowingComponent
// Size: 0x380 (Inherited: 0x160)
struct UPathFollowingComponent : UActorComponent {
	char pad_160[0x30]; // 0x160(0x30)
	struct UNavMovementComponent* MovementComp; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
	struct ANavigationData* MyNavData; // 0x1a0(0x08)
	char pad_1a8[0x1d8]; // 0x1a8(0x1d8)

	void OnNavDataRegistered(struct ANavigationData* NavData); // Function AIModule.PathFollowingComponent.OnNavDataRegistered // (Final|RequiredAPI|Native|Protected) // @ game+0x3f39310
	void OnActorBump(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit); // Function AIModule.PathFollowingComponent.OnActorBump // (RequiredAPI|Native|Public|HasOutParms|HasDefaults) // @ game+0x3f344a0
	struct FVector GetPathDestination(); // Function AIModule.PathFollowingComponent.GetPathDestination // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f1cd30
	enum class EPathFollowingAction GetPathActionType(); // Function AIModule.PathFollowingComponent.GetPathActionType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f32ef0
};

// Class AIModule.CrowdFollowingComponent
// Size: 0x3d0 (Inherited: 0x380)
struct UCrowdFollowingComponent : UPathFollowingComponent {
	char pad_380[0x18]; // 0x380(0x18)
	struct FVector CrowdAgentMoveDirection; // 0x398(0x18)
	char pad_3b0[0x20]; // 0x3b0(0x20)

	void SuspendCrowdSteering(bool bSuspend); // Function AIModule.CrowdFollowingComponent.SuspendCrowdSteering // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f3af70
};

// Class AIModule.CrowdManager
// Size: 0x160 (Inherited: 0xa0)
struct UCrowdManager : UCrowdManagerBase {
	struct ANavigationData* MyNavData; // 0x98(0x08)
	struct TArray<struct FCrowdAvoidanceConfig> AvoidanceConfig; // 0xa0(0x10)
	struct TArray<struct FCrowdAvoidanceSamplingPattern> SamplingPatterns; // 0xb0(0x10)
	int32_t MaxAgents; // 0xc0(0x04)
	float MaxAgentRadius; // 0xc4(0x04)
	int32_t MaxAvoidedAgents; // 0xc8(0x04)
	int32_t MaxAvoidedWalls; // 0xcc(0x04)
	float NavmeshCheckInterval; // 0xd0(0x04)
	float PathOptimizationInterval; // 0xd4(0x04)
	float SeparationDirClamp; // 0xd8(0x04)
	float PathOffsetRadiusMultiplier; // 0xdc(0x04)
	char pad_e8_0 : 4; // 0xe8(0x01)
	char bResolveCollisions : 1; // 0xe0(0x01)
	char pad_e8_5 : 3; // 0xe8(0x01)
	char pad_e9[0x77]; // 0xe9(0x77)
};

// Class AIModule.GridPathFollowingComponent
// Size: 0x3b0 (Inherited: 0x380)
struct UGridPathFollowingComponent : UPathFollowingComponent {
	struct UNavLocalGridManager* GridManager; // 0x380(0x08)
	char pad_388[0x28]; // 0x388(0x28)
};

// Class AIModule.NavFilter_AIControllerDefault
// Size: 0xc0 (Inherited: 0xc0)
struct UNavFilter_AIControllerDefault : UNavigationQueryFilter {
};

// Class AIModule.NavLinkProxy
// Size: 0x3f0 (Inherited: 0x3a0)
struct ANavLinkProxy : AActor {
	char pad_3a0[0x8]; // 0x3a0(0x08)
	struct TArray<struct FNavigationLink> PointLinks; // 0x3a8(0x10)
	struct TArray<struct FNavigationSegmentLink> SegmentLinks; // 0x3b8(0x10)
	struct UNavLinkCustomComponent* SmartLinkComp; // 0x3c8(0x08)
	bool bSmartLinkIsRelevant; // 0x3d0(0x01)
	char pad_3d1[0x7]; // 0x3d1(0x07)
	struct FMulticastInlineDelegate OnSmartLinkReached; // 0x3d8(0x10)
	char pad_3e8[0x8]; // 0x3e8(0x08)

	void SetSmartLinkEnabled(bool bEnabled); // Function AIModule.NavLinkProxy.SetSmartLinkEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f47c10
	void ResumePathFollowing(struct AActor* Agent); // Function AIModule.NavLinkProxy.ResumePathFollowing // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f40570
	void ReceiveSmartLinkReached(struct AActor* Agent, struct FVector& Destination); // Function AIModule.NavLinkProxy.ReceiveSmartLinkReached // (RequiredAPI|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x4abfe0
	bool IsSmartLinkEnabled(); // Function AIModule.NavLinkProxy.IsSmartLinkEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f1d700
	bool HasMovingAgents(); // Function AIModule.NavLinkProxy.HasMovingAgents // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f1a1b0
};

// Class AIModule.NavLocalGridManager
// Size: 0xd0 (Inherited: 0xa0)
struct UNavLocalGridManager : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)

	bool SetLocalNavigationGridDensity(struct UObject* WorldContextObject, float CellSize); // Function AIModule.NavLocalGridManager.SetLocalNavigationGridDensity // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f46180
	void RemoveLocalNavigationGrid(struct UObject* WorldContextObject, int32_t GridId, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.RemoveLocalNavigationGrid // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f435c0
	bool FindLocalNavigationGridPath(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, struct TArray<struct FVector>& PathPoints); // Function AIModule.NavLocalGridManager.FindLocalNavigationGridPath // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3f26b20
	int32_t AddLocalNavigationGridForPoints(struct UObject* WorldContextObject, struct TArray<struct FVector>& Locations, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoints // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3f2a490
	int32_t AddLocalNavigationGridForPoint(struct UObject* WorldContextObject, struct FVector& Location, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForPoint // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3f1bdb0
	int32_t AddLocalNavigationGridForCapsule(struct UObject* WorldContextObject, struct FVector& Location, float CapsuleRadius, float CapsuleHalfHeight, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForCapsule // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3f215e0
	int32_t AddLocalNavigationGridForBox(struct UObject* WorldContextObject, struct FVector& Location, struct FVector Extent, struct FRotator Rotation, int32_t Radius2D, float Height, bool bRebuildGrids); // Function AIModule.NavLocalGridManager.AddLocalNavigationGridForBox // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3f1c110
};

// Class AIModule.PathFollowingManager
// Size: 0xa0 (Inherited: 0xa0)
struct UPathFollowingManager : UObject {
};

// Class AIModule.AIPerceptionComponent
// Size: 0x250 (Inherited: 0x160)
struct UAIPerceptionComponent : UActorComponent {
	struct TArray<struct UAISenseConfig*> SensesConfig; // 0x158(0x10)
	struct UAISense* DominantSense; // 0x168(0x08)
	char pad_178[0x8]; // 0x178(0x08)
	struct AAIController* AIOwner; // 0x180(0x08)
	char pad_188[0x80]; // 0x188(0x80)
	struct FMulticastInlineDelegate OnPerceptionUpdated; // 0x208(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionForgotten; // 0x218(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionUpdated; // 0x228(0x10)
	struct FMulticastInlineDelegate OnTargetPerceptionInfoUpdated; // 0x238(0x10)
	char pad_248[0x8]; // 0x248(0x08)

	void SetSenseEnabled(struct UAISense* SenseClass, bool bEnable); // Function AIModule.AIPerceptionComponent.SetSenseEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f56e30
	void RequestStimuliListenerUpdate(); // Function AIModule.AIPerceptionComponent.RequestStimuliListenerUpdate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f48ae0
	void OnOwnerEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function AIModule.AIPerceptionComponent.OnOwnerEndPlay // (Final|RequiredAPI|Native|Public) // @ game+0x3f4b110
	void GetPerceivedHostileActorsBySense(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetPerceivedHostileActorsBySense // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f65670
	void GetPerceivedHostileActors(struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetPerceivedHostileActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f56d70
	void GetKnownPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetKnownPerceivedActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f52440
	void GetCurrentlyPerceivedActors(struct UAISense* SenseToUse, struct TArray<struct AActor*>& OutActors); // Function AIModule.AIPerceptionComponent.GetCurrentlyPerceivedActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f61200
	bool GetActorsPerception(struct AActor* Actor, struct FActorPerceptionBlueprintInfo& Info); // Function AIModule.AIPerceptionComponent.GetActorsPerception // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3f57d90
	void ForgetAll(); // Function AIModule.AIPerceptionComponent.ForgetAll // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f4a850
};

// Class AIModule.AIPerceptionListenerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UAIPerceptionListenerInterface : UInterface {
};

// Class AIModule.AIPerceptionStimuliSourceComponent
// Size: 0x170 (Inherited: 0x160)
struct UAIPerceptionStimuliSourceComponent : UActorComponent {
	char bAutoRegisterAsSource : 1; // 0x158(0x01)
	struct TArray<struct UAISense*> RegisterAsSourceForSenses; // 0x160(0x10)

	void UnregisterFromSense(struct UAISense* SenseClass); // Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromSense // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f568b0
	void UnregisterFromPerceptionSystem(); // Function AIModule.AIPerceptionStimuliSourceComponent.UnregisterFromPerceptionSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f4f7d0
	void RegisterWithPerceptionSystem(); // Function AIModule.AIPerceptionStimuliSourceComponent.RegisterWithPerceptionSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f4f350
	void RegisterForSense(struct UAISense* SenseClass); // Function AIModule.AIPerceptionStimuliSourceComponent.RegisterForSense // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f6e660
};

// Class AIModule.AIPerceptionSystem
// Size: 0x1b0 (Inherited: 0xb0)
struct UAIPerceptionSystem : UAISubsystem {
	char pad_b0[0x48]; // 0xb0(0x48)
	struct TArray<struct UAISense*> Senses; // 0xf8(0x10)
	float PerceptionAgingRate; // 0x108(0x04)
	char pad_10c[0xa4]; // 0x10c(0xa4)

	void ReportPerceptionEvent(struct UObject* WorldContextObject, struct UAISenseEvent* PerceptionEvent); // Function AIModule.AIPerceptionSystem.ReportPerceptionEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f5bc90
	void ReportEvent(struct UAISenseEvent* PerceptionEvent); // Function AIModule.AIPerceptionSystem.ReportEvent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3f599c0
	bool RegisterPerceptionStimuliSource(struct UObject* WorldContextObject, struct UAISense* Sense, struct AActor* Target); // Function AIModule.AIPerceptionSystem.RegisterPerceptionStimuliSource // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f4f430
	void OnPerceptionStimuliSourceEndPlay(struct AActor* Actor, enum class EEndPlayReason EndPlayReason); // Function AIModule.AIPerceptionSystem.OnPerceptionStimuliSourceEndPlay // (Final|RequiredAPI|Native|Protected) // @ game+0x3f535b0
	struct UAISense* GetSenseClassForStimulus(struct UObject* WorldContextObject, struct FAIStimulus& Stimulus); // Function AIModule.AIPerceptionSystem.GetSenseClassForStimulus // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x3f637c0
};

// Class AIModule.AISense
// Size: 0xf0 (Inherited: 0xa0)
struct UAISense : UObject {
	enum class EAISenseNotifyType NotifyType; // 0x98(0x01)
	char bWantsNewPawnNotification : 1; // 0x9c(0x01)
	char bAutoRegisterAllPawnsAsSources : 1; // 0x9c(0x01)
	struct UAIPerceptionSystem* PerceptionSystemInstance; // 0xa0(0x08)
	char pad_a9_2 : 6; // 0xa9(0x01)
	char pad_aa[0x46]; // 0xaa(0x46)
};

// Class AIModule.AISenseConfig_Damage
// Size: 0xc0 (Inherited: 0xc0)
struct UAISenseConfig_Damage : UAISenseConfig {
	struct UAISense_Damage* Implementation; // 0xb8(0x08)
};

// Class AIModule.AISense_Blueprint
// Size: 0x110 (Inherited: 0xf0)
struct UAISense_Blueprint : UAISense {
	struct UUserDefinedStruct* ListenerDataType; // 0xe8(0x08)
	struct TArray<struct UAIPerceptionComponent*> ListenerContainer; // 0xf0(0x10)
	struct TArray<struct UAISenseEvent*> UnprocessedEvents; // 0x100(0x10)

	float OnUpdate(struct TArray<struct UAISenseEvent*>& EventsToProcess); // Function AIModule.AISense_Blueprint.OnUpdate // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnListenerUpdated(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent); // Function AIModule.AISense_Blueprint.OnListenerUpdated // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnListenerUnregistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent); // Function AIModule.AISense_Blueprint.OnListenerUnregistered // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnListenerRegistered(struct AActor* ActorListener, struct UAIPerceptionComponent* PerceptionComponent); // Function AIModule.AISense_Blueprint.OnListenerRegistered // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void K2_OnNewPawn(struct APawn* NewPawn); // Function AIModule.AISense_Blueprint.K2_OnNewPawn // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void GetAllListenerComponents(struct TArray<struct UAIPerceptionComponent*>& ListenerComponents); // Function AIModule.AISense_Blueprint.GetAllListenerComponents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f62da0
	void GetAllListenerActors(struct TArray<struct AActor*>& ListenerActors); // Function AIModule.AISense_Blueprint.GetAllListenerActors // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f4e770
};

// Class AIModule.AISense_Damage
// Size: 0x100 (Inherited: 0xf0)
struct UAISense_Damage : UAISense {
	struct TArray<struct FAIDamageEvent> RegisteredEvents; // 0xe8(0x10)

	void ReportDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation, struct FName Tag); // Function AIModule.AISense_Damage.ReportDamageEvent // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3f65f30
};

// Class AIModule.AISense_Hearing
// Size: 0x150 (Inherited: 0xf0)
struct UAISense_Hearing : UAISense {
	struct TArray<struct FAINoiseEvent> NoiseEvents; // 0xe8(0x10)
	float SpeedOfSoundSq; // 0xf8(0x04)
	char pad_104[0x4c]; // 0x104(0x4c)

	void ReportNoiseEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Loudness, struct AActor* Instigator, float MaxRange, struct FName Tag); // Function AIModule.AISense_Hearing.ReportNoiseEvent // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3f58410
};

// Class AIModule.AISense_Prediction
// Size: 0x100 (Inherited: 0xf0)
struct UAISense_Prediction : UAISense {
	struct TArray<struct FAIPredictionEvent> RegisteredEvents; // 0xe8(0x10)

	void RequestPawnPredictionEvent(struct APawn* Requestor, struct AActor* PredictedActor, float PredictionTime); // Function AIModule.AISense_Prediction.RequestPawnPredictionEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f48da0
	void RequestControllerPredictionEvent(struct AAIController* Requestor, struct AActor* PredictedActor, float PredictionTime); // Function AIModule.AISense_Prediction.RequestControllerPredictionEvent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f65a20
};

// Class AIModule.AISense_Sight
// Size: 0x220 (Inherited: 0xf0)
struct UAISense_Sight : UAISense {
	char pad_f0[0xd0]; // 0xf0(0xd0)
	int32_t MaxTracesPerTick; // 0x1c0(0x04)
	int32_t MaxAsyncTracesPerTick; // 0x1c4(0x04)
	int32_t MinQueriesPerTimeSliceCheck; // 0x1c8(0x04)
	char pad_1cc[0x4]; // 0x1cc(0x04)
	double MaxTimeSlicePerTick; // 0x1d0(0x08)
	float HighImportanceQueryDistanceThreshold; // 0x1d8(0x04)
	char pad_1dc[0x4]; // 0x1dc(0x04)
	float MaxQueryImportance; // 0x1e0(0x04)
	float SightLimitQueryImportance; // 0x1e4(0x04)
	float PendingQueriesBudgetReductionRatio; // 0x1e8(0x04)
	bool bUseAsynchronousTraceForDefaultSightQueries; // 0x1ec(0x01)
	char pad_1ed[0x33]; // 0x1ed(0x33)
};

// Class AIModule.AISense_Team
// Size: 0x100 (Inherited: 0xf0)
struct UAISense_Team : UAISense {
	struct TArray<struct FAITeamStimulusEvent> RegisteredEvents; // 0xe8(0x10)
};

// Class AIModule.AISense_Touch
// Size: 0x100 (Inherited: 0xf0)
struct UAISense_Touch : UAISense {
	struct TArray<struct FAITouchEvent> RegisteredEvents; // 0xe8(0x10)

	void ReportTouchEvent(struct UObject* WorldContextObject, struct AActor* TouchReceiver, struct AActor* OtherActor, struct FVector Location); // Function AIModule.AISense_Touch.ReportTouchEvent // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3f6e810
};

// Class AIModule.AISightTargetInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UAISightTargetInterface : UInterface {
};

// Class AIModule.PawnSensingComponent
// Size: 0x1a0 (Inherited: 0x160)
struct UPawnSensingComponent : UActorComponent {
	float HearingThreshold; // 0x158(0x04)
	float LOSHearingThreshold; // 0x15c(0x04)
	float SightRadius; // 0x160(0x04)
	float SensingInterval; // 0x164(0x04)
	float HearingMaxSoundAge; // 0x168(0x04)
	char bEnableSensingUpdates : 1; // 0x16c(0x01)
	char bOnlySensePlayers : 1; // 0x16c(0x01)
	char bSeePawns : 1; // 0x16c(0x01)
	char bHearNoises : 1; // 0x16c(0x01)
	char pad_174_4 : 4; // 0x174(0x01)
	char pad_175[0x3]; // 0x175(0x03)
	struct FMulticastInlineDelegate OnSeePawn; // 0x178(0x10)
	struct FMulticastInlineDelegate OnHearNoise; // 0x188(0x10)
	float PeripheralVisionAngle; // 0x198(0x04)
	float PeripheralVisionCosine; // 0x19c(0x04)

	void SetSensingUpdatesEnabled(bool bEnabled); // Function AIModule.PawnSensingComponent.SetSensingUpdatesEnabled // (RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3f56800
	void SetSensingInterval(float NewSensingInterval); // Function AIModule.PawnSensingComponent.SetSensingInterval // (RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3f59840
	void SetPeripheralVisionAngle(float NewPeripheralVisionAngle); // Function AIModule.PawnSensingComponent.SetPeripheralVisionAngle // (RequiredAPI|BlueprintAuthorityOnly|Native|Public|BlueprintCallable) // @ game+0x3f69ce0
	void SeePawnDelegate__DelegateSignature(struct APawn* Pawn); // DelegateFunction AIModule.PawnSensingComponent.SeePawnDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void HearNoiseDelegate__DelegateSignature(struct APawn* Instigator, struct FVector& Location, float Volume); // DelegateFunction AIModule.PawnSensingComponent.HearNoiseDelegate__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms|HasDefaults) // @ game+0x4abfe0
	float GetPeripheralVisionCosine(); // Function AIModule.PawnSensingComponent.GetPeripheralVisionCosine // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f4fca0
	float GetPeripheralVisionAngle(); // Function AIModule.PawnSensingComponent.GetPeripheralVisionAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f6c8d0
};

// Class AIModule.AITask
// Size: 0xe0 (Inherited: 0xe0)
struct UAITask : UGameplayTask {
	struct AAIController* OwnerController; // 0xd8(0x08)
};

// Class AIModule.AITask_LockLogic
// Size: 0xe0 (Inherited: 0xe0)
struct UAITask_LockLogic : UAITask {
};

// Class AIModule.AITask_MoveTo
// Size: 0x190 (Inherited: 0xe0)
struct UAITask_MoveTo : UAITask {
	struct FMulticastInlineDelegate OnRequestFailed; // 0xe0(0x10)
	struct FMulticastInlineDelegate OnMoveFinished; // 0xf0(0x10)
	struct FAIMoveRequest MoveRequest; // 0x100(0x50)
	char pad_150[0x40]; // 0x150(0x40)

	struct UAITask_MoveTo* AIMoveTo(struct AAIController* Controller, struct FVector GoalLocation, struct AActor* GoalActor, float AcceptanceRadius, enum class EAIOptionFlag StopOnOverlap, enum class EAIOptionFlag AcceptPartialPath, bool bUsePathfinding, bool bLockAILogic, bool bUseContinuousGoalTracking, enum class EAIOptionFlag ProjectGoalOnNavigation); // Function AIModule.AITask_MoveTo.AIMoveTo // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x3f6e220
};

// Class AIModule.AITask_RunEQS
// Size: 0x160 (Inherited: 0xe0)
struct UAITask_RunEQS : UAITask {
	char pad_e0[0x80]; // 0xe0(0x80)

	struct UAITask_RunEQS* RunEQS(struct AAIController* Controller, struct UEnvQuery* QueryTemplate); // Function AIModule.AITask_RunEQS.RunEQS // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x3f62970
};

// Class AIModule.VisualLoggerExtension
// Size: 0xa0 (Inherited: 0xa0)
struct UVisualLoggerExtension : UObject {
};

