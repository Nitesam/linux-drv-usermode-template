// Enum Quilkin.EQuilkinReachability
enum class EQuilkinReachability : uint8_t {
	NoNetworkDevice = 0,
	ConnectedToNetworkNoInternet = 1,
	ConnectedToInternetCannotReachAddress = 2,
	ConnectedToInternetCannotReachProxy = 3,
	CanReachAddress = 4,
	EQuilkinReachability_MAX = 5
};

// ScriptStruct Quilkin.QuilkinEndpoint
// Size: 0x28 (Inherited: 0x00)
struct FQuilkinEndpoint {
	struct FString Host; // 0x00(0x10)
	uint16_t QcmpPort; // 0x10(0x02)
	uint16_t TrafficPort; // 0x12(0x02)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString Region; // 0x18(0x10)
};

