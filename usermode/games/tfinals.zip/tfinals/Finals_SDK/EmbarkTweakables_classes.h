// Class EmbarkTweakables.EmbarkTweakablesSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UEmbarkTweakablesSettings : UDeveloperSettings {
	struct TArray<struct TSoftClassPtr<UObject>> TweakableClasses; // 0xa8(0x10)
};

// Class EmbarkTweakables.TweakableObject
// Size: 0xa0 (Inherited: 0xa0)
struct UTweakableObject : UObject {
};

// Class EmbarkTweakables.EmbarkTweakablesSubsystem
// Size: 0x1a0 (Inherited: 0xa0)
struct UEmbarkTweakablesSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnOnlineTweakableApplied; // 0xb0(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)
	struct FTweakablesContainer TweakablesContainer; // 0xd0(0x50)
	char pad_120[0x60]; // 0x120(0x60)
	struct TArray<struct UObject*> PreloadedAssets; // 0x180(0x10)
	char pad_190[0x10]; // 0x190(0x10)

	void RegisterOnlineTweakables_Server(struct FOnlineTweakablesContainer& InOnlineTweakablesContainer); // Function EmbarkTweakables.EmbarkTweakablesSubsystem.RegisterOnlineTweakables_Server // (Final|Native|Public|HasOutParms) // @ game+0x5570920
	void RegisterOnlineTweakables_Client(struct FOnlineTweakablesContainer& InOnlineTweakablesContainer); // Function EmbarkTweakables.EmbarkTweakablesSubsystem.RegisterOnlineTweakables_Client // (Final|Native|Public|HasOutParms) // @ game+0x5571ff0
	bool IsTweakableDefaulted(struct FOnlineTweakable& Tweakable); // Function EmbarkTweakables.EmbarkTweakablesSubsystem.IsTweakableDefaulted // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x55738b0
	bool IsInitialized(); // Function EmbarkTweakables.EmbarkTweakablesSubsystem.IsInitialized // (Final|Native|Public|Const) // @ game+0x55728f0
	bool GetTweakableDefault(struct FOnlineTweakable& Tweakable, struct FString& OutDefaultValue); // Function EmbarkTweakables.EmbarkTweakablesSubsystem.GetTweakableDefault // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5571d90
};

