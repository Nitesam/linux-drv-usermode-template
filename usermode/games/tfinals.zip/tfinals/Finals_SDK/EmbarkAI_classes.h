// Class EmbarkAI.BTComposite_Utility
// Size: 0x100 (Inherited: 0xf0)
struct UBTComposite_Utility : UBTCompositeNode {
	enum class EUtilitySelectionMethod SelectionMethod; // 0xf0(0x01)
	char pad_f1[0xf]; // 0xf1(0x0f)
};

// Class EmbarkAI.BTDecorator_UtilityFunction
// Size: 0xf0 (Inherited: 0xe0)
struct UBTDecorator_UtilityFunction : UBTDecorator {
	bool bContinuousEvaluation; // 0xd8(0x01)
	float TickInterval; // 0xdc(0x04)
	char pad_e5[0xb]; // 0xe5(0x0b)
};

// Class EmbarkAI.BTDecorator_UtilityBlackboard
// Size: 0x110 (Inherited: 0xf0)
struct UBTDecorator_UtilityBlackboard : UBTDecorator_UtilityFunction {
	struct FBlackboardKeySelector UtilityValueKey; // 0xe8(0x28)
};

// Class EmbarkAI.BTDecorator_UtilityBlueprintBase
// Size: 0x100 (Inherited: 0xf0)
struct UBTDecorator_UtilityBlueprintBase : UBTDecorator_UtilityFunction {
	struct AAIController* AIOwner; // 0xe8(0x08)
	struct AActor* ActorOwner; // 0xf0(0x08)
	bool bIsActive; // 0xf8(0x01)

	void OnTick(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function EmbarkAI.BTDecorator_UtilityBlueprintBase.OnTick // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnActivation(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function EmbarkAI.BTDecorator_UtilityBlueprintBase.OnActivation // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	float CalculateUtility(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function EmbarkAI.BTDecorator_UtilityBlueprintBase.CalculateUtility // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkAI.BTUtilityCalculation
// Size: 0xa0 (Inherited: 0xa0)
struct UBTUtilityCalculation : UObject {
	bool bIsBTExclusive; // 0x98(0x01)

	float Calculate_WithLocation(struct APawn* OwnerPawn, struct UBTDecorator_UtilityCalculationBase* OwningNode, struct TArray<struct FAITargetHandle>& Targets, bool& bOutNeedsEQS, struct FVector DesiredDestination, bool bDrawDebug); // Function EmbarkAI.BTUtilityCalculation.Calculate_WithLocation // (Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x5f31cc0
	float Calculate(struct APawn* OwnerPawn, struct UBTDecorator_UtilityCalculationBase* OwningNode, struct TArray<struct FAITargetHandle>& Targets, bool bDrawDebug); // Function EmbarkAI.BTUtilityCalculation.Calculate // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkAI.BTUtilityCalculationData
// Size: 0x140 (Inherited: 0xa0)
struct UBTUtilityCalculationData : UEmbarkDataAsset {
	struct TMap<struct FName, struct FBTUtilityComposition> Utilities; // 0xa0(0x50)
	struct TMap<struct FName, struct FGameplayTag> UtilityToTagLookup; // 0xf0(0x50)
};

// Class EmbarkAI.BTDecorator_UtilityCalculationBase
// Size: 0x160 (Inherited: 0x100)
struct UBTDecorator_UtilityCalculationBase : UBTDecorator_UtilityBlueprintBase {
	float LastActivationTime; // 0x100(0x04)
	float LastDeactivationTime; // 0x104(0x04)
	struct UBTUtilityCalculationData* UtilityData; // 0x108(0x08)
	struct FName UtilityField; // 0x110(0x08)
	struct FBlackboardKeySelector LocationKey; // 0x118(0x28)
	bool bContinuousPositionalUpdate; // 0x140(0x01)
	char pad_141[0x7]; // 0x141(0x07)
	struct UAIKnowledgeBaseInterface* KnowledgeBase; // 0x148(0x08)
	struct APawn* ControlledPawn; // 0x150(0x08)
	float QueryExpirationTime; // 0x158(0x04)
	char pad_15c[0x4]; // 0x15c(0x04)

	struct TArray<struct FString> GetNameOptions(); // Function EmbarkAI.BTDecorator_UtilityCalculationBase.GetNameOptions // (Final|Native|Private|Const) // @ game+0x5f2fce0
};

// Class EmbarkAI.BTDecorator_UtilityConstant
// Size: 0xf0 (Inherited: 0xf0)
struct UBTDecorator_UtilityConstant : UBTDecorator_UtilityFunction {
	float UtilityValue; // 0xe8(0x04)
};

// Class EmbarkAI.BTTask_EmbarkAIRunBehaviorDynamic
// Size: 0x100 (Inherited: 0x100)
struct UBTTask_EmbarkAIRunBehaviorDynamic : UBTTask_RunBehaviorDynamic {
};

// Class EmbarkAI.EmbarkBTUtilityLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkBTUtilityLibrary : UBlueprintFunctionLibrary {
};

// Class EmbarkAI.BTUtilitySelectionMethod
// Size: 0xa0 (Inherited: 0xa0)
struct UBTUtilitySelectionMethod : UObject {
};

// Class EmbarkAI.EmbarkAIController
// Size: 0x530 (Inherited: 0x4c0)
struct AEmbarkAIController : AAIController {
	char pad_4c0[0x8]; // 0x4c0(0x08)
	struct FMulticastInlineDelegate OnPawnChanged; // 0x4c8(0x10)
	char bResetPitchWhenNoFocusPawn : 1; // 0x4d8(0x01)
	char pad_4d8_1 : 7; // 0x4d8(0x01)
	char pad_4d9[0x3f]; // 0x4d9(0x3f)
	struct APawn* LastPossessedPawn; // 0x518(0x08)
	struct TArray<struct UEmbarkPawnComponent*> CachedPawnComponents; // 0x520(0x10)

	void RemovePerceptionComponentByIndex(int32_t PerceptionComponentIdx); // Function EmbarkAI.EmbarkAIController.RemovePerceptionComponentByIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3baf0
	void RemovePerceptionComponent(struct USceneComponent* OwningComponent); // Function EmbarkAI.EmbarkAIController.RemovePerceptionComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5f40090
	void RegisterAIData(struct UEmbarkAITemplateDataAsset* DataAsset); // Function EmbarkAI.EmbarkAIController.RegisterAIData // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3e4f0
	void ReceiveRegisterAIData(struct UEmbarkAITemplateDataAsset* DataAsset); // Function EmbarkAI.EmbarkAIController.ReceiveRegisterAIData // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostInitializeComponents(); // Function EmbarkAI.EmbarkAIController.ReceivePostInitializeComponents // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnSenseConfigured(struct UAISenseConfig* SenseConfig); // Function EmbarkAI.EmbarkAIController.ReceiveOnSenseConfigured // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnPawnChangedSignature__DelegateSignature(struct AController* Controller); // DelegateFunction EmbarkAI.EmbarkAIController.OnPawnChangedSignature__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnActorPerceptionUpdated(struct AActor* Actor, struct FAIStimulus Stimulus); // Function EmbarkAI.EmbarkAIController.OnActorPerceptionUpdated // (Final|Native|Private) // @ game+0x5f3c400
	void MakeAIForgetActor(struct AActor* ActorToForget); // Function EmbarkAI.EmbarkAIController.MakeAIForgetActor // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5f3e910
	bool HasSenseConfig(struct UAIPerceptionComponent* InPerceptionComponent, struct UAISenseConfig* SenseConfig); // Function EmbarkAI.EmbarkAIController.HasSenseConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3ff80
	struct UEmbarkAISenseConfig_Sight* GetPerceptionSightConfig(struct UAIPerceptionComponent* InPerceptionComponent); // Function EmbarkAI.EmbarkAIController.GetPerceptionSightConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3eba0
	struct UEmbarkAISenseConfig_Network* GetPerceptionNetworkConfig(struct UAIPerceptionComponent* InPerceptionComponent); // Function EmbarkAI.EmbarkAIController.GetPerceptionNetworkConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3ae50
	struct UEmbarkAISenseConfig_Hearing* GetPerceptionHearingConfig(struct UAIPerceptionComponent* InPerceptionComponent); // Function EmbarkAI.EmbarkAIController.GetPerceptionHearingConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3df90
	struct UEmbarkAISenseConfig_Damage* GetPerceptionDamageConfig(struct UAIPerceptionComponent* InPerceptionComponent); // Function EmbarkAI.EmbarkAIController.GetPerceptionDamageConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3faa0
	void GetPerceptionComponentsByOwner(struct USceneComponent* OwningComponent, struct TArray<struct UAIPerceptionComponent*>& OutPerceptionComponents); // Function EmbarkAI.EmbarkAIController.GetPerceptionComponentsByOwner // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f420d0
	void GetPerceptionComponents(struct TArray<struct UAIPerceptionComponent*>& OutPerceptionComponents); // Function EmbarkAI.EmbarkAIController.GetPerceptionComponents // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f3b1c0
	void ForgetEverything(); // Function EmbarkAI.EmbarkAIController.ForgetEverything // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3ac80
	void ForgetActor(struct AActor* ActorToForget); // Function EmbarkAI.EmbarkAIController.ForgetActor // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3aa60
	struct FEmbarkAIVisLogInfo DescribeSelfToVisLog(); // Function EmbarkAI.EmbarkAIController.DescribeSelfToVisLog // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	void ConfigureSense(struct UAIPerceptionComponent* InPerceptionComponent, struct UAISenseConfig* SenseConfig); // Function EmbarkAI.EmbarkAIController.ConfigureSense // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3f0a0
	void BP_SetTeam(enum class EEmbarkTeamId NewTeam); // Function EmbarkAI.EmbarkAIController.BP_SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3e670
	enum class EEmbarkTeamId BP_GetTeam(); // Function EmbarkAI.EmbarkAIController.BP_GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3e130
	int32_t AddPerceptionComponent(struct USceneComponent* OwningComponent, struct TArray<struct UAISenseConfig*>& SenseConfigs); // Function EmbarkAI.EmbarkAIController.AddPerceptionComponent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f3ec50
};

// Class EmbarkAI.ConstructableAIControllerBase
// Size: 0x570 (Inherited: 0x530)
struct AConstructableAIControllerBase : AEmbarkAIController {
	struct UAIKnowledgeBaseInterface* KnowledgeBase; // 0x530(0x08)
	struct UAIFocusingInterface* BackupFocusing; // 0x538(0x08)
	char pad_540[0x30]; // 0x540(0x30)

	void SetDynamicSubtree(struct FGameplayTag& Tag, struct UBehaviorTree* BehaviorTree); // Function EmbarkAI.ConstructableAIControllerBase.SetDynamicSubtree // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f238e0
	void RequestFocus(struct FFocusRequest Request); // Function EmbarkAI.ConstructableAIControllerBase.RequestFocus // (Final|Native|Public) // @ game+0x5f29e00
	void RemovePartPerceptionComponent(int32_t OwningPartID); // Function EmbarkAI.ConstructableAIControllerBase.RemovePartPerceptionComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc77c0
	bool IsRequestValid(struct FFocusRequest& Request); // Function EmbarkAI.ConstructableAIControllerBase.IsRequestValid // (Final|Native|Public|HasOutParms) // @ game+0x5f25700
	bool HasValidFocus(); // Function EmbarkAI.ConstructableAIControllerBase.HasValidFocus // (Final|Native|Public|Const) // @ game+0x5198790
	bool HasDynamicTreeTag(struct FGameplayTag& Tag); // Function EmbarkAI.ConstructableAIControllerBase.HasDynamicTreeTag // (Final|Native|Public|HasOutParms) // @ game+0x5f393a0
	struct FFocusTarget GetCurrentFocus(); // Function EmbarkAI.ConstructableAIControllerBase.GetCurrentFocus // (Final|Native|Public|Const) // @ game+0x5f2faf0
	void ClearFocus(enum class EAIFocusMode FocusMode); // Function EmbarkAI.ConstructableAIControllerBase.ClearFocus // (Final|Native|Public) // @ game+0x5a1d9d0
	void ClearDynamicSubTree(struct FGameplayTag& Tag); // Function EmbarkAI.ConstructableAIControllerBase.ClearDynamicSubTree // (Final|Native|Public|HasOutParms) // @ game+0x5f2de90
	struct FRotator CalcFocusRotator(); // Function EmbarkAI.ConstructableAIControllerBase.CalcFocusRotator // (Final|Native|Public|HasDefaults) // @ game+0x5f35800
	struct FVector CalcFocusLocation(); // Function EmbarkAI.ConstructableAIControllerBase.CalcFocusLocation // (Final|Native|Public|HasDefaults) // @ game+0x5f35800
	void AddPartPerceptionComponent(struct USceneComponent* OwningComponent, struct TArray<struct UAISenseConfig*>& SenseConfigs, struct FConstructablePart& OwningPart); // Function EmbarkAI.ConstructableAIControllerBase.AddPartPerceptionComponent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f2ef00
};

// Class EmbarkAI.ConstructablePerceptionServiceConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UConstructablePerceptionServiceConfig : UDataAsset {
	struct TArray<struct FConstructablePerceptionServiceSenseConfig> PartSenseConfigs; // 0xa0(0x10)
};

// Class EmbarkAI.ConstructablePerceptionServiceComponent
// Size: 0x180 (Inherited: 0x180)
struct UConstructablePerceptionServiceComponent : UConstructableServiceComponentBase {
	struct UConstructablePerceptionServiceConfig* ServiceConfig; // 0x178(0x08)

	void OnPartDestroyed(struct UConstructableHealthServiceComponent* HealthServiceComponent, struct UPrimitiveComponent* OwnerStyle, struct FConstructableDamageData& LatestData); // Function EmbarkAI.ConstructablePerceptionServiceComponent.OnPartDestroyed // (Final|Native|Public|HasOutParms) // @ game+0x5f37af0
};

// Class EmbarkAI.AIPerceiver
// Size: 0xa0 (Inherited: 0xa0)
struct UAIPerceiver : UObject {

	void GetAIPerceivedActors(struct FAIPerceiveResult& Result, struct FActorPerceptionBlueprintInfo& PerceptionInfoTemp, struct TArray<struct AActor*>& PerceivedActors, struct FActorPerceptionBlueprintInfo& EmptyPerceptionInfo, struct UAIPerceptionComponent* PerceptionComponent); // Function EmbarkAI.AIPerceiver.GetAIPerceivedActors // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x5f267b0
};

// Class EmbarkAI.AITargetComponent
// Size: 0x490 (Inherited: 0x3c0)
struct UAITargetComponent : USceneComponent {
	struct UAIKnowledgeBaseInterface* AIKBInterface; // 0x3c0(0x08)
	float AccuracyFactor; // 0x3c8(0x04)
	char pad_3cc[0x54]; // 0x3cc(0x54)
	bool bBypassPerception; // 0x420(0x01)
	bool bRegisterWithPerception; // 0x421(0x01)
	char pad_422[0x2]; // 0x422(0x02)
	float ThreatRange; // 0x424(0x04)
	float SightTraceDistanceTolerance; // 0x428(0x04)
	enum class EEmbarkTeamId OverrideTeamId; // 0x42c(0x01)
	char pad_42d[0x3]; // 0x42d(0x03)
	float TargetRadius; // 0x430(0x04)
	char pad_434[0x4]; // 0x434(0x04)
	struct TMap<struct AAIController*, double> LastTimeTargetedBy; // 0x438(0x50)
	char pad_488[0x8]; // 0x488(0x08)

	void UpdateAITargeting(struct FAITargetingParams& TargetingParams, float DeltaSeconds); // Function EmbarkAI.AITargetComponent.UpdateAITargeting // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f34b90
	void RemoveTargetAdjustment(struct FName AdjustmentName); // Function EmbarkAI.AITargetComponent.RemoveTargetAdjustment // (Final|Native|Public|BlueprintCallable) // @ game+0x5f38d60
	struct FVector GetAimDirectionOffset(struct FVector AimDirection, struct FAITargetingParams& TargetingParams, struct FAIAimParams& AimParams, float DeltaSeconds); // Function EmbarkAI.AITargetComponent.GetAimDirectionOffset // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f35120
	float GetAccuracyFactor(); // Function EmbarkAI.AITargetComponent.GetAccuracyFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f25a40
	void AddTargetAdjustment(struct FName AdjustmentName, struct FTemporaryAITargetingModification& TargetAdjustment); // Function EmbarkAI.AITargetComponent.AddTargetAdjustment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f304e0
};

// Class EmbarkAI.AIFocusingInterface
// Size: 0xe0 (Inherited: 0xa0)
struct UAIFocusingInterface : UObject {
	struct TArray<struct FFocusRequest> FocusRequests; // 0x98(0x10)
	struct FFocusTarget SelectedFocus; // 0xa8(0x28)
	enum class EAIFocusMode SelectedFocusMode; // 0xd0(0x01)
	char pad_d9[0x7]; // 0xd9(0x07)

	void SelectFocus(float DeltaSeconds, struct AAIController* AIAgent, bool bCalledViaFocusRequest); // Function EmbarkAI.AIFocusingInterface.SelectFocus // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void RequestFocus(struct AAIController* AIAgent, struct FFocusRequest FocusRequest); // Function EmbarkAI.AIFocusingInterface.RequestFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x5f29c10
	bool IsRequestValid(struct FFocusRequest& Request); // Function EmbarkAI.AIFocusingInterface.IsRequestValid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f30fb0
	bool HasValidFocus(); // Function EmbarkAI.AIFocusingInterface.HasValidFocus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f227b0
	struct FFocusTarget GetCurrentFocus(); // Function EmbarkAI.AIFocusingInterface.GetCurrentFocus // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f2fe20
	void ClearFocus(struct AAIController* AIAgent, enum class EAIFocusMode FocusMode); // Function EmbarkAI.AIFocusingInterface.ClearFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x5a1bcc0
};

// Class EmbarkAI.AIAgentStimuliInfoLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIAgentStimuliInfoLibrary : UBlueprintFunctionLibrary {

	struct FAIStimulusInfo GetTouch(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetTouch // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f390e0
	struct TArray<struct FAIStimulusInfo> GetStimulusInfosAscendingPriority(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetStimulusInfosAscendingPriority // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2bfc0
	struct FAIStimulusInfo GetStimulusBySenseNonConst(struct FAIAgentStimuliInfo& I, enum class EStimulusSense Sense); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetStimulusBySenseNonConst // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f30020
	struct FAIStimulusInfo GetStimulusBySense(struct FAIAgentStimuliInfo& I, enum class EStimulusSense Sense); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetStimulusBySense // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f30020
	struct FAIStimulusInfo GetSight(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetSight // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2c350
	struct FAIStimulusInfo GetSensedStimulus(struct FAIAgentStimuliInfo& I, struct FAIStimulus Stimulus); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetSensedStimulus // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f323b0
	struct FAIStimulusInfo GetNetwork(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetNetwork // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2a410
	float GetLastSensedTime(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetLastSensedTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2bb60
	struct FGameplayTag GetLastKnownTag(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetLastKnownTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f28b90
	float GetHighestAlertness(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetHighestAlertness // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2bb60
	struct FAIStimulusInfo GetHearing(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetHearing // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f31410
	struct FAIStimulusInfo GetDamage(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f374c0
	struct FAIStimulusInfo GetBypass(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.GetBypass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f21e60
	float CombatExpiresAt(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.CombatExpiresAt // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f37e10
	float AlertnessExpiresAt(struct FAIAgentStimuliInfo& I); // Function EmbarkAI.AIAgentStimuliInfoLibrary.AlertnessExpiresAt // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f27570
};

// Class EmbarkAI.EmbarkAITemplateDataAsset
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkAITemplateDataAsset : UDataAsset {
	bool bIgnoreZReachThreshold; // 0xa0(0x01)
	bool bOverrideHasReachedCurrentTargetFunction; // 0xa1(0x01)
	char pad_a2[0x6]; // 0xa2(0x06)
	struct UBlackboardData* BlackboardAssetOverride; // 0xa8(0x08)
};

// Class EmbarkAI.AITemplateDataAsset
// Size: 0x470 (Inherited: 0xb0)
struct UAITemplateDataAsset : UEmbarkAITemplateDataAsset {
	enum class EAINavigationCapability NavigationCapability; // 0xb0(0x01)
	bool bAdhesiveMovement; // 0xb1(0x01)
	char pad_b2[0x2]; // 0xb2(0x02)
	float MinimumProximityRequiredDefault; // 0xb4(0x04)
	bool bAllowSmoothDecelerationWhenComingToFullStop; // 0xb8(0x01)
	char pad_b9[0x3]; // 0xb9(0x03)
	float MinLookAheadDistance; // 0xbc(0x04)
	float MaxLookAheadDistance; // 0xc0(0x04)
	float CurvatureMaxLookAheadDistanceOverride; // 0xc4(0x04)
	float MinimumHeightAboveGround; // 0xc8(0x04)
	float KeepFlyingVelocityForwardSecDuringTurns; // 0xcc(0x04)
	float DestinationToVelocityLerpAlpha; // 0xd0(0x04)
	float ImmediateDestinationVerticalOffset; // 0xd4(0x04)
	float DesiredFocusLerpAlpha; // 0xd8(0x04)
	float NoProgressStuckDetectionTime; // 0xdc(0x04)
	bool bUseGroundSplinePathOutOfSharpCorners; // 0xe0(0x01)
	char pad_e1[0x7]; // 0xe1(0x07)
	struct FGameplayTagContainer GrantedBehaviors; // 0xe8(0x20)
	struct UAIFocusingInterface* FocusingFunction; // 0x108(0x08)
	struct UAITargetingInterface* TargetingFunction; // 0x110(0x08)
	struct TArray<struct UGameplayEffect*> InitialGameplayEffects; // 0x118(0x10)
	struct USMInstance* AlertnessStateProgram; // 0x128(0x08)
	bool bStickyIdentified; // 0x130(0x01)
	char pad_131[0x7]; // 0x131(0x07)
	struct FAISensingIdentification IdentifiedThreatRequirement; // 0x138(0x18)
	struct TArray<struct FAISensingIdentification> IdentifiedThreatRequirementOptions; // 0x150(0x10)
	struct FAISensingStatusTransition PotentialThreatRequirement; // 0x160(0x18)
	struct FNetworkMessageSettings LocalNetworkMessages; // 0x178(0x20)
	float FriendlyDetectionRange; // 0x198(0x04)
	float NeutralDetectionRange; // 0x19c(0x04)
	float TargetingTrackingSpeed; // 0x1a0(0x04)
	float TargetingLookAheadTime; // 0x1a4(0x04)
	float TargetingDirectionCorrectionSpeed; // 0x1a8(0x04)
	char pad_1ac[0x4]; // 0x1ac(0x04)
	struct FAISmartObjectData SmartObjectSettings; // 0x1b0(0x2c0)
};

// Class EmbarkAI.AITargetingInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UAITargetingInterface : UObject {

	void SelectTargets(float DeltaSeconds, struct AAIController* AIAgent, struct TArray<struct UAITargetComponent*>& OutSelectedTargets); // Function EmbarkAI.AITargetingInterface.SelectTargets // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void SelectNeutralTargets(float DeltaSeconds, struct AAIController* AIAgent, struct TArray<struct UAITargetComponent*>& OutSelectedNeutralTargets); // Function EmbarkAI.AITargetingInterface.SelectNeutralTargets // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void SelectFriendlyTargets(float DeltaSeconds, struct AAIController* AIAgent, struct TArray<struct UAITargetComponent*>& OutSelectedFriendlyTargets); // Function EmbarkAI.AITargetingInterface.SelectFriendlyTargets // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkAI.AgentInfoFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAgentInfoFunctionLibrary : UBlueprintFunctionLibrary {

	void RegisterShot(struct FAgentInfo& AgentInfo, struct FVector& SourceLocation, struct FVector& TargetLocation, struct FVector& HitLocation); // Function EmbarkAI.AgentInfoFunctionLibrary.RegisterShot // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f27770
	bool IsTargetPerceivedBySense(struct UObject* WorldContextObject, struct FAgentInfo& Info, struct UAITargetComponent* TargetComponent, enum class EStimulusSense Sense, float TimeSincePerceived); // Function EmbarkAI.AgentInfoFunctionLibrary.IsTargetPerceivedBySense // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f2e850
	bool IsLastTimeWithin(struct UObject* WorldContextObject, float LastTime, float TimeWithin); // Function EmbarkAI.AgentInfoFunctionLibrary.IsLastTimeWithin // (Final|Native|Static|Public) // @ game+0x5f2d180
	bool HasTarget(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.HasTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f21d90
	bool HasRecentMissedShot(struct FAgentInfo& AgentInfo, struct FVector& SourceLocation, struct FVector& TargetLocation, float SourceTolerance, float TargetTolerance, float MissDistance); // Function EmbarkAI.AgentInfoFunctionLibrary.HasRecentMissedShot // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f24d10
	bool HasGrantedBehavior(struct FAgentInfo& Info, struct FGameplayTag& Tag); // Function EmbarkAI.AgentInfoFunctionLibrary.HasGrantedBehavior // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f30ab0
	bool GetUnsensedFriendlyTargetsWithinRange(struct FAgentInfo& Info, float MaxRange, struct TArray<struct UAITargetComponent*>& OutTargets); // Function EmbarkAI.AgentInfoFunctionLibrary.GetUnsensedFriendlyTargetsWithinRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f381e0
	float GetTimeSince(struct UObject* WorldContextObject, float LastTime); // Function EmbarkAI.AgentInfoFunctionLibrary.GetTimeSince // (Final|Native|Static|Public) // @ game+0x5f32d60
	struct FGameplayTagQuery GetSmartObjectUserQueryFromAgentInfoSettings(struct FAgentInfo& AgentInfo); // Function EmbarkAI.AgentInfoFunctionLibrary.GetSmartObjectUserQueryFromAgentInfoSettings // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f35dc0
	struct FGameplayTagQuery GetSmartObjectUserQuery(struct FAISmartObjectQuerySettings& Settings, struct FAgentInfo& AgentInfo); // Function EmbarkAI.AgentInfoFunctionLibrary.GetSmartObjectUserQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f23e10
	struct FAISmartObjectQuerySettings GetSmartObjectQuerySettings(struct FAgentInfo& AgentInfo); // Function EmbarkAI.AgentInfoFunctionLibrary.GetSmartObjectQuerySettings // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f23fd0
	bool GetSelectedTargetsWithinRange(struct FAgentInfo& Info, float MaxRange, struct TArray<struct UAITargetComponent*>& OutTargets); // Function EmbarkAI.AgentInfoFunctionLibrary.GetSelectedTargetsWithinRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f381e0
	float GetRecentDamageTakenFromTarget(struct UObject* WorldContextObject, struct FAgentTargetInfo& AgentTargetInfo, int32_t Seconds, int32_t PartID, enum class EDamageTakenSecondType DamageType, char DamageEffectTypeBitMask); // Function EmbarkAI.AgentInfoFunctionLibrary.GetRecentDamageTakenFromTarget // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f22e00
	float GetRecentDamageTaken(struct UObject* WorldContextObject, struct FAgentInfo& AgentInfo, int32_t Seconds, int32_t PartID, enum class EDamageTakenSecondType DamageType, char DamageEffectTypeBitMask); // Function EmbarkAI.AgentInfoFunctionLibrary.GetRecentDamageTaken // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f35370
	struct UAITargetComponent* GetMostRelevantTarget(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetMostRelevantTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f27c10
	struct UAITargetComponent* GetMostRelevantNeutralTarget(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetMostRelevantNeutralTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2cf50
	struct UAITargetComponent* GetMostRelevantFriendlyTarget(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetMostRelevantFriendlyTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f2bd50
	struct TArray<struct UAITargetComponent*> GetKnownTargetsBySense(struct UObject* WorldContextObject, struct FAgentInfo& Info, enum class EStimulusSense Sense, bool bOnlyCurrentlyPerceived); // Function EmbarkAI.AgentInfoFunctionLibrary.GetKnownTargetsBySense // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f307f0
	struct FVector GetAverageVelocitySince(struct FAgentInfo& AgentInfo, float& CurrentTime, float& Duration); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAverageVelocitySince // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f22920
	struct FVector GetAverageLocationSince(struct FAgentInfo& AgentInfo, float& CurrentTime, float& Duration); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAverageLocationSince // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f22920
	struct TArray<struct UAITargetComponent*> GetAllSortedRelevantTargets(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAllSortedRelevantTargets // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f22c00
	struct TArray<struct FAITargetHandle> GetAllSortedRelevantTargetHandles(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAllSortedRelevantTargetHandles // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f26d90
	struct TArray<struct UAITargetComponent*> GetAllSortedFriendlyTargets(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAllSortedFriendlyTargets // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f349d0
	struct TArray<struct UAITargetComponent*> GetAllNeutralTargets(struct FAgentInfo& Info); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAllNeutralTargets // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f32a50
	bool GetAIAgentsWithinRange(struct UObject* WorldContextObject, struct FVector& Origin, float MaxRange, struct TArray<struct AAIController*>& OutAgents); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAIAgentsWithinRange // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f24520
	bool GetAgentTargetInfoSafe(struct FAgentTargetInfo& OutAgentTargetInfo, struct FAgentInfo& Info, struct UAITargetComponent* TargetComponent); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAgentTargetInfoSafe // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f2c810
	struct FAgentTargetInfo GetAgentTargetInfoFromHandle(struct FAgentInfo& Info, struct FAITargetHandle& TargetHandle); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAgentTargetInfoFromHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f2f5c0
	struct FAgentTargetInfo GetAgentTargetInfo(struct FAgentInfo& Info, struct UAITargetComponent* TargetComponent); // Function EmbarkAI.AgentInfoFunctionLibrary.GetAgentTargetInfo // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f38900
	void GatherPendingAgentOrders(struct FAgentInfo& AgentInfo, struct TArray<struct UAgentOrder*>& OrdersOut); // Function EmbarkAI.AgentInfoFunctionLibrary.GatherPendingAgentOrders // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f28410
	void GatherAllActiveOrdersOfType(struct FAgentInfo& AgentInfo, struct TArray<struct UAgentOrder*>& OrdersOut, struct UObject* Type); // Function EmbarkAI.AgentInfoFunctionLibrary.GatherAllActiveOrdersOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f246e0
	void GatherAllActiveOrders(struct FAgentInfo& AgentInfo, struct TArray<struct UAgentOrder*>& OrdersOut); // Function EmbarkAI.AgentInfoFunctionLibrary.GatherAllActiveOrders // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f28410
	bool FindStimuliInfo(struct FAgentInfo& Info, struct FAITargetHandle& TargetHandle, struct FAIAgentStimuliInfo& OutValue); // Function EmbarkAI.AgentInfoFunctionLibrary.FindStimuliInfo // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f27f30
	struct UAgentBehaviorOrder* FindFirstPendingAgentBehaviorOrder(struct FAgentInfo& AgentInfo); // Function EmbarkAI.AgentInfoFunctionLibrary.FindFirstPendingAgentBehaviorOrder // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f23ae0
	struct UAgentBehaviorOrder* FindActiveAgentBehaviorOrder(struct FAgentInfo& AgentInfo); // Function EmbarkAI.AgentInfoFunctionLibrary.FindActiveAgentBehaviorOrder // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f23ae0
	struct FRotator CalcFocusRotator(struct FAgentInfo& AgentInfo, struct FFocusTarget& FocusTarget); // Function EmbarkAI.AgentInfoFunctionLibrary.CalcFocusRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f31970
	struct FVector CalcFocusLocation(struct FAgentInfo& AgentInfo, struct FFocusTarget& FocusTarget); // Function EmbarkAI.AgentInfoFunctionLibrary.CalcFocusLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f2c570
	void AddRecentDamageTaken(struct UObject* WorldContextObject, struct FAgentInfo& AgentInfo, int32_t PartID, struct FConstructableDamageData& DamageData); // Function EmbarkAI.AgentInfoFunctionLibrary.AddRecentDamageTaken // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f27960
};

// Class EmbarkAI.AITargetHandleFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAITargetHandleFunctionLibrary : UBlueprintFunctionLibrary {

	struct UAITargetComponent* Unwrap(struct FAITargetHandle& Handle); // Function EmbarkAI.AITargetHandleFunctionLibrary.Unwrap // (Final|Native|Static|Public|HasOutParms) // @ game+0x2b0f1a0
	bool IsValid(struct FAITargetHandle& Handle); // Function EmbarkAI.AITargetHandleFunctionLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9acf0
	struct FName GetTargetName(struct FAITargetHandle& Handle); // Function EmbarkAI.AITargetHandleFunctionLibrary.GetTargetName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f31230
	struct FVector GetLocation(struct AAIController* AIController, struct FAITargetHandle& Handle, enum class EPerceivedTargetLocationMode LocationMode); // Function EmbarkAI.AITargetHandleFunctionLibrary.GetLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f35860
	struct FVector GetAverageVelocity(struct AAIController* AIController, struct FAITargetHandle& Handle); // Function EmbarkAI.AITargetHandleFunctionLibrary.GetAverageVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f22660
};

// Class EmbarkAI.AgentOrderContextFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAgentOrderContextFunctionLibrary : UBlueprintFunctionLibrary {

	struct UAgentOrderContextBase* MakeContextAndSetStructData(struct AAIController* AIController, struct FEmbarkGenericStruct StructData, struct UObject* ObjectData); // Function EmbarkAI.AgentOrderContextFunctionLibrary.MakeContextAndSetStructData // (Final|Native|Static|Public) // @ game+0x5f40790
	struct UAgentOrderContextBase* MakeContext(struct AAIController* AIController, struct UObject* ObjectData); // Function EmbarkAI.AgentOrderContextFunctionLibrary.MakeContext // (Final|Native|Static|Public) // @ game+0x5f3de00
};

// Class EmbarkAI.AgentOrderContextBase
// Size: 0xc0 (Inherited: 0xa0)
struct UAgentOrderContextBase : UObject {
	struct FEmbarkGenericStruct StructData; // 0x98(0x18)
	struct UObject* ObjectData; // 0xb0(0x08)

	bool IsValid(); // Function EmbarkAI.AgentOrderContextBase.IsValid // (Native|Public|Const) // @ game+0x3247a90
	struct FVector GetContextLocation(); // Function EmbarkAI.AgentOrderContextBase.GetContextLocation // (Native|Public|HasDefaults|Const) // @ game+0x5f3fed0
};

// Class EmbarkAI.AgentOrderLocationContext
// Size: 0xd0 (Inherited: 0xc0)
struct UAgentOrderLocationContext : UAgentOrderContextBase {
	struct FVector Location; // 0xb8(0x18)
};

// Class EmbarkAI.AgentOrderActorContext
// Size: 0xc0 (Inherited: 0xc0)
struct UAgentOrderActorContext : UAgentOrderContextBase {
	struct AActor* Actor; // 0xb8(0x08)
};

// Class EmbarkAI.AgentOrderObjectContext
// Size: 0xc0 (Inherited: 0xc0)
struct UAgentOrderObjectContext : UAgentOrderContextBase {
	struct UObject* Object; // 0xb8(0x08)
};

// Class EmbarkAI.AgentOrderContextHelperFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAgentOrderContextHelperFunctionLibrary : UBlueprintFunctionLibrary {

	struct UAgentOrderObjectContext* CreateAgentOrderObjectContext(struct AAIController* AIAgent, struct UObject* Object); // Function EmbarkAI.AgentOrderContextHelperFunctionLibrary.CreateAgentOrderObjectContext // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5f3b680
	struct UAgentOrderLocationContext* CreateAgentOrderLocationContext(struct AAIController* AIAgent, struct FVector& Location); // Function EmbarkAI.AgentOrderContextHelperFunctionLibrary.CreateAgentOrderLocationContext // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5f3a6b0
	struct UAgentOrderActorContext* CreateAgentOrderActorContext(struct AAIController* AIAgent, struct AActor* Actor); // Function EmbarkAI.AgentOrderContextHelperFunctionLibrary.CreateAgentOrderActorContext // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5f3b080
};

// Class EmbarkAI.AgentOrder
// Size: 0xd0 (Inherited: 0xa0)
struct UAgentOrder : UObject {
	struct UAgentOrderContextBase* CurrentContext; // 0x98(0x08)
	struct AAIController* AIAgent; // 0xa0(0x08)
	struct AActor* OrderInstigator; // 0xa8(0x08)
	enum class EAIAgentOrder AIAgentOrder; // 0xb0(0x01)
	bool bRaiseAlertnessToMatchFilter; // 0xb1(0x01)
	int32_t RequiredAlertnessFilter; // 0xb4(0x04)
	float OrderTimeout; // 0xb8(0x04)
	float OrderDuration; // 0xbc(0x04)
	char pad_c6[0xa]; // 0xc6(0x0a)

	void SetOrderHandle(int32_t ID); // Function EmbarkAI.AgentOrder.SetOrderHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3ba50
	void OnOrderStartedBP(struct UAgentOrderContextBase* InCurrentContext); // Function EmbarkAI.AgentOrder.OnOrderStartedBP // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnOrderStarted(); // Function EmbarkAI.AgentOrder.OnOrderStarted // (Native|Event|Public|BlueprintEvent) // @ game+0x2b95cb0
	void OnOrderIssuedBP(struct UAgentOrderContextBase* InCurrentContext); // Function EmbarkAI.AgentOrder.OnOrderIssuedBP // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnOrderIssued_Internal(); // Function EmbarkAI.AgentOrder.OnOrderIssued_Internal // (Final|Native|Public|BlueprintCallable) // @ game+0x5f3db90
	void OnOrderIssued(); // Function EmbarkAI.AgentOrder.OnOrderIssued // (Native|Event|Public|BlueprintEvent) // @ game+0x2b96540
	bool IsValid_Internal(); // Function EmbarkAI.AgentOrder.IsValid_Internal // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ae8f50
	bool IsValid(); // Function EmbarkAI.AgentOrder.IsValid // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2ae8f50
	bool HasOrderTimedout(); // Function EmbarkAI.AgentOrder.HasOrderTimedout // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3e640
	bool HasOrderDurationEnded(); // Function EmbarkAI.AgentOrder.HasOrderDurationEnded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3cd80
	float GetOrderTimeoutLeft(); // Function EmbarkAI.AgentOrder.GetOrderTimeoutLeft // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3dce0
	int32_t GetOrderHandle(); // Function EmbarkAI.AgentOrder.GetOrderHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x32ad310
	float GetOrderDurationLeft(); // Function EmbarkAI.AgentOrder.GetOrderDurationLeft // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f3fea0
};

// Class EmbarkAI.AgentBehaviorOrder
// Size: 0xf0 (Inherited: 0xd0)
struct UAgentBehaviorOrder : UAgentOrder {
	struct UBehaviorTree* BehaviorTree; // 0xd0(0x08)
	struct UEmbarkAICombatPositionQueryBase* PositionQuery; // 0xd8(0x08)
	float OptimalRange; // 0xe0(0x04)
	char pad_e4[0xc]; // 0xe4(0x0c)
};

// Class EmbarkAI.EmbarkAIAvoidanceManager
// Size: 0x150 (Inherited: 0x150)
struct UEmbarkAIAvoidanceManager : UAvoidanceManager {

	int32_t RegisterAvoidanceObject(struct FVector& Location, float Radius, float TimeToLive, float Weight, int32_t GroupMask, int32_t GroupsToAvoid, int32_t GroupsToIgnore); // Function EmbarkAI.EmbarkAIAvoidanceManager.RegisterAvoidanceObject // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f40e00
	struct UEmbarkAIAvoidanceManager* GetAvoidanceManager(struct UWorld* World); // Function EmbarkAI.EmbarkAIAvoidanceManager.GetAvoidanceManager // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5f3e2f0
};

// Class EmbarkAI.EmbarkAIAvoidanceManagerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAIAvoidanceManagerMixinLibrary : UObject {

	void RemoveAvoidanceObject(struct UEmbarkAIAvoidanceManager* Manager, int32_t AvoidanceUID); // Function EmbarkAI.EmbarkAIAvoidanceManagerMixinLibrary.RemoveAvoidanceObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5f3d270
};

// Class EmbarkAI.EmbarkAIBehaviorTreeComponent
// Size: 0x370 (Inherited: 0x350)
struct UEmbarkAIBehaviorTreeComponent : UBehaviorTreeComponent {
	struct FMulticastInlineDelegate OnSignalTreeFinished; // 0x348(0x10)
	struct FMulticastInlineDelegate OnSignalTreeStarted; // 0x358(0x10)
};

// Class EmbarkAI.EmbarkAIFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAIFunctionLibrary : UBlueprintFunctionLibrary {

	bool SearchForHomeAreaGroundPolys(struct TArray<struct FNavMeshGrid>& GroundNavigationPolys, struct FVector& SearchPoint, struct AEmbarkConstructableRecastNavMesh_Base* NavAreaClass, struct TArray<uint64_t>& OutNavAreaPolys); // Function EmbarkAI.EmbarkAIFunctionLibrary.SearchForHomeAreaGroundPolys // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f3fc40
	bool IsLocationInNodeCluster(struct FVector Location, struct TArray<uint64_t>& NodeCluster, struct ARecastNavMesh* NavMeshData, struct FVector& OutAdjustedLocation); // Function EmbarkAI.EmbarkAIFunctionLibrary.IsLocationInNodeCluster // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f3f1a0
	int32_t GetNearestNavMeshCellIndex(struct FNavMeshGrid& NavMeshGrid, struct FVector& SearchLocation); // Function EmbarkAI.EmbarkAIFunctionLibrary.GetNearestNavMeshCellIndex // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f402d0
	struct FVector GetNavPolyCenter(uint64_t PolyIndex, struct ARecastNavMesh* NavMeshData); // Function EmbarkAI.EmbarkAIFunctionLibrary.GetNavPolyCenter // (Final|Native|Static|Public|HasDefaults) // @ game+0x5f40cb0
	struct TArray<uint64_t> GetNavigationNodesInRange(struct FVector Location, float MaxDistance, struct ARecastNavMesh* NavMeshData); // Function EmbarkAI.EmbarkAIFunctionLibrary.GetNavigationNodesInRange // (Final|Native|Static|Public|HasDefaults) // @ game+0x5f3f370
	void GetNavAgentPropertiesFromNavMesh(struct FNavAgentProperties& NavProps, struct AEmbarkConstructableRecastNavMesh_Base*& NavMeshClass); // Function EmbarkAI.EmbarkAIFunctionLibrary.GetNavAgentPropertiesFromNavMesh // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f40560
	void GetDebugGeometryForNavTile(uint64_t PolyIndex, struct ARecastNavMesh* NavMeshData, struct TArray<struct FVector>& OutPolyEdges); // Function EmbarkAI.EmbarkAIFunctionLibrary.GetDebugGeometryForNavTile // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f41290
	void FindNavPolySpawnLocationsWithFractionBelowHeightMap(struct UObject* WorldContextObject, struct TArray<struct FNavMeshGrid>& NavMeshGrids, struct TArray<struct AEmbarkConstructableRecastNavMesh_Base*>& NavMeshClasses, struct FVector& SearchLocation, struct TArray<struct FVector>& AvoidLocations, float AvoidanceRadius, float FractionThreshold, bool bGreaterThanThreshold, struct TArray<struct FVector>& OutLocations); // Function EmbarkAI.EmbarkAIFunctionLibrary.FindNavPolySpawnLocationsWithFractionBelowHeightMap // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f3d700
	void CreateNavPolyGrid(struct FNavMeshGrid& NavMeshGrid, struct TArray<struct FVector>& SearchPoints, float PolyCheckDistance); // Function EmbarkAI.EmbarkAIFunctionLibrary.CreateNavPolyGrid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f3c9e0
};

// Class EmbarkAI.EmbarkEnvQueryResultWrapper
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkEnvQueryResultWrapper : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)

	bool IsSuccessful(); // Function EmbarkAI.EmbarkEnvQueryResultWrapper.IsSuccessful // (Final|Native|Public|Const) // @ game+0x5f4b110
	bool IsFinished(); // Function EmbarkAI.EmbarkEnvQueryResultWrapper.IsFinished // (Final|Native|Public|Const) // @ game+0x5f4d430
	bool IsAborted(); // Function EmbarkAI.EmbarkEnvQueryResultWrapper.IsAborted // (Final|Native|Public|Const) // @ game+0x5f424a0
	bool HasResult(); // Function EmbarkAI.EmbarkEnvQueryResultWrapper.HasResult // (Final|Native|Public|Const) // @ game+0x5644c50
	struct FEnvQueryResult GetQueryResult(); // Function EmbarkAI.EmbarkEnvQueryResultWrapper.GetQueryResult // (Final|Native|Public|Const) // @ game+0x5f4cd10
	void Clear(); // Function EmbarkAI.EmbarkEnvQueryResultWrapper.Clear // (Final|Native|Public) // @ game+0x5f4c7c0
};

// Class EmbarkAI.EnvQueryResultMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryResultMixinLibrary : UObject {

	void GetItemsAsLocations(struct FEnvQueryResult& Result, struct TArray<struct FVector>& OutLocations); // Function EmbarkAI.EnvQueryResultMixinLibrary.GetItemsAsLocations // (Final|Native|Static|Private|HasOutParms) // @ game+0x5f489c0
};

// Class EmbarkAI.EnvQueryManagerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEnvQueryManagerMixinLibrary : UObject {

	int32_t RunQueryWithParams(struct UEnvQueryManager* Manager, struct UEnvQuery* Query, struct UObject* RequestOwner, enum class EEnvQueryRunMode RunMode, struct FEmbarkEnvQueryParams& Params, struct UEmbarkEnvQueryResultWrapper* NotifyWrapper); // Function EmbarkAI.EnvQueryManagerMixinLibrary.RunQueryWithParams // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f446e0
	int32_t RunQuery(struct UEnvQueryManager* Manager, struct UEnvQuery* Query, struct UObject* RequestOwner, enum class EEnvQueryRunMode RunMode, struct UEmbarkEnvQueryResultWrapper* NotifyWrapper); // Function EmbarkAI.EnvQueryManagerMixinLibrary.RunQuery // (Final|Native|Static|Public) // @ game+0x5f4d680
};

// Class EmbarkAI.EmbarkAIFlowSubsystem
// Size: 0x1e0 (Inherited: 0xb0)
struct UEmbarkAIFlowSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x18]; // 0xb0(0x18)
	double GroupSearchDistance; // 0xc8(0x08)
	double GroupAvoidanceWeight; // 0xd0(0x08)
	int32_t GroupSearchGradient; // 0xd8(0x04)
	char pad_dc[0x4]; // 0xdc(0x04)
	double GroupTurnSpeed; // 0xe0(0x08)
	int32_t VisionDim; // 0xe8(0x04)
	int32_t HeightMapDistanceBetweenVertices; // 0xec(0x04)
	double GroundHeightMargin; // 0xf0(0x08)
	int32_t MaxBucketUpdates; // 0xf8(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)
	struct FVector WorldOrigin; // 0x100(0x18)
	struct FVector WorldEnd; // 0x118(0x18)
	int32_t CellSize; // 0x130(0x04)
	int32_t XGridSize; // 0x134(0x04)
	int32_t YGridSize; // 0x138(0x04)
	char pad_13c[0x4]; // 0x13c(0x04)
	struct FFlowHeightMap HeightMap; // 0x140(0x20)
	struct TArray<int32_t> Visitation; // 0x160(0x10)
	struct TArray<struct FFlowPriorityBucket> BucketPriorityQueue; // 0x170(0x10)
	char pad_180[0x60]; // 0x180(0x60)

	void UpdateGroups(struct TArray<struct APawn*> Agents, double DeltaUpdateTime); // Function EmbarkAI.EmbarkAIFlowSubsystem.UpdateGroups // (Final|Native|Public|BlueprintCallable) // @ game+0x5f4e5d0
	void UnregisterUser(struct AAIController* User); // Function EmbarkAI.EmbarkAIFlowSubsystem.UnregisterUser // (Final|Native|Public|BlueprintCallable) // @ game+0x5f4dee0
	void RegisterUser(struct AAIController* User, double Timeout); // Function EmbarkAI.EmbarkAIFlowSubsystem.RegisterUser // (Final|Native|Public|BlueprintCallable) // @ game+0x5f4c870
	bool OnTryInitialize(); // Function EmbarkAI.EmbarkAIFlowSubsystem.OnTryInitialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	double LineValue(struct FVector Start, struct FVector Direction, double SearchDistance, double BaseHeight); // Function EmbarkAI.EmbarkAIFlowSubsystem.LineValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f4bc70
	bool IsUserActive(struct AAIController* User); // Function EmbarkAI.EmbarkAIFlowSubsystem.IsUserActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f47d50
	int32_t GetTime(int32_t CellX, int32_t CellY); // Function EmbarkAI.EmbarkAIFlowSubsystem.GetTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f4c000
	double FindHeight(struct FVector Location); // Function EmbarkAI.EmbarkAIFlowSubsystem.FindHeight // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f4db10
	double CellValue(struct FVector WorldLocation); // Function EmbarkAI.EmbarkAIFlowSubsystem.CellValue // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f4f3e0
	struct FVector CalculateGroupMovement(struct FVector Centroid, struct FVector HomeLocation, bool bHasGroundAgents, struct TArray<struct FVector>& AvoidanceLocations, struct FAgentGroupInfo& GroupInfo); // Function EmbarkAI.EmbarkAIFlowSubsystem.CalculateGroupMovement // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f45540
};

// Class EmbarkAI.EmbarkAIGroundPathFollowingComponent
// Size: 0x390 (Inherited: 0x380)
struct UEmbarkAIGroundPathFollowingComponent : UPathFollowingComponent {
	char pad_380[0x10]; // 0x380(0x10)

	void SetOverrideHasReachedCurrentTargetFunction(bool bOverride); // Function EmbarkAI.EmbarkAIGroundPathFollowingComponent.SetOverrideHasReachedCurrentTargetFunction // (Final|Native|Public) // @ game+0x5f44140
	void SetIgnoreZReachThreshold(bool bIgnore); // Function EmbarkAI.EmbarkAIGroundPathFollowingComponent.SetIgnoreZReachThreshold // (Final|Native|Public) // @ game+0x5f51090
};

// Class EmbarkAI.GroupRoleInfoMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGroupRoleInfoMixinLibrary : UObject {

	bool IsValid(struct FGroupRoleInfo& Info); // Function EmbarkAI.GroupRoleInfoMixinLibrary.IsValid // (Final|Native|Static|Private|HasOutParms) // @ game+0x5f4ca40
};

// Class EmbarkAI.NavMeshCellMixInLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNavMeshCellMixInLibrary : UObject {

	float GetBelowHeightMapFraction(struct FNavMeshCell& NavMeshCell, int32_t Index); // Function EmbarkAI.NavMeshCellMixInLibrary.GetBelowHeightMapFraction // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f44a20
	void AddNavPoly(struct FNavMeshCell& NavMeshCell, uint64_t PolyID, struct AEmbarkHierarchicalHeightMap* HeightMap, struct ARecastNavMesh* NavMeshData); // Function EmbarkAI.NavMeshCellMixInLibrary.AddNavPoly // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f4d1b0
};

// Class EmbarkAI.NavMeshGridMixInLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNavMeshGridMixInLibrary : UObject {

	int32_t ConvertWorldLocationToIndex(struct FNavMeshGrid& NavMeshGrid, struct FVector& WorldLocation); // Function EmbarkAI.NavMeshGridMixInLibrary.ConvertWorldLocationToIndex // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f46420
};

// Class EmbarkAI.AgentGroupInfoMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAgentGroupInfoMixinLibrary : UObject {

	struct FVector SearchForHomeLocation(struct FAgentGroupInfo& Info, struct FVector SearchPoint); // Function EmbarkAI.AgentGroupInfoMixinLibrary.SearchForHomeLocation // (Final|Native|Static|Private|HasOutParms|HasDefaults) // @ game+0x5f4eff0
	bool SearchForHomeAreaGroundPolys(struct FAgentGroupInfo& Info, struct FVector& SearchPoint, struct AEmbarkConstructableRecastNavMesh_Base* NavAreaClass, struct TArray<uint64_t>& OutNavAreaPolys); // Function EmbarkAI.AgentGroupInfoMixinLibrary.SearchForHomeAreaGroundPolys // (Final|Native|Static|Private|HasOutParms|HasDefaults) // @ game+0x5f479a0
};

// Class EmbarkAI.AIAlertnessFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIAlertnessFunctionLibrary : UBlueprintFunctionLibrary {

	struct FName ToFName(enum class EAIAlertness inAIAlertness); // Function EmbarkAI.AIAlertnessFunctionLibrary.ToFName // (Final|Native|Static|Public) // @ game+0x5f42940
};

// Class EmbarkAI.AIAlertnessSourceFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIAlertnessSourceFunctionLibrary : UBlueprintFunctionLibrary {

	struct FName ToFName(enum class EAIAlertnessSource inAIAlertnessSource); // Function EmbarkAI.AIAlertnessSourceFunctionLibrary.ToFName // (Final|Native|Static|Public) // @ game+0x5f42770
};

// Class EmbarkAI.EmbarkAIKnowledgeBaseInterfaceFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAIKnowledgeBaseInterfaceFunctionLibrary : UBlueprintFunctionLibrary {

	struct UAIKnowledgeBaseInterface* GetAIKnowledgeBaseInterfaceFromGameMode(struct AGameModeBase* GameMode); // Function EmbarkAI.EmbarkAIKnowledgeBaseInterfaceFunctionLibrary.GetAIKnowledgeBaseInterfaceFromGameMode // (Final|Native|Static|Public) // @ game+0x5f48070
	struct UAIKnowledgeBaseInterface* GetAIKnowledgeBaseInterface(struct UObject* WorldContextObject); // Function EmbarkAI.EmbarkAIKnowledgeBaseInterfaceFunctionLibrary.GetAIKnowledgeBaseInterface // (Final|Native|Static|Public) // @ game+0x5f45ec0
};

// Class EmbarkAI.AIKnowledgeBaseInterface
// Size: 0x250 (Inherited: 0x160)
struct UAIKnowledgeBaseInterface : UActorComponent {
	struct TMap<struct AAIController*, struct FAgentInfo> AgentInfoMap; // 0x158(0x50)
	struct TMap<struct UAITargetComponent*, struct FTargetInfo> TargetInfoMap; // 0x1a8(0x50)
	struct TMap<int32_t, struct FAgentGroupInfo> AgentGroupInfos; // 0x1f8(0x50)

	void UpdateAgentTargetInfos(float DeltaSeconds, struct TArray<struct FAIKnowledgebaseNativeEvent>& OutEvents); // Function EmbarkAI.AIKnowledgeBaseInterface.UpdateAgentTargetInfos // (Final|Native|Public|HasOutParms) // @ game+0x5f50c80
	void UpdateAgentPerception(float DeltaSeconds, struct TArray<struct UAITargetComponent*>& PerceptionBypassTargets, struct UAIPerceiver* Perceiver, struct TArray<struct FAIKnowledgebaseNativeEvent>& OutEvents); // Function EmbarkAI.AIKnowledgeBaseInterface.UpdateAgentPerception // (Final|Native|Public|HasOutParms) // @ game+0x5f4f890
	void UpdateAgentInfosSpatialInfo(); // Function EmbarkAI.AIKnowledgeBaseInterface.UpdateAgentInfosSpatialInfo // (Final|Native|Public) // @ game+0x33aadf0
	void UnregisterAITarget(struct UActorComponent* Target); // Function EmbarkAI.AIKnowledgeBaseInterface.UnregisterAITarget // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void UnregisterAIAgent(struct AAIController* Agent); // Function EmbarkAI.AIKnowledgeBaseInterface.UnregisterAIAgent // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct AAIController* TargetFirstIdentifiedBy(struct UAITargetComponent* Target, bool bTargetIsCurrent); // Function EmbarkAI.AIKnowledgeBaseInterface.TargetFirstIdentifiedBy // (Final|Native|Public|Const) // @ game+0x5f45050
	void RegisterAITarget(struct UActorComponent* Target); // Function EmbarkAI.AIKnowledgeBaseInterface.RegisterAITarget // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void RegisterAIAgent(struct AAIController* Agent, struct UDataAsset* Template); // Function EmbarkAI.AIKnowledgeBaseInterface.RegisterAIAgent // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDamageTaken(struct UConstructableHealthServiceComponent* HealthService, struct FConstructableDamageData& DamageData); // Function EmbarkAI.AIKnowledgeBaseInterface.OnDamageTaken // (Final|Native|Public|HasOutParms) // @ game+0x5f43ee0
	int32_t NumAgentsHasTarget(struct UAITargetComponent* Target, bool bIsIdentified, bool bTargetIsCurrent, struct AAIController* QuerierToSkip); // Function EmbarkAI.AIKnowledgeBaseInterface.NumAgentsHasTarget // (Final|Native|Public|Const) // @ game+0x5f4a080
	bool HasAgentGroupInfo(int32_t GroupId); // Function EmbarkAI.AIKnowledgeBaseInterface.HasAgentGroupInfo // (Final|Native|Public|Const) // @ game+0x5f4b3b0
	struct TMap<struct UAITargetComponent*, struct FTargetInfo> GetTargetInfos(); // Function EmbarkAI.AIKnowledgeBaseInterface.GetTargetInfos // (Final|Native|Public|Const) // @ game+0x5f475f0
	struct FTargetInfo GetTargetInfo(struct UAITargetComponent* Comp); // Function EmbarkAI.AIKnowledgeBaseInterface.GetTargetInfo // (Final|Native|Public|Const) // @ game+0x5f48b10
	struct TMap<struct AAIController*, struct FAgentInfo> GetAgentInfos(); // Function EmbarkAI.AIKnowledgeBaseInterface.GetAgentInfos // (Final|Native|Public|Const) // @ game+0x5f4b470
	struct FAgentInfo GetAgentInfoNonRef(struct AAIController* AIController); // Function EmbarkAI.AIKnowledgeBaseInterface.GetAgentInfoNonRef // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f42860
	struct FAgentInfo GetAgentInfoNonConst(struct AAIController* AIController); // Function EmbarkAI.AIKnowledgeBaseInterface.GetAgentInfoNonConst // (Final|Native|Public) // @ game+0x5f44c00
	struct FAgentInfo GetAgentInfo(struct AAIController* AIController); // Function EmbarkAI.AIKnowledgeBaseInterface.GetAgentInfo // (Final|Native|Public|Const) // @ game+0x5f47540
	struct FAgentGroupInfo GetAgentGroupInfo(int32_t GroupId); // Function EmbarkAI.AIKnowledgeBaseInterface.GetAgentGroupInfo // (Final|Native|Public|Const) // @ game+0x5f476f0
	bool CanSeeTarget(struct UObject* WorldContextObject, struct FAgentInfo& Info, struct UAITargetComponent* TargetComponent, float TimeSinceSeen); // Function EmbarkAI.AIKnowledgeBaseInterface.CanSeeTarget // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f4fd50
	bool AgentInfoExist(struct AAIController* AIController); // Function EmbarkAI.AIKnowledgeBaseInterface.AgentInfoExist // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x59068a0
};

// Class EmbarkAI.EmbarkAINavigationComponentBase
// Size: 0x190 (Inherited: 0x160)
struct UEmbarkAINavigationComponentBase : UActorComponent {
	struct AAIController* Controller; // 0x158(0x08)
	struct FVector Destination; // 0x160(0x18)
	struct FVector ImmediateDestination; // 0x178(0x18)

	void StopMovement(); // Function EmbarkAI.EmbarkAINavigationComponentBase.StopMovement // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool GetPreviouslyVisitedLocations(struct TArray<struct FVector>& OutPositions); // Function EmbarkAI.EmbarkAINavigationComponentBase.GetPreviouslyVisitedLocations // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	struct FVector GetMoveDestination(); // Function EmbarkAI.EmbarkAINavigationComponentBase.GetMoveDestination // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f588e0
	struct FVector GetImmediateMoveDestination(); // Function EmbarkAI.EmbarkAINavigationComponentBase.GetImmediateMoveDestination // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f56600
	enum class EPathFollowingRequestResult FindPath(struct FEmbarkAIPathRequest& PathRequest, struct TArray<struct FVector>& OutOptimizedPath); // Function EmbarkAI.EmbarkAINavigationComponentBase.FindPath // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f57a20
};

// Class EmbarkAI.EmbarkAINavLinkComponent
// Size: 0x2a0 (Inherited: 0x2a0)
struct UEmbarkAINavLinkComponent : UNavLinkCustomComponent {

	void BP_SetEnabled(bool bNewEnabled); // Function EmbarkAI.EmbarkAINavLinkComponent.BP_SetEnabled // (Final|Native|Protected) // @ game+0x5f54fe0
	bool BP_IsEnabled(); // Function EmbarkAI.EmbarkAINavLinkComponent.BP_IsEnabled // (Final|Native|Protected|Const) // @ game+0x5f52280
	struct FVector BP_GetStartPoint(); // Function EmbarkAI.EmbarkAINavLinkComponent.BP_GetStartPoint // (Final|Native|Protected|HasDefaults|Const) // @ game+0x5f58200
	struct FVector BP_GetEndPoint(); // Function EmbarkAI.EmbarkAINavLinkComponent.BP_GetEndPoint // (Final|Native|Protected|HasDefaults|Const) // @ game+0x5f53880
};

// Class EmbarkAI.EmbarkAIPerceivableInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAIPerceivableInterface : UInterface {
};

// Class EmbarkAI.EmbarkAIPerceptionSystem
// Size: 0x1b0 (Inherited: 0x1b0)
struct UEmbarkAIPerceptionSystem : UAIPerceptionSystem {

	void SetVisibilityModifier(struct UObject* WorldContextObject, float InVisibilityModifier); // Function EmbarkAI.EmbarkAIPerceptionSystem.SetVisibilityModifier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5f538e0
	void SetIncreasedNoiseLevel(struct UObject* WorldContextObject, char InIncreasedNoiseLevel); // Function EmbarkAI.EmbarkAIPerceptionSystem.SetIncreasedNoiseLevel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5f516a0
};

// Class EmbarkAI.EmbarkAICombatPositionQueryBase
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkAICombatPositionQueryBase : UObject {
	bool bStopMovingWithinLOS; // 0x98(0x01)
	bool bIsContinious; // 0x99(0x01)
	struct FCombatPositionQueryInfo StoredQueryInfo; // 0xa0(0x30)
	struct FCombatPositionQueryResults StoredQueryResults; // 0xd0(0x28)
	float QueryFrequency; // 0xf8(0x04)
	char pad_fe[0x2]; // 0xfe(0x02)

	void UpdateQuery_Internal(); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.UpdateQuery_Internal // (Final|Native|Protected|BlueprintCallable) // @ game+0x29fb8f0
	void UpdateQuery(); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.UpdateQuery // (Native|Event|Public|BlueprintEvent) // @ game+0x29fb8f0
	enum class EAICombatPositionQueryState RunQuery_Internal(struct FCombatPositionQueryInfo& QueryInfo); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.RunQuery_Internal // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x5f523d0
	enum class EAICombatPositionQueryState RunQuery(struct FCombatPositionQueryInfo& QueryInfo); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.RunQuery // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5f51c50
	bool ReadyToRunContiniousQuery(); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.ReadyToRunContiniousQuery // (Final|Native|Protected|BlueprintCallable) // @ game+0x5f54820
	enum class EAICombatPositionQueryState GetQueryResult_Internal(struct FCombatPositionQueryResults& OutPositionInfo); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.GetQueryResult_Internal // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f534f0
	enum class EAICombatPositionQueryState GetQueryResult(struct FCombatPositionQueryResults& OutPositionInfo); // Function EmbarkAI.EmbarkAICombatPositionQueryBase.GetQueryResult // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5f534f0
};

// Class EmbarkAI.EmbarkAISenseEvent_Damage
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkAISenseEvent_Damage : UAISenseEvent {
	struct FEmbarkAIDamageEvent Event; // 0x98(0x58)
};

// Class EmbarkAI.EmbarkAISense_Damage
// Size: 0x110 (Inherited: 0x100)
struct UEmbarkAISense_Damage : UAISense_Damage {
	struct TArray<struct FEmbarkAIDamageEvent> RegisteredDamageEvents; // 0xf8(0x10)

	void ReportEmbarkDamageEvent(struct UObject* WorldContextObject, struct AActor* DamagedActor, struct AActor* Instigator, float DamageAmount, struct FVector EventLocation, struct FVector HitLocation, bool bProxyDamage, struct FName Tag); // Function EmbarkAI.EmbarkAISense_Damage.ReportEmbarkDamageEvent // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5f51dc0
};

// Class EmbarkAI.EmbarkAISenseConfig_Damage
// Size: 0xd0 (Inherited: 0xc0)
struct UEmbarkAISenseConfig_Damage : UAISenseConfig_Damage {
	float StrengthMultiplier; // 0xc0(0x04)
	float ProxyDamageStrengthMultiplier; // 0xc4(0x04)
	char pad_c8[0x8]; // 0xc8(0x08)
};

// Class EmbarkAI.EmbarkAISense_Hearing
// Size: 0x150 (Inherited: 0xf0)
struct UEmbarkAISense_Hearing : UAISense {
	struct TArray<struct FEmbarkAISoundEvent> SoundEvents; // 0xe8(0x10)
	char pad_100[0x50]; // 0x100(0x50)

	void ReportSoundEvent(struct UObject* WorldContextObject, struct FVector NoiseLocation, float Range, struct AActor* Instigator, struct FName Tag); // Function EmbarkAI.EmbarkAISense_Hearing.ReportSoundEvent // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5f56040
};

// Class EmbarkAI.EmbarkAISenseEvent_Hearing
// Size: 0xd0 (Inherited: 0xa0)
struct UEmbarkAISenseEvent_Hearing : UAISenseEvent {
	struct FEmbarkAISoundEvent Event; // 0x98(0x38)
};

// Class EmbarkAI.EmbarkAISenseConfig_Hearing
// Size: 0xd0 (Inherited: 0xc0)
struct UEmbarkAISenseConfig_Hearing : UAISenseConfig {
	float StrengthScalar; // 0xb8(0x04)
	enum class EAISoundInterestRange InterestRange; // 0xbc(0x01)
	enum class EAISoundMaskingEngine NoiseMasking; // 0xbd(0x01)
	bool bUseLoSHearing; // 0xbe(0x01)
	struct FAISenseAffiliationFilter DetectionByAffiliation; // 0xc0(0x04)
	char pad_cb[0x5]; // 0xcb(0x05)
};

// Class EmbarkAI.EmbarkAISense_Network
// Size: 0x150 (Inherited: 0xf0)
struct UEmbarkAISense_Network : UAISense {
	struct TArray<struct FEmbarkAINetworkEvent> RegisteredEvents; // 0xe8(0x10)
	char pad_100[0x50]; // 0x100(0x50)

	void ReportNetworkEvent(struct UObject* WorldContextObject, struct AActor* Instigator, struct AActor* TargetActor, struct FVector& LastSeenLocation, float MaxRange, struct FName Tag); // Function EmbarkAI.EmbarkAISense_Network.ReportNetworkEvent // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f58650
};

// Class EmbarkAI.EmbarkAISenseEvent_Network
// Size: 0xe0 (Inherited: 0xa0)
struct UEmbarkAISenseEvent_Network : UAISenseEvent {
	struct FEmbarkAINetworkEvent Event; // 0x98(0x40)
};

// Class EmbarkAI.EmbarkAISenseConfig_Network
// Size: 0x120 (Inherited: 0xc0)
struct UEmbarkAISenseConfig_Network : UAISenseConfig {
	float StrengthScalar; // 0xb8(0x04)
	struct TMap<struct FGameplayTag, float> TagBasedStrengthOverride; // 0xc0(0x50)
	float HeightCutoffDistance; // 0x110(0x04)
	float InterestRange; // 0x114(0x04)
	char pad_11c[0x4]; // 0x11c(0x04)
};

// Class EmbarkAI.EmbarkAISense_Sight
// Size: 0x220 (Inherited: 0x220)
struct UEmbarkAISense_Sight : UAISense_Sight {
};

// Class EmbarkAI.EmbarkAISenseConfig_Sight
// Size: 0x100 (Inherited: 0xe0)
struct UEmbarkAISenseConfig_Sight : UAISenseConfig_Sight {
	float StrengthScalar; // 0xe0(0x04)
	float MacularVisionAngleDegrees; // 0xe4(0x04)
	float VerticalPeripheralFactor; // 0xe8(0x04)
	float VisionFalloff; // 0xec(0x04)
	float MinimumSightRadius; // 0xf0(0x04)
	char pad_f4[0xc]; // 0xf4(0x0c)
};

// Class EmbarkAI.EmbarkAISense_Touch
// Size: 0x100 (Inherited: 0xf0)
struct UEmbarkAISense_Touch : UAISense {
	struct TArray<struct FEmbarkAITouchEvent> RegisteredEvents; // 0xe8(0x10)

	void ReportTouchEvent(struct UObject* WorldContextObject, struct AActor* TouchReceiver, struct AActor* OtherActor, struct FVector& EventLocation, struct FGameplayTag SenseTag); // Function EmbarkAI.EmbarkAISense_Touch.ReportTouchEvent // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f54290
};

// Class EmbarkAI.EmbarkAISenseEvent_Touch
// Size: 0xd0 (Inherited: 0xa0)
struct UEmbarkAISenseEvent_Touch : UAISenseEvent {
	struct FEmbarkAITouchEvent Event; // 0x98(0x38)
};

// Class EmbarkAI.EmbarkAISenseConfig_Touch
// Size: 0xc0 (Inherited: 0xc0)
struct UEmbarkAISenseConfig_Touch : UAISenseConfig {
};

// Class EmbarkAI.EmbarkAISpawnerBase
// Size: 0x3a0 (Inherited: 0x3a0)
struct AEmbarkAISpawnerBase : AActor {

	void ReceivePreSave(); // Function EmbarkAI.EmbarkAISpawnerBase.ReceivePreSave // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void RecastNavmeshCommandletUpdate(struct TArray<struct UPackage*>& OutModifiedPackages); // Function EmbarkAI.EmbarkAISpawnerBase.RecastNavmeshCommandletUpdate // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkAI.EmbarkBTTask_BlueprintBase
// Size: 0x120 (Inherited: 0x120)
struct UEmbarkBTTask_BlueprintBase : UBTTask_BlueprintBase {

	void ReceiveOnTaskFinished(struct AAIController* OwnerController, enum class EBTNodeResult TaskResult); // Function EmbarkAI.EmbarkBTTask_BlueprintBase.ReceiveOnTaskFinished // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	struct FString ReceiveGetStaticDescription(); // Function EmbarkAI.EmbarkBTTask_BlueprintBase.ReceiveGetStaticDescription // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkAI.EmbarkEnvQueryGenerator_DonutSpan
// Size: 0x250 (Inherited: 0x100)
struct UEmbarkEnvQueryGenerator_DonutSpan : UEnvQueryGenerator_ProjectedPoints {
	struct FAIDataProviderFloatValue InnerRadius; // 0x100(0x38)
	struct FAIDataProviderFloatValue RadiusSpan; // 0x138(0x38)
	struct FAIDataProviderIntValue NumberOfRings; // 0x170(0x38)
	struct FAIDataProviderIntValue PointsPerRing; // 0x1a8(0x38)
	struct FEnvDirection ArcDirection; // 0x1e0(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x200(0x38)
	bool bUseSpiralPattern; // 0x238(0x01)
	char pad_239[0x7]; // 0x239(0x07)
	struct UEnvQueryContext* Center; // 0x240(0x08)
	char bDefineArc : 1; // 0x248(0x01)
	char pad_248_1 : 7; // 0x248(0x01)
	char pad_249[0x7]; // 0x249(0x07)
};

// Class EmbarkAI.EmbarkEnvQueryGenerator_DynamicShape
// Size: 0x3f0 (Inherited: 0x100)
struct UEmbarkEnvQueryGenerator_DynamicShape : UEnvQueryGenerator_ProjectedPoints {
	struct UEnvQueryContext* Center; // 0x100(0x08)
	struct UEnvQueryContext* ReferenceContext; // 0x108(0x08)
	enum class EEnvQueryDynamicShapeNavOption NavigationOption; // 0x110(0x01)
	bool bUseDistanceThreshold; // 0x111(0x01)
	char pad_112[0x2]; // 0x112(0x02)
	float FuzzyLocationThresholdDistance; // 0x114(0x04)
	float HeightOffsetVoxelScale; // 0x118(0x04)
	bool bAlwaysAddCenterToPattern; // 0x11c(0x01)
	char pad_11d[0x3]; // 0x11d(0x03)
	float MinDistance; // 0x120(0x04)
	float MaxDistance; // 0x124(0x04)
	bool bUse2D; // 0x128(0x01)
	bool bAdjustForHeightDifference; // 0x129(0x01)
	char pad_12a[0x2]; // 0x12a(0x02)
	float HeightDistanceMaxAngle; // 0x12c(0x04)
	bool bHeightAngleIsFromCenter; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	float HeightAngleFromContext; // 0x134(0x04)
	struct FRuntimeFloatCurve InnerRadius; // 0x138(0x88)
	struct FRuntimeFloatCurve OuterRadius; // 0x1c0(0x88)
	struct FRuntimeFloatCurve Spacing; // 0x248(0x88)
	bool bArcLineFromCenterToReference; // 0x2d0(0x01)
	char pad_2d1[0x7]; // 0x2d1(0x07)
	struct FRuntimeFloatCurve Arc; // 0x2d8(0x88)
	struct FRuntimeFloatCurve Offset; // 0x360(0x88)
	char pad_3e8[0x8]; // 0x3e8(0x08)
};

// Class EmbarkAI.EmbarkEnvQueryGenerator_FlyingBase
// Size: 0x150 (Inherited: 0xc0)
struct UEmbarkEnvQueryGenerator_FlyingBase : UEnvQueryGenerator {
	struct FAIDataProviderFloatValue DesiredFlyingHeight; // 0xc0(0x38)
	struct UEnvQueryContext* MinimumFlyingHeightTarget; // 0xf8(0x08)
	enum class EEmbarkEnvQueryFlyingProjection ProjectionType; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FAIDataProviderFloatValue CollisionRadius; // 0x108(0x38)
	enum class ETraceTypeQuery TraceChannel; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	float ProjectDown; // 0x144(0x04)
	float ProjectUp; // 0x148(0x04)
	char pad_14c[0x4]; // 0x14c(0x04)
};

// Class EmbarkAI.EmbarkEnvQueryGenerator_Flying
// Size: 0x2d0 (Inherited: 0x150)
struct UEmbarkEnvQueryGenerator_Flying : UEmbarkEnvQueryGenerator_FlyingBase {
	struct UEnvQueryContext* Center; // 0x150(0x08)
	struct FAIDataProviderFloatValue InnerRadius; // 0x158(0x38)
	struct FAIDataProviderFloatValue RadiusSpan; // 0x190(0x38)
	struct FAIDataProviderIntValue NumRings; // 0x1c8(0x38)
	struct FAIDataProviderIntValue NumPoints; // 0x200(0x38)
	struct FEnvDirection Direction; // 0x238(0x20)
	struct FAIDataProviderFloatValue ArcAngle; // 0x258(0x38)
	struct FAIDataProviderFloatValue StartAngle; // 0x290(0x38)
	char pad_2c8[0x8]; // 0x2c8(0x08)
};

// Class EmbarkAI.EmbarkEnvQueryGenerator_Hiding
// Size: 0x1a0 (Inherited: 0x100)
struct UEmbarkEnvQueryGenerator_Hiding : UEnvQueryGenerator_ProjectedPoints {
	struct UEnvQueryContext* Center; // 0x100(0x08)
	struct UEnvQueryContext* ReferenceContext; // 0x108(0x08)
	float MinDistance2D; // 0x110(0x04)
	float MaxDistance2D; // 0x114(0x04)
	float HeightDiffThreshold; // 0x118(0x04)
	int32_t MaxNumPoints; // 0x11c(0x04)
	bool bFailGeneratorIfCenterIndoor; // 0x120(0x01)
	bool bRemoveFailedHeightDrops; // 0x121(0x01)
	enum class EGeneratorProjectionType ProjectionType; // 0x122(0x01)
	char pad_123[0x5]; // 0x123(0x05)
	struct FAIDataProviderFloatValue DesiredFlyingHeight; // 0x128(0x38)
	struct FAIDataProviderFloatValue CollisionRadius; // 0x160(0x38)
	float ProjectDown; // 0x198(0x04)
	float ProjectUp; // 0x19c(0x04)
};

// Class EmbarkAI.EmbarkEnvQueryTest_BlueprintBase
// Size: 0x2b0 (Inherited: 0x270)
struct UEmbarkEnvQueryTest_BlueprintBase : UEnvQueryTest {
	struct FAIDataProviderBoolValue BoolValueUseFloatScore; // 0x268(0x38)
	struct UEnvQueryContext* Context; // 0x2a0(0x08)
	enum class EEmbarkEnvQueryCost TestCost; // 0x2a8(0x01)

	void ReceiveRunTest_Item(struct FQueryInstanceItemInput& ItemInput, struct FQueryInstanceItemOutput& ItemOutput); // Function EmbarkAI.EmbarkEnvQueryTest_BlueprintBase.ReceiveRunTest_Item // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveGetDescriptionTitle(struct FText& Out); // Function EmbarkAI.EmbarkEnvQueryTest_BlueprintBase.ReceiveGetDescriptionTitle // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveGetDescriptionDetails(struct FText& Out); // Function EmbarkAI.EmbarkEnvQueryTest_BlueprintBase.ReceiveGetDescriptionDetails // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkAI.EmbarkEnvQueryTest_HpaPathfinding
// Size: 0x2b0 (Inherited: 0x270)
struct UEmbarkEnvQueryTest_HpaPathfinding : UEnvQueryTest {
	struct UEnvQueryContext* Context; // 0x268(0x08)
	struct FAIDataProviderFloatValue AgentCollisionRadius; // 0x270(0x38)
};

// Class EmbarkAI.EmbarkSmartObjectComponent
// Size: 0x3e0 (Inherited: 0x3c0)
struct UEmbarkSmartObjectComponent : USceneComponent {
	struct TArray<struct FEmbarkSmartObjectSlot> Slots; // 0x3c0(0x10)
	char pad_3d0[0x10]; // 0x3d0(0x10)

	int32_t ReceiveSelectSlot(struct AActor* Querier, struct TArray<int32_t>& AvailableSlots); // Function EmbarkAI.EmbarkSmartObjectComponent.ReceiveSelectSlot // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveRelease(struct AActor* Querier, int32_t Slot); // Function EmbarkAI.EmbarkSmartObjectComponent.ReceiveRelease // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveNotify(struct AActor* Querier, int32_t Slot, enum class ESmartObjectNotify Notify); // Function EmbarkAI.EmbarkSmartObjectComponent.ReceiveNotify // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveClaim(struct AActor* Querier, int32_t Slot); // Function EmbarkAI.EmbarkSmartObjectComponent.ReceiveClaim // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveCanBeClaimed(struct AActor* Querier, int32_t Slot); // Function EmbarkAI.EmbarkSmartObjectComponent.ReceiveCanBeClaimed // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkAI.EmbarkSmartObjectSubsystem
// Size: 0x1d0 (Inherited: 0xa0)
struct UEmbarkSmartObjectSubsystem : UWorldSubsystem {
	struct TArray<struct FEmbarkSmartObjectClaimHandle> CurrentClaimHandles; // 0xa0(0x10)
	char pad_b0[0xb8]; // 0xb0(0xb8)
	struct TArray<struct UEmbarkSmartObjectComponent*> QueuedSmartObjects; // 0x168(0x10)
	struct TMap<struct UEmbarkSmartObjectComponent*, struct FEmbarkOctreeDataHandle> SmartObjectToOctreeHandle; // 0x178(0x50)
	char pad_1c8[0x8]; // 0x1c8(0x08)

	bool Release(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.Release // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f5cd20
	bool IsInitialized(); // Function EmbarkAI.EmbarkSmartObjectSubsystem.IsInitialized // (Final|Native|Public|BlueprintCallable) // @ game+0x5f5d300
	void InitializeOctree(struct FBox& Bounds); // Function EmbarkAI.EmbarkSmartObjectSubsystem.InitializeOctree // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f5d250
	bool GetSmartObjectRawPtrsInRange(struct FBox& QueryBox, struct TArray<struct UEmbarkSmartObjectComponent*>& OutResults); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetSmartObjectRawPtrsInRange // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f5a300
	struct UEmbarkSmartObjectComponent* GetSmartObject(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetSmartObject // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f59890
	struct FQuat GetSlotRotation(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetSlotRotation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f59bb0
	struct FVector GetSlotLocation(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetSlotLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f5c310
	int32_t GetSlotIndex(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetSlotIndex // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f5c250
	struct UEmbarkSmartObjectSubsystem* GetCurrent(struct UWorld* World); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetCurrent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5f5db90
	struct FEmbarkSmartObjectClaimHandle GetClaim(struct AActor* Owner); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetClaim // (Final|Native|Public|BlueprintCallable) // @ game+0x5f5a740
	struct UAgentOrder* GetBehaviorOrder(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.GetBehaviorOrder // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f58db0
	struct FEmbarkSmartObjectClaimHandle FindSmartObjectWithPredicate(struct FEmbarkSmartObjectRequest& Request, struct FDelegate Predicate); // Function EmbarkAI.EmbarkSmartObjectSubsystem.FindSmartObjectWithPredicate // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f5dc30
	struct FEmbarkSmartObjectClaimHandle FindSmartObject(struct FEmbarkSmartObjectRequest& Request); // Function EmbarkAI.EmbarkSmartObjectSubsystem.FindSmartObject // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f590e0
	struct FEmbarkSmartObjectClaimHandle FindClosestSmartObject(struct FEmbarkSmartObjectRequest& Request); // Function EmbarkAI.EmbarkSmartObjectSubsystem.FindClosestSmartObject // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f590e0
	bool FindAllSmartObjects(struct FEmbarkSmartObjectRequest& Request, struct TArray<struct FEmbarkSmartObjectClaimHandle>& OutResults); // Function EmbarkAI.EmbarkSmartObjectSubsystem.FindAllSmartObjects // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f5aea0
	void DebugDraw(); // Function EmbarkAI.EmbarkSmartObjectSubsystem.DebugDraw // (Final|Native|Public|BlueprintCallable) // @ game+0x5f59e40
	bool Claim(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectSubsystem.Claim // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f593a0
};

// Class EmbarkAI.EmbarkSmartObjectClaimHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkSmartObjectClaimHandleMixinLibrary : UObject {

	bool IsValid(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectClaimHandleMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5f61090
	float GetClaimTime(struct FEmbarkSmartObjectClaimHandle& Handle); // Function EmbarkAI.EmbarkSmartObjectClaimHandleMixinLibrary.GetClaimTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5f642d0
};

