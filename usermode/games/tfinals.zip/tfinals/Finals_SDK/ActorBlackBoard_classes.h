// Class ActorBlackBoard.ActorBlackBoardFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UActorBlackBoardFunctionLibrary : UBlueprintFunctionLibrary {

	void RemoveSpectatingConnection(struct ACharacter* Character, struct UNetConnection* Conn); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.RemoveSpectatingConnection // (Final|Native|Static|Private) // @ game+0x5b60700
	struct UObject* RegisterClassToBlackBoard(struct FBlackBoardVariableDeltaCompressionPtr& BB, struct UObject* Clazz); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.RegisterClassToBlackBoard // (Final|Native|Static|Private|HasOutParms) // @ game+0x5b617d0
	struct UObject* GetFirstStateOfTypeFromBlackBoard(struct FBlackBoardVariableDeltaCompressionPtr& BB, struct UObject* Clazz); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.GetFirstStateOfTypeFromBlackBoard // (Final|Native|Static|Private|HasOutParms) // @ game+0x5b64de0
	struct UObject* EditFirstStateOfTypeFromBlackBoard(struct FBlackBoardVariableDeltaCompressionPtr& BB, struct UObject* Clazz); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.EditFirstStateOfTypeFromBlackBoard // (Final|Native|Static|Private|HasOutParms) // @ game+0x5b61940
	void DirtyStateInBlackBoard(struct FBlackBoardVariableDeltaCompressionPtr& BB, struct USimBaseClass* State); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.DirtyStateInBlackBoard // (Final|Native|Static|Private|HasOutParms) // @ game+0x5b61310
	struct UObject* ASRegisterClassToBlackBoard(struct UObject* BBOwner, struct UObject* Class); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.ASRegisterClassToBlackBoard // (Final|Native|Static|Private) // @ game+0x5b5fc40
	struct UObject* ASGetFirstStateOfTypeFromBlackBoard(struct UObject* BBOwner, struct UObject* Class); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.ASGetFirstStateOfTypeFromBlackBoard // (Final|Native|Static|Private) // @ game+0x5b5dbb0
	struct UObject* ASEditFirstStateOfTypeFromBlackBoard(struct UObject* BBOwner, struct UObject* Class); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.ASEditFirstStateOfTypeFromBlackBoard // (Final|Native|Static|Private) // @ game+0x5b5ffe0
	void ASDirtyStateInBlackBoard(struct UObject* BBOwner, struct USimBaseClass* State); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.ASDirtyStateInBlackBoard // (Final|Native|Static|Private) // @ game+0x5b651e0
	void AddSpectatingConnection(struct ACharacter* Character, struct UNetConnection* Conn); // Function ActorBlackBoard.ActorBlackBoardFunctionLibrary.AddSpectatingConnection // (Final|Native|Static|Private) // @ game+0x5b5f230
};

// Class ActorBlackBoard.ActorBlackBoardOwner
// Size: 0xa0 (Inherited: 0xa0)
struct UActorBlackBoardOwner : UInterface {

	struct UObject* RegisterClassToBlackBoard(struct UObject* Clazz); // Function ActorBlackBoard.ActorBlackBoardOwner.RegisterClassToBlackBoard // (Native|Public) // @ game+0x5b65030
	struct UObject* GetFirstStateOfTypeFromBlackBoard(struct UObject* Clazz); // Function ActorBlackBoard.ActorBlackBoardOwner.GetFirstStateOfTypeFromBlackBoard // (Native|Public) // @ game+0x5b5f7f0
	struct FBlackBoardVariableDeltaCompressionPtr GetDeltaCompressionPtr(); // Function ActorBlackBoard.ActorBlackBoardOwner.GetDeltaCompressionPtr // (Native|Public) // @ game+0x5b65450
	struct UObject* EditFirstStateOfTypeFromBlackBoard(struct UObject* Clazz); // Function ActorBlackBoard.ActorBlackBoardOwner.EditFirstStateOfTypeFromBlackBoard // (Native|Public) // @ game+0x5b5d0d0
	void DirtyStateInBlackBoard(struct USimBaseClass* State); // Function ActorBlackBoard.ActorBlackBoardOwner.DirtyStateInBlackBoard // (Native|Public) // @ game+0x5b622d0
};

// Class ActorBlackBoard.SimBaseClass
// Size: 0xa0 (Inherited: 0xa0)
struct USimBaseClass : UObject {
	char SlotIndexInBlackBoardVariable; // 0x98(0x01)

	char GetSlotIndex(); // Function ActorBlackBoard.SimBaseClass.GetSlotIndex // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x32a8840
	int32_t ExtraAllocatedMemory(); // Function ActorBlackBoard.SimBaseClass.ExtraAllocatedMemory // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2c808c0
};

// Class ActorBlackBoard.SimBaseClassForwarder
// Size: 0xa0 (Inherited: 0xa0)
struct USimBaseClassForwarder : UObject {
};

// Class ActorBlackBoard.ABFloatQuantizationMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABFloatQuantizationMixinLibrary : UObject {

	void SetRange(struct FABFloatQuantization& val, float Min, float Max); // Function ActorBlackBoard.ABFloatQuantizationMixinLibrary.SetRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b63aa0
};

// Class ActorBlackBoard.ABFloatMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABFloatMixinLibrary : UObject {

	void QuantizeValue(struct FABFloat& val); // Function ActorBlackBoard.ABFloatMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b61110
};

// Class ActorBlackBoard.ABBHighCompressedWorldVectorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBHighCompressedWorldVectorMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBHighCompressedWorldVector& val, struct FVector& Vector); // Function ActorBlackBoard.ABBHighCompressedWorldVectorMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b65f90
	void QuantizeValue(struct FABBHighCompressedWorldVector& val); // Function ActorBlackBoard.ABBHighCompressedWorldVectorMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b64a00
};

// Class ActorBlackBoard.ABBLowCompressedWorldVectorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBLowCompressedWorldVectorMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBLowCompressedWorldVector& val, struct FVector& Vector); // Function ActorBlackBoard.ABBLowCompressedWorldVectorMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b60840
	void QuantizeValue(struct FABBLowCompressedWorldVector& val); // Function ActorBlackBoard.ABBLowCompressedWorldVectorMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b64ac0
};

// Class ActorBlackBoard.ABBHighCompressedVectorMaxLen2000MixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBHighCompressedVectorMaxLen2000MixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBHighCompressedVectorMaxLen2000& val, struct FVector& Vector); // Function ActorBlackBoard.ABBHighCompressedVectorMaxLen2000MixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b65e70
	void QuantizeValue(struct FABBHighCompressedVectorMaxLen2000& val); // Function ActorBlackBoard.ABBHighCompressedVectorMaxLen2000MixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5e520
};

// Class ActorBlackBoard.ABBLowCompressedVectorMaxLen2000MixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBLowCompressedVectorMaxLen2000MixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBLowCompressedVectorMaxLen2000& val, struct FVector& Vector); // Function ActorBlackBoard.ABBLowCompressedVectorMaxLen2000MixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b62790
	void QuantizeValue(struct FABBLowCompressedVectorMaxLen2000& val); // Function ActorBlackBoard.ABBLowCompressedVectorMaxLen2000MixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b60220
};

// Class ActorBlackBoard.ABBHighCompressedVectorMaxLen200MixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBHighCompressedVectorMaxLen200MixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBHighCompressedVectorMaxLen200& val, struct FVector& Vector); // Function ActorBlackBoard.ABBHighCompressedVectorMaxLen200MixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b5f9e0
	void QuantizeValue(struct FABBHighCompressedVectorMaxLen200& val); // Function ActorBlackBoard.ABBHighCompressedVectorMaxLen200MixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b64ba0
};

// Class ActorBlackBoard.ABBLowCompressedVectorMaxLen200MixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBLowCompressedVectorMaxLen200MixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBLowCompressedVectorMaxLen200& val, struct FVector& Vector); // Function ActorBlackBoard.ABBLowCompressedVectorMaxLen200MixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b65790
	void QuantizeValue(struct FABBLowCompressedVectorMaxLen200& val); // Function ActorBlackBoard.ABBLowCompressedVectorMaxLen200MixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b625d0
};

// Class ActorBlackBoard.ABBCustomCompressedVectorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBCustomCompressedVectorMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBCustomCompressedVector& val, struct FVector& Vector); // Function ActorBlackBoard.ABBCustomCompressedVectorMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b61c20
	void QuantizeValue(struct FABBCustomCompressedVector& val); // Function ActorBlackBoard.ABBCustomCompressedVectorMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b600e0
};

// Class ActorBlackBoard.ABBHighCompressedQuatMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBHighCompressedQuatMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBHighCompressedQuat& val, struct FQuat& Quat); // Function ActorBlackBoard.ABBHighCompressedQuatMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b62470
	void QuantizeValue(struct FABBHighCompressedQuat& val); // Function ActorBlackBoard.ABBHighCompressedQuatMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5e6e0
};

// Class ActorBlackBoard.ABBLowCompressedQuatMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBLowCompressedQuatMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBLowCompressedQuat& val, struct FQuat& Quat); // Function ActorBlackBoard.ABBLowCompressedQuatMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b5ddf0
	void QuantizeValue(struct FABBLowCompressedQuat& val); // Function ActorBlackBoard.ABBLowCompressedQuatMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b65550
};

// Class ActorBlackBoard.ABBUltraLowCompressedQuatMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBUltraLowCompressedQuatMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBUltraLowCompressedQuat& val, struct FQuat& Quat); // Function ActorBlackBoard.ABBUltraLowCompressedQuatMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b65670
	void QuantizeValue(struct FABBUltraLowCompressedQuat& val); // Function ActorBlackBoard.ABBUltraLowCompressedQuatMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b64ce0
};

// Class ActorBlackBoard.ABBLowCompressedWorldTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBLowCompressedWorldTransformMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBLowCompressedWorldTransform& val, struct FTransform& Transform); // Function ActorBlackBoard.ABBLowCompressedWorldTransformMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b60520
	void QuantizeValue(struct FABBLowCompressedWorldTransform& val); // Function ActorBlackBoard.ABBLowCompressedWorldTransformMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5fe40
};

// Class ActorBlackBoard.ABBHighCompressedWorldTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBHighCompressedWorldTransformMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBHighCompressedWorldTransform& val, struct FTransform& Transform); // Function ActorBlackBoard.ABBHighCompressedWorldTransformMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b61e70
	void QuantizeValue(struct FABBHighCompressedWorldTransform& val); // Function ActorBlackBoard.ABBHighCompressedWorldTransformMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b66550
};

// Class ActorBlackBoard.ABBLowCompressedLocalTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBLowCompressedLocalTransformMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBLowCompressedLocalTransform& val, struct FTransform& Transform); // Function ActorBlackBoard.ABBLowCompressedLocalTransformMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b63710
	void QuantizeValue(struct FABBLowCompressedLocalTransform& val); // Function ActorBlackBoard.ABBLowCompressedLocalTransformMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5e430
};

// Class ActorBlackBoard.ABBHighCompressedLocalTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBHighCompressedLocalTransformMixinLibrary : UObject {

	void SetAndQuantizeValue(struct FABBHighCompressedLocalTransform& val, struct FTransform& Transform); // Function ActorBlackBoard.ABBHighCompressedLocalTransformMixinLibrary.SetAndQuantizeValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b65c90
	void QuantizeValue(struct FABBHighCompressedLocalTransform& val); // Function ActorBlackBoard.ABBHighCompressedLocalTransformMixinLibrary.QuantizeValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b63f90
};

// Class ActorBlackBoard.ABBWeakPtrMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBWeakPtrMixinLibrary : UObject {

	void SetObj(struct FABBWeakPtr& WPObj, struct UObject* Obj); // Function ActorBlackBoard.ABBWeakPtrMixinLibrary.SetObj // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b61000
	struct UObject* GetObj(struct FABBWeakPtr& WPObj); // Function ActorBlackBoard.ABBWeakPtrMixinLibrary.GetObj // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5d1f0
	struct UObject* EditObj(struct FABBWeakPtr& WPObj); // Function ActorBlackBoard.ABBWeakPtrMixinLibrary.EditObj // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5d1f0
};

// Class ActorBlackBoard.ABBWeakConstPtrMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UABBWeakConstPtrMixinLibrary : UObject {

	void SetObject(struct FABBWeakConstPtr& WPObject, struct UObject* Object); // Function ActorBlackBoard.ABBWeakConstPtrMixinLibrary.SetObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b61000
	struct UObject* GetObject(struct FABBWeakConstPtr& WPObject); // Function ActorBlackBoard.ABBWeakConstPtrMixinLibrary.GetObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b5d1f0
};

// Class ActorBlackBoard.ActorBlackBoardSubSystem
// Size: 0x4130 (Inherited: 0xa0)
struct UActorBlackBoardSubSystem : UWorldSubsystem {
	char pad_a0[0x4090]; // 0xa0(0x4090)
};

// Class ActorBlackBoard.ActorBlackBoardTestHoverNetState3
// Size: 0x190 (Inherited: 0xa0)
struct UActorBlackBoardTestHoverNetState3 : USimBaseClass {
	bool BoolA; // 0xa0(0x01)
	bool BoolB; // 0xa1(0x01)
	char pad_a2[0x2]; // 0xa2(0x02)
	struct FABFloat TestFloat; // 0xa4(0x10)
	bool BoolC; // 0xb4(0x01)
	char pad_b5[0x3]; // 0xb5(0x03)
	float MaxLean; // 0xb8(0x04)
	float RotationSpeed; // 0xbc(0x04)
	struct FVector AdditionalForce2; // 0xc0(0x18)
	float YetAnotherFloat; // 0xd8(0x04)
	char pad_dc[0x4]; // 0xdc(0x04)
	struct FVector_NetQuantize VecNetQuantize; // 0xe0(0x18)
	struct FABBLowCompressedWorldVector Test; // 0xf8(0x18)
	struct FABBLowCompressedQuat TestQ; // 0x110(0x20)
	struct FABBLowCompressedWorldTransform TestT; // 0x130(0x60)
};

// Class ActorBlackBoard.ActorBlackBoardTestHoverNetState4
// Size: 0xd0 (Inherited: 0xa0)
struct UActorBlackBoardTestHoverNetState4 : USimBaseClass {
	float MaxLean; // 0xa0(0x04)
	float RotationSpeed; // 0xa4(0x04)
	float YetAnotherFloat; // 0xa8(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
	struct FVector AdditionalForce2; // 0xb0(0x18)
	char pad_c8[0x8]; // 0xc8(0x08)
};

// Class ActorBlackBoard.ActorBlackBoardTestFixedArrayNetTestStruct
// Size: 0x120 (Inherited: 0xa0)
struct UActorBlackBoardTestFixedArrayNetTestStruct : USimBaseClass {
	int32_t MaxLean; // 0xa0(0x04)
	struct FActorBlackBoardTestInternalFixedArrayNetTestStruct TestStruct1[0x3]; // 0xa4(0x3c)
	struct FActorBlackBoardTestInternalFixedArrayNetTestStructWithArray StructWithArray; // 0xe0(0x40)
};

// Class ActorBlackBoard.ActorBlackBoardTestTArrayNetTestStruct
// Size: 0xc0 (Inherited: 0xa0)
struct UActorBlackBoardTestTArrayNetTestStruct : USimBaseClass {
	int32_t MaxLean; // 0xa0(0x04)
	struct FABArraySizeLimiter SizeLimiter; // 0xa4(0x04)
	struct TArray<struct FActorBlackBoardTestInternalFixedArrayNetTestStruct> TestStruct1; // 0xa8(0x10)
	int32_t MaxLean2; // 0xb8(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// Class ActorBlackBoard.ActorBlackBoardTestTArrayNetTestStructOuter
// Size: 0xc0 (Inherited: 0xa0)
struct UActorBlackBoardTestTArrayNetTestStructOuter : USimBaseClass {
	int32_t A; // 0xa0(0x04)
	struct FABArraySizeLimiter SizeLimiter; // 0xa4(0x04)
	struct TArray<struct FActorBlackBoardTestTArrayNetTestStructInner> TestStruct1; // 0xa8(0x10)
	int32_t B; // 0xb8(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// Class ActorBlackBoard.ActorBlackBoardTestOnReps
// Size: 0xc0 (Inherited: 0xa0)
struct UActorBlackBoardTestOnReps : USimBaseClass {
	int32_t A; // 0xa0(0x04)
	struct FABArraySizeLimiter SizeLimiter; // 0xa4(0x04)
	struct TArray<int32_t> TriggeredExplosions; // 0xa8(0x10)
	int32_t ToBeSetByOnRepExpl; // 0xb8(0x04)
	int32_t ToBeSetByOnRepA; // 0xbc(0x04)

	void OnRep_TriggeredExplosions(); // Function ActorBlackBoard.ActorBlackBoardTestOnReps.OnRep_TriggeredExplosions // (Final|Native|Public) // @ game+0x5b6a190
	void OnRep_TriggeredA(); // Function ActorBlackBoard.ActorBlackBoardTestOnReps.OnRep_TriggeredA // (Final|Native|Public) // @ game+0x5b76040
};

// Class ActorBlackBoard.ActorBlackBoardTestInitialization
// Size: 0xb0 (Inherited: 0xa0)
struct UActorBlackBoardTestInitialization : USimBaseClass {
	int32_t A; // 0xa0(0x04)
	int32_t B; // 0xa4(0x04)
	char pad_a8[0x8]; // 0xa8(0x08)

	void InitForActor(struct UObject* Owner); // Function ActorBlackBoard.ActorBlackBoardTestInitialization.InitForActor // (Final|Native|Public) // @ game+0x5b866c0
};

// Class ActorBlackBoard.BlackBoardTesterAS
// Size: 0x25e40 (Inherited: 0xa0)
struct UBlackBoardTesterAS : UObject {
	char pad_a0[0x25da0]; // 0xa0(0x25da0)

	void SetOwnerActor(struct AActor* Obj); // Function ActorBlackBoard.BlackBoardTesterAS.SetOwnerActor // (Final|Native|Public) // @ game+0x5b798d0
	void RemoveStateFromBlackBoard(int32_t SlotIndex); // Function ActorBlackBoard.BlackBoardTesterAS.RemoveStateFromBlackBoard // (Final|Native|Public|BlueprintCallable) // @ game+0x5b715a0
	struct UObject* RegisterClassToServerBlackBoard(struct UObject* Class); // Function ActorBlackBoard.BlackBoardTesterAS.RegisterClassToServerBlackBoard // (Final|Native|Public|BlueprintCallable) // @ game+0x5b68ad0
	void Init(); // Function ActorBlackBoard.BlackBoardTesterAS.Init // (Final|Native|Public) // @ game+0x5b84350
	struct UObject* GetFirstStateOfTypeFromServerBlackBoard(struct UObject* Class); // Function ActorBlackBoard.BlackBoardTesterAS.GetFirstStateOfTypeFromServerBlackBoard // (Final|Native|Public|BlueprintCallable) // @ game+0x5b68ad0
	struct UObject* GetFirstStateOfTypeFromClientBlackBoard(struct UObject* Class); // Function ActorBlackBoard.BlackBoardTesterAS.GetFirstStateOfTypeFromClientBlackBoard // (Final|Native|Public|BlueprintCallable) // @ game+0x5b68ad0
	void FakeTransmit(bool bIsSentToOwner); // Function ActorBlackBoard.BlackBoardTesterAS.FakeTransmit // (Final|Native|Public) // @ game+0x5b71330
	void DirtyState(struct USimBaseClass* State); // Function ActorBlackBoard.BlackBoardTesterAS.DirtyState // (Final|Native|Public) // @ game+0x5b7c430
};

// Class ActorBlackBoard.ActorBlackboardTransformExtension
// Size: 0xa0 (Inherited: 0xa0)
struct UActorBlackboardTransformExtension : UInterface {
};

// Class ActorBlackBoard.ObjectRelativeLocationMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UObjectRelativeLocationMixinLibrary : UObject {

	void SetWorldLocation(struct FObjectRelativeLocation& WPObj, struct FVector& Target); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.SetWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b73550
	void SetObj(struct FObjectRelativeLocation& WPObj, struct UObject* Obj, int32_t PartID); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.SetObj // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b7f150
	void Quantize(struct FObjectRelativeLocation& WPObj); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.Quantize // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b6fd30
	struct FQuat GetWorldOrientation(struct FObjectRelativeLocation& WPObj, struct FQuat& RelativeOrientation); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.GetWorldOrientation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b70d30
	struct FVector GetWorldLocation(struct FObjectRelativeLocation& WPObj); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.GetWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b84250
	struct FQuat GetRelativeOrientation(struct FObjectRelativeLocation& WPObj, struct FQuat& WorldOrientation); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.GetRelativeOrientation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5b688f0
	int32_t GetPartID(struct FObjectRelativeLocation& WPObj); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.GetPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b67710
	struct UObject* GetObj(struct FObjectRelativeLocation& WPObj); // Function ActorBlackBoard.ObjectRelativeLocationMixinLibrary.GetObj // (Final|Native|Static|Public|HasOutParms) // @ game+0x5b69650
};

