// Class MovieRenderPipelineSettings.MoviePipelineBurnInWidget
// Size: 0x350 (Inherited: 0x350)
struct UMoviePipelineBurnInWidget : UUserWidget {

	void OnOutputFrameStarted(struct UMoviePipeline* ForPipeline); // Function MovieRenderPipelineSettings.MoviePipelineBurnInWidget.OnOutputFrameStarted // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class MovieRenderPipelineSettings.MoviePipelineBurnInSetting
// Size: 0x120 (Inherited: 0xc0)
struct UMoviePipelineBurnInSetting : UMoviePipelineRenderPass {
	struct FSoftClassPath BurnInClass; // 0xb8(0x20)
	bool bCompositeOntoFinalImage; // 0xd8(0x01)
	char pad_e1[0x27]; // 0xe1(0x27)
	struct UTextureRenderTarget2D* RenderTarget; // 0x108(0x08)
	struct TArray<struct UMoviePipelineBurnInWidget*> BurnInWidgetInstances; // 0x110(0x10)
};

// Class MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting
// Size: 0x170 (Inherited: 0xc0)
struct UMoviePipelineConsoleVariableSetting : UMoviePipelineSetting {
	struct TArray<struct TScriptInterface<IMovieSceneConsoleVariableTrackInterface>> ConsoleVariablePresets; // 0xb8(0x10)
	struct TMap<struct FString, float> ConsoleVariables; // 0xc8(0x50)
	struct TArray<struct FString> StartConsoleCommands; // 0x118(0x10)
	struct TArray<struct FString> EndConsoleCommands; // 0x128(0x10)
	struct TArray<struct FMoviePipelineConsoleVariableEntry> CVars; // 0x138(0x10)
	char pad_150[0x20]; // 0x150(0x20)

	bool UpdateConsoleVariableEnableState(struct FString Name, bool bIsEnabled); // Function MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting.UpdateConsoleVariableEnableState // (Final|Native|Public|BlueprintCallable) // @ game+0x9be6850
	bool RemoveConsoleVariable(struct FString Name, bool bRemoveAllInstances); // Function MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting.RemoveConsoleVariable // (Final|Native|Public|BlueprintCallable) // @ game+0x9be5a80
	struct TArray<struct FMoviePipelineConsoleVariableEntry> GetConsoleVariables(); // Function MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting.GetConsoleVariables // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9beab00
	bool AddOrUpdateConsoleVariable(struct FString Name, float Value); // Function MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting.AddOrUpdateConsoleVariable // (Final|Native|Public|BlueprintCallable) // @ game+0x9beacb0
	bool AddConsoleVariable(struct FString Name, float Value); // Function MovieRenderPipelineSettings.MoviePipelineConsoleVariableSetting.AddConsoleVariable // (Final|Native|Public|BlueprintCallable) // @ game+0x9beaf50
};

// Class MovieRenderPipelineSettings.MoviePipelineWidgetRenderer
// Size: 0xe0 (Inherited: 0xc0)
struct UMoviePipelineWidgetRenderer : UMoviePipelineRenderPass {
	bool bCompositeOntoFinalImage; // 0xb8(0x01)
	char pad_c1[0xf]; // 0xc1(0x0f)
	struct UTextureRenderTarget2D* RenderTarget; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)
};

