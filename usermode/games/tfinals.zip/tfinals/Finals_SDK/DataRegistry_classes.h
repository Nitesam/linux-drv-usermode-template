// Class DataRegistry.DataRegistrySettings
// Size: 0xc0 (Inherited: 0xb0)
struct UDataRegistrySettings : UDeveloperSettings {
	struct TArray<struct FDirectoryPath> DirectoriesToScan; // 0xa8(0x10)
	bool bInitializeAllLoadedRegistries; // 0xb8(0x01)
	bool bIgnoreMissingCookedAssetRegistryData; // 0xb9(0x01)
};

// Class DataRegistry.DataRegistry
// Size: 0x130 (Inherited: 0xa0)
struct UDataRegistry : UObject {
	struct FName RegistryType; // 0x98(0x08)
	struct FDataRegistryIdFormat IdFormat; // 0xa0(0x08)
	struct UScriptStruct* ItemStruct; // 0xa8(0x08)
	struct TArray<struct UDataRegistrySource*> DataSources; // 0xb0(0x10)
	struct TArray<struct UDataRegistrySource*> RuntimeSources; // 0xc0(0x10)
	float TimerUpdateFrequency; // 0xd0(0x04)
	struct FDataRegistryCachePolicy DefaultCachePolicy; // 0xd4(0x14)
	char pad_f0[0x40]; // 0xf0(0x40)
};

// Class DataRegistry.DataRegistrySource
// Size: 0xb0 (Inherited: 0xa0)
struct UDataRegistrySource : UObject {
	struct UDataRegistrySource* ParentSource; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class DataRegistry.MetaDataRegistrySource
// Size: 0x180 (Inherited: 0xb0)
struct UMetaDataRegistrySource : UDataRegistrySource {
	enum class EMetaDataRegistrySourceAssetUsage AssetUsage; // 0xa8(0x01)
	struct FAssetManagerSearchRules SearchRules; // 0xb0(0x50)
	struct TMap<struct FName, struct UDataRegistrySource*> RuntimeChildren; // 0x100(0x50)
	char pad_151[0x2f]; // 0x151(0x2f)
};

// Class DataRegistry.DataRegistrySource_CurveTable
// Size: 0x110 (Inherited: 0xb0)
struct UDataRegistrySource_CurveTable : UDataRegistrySource {
	struct TSoftObjectPtr<UCurveTable> SourceTable; // 0xa8(0x28)
	struct FDataRegistrySource_DataTableRules TableRules; // 0xd0(0x08)
	struct UCurveTable* CachedTable; // 0xd8(0x08)
	struct UCurveTable* PreloadTable; // 0xe0(0x08)
	char pad_f0[0x20]; // 0xf0(0x20)
};

// Class DataRegistry.MetaDataRegistrySource_CurveTable
// Size: 0x190 (Inherited: 0x180)
struct UMetaDataRegistrySource_CurveTable : UMetaDataRegistrySource {
	struct UDataRegistrySource_CurveTable* CreatedSource; // 0x178(0x08)
	struct FDataRegistrySource_DataTableRules TableRules; // 0x180(0x08)
};

// Class DataRegistry.DataRegistrySource_DataTable
// Size: 0x110 (Inherited: 0xb0)
struct UDataRegistrySource_DataTable : UDataRegistrySource {
	struct TSoftObjectPtr<UDataTable> SourceTable; // 0xa8(0x28)
	struct FDataRegistrySource_DataTableRules TableRules; // 0xd0(0x08)
	struct UDataTable* CachedTable; // 0xd8(0x08)
	struct UDataTable* PreloadTable; // 0xe0(0x08)
	char pad_f0[0x20]; // 0xf0(0x20)
};

// Class DataRegistry.MetaDataRegistrySource_DataTable
// Size: 0x190 (Inherited: 0x180)
struct UMetaDataRegistrySource_DataTable : UMetaDataRegistrySource {
	struct UDataRegistrySource_DataTable* CreatedSource; // 0x178(0x08)
	struct FDataRegistrySource_DataTableRules TableRules; // 0x180(0x08)
};

// Class DataRegistry.DataRegistrySubsystem
// Size: 0x140 (Inherited: 0xa0)
struct UDataRegistrySubsystem : UEngineSubsystem {
	char pad_a0[0xa0]; // 0xa0(0xa0)

	bool NotEqual_DataRegistryType(struct FDataRegistryType A, struct FDataRegistryType B); // Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b0a820
	bool NotEqual_DataRegistryId(struct FDataRegistryId A, struct FDataRegistryId B); // Function DataRegistry.DataRegistrySubsystem.NotEqual_DataRegistryId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x336da70
	bool IsValidDataRegistryType(struct FDataRegistryType DataRegistryType); // Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b04f90
	bool IsValidDataRegistryId(struct FDataRegistryId DataRegistryId); // Function DataRegistry.DataRegistrySubsystem.IsValidDataRegistryId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3377060
	bool GetCachedItemFromLookupBP(struct FDataRegistryId ItemId, struct FDataRegistryLookup& ResolvedLookup, struct FTableRowBase& OutItem); // Function DataRegistry.DataRegistrySubsystem.GetCachedItemFromLookupBP // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4e37a00
	bool GetCachedItemBP(struct FDataRegistryId ItemId, struct FTableRowBase& OutItem); // Function DataRegistry.DataRegistrySubsystem.GetCachedItemBP // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4e354b0
	void FindCachedItemBP(struct FDataRegistryId ItemId, enum class EDataRegistrySubsystemGetItemResult& OutResult, struct FTableRowBase& OutItem); // Function DataRegistry.DataRegistrySubsystem.FindCachedItemBP // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4e30c40
	void EvaluateDataRegistryCurve(struct FDataRegistryId ItemId, float InputValue, float DefaultValue, enum class EDataRegistrySubsystemGetItemResult& OutResult, float& OutValue); // Function DataRegistry.DataRegistrySubsystem.EvaluateDataRegistryCurve // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4e40750
	bool EqualEqual_DataRegistryType(struct FDataRegistryType A, struct FDataRegistryType B); // Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2afee00
	bool EqualEqual_DataRegistryId(struct FDataRegistryId A, struct FDataRegistryId B); // Function DataRegistry.DataRegistrySubsystem.EqualEqual_DataRegistryId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x33d2790
	struct FString Conv_DataRegistryTypeToString(struct FDataRegistryType DataRegistryType); // Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryTypeToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b017f0
	struct FString Conv_DataRegistryIdToString(struct FDataRegistryId DataRegistryId); // Function DataRegistry.DataRegistrySubsystem.Conv_DataRegistryIdToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4e37920
	bool AcquireItemBP(struct FDataRegistryId ItemId, struct FDelegate AcquireCallback); // Function DataRegistry.DataRegistrySubsystem.AcquireItemBP // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4e34810
};

