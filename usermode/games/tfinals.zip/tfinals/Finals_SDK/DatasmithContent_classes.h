// Class DatasmithContent.DatasmithObjectTemplate
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithObjectTemplate : UObject {
};

// Class DatasmithContent.DatasmithActorTemplate
// Size: 0x140 (Inherited: 0xa0)
struct UDatasmithActorTemplate : UDatasmithObjectTemplate {
	struct TSet<struct FName> Layers; // 0xa0(0x50)
	struct TSet<struct FName> Tags; // 0xf0(0x50)
};

// Class DatasmithContent.DatasmithAdditionalData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithAdditionalData : UObject {
};

// Class DatasmithContent.DatasmithAreaLightActor
// Size: 0x410 (Inherited: 0x3a0)
struct ADatasmithAreaLightActor : AActor {
	enum class EComponentMobility Mobility; // 0x398(0x01)
	enum class EDatasmithAreaLightActorType LightType; // 0x399(0x01)
	enum class EDatasmithAreaLightActorShape LightShape; // 0x39a(0x01)
	struct FVector2D Dimensions; // 0x3a0(0x10)
	float Intensity; // 0x3b0(0x04)
	enum class ELightUnits IntensityUnits; // 0x3b4(0x01)
	struct FLinearColor Color; // 0x3b8(0x10)
	float Temperature; // 0x3c8(0x04)
	char pad_3cc[0x4]; // 0x3cc(0x04)
	struct UTextureLightProfile* IESTexture; // 0x3d0(0x08)
	bool bUseIESBrightness; // 0x3d8(0x01)
	char pad_3d9[0x3]; // 0x3d9(0x03)
	float IESBrightnessScale; // 0x3dc(0x04)
	struct FRotator Rotation; // 0x3e0(0x18)
	float SourceRadius; // 0x3f8(0x04)
	float SourceLength; // 0x3fc(0x04)
	float AttenuationRadius; // 0x400(0x04)
	float SpotlightInnerAngle; // 0x404(0x04)
	float SpotlightOuterAngle; // 0x408(0x04)
	char pad_40c[0x4]; // 0x40c(0x04)
};

// Class DatasmithContent.DatasmithAreaLightActorTemplate
// Size: 0x130 (Inherited: 0xa0)
struct UDatasmithAreaLightActorTemplate : UDatasmithObjectTemplate {
	enum class EDatasmithAreaLightActorType LightType; // 0xa0(0x01)
	enum class EDatasmithAreaLightActorShape LightShape; // 0xa1(0x01)
	char pad_a2[0x6]; // 0xa2(0x06)
	struct FVector2D Dimensions; // 0xa8(0x10)
	struct FLinearColor Color; // 0xb8(0x10)
	float Intensity; // 0xc8(0x04)
	enum class ELightUnits IntensityUnits; // 0xcc(0x01)
	char pad_cd[0x3]; // 0xcd(0x03)
	float Temperature; // 0xd0(0x04)
	char pad_d4[0x4]; // 0xd4(0x04)
	struct TSoftObjectPtr<UTextureLightProfile> IESTexture; // 0xd8(0x28)
	bool bUseIESBrightness; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	float IESBrightnessScale; // 0x104(0x04)
	struct FRotator Rotation; // 0x108(0x18)
	float SourceRadius; // 0x120(0x04)
	float SourceLength; // 0x124(0x04)
	float AttenuationRadius; // 0x128(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)
};

// Class DatasmithContent.DatasmithAssetImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithAssetImportData : UAssetImportData {
};

// Class DatasmithContent.DatasmithStaticMeshImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithStaticMeshImportData : UDatasmithAssetImportData {
};

// Class DatasmithContent.DatasmithStaticMeshCADImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithStaticMeshCADImportData : UDatasmithStaticMeshImportData {
};

// Class DatasmithContent.DatasmithSceneImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithSceneImportData : UAssetImportData {
};

// Class DatasmithContent.DatasmithTranslatedSceneImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithTranslatedSceneImportData : UDatasmithSceneImportData {
};

// Class DatasmithContent.DatasmithCADImportSceneData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithCADImportSceneData : UDatasmithSceneImportData {
};

// Class DatasmithContent.DatasmithMDLSceneImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithMDLSceneImportData : UDatasmithSceneImportData {
};

// Class DatasmithContent.DatasmithGLTFSceneImportData
// Size: 0xe0 (Inherited: 0xa0)
struct UDatasmithGLTFSceneImportData : UDatasmithSceneImportData {
	struct FString Generator; // 0x98(0x10)
	float Version; // 0xa8(0x04)
	struct FString Author; // 0xb0(0x10)
	struct FString License; // 0xc0(0x10)
	struct FString Source; // 0xd0(0x10)
};

// Class DatasmithContent.DatasmithStaticMeshGLTFImportData
// Size: 0xb0 (Inherited: 0xa0)
struct UDatasmithStaticMeshGLTFImportData : UDatasmithStaticMeshImportData {
	struct FString SourceMeshName; // 0x98(0x10)
};

// Class DatasmithContent.DatasmithFBXSceneImportData
// Size: 0xc0 (Inherited: 0xa0)
struct UDatasmithFBXSceneImportData : UDatasmithSceneImportData {
	bool bGenerateLightmapUVs; // 0x98(0x01)
	struct FString TexturesDir; // 0xa0(0x10)
	char IntermediateSerialization; // 0xb0(0x01)
	bool bColorizeMaterials; // 0xb1(0x01)
	char pad_b3[0xd]; // 0xb3(0x0d)
};

// Class DatasmithContent.DatasmithDeltaGenAssetImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithDeltaGenAssetImportData : UDatasmithAssetImportData {
};

// Class DatasmithContent.DatasmithDeltaGenSceneImportData
// Size: 0x100 (Inherited: 0xc0)
struct UDatasmithDeltaGenSceneImportData : UDatasmithFBXSceneImportData {
	bool bMergeNodes; // 0xb8(0x01)
	bool bOptimizeDuplicatedNodes; // 0xb9(0x01)
	bool bRemoveInvisibleNodes; // 0xba(0x01)
	bool bSimplifyNodeHierarchy; // 0xbb(0x01)
	bool bImportVar; // 0xbc(0x01)
	struct FString VarPath; // 0xc0(0x10)
	bool bImportPos; // 0xd0(0x01)
	char pad_d6[0x2]; // 0xd6(0x02)
	struct FString PosPath; // 0xd8(0x10)
	bool bImportTml; // 0xe8(0x01)
	char pad_e9[0x7]; // 0xe9(0x07)
	struct FString TmlPath; // 0xf0(0x10)
};

// Class DatasmithContent.DatasmithVREDAssetImportData
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithVREDAssetImportData : UDatasmithAssetImportData {
};

// Class DatasmithContent.DatasmithVREDSceneImportData
// Size: 0x120 (Inherited: 0xc0)
struct UDatasmithVREDSceneImportData : UDatasmithFBXSceneImportData {
	bool bMergeNodes; // 0xb8(0x01)
	bool bOptimizeDuplicatedNodes; // 0xb9(0x01)
	bool bImportMats; // 0xba(0x01)
	struct FString MatsPath; // 0xc0(0x10)
	bool bImportVar; // 0xd0(0x01)
	bool bCleanVar; // 0xd1(0x01)
	char pad_d5[0x3]; // 0xd5(0x03)
	struct FString VarPath; // 0xd8(0x10)
	bool bImportLightInfo; // 0xe8(0x01)
	char pad_e9[0x7]; // 0xe9(0x07)
	struct FString LightInfoPath; // 0xf0(0x10)
	bool bImportClipInfo; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FString ClipInfoPath; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// Class DatasmithContent.DatasmithAssetUserData
// Size: 0xf0 (Inherited: 0xa0)
struct UDatasmithAssetUserData : UAssetUserData {
	struct TMap<struct FName, struct FString> MetaData; // 0x98(0x50)
};

// Class DatasmithContent.DatasmithCineCameraActorTemplate
// Size: 0xd0 (Inherited: 0xa0)
struct UDatasmithCineCameraActorTemplate : UDatasmithObjectTemplate {
	struct FDatasmithCameraLookatTrackingSettingsTemplate LookatTrackingSettings; // 0xa0(0x30)
};

// Class DatasmithContent.DatasmithCineCameraComponentTemplate
// Size: 0x100 (Inherited: 0xa0)
struct UDatasmithCineCameraComponentTemplate : UDatasmithObjectTemplate {
	struct FDatasmithCameraFilmbackSettingsTemplate FilmbackSettings; // 0xa0(0x08)
	struct FDatasmithCameraLensSettingsTemplate LensSettings; // 0xa8(0x04)
	struct FDatasmithCameraFocusSettingsTemplate FocusSettings; // 0xac(0x08)
	float CurrentFocalLength; // 0xb4(0x04)
	float CurrentAperture; // 0xb8(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
	struct FDatasmithPostProcessSettingsTemplate PostProcessSettings; // 0xc0(0x40)
};

// Class DatasmithContent.DatasmithContentBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithContentBlueprintLibrary : UBlueprintFunctionLibrary {

	struct TArray<struct FString> GetDatasmithUserDataValuesForKey(struct UObject* Object, struct FName Key, bool bPartialMatchKey); // Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataValuesForKey // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x97ca760
	struct FString GetDatasmithUserDataValueForKey(struct UObject* Object, struct FName Key, bool bPartialMatchKey); // Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataValueForKey // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x97cabb0
	void GetDatasmithUserDataKeysAndValuesForValue(struct UObject* Object, struct FString StringToMatch, struct TArray<struct FName>& OutKeys, struct TArray<struct FString>& OutValues); // Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserDataKeysAndValuesForValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x97ca420
	struct UDatasmithAssetUserData* GetDatasmithUserData(struct UObject* Object); // Function DatasmithContent.DatasmithContentBlueprintLibrary.GetDatasmithUserData // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x97c8770
};

// Class DatasmithContent.DatasmithCustomActionBase
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithCustomActionBase : UObject {
};

// Class DatasmithContent.DatasmithDecalComponentTemplate
// Size: 0xd0 (Inherited: 0xa0)
struct UDatasmithDecalComponentTemplate : UDatasmithObjectTemplate {
	int32_t SortOrder; // 0xa0(0x04)
	char pad_a4[0x4]; // 0xa4(0x04)
	struct FVector DecalSize; // 0xa8(0x18)
	struct UMaterialInterface* Material; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)
};

// Class DatasmithContent.DatasmithImportedSequencesActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ADatasmithImportedSequencesActor : AActor {
	struct TArray<struct ULevelSequence*> ImportedSequences; // 0x398(0x10)

	void PlayLevelSequence(struct ULevelSequence* SequenceToPlay); // Function DatasmithContent.DatasmithImportedSequencesActor.PlayLevelSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x2424450
};

// Class DatasmithContent.DatasmithOptionsBase
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithOptionsBase : UObject {
};

// Class DatasmithContent.DatasmithCommonTessellationOptions
// Size: 0xb0 (Inherited: 0xa0)
struct UDatasmithCommonTessellationOptions : UDatasmithOptionsBase {
	struct FDatasmithTessellationOptions Options; // 0x98(0x10)
};

// Class DatasmithContent.DatasmithImportOptions
// Size: 0x100 (Inherited: 0xa0)
struct UDatasmithImportOptions : UDatasmithOptionsBase {
	enum class EDatasmithImportSearchPackagePolicy SearchPackagePolicy; // 0x98(0x01)
	enum class EDatasmithImportAssetConflictPolicy MaterialConflictPolicy; // 0x99(0x01)
	enum class EDatasmithImportAssetConflictPolicy TextureConflictPolicy; // 0x9a(0x01)
	enum class EDatasmithImportActorPolicy StaticMeshActorImportPolicy; // 0x9b(0x01)
	enum class EDatasmithImportActorPolicy LightImportPolicy; // 0x9c(0x01)
	enum class EDatasmithImportActorPolicy CameraImportPolicy; // 0x9d(0x01)
	enum class EDatasmithImportActorPolicy OtherActorImportPolicy; // 0x9e(0x01)
	enum class EDatasmithImportMaterialQuality MaterialQuality; // 0x9f(0x01)
	struct FDatasmithImportBaseOptions BaseOptions; // 0xa0(0x14)
	struct FDatasmithReimportOptions ReimportOptions; // 0xb4(0x02)
	struct FString Filename; // 0xb8(0x10)
	struct FString FilePath; // 0xc8(0x10)
	struct FString SourceUri; // 0xd8(0x10)
	char pad_ee[0x12]; // 0xee(0x12)
};

// Class DatasmithContent.DatasmithLandscapeTemplate
// Size: 0xb0 (Inherited: 0xa0)
struct UDatasmithLandscapeTemplate : UDatasmithObjectTemplate {
	struct UMaterialInterface* LandscapeMaterial; // 0xa0(0x08)
	int32_t StaticLightingLOD; // 0xa8(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
};

// Class DatasmithContent.DatasmithLightComponentTemplate
// Size: 0xe0 (Inherited: 0xa0)
struct UDatasmithLightComponentTemplate : UDatasmithObjectTemplate {
	char bVisible : 1; // 0xa0(0x01)
	char pad_a0_1 : 7; // 0xa0(0x01)
	char pad_a1[0x3]; // 0xa1(0x03)
	char CastShadows : 1; // 0xa4(0x01)
	char bUseTemperature : 1; // 0xa4(0x01)
	char bUseIESBrightness : 1; // 0xa4(0x01)
	char pad_a4_3 : 5; // 0xa4(0x01)
	char pad_a5[0x3]; // 0xa5(0x03)
	float Intensity; // 0xa8(0x04)
	float Temperature; // 0xac(0x04)
	float IESBrightnessScale; // 0xb0(0x04)
	struct FLinearColor LightColor; // 0xb4(0x10)
	char pad_c4[0x4]; // 0xc4(0x04)
	struct UMaterialInterface* LightFunctionMaterial; // 0xc8(0x08)
	struct UTextureLightProfile* IESTexture; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class DatasmithContent.DatasmithMaterialInstanceTemplate
// Size: 0x210 (Inherited: 0xa0)
struct UDatasmithMaterialInstanceTemplate : UDatasmithObjectTemplate {
	struct TSoftObjectPtr<UMaterialInterface> ParentMaterial; // 0xa0(0x28)
	struct TMap<struct FName, float> ScalarParameterValues; // 0xc8(0x50)
	struct TMap<struct FName, struct FLinearColor> VectorParameterValues; // 0x118(0x50)
	struct TMap<struct FName, struct TSoftObjectPtr<UTexture>> TextureParameterValues; // 0x168(0x50)
	struct FDatasmithStaticParameterSetTemplate StaticParameters; // 0x1b8(0x50)
	char pad_208[0x8]; // 0x208(0x08)
};

// Class DatasmithContent.DatasmithPointLightComponentTemplate
// Size: 0xb0 (Inherited: 0xa0)
struct UDatasmithPointLightComponentTemplate : UDatasmithObjectTemplate {
	enum class ELightUnits IntensityUnits; // 0xa0(0x01)
	char pad_a1[0x3]; // 0xa1(0x03)
	float SourceRadius; // 0xa4(0x04)
	float SourceLength; // 0xa8(0x04)
	float AttenuationRadius; // 0xac(0x04)
};

// Class DatasmithContent.DatasmithPostProcessVolumeTemplate
// Size: 0xf0 (Inherited: 0xa0)
struct UDatasmithPostProcessVolumeTemplate : UDatasmithObjectTemplate {
	struct FDatasmithPostProcessSettingsTemplate Settings; // 0xa0(0x40)
	char bEnabled : 1; // 0xe0(0x01)
	char bUnbound : 1; // 0xe0(0x01)
	char pad_e0_2 : 6; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class DatasmithContent.DatasmithScene
// Size: 0xa0 (Inherited: 0xa0)
struct UDatasmithScene : UObject {
};

// Class DatasmithContent.DatasmithSceneActor
// Size: 0x3f0 (Inherited: 0x3a0)
struct ADatasmithSceneActor : AActor {
	struct UDatasmithScene* Scene; // 0x398(0x08)
	struct TMap<struct FName, struct TSoftObjectPtr<AActor>> RelatedActors; // 0x3a0(0x50)
};

// Class DatasmithContent.DatasmithSceneComponentTemplate
// Size: 0x190 (Inherited: 0xa0)
struct UDatasmithSceneComponentTemplate : UDatasmithObjectTemplate {
	struct FTransform RelativeTransform; // 0xa0(0x60)
	enum class EComponentMobility Mobility; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct TSoftObjectPtr<USceneComponent> AttachParent; // 0x108(0x28)
	bool bVisible; // 0x130(0x01)
	bool bCastShadow; // 0x131(0x01)
	char pad_132[0x6]; // 0x132(0x06)
	struct TSet<struct FName> Tags; // 0x138(0x50)
	char pad_188[0x8]; // 0x188(0x08)
};

// Class DatasmithContent.DatasmithSkyLightComponentTemplate
// Size: 0xb0 (Inherited: 0xa0)
struct UDatasmithSkyLightComponentTemplate : UDatasmithObjectTemplate {
	enum class ESkyLightSourceType SourceType; // 0xa0(0x01)
	char pad_a1[0x3]; // 0xa1(0x03)
	int32_t CubemapResolution; // 0xa4(0x04)
	struct UTextureCube* Cubemap; // 0xa8(0x08)
};

// Class DatasmithContent.DatasmithSpotLightComponentTemplate
// Size: 0xb0 (Inherited: 0xa0)
struct UDatasmithSpotLightComponentTemplate : UDatasmithObjectTemplate {
	float InnerConeAngle; // 0xa0(0x04)
	float OuterConeAngle; // 0xa4(0x04)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class DatasmithContent.DatasmithStaticMeshComponentTemplate
// Size: 0xc0 (Inherited: 0xa0)
struct UDatasmithStaticMeshComponentTemplate : UDatasmithObjectTemplate {
	struct UStaticMesh* StaticMesh; // 0xa0(0x08)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0xa8(0x10)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class DatasmithContent.DatasmithStaticMeshTemplate
// Size: 0x120 (Inherited: 0xa0)
struct UDatasmithStaticMeshTemplate : UDatasmithObjectTemplate {
	struct FDatasmithMeshSectionInfoMapTemplate SectionInfoMap; // 0xa0(0x50)
	int32_t LightMapCoordinateIndex; // 0xf0(0x04)
	int32_t LightMapResolution; // 0xf4(0x04)
	struct TArray<struct FDatasmithMeshBuildSettingsTemplate> BuildSettings; // 0xf8(0x10)
	struct TArray<struct FDatasmithStaticMaterialTemplate> StaticMaterials; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

