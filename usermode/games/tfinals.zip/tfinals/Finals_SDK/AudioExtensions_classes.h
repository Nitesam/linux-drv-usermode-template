// Class AudioExtensions.SpatializationPluginSourceSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct USpatializationPluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.SourceDataOverridePluginSourceSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct USourceDataOverridePluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.OcclusionPluginSourceSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct UOcclusionPluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.ReverbPluginSourceSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct UReverbPluginSourceSettingsBase : UObject {
};

// Class AudioExtensions.AudioParameterControllerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioParameterControllerInterface : UInterface {

	void SetTriggerParameter(struct FName InName); // Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter // (Native|Public|BlueprintCallable) // @ game+0x1525060
	void SetStringParameter(struct FName InName, struct FString InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter // (Native|Public|BlueprintCallable) // @ game+0x1524e30
	void SetStringArrayParameter(struct FName InName, struct TArray<struct FString>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x15279c0
	void SetParameters_Blueprint(struct TArray<struct FAudioParameter>& InParameters); // Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1527c80
	void SetObjectParameter(struct FName InName, struct UObject* InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter // (Native|Public|BlueprintCallable) // @ game+0x15286f0
	void SetObjectArrayParameter(struct FName InName, struct TArray<struct UObject*>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x151d3a0
	void SetIntParameter(struct FName InName, int32_t inInt); // Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter // (Native|Public|BlueprintCallable) // @ game+0x1521a80
	void SetIntArrayParameter(struct FName InName, struct TArray<int32_t>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1525260
	void SetFloatParameter(struct FName InName, float InFloat); // Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter // (Native|Public|BlueprintCallable) // @ game+0x151e170
	void SetFloatArrayParameter(struct FName InName, struct TArray<float>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x151f770
	void SetBoolParameter(struct FName InName, bool InBool); // Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter // (Native|Public|BlueprintCallable) // @ game+0x1520db0
	void SetBoolArrayParameter(struct FName InName, struct TArray<bool>& InValue); // Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x151dad0
	void ResetParameters(); // Function AudioExtensions.AudioParameterControllerInterface.ResetParameters // (Native|Public|BlueprintCallable) // @ game+0x1520a60
};

// Class AudioExtensions.AudioCodecEncoderSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioCodecEncoderSettings : UObject {
	int32_t Version; // 0x98(0x04)
};

// Class AudioExtensions.AudioEndpointSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioEndpointSettingsBase : UObject {
};

// Class AudioExtensions.DummyEndpointSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UDummyEndpointSettings : UAudioEndpointSettingsBase {
};

// Class AudioExtensions.SoundModulatorBase
// Size: 0xa0 (Inherited: 0xa0)
struct USoundModulatorBase : UObject {
};

// Class AudioExtensions.SoundfieldEndpointSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct USoundfieldEndpointSettingsBase : UObject {
};

// Class AudioExtensions.SoundfieldEncodingSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct USoundfieldEncodingSettingsBase : UObject {
};

// Class AudioExtensions.SoundfieldEffectSettingsBase
// Size: 0xa0 (Inherited: 0xa0)
struct USoundfieldEffectSettingsBase : UObject {
};

// Class AudioExtensions.SoundfieldEffectBase
// Size: 0xa0 (Inherited: 0xa0)
struct USoundfieldEffectBase : UObject {
	struct USoundfieldEffectSettingsBase* Settings; // 0x98(0x08)
};

// Class AudioExtensions.WaveformTransformationBase
// Size: 0xa0 (Inherited: 0xa0)
struct UWaveformTransformationBase : UObject {
};

// Class AudioExtensions.WaveformTransformationChain
// Size: 0xb0 (Inherited: 0xa0)
struct UWaveformTransformationChain : UObject {
	struct TArray<struct UWaveformTransformationBase*> Transformations; // 0x98(0x10)
};

