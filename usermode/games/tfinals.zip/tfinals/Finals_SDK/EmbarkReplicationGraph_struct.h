// Enum EmbarkReplicationGraph.EClassReplicationPolicy
enum class EClassReplicationPolicy : uint8_t {
	None = 0,
	AlwaysRelevant = 1,
	AlwaysRelevantPerConnection = 2,
	SpatializeStatic = 3,
	SpatializeDynamic = 4,
	EClassReplicationPolicy_MAX = 5
};

// ScriptStruct EmbarkReplicationGraph.ConnectionAlwaysRelevantPair
// Size: 0x10 (Inherited: 0x00)
struct FConnectionAlwaysRelevantPair {
	struct UNetConnection* NetConnection; // 0x00(0x08)
	struct UReplicationGraphNode_AlwaysRelevant_ForConnection* Node; // 0x08(0x08)
};

// ScriptStruct EmbarkReplicationGraph.EmbarkSortedActorReplicationEntry
// Size: 0x1c (Inherited: 0x00)
struct FEmbarkSortedActorReplicationEntry {
	struct TWeakObjectPtr<struct AActor> Actor; // 0x00(0x08)
	float DistanceSq; // 0x08(0x04)
	float DotProduct; // 0x0c(0x04)
	float Score; // 0x10(0x04)
	int32_t Index; // 0x14(0x04)
	int32_t ReplicationFrameNum; // 0x18(0x04)
};

// ScriptStruct EmbarkReplicationGraph.EmbarkSortedRelevantActorsArrayWrapperEntry
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkSortedRelevantActorsArrayWrapperEntry {
	char pad_0[0x10]; // 0x00(0x10)
};

