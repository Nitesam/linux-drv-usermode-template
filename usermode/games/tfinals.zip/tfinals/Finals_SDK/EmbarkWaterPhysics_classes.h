// Class EmbarkWaterPhysics.EmbarkWaterPhysics
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWaterPhysics : UObject {

	void SubdivideWaterBodyMesh(struct FEmbarkWaterBodyMesh& InWaterBodyMesh, int32_t SubdivisionLevels); // Function EmbarkWaterPhysics.EmbarkWaterPhysics.SubdivideWaterBodyMesh // (Final|Native|Static|Public|HasOutParms) // @ game+0x696f330
	void SolveWaterPhysics(struct TArray<struct FEmbarkWaterPhysicsBody>& WaterPhysicsBodies, float DeltaTime, struct FVector Gravity, struct UWorld* DebugDrawWorld); // Function EmbarkWaterPhysics.EmbarkWaterPhysics.SolveWaterPhysics // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x69714b0
	struct FEmbarkWaterPhysicsSettings MergeWaterPhysicsSettings(struct FEmbarkWaterPhysicsSettings& DefaultSettings, struct FEmbarkWaterPhysicsSettings& OverrideSettings); // Function EmbarkWaterPhysics.EmbarkWaterPhysics.MergeWaterPhysicsSettings // (Final|Native|Static|Public|HasOutParms) // @ game+0x696c520
	void AddWaterForceToPrimitive(struct UPrimitiveComponent* PrimitiveComponent, struct FEmbarkWaterPhysicsForce& Force, struct FName BoneName, bool bAccelChange); // Function EmbarkWaterPhysics.EmbarkWaterPhysics.AddWaterForceToPrimitive // (Final|Native|Static|Public|HasOutParms) // @ game+0x696c740
};

