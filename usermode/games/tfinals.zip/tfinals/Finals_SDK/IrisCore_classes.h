// Class IrisCore.DataStream
// Size: 0xa0 (Inherited: 0xa0)
struct UDataStream : UObject {
};

// Class IrisCore.DataStreamDefinitions
// Size: 0xb0 (Inherited: 0xa0)
struct UDataStreamDefinitions : UObject {
	struct TArray<struct FDataStreamDefinition> DataStreamDefinitions; // 0x98(0x10)
};

// Class IrisCore.DataStreamManager
// Size: 0xa0 (Inherited: 0xa0)
struct UDataStreamManager : UDataStream {
};

// Class IrisCore.NetObjectFilterConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UNetObjectFilterConfig : UObject {
	enum class ENetFilterType FilterType; // 0x98(0x01)
};

// Class IrisCore.FilterOutNetObjectFilterConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UFilterOutNetObjectFilterConfig : UNetObjectFilterConfig {
};

// Class IrisCore.NetObjectFilter
// Size: 0xc0 (Inherited: 0xa0)
struct UNetObjectFilter : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class IrisCore.FilterOutNetObjectFilter
// Size: 0xc0 (Inherited: 0xc0)
struct UFilterOutNetObjectFilter : UNetObjectFilter {
};

// Class IrisCore.IrisObjectReferencePackageMap
// Size: 0x160 (Inherited: 0x150)
struct UIrisObjectReferencePackageMap : UPackageMap {
	char pad_150[0x10]; // 0x150(0x10)
};

// Class IrisCore.NetObjectPrioritizer
// Size: 0xa0 (Inherited: 0xa0)
struct UNetObjectPrioritizer : UObject {
};

// Class IrisCore.LocationBasedNetObjectPrioritizer
// Size: 0xd0 (Inherited: 0xa0)
struct ULocationBasedNetObjectPrioritizer : UNetObjectPrioritizer {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class IrisCore.NetBlobHandler
// Size: 0xb0 (Inherited: 0xa0)
struct UNetBlobHandler : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class IrisCore.NetBlobHandlerDefinitions
// Size: 0xb0 (Inherited: 0xa0)
struct UNetBlobHandlerDefinitions : UObject {
	struct TArray<struct FNetBlobHandlerDefinition> NetBlobHandlerDefinitions; // 0x98(0x10)
};

// Class IrisCore.NetObjectBlobHandler
// Size: 0xb0 (Inherited: 0xb0)
struct UNetObjectBlobHandler : UNetBlobHandler {
};

// Class IrisCore.NetObjectConnectionFilterConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UNetObjectConnectionFilterConfig : UNetObjectFilterConfig {
	uint16_t MaxObjectCount; // 0xa0(0x02)
	char pad_a2[0xe]; // 0xa2(0x0e)
};

// Class IrisCore.NetObjectConnectionFilter
// Size: 0x110 (Inherited: 0xc0)
struct UNetObjectConnectionFilter : UNetObjectFilter {
	char pad_c0[0x50]; // 0xc0(0x50)
};

// Class IrisCore.NetObjectPrioritizerConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UNetObjectPrioritizerConfig : UObject {
};

// Class IrisCore.NetObjectCountLimiterConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UNetObjectCountLimiterConfig : UNetObjectPrioritizerConfig {
	enum class ENetObjectCountLimiterMode Mode; // 0x98(0x04)
	uint32_t MaxObjectCount; // 0x9c(0x04)
	float Priority; // 0xa0(0x04)
	float OwningConnectionPriority; // 0xa4(0x04)
	bool bEnableOwnedObjectsFastLane; // 0xa8(0x01)
};

// Class IrisCore.NetObjectCountLimiter
// Size: 0x100 (Inherited: 0xa0)
struct UNetObjectCountLimiter : UNetObjectPrioritizer {
	char pad_a0[0x60]; // 0xa0(0x60)
};

// Class IrisCore.NetObjectFilterDefinitions
// Size: 0xb0 (Inherited: 0xa0)
struct UNetObjectFilterDefinitions : UObject {
	struct TArray<struct FNetObjectFilterDefinition> NetObjectFilterDefinitions; // 0x98(0x10)
};

// Class IrisCore.NetObjectGridFilterConfig
// Size: 0xf0 (Inherited: 0xa0)
struct UNetObjectGridFilterConfig : UNetObjectFilterConfig {
	uint32_t ViewPosRelevancyFrameCount; // 0xa0(0x04)
	float CellSizeX; // 0xa4(0x04)
	float CellSizeY; // 0xa8(0x04)
	float MaxCullDistance; // 0xac(0x04)
	float DefaultCullDistance; // 0xb0(0x04)
	char pad_b4[0x4]; // 0xb4(0x04)
	struct FVector MinPos; // 0xb8(0x18)
	struct FVector MaxPos; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class IrisCore.NetObjectGridFilter
// Size: 0x170 (Inherited: 0xc0)
struct UNetObjectGridFilter : UNetObjectFilter {
	char pad_c0[0xb0]; // 0xc0(0xb0)
};

// Class IrisCore.NetObjectGridWorldLocFilter
// Size: 0x170 (Inherited: 0x170)
struct UNetObjectGridWorldLocFilter : UNetObjectGridFilter {
};

// Class IrisCore.NetObjectGridFragmentLocFilter
// Size: 0x1c0 (Inherited: 0x170)
struct UNetObjectGridFragmentLocFilter : UNetObjectGridFilter {
	char pad_170[0x50]; // 0x170(0x50)
};

// Class IrisCore.NetObjectPrioritizerDefinitions
// Size: 0xb0 (Inherited: 0xa0)
struct UNetObjectPrioritizerDefinitions : UObject {
	struct TArray<struct FNetObjectPrioritizerDefinition> NetObjectPrioritizerDefinitions; // 0x98(0x10)
};

// Class IrisCore.NetRPCHandler
// Size: 0xb0 (Inherited: 0xb0)
struct UNetRPCHandler : UNetBlobHandler {
};

// Class IrisCore.NetTokenDataStream
// Size: 0xf0 (Inherited: 0xa0)
struct UNetTokenDataStream : UDataStream {
	char pad_a0[0x50]; // 0xa0(0x50)
};

// Class IrisCore.NopNetObjectFilterConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UNopNetObjectFilterConfig : UNetObjectFilterConfig {
};

// Class IrisCore.NopNetObjectFilter
// Size: 0xc0 (Inherited: 0xc0)
struct UNopNetObjectFilter : UNetObjectFilter {
};

// Class IrisCore.ReplicationBridge
// Size: 0x180 (Inherited: 0xa0)
struct UReplicationBridge : UObject {
	char pad_a0[0xe0]; // 0xa0(0xe0)
};

// Class IrisCore.ObjectReplicationBridge
// Size: 0x520 (Inherited: 0x180)
struct UObjectReplicationBridge : UReplicationBridge {
	char pad_180[0x3a0]; // 0x180(0x3a0)
};

// Class IrisCore.ObjectReplicationBridgeConfig
// Size: 0xf0 (Inherited: 0xa0)
struct UObjectReplicationBridgeConfig : UObject {
	struct TArray<struct FObjectReplicationBridgePollConfig> PollConfigs; // 0x98(0x10)
	struct TArray<struct FObjectReplicationBridgeFilterConfig> FilterConfigs; // 0xa8(0x10)
	struct TArray<struct FObjectReplicationBridgePrioritizerConfig> PrioritizerConfigs; // 0xb8(0x10)
	struct TArray<struct FObjectReplicationBridgeDeltaCompressionConfig> DeltaCompressionConfigs; // 0xc8(0x10)
	struct FName DefaultSpatialFilterName; // 0xd8(0x08)
	struct FName RequiredNetDriverChannelClassName; // 0xe0(0x08)
};

// Class IrisCore.SequentialPartialNetBlobHandlerConfig
// Size: 0xa0 (Inherited: 0xa0)
struct USequentialPartialNetBlobHandlerConfig : UObject {
	uint32_t MaxPartBitCount; // 0x98(0x04)
	uint32_t MaxPartCount; // 0x9c(0x04)
};

// Class IrisCore.PartialNetObjectAttachmentHandlerConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UPartialNetObjectAttachmentHandlerConfig : USequentialPartialNetBlobHandlerConfig {
	uint32_t BitCountSplitThreshold; // 0xa0(0x04)
	char pad_a4[0xc]; // 0xa4(0x0c)
};

// Class IrisCore.SequentialPartialNetBlobHandler
// Size: 0xc0 (Inherited: 0xb0)
struct USequentialPartialNetBlobHandler : UNetBlobHandler {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class IrisCore.PartialNetObjectAttachmentHandler
// Size: 0xc0 (Inherited: 0xc0)
struct UPartialNetObjectAttachmentHandler : USequentialPartialNetBlobHandler {
};

// Class IrisCore.ReplicationDataStream
// Size: 0xb0 (Inherited: 0xa0)
struct UReplicationDataStream : UDataStream {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class IrisCore.ReplicationSystem
// Size: 0xd0 (Inherited: 0xa0)
struct UReplicationSystem : UObject {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct UReplicationBridge* ReplicationBridge; // 0xa8(0x08)
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class IrisCore.SphereNetObjectPrioritizerConfig
// Size: 0xb0 (Inherited: 0xa0)
struct USphereNetObjectPrioritizerConfig : UNetObjectPrioritizerConfig {
	float InnerRadius; // 0x98(0x04)
	float OuterRadius; // 0x9c(0x04)
	float InnerPriority; // 0xa0(0x04)
	float OuterPriority; // 0xa4(0x04)
	float OutsidePriority; // 0xa8(0x04)
};

// Class IrisCore.SphereNetObjectPrioritizer
// Size: 0xe0 (Inherited: 0xd0)
struct USphereNetObjectPrioritizer : ULocationBasedNetObjectPrioritizer {
	char pad_d0[0x10]; // 0xd0(0x10)
};

// Class IrisCore.SphereWithOwnerBoostNetObjectPrioritizerConfig
// Size: 0xc0 (Inherited: 0xb0)
struct USphereWithOwnerBoostNetObjectPrioritizerConfig : USphereNetObjectPrioritizerConfig {
	float OwnerPriorityBoost; // 0xb0(0x04)
	char pad_b4[0xc]; // 0xb4(0x0c)
};

// Class IrisCore.SphereWithOwnerBoostNetObjectPrioritizer
// Size: 0x110 (Inherited: 0xe0)
struct USphereWithOwnerBoostNetObjectPrioritizer : USphereNetObjectPrioritizer {
	char pad_e0[0x30]; // 0xe0(0x30)
};

// Class IrisCore.ReplicationStateDescriptorConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UReplicationStateDescriptorConfig : UObject {
	struct TArray<struct FSupportsStructNetSerializerConfig> SupportsStructNetSerializerList; // 0x98(0x10)
};

