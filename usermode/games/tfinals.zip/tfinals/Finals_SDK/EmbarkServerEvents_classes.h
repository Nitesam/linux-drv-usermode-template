// Class EmbarkServerEvents.EmbarkServerEventsSubsystem
// Size: 0x150 (Inherited: 0xa0)
struct UEmbarkServerEventsSubsystem : UGameInstanceSubsystem {
	struct FMulticastInlineDelegate OnRewardGained; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnRankChange; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnEventPipelineCompleted; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnAngelscriptError; // 0xd0(0x10)
	char pad_e0[0x70]; // 0xe0(0x70)

	bool IsReady(); // Function EmbarkServerEvents.EmbarkServerEventsSubsystem.IsReady // (Final|Native|Public|Const) // @ game+0x5931ed0
	bool HasTestEvent(struct UObject* Class); // Function EmbarkServerEvents.EmbarkServerEventsSubsystem.HasTestEvent // (Final|Native|Public) // @ game+0x59068a0
	struct TArray<struct UServerEventTestBase*> GetTestEvents(struct UObject* Class); // Function EmbarkServerEvents.EmbarkServerEventsSubsystem.GetTestEvents // (Final|Native|Public) // @ game+0x59dcbc0
	struct FString GetTelemetryRoundId(); // Function EmbarkServerEvents.EmbarkServerEventsSubsystem.GetTelemetryRoundId // (Final|Native|Public) // @ game+0x591f690
	struct TArray<struct UServerEventTestBase*> GetAllTestEvents(); // Function EmbarkServerEvents.EmbarkServerEventsSubsystem.GetAllTestEvents // (Final|Native|Public) // @ game+0x23da620
};

// Class EmbarkServerEvents.EmbarkServerEventUtil
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkServerEventUtil : UBlueprintFunctionLibrary {

	void ServerShutdown(struct UObject* WorldContextObject, struct FString ShutdownMessage); // Function EmbarkServerEvents.EmbarkServerEventUtil.ServerShutdown // (Final|Native|Static|Public) // @ game+0x5953050
	void RoundCompleted(struct UObject* WorldContextObject); // Function EmbarkServerEvents.EmbarkServerEventUtil.RoundCompleted // (Final|Native|Static|Public) // @ game+0x5998b10
	void FlushEvents(struct UObject* WorldContextObject); // Function EmbarkServerEvents.EmbarkServerEventUtil.FlushEvents // (Final|Native|Static|Public) // @ game+0x5947b40
};

// Class EmbarkServerEvents.EventAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UEventAPI : UBlueprintFunctionLibrary {

	void ZiplineUse(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, bool bIsStatic, int64_t PlacingPlayer); // Function EmbarkServerEvents.EventAPI.ZiplineUse // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59993f0
	void XPEventUpdate3(struct UObject* WorldContextObject, int64_t Player, int64_t CategoryAssetId, int64_t XpEventId, int64_t Xp); // Function EmbarkServerEvents.EventAPI.XPEventUpdate3 // (Final|Native|Static|Public) // @ game+0x592e380
	void XPBonusApplied2(struct UObject* WorldContextObject, int64_t Player, struct FString Reason, float XpMultiplier, int64_t BaseXp, int64_t BonusXp, int64_t TotalXP); // Function EmbarkServerEvents.EventAPI.XPBonusApplied2 // (Final|Native|Static|Public) // @ game+0x59bcb60
	void XPBonusApplied(struct UObject* WorldContextObject, int64_t Player, float XpMultiplier, int64_t BaseXp, int64_t BonusXp, int64_t TotalXP); // Function EmbarkServerEvents.EventAPI.XPBonusApplied // (Final|Native|Static|Public) // @ game+0x59a4400
	void WorldActivitySpawned(struct UObject* WorldContextObject, struct FString ActivityName, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.WorldActivitySpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5966c40
	void WorldActivityInteraction(struct UObject* WorldContextObject, int64_t Player, struct FString Name, struct FVector& ActivityLocation, struct FString Interaction); // Function EmbarkServerEvents.EventAPI.WorldActivityInteraction // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x598bcb0
	void WeaponReload(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, struct FVector& Location, int64_t BulletsBefore, int64_t BulletsAfter, int64_t WeaponId); // Function EmbarkServerEvents.EventAPI.WeaponReload // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x598d780
	void WeaponModSet4(struct UObject* WorldContextObject, int64_t Player, int64_t WeaponGameAssetId, struct FString WeaponName, struct FString WeaponInstanceId, int64_t ModGameAssetId, struct FString ModName, struct FString ModInstanceId); // Function EmbarkServerEvents.EventAPI.WeaponModSet4 // (Final|Native|Static|Public) // @ game+0x5951630
	void WeaponModRemoved4(struct UObject* WorldContextObject, int64_t Player, int64_t WeaponGameAssetId, struct FString WeaponName, struct FString WeaponInstanceId, int64_t ModGameAssetId, struct FString ModName, struct FString ModInstanceId); // Function EmbarkServerEvents.EventAPI.WeaponModRemoved4 // (Final|Native|Static|Public) // @ game+0x5951630
	void WeaponFired4(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, struct FVector& Location, struct FVector& Direction, int64_t BulletsAfter, bool bUsingCamera, int64_t WeaponId, float Dispersion, float Durability, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems); // Function EmbarkServerEvents.EventAPI.WeaponFired4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599e140
	void WeaponFired3(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, struct FVector& Location, struct FVector& Direction, int64_t BulletsAfter, bool bUsingCamera, int64_t WeaponId, float Dispersion, float Durability, float MaxDurability); // Function EmbarkServerEvents.EventAPI.WeaponFired3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5926b10
	void WeaponFired(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, struct FVector& Location, struct FVector& Direction, int64_t BulletsAfter, bool bUsingCamera, int64_t WeaponId); // Function EmbarkServerEvents.EventAPI.WeaponFired // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5989950
	void ViewSample(struct UObject* WorldContextObject, int64_t Player, struct TArray<float>& MovementInputX, struct TArray<float>& MovementInputY, struct TArray<float>& MovementInputZ, struct TArray<float>& LookRotationVelocityPitch, struct TArray<float>& LookRotationVelocityYaw, struct TArray<bool>& IsUsingGamepad); // Function EmbarkServerEvents.EventAPI.ViewSample // (Final|Native|Static|Public|HasOutParms) // @ game+0x596d4c0
	void UsedSpawnBudgetUpdate(struct UObject* WorldContextObject, int64_t OldUsedSpawnBudget, int64_t NewUsedSpawnBudget, int64_t MaxSpawnBudget, int64_t PlayerCount); // Function EmbarkServerEvents.EventAPI.UsedSpawnBudgetUpdate // (Final|Native|Static|Public) // @ game+0x592e380
	void UpdatePlayerStats(struct UObject* WorldContextObject, int64_t Player, int64_t TotalScore, int64_t CombatScore, int64_t SupportScore, int64_t ObjectiveScore, int64_t NumberOfEliminitations, int64_t NumberOfAssists, int64_t NumberOfDeaths, int64_t NumberOfRevives, int64_t NumberOfObjectives, int64_t SquadCashCollected); // Function EmbarkServerEvents.EventAPI.UpdatePlayerStats // (Final|Native|Static|Public) // @ game+0x5998400
	void UpdateBounty(struct UObject* WorldContextObject, int64_t Player, int32_t PrevAmount, int32_t NewAmount); // Function EmbarkServerEvents.EventAPI.UpdateBounty // (Final|Native|Static|Public) // @ game+0x5963810
	void UnrealServerTime2(struct UObject* WorldContextObject, int64_t UnrealTime); // Function EmbarkServerEvents.EventAPI.UnrealServerTime2 // (Final|Native|Static|Public) // @ game+0x591e350
	void TutorialTagAdded(struct UObject* WorldContextObject, int64_t Player, struct FString TutorialTag); // Function EmbarkServerEvents.EventAPI.TutorialTagAdded // (Final|Native|Static|Public) // @ game+0x5920650
	void TutorialCompleted(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.TutorialCompleted // (Final|Native|Static|Public) // @ game+0x591e350
	void TurbulenceShieldDamageTaken(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, float AccumulatedShieldDamage); // Function EmbarkServerEvents.EventAPI.TurbulenceShieldDamageTaken // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d3d90
	void TugOfWarCartStatus(struct UObject* WorldContextObject, float Distance, float Speed, struct FVector& CartLocation, struct FVector& CartRotation, int64_t PlayersSquad0, int64_t PlayersSquad1, int64_t ControllingSquadId); // Function EmbarkServerEvents.EventAPI.TugOfWarCartStatus // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a57f0
	void TugOfWarCartDistancePushed(struct UObject* WorldContextObject, int64_t Player, int64_t Distance); // Function EmbarkServerEvents.EventAPI.TugOfWarCartDistancePushed // (Final|Native|Static|Public) // @ game+0x590e710
	void TugOfWarCartControlChange(struct UObject* WorldContextObject, struct FVector& CartLocation, int64_t PreviousSquadId, int64_t NewSquadId, int64_t PlayersSquad0, int64_t PlayersSquad1); // Function EmbarkServerEvents.EventAPI.TugOfWarCartControlChange // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x597b1e0
	void TugOfWarCartActivationStarted(struct UObject* WorldContextObject, int64_t Player, struct FVector& CartLocation); // Function EmbarkServerEvents.EventAPI.TugOfWarCartActivationStarted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void TugOfWarCartActivationFinished(struct UObject* WorldContextObject, int64_t Player, struct FVector& CartLocation); // Function EmbarkServerEvents.EventAPI.TugOfWarCartActivationFinished // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void TryActivateAbility(struct UObject* WorldContextObject, int64_t Player, struct FString Ability, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.TryActivateAbility // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590b130
	void TournamentState(struct UObject* WorldContextObject, struct FString TournamentId, struct FString MatchId); // Function EmbarkServerEvents.EventAPI.TournamentState // (Final|Native|Static|Public) // @ game+0x5941ca0
	void TelemetryStartup(struct UObject* WorldContextObject, struct FString ServerSessionId); // Function EmbarkServerEvents.EventAPI.TelemetryStartup // (Final|Native|Static|Public) // @ game+0x59134c0
	void SubroundWin(struct UObject* WorldContextObject, int64_t Player, struct FString SubroundId, struct FString EndReason, struct FString Team); // Function EmbarkServerEvents.EventAPI.SubroundWin // (Final|Native|Static|Public) // @ game+0x59240c0
	void SubroundStarted2(struct UObject* WorldContextObject, struct FString SubroundId, struct FString RoundState, struct FString AttackDefendScenario); // Function EmbarkServerEvents.EventAPI.SubroundStarted2 // (Final|Native|Static|Public) // @ game+0x594a4e0
	void SubroundLoss(struct UObject* WorldContextObject, int64_t Player, struct FString SubroundId, struct FString EndReason, struct FString Team); // Function EmbarkServerEvents.EventAPI.SubroundLoss // (Final|Native|Static|Public) // @ game+0x59240c0
	void SubroundEnded(struct UObject* WorldContextObject, struct FString SubroundId, struct FString EndReason); // Function EmbarkServerEvents.EventAPI.SubroundEnded // (Final|Native|Static|Public) // @ game+0x5941ca0
	void SteamApp(struct UObject* WorldContextObject, int32_t SteamAppId, struct FString BranchName, int64_t Player); // Function EmbarkServerEvents.EventAPI.SteamApp // (Final|Native|Static|Public) // @ game+0x59837a0
	void StaticSpawnerSpawnEnemy3(struct UObject* WorldContextObject, struct FString Enemy, struct FString Spawner, int64_t EnemySpawnId, struct FString SpawnerUuid, int64_t EnemyId); // Function EmbarkServerEvents.EventAPI.StaticSpawnerSpawnEnemy3 // (Final|Native|Static|Public) // @ game+0x595c1a0
	void StaticSpawnerSpawnEnemy2(struct UObject* WorldContextObject, struct FString Enemy, struct FString Spawner, int64_t EnemySpawnId, struct FString SpawnerUuid); // Function EmbarkServerEvents.EventAPI.StaticSpawnerSpawnEnemy2 // (Final|Native|Static|Public) // @ game+0x594a690
	void StaticSpawnerDeactivate2(struct UObject* WorldContextObject, struct FVector& Location, struct FString Spawner, struct FString SpawnerUuid); // Function EmbarkServerEvents.EventAPI.StaticSpawnerDeactivate2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5982210
	void StaticSpawnerCreated2(struct UObject* WorldContextObject, struct FVector& Location, struct FString Spawner, struct FString SpawnerParent, struct FString EnemyTable, struct FString SpawnerUuid); // Function EmbarkServerEvents.EventAPI.StaticSpawnerCreated2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b72f0
	void StaticSpawnerActivate2(struct UObject* WorldContextObject, struct FVector& Location, int64_t Player, struct FVector& PlayerLocation, struct FString Spawner, struct FString SpawnerUuid); // Function EmbarkServerEvents.EventAPI.StaticSpawnerActivate2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5949d30
	void StashMetaItems2(struct UObject* WorldContextObject, int64_t Player, struct TArray<struct FFieldTypeAssetInstanceAmount> StashMetaItems); // Function EmbarkServerEvents.EventAPI.StashMetaItems2 // (Final|Native|Static|Public) // @ game+0x59968b0
	void StashItems5(struct UObject* WorldContextObject, int64_t Player, struct TArray<struct FFieldTypeAssetInstanceAmountDurability> StashItems, struct TArray<struct FFieldTypeAssetInstanceAmountDurability> AttachedStashItems); // Function EmbarkServerEvents.EventAPI.StashItems5 // (Final|Native|Static|Public) // @ game+0x59d61c0
	void StashItems4(struct UObject* WorldContextObject, int64_t Player, struct TArray<struct FFieldTypeAssetInstanceAmount> StashItems, struct TArray<struct FFieldTypeAssetInstanceAmount> AttachedStashItems); // Function EmbarkServerEvents.EventAPI.StashItems4 // (Final|Native|Static|Public) // @ game+0x5908e90
	void StartSpawnSequenceProxy(struct UObject* WorldContextObject, int64_t Player, struct TArray<int64_t>& AuxilaryPlayerIds, struct FVector& Location, struct FString SpawnSource, struct FString InstigatorName, int64_t InstigatorGameAssetId, int64_t InstigatorEnemySpawnId, int64_t GroupId); // Function EmbarkServerEvents.EventAPI.StartSpawnSequenceProxy // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599d250
	void StartSpawnSequence(struct UObject* WorldContextObject, int64_t Player, struct TArray<int64_t>& AuxilaryPlayerIds, struct FVector& Location, struct FString SpawnSource, struct FString InstigatorName, int64_t InstigatorGameAssetId, int64_t InstigatorEnemySpawnId, int64_t GroupId); // Function EmbarkServerEvents.EventAPI.StartSpawnSequence // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599d250
	void StartInstantReplayDownload(struct UObject* WorldContextObject, int32_t FileId, int32_t NumPackets, int32_t CompressedSize, int32_t UncompressedSize, int32_t UncompressedCheckpointSize, int32_t UncompressedStreamChunkSize, int64_t Player); // Function EmbarkServerEvents.EventAPI.StartInstantReplayDownload // (Final|Native|Static|Public) // @ game+0x597e380
	void StanceChanged(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString OldStance, struct FString NewStance); // Function EmbarkServerEvents.EventAPI.StanceChanged // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5927e00
	void StaminaUsed(struct UObject* WorldContextObject, int64_t Player, float StaminaUsed, float ActuallyConsumedStamina, struct FVector& Location, struct FString AbilityName); // Function EmbarkServerEvents.EventAPI.StaminaUsed // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x592abc0
	void SquadAbandon(struct UObject* WorldContextObject, int64_t SquadIndex); // Function EmbarkServerEvents.EventAPI.SquadAbandon // (Final|Native|Static|Public) // @ game+0x591e350
	void SpawnWorldItem(struct UObject* WorldContextObject, struct FString Instigator, struct FVector& Location, int64_t GameAssetId, struct FVector& WorldItemLocation); // Function EmbarkServerEvents.EventAPI.SpawnWorldItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59481e0
	void SpawnedInventorySlot3(struct UObject* WorldContextObject, int64_t Player, int64_t Amount, int64_t GameAssetId, struct FString InstanceId, struct FString Container, float Durability, float MaxDurability, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems); // Function EmbarkServerEvents.EventAPI.SpawnedInventorySlot3 // (Final|Native|Static|Public) // @ game+0x592cca0
	void SoundTrapActivated(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString TrapName, float ElevationChangedTime); // Function EmbarkServerEvents.EventAPI.SoundTrapActivated // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590efb0
	void SessionModifier(struct UObject* WorldContextObject, struct TArray<int64_t>& ModifierIds); // Function EmbarkServerEvents.EventAPI.SessionModifier // (Final|Native|Static|Public|HasOutParms) // @ game+0x59340f0
	void SessionDefeatForceKill(struct UObject* WorldContextObject, int64_t Player, struct FString DefeatReason); // Function EmbarkServerEvents.EventAPI.SessionDefeatForceKill // (Final|Native|Static|Public) // @ game+0x5920650
	void ServerShutdown(struct UObject* WorldContextObject, struct FString Reason); // Function EmbarkServerEvents.EventAPI.ServerShutdown // (Final|Native|Static|Public) // @ game+0x59134c0
	void ServerPerformance2(struct UObject* WorldContextObject, struct TArray<char>& Frametimes, struct TArray<char>& TotalSaturatedConnections, int32_t NumBadFrams, int32_t StartingFrameNum); // Function EmbarkServerEvents.EventAPI.ServerPerformance2 // (Final|Native|Static|Public|HasOutParms) // @ game+0x5985a90
	void ServerNetDriverPerformance(struct UObject* WorldContextObject, struct FString DriverName, int64_t FrameCount, struct TArray<char>& Frames, int64_t FirstFrame); // Function EmbarkServerEvents.EventAPI.ServerNetDriverPerformance // (Final|Native|Static|Public|HasOutParms) // @ game+0x59b9380
	void ServerManifest(struct UObject* WorldContextObject, int64_t ServerManifestId); // Function EmbarkServerEvents.EventAPI.ServerManifest // (Final|Native|Static|Public) // @ game+0x591e350
	void ServerDetectedClientConnectionFailure3(struct UObject* WorldContextObject, int64_t Player, int32_t FromFailureOrigin, int32_t ErrorType, struct FFieldTypeNetConnectionData& ConnectionInfo); // Function EmbarkServerEvents.EventAPI.ServerDetectedClientConnectionFailure3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x5980fa0
	void ServerAgonesReady(struct UObject* WorldContextObject, int64_t UnrealTime); // Function EmbarkServerEvents.EventAPI.ServerAgonesReady // (Final|Native|Static|Public) // @ game+0x591e350
	void SelectedEmote(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, struct FString Name); // Function EmbarkServerEvents.EventAPI.SelectedEmote // (Final|Native|Static|Public) // @ game+0x59135b0
	void SaturatedFrames(struct UObject* WorldContextObject, struct TArray<char>& TotalSaturatedConnections); // Function EmbarkServerEvents.EventAPI.SaturatedFrames // (Final|Native|Static|Public|HasOutParms) // @ game+0x59340f0
	void RoundWin(struct UObject* WorldContextObject, int64_t Player, int32_t WinReason); // Function EmbarkServerEvents.EventAPI.RoundWin // (Final|Native|Static|Public) // @ game+0x593bc60
	void RoundStarted(struct UObject* WorldContextObject, int64_t UnrealTime); // Function EmbarkServerEvents.EventAPI.RoundStarted // (Final|Native|Static|Public) // @ game+0x591e350
	void RoundDefeat(struct UObject* WorldContextObject, int64_t Player, int32_t DefeatReason); // Function EmbarkServerEvents.EventAPI.RoundDefeat // (Final|Native|Static|Public) // @ game+0x593bc60
	void RoundCompleted(struct UObject* WorldContextObject, int64_t UnrealTime); // Function EmbarkServerEvents.EventAPI.RoundCompleted // (Final|Native|Static|Public) // @ game+0x591e350
	void ReverseGravityZoneSpawned(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.ReverseGravityZoneSpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void RemoveBounty(struct UObject* WorldContextObject, int64_t Player, int32_t Amount); // Function EmbarkServerEvents.EventAPI.RemoveBounty // (Final|Native|Static|Public) // @ game+0x593bc60
	void PuzzleStepDeactivated(struct UObject* WorldContextObject, int64_t Player, struct FString PuzzleActorName, struct FVector& PuzzleLocation, int64_t CurrentStep, int64_t TotalStepsRequired, struct FString AcctivatorActorName); // Function EmbarkServerEvents.EventAPI.PuzzleStepDeactivated // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591e650
	void PuzzleStepActivated(struct UObject* WorldContextObject, int64_t Player, struct FString PuzzleActorName, struct FVector& PuzzleLocation, int64_t CurrentStep, int64_t TotalStepsRequired, struct FString ActivatorActorName); // Function EmbarkServerEvents.EventAPI.PuzzleStepActivated // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591e650
	void PuzzleReset(struct UObject* WorldContextObject, int64_t Player, struct FString PuzzleActorName, struct FVector& PuzzleLocation, int64_t StepAtReset, int64_t TotalStepsRequired); // Function EmbarkServerEvents.EventAPI.PuzzleReset // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599ea90
	void PuzzleCompleted(struct UObject* WorldContextObject, int64_t Player, struct FString PuzzleActorName, struct FVector& PuzzleLocation, int64_t TotalSteps); // Function EmbarkServerEvents.EventAPI.PuzzleCompleted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593ac70
	void PushTokenChange(struct UObject* WorldContextObject, int64_t Player, int32_t ScenarioIndex, int32_t OldValue, int32_t NewValue, struct FString Reason); // Function EmbarkServerEvents.EventAPI.PushTokenChange // (Final|Native|Static|Public) // @ game+0x5913760
	void PushScenarioStarted2(struct UObject* WorldContextObject, int32_t ScenarioIndex, int64_t ScenarioStartTimestamp, int32_t AttackingTeamId, int32_t DefendingTeamId, int32_t AttackerTickets, int32_t MaxAttackerTickets); // Function EmbarkServerEvents.EventAPI.PushScenarioStarted2 // (Final|Native|Static|Public) // @ game+0x59a52c0
	void PushScenarioCompleted3(struct UObject* WorldContextObject, int32_t ScenarioIndex, float ScenarioDuration, int32_t AttackingSquadId, int32_t DefendingSquadId, struct FString EndReason, int32_t AttackerTickets, int32_t MaxAttackerTickets, int32_t AddedAttackerTickets); // Function EmbarkServerEvents.EventAPI.PushScenarioCompleted3 // (Final|Native|Static|Public) // @ game+0x5976e50
	void PushRoundCompleted4(struct UObject* WorldContextObject, int32_t WinningSquadId, struct FString EndReason, int32_t TotalScenariosCompleted, int32_t FinalTicketCount, bool bAttackersWon, float Duration); // Function EmbarkServerEvents.EventAPI.PushRoundCompleted4 // (Final|Native|Static|Public) // @ game+0x59a4120
	void PushObjectiveStateChange4(struct UObject* WorldContextObject, int32_t ScenarioIndex, int32_t ObjectiveSpawnIndex, struct FString ObjectiveLabel, struct FString PreviousState, struct FString NewState, int64_t Player, int64_t TicketsAtStateChange, float Duration, struct FVector& Location, int32_t AddedTickets); // Function EmbarkServerEvents.EventAPI.PushObjectiveStateChange4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5982950
	void PushObjectivePosition(struct UObject* WorldContextObject, int32_t ObjectiveIndex, int32_t ScenarioIndex, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.PushObjectivePosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59635c0
	void ProjectileValidationFailed(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, float PlayerPing, float TargetPlayerPing, struct FVector& AimingLocation, struct FVector& ActorLocation, struct FVector& HitLocation, struct FVector& PelvisLocation, bool bIsCrouching, struct FString Reason, float FailingValue); // Function EmbarkServerEvents.EventAPI.ProjectileValidationFailed // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b9cd0
	void PotentialTargets(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, float Distance, float BulletDistance, int64_t WeaponGameAssetId); // Function EmbarkServerEvents.EventAPI.PotentialTargets // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599b0a0
	void PortalSpawned(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.PortalSpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void POIExited(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString PoiName, struct FString Description, struct FString PoiHierarchy); // Function EmbarkServerEvents.EventAPI.POIExited // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5911eb0
	void POIEntered(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString PoiName, struct FString Description, struct FString PoiHierarchy); // Function EmbarkServerEvents.EventAPI.POIEntered // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5911eb0
	void PlayerTeleported(struct UObject* WorldContextObject, int64_t Player, struct FVector& FromLocation, struct FVector& ToLocation, bool bFriendlyPortal); // Function EmbarkServerEvents.EventAPI.PlayerTeleported // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59db830
	void PlayerSurrender(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerSurrender // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerStopSpectate(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerStopSpectate // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerStateChange(struct UObject* WorldContextObject, int64_t Player, int32_t OldState, int32_t NewState); // Function EmbarkServerEvents.EventAPI.PlayerStateChange // (Final|Native|Static|Public) // @ game+0x5963810
	void PlayerStartSpectate(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerStartSpectate // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerStandingOnMovingFloor(struct UObject* WorldContextObject, int64_t Player, float TimeSpentOnMovingFloor); // Function EmbarkServerEvents.EventAPI.PlayerStandingOnMovingFloor // (Final|Native|Static|Public) // @ game+0x5986f50
	void PlayerSpawnWorldItem(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, struct FString InstanceId, struct FVector& WorldItemLocation); // Function EmbarkServerEvents.EventAPI.PlayerSpawnWorldItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5955e70
	void PlayerSpawn4(struct UObject* WorldContextObject, int64_t Player, int64_t SquadId, struct FString Squad, struct FVector& Location, int64_t CharacterId, struct FString Difficulty, struct FString GameMap, struct FString MapLocation); // Function EmbarkServerEvents.EventAPI.PlayerSpawn4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c4300
	void PlayerShieldRecharge(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, int64_t GameAssetId, float ArmorHealthBefore, float ArmorHealthAfter, int64_t RepairTime); // Function EmbarkServerEvents.EventAPI.PlayerShieldRecharge // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5975700
	void PlayerRoundID(struct UObject* WorldContextObject, int64_t Player, struct FString PlayerRoundID); // Function EmbarkServerEvents.EventAPI.PlayerRoundID // (Final|Native|Static|Public) // @ game+0x5920650
	void PlayerRevive2(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, struct FVector& TargetLocation, float TargetHealTaken, float TargetDbnoHealth, struct FString ItemUsed, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.PlayerRevive2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x592dc70
	void PlayerRepairExtractionPoint(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString ExtractionPointName, struct FString ExtractionPointType, struct FVector& ExtractionPointLocation); // Function EmbarkServerEvents.EventAPI.PlayerRepairExtractionPoint // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c3310
	void PlayerReconnect(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerReconnect // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerPosition(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FVector& ForwardVector, struct FVector& Velocity); // Function EmbarkServerEvents.EventAPI.PlayerPosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599ded0
	void PlayerPawnAssigned(struct UObject* WorldContextObject, int64_t Player, struct FString PawnName); // Function EmbarkServerEvents.EventAPI.PlayerPawnAssigned // (Final|Native|Static|Public) // @ game+0x5920650
	void PlayerNotCloseToCart(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.PlayerNotCloseToCart // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void PlayerNetworkUnresponsive3(struct UObject* WorldContextObject, int64_t Player, float LastReceiveRealtime, struct FString UnresponsiveId, struct FFieldTypeNetConnectionData& ConnectionInfo); // Function EmbarkServerEvents.EventAPI.PlayerNetworkUnresponsive3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x596d060
	void PlayerNetworkResponsive(struct UObject* WorldContextObject, int64_t Player, float Duration, struct FString UnresponsiveId); // Function EmbarkServerEvents.EventAPI.PlayerNetworkResponsive // (Final|Native|Static|Public) // @ game+0x5915260
	void PlayerNetworkLatency(struct UObject* WorldContextObject, int64_t Player, float NetworkLatency); // Function EmbarkServerEvents.EventAPI.PlayerNetworkLatency // (Final|Native|Static|Public) // @ game+0x5986f50
	void PlayerNetworkConnectionClose(struct UObject* WorldContextObject, int64_t Player, struct FFieldTypeNetConnectionData& ConnectionInfo, struct FString CloseReason); // Function EmbarkServerEvents.EventAPI.PlayerNetworkConnectionClose // (Final|Native|Static|Public|HasOutParms) // @ game+0x59d1e10
	void PlayerKickedByServer(struct UObject* WorldContextObject, int64_t Player, struct FString Reason); // Function EmbarkServerEvents.EventAPI.PlayerKickedByServer // (Final|Native|Static|Public) // @ game+0x5920650
	void PlayerInitialized(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerInitialized // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerInitializationStep(struct UObject* WorldContextObject, int64_t Player, struct FString InitStepDescription, bool bWasSuccess); // Function EmbarkServerEvents.EventAPI.PlayerInitializationStep // (Final|Native|Static|Public) // @ game+0x59767a0
	void PlayerIndoorStateChange(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, bool bIsIndoors); // Function EmbarkServerEvents.EventAPI.PlayerIndoorStateChange // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x595ada0
	void PlayerHit2(struct UObject* WorldContextObject, int64_t Player, struct FVector& PlayerLocation, int64_t WeaponGameAssetId, int64_t TargetPlayer, struct FVector& TargetPlayerLocation, bool bIsDead); // Function EmbarkServerEvents.EventAPI.PlayerHit2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b1610
	void PlayerHeal4(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, int64_t ItemId, float HealthBefore, float HealthAfter, struct FVector& TargetLocation, struct FString ItemUsed, struct FVector& Location, struct TArray<struct FString>& TargetOngoingGameplayEffects, float DbnoHealthBefore, bool bWasDbno, bool bIsDbno); // Function EmbarkServerEvents.EventAPI.PlayerHeal4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5979900
	void PlayerFellOutOfWorld(struct UObject* WorldContextObject, int64_t Player, struct FVector& KillZHitLocation, struct FVector& LastGroundedLocation); // Function EmbarkServerEvents.EventAPI.PlayerFellOutOfWorld // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a6990
	void PlayerExtractionStarted(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString ExtractionPointName, struct FString ExtractionPointType, int32_t ExtractionCycle); // Function EmbarkServerEvents.EventAPI.PlayerExtractionStarted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5959ce0
	void PlayerExtractionFinalized(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString ExtractionPointName, struct FString ExtractionPointType, int32_t ExtractionCycle); // Function EmbarkServerEvents.EventAPI.PlayerExtractionFinalized // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5959ce0
	void PlayerExtractionCanceled(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString ExtractionPointName, struct FString ExtractionPointType, int32_t ExtractionCycle); // Function EmbarkServerEvents.EventAPI.PlayerExtractionCanceled // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5959ce0
	void PlayerExpressionUsed(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, struct FString EventTag); // Function EmbarkServerEvents.EventAPI.PlayerExpressionUsed // (Final|Native|Static|Public) // @ game+0x59135b0
	void PlayerEndAffectedByInstrument(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t OtherPlayer, struct FVector& OtherLocation, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.PlayerEndAffectedByInstrument // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59677e0
	void PlayerDisconnect(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerDisconnect // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerDie(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerDie // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerDeathItemDecay(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, struct FString Name, struct FString InstanceId, float Decay, float PostDeathDurability); // Function EmbarkServerEvents.EventAPI.PlayerDeathItemDecay // (Final|Native|Static|Public) // @ game+0x59a18f0
	void PlayerDamagePlayer6(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, float HealthBefore, float HealthAfter, struct FString DamageCauser, int64_t GameAssetId, bool bIsDbno, struct FString BoneHit, struct TArray<struct FString>& TargetOngoingGameplayEffects, float DbnoHealthBefore, float DbnoHealthAfter, bool bWasDbno, float ArmorHealthBefore, float ArmorHealthAfter, float ArmorMitigatedDamage, struct FString WeaponInstanceId); // Function EmbarkServerEvents.EventAPI.PlayerDamagePlayer6 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59bee80
	void PlayerDamagePlayer5(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, float HealthBefore, float HealthAfter, struct FString DamageCauser, int64_t GameAssetId, bool bIsDbno, struct FString BoneHit, struct TArray<struct FString>& TargetOngoingGameplayEffects, float DbnoHealthBefore, float DbnoHealthAfter, bool bWasDbno, float ArmorHealthBefore, float ArmorHealthAfter, float ArmorMitigatedDamage); // Function EmbarkServerEvents.EventAPI.PlayerDamagePlayer5 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5928730
	void PlayerDamageActor(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString TargetName, struct FVector& TargetLocation, float PreviousHealth, float CurrentHealth, int64_t GameAssetId, struct FString BoneName); // Function EmbarkServerEvents.EventAPI.PlayerDamageActor // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593cb80
	void PlayerConnectTelemetry(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerConnectTelemetry // (Final|Native|Static|Public) // @ game+0x591e350
	void PlayerConnectIp(struct UObject* WorldContextObject, int64_t Player, struct FString Ip); // Function EmbarkServerEvents.EventAPI.PlayerConnectIp // (Final|Native|Static|Public) // @ game+0x5920650
	void PlayerConnect3(struct UObject* WorldContextObject, int64_t Player, int64_t ManifestId, struct FString ClientUuid, int64_t ClientPlatform); // Function EmbarkServerEvents.EventAPI.PlayerConnect3 // (Final|Native|Static|Public) // @ game+0x5951e80
	void PlayerCloseToCart(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.PlayerCloseToCart // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void PlayerBeginAffectedByInstrument(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t OtherPlayer, struct FVector& OtherLocation, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.PlayerBeginAffectedByInstrument // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59677e0
	void PlayerBackfill(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.PlayerBackfill // (Final|Native|Static|Public) // @ game+0x591e350
	void PioViewToKill3(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, struct TArray<float>& KillerMovementInputX, struct TArray<float>& KillerMovementInputY, struct TArray<float>& KillerMovementInputZ, struct TArray<float>& KillerLookRotationVelocityPitch, struct TArray<float>& KillerLookRotationVelocityYaw, struct TArray<float>& VictimPosInKillerFrustumX, struct TArray<float>& VictimPosInKillerFrustumY, struct TArray<float>& VictimPosInKillerFrustumZ, struct TArray<bool>& IsUsingGamepad, struct TArray<bool>& IsFiring, struct TArray<float>& VictimVelocityInKillerFrustumX, struct TArray<float>& VictimVelocityInKillerFrustumY, struct TArray<float>& VictimVelocityInKillerFrustumZ, struct TArray<float>& KillerVelocityInKillerFrustumX, struct TArray<float>& KillerVelocityInKillerFrustumY, struct TArray<float>& KillerVelocityInKillerFrustumZ, struct TArray<bool>& IsUsingAimAssist, struct TArray<float>& KillerLatencies); // Function EmbarkServerEvents.EventAPI.PioViewToKill3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x595fe40
	void PioPlayerStuckStateChanged(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, bool bIsStuck); // Function EmbarkServerEvents.EventAPI.PioPlayerStuckStateChanged // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x595ada0
	void PioFixStuckPlayer(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, bool bIsStuck); // Function EmbarkServerEvents.EventAPI.PioFixStuckPlayer // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x595ada0
	void Pinging(struct UObject* WorldContextObject, int64_t Player, struct FString PingIntent, struct FString PingTagname, struct FVector& Location, struct FVector& PingLocation); // Function EmbarkServerEvents.EventAPI.Pinging // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59cd830
	void PickupCarriable(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString CarriableName); // Function EmbarkServerEvents.EventAPI.PickupCarriable // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5925dd0
	void PartyBonusXp2(struct UObject* WorldContextObject, int64_t Player, struct FString BonusType, int32_t PartySize, int32_t PartyBonusXp, float Multiplier); // Function EmbarkServerEvents.EventAPI.PartyBonusXp2 // (Final|Native|Static|Public) // @ game+0x59573e0
	void PartyBonusFans(struct UObject* WorldContextObject, int64_t Player, int32_t PartySize, int32_t PartyBonusFans, float Multiplier); // Function EmbarkServerEvents.EventAPI.PartyBonusFans // (Final|Native|Static|Public) // @ game+0x5939ab0
	void OvertimeStarted(struct UObject* WorldContextObject, float Duration); // Function EmbarkServerEvents.EventAPI.OvertimeStarted // (Final|Native|Static|Public) // @ game+0x59658f0
	void OvertimeSet(struct UObject* WorldContextObject, float Duration); // Function EmbarkServerEvents.EventAPI.OvertimeSet // (Final|Native|Static|Public) // @ game+0x59658f0
	void OvertimeEnded(struct UObject* WorldContextObject, float ElapsedTime, float RemainingTime); // Function EmbarkServerEvents.EventAPI.OvertimeEnded // (Final|Native|Static|Public) // @ game+0x592fd10
	void OnlineTelemetry(struct UObject* WorldContextObject, int64_t Player, struct FString Message); // Function EmbarkServerEvents.EventAPI.OnlineTelemetry // (Final|Native|Static|Public) // @ game+0x5920650
	void OnboardingPlayerRespawn(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.OnboardingPlayerRespawn // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void OnboardingNpcWeaponFired(struct UObject* WorldContextObject, int64_t TargetPlayer, struct FVector& TargetLocation, struct FVector& NpcLocation, struct FVector& Direction); // Function EmbarkServerEvents.EventAPI.OnboardingNpcWeaponFired // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x599ded0
	void OnboardingNPCDamagePlayer2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, float HealthBefore, float HealthAfter, struct FString DamageCauser, struct FVector& EnemyLocation, bool bIsDbno, struct FString BoneHit, struct TArray<struct FString>& TargetOngoingGameplayEffects, float DbnoHealthBefore, float DbnoHealthAfter, bool bWasDbno); // Function EmbarkServerEvents.EventAPI.OnboardingNPCDamagePlayer2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a4ca0
	void ObjectTransmuted(struct UObject* WorldContextObject, int64_t Player, struct FString TargetClass, struct FString NewClass, struct FVector& TargetLocation); // Function EmbarkServerEvents.EventAPI.ObjectTransmuted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5921770
	void NoClientTimeoutShutdown(struct UObject* WorldContextObject, double TimeWaited); // Function EmbarkServerEvents.EventAPI.NoClientTimeoutShutdown // (Final|Native|Static|Public) // @ game+0x59559b0
	void MovementModeChanged(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString OldMovementMode, struct FString NewMovementMode); // Function EmbarkServerEvents.EventAPI.MovementModeChanged // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5927e00
	void MoveItem(struct UObject* WorldContextObject, int64_t Player, int64_t Amount, struct FVector& Location, int64_t GameAssetId, struct FString InstanceId, struct FString PreviousContainer, struct FString NewContainer); // Function EmbarkServerEvents.EventAPI.MoveItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59783c0
	void MissedInput(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.MissedInput // (Final|Native|Static|Public) // @ game+0x591e350
	void MeleeSwingStart3(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString WeaponName, int64_t GameAssetId, struct FString SwingTag, struct FString AttackTag, float ClosestEnemy); // Function EmbarkServerEvents.EventAPI.MeleeSwingStart3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59882e0
	void MeleeSwingEnd(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, struct FString SwingTag, struct FString AttackTag); // Function EmbarkServerEvents.EventAPI.MeleeSwingEnd // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59cbac0
	void MeleeHitValidationFailed(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, float PlayerPing, float TargetPlayerPing, struct FVector& SwingLocation, struct FVector& HitLocation, bool bIsCrouching, struct FString Reason, float FailingValue); // Function EmbarkServerEvents.EventAPI.MeleeHitValidationFailed // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5972d80
	void MeleeHit2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, struct FString Name, int64_t GameAssetId, struct FString SwingTag, struct FString AttackTag, float ClosestEnemyPlayer, struct FString HitType, struct FString HitAlliance); // Function EmbarkServerEvents.EventAPI.MeleeHit2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591db80
	void MaxSpawnBudgetUpdate(struct UObject* WorldContextObject, int64_t OldMaxSpawnBudget, int64_t NewMaxSpawnBudget, int64_t UsedSpawnBudget, int64_t PlayerCount); // Function EmbarkServerEvents.EventAPI.MaxSpawnBudgetUpdate // (Final|Native|Static|Public) // @ game+0x592e380
	void MatchmakingScenario(struct UObject* WorldContextObject, struct FString ScenarioId); // Function EmbarkServerEvents.EventAPI.MatchmakingScenario // (Final|Native|Static|Public) // @ game+0x59134c0
	void MatchId(struct UObject* WorldContextObject, struct FString MatchId); // Function EmbarkServerEvents.EventAPI.MatchId // (Final|Native|Static|Public) // @ game+0x59134c0
	void MasteryMultiplier(struct UObject* WorldContextObject, int64_t Player, int64_t Multiplier); // Function EmbarkServerEvents.EventAPI.MasteryMultiplier // (Final|Native|Static|Public) // @ game+0x590e710
	void MapCondition(struct UObject* WorldContextObject, int64_t GameAssetId, struct FString Name); // Function EmbarkServerEvents.EventAPI.MapCondition // (Final|Native|Static|Public) // @ game+0x5920650
	void LostQuestObjectiveProgress(struct UObject* WorldContextObject, int64_t Player, int64_t QuestId, int64_t ObjectiveId, int64_t ProgressLost); // Function EmbarkServerEvents.EventAPI.LostQuestObjectiveProgress // (Final|Native|Static|Public) // @ game+0x592e380
	void LootCrateSpawn6(struct UObject* WorldContextObject, struct FVector& Location, struct FString LootCrate, struct TArray<struct FFieldTypeAssetInstanceAmount> Items, bool bIsArc, struct FString PoiName, struct FString Description, struct FString PoiHierarchy, struct TArray<struct FFieldTypeStringPair> SubItemReferences); // Function EmbarkServerEvents.EventAPI.LootCrateSpawn6 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59af380
	void LootCrateOpen7(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString LootCrate, struct FString PointOfInterest, struct FString PoiHierarchy, struct FString LootCrateName, struct TArray<struct FFieldTypeAssetInstanceAmount> Items, struct FString InteractionId, struct TArray<struct FFieldTypeStringPair> SubItemReferences, struct FVector& LootCrateLocation); // Function EmbarkServerEvents.EventAPI.LootCrateOpen7 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5919ad0
	void LootCrateClose3(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString LootCrate, struct FString PointOfInterest, struct FString PoiHierarchy, struct FString LootCrateName, struct TArray<struct FFieldTypeAssetInstanceAmount> Items, struct FString InteractionId, struct TArray<struct FFieldTypeStringPair> SubItemReferences, struct FVector& LootCrateLocation); // Function EmbarkServerEvents.EventAPI.LootCrateClose3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5919ad0
	void LoadoutConfiguration(struct UObject* WorldContextObject, int64_t Player, int64_t LoadoutFrameGameAssetId, int64_t PrimaryWeaponSlots, int64_t SecondaryWeaponSlots, int64_t ArmorSlots, struct TArray<int64_t>& AllowedArmorGameAssetIds, int64_t GadgetSlots, int64_t BackpackSlots, int64_t BeltSlots, int64_t SafePouchSlots); // Function EmbarkServerEvents.EventAPI.LoadoutConfiguration // (Final|Native|Static|Public|HasOutParms) // @ game+0x596dc10
	void LightingConditionSet(struct UObject* WorldContextObject, struct FString LightingCondition, bool bOverridden); // Function EmbarkServerEvents.EventAPI.LightingConditionSet // (Final|Native|Static|Public) // @ game+0x592ae60
	void LiftableUsageReport(struct UObject* WorldContextObject, int32_t LiftableActorsSpawned, int32_t LiftableActorsPickedUp, int32_t LiftableActorThrows, int32_t ArenaToolkitActorsSpawned, int32_t ArenaToolkitActorsPickedUp, int32_t ArenaToolkitActorsThrows, int32_t ArenaToolkitActorsExploded); // Function EmbarkServerEvents.EventAPI.LiftableUsageReport // (Final|Native|Static|Public) // @ game+0x594b0f0
	void LaunchPadUse(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, bool bIsStatic, int64_t PlacingPlayer); // Function EmbarkServerEvents.EventAPI.LaunchPadUse // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59993f0
	void KillStealer(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, int32_t TransferPointId, int32_t Cash); // Function EmbarkServerEvents.EventAPI.KillStealer // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5922fd0
	void KillBoxCarrier(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, int32_t TicketIndex, int32_t Cash); // Function EmbarkServerEvents.EventAPI.KillBoxCarrier // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5922fd0
	void ItemUsed4(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, struct FString Name, struct FString InstanceId, float DurabilityBefore, float DurabilityAfter, struct TArray<struct FString>& SpawnedItemNames); // Function EmbarkServerEvents.EventAPI.ItemUsed4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x592fff0
	void ItemUsed3(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, struct FString Name, struct FString InstanceId, float DurabilityBefore, float DurabilityAfter); // Function EmbarkServerEvents.EventAPI.ItemUsed3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593d260
	void ItemUnequipped3(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, struct FVector& Location, int64_t GameAssetId, struct FString InstanceId, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems); // Function EmbarkServerEvents.EventAPI.ItemUnequipped3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590d4d0
	void ItemUnequipped2(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, struct FVector& Location, int64_t GameAssetId, struct FString InstanceId); // Function EmbarkServerEvents.EventAPI.ItemUnequipped2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x595f190
	void ItemTriggered(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, struct FString InstanceId, struct FVector& TriggerLocation, struct FString WorldItemName); // Function EmbarkServerEvents.EventAPI.ItemTriggered // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d80b0
	void ItemMaxDurabilityChanged(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, struct FString InstanceId, float OldMaxDurability, float NewMaxDurability); // Function EmbarkServerEvents.EventAPI.ItemMaxDurabilityChanged // (Final|Native|Static|Public) // @ game+0x59667f0
	void ItemInventoryChange13(struct UObject* WorldContextObject, int64_t Player, struct FString ItemType, struct FString Rarity, struct FString ItemSource, int32_t AmountBefore, int32_t AmountAfter, struct FVector& Location, int64_t ItemId, struct FString InstanceId, struct FString Container, float Durability, float MaxDurability, int64_t OccupiedSlots, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems, struct FString SourceInstanceId, struct FString FromContainerOwner, struct FString ToContainerOwner); // Function EmbarkServerEvents.EventAPI.ItemInventoryChange13 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x595e5a0
	void ItemHit(struct UObject* WorldContextObject, int64_t Player, struct FVector& PlayerLocation, int64_t WeaponGameAssetId, struct FString ItemName, int64_t ItemGameAssetId, struct FVector& ItemLocation); // Function EmbarkServerEvents.EventAPI.ItemHit // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590dc90
	void ItemFireFailure(struct UObject* WorldContextObject, int64_t Player, struct FString FailureReason, int64_t GameAssetId, struct FString ItemName, float DebugFloat1, float DebugFloat2); // Function EmbarkServerEvents.EventAPI.ItemFireFailure // (Final|Native|Static|Public) // @ game+0x593aeb0
	void ItemFieldSalvaged3(struct UObject* WorldContextObject, int64_t Player, struct TArray<struct FFieldTypeAssetInstanceAmounts> ConsumedItems, struct TArray<struct FFieldTypeAssetInstanceAmounts> ProducedItems, int64_t OfferId); // Function EmbarkServerEvents.EventAPI.ItemFieldSalvaged3 // (Final|Native|Static|Public) // @ game+0x5924f30
	void ItemFieldCrafted3(struct UObject* WorldContextObject, int64_t Player, struct TArray<struct FFieldTypeAssetInstanceAmounts> ConsumedItems, struct TArray<struct FFieldTypeAssetInstanceAmounts> ProducedItems, int64_t OfferId); // Function EmbarkServerEvents.EventAPI.ItemFieldCrafted3 // (Final|Native|Static|Public) // @ game+0x5924f30
	void ItemEquipped4(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, struct FVector& Location, int64_t ItemId, struct FString InstanceId, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems); // Function EmbarkServerEvents.EventAPI.ItemEquipped4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590d4d0
	void ItemEquipped3(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, struct FVector& Location, int64_t ItemId, struct FString InstanceId); // Function EmbarkServerEvents.EventAPI.ItemEquipped3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x595f190
	void ItemBroke2(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, struct FString InstanceId, float MaxDurability); // Function EmbarkServerEvents.EventAPI.ItemBroke2 // (Final|Native|Static|Public) // @ game+0x591f420
	void InventoryUpdateCompleted(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.InventoryUpdateCompleted // (Final|Native|Static|Public) // @ game+0x591e350
	void InventoryContainerFull(struct UObject* WorldContextObject, int64_t Player, struct FString Container); // Function EmbarkServerEvents.EventAPI.InventoryContainerFull // (Final|Native|Static|Public) // @ game+0x5920650
	void InteractionStarted(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString InteractionName, struct FString ObjectName, struct FString PromptText); // Function EmbarkServerEvents.EventAPI.InteractionStarted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5911eb0
	void InteractionEnded(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString InteractionName, struct FString ObjectName, struct FString PromptText, bool bEndedSuccessfully); // Function EmbarkServerEvents.EventAPI.InteractionEnded // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59dd810
	void InstantReplayEnabledOnServer(struct UObject* WorldContextObject, int64_t Player, bool bIsReplaysEnabled); // Function EmbarkServerEvents.EventAPI.InstantReplayEnabledOnServer // (Final|Native|Static|Public) // @ game+0x592e6c0
	void InputMethodChanged(struct UObject* WorldContextObject, int64_t Player, struct FString InputDevice); // Function EmbarkServerEvents.EventAPI.InputMethodChanged // (Final|Native|Static|Public) // @ game+0x5920650
	void InputBufferOverflow(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.InputBufferOverflow // (Final|Native|Static|Public) // @ game+0x591e350
	void HitscanValidationFailed2(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, float PlayerPing, float TargetPlayerPing, struct FVector& AimingLocation, struct FVector& ActorLocation, struct FVector& HitLocation, struct FVector& PelvisLocation, bool bIsCrouching, struct FString Reason, float FailingValue, struct FString ExtraContext, int64_t CauserGameAssetId, struct FString CauserItemName); // Function EmbarkServerEvents.EventAPI.HitscanValidationFailed2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x598fa30
	void HealthChange6(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, float HealthBefore, float HealthAfter, struct FString DamageCauser, bool bIsDbno, struct FString BoneHit, struct TArray<struct FString>& TargetOngoingGameplayEffects, float DbnoHealthBefore, float DbnoHealthAfter, bool bWasDbno, float ArmorHealthBefore, float ArmorHealthAfter, float ArmorMitigatedDamage); // Function EmbarkServerEvents.EventAPI.HealthChange6 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5966f90
	void HarvesterCoreStateChanged(struct UObject* WorldContextObject, struct FString Enemy, struct FVector& Location, struct FString PreviousState, struct FString NewState); // Function EmbarkServerEvents.EventAPI.HarvesterCoreStateChanged // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d03e0
	void HarpoonFailure(struct UObject* WorldContextObject, int64_t Player, struct FString OwningName, struct FString FailureReason, float Ping, float FloatValue1, float FloatValue2, struct FString TargetActorName, struct FString TargetName, struct FString TargetBone); // Function EmbarkServerEvents.EventAPI.HarpoonFailure // (Final|Native|Static|Public) // @ game+0x5924aa0
	void GravityZoneUpdated(struct UObject* WorldContextObject, int64_t Player, struct FVector& GravityZoneLocation, int64_t CreationFrame, int64_t CharactersInZone, int64_t ComponentsInZone); // Function EmbarkServerEvents.EventAPI.GravityZoneUpdated // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x594de00
	void GooSpawned2(struct UObject* WorldContextObject, int64_t Player, struct FString CauserClass, struct FString SourceTag, struct FVector& Location, int64_t NumGooBlobs); // Function EmbarkServerEvents.EventAPI.GooSpawned2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x594f040
	void GenesisTeamRoundStartWealth(struct UObject* WorldContextObject, int64_t Round, struct FString Team, int64_t Wealth); // Function EmbarkServerEvents.EventAPI.GenesisTeamRoundStartWealth // (Final|Native|Static|Public) // @ game+0x5909d00
	void GameshowEventStopped(struct UObject* WorldContextObject, struct FString GameShow); // Function EmbarkServerEvents.EventAPI.GameshowEventStopped // (Final|Native|Static|Public) // @ game+0x59134c0
	void GameshowEventStarted(struct UObject* WorldContextObject, struct FString GameShow); // Function EmbarkServerEvents.EventAPI.GameshowEventStarted // (Final|Native|Static|Public) // @ game+0x59134c0
	void GameplayOver(struct UObject* WorldContextObject, int64_t UnrealTime); // Function EmbarkServerEvents.EventAPI.GameplayOver // (Final|Native|Static|Public) // @ game+0x591e350
	void GameplayEffectRemoved(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t InstigatorPlayer, struct FString Tag); // Function EmbarkServerEvents.EventAPI.GameplayEffectRemoved // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593f4c0
	void GameplayEffectAdded(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t InstigatorPlayer, struct FString Tag); // Function EmbarkServerEvents.EventAPI.GameplayEffectAdded // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593f4c0
	void GamePassBonusXp(struct UObject* WorldContextObject, int64_t Player, int32_t GamePassBonusXp); // Function EmbarkServerEvents.EventAPI.GamePassBonusXp // (Final|Native|Static|Public) // @ game+0x593bc60
	void GameMode2(struct UObject* WorldContextObject, struct FString Mode, struct FString Difficulty, struct FString Severity, struct FString LocationTag); // Function EmbarkServerEvents.EventAPI.GameMode2 // (Final|Native|Static|Public) // @ game+0x59059f0
	void GameMap(struct UObject* WorldContextObject, struct FString GameMap); // Function EmbarkServerEvents.EventAPI.GameMap // (Final|Native|Static|Public) // @ game+0x59134c0
	void GameCancelStateSet(struct UObject* WorldContextObject, struct FString Reason); // Function EmbarkServerEvents.EventAPI.GameCancelStateSet // (Final|Native|Static|Public) // @ game+0x59134c0
	void FoundStartGroup3(struct UObject* WorldContextObject, struct FString GroupName, struct FString RestartContext, struct FString AdditionalInfo, int32_t GroupSize, int32_t RequestSize, int32_t SquadIndex, int64_t Seed); // Function EmbarkServerEvents.EventAPI.FoundStartGroup3 // (Final|Native|Static|Public) // @ game+0x59bdb70
	void FallDamage3(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, float DamageTaken, float HealthBefore, float HealthAfter, bool bIsDbno, float DbnoHealthBefore, float DbnoHealthAfter, bool bWasDbno); // Function EmbarkServerEvents.EventAPI.FallDamage3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x597bee0
	void FailedToActivateAbility(struct UObject* WorldContextObject, int64_t Player, struct FString Ability, struct FVector& Location, struct FString FailureReason); // Function EmbarkServerEvents.EventAPI.FailedToActivateAbility // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x598bcb0
	void ExtractionTimerStarted(struct UObject* WorldContextObject, struct FString Name, int32_t ExtractionCycle); // Function EmbarkServerEvents.EventAPI.ExtractionTimerStarted // (Final|Native|Static|Public) // @ game+0x59b32c0
	void ExtractionPointStateChanged2(struct UObject* WorldContextObject, struct FString ExtractionPointName, struct FVector& ExtractionPointLocation, struct FString ExtractionPointType, struct FString OldState, struct FString NewState, struct FString GeneratedName); // Function EmbarkServerEvents.EventAPI.ExtractionPointStateChanged2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x597cb10
	void ExtractionPointStateChanged(struct UObject* WorldContextObject, struct FString ExtractionPointName, struct FVector& ExtractionPointLocation, struct FString ExtractionPointType, struct FString OldState, struct FString NewState); // Function EmbarkServerEvents.EventAPI.ExtractionPointStateChanged // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c5200
	void ExtractionPointRequiredItems(struct UObject* WorldContextObject, struct FString ExtractionPointName, struct FString InteractionName, struct TArray<struct FFieldTypeAssetIdAmount> RequiredItems); // Function EmbarkServerEvents.EventAPI.ExtractionPointRequiredItems // (Final|Native|Static|Public) // @ game+0x59da8e0
	void ExtractionFinalized(struct UObject* WorldContextObject, struct FString Name, int32_t PlayerAmount, int32_t ExtractionCycle); // Function EmbarkServerEvents.EventAPI.ExtractionFinalized // (Final|Native|Static|Public) // @ game+0x59a84f0
	void ExtractedInventorySlot7(struct UObject* WorldContextObject, int64_t Player, int64_t Amount, int64_t GameAssetId, struct FString InstanceId, struct FString Container, float Durability, float MaxDurability, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems); // Function EmbarkServerEvents.EventAPI.ExtractedInventorySlot7 // (Final|Native|Static|Public) // @ game+0x592cca0
	void ExplosiveBarrelSpawned(struct UObject* WorldContextObject, struct FVector& Location, struct FString Name); // Function EmbarkServerEvents.EventAPI.ExplosiveBarrelSpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5933ba0
	void ExpectedPlayersProxy(struct UObject* WorldContextObject, int64_t Amount, struct TArray<int64_t>& ExpectedPlayerIds); // Function EmbarkServerEvents.EventAPI.ExpectedPlayersProxy // (Final|Native|Static|Public|HasOutParms) // @ game+0x595a380
	void EventDropped(struct UObject* WorldContextObject, struct FString EventName, int64_t EventSize, int64_t StreamSize); // Function EmbarkServerEvents.EventAPI.EventDropped // (Final|Native|Static|Public) // @ game+0x59528e0
	void EquippedLoadoutFrame(struct UObject* WorldContextObject, int64_t Player, int64_t LoadoutFrameGameAssetId, int64_t AugmentGameAssetId); // Function EmbarkServerEvents.EventAPI.EquippedLoadoutFrame // (Final|Native|Static|Public) // @ game+0x593a810
	void EquipItemFailure(struct UObject* WorldContextObject, int64_t Player, struct FString SlotName, struct FString ItemName, struct FString FailureReason); // Function EmbarkServerEvents.EventAPI.EquipItemFailure // (Final|Native|Static|Public) // @ game+0x59240c0
	void EOSProductUserId(struct UObject* WorldContextObject, int64_t Player, struct FString ProductUserId); // Function EmbarkServerEvents.EventAPI.EOSProductUserId // (Final|Native|Static|Public) // @ game+0x5920650
	void EnvironmentLootSpawned2(struct UObject* WorldContextObject, struct FVector& Location, struct TArray<struct FString>& Tags, int64_t ItemAssetId, int64_t Amount, struct FString InstanceId); // Function EmbarkServerEvents.EventAPI.EnvironmentLootSpawned2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b1260
	void EnemyWeaponFired2(struct UObject* WorldContextObject, struct FString Weapon, struct FString ProjectileClass, struct FVector& Location, struct FVector& Direction, struct FString Enemy, int64_t EnemyId, int64_t TargetPlayer, int64_t TargetGameAssetId); // Function EmbarkServerEvents.EventAPI.EnemyWeaponFired2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a1440
	void EnemyStuck2(struct UObject* WorldContextObject, struct FString Enemy, struct FVector& Location, int64_t AssetId); // Function EmbarkServerEvents.EventAPI.EnemyStuck2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x597f7c0
	void EnemySpawned3(struct UObject* WorldContextObject, struct FString Enemy, struct FVector& Location, int64_t GroupId, int64_t EnemyId, int64_t EnemySpawnId, struct FString Alertness); // Function EmbarkServerEvents.EventAPI.EnemySpawned3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d9d80
	void EnemyPosition(struct UObject* WorldContextObject, int64_t EnemySpawnId, struct FVector& Location, struct FVector& ForwardVector, struct FVector& Velocity, struct FString Enemy, int64_t EnemyId); // Function EmbarkServerEvents.EventAPI.EnemyPosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d83c0
	void EnemyPhysicsKill(struct UObject* WorldContextObject, int64_t EnemyId, struct FVector& Location, struct FString DamageCauser, struct FString Target); // Function EmbarkServerEvents.EventAPI.EnemyPhysicsKill // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5927e00
	void EnemyPhysicsDamage2(struct UObject* WorldContextObject, int64_t EnemyId, float DamageTaken, struct FString PartHit, struct FVector& Location, bool bIsCriticalPart, struct FString DamageCauser, struct FString Target, struct TArray<struct FString>& TargetOngoingGameplayEffects); // Function EmbarkServerEvents.EventAPI.EnemyPhysicsDamage2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591a390
	void EnemyKill3(struct UObject* WorldContextObject, int64_t Player, int64_t EnemyId, int64_t WeaponId, int64_t ProjectileId, struct FVector& Location, struct FString DamageCauser, struct FString Target, struct FString WeaponInstanceId); // Function EmbarkServerEvents.EventAPI.EnemyKill3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x596f570
	void EnemyKill2(struct UObject* WorldContextObject, int64_t Player, int64_t EnemyId, int64_t WeaponId, int64_t ProjectileId, struct FVector& Location, struct FString DamageCauser, struct FString Target); // Function EmbarkServerEvents.EventAPI.EnemyKill2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x594d910
	void EnemyHit5(struct UObject* WorldContextObject, int64_t Player, struct FVector& PlayerLocation, int64_t WeaponGameAssetId, struct FString Enemy, int64_t EnemyGameAssetId, struct FVector& EnemyLocation, int64_t PartHitId, struct FString PartHit, bool bIsDestroyed, struct FString WeaponInstanceId); // Function EmbarkServerEvents.EventAPI.EnemyHit5 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5927730
	void EnemyHit4(struct UObject* WorldContextObject, int64_t Player, struct FVector& PlayerLocation, int64_t WeaponGameAssetId, struct FString Enemy, int64_t EnemyGameAssetId, struct FVector& EnemyLocation, int64_t PartHitId, struct FString PartHit, bool bIsDestroyed); // Function EmbarkServerEvents.EventAPI.EnemyHit4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59cc5b0
	void EnemyForceDestroyParts(struct UObject* WorldContextObject, int64_t EnemySpawnId, int64_t EnemyId, struct FVector& Location, struct FString Target, struct FString ExplosionEffectName, struct FString Querystring, struct FString TargetType); // Function EmbarkServerEvents.EventAPI.EnemyForceDestroyParts // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59be4b0
	void EnemyEvict2(struct UObject* WorldContextObject, struct FString Enemy, struct FVector& Location, int64_t EnemyId, bool bInCombat, struct FString Reason, int64_t EnemySpawnId); // Function EmbarkServerEvents.EventAPI.EnemyEvict2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59131d0
	void EnemyDestroyed2(struct UObject* WorldContextObject, int64_t EnemySpawnId, int64_t EnemyId, struct FVector& Location, struct FString Target, bool bSelfDestoyed, struct FString HealthChangeReason, int64_t AffectedPartID); // Function EmbarkServerEvents.EventAPI.EnemyDestroyed2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x598bf10
	void EnemyDamagePlayer5(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, struct FString Enemy, struct FVector& EnemyLocation, float HealthBefore, float HealthAfter, struct FString DamageCauser, bool bIsDbno, struct FString BoneHit, struct TArray<struct FString>& TargetOngoingGameplayEffects, float DbnoHealthBefore, float DbnoHealthAfter, bool bWasDbno, float ArmorHealthBefore, float ArmorHealthAfter, float ArmorMitigatedDamage); // Function EmbarkServerEvents.EventAPI.EnemyDamagePlayer5 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59bf780
	void EnemyDamage4(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString DamageCauser, int64_t WeaponId, struct FString Weapon, int64_t ProjectileId, struct FString Target, struct FVector& TargetLocation, int64_t EnemyId, int64_t PartID, struct FString PartHit, float DamageTaken, bool bIsCriticalPart, struct TArray<struct FString>& TargetOngoingGameplayEffects, struct FString WeaponInstanceId); // Function EmbarkServerEvents.EventAPI.EnemyDamage4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c65d0
	void EnemyDamage3(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString DamageCauser, int64_t WeaponId, struct FString Weapon, int64_t ProjectileId, struct FString Target, struct FVector& TargetLocation, int64_t EnemyId, int64_t PartID, struct FString PartHit, float DamageTaken, bool bIsCriticalPart, struct TArray<struct FString>& TargetOngoingGameplayEffects); // Function EmbarkServerEvents.EventAPI.EnemyDamage3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5969bc0
	void EnemyAlertNonPlayer(struct UObject* WorldContextObject, struct FString Enemy, struct FString NewAlertness, int64_t NewAlertnessIndex, struct FString OldAlertness, int64_t OldAlertnessIndex, struct FString AlertnessSource, struct FString LastTag, struct FVector& Location, int64_t EnemyId, int64_t TargetGameAssetId, float SightAlertness, float HearingAlertness, float DamageAlertness, float BypassAlertness, float NetworkAlertness, float TouchAlertness); // Function EmbarkServerEvents.EventAPI.EnemyAlertNonPlayer // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x596e810
	void EnemyAlert3(struct UObject* WorldContextObject, struct FString Enemy, struct FString NewAlertness, int64_t NewAlertnessIndex, struct FString OldAlertness, int64_t OldAlertnessIndex, struct FString AlertnessSource, struct FString LastTag, struct FVector& Location, int64_t EnemyId, int64_t TargetPlayer, int64_t TargetGameAssetId, float SightAlertness, float HearingAlertness, float DamageAlertness, float BypassAlertness, float NetworkAlertness, float TouchAlertness); // Function EmbarkServerEvents.EventAPI.EnemyAlert3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59bbd80
	void EnemyAbilityActivated(struct UObject* WorldContextObject, struct FString Enemy, int64_t EnemyId, struct FString AbilityTag, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.EnemyAbilityActivated // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c9be0
	void EndUseInstrument(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId, float Duration); // Function EmbarkServerEvents.EventAPI.EndUseInstrument // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x594a250
	void EndedAbility(struct UObject* WorldContextObject, int64_t Player, struct FString Ability, struct FVector& Location, bool bWasCancelled); // Function EmbarkServerEvents.EventAPI.EndedAbility // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d45c0
	void EmoteUsed2(struct UObject* WorldContextObject, int64_t Player, struct FString EmoteName, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.EmoteUsed2 // (Final|Native|Static|Public) // @ game+0x5909d00
	void EmoteUsed(struct UObject* WorldContextObject, int64_t Player, struct FString EmoteName); // Function EmbarkServerEvents.EventAPI.EmoteUsed // (Final|Native|Static|Public) // @ game+0x5920650
	void DualBladeDeflect(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t DeflectedGameAssetId, struct FString DeflectedItemName, struct FString DeflectedItemTag, int64_t InstigatorPlayer, struct FVector& InstigatorLocation, int64_t DeflectingItem); // Function EmbarkServerEvents.EventAPI.DualBladeDeflect // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59aed80
	void DropItem(struct UObject* WorldContextObject, int64_t Player, int64_t Amount, struct FVector& Location, int64_t GameAssetId, struct FString InstanceId, struct FString Container); // Function EmbarkServerEvents.EventAPI.DropItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5904fa0
	void DropCarriable(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString CarriableName); // Function EmbarkServerEvents.EventAPI.DropCarriable // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5925dd0
	void DisregardItem(struct UObject* WorldContextObject, int64_t PlayerId, int64_t GameAssetId, struct FString InstanceId, int32_t StackSize, struct FString LootContainer); // Function EmbarkServerEvents.EventAPI.DisregardItem // (Final|Native|Static|Public) // @ game+0x59b7c40
	void DisqualifiedRespawnGroup2(struct UObject* WorldContextObject, struct FString Ctx, struct FString GroupName, struct FVector& Location, int32_t SquadIndex, struct FString Reason); // Function EmbarkServerEvents.EventAPI.DisqualifiedRespawnGroup2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c93f0
	void DiscoXpRewardTelemetry(struct UObject* WorldContextObject, int64_t Player, int64_t BucketId, int64_t Amount, struct FString EventTag, int64_t ItemId); // Function EmbarkServerEvents.EventAPI.DiscoXpRewardTelemetry // (Final|Native|Static|Public) // @ game+0x5974bb0
	void DiscoWeaponHitThing3(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, int64_t WeaponId, struct FString Target, struct FVector& TargetLocation, float ChargingProgress); // Function EmbarkServerEvents.EventAPI.DiscoWeaponHitThing3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5956890
	void DiscoWeaponHitPlayer4(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, int64_t WeaponId, int64_t TargetPlayer, struct FVector& TargetLocation, bool bIsEnemy, bool bIsHeadshot, float ChargingProgress); // Function EmbarkServerEvents.EventAPI.DiscoWeaponHitPlayer4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59148b0
	void DiscoWeaponHitPlayer3(struct UObject* WorldContextObject, int64_t Player, struct FString Weapon, int64_t WeaponId, int64_t TargetPlayer, struct FVector& TargetLocation, bool bIsEnemy, bool bIsHeadshot); // Function EmbarkServerEvents.EventAPI.DiscoWeaponHitPlayer3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b2b60
	void DiscoViewToKill8(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, struct TArray<float>& KillerMovementInputX, struct TArray<float>& KillerMovementInputY, struct TArray<float>& KillerMovementInputZ, struct TArray<float>& KillerLookRotationVelocityPitch, struct TArray<float>& KillerLookRotationVelocityYaw, struct TArray<float>& VictimPosInKillerFrustumX, struct TArray<float>& VictimPosInKillerFrustumY, struct TArray<float>& VictimPosInKillerFrustumZ, struct TArray<bool>& IsUsingGamepad, struct TArray<bool>& IsFiring, struct TArray<float>& VictimVelocityInKillerFrustumX, struct TArray<float>& VictimVelocityInKillerFrustumY, struct TArray<float>& VictimVelocityInKillerFrustumZ, struct TArray<float>& KillerVelocityInKillerFrustumX, struct TArray<float>& KillerVelocityInKillerFrustumY, struct TArray<float>& KillerVelocityInKillerFrustumZ, struct TArray<bool>& IsAimAssistEnabled, struct TArray<float>& KillerLatencies); // Function EmbarkServerEvents.EventAPI.DiscoViewToKill8 // (Final|Native|Static|Public|HasOutParms) // @ game+0x595fe40
	void DiscoViewSample2(struct UObject* WorldContextObject, int64_t Player, struct TArray<float>& MovementInputX, struct TArray<float>& MovementInputY, struct TArray<float>& MovementInputZ, struct TArray<float>& LookRotationVelocityPitch, struct TArray<float>& LookRotationVelocityYaw, struct TArray<bool>& IsUsingGamepad); // Function EmbarkServerEvents.EventAPI.DiscoViewSample2 // (Final|Native|Static|Public|HasOutParms) // @ game+0x596d4c0
	void DiscoVaultSpawned4(struct UObject* WorldContextObject, int64_t VaultIndex, int32_t Cash, struct FVector& Location, struct FString LocationName, bool bIsInitialSpawn, int64_t Seed); // Function EmbarkServerEvents.EventAPI.DiscoVaultSpawned4 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5986980
	void DiscoVaultOpenStarted(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int32_t VaultIndex); // Function EmbarkServerEvents.EventAPI.DiscoVaultOpenStarted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591b5a0
	void DiscoVaultOpened(struct UObject* WorldContextObject, int32_t VaultIndex, struct FVector& Location, int32_t CaseAmount); // Function EmbarkServerEvents.EventAPI.DiscoVaultOpened // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5982540
	void DiscoUseRespawnCredit(struct UObject* WorldContextObject, int64_t Player, int32_t RemainingRespawnCredits); // Function EmbarkServerEvents.EventAPI.DiscoUseRespawnCredit // (Final|Native|Static|Public) // @ game+0x593bc60
	void DiscoUpdatedLoadoutItem3(struct UObject* WorldContextObject, int64_t Player, struct FString Item, int64_t ItemId, struct FString LoadoutUpdateId, struct TArray<int64_t>& WeaponAttachmentIds, bool bIsActiveGameplay); // Function EmbarkServerEvents.EventAPI.DiscoUpdatedLoadoutItem3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x59c4c90
	void DiscoUIRoundStateChange(struct UObject* WorldContextObject, struct FString State); // Function EmbarkServerEvents.EventAPI.DiscoUIRoundStateChange // (Final|Native|Static|Public) // @ game+0x59134c0
	void DiscoTriggerRemoteItem(struct UObject* WorldContextObject, int64_t Player, struct FString ProjectileName, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoTriggerRemoteItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590b130
	void DiscoTransferPointSpawned3(struct UObject* WorldContextObject, int32_t TransferPointId, int32_t TransferPointIndex, struct FVector& Location, struct FString LocationName, bool bFromPrioritizedPool, bool bIsInitialSpawn, int64_t Seed); // Function EmbarkServerEvents.EventAPI.DiscoTransferPointSpawned3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5997830
	void DiscoTransferPointSpawned(struct UObject* WorldContextObject, int32_t TransferPointId, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoTransferPointSpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x596e3c0
	void DiscoTransferPointPosition(struct UObject* WorldContextObject, int32_t TransferPointId, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoTransferPointPosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x596e3c0
	void DiscoTransferPointDespawned(struct UObject* WorldContextObject, int32_t TransferPointId, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoTransferPointDespawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x596e3c0
	void DiscoTransferCompleted2(struct UObject* WorldContextObject, struct FVector& Location, int32_t TransferPointId, int32_t TransferPointIndex, int32_t Cash, int32_t SquadIndex); // Function EmbarkServerEvents.EventAPI.DiscoTransferCompleted2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a5ca0
	void DiscoTournamentWon(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.DiscoTournamentWon // (Final|Native|Static|Public) // @ game+0x591e350
	void DiscoTombstoneRespawn(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation); // Function EmbarkServerEvents.EventAPI.DiscoTombstoneRespawn // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5915990
	void DiscoTicketSpawn2(struct UObject* WorldContextObject, int32_t TicketIndex, struct FVector& Location, int32_t Cash); // Function EmbarkServerEvents.EventAPI.DiscoTicketSpawn2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5982540
	void DiscoTicketPosition2(struct UObject* WorldContextObject, int32_t TicketIndex, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoTicketPosition2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x596e3c0
	void DiscoTicketPickup2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int32_t TicketIndex); // Function EmbarkServerEvents.EventAPI.DiscoTicketPickup2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591b5a0
	void DiscoTicketInserted3(struct UObject* WorldContextObject, int64_t Player, int32_t TicketIndex, struct FVector& Location, int32_t TransferPointId, int32_t TransferPointIndex, int32_t Cash); // Function EmbarkServerEvents.EventAPI.DiscoTicketInserted3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b2470
	void DiscoTicketDrop2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int32_t TicketIndex); // Function EmbarkServerEvents.EventAPI.DiscoTicketDrop2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591b5a0
	void DiscoThingDamage(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString Target, struct FVector& TargetLocation, int64_t WeaponGameAssetId, float DamageTaken, float PreviousHealth, float CurrentHealth, struct FString DamageTypeTag, struct FString SourceTag, float Distance); // Function EmbarkServerEvents.EventAPI.DiscoThingDamage // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5961880
	void DiscoSquadWiped2(struct UObject* WorldContextObject, int64_t SquadId); // Function EmbarkServerEvents.EventAPI.DiscoSquadWiped2 // (Final|Native|Static|Public) // @ game+0x591e350
	void DiscoSquadRoundCurrencyChanged2(struct UObject* WorldContextObject, int32_t SquadId, int32_t PreviousRoundCurrency, int32_t CurrentRoundCurrency, int32_t RoundCurrencyDelta, struct FString Source); // Function EmbarkServerEvents.EventAPI.DiscoSquadRoundCurrencyChanged2 // (Final|Native|Static|Public) // @ game+0x5917ca0
	void DiscoSelfDamage2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString Causer, int64_t CauserId, float DamageTaken, float PreviousHealth, float CurrentHealth, int32_t DamageType, bool bIsDbno, struct FString DamageTypeTag, struct FString SourceTag); // Function EmbarkServerEvents.EventAPI.DiscoSelfDamage2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5948f10
	void DiscoSelectedWeaponSticker2(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId, int64_t WeaponGameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedWeaponSticker2 // (Final|Native|Static|Public) // @ game+0x596a9b0
	void DiscoSelectedWeaponSkin2(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId, int64_t WeaponGameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedWeaponSkin2 // (Final|Native|Static|Public) // @ game+0x596a9b0
	void DiscoSelectedWeaponCharm2(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId, int64_t WeaponGameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedWeaponCharm2 // (Final|Native|Static|Public) // @ game+0x596a9b0
	void DiscoSelectedWeaponAttachment2(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId, int64_t WeaponGameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedWeaponAttachment2 // (Final|Native|Static|Public) // @ game+0x596a9b0
	void DiscoSelectedWeaponAnimation2(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId, int64_t WeaponGameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedWeaponAnimation2 // (Final|Native|Static|Public) // @ game+0x596a9b0
	void DiscoSelectedWatch(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedWatch // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedSpray(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedSpray // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedSoundEffect(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedSoundEffect // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedPose(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId, struct FString PoseType); // Function EmbarkServerEvents.EventAPI.DiscoSelectedPose // (Final|Native|Static|Public) // @ game+0x597ea00
	void DiscoSelectedPet(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedPet // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedObjectiveSticker(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedObjectiveSticker // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedHandGesture(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedHandGesture // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedEmoticon(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedEmoticon // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoSelectedEmote(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoSelectedEmote // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoRoundTravelToNextStage(struct UObject* WorldContextObject, struct FString NextMatchId); // Function EmbarkServerEvents.EventAPI.DiscoRoundTravelToNextStage // (Final|Native|Static|Public) // @ game+0x59134c0
	void DiscoRoundCurrencyChanged2(struct UObject* WorldContextObject, int64_t Player, int32_t PreviousRoundCurrency, int32_t CurrentRoundCurrency, int32_t RoundCurrencyDelta, struct FString Source); // Function EmbarkServerEvents.EventAPI.DiscoRoundCurrencyChanged2 // (Final|Native|Static|Public) // @ game+0x5913760
	void DiscoRespawnSummary(struct UObject* WorldContextObject, int64_t Player, int64_t RemainingRespawnTokens, bool bUsedRespawnToken, bool bTeamWipeRespawn, bool bWasRevivedRespawn, bool bWasDefibRevived, struct FString RespawnReason); // Function EmbarkServerEvents.EventAPI.DiscoRespawnSummary // (Final|Native|Static|Public) // @ game+0x5938cc0
	void DiscoRespawn(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int32_t RemainingRespawnCredits); // Function EmbarkServerEvents.EventAPI.DiscoRespawn // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x591b5a0
	void DiscoReserveItem2(struct UObject* WorldContextObject, int64_t Player, struct FString Item, int64_t ItemId, struct TArray<int64_t>& WeaponAttachmentIds); // Function EmbarkServerEvents.EventAPI.DiscoReserveItem2 // (Final|Native|Static|Public|HasOutParms) // @ game+0x594ece0
	void DiscoQuestCompleted2(struct UObject* WorldContextObject, int64_t Player, struct FString QuestInstanceId, int64_t QuestAssetId, int64_t CircuitId, int64_t StageId); // Function EmbarkServerEvents.EventAPI.DiscoQuestCompleted2 // (Final|Native|Static|Public) // @ game+0x598b450
	void DiscoQuestCompleted(struct UObject* WorldContextObject, int64_t Player, struct FString QuestInstanceId, int64_t QuestAssetId); // Function EmbarkServerEvents.EventAPI.DiscoQuestCompleted // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoPreLoginEvent(struct UObject* WorldContextObject, int64_t Player, bool bIsAllowedToConnect); // Function EmbarkServerEvents.EventAPI.DiscoPreLoginEvent // (Final|Native|Static|Public) // @ game+0x592e6c0
	void DiscoPlayerWorldTourInfo(struct UObject* WorldContextObject, int64_t Player, bool bIsWorldTourFinals); // Function EmbarkServerEvents.EventAPI.DiscoPlayerWorldTourInfo // (Final|Native|Static|Public) // @ game+0x592e6c0
	void DiscoPlayerStartSteal(struct UObject* WorldContextObject, int64_t Player, int32_t TransferPointId, int32_t Cash); // Function EmbarkServerEvents.EventAPI.DiscoPlayerStartSteal // (Final|Native|Static|Public) // @ game+0x5963810
	void DiscoPlayerStartingInfo(struct UObject* WorldContextObject, int64_t Player, int32_t StartingRespawnCredits); // Function EmbarkServerEvents.EventAPI.DiscoPlayerStartingInfo // (Final|Native|Static|Public) // @ game+0x593bc60
	void DiscoPlayerSquadWiped(struct UObject* WorldContextObject, int64_t Player, int64_t SquadId); // Function EmbarkServerEvents.EventAPI.DiscoPlayerSquadWiped // (Final|Native|Static|Public) // @ game+0x590e710
	void DiscoPlayerSpawn2(struct UObject* WorldContextObject, int64_t Player, int64_t SquadId, struct FString Squad, struct FVector& Location, struct FString CharacterArchetype, struct FString GameMode, struct FString MapName, struct FString Deck); // Function EmbarkServerEvents.EventAPI.DiscoPlayerSpawn2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5940f20
	void DiscoPlayerHealPlayer(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer, int64_t GameAssetId, float AmountHealed); // Function EmbarkServerEvents.EventAPI.DiscoPlayerHealPlayer // (Final|Native|Static|Public) // @ game+0x5973730
	void DiscoPlayerHeal(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, struct FString Causer, float AmountHealed, float PreviousHealth, float CurrentHealth, bool bIsDbno); // Function EmbarkServerEvents.EventAPI.DiscoPlayerHeal // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5922920
	void DiscoPlayerFinishSteal(struct UObject* WorldContextObject, int64_t Player, int32_t TransferPointId, int32_t Cash); // Function EmbarkServerEvents.EventAPI.DiscoPlayerFinishSteal // (Final|Native|Static|Public) // @ game+0x5963810
	void DiscoPlayerEliminated(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoPlayerEliminated // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void DiscoPlayerDisconnect(struct UObject* WorldContextObject, int64_t Player, struct FString Reason); // Function EmbarkServerEvents.EventAPI.DiscoPlayerDisconnect // (Final|Native|Static|Public) // @ game+0x5920650
	void DiscoPlayerDie(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoPlayerDie // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void DiscoPlayerDepartedTournament(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.DiscoPlayerDepartedTournament // (Final|Native|Static|Public) // @ game+0x591e350
	void DiscoPlayerAbandonedTournament(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.DiscoPlayerAbandonedTournament // (Final|Native|Static|Public) // @ game+0x591e350
	void DiscoPickupArenaItem(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString ItemName); // Function EmbarkServerEvents.EventAPI.DiscoPickupArenaItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5925dd0
	void DiscoLoadoutItem3(struct UObject* WorldContextObject, int64_t Player, struct FString Item, int64_t ItemId, struct TArray<int64_t>& WeaponAttachmentIds); // Function EmbarkServerEvents.EventAPI.DiscoLoadoutItem3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x594ece0
	void DiscoKillAssist(struct UObject* WorldContextObject, int64_t Player, int64_t TargetPlayer); // Function EmbarkServerEvents.EventAPI.DiscoKillAssist // (Final|Native|Static|Public) // @ game+0x590e710
	void DiscoItemUse2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString Name, int64_t ItemId, int32_t AmountBefore, int32_t AmountNow, struct FString DefaultInstigatorTag); // Function EmbarkServerEvents.EventAPI.DiscoItemUse2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59900e0
	void DiscoItemUsageStat2(struct UObject* WorldContextObject, int64_t Player, int64_t ItemId, struct FString Tag, float Modifier, float Usage, struct FString Description, struct FString Archetype); // Function EmbarkServerEvents.EventAPI.DiscoItemUsageStat2 // (Final|Native|Static|Public) // @ game+0x59d5d40
	void DiscoItemDeadTelemetry(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, struct FVector& ItemLocation, int64_t GameAssetId, bool bDestroyed); // Function EmbarkServerEvents.EventAPI.DiscoItemDeadTelemetry // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59375f0
	void DiscoHealthChanged3(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString Causer, float DamageTaken, float PreviousHealth, float CurrentHealth, int32_t DamageType, bool bIsDbno, struct FString DamageTypeTag, struct FString SourceTag); // Function EmbarkServerEvents.EventAPI.DiscoHealthChanged3 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5946a50
	void DiscoGraveShiftSubRoundSummary(struct UObject* WorldContextObject, int64_t SubroundCount, struct FString SubroundId, struct FString EndReason, int32_t Survivors, int32_t Monsters); // Function EmbarkServerEvents.EventAPI.DiscoGraveShiftSubRoundSummary // (Final|Native|Static|Public) // @ game+0x5980aa0
	void DiscoGraveShiftPlayerStateChanged(struct UObject* WorldContextObject, int64_t Player, int64_t SubroundCount, struct FString SubroundId, int32_t PreviousState, int32_t CurrentState); // Function EmbarkServerEvents.EventAPI.DiscoGraveShiftPlayerStateChanged // (Final|Native|Static|Public) // @ game+0x5995d70
	void DiscoGrabArenaItem(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString Name, float TimeElapsedSincePickup); // Function EmbarkServerEvents.EventAPI.DiscoGrabArenaItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590efb0
	void DiscoGameModeStart3(struct UObject* WorldContextObject, struct FString EnvironmentalCondition, struct FString VariantName, struct TArray<struct FString>& RandomGameShowEvents, bool bIsPractice, bool bIsRanked, bool bIsCasual, bool bIsWorldTour, struct FString GameModeName, struct FString MapName); // Function EmbarkServerEvents.EventAPI.DiscoGameModeStart3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x59dc6e0
	void DiscoGameModeRequest(struct UObject* WorldContextObject, struct FString DesiredGameMode, struct FString ResultingGameMode); // Function EmbarkServerEvents.EventAPI.DiscoGameModeRequest // (Final|Native|Static|Public) // @ game+0x5941ca0
	void DiscoFracturedDamageTarget(struct UObject* WorldContextObject, struct FString FracturedClass, float AccumulatedDamage, int32_t DestroyedBones); // Function EmbarkServerEvents.EventAPI.DiscoFracturedDamageTarget // (Final|Native|Static|Public) // @ game+0x59c1630
	void DiscoFracturedDamageSource(struct UObject* WorldContextObject, struct FString InstigatorTag, float AccumulatedDamage, int32_t DestroyedBones); // Function EmbarkServerEvents.EventAPI.DiscoFracturedDamageSource // (Final|Native|Static|Public) // @ game+0x59c1630
	void DiscoFracturedDamage(struct UObject* WorldContextObject, int64_t Player, float Damage, struct FString DamageState, struct FString BoneName, struct FVector& ImpactPoint, struct FString FracturedClass, struct FString SourceTag, struct FString CauserName, int64_t GameAssetId, float Distance); // Function EmbarkServerEvents.EventAPI.DiscoFracturedDamage // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5932100
	void DiscoFlashbangResult(struct UObject* WorldContextObject, int64_t Player, int64_t ExplosionId, struct FVector& EyeLocation, float Distance, float ViewFalloff, float Intensity, struct FString TargetType, struct FString HitType); // Function EmbarkServerEvents.EventAPI.DiscoFlashbangResult // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5955580
	void DiscoFlashbangExplosion(struct UObject* WorldContextObject, int64_t Player, int64_t ExplosionId, struct FVector& Location, struct FString ItemName, int64_t GameAssetId, struct FString SourceTag); // Function EmbarkServerEvents.EventAPI.DiscoFlashbangExplosion // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59adb40
	void DiscoFansAdded2(struct UObject* WorldContextObject, int64_t Player, int64_t Fans, int64_t Sponsor, struct FString ProgressionEventTag, int64_t CircuitStageId); // Function EmbarkServerEvents.EventAPI.DiscoFansAdded2 // (Final|Native|Static|Public) // @ game+0x5974bb0
	void DiscoEquippingItem(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.DiscoEquippingItem // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoEquipItem2(struct UObject* WorldContextObject, int64_t Player, struct FString ItemName, int64_t GameAssetId, struct FString DefaultInstigatorTag); // Function EmbarkServerEvents.EventAPI.DiscoEquipItem2 // (Final|Native|Static|Public) // @ game+0x597ea00
	void DiscoEnemyKilled(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation); // Function EmbarkServerEvents.EventAPI.DiscoEnemyKilled // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5915990
	void DiscoEnemyDamage8(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, struct FString Causer, int64_t CauserId, float DamageTaken, float PreviousHealth, float CurrentHealth, int32_t DamageType, bool bIsDbno, struct FString DamageTypeTag, bool bIsHeadshot, struct FString SourceTag, float Distance, struct TArray<struct FString>& TargetOngoingGameplayEffects); // Function EmbarkServerEvents.EventAPI.DiscoEnemyDamage8 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5954940
	void DiscoEndRoundPlacement(struct UObject* WorldContextObject, int64_t Player, int64_t Place); // Function EmbarkServerEvents.EventAPI.DiscoEndRoundPlacement // (Final|Native|Static|Public) // @ game+0x590e710
	void DiscoDropArenaItem(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FString ItemName, struct FString DropType); // Function EmbarkServerEvents.EventAPI.DiscoDropArenaItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5927e00
	void DiscoDefibRespawn(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation); // Function EmbarkServerEvents.EventAPI.DiscoDefibRespawn // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5915990
	void DiscoCloakedBackHit(struct UObject* WorldContextObject, int64_t Player); // Function EmbarkServerEvents.EventAPI.DiscoCloakedBackHit // (Final|Native|Static|Public) // @ game+0x591e350
	void DiscoCharacterCustomizationItem(struct UObject* WorldContextObject, int64_t Player, struct FString Item, int64_t ItemId); // Function EmbarkServerEvents.EventAPI.DiscoCharacterCustomizationItem // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoChallengeStarted3(struct UObject* WorldContextObject, int64_t Player, int64_t ChallengeAssetId, struct FString ChallengeInstanceId, int32_t ParticipantsNumber, int64_t ChallengeGroupAssetId, struct TArray<int64_t>& ItemIds, struct FString CharacterArchetype); // Function EmbarkServerEvents.EventAPI.DiscoChallengeStarted3 // (Final|Native|Static|Public|HasOutParms) // @ game+0x59d3310
	void DiscoChallengeResult3(struct UObject* WorldContextObject, int64_t Player, int64_t ChallengeAssetId, struct FString ChallengeInstanceId, float Score, float Duration, int32_t ParticipantsNumber, bool bSuccess, struct FString ScoreType, int64_t ChallengeGroupAssetId); // Function EmbarkServerEvents.EventAPI.DiscoChallengeResult3 // (Final|Native|Static|Public) // @ game+0x596caa0
	void DiscoCaseSpawned(struct UObject* WorldContextObject, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DiscoCaseSpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59634c0
	void DiscoCasePickup(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, struct FVector& CaseLocation, int32_t PreviousCash, int32_t CaseValue); // Function EmbarkServerEvents.EventAPI.DiscoCasePickup // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59100f0
	void DiscoBankItTransferStarted(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int32_t TransferPointId, struct FVector& TransferPointLocation, int32_t Cash, int32_t SquadIndex); // Function EmbarkServerEvents.EventAPI.DiscoBankItTransferStarted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a0030
	void DiscoBankItTransferCompleted(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int32_t TransferPointId, struct FVector& TransferPointLocation, int32_t Cash, int32_t SquadIndex); // Function EmbarkServerEvents.EventAPI.DiscoBankItTransferCompleted // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59a0030
	void DiscoBallPassCaught(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t PassingPlayer, struct FVector& PassingLocation, int32_t PreviousCharge, int32_t NewCharge); // Function EmbarkServerEvents.EventAPI.DiscoBallPassCaught // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5922fd0
	void DiscoAssignPlayerSquad(struct UObject* WorldContextObject, int64_t Player, int64_t SquadId, struct FString Squad); // Function EmbarkServerEvents.EventAPI.DiscoAssignPlayerSquad // (Final|Native|Static|Public) // @ game+0x59135b0
	void DiscoArchetypeSummary(struct UObject* WorldContextObject, int64_t Player, struct FString Archetype, int64_t TimeUsed); // Function EmbarkServerEvents.EventAPI.DiscoArchetypeSummary // (Final|Native|Static|Public) // @ game+0x5909d00
	void DiscoArchetypeChanged(struct UObject* WorldContextObject, int64_t Player, struct FString OldArchetype, struct FString NewArchetype, struct FString LoadoutUpdateId); // Function EmbarkServerEvents.EventAPI.DiscoArchetypeChanged // (Final|Native|Static|Public) // @ game+0x59240c0
	void DiscoAnonymousName(struct UObject* WorldContextObject, int64_t Player, struct FString AnonymousName); // Function EmbarkServerEvents.EventAPI.DiscoAnonymousName // (Final|Native|Static|Public) // @ game+0x5920650
	void DiscoAddRankBucketRewardXp(struct UObject* WorldContextObject, int64_t Player, int64_t BucketId, int64_t Amount); // Function EmbarkServerEvents.EventAPI.DiscoAddRankBucketRewardXp // (Final|Native|Static|Public) // @ game+0x593a810
	void DiedInventorySlot7(struct UObject* WorldContextObject, int64_t Player, int64_t Amount, int64_t GameAssetId, struct FString InstanceId, struct FString Container, float Durability, float MaxDurability, struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems); // Function EmbarkServerEvents.EventAPI.DiedInventorySlot7 // (Final|Native|Static|Public) // @ game+0x592cca0
	void DevInstanceKey(struct UObject* WorldContextObject, struct FString DevInstanceKey); // Function EmbarkServerEvents.EventAPI.DevInstanceKey // (Final|Native|Static|Public) // @ game+0x59134c0
	void DestructionStartSimulate(struct UObject* WorldContextObject, int64_t Size, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DestructionStartSimulate // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x593a0b0
	void DestructionRuntimeGraphComplete(struct UObject* WorldContextObject, float BuildTime, int32_t BoneCount, int32_t SimpleCount, int32_t ConnectionCount); // Function EmbarkServerEvents.EventAPI.DestructionRuntimeGraphComplete // (Final|Native|Static|Public) // @ game+0x59c80c0
	void DestructionMatchReport(struct UObject* WorldContextObject, int32_t TotalBones, int32_t BonesDestroyed, int32_t TotalSimulatedBones, int32_t TotalConnections, int32_t TotalBrokenConnections); // Function EmbarkServerEvents.EventAPI.DestructionMatchReport // (Final|Native|Static|Public) // @ game+0x596ff60
	void DestructionCutConnection(struct UObject* WorldContextObject, int64_t StrainConnects, int64_t BrokenLinks); // Function EmbarkServerEvents.EventAPI.DestructionCutConnection // (Final|Native|Static|Public) // @ game+0x590e710
	void DestructionBoneDestroyed(struct UObject* WorldContextObject, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.DestructionBoneDestroyed // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59634c0
	void DeliverItem(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, struct FVector& DropZoneLocation, struct FString DropZoneName); // Function EmbarkServerEvents.EventAPI.DeliverItem // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59173e0
	void DeliverCarriable(struct UObject* WorldContextObject, int64_t Player, struct FString CarriableName, struct FVector& DropZoneLocation, struct FString DropZoneName); // Function EmbarkServerEvents.EventAPI.DeliverCarriable // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x598bcb0
	void DefibReviveFailed(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, float PlayerPing, float TargetPlayerPing, struct FString Reason); // Function EmbarkServerEvents.EventAPI.DefibReviveFailed // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59b55a0
	void DeathMatchTeam(struct UObject* WorldContextObject, int64_t Player, int64_t SquadId, struct FString SubroundId); // Function EmbarkServerEvents.EventAPI.DeathMatchTeam // (Final|Native|Static|Public) // @ game+0x59135b0
	void DeathMatchSubroundWin(struct UObject* WorldContextObject, int64_t Player, struct FString SubroundId, struct FString EndReason, int64_t SquadId); // Function EmbarkServerEvents.EventAPI.DeathMatchSubroundWin // (Final|Native|Static|Public) // @ game+0x59224d0
	void DeathMatchSubroundStarted3(struct UObject* WorldContextObject, struct FString SubroundId, struct FString RoundState, struct FString Scenario); // Function EmbarkServerEvents.EventAPI.DeathMatchSubroundStarted3 // (Final|Native|Static|Public) // @ game+0x594a4e0
	void DeathMatchSubroundLoss(struct UObject* WorldContextObject, int64_t Player, struct FString SubroundId, struct FString EndReason, int64_t SquadId); // Function EmbarkServerEvents.EventAPI.DeathMatchSubroundLoss // (Final|Native|Static|Public) // @ game+0x59224d0
	void DdosSeverityEscalation(struct UObject* WorldContextObject, struct FString Severity); // Function EmbarkServerEvents.EventAPI.DdosSeverityEscalation // (Final|Native|Static|Public) // @ game+0x59134c0
	void CreatePing2(struct UObject* WorldContextObject, int64_t CreatorPlayer, int32_t PingId, struct FString Intent, struct FString Object, struct FString DialogueTag, struct TArray<struct FString>& AdditionalTags, struct FVector& PingerLocation, struct FVector& PingedLocation); // Function EmbarkServerEvents.EventAPI.CreatePing2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x592c840
	void ColonyRunLoadout(struct UObject* WorldContextObject, int64_t Player, int64_t LoadoutId); // Function EmbarkServerEvents.EventAPI.ColonyRunLoadout // (Final|Native|Static|Public) // @ game+0x590e710
	void ChosenSpawnPoint2(struct UObject* WorldContextObject, int64_t Player, struct FString SpawnPointName, struct FString Source); // Function EmbarkServerEvents.EventAPI.ChosenSpawnPoint2 // (Final|Native|Static|Public) // @ game+0x59a5f20
	void CharacterSkillInitialized(struct UObject* WorldContextObject, int64_t Player, int64_t CharacterSkillAssetId, int64_t Level); // Function EmbarkServerEvents.EventAPI.CharacterSkillInitialized // (Final|Native|Static|Public) // @ game+0x593a810
	void CharacterCustomization2(struct UObject* WorldContextObject, int64_t Player, struct TArray<int64_t>& GameAssetId, int64_t OutfitGameAssetId); // Function EmbarkServerEvents.EventAPI.CharacterCustomization2 // (Final|Native|Static|Public|HasOutParms) // @ game+0x59dc530
	void CarriableSpawned(struct UObject* WorldContextObject, struct FString CarriableName, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.CarriableSpawned // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5966c40
	void BulletHitRejected2(struct UObject* WorldContextObject, int64_t Player, int64_t RejectionType, struct FVector& ClientHitLocation, struct FVector& ServerHitLocation, struct FVector& ShooterLocation, float ThresholdValue); // Function EmbarkServerEvents.EventAPI.BulletHitRejected2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5906ec0
	void BulletHitRejected(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t RejectionType, float ThresholdValue); // Function EmbarkServerEvents.EventAPI.BulletHitRejected // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x594a250
	void BotTargetChanged(struct UObject* WorldContextObject, int64_t Player, struct FString Target); // Function EmbarkServerEvents.EventAPI.BotTargetChanged // (Final|Native|Static|Public) // @ game+0x5920650
	void BotDefensiveTargetChanged(struct UObject* WorldContextObject, int64_t Player, struct FString Target); // Function EmbarkServerEvents.EventAPI.BotDefensiveTargetChanged // (Final|Native|Static|Public) // @ game+0x5920650
	void BonusReward(struct UObject* WorldContextObject, int64_t Player, int64_t GameAssetId, float Multiplier, int64_t Amount); // Function EmbarkServerEvents.EventAPI.BonusReward // (Final|Native|Static|Public) // @ game+0x59a8c10
	void BeginUseInstrument(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t GameAssetId); // Function EmbarkServerEvents.EventAPI.BeginUseInstrument // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d4c90
	void BattlepassUltimateXPBonus(struct UObject* WorldContextObject, int64_t Player, int32_t UltimateBpBonusXp); // Function EmbarkServerEvents.EventAPI.BattlepassUltimateXPBonus // (Final|Native|Static|Public) // @ game+0x593bc60
	void BadBadFrame2(struct UObject* WorldContextObject, int64_t DeltaTimeMs, int64_t AdjustedFrameNumber, struct TArray<float>& FrameComponents); // Function EmbarkServerEvents.EventAPI.BadBadFrame2 // (Final|Native|Static|Public|HasOutParms) // @ game+0x59d0690
	void AwardEndOfRoundScorecardGrade3(struct UObject* WorldContextObject, int64_t Player, int64_t ScorecardGradeAssetId, int32_t ScorecardGradeLevel, float ScorecardGradeScore); // Function EmbarkServerEvents.EventAPI.AwardEndOfRoundScorecardGrade3 // (Final|Native|Static|Public) // @ game+0x599b940
	void AwardEndOfRoundScorecardGrade2(struct UObject* WorldContextObject, int64_t Player, int64_t ScorecardGradeAssetId, int32_t ScorecardGradeLevel); // Function EmbarkServerEvents.EventAPI.AwardEndOfRoundScorecardGrade2 // (Final|Native|Static|Public) // @ game+0x59ae9f0
	void AutobotSpawned(struct UObject* WorldContextObject, int64_t Player, bool bIsServerBot); // Function EmbarkServerEvents.EventAPI.AutobotSpawned // (Final|Native|Static|Public) // @ game+0x592e6c0
	void AttackDefendTeam(struct UObject* WorldContextObject, int64_t Player, struct FString Team, struct FString SubroundId); // Function EmbarkServerEvents.EventAPI.AttackDefendTeam // (Final|Native|Static|Public) // @ game+0x59a5f20
	void AttackDefendSquadAbandon(struct UObject* WorldContextObject, int64_t SquadIndex); // Function EmbarkServerEvents.EventAPI.AttackDefendSquadAbandon // (Final|Native|Static|Public) // @ game+0x591e350
	void AssignedSessionSeed(struct UObject* WorldContextObject, int64_t Seed); // Function EmbarkServerEvents.EventAPI.AssignedSessionSeed // (Final|Native|Static|Public) // @ game+0x591e350
	void ArmorModSet2(struct UObject* WorldContextObject, int64_t Player, int64_t ArmorGameAssetId, struct FString ArmorName, struct FString ArmorInstanceId, int64_t ModGameAssetId, struct FString ModName, struct FString ModInstanceId); // Function EmbarkServerEvents.EventAPI.ArmorModSet2 // (Final|Native|Static|Public) // @ game+0x5951630
	void ArmorModRemoved2(struct UObject* WorldContextObject, int64_t Player, int64_t ArmorGameAssetId, struct FString ArmorName, struct FString ArmorInstanceId, int64_t ModGameAssetId, struct FString ModName, struct FString ModInstanceId); // Function EmbarkServerEvents.EventAPI.ArmorModRemoved2 // (Final|Native|Static|Public) // @ game+0x5951630
	void AppInfo(struct UObject* WorldContextObject, struct FString AppId, struct FString BranchName, struct FString CountryCode, int64_t Player); // Function EmbarkServerEvents.EventAPI.AppInfo // (Final|Native|Static|Public) // @ game+0x592bbf0
	void AntiCheatRpcMismatch(struct UObject* WorldContextObject, int64_t Player, struct FString Name, int32_t Count); // Function EmbarkServerEvents.EventAPI.AntiCheatRpcMismatch // (Final|Native|Static|Public) // @ game+0x590c080
	void AntiCheatPlayerActionRequiredServer(struct UObject* WorldContextObject, int64_t Player, struct FString ClientAction, struct FString Reason, struct FString Details); // Function EmbarkServerEvents.EventAPI.AntiCheatPlayerActionRequiredServer // (Final|Native|Static|Public) // @ game+0x59240c0
	void AntiCheatAuthIntegrity(struct UObject* WorldContextObject, int64_t Player, struct FString Details); // Function EmbarkServerEvents.EventAPI.AntiCheatAuthIntegrity // (Final|Native|Static|Public) // @ game+0x5920650
	void AngelscriptServerError2(struct UObject* WorldContextObject, struct FString Source, struct FString Message, struct TArray<struct FString>& Trace); // Function EmbarkServerEvents.EventAPI.AngelscriptServerError2 // (Final|Native|Static|Public|HasOutParms) // @ game+0x590ff00
	void AnchorAttached2(struct UObject* WorldContextObject, int64_t Player, struct FVector& Location, int64_t TargetPlayer, struct FVector& TargetLocation, struct FVector& AnchorLocation, int64_t CreationFrame, int64_t CurrentCharacters, int64_t CurrentObjects); // Function EmbarkServerEvents.EventAPI.AnchorAttached2 // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5909370
	void AINavigationNavmeshSwap(struct UObject* WorldContextObject, struct FString Enemy, struct FVector& Location, struct FString PreviousNavmesh, struct FString CurrentNavmesh, int64_t AssetId); // Function EmbarkServerEvents.EventAPI.AINavigationNavmeshSwap // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59d2920
	void AimingValidationFailed(struct UObject* WorldContextObject, int64_t Player, float PlayerPing, struct FVector& ClientAimingLocation, struct FString Reason); // Function EmbarkServerEvents.EventAPI.AimingValidationFailed // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59394c0
	void AimBasedForceApplication(struct UObject* WorldContextObject, int64_t Player, float ForceMagnitude, struct FVector& Location, struct FString Target, int64_t TargetId); // Function EmbarkServerEvents.EventAPI.AimBasedForceApplication // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59ae180
	void AddQuestProgress3(struct UObject* WorldContextObject, int64_t Player, struct FString QuestInstanceId, int64_t QuestAssetId, int64_t DeltaAmount, int64_t Amount); // Function EmbarkServerEvents.EventAPI.AddQuestProgress3 // (Final|Native|Static|Public) // @ game+0x598b450
	void AddPersistedItem(struct UObject* WorldContextObject, int64_t Player, struct FString Source, int64_t GameAssetId, struct FString AssetType, int64_t Amount, struct TArray<int64_t>& Breakthroughs); // Function EmbarkServerEvents.EventAPI.AddPersistedItem // (Final|Native|Static|Public|HasOutParms) // @ game+0x59af9d0
	void AddNewBounty(struct UObject* WorldContextObject, int64_t Player, int32_t Amount); // Function EmbarkServerEvents.EventAPI.AddNewBounty // (Final|Native|Static|Public) // @ game+0x593bc60
	void ActorStuckUnderground(struct UObject* WorldContextObject, struct FString ActorName, struct FVector& Location, struct FVector& Rotation, struct FString HitActorName); // Function EmbarkServerEvents.EventAPI.ActorStuckUnderground // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59c2730
	void ActorHealthChange(struct UObject* WorldContextObject, struct FString Name, struct FVector& Location, float PreviousHealth, float CurrentHealth, int64_t GameAssetId, struct FString BoneName); // Function EmbarkServerEvents.EventAPI.ActorHealthChange // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x59bd300
	void ActorDied(struct UObject* WorldContextObject, struct FString Name, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.ActorDied // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5966c40
	void ActiveARC(struct UObject* WorldContextObject, int64_t NumActiveArc); // Function EmbarkServerEvents.EventAPI.ActiveARC // (Final|Native|Static|Public) // @ game+0x591e350
	void ActivatedAbility(struct UObject* WorldContextObject, int64_t Player, struct FString Ability, struct FVector& Location); // Function EmbarkServerEvents.EventAPI.ActivatedAbility // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x590b130
};

// Class EmbarkServerEvents.ServerEventTestBase
// Size: 0xa0 (Inherited: 0xa0)
struct UServerEventTestBase : UObject {
};

// Class EmbarkServerEvents.AINavigationNavmeshSwap
// Size: 0xf0 (Inherited: 0xa0)
struct UAINavigationNavmeshSwap : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	struct FString PreviousNavmesh; // 0xc0(0x10)
	struct FString CurrentNavmesh; // 0xd0(0x10)
	int64_t AssetId; // 0xe0(0x08)

	struct TArray<struct UAINavigationNavmeshSwap*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AINavigationNavmeshSwap.From // (Final|Native|Static|Public) // @ game+0x592d830
};

// Class EmbarkServerEvents.ActivatedAbility
// Size: 0xd0 (Inherited: 0xa0)
struct UActivatedAbility : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Ability; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)

	struct TArray<struct UActivatedAbility*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ActivatedAbility.From // (Final|Native|Static|Public) // @ game+0x5912d90
};

// Class EmbarkServerEvents.ActiveARC
// Size: 0xa0 (Inherited: 0xa0)
struct UActiveARC : UServerEventTestBase {
	int64_t NumActiveArc; // 0x98(0x08)

	struct TArray<struct UActiveARC*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ActiveARC.From // (Final|Native|Static|Public) // @ game+0x595fcc0
};

// Class EmbarkServerEvents.ActorDied
// Size: 0xc0 (Inherited: 0xa0)
struct UActorDied : UServerEventTestBase {
	struct FString Name; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)

	struct TArray<struct UActorDied*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ActorDied.From // (Final|Native|Static|Public) // @ game+0x594a8a0
};

// Class EmbarkServerEvents.ActorHealthChange
// Size: 0xe0 (Inherited: 0xa0)
struct UActorHealthChange : UServerEventTestBase {
	struct FString Name; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	float PreviousHealth; // 0xc0(0x04)
	float CurrentHealth; // 0xc4(0x04)
	int64_t GameAssetId; // 0xc8(0x08)
	struct FString BoneName; // 0xd0(0x10)

	struct TArray<struct UActorHealthChange*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ActorHealthChange.From // (Final|Native|Static|Public) // @ game+0x59ac940
};

// Class EmbarkServerEvents.ActorStuckUnderground
// Size: 0xf0 (Inherited: 0xa0)
struct UActorStuckUnderground : UServerEventTestBase {
	struct FString ActorName; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	struct FVector Rotation; // 0xc0(0x18)
	struct FString HitActorName; // 0xd8(0x10)

	struct TArray<struct UActorStuckUnderground*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ActorStuckUnderground.From // (Final|Native|Static|Public) // @ game+0x591d160
};

// Class EmbarkServerEvents.AddNewBounty
// Size: 0xb0 (Inherited: 0xa0)
struct UAddNewBounty : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t Amount; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UAddNewBounty*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AddNewBounty.From // (Final|Native|Static|Public) // @ game+0x5916420
};

// Class EmbarkServerEvents.AddPersistedItem
// Size: 0xe0 (Inherited: 0xa0)
struct UAddPersistedItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Source; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	struct FString AssetType; // 0xb8(0x10)
	int64_t Amount; // 0xc8(0x08)
	struct TArray<int64_t> Breakthroughs; // 0xd0(0x10)

	struct TArray<struct UAddPersistedItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AddPersistedItem.From // (Final|Native|Static|Public) // @ game+0x5977490
};

// Class EmbarkServerEvents.AddQuestProgress3
// Size: 0xd0 (Inherited: 0xa0)
struct UAddQuestProgress3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString QuestInstanceId; // 0xa0(0x10)
	int64_t QuestAssetId; // 0xb0(0x08)
	int64_t DeltaAmount; // 0xb8(0x08)
	int64_t Amount; // 0xc0(0x08)

	struct TArray<struct UAddQuestProgress3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AddQuestProgress3.From // (Final|Native|Static|Public) // @ game+0x59d90a0
};

// Class EmbarkServerEvents.AimBasedForceApplication
// Size: 0xe0 (Inherited: 0xa0)
struct UAimBasedForceApplication : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float ForceMagnitude; // 0xa0(0x04)
	struct FVector Location; // 0xa8(0x18)
	struct FString Target; // 0xc0(0x10)
	int64_t TargetId; // 0xd0(0x08)
	char pad_dc[0x4]; // 0xdc(0x04)

	struct TArray<struct UAimBasedForceApplication*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AimBasedForceApplication.From // (Final|Native|Static|Public) // @ game+0x590b560
};

// Class EmbarkServerEvents.AimingValidationFailed
// Size: 0xd0 (Inherited: 0xa0)
struct UAimingValidationFailed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float PlayerPing; // 0xa0(0x04)
	struct FVector ClientAimingLocation; // 0xa8(0x18)
	struct FString Reason; // 0xc0(0x10)

	struct TArray<struct UAimingValidationFailed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AimingValidationFailed.From // (Final|Native|Static|Public) // @ game+0x59d7f30
};

// Class EmbarkServerEvents.AnchorAttached2
// Size: 0x110 (Inherited: 0xa0)
struct UAnchorAttached2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	struct FVector AnchorLocation; // 0xd8(0x18)
	int64_t CreationFrame; // 0xf0(0x08)
	int64_t CurrentCharacters; // 0xf8(0x08)
	int64_t CurrentObjects; // 0x100(0x08)

	struct TArray<struct UAnchorAttached2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AnchorAttached2.From // (Final|Native|Static|Public) // @ game+0x5962b60
};

// Class EmbarkServerEvents.AngelscriptServerError2
// Size: 0xd0 (Inherited: 0xa0)
struct UAngelscriptServerError2 : UServerEventTestBase {
	struct FString Source; // 0x98(0x10)
	struct FString Message; // 0xa8(0x10)
	struct TArray<struct FString> Trace; // 0xb8(0x10)

	struct TArray<struct UAngelscriptServerError2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AngelscriptServerError2.From // (Final|Native|Static|Public) // @ game+0x597fe10
};

// Class EmbarkServerEvents.AntiCheatAuthIntegrity
// Size: 0xb0 (Inherited: 0xa0)
struct UAntiCheatAuthIntegrity : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Details; // 0xa0(0x10)

	struct TArray<struct UAntiCheatAuthIntegrity*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AntiCheatAuthIntegrity.From // (Final|Native|Static|Public) // @ game+0x5947500
};

// Class EmbarkServerEvents.AntiCheatPlayerActionRequiredServer
// Size: 0xd0 (Inherited: 0xa0)
struct UAntiCheatPlayerActionRequiredServer : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ClientAction; // 0xa0(0x10)
	struct FString Reason; // 0xb0(0x10)
	struct FString Details; // 0xc0(0x10)

	struct TArray<struct UAntiCheatPlayerActionRequiredServer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AntiCheatPlayerActionRequiredServer.From // (Final|Native|Static|Public) // @ game+0x590ebb0
};

// Class EmbarkServerEvents.AntiCheatRpcMismatch
// Size: 0xc0 (Inherited: 0xa0)
struct UAntiCheatRpcMismatch : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int32_t Count; // 0xb0(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UAntiCheatRpcMismatch*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AntiCheatRpcMismatch.From // (Final|Native|Static|Public) // @ game+0x59aca80
};

// Class EmbarkServerEvents.AppInfo
// Size: 0xd0 (Inherited: 0xa0)
struct UAppInfo : UServerEventTestBase {
	struct FString AppId; // 0x98(0x10)
	struct FString BranchName; // 0xa8(0x10)
	struct FString CountryCode; // 0xb8(0x10)
	int64_t Player; // 0xc8(0x08)

	struct TArray<struct UAppInfo*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AppInfo.From // (Final|Native|Static|Public) // @ game+0x5981790
};

// Class EmbarkServerEvents.ArmorModRemoved2
// Size: 0xf0 (Inherited: 0xa0)
struct UArmorModRemoved2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ArmorGameAssetId; // 0xa0(0x08)
	struct FString ArmorName; // 0xa8(0x10)
	struct FString ArmorInstanceId; // 0xb8(0x10)
	int64_t ModGameAssetId; // 0xc8(0x08)
	struct FString ModName; // 0xd0(0x10)
	struct FString ModInstanceId; // 0xe0(0x10)

	struct TArray<struct UArmorModRemoved2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ArmorModRemoved2.From // (Final|Native|Static|Public) // @ game+0x59a62d0
};

// Class EmbarkServerEvents.ArmorModSet2
// Size: 0xf0 (Inherited: 0xa0)
struct UArmorModSet2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ArmorGameAssetId; // 0xa0(0x08)
	struct FString ArmorName; // 0xa8(0x10)
	struct FString ArmorInstanceId; // 0xb8(0x10)
	int64_t ModGameAssetId; // 0xc8(0x08)
	struct FString ModName; // 0xd0(0x10)
	struct FString ModInstanceId; // 0xe0(0x10)

	struct TArray<struct UArmorModSet2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ArmorModSet2.From // (Final|Native|Static|Public) // @ game+0x59272b0
};

// Class EmbarkServerEvents.AssignedSessionSeed
// Size: 0xa0 (Inherited: 0xa0)
struct UAssignedSessionSeed : UServerEventTestBase {
	int64_t Seed; // 0x98(0x08)

	struct TArray<struct UAssignedSessionSeed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AssignedSessionSeed.From // (Final|Native|Static|Public) // @ game+0x5974f90
};

// Class EmbarkServerEvents.AttackDefendSquadAbandon
// Size: 0xa0 (Inherited: 0xa0)
struct UAttackDefendSquadAbandon : UServerEventTestBase {
	int64_t SquadIndex; // 0x98(0x08)

	struct TArray<struct UAttackDefendSquadAbandon*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AttackDefendSquadAbandon.From // (Final|Native|Static|Public) // @ game+0x593c4d0
};

// Class EmbarkServerEvents.AttackDefendTeam
// Size: 0xc0 (Inherited: 0xa0)
struct UAttackDefendTeam : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Team; // 0xa0(0x10)
	struct FString SubroundId; // 0xb0(0x10)

	struct TArray<struct UAttackDefendTeam*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AttackDefendTeam.From // (Final|Native|Static|Public) // @ game+0x5933120
};

// Class EmbarkServerEvents.AutobotSpawned
// Size: 0xb0 (Inherited: 0xa0)
struct UAutobotSpawned : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	bool bIsServerBot; // 0xa0(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)

	struct TArray<struct UAutobotSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AutobotSpawned.From // (Final|Native|Static|Public) // @ game+0x5980e60
};

// Class EmbarkServerEvents.AwardEndOfRoundScorecardGrade2
// Size: 0xb0 (Inherited: 0xa0)
struct UAwardEndOfRoundScorecardGrade2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ScorecardGradeAssetId; // 0xa0(0x08)
	int32_t ScorecardGradeLevel; // 0xa8(0x04)

	struct TArray<struct UAwardEndOfRoundScorecardGrade2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AwardEndOfRoundScorecardGrade2.From // (Final|Native|Static|Public) // @ game+0x59b2a20
};

// Class EmbarkServerEvents.AwardEndOfRoundScorecardGrade3
// Size: 0xb0 (Inherited: 0xa0)
struct UAwardEndOfRoundScorecardGrade3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ScorecardGradeAssetId; // 0xa0(0x08)
	int32_t ScorecardGradeLevel; // 0xa8(0x04)
	float ScorecardGradeScore; // 0xac(0x04)

	struct TArray<struct UAwardEndOfRoundScorecardGrade3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.AwardEndOfRoundScorecardGrade3.From // (Final|Native|Static|Public) // @ game+0x599a380
};

// Class EmbarkServerEvents.BadBadFrame2
// Size: 0xc0 (Inherited: 0xa0)
struct UBadBadFrame2 : UServerEventTestBase {
	int64_t DeltaTimeMs; // 0x98(0x08)
	int64_t AdjustedFrameNumber; // 0xa0(0x08)
	struct TArray<float> FrameComponents; // 0xa8(0x10)

	struct TArray<struct UBadBadFrame2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BadBadFrame2.From // (Final|Native|Static|Public) // @ game+0x599cd10
};

// Class EmbarkServerEvents.BattlepassUltimateXPBonus
// Size: 0xb0 (Inherited: 0xa0)
struct UBattlepassUltimateXPBonus : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t UltimateBpBonusXp; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UBattlepassUltimateXPBonus*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BattlepassUltimateXPBonus.From // (Final|Native|Static|Public) // @ game+0x59625c0
};

// Class EmbarkServerEvents.BeginUseInstrument
// Size: 0xc0 (Inherited: 0xa0)
struct UBeginUseInstrument : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)

	struct TArray<struct UBeginUseInstrument*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BeginUseInstrument.From // (Final|Native|Static|Public) // @ game+0x59b4350
};

// Class EmbarkServerEvents.BonusReward
// Size: 0xc0 (Inherited: 0xa0)
struct UBonusReward : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	float Multiplier; // 0xa8(0x04)
	int64_t Amount; // 0xb0(0x08)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UBonusReward*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BonusReward.From // (Final|Native|Static|Public) // @ game+0x5946590
};

// Class EmbarkServerEvents.BotDefensiveTargetChanged
// Size: 0xb0 (Inherited: 0xa0)
struct UBotDefensiveTargetChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Target; // 0xa0(0x10)

	struct TArray<struct UBotDefensiveTargetChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BotDefensiveTargetChanged.From // (Final|Native|Static|Public) // @ game+0x5947be0
};

// Class EmbarkServerEvents.BotTargetChanged
// Size: 0xb0 (Inherited: 0xa0)
struct UBotTargetChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Target; // 0xa0(0x10)

	struct TArray<struct UBotTargetChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BotTargetChanged.From // (Final|Native|Static|Public) // @ game+0x5904e60
};

// Class EmbarkServerEvents.BulletHitRejected
// Size: 0xd0 (Inherited: 0xa0)
struct UBulletHitRejected : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t RejectionType; // 0xb8(0x08)
	float ThresholdValue; // 0xc0(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)

	struct TArray<struct UBulletHitRejected*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BulletHitRejected.From // (Final|Native|Static|Public) // @ game+0x59a75f0
};

// Class EmbarkServerEvents.BulletHitRejected2
// Size: 0x100 (Inherited: 0xa0)
struct UBulletHitRejected2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t RejectionType; // 0xa0(0x08)
	struct FVector ClientHitLocation; // 0xa8(0x18)
	struct FVector ServerHitLocation; // 0xc0(0x18)
	struct FVector ShooterLocation; // 0xd8(0x18)
	float ThresholdValue; // 0xf0(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)

	struct TArray<struct UBulletHitRejected2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.BulletHitRejected2.From // (Final|Native|Static|Public) // @ game+0x592a6c0
};

// Class EmbarkServerEvents.CarriableSpawned
// Size: 0xc0 (Inherited: 0xa0)
struct UCarriableSpawned : UServerEventTestBase {
	struct FString CarriableName; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)

	struct TArray<struct UCarriableSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.CarriableSpawned.From // (Final|Native|Static|Public) // @ game+0x59d11d0
};

// Class EmbarkServerEvents.CharacterCustomization2
// Size: 0xc0 (Inherited: 0xa0)
struct UCharacterCustomization2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<int64_t> GameAssetId; // 0xa0(0x10)
	int64_t OutfitGameAssetId; // 0xb0(0x08)

	struct TArray<struct UCharacterCustomization2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.CharacterCustomization2.From // (Final|Native|Static|Public) // @ game+0x5968fa0
};

// Class EmbarkServerEvents.CharacterSkillInitialized
// Size: 0xb0 (Inherited: 0xa0)
struct UCharacterSkillInitialized : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t CharacterSkillAssetId; // 0xa0(0x08)
	int64_t Level; // 0xa8(0x08)

	struct TArray<struct UCharacterSkillInitialized*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.CharacterSkillInitialized.From // (Final|Native|Static|Public) // @ game+0x594fdc0
};

// Class EmbarkServerEvents.ChosenSpawnPoint2
// Size: 0xc0 (Inherited: 0xa0)
struct UChosenSpawnPoint2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString SpawnPointName; // 0xa0(0x10)
	struct FString Source; // 0xb0(0x10)

	struct TArray<struct UChosenSpawnPoint2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ChosenSpawnPoint2.From // (Final|Native|Static|Public) // @ game+0x596f1f0
};

// Class EmbarkServerEvents.ColonyRunLoadout
// Size: 0xb0 (Inherited: 0xa0)
struct UColonyRunLoadout : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t LoadoutId; // 0xa0(0x08)

	struct TArray<struct UColonyRunLoadout*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ColonyRunLoadout.From // (Final|Native|Static|Public) // @ game+0x5988b20
};

// Class EmbarkServerEvents.CreatePing2
// Size: 0x120 (Inherited: 0xa0)
struct UCreatePing2 : UServerEventTestBase {
	int64_t CreatorPlayer; // 0x98(0x08)
	int32_t PingId; // 0xa0(0x04)
	struct FString Intent; // 0xa8(0x10)
	struct FString Object; // 0xb8(0x10)
	struct FString DialogueTag; // 0xc8(0x10)
	struct TArray<struct FString> AdditionalTags; // 0xd8(0x10)
	struct FVector PingerLocation; // 0xe8(0x18)
	struct FVector PingedLocation; // 0x100(0x18)
	char pad_11c[0x4]; // 0x11c(0x04)

	struct TArray<struct UCreatePing2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.CreatePing2.From // (Final|Native|Static|Public) // @ game+0x59ccfb0
};

// Class EmbarkServerEvents.DdosSeverityEscalation
// Size: 0xb0 (Inherited: 0xa0)
struct UDdosSeverityEscalation : UServerEventTestBase {
	struct FString Severity; // 0x98(0x10)

	struct TArray<struct UDdosSeverityEscalation*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DdosSeverityEscalation.From // (Final|Native|Static|Public) // @ game+0x59b3f90
};

// Class EmbarkServerEvents.DeathMatchSubroundLoss
// Size: 0xd0 (Inherited: 0xa0)
struct UDeathMatchSubroundLoss : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString SubroundId; // 0xa0(0x10)
	struct FString EndReason; // 0xb0(0x10)
	int64_t SquadId; // 0xc0(0x08)

	struct TArray<struct UDeathMatchSubroundLoss*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DeathMatchSubroundLoss.From // (Final|Native|Static|Public) // @ game+0x59432d0
};

// Class EmbarkServerEvents.DeathMatchSubroundStarted3
// Size: 0xd0 (Inherited: 0xa0)
struct UDeathMatchSubroundStarted3 : UServerEventTestBase {
	struct FString SubroundId; // 0x98(0x10)
	struct FString RoundState; // 0xa8(0x10)
	struct FString Scenario; // 0xb8(0x10)

	struct TArray<struct UDeathMatchSubroundStarted3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DeathMatchSubroundStarted3.From // (Final|Native|Static|Public) // @ game+0x5944f50
};

// Class EmbarkServerEvents.DeathMatchSubroundWin
// Size: 0xd0 (Inherited: 0xa0)
struct UDeathMatchSubroundWin : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString SubroundId; // 0xa0(0x10)
	struct FString EndReason; // 0xb0(0x10)
	int64_t SquadId; // 0xc0(0x08)

	struct TArray<struct UDeathMatchSubroundWin*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DeathMatchSubroundWin.From // (Final|Native|Static|Public) // @ game+0x5920090
};

// Class EmbarkServerEvents.DeathMatchTeam
// Size: 0xc0 (Inherited: 0xa0)
struct UDeathMatchTeam : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t SquadId; // 0xa0(0x08)
	struct FString SubroundId; // 0xa8(0x10)

	struct TArray<struct UDeathMatchTeam*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DeathMatchTeam.From // (Final|Native|Static|Public) // @ game+0x5943b90
};

// Class EmbarkServerEvents.DefibReviveFailed
// Size: 0xf0 (Inherited: 0xa0)
struct UDefibReviveFailed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	float PlayerPing; // 0xd8(0x04)
	float TargetPlayerPing; // 0xdc(0x04)
	struct FString Reason; // 0xe0(0x10)

	struct TArray<struct UDefibReviveFailed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DefibReviveFailed.From // (Final|Native|Static|Public) // @ game+0x599f980
};

// Class EmbarkServerEvents.DeliverCarriable
// Size: 0xe0 (Inherited: 0xa0)
struct UDeliverCarriable : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString CarriableName; // 0xa0(0x10)
	struct FVector DropZoneLocation; // 0xb0(0x18)
	struct FString DropZoneName; // 0xc8(0x10)

	struct TArray<struct UDeliverCarriable*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DeliverCarriable.From // (Final|Native|Static|Public) // @ game+0x5904ce0
};

// Class EmbarkServerEvents.DeliverItem
// Size: 0xd0 (Inherited: 0xa0)
struct UDeliverItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FVector DropZoneLocation; // 0xa8(0x18)
	struct FString DropZoneName; // 0xc0(0x10)

	struct TArray<struct UDeliverItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DeliverItem.From // (Final|Native|Static|Public) // @ game+0x594cb80
};

// Class EmbarkServerEvents.DestructionBoneDestroyed
// Size: 0xb0 (Inherited: 0xa0)
struct UDestructionBoneDestroyed : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)

	struct TArray<struct UDestructionBoneDestroyed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DestructionBoneDestroyed.From // (Final|Native|Static|Public) // @ game+0x59823c0
};

// Class EmbarkServerEvents.DestructionCutConnection
// Size: 0xb0 (Inherited: 0xa0)
struct UDestructionCutConnection : UServerEventTestBase {
	int64_t StrainConnects; // 0x98(0x08)
	int64_t BrokenLinks; // 0xa0(0x08)

	struct TArray<struct UDestructionCutConnection*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DestructionCutConnection.From // (Final|Native|Static|Public) // @ game+0x5969a80
};

// Class EmbarkServerEvents.DestructionMatchReport
// Size: 0xb0 (Inherited: 0xa0)
struct UDestructionMatchReport : UServerEventTestBase {
	int32_t TotalBones; // 0x98(0x04)
	int32_t BonesDestroyed; // 0x9c(0x04)
	int32_t TotalSimulatedBones; // 0xa0(0x04)
	int32_t TotalConnections; // 0xa4(0x04)
	int32_t TotalBrokenConnections; // 0xa8(0x04)

	struct TArray<struct UDestructionMatchReport*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DestructionMatchReport.From // (Final|Native|Static|Public) // @ game+0x5934bf0
};

// Class EmbarkServerEvents.DestructionRuntimeGraphComplete
// Size: 0xb0 (Inherited: 0xa0)
struct UDestructionRuntimeGraphComplete : UServerEventTestBase {
	float BuildTime; // 0x98(0x04)
	int32_t BoneCount; // 0x9c(0x04)
	int32_t SimpleCount; // 0xa0(0x04)
	int32_t ConnectionCount; // 0xa4(0x04)

	struct TArray<struct UDestructionRuntimeGraphComplete*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DestructionRuntimeGraphComplete.From // (Final|Native|Static|Public) // @ game+0x59cb330
};

// Class EmbarkServerEvents.DestructionStartSimulate
// Size: 0xc0 (Inherited: 0xa0)
struct UDestructionStartSimulate : UServerEventTestBase {
	int64_t Size; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UDestructionStartSimulate*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DestructionStartSimulate.From // (Final|Native|Static|Public) // @ game+0x591a7d0
};

// Class EmbarkServerEvents.DevInstanceKey
// Size: 0xb0 (Inherited: 0xa0)
struct UDevInstanceKey : UServerEventTestBase {
	struct FString DevInstanceKey; // 0x98(0x10)

	struct TArray<struct UDevInstanceKey*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DevInstanceKey.From // (Final|Native|Static|Public) // @ game+0x5975580
};

// Class EmbarkServerEvents.DiedInventorySlot7
// Size: 0xf0 (Inherited: 0xa0)
struct UDiedInventorySlot7 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Amount; // 0xa0(0x08)
	int64_t GameAssetId; // 0xa8(0x08)
	struct FString InstanceId; // 0xb0(0x10)
	struct FString Container; // 0xc0(0x10)
	float Durability; // 0xd0(0x04)
	float MaxDurability; // 0xd4(0x04)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0xd8(0x10)

	struct TArray<struct UDiedInventorySlot7*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiedInventorySlot7.From // (Final|Native|Static|Public) // @ game+0x591ae20
};

// Class EmbarkServerEvents.DiscoAddRankBucketRewardXp
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoAddRankBucketRewardXp : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t BucketId; // 0xa0(0x08)
	int64_t Amount; // 0xa8(0x08)

	struct TArray<struct UDiscoAddRankBucketRewardXp*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoAddRankBucketRewardXp.From // (Final|Native|Static|Public) // @ game+0x596b2d0
};

// Class EmbarkServerEvents.DiscoAnonymousName
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoAnonymousName : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString AnonymousName; // 0xa0(0x10)

	struct TArray<struct UDiscoAnonymousName*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoAnonymousName.From // (Final|Native|Static|Public) // @ game+0x591e950
};

// Class EmbarkServerEvents.DiscoArchetypeChanged
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoArchetypeChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString OldArchetype; // 0xa0(0x10)
	struct FString NewArchetype; // 0xb0(0x10)
	struct FString LoadoutUpdateId; // 0xc0(0x10)

	struct TArray<struct UDiscoArchetypeChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoArchetypeChanged.From // (Final|Native|Static|Public) // @ game+0x591fb10
};

// Class EmbarkServerEvents.DiscoArchetypeSummary
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoArchetypeSummary : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Archetype; // 0xa0(0x10)
	int64_t TimeUsed; // 0xb0(0x08)

	struct TArray<struct UDiscoArchetypeSummary*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoArchetypeSummary.From // (Final|Native|Static|Public) // @ game+0x5971080
};

// Class EmbarkServerEvents.DiscoAssignPlayerSquad
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoAssignPlayerSquad : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t SquadId; // 0xa0(0x08)
	struct FString Squad; // 0xa8(0x10)

	struct TArray<struct UDiscoAssignPlayerSquad*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoAssignPlayerSquad.From // (Final|Native|Static|Public) // @ game+0x5953580
};

// Class EmbarkServerEvents.DiscoBallPassCaught
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoBallPassCaught : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t PassingPlayer; // 0xb8(0x08)
	struct FVector PassingLocation; // 0xc0(0x18)
	int32_t PreviousCharge; // 0xd8(0x04)
	int32_t NewCharge; // 0xdc(0x04)

	struct TArray<struct UDiscoBallPassCaught*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoBallPassCaught.From // (Final|Native|Static|Public) // @ game+0x59dcfa0
};

// Class EmbarkServerEvents.DiscoBankItTransferCompleted
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoBankItTransferCompleted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int32_t TransferPointId; // 0xb8(0x04)
	struct FVector TransferPointLocation; // 0xc0(0x18)
	int32_t Cash; // 0xd8(0x04)
	int32_t SquadIndex; // 0xdc(0x04)

	struct TArray<struct UDiscoBankItTransferCompleted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoBankItTransferCompleted.From // (Final|Native|Static|Public) // @ game+0x592a580
};

// Class EmbarkServerEvents.DiscoBankItTransferStarted
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoBankItTransferStarted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int32_t TransferPointId; // 0xb8(0x04)
	struct FVector TransferPointLocation; // 0xc0(0x18)
	int32_t Cash; // 0xd8(0x04)
	int32_t SquadIndex; // 0xdc(0x04)

	struct TArray<struct UDiscoBankItTransferStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoBankItTransferStarted.From // (Final|Native|Static|Public) // @ game+0x59c9ea0
};

// Class EmbarkServerEvents.DiscoCasePickup
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoCasePickup : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FVector CaseLocation; // 0xb8(0x18)
	int32_t PreviousCash; // 0xd0(0x04)
	int32_t CaseValue; // 0xd4(0x04)

	struct TArray<struct UDiscoCasePickup*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoCasePickup.From // (Final|Native|Static|Public) // @ game+0x593f000
};

// Class EmbarkServerEvents.DiscoCaseSpawned
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoCaseSpawned : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)

	struct TArray<struct UDiscoCaseSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoCaseSpawned.From // (Final|Native|Static|Public) // @ game+0x595d650
};

// Class EmbarkServerEvents.DiscoChallengeResult3
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoChallengeResult3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ChallengeAssetId; // 0xa0(0x08)
	struct FString ChallengeInstanceId; // 0xa8(0x10)
	float Score; // 0xb8(0x04)
	float Duration; // 0xbc(0x04)
	int32_t ParticipantsNumber; // 0xc0(0x04)
	bool bSuccess; // 0xc4(0x01)
	struct FString ScoreType; // 0xc8(0x10)
	int64_t ChallengeGroupAssetId; // 0xd8(0x08)

	struct TArray<struct UDiscoChallengeResult3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoChallengeResult3.From // (Final|Native|Static|Public) // @ game+0x59ba210
};

// Class EmbarkServerEvents.DiscoChallengeStarted3
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscoChallengeStarted3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ChallengeAssetId; // 0xa0(0x08)
	struct FString ChallengeInstanceId; // 0xa8(0x10)
	int32_t ParticipantsNumber; // 0xb8(0x04)
	int64_t ChallengeGroupAssetId; // 0xc0(0x08)
	struct TArray<int64_t> ItemIds; // 0xc8(0x10)
	struct FString CharacterArchetype; // 0xd8(0x10)
	char pad_ec[0x4]; // 0xec(0x04)

	struct TArray<struct UDiscoChallengeStarted3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoChallengeStarted3.From // (Final|Native|Static|Public) // @ game+0x599c810
};

// Class EmbarkServerEvents.DiscoCharacterCustomizationItem
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoCharacterCustomizationItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Item; // 0xa0(0x10)
	int64_t ItemId; // 0xb0(0x08)

	struct TArray<struct UDiscoCharacterCustomizationItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoCharacterCustomizationItem.From // (Final|Native|Static|Public) // @ game+0x59dd220
};

// Class EmbarkServerEvents.DiscoCloakedBackHit
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoCloakedBackHit : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UDiscoCloakedBackHit*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoCloakedBackHit.From // (Final|Native|Static|Public) // @ game+0x5985810
};

// Class EmbarkServerEvents.DiscoDefibRespawn
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoDefibRespawn : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)

	struct TArray<struct UDiscoDefibRespawn*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoDefibRespawn.From // (Final|Native|Static|Public) // @ game+0x5978280
};

// Class EmbarkServerEvents.DiscoDropArenaItem
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoDropArenaItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString ItemName; // 0xb8(0x10)
	struct FString DropType; // 0xc8(0x10)

	struct TArray<struct UDiscoDropArenaItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoDropArenaItem.From // (Final|Native|Static|Public) // @ game+0x59b50d0
};

// Class EmbarkServerEvents.DiscoEndRoundPlacement
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoEndRoundPlacement : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Place; // 0xa0(0x08)

	struct TArray<struct UDiscoEndRoundPlacement*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoEndRoundPlacement.From // (Final|Native|Static|Public) // @ game+0x59ae040
};

// Class EmbarkServerEvents.DiscoEnemyDamage8
// Size: 0x150 (Inherited: 0xa0)
struct UDiscoEnemyDamage8 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	struct FString Causer; // 0xd8(0x10)
	int64_t CauserId; // 0xe8(0x08)
	float DamageTaken; // 0xf0(0x04)
	float PreviousHealth; // 0xf4(0x04)
	float CurrentHealth; // 0xf8(0x04)
	int32_t DamageType; // 0xfc(0x04)
	bool bIsDbno; // 0x100(0x01)
	struct FString DamageTypeTag; // 0x108(0x10)
	bool bIsHeadshot; // 0x118(0x01)
	char pad_11a[0x6]; // 0x11a(0x06)
	struct FString SourceTag; // 0x120(0x10)
	float Distance; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x138(0x10)
	char pad_148[0x8]; // 0x148(0x08)

	struct TArray<struct UDiscoEnemyDamage8*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoEnemyDamage8.From // (Final|Native|Static|Public) // @ game+0x59bdf30
};

// Class EmbarkServerEvents.DiscoEnemyKilled
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoEnemyKilled : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)

	struct TArray<struct UDiscoEnemyKilled*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoEnemyKilled.From // (Final|Native|Static|Public) // @ game+0x59d9960
};

// Class EmbarkServerEvents.DiscoEquipItem2
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoEquipItem2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	struct FString DefaultInstigatorTag; // 0xb8(0x10)

	struct TArray<struct UDiscoEquipItem2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoEquipItem2.From // (Final|Native|Static|Public) // @ game+0x5905e00
};

// Class EmbarkServerEvents.DiscoEquippingItem
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoEquippingItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoEquippingItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoEquippingItem.From // (Final|Native|Static|Public) // @ game+0x590cfc0
};

// Class EmbarkServerEvents.DiscoFansAdded2
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoFansAdded2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Fans; // 0xa0(0x08)
	int64_t Sponsor; // 0xa8(0x08)
	struct FString ProgressionEventTag; // 0xb0(0x10)
	int64_t CircuitStageId; // 0xc0(0x08)

	struct TArray<struct UDiscoFansAdded2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoFansAdded2.From // (Final|Native|Static|Public) // @ game+0x59d7a30
};

// Class EmbarkServerEvents.DiscoFlashbangExplosion
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscoFlashbangExplosion : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ExplosionId; // 0xa0(0x08)
	struct FVector Location; // 0xa8(0x18)
	struct FString ItemName; // 0xc0(0x10)
	int64_t GameAssetId; // 0xd0(0x08)
	struct FString SourceTag; // 0xd8(0x10)

	struct TArray<struct UDiscoFlashbangExplosion*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoFlashbangExplosion.From // (Final|Native|Static|Public) // @ game+0x59801e0
};

// Class EmbarkServerEvents.DiscoFlashbangResult
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscoFlashbangResult : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ExplosionId; // 0xa0(0x08)
	struct FVector EyeLocation; // 0xa8(0x18)
	float Distance; // 0xc0(0x04)
	float ViewFalloff; // 0xc4(0x04)
	float Intensity; // 0xc8(0x04)
	struct FString TargetType; // 0xd0(0x10)
	struct FString HitType; // 0xe0(0x10)

	struct TArray<struct UDiscoFlashbangResult*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoFlashbangResult.From // (Final|Native|Static|Public) // @ game+0x59160a0
};

// Class EmbarkServerEvents.DiscoFracturedDamage
// Size: 0x120 (Inherited: 0xa0)
struct UDiscoFracturedDamage : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float Damage; // 0xa0(0x04)
	struct FString DamageState; // 0xa8(0x10)
	struct FString BoneName; // 0xb8(0x10)
	struct FVector ImpactPoint; // 0xc8(0x18)
	struct FString FracturedClass; // 0xe0(0x10)
	struct FString SourceTag; // 0xf0(0x10)
	struct FString CauserName; // 0x100(0x10)
	int64_t GameAssetId; // 0x110(0x08)
	float Distance; // 0x118(0x04)

	struct TArray<struct UDiscoFracturedDamage*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoFracturedDamage.From // (Final|Native|Static|Public) // @ game+0x59b62f0
};

// Class EmbarkServerEvents.DiscoFracturedDamageSource
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoFracturedDamageSource : UServerEventTestBase {
	struct FString InstigatorTag; // 0x98(0x10)
	float AccumulatedDamage; // 0xa8(0x04)
	int32_t DestroyedBones; // 0xac(0x04)

	struct TArray<struct UDiscoFracturedDamageSource*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoFracturedDamageSource.From // (Final|Native|Static|Public) // @ game+0x59aac00
};

// Class EmbarkServerEvents.DiscoFracturedDamageTarget
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoFracturedDamageTarget : UServerEventTestBase {
	struct FString FracturedClass; // 0x98(0x10)
	float AccumulatedDamage; // 0xa8(0x04)
	int32_t DestroyedBones; // 0xac(0x04)

	struct TArray<struct UDiscoFracturedDamageTarget*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoFracturedDamageTarget.From // (Final|Native|Static|Public) // @ game+0x591ff10
};

// Class EmbarkServerEvents.DiscoGameModeRequest
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoGameModeRequest : UServerEventTestBase {
	struct FString DesiredGameMode; // 0x98(0x10)
	struct FString ResultingGameMode; // 0xa8(0x10)

	struct TArray<struct UDiscoGameModeRequest*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoGameModeRequest.From // (Final|Native|Static|Public) // @ game+0x597a9e0
};

// Class EmbarkServerEvents.DiscoGameModeStart3
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscoGameModeStart3 : UServerEventTestBase {
	struct FString EnvironmentalCondition; // 0x98(0x10)
	struct FString VariantName; // 0xa8(0x10)
	struct TArray<struct FString> RandomGameShowEvents; // 0xb8(0x10)
	bool bIsPractice; // 0xc8(0x01)
	bool bIsRanked; // 0xc9(0x01)
	bool bIsCasual; // 0xca(0x01)
	bool bIsWorldTour; // 0xcb(0x01)
	struct FString GameModeName; // 0xd0(0x10)
	struct FString MapName; // 0xe0(0x10)

	struct TArray<struct UDiscoGameModeStart3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoGameModeStart3.From // (Final|Native|Static|Public) // @ game+0x5961120
};

// Class EmbarkServerEvents.DiscoGrabArenaItem
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoGrabArenaItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString Name; // 0xb8(0x10)
	float TimeElapsedSincePickup; // 0xc8(0x04)

	struct TArray<struct UDiscoGrabArenaItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoGrabArenaItem.From // (Final|Native|Static|Public) // @ game+0x59aec40
};

// Class EmbarkServerEvents.DiscoGraveShiftPlayerStateChanged
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoGraveShiftPlayerStateChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t SubroundCount; // 0xa0(0x08)
	struct FString SubroundId; // 0xa8(0x10)
	int32_t PreviousState; // 0xb8(0x04)
	int32_t CurrentState; // 0xbc(0x04)

	struct TArray<struct UDiscoGraveShiftPlayerStateChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoGraveShiftPlayerStateChanged.From // (Final|Native|Static|Public) // @ game+0x59c4990
};

// Class EmbarkServerEvents.DiscoGraveShiftSubRoundSummary
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoGraveShiftSubRoundSummary : UServerEventTestBase {
	int64_t SubroundCount; // 0x98(0x08)
	struct FString SubroundId; // 0xa0(0x10)
	struct FString EndReason; // 0xb0(0x10)
	int32_t Survivors; // 0xc0(0x04)
	int32_t Monsters; // 0xc4(0x04)

	struct TArray<struct UDiscoGraveShiftSubRoundSummary*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoGraveShiftSubRoundSummary.From // (Final|Native|Static|Public) // @ game+0x59a3620
};

// Class EmbarkServerEvents.DiscoHealthChanged3
// Size: 0x100 (Inherited: 0xa0)
struct UDiscoHealthChanged3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString Causer; // 0xb8(0x10)
	float DamageTaken; // 0xc8(0x04)
	float PreviousHealth; // 0xcc(0x04)
	float CurrentHealth; // 0xd0(0x04)
	int32_t DamageType; // 0xd4(0x04)
	bool bIsDbno; // 0xd8(0x01)
	struct FString DamageTypeTag; // 0xe0(0x10)
	struct FString SourceTag; // 0xf0(0x10)

	struct TArray<struct UDiscoHealthChanged3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoHealthChanged3.From // (Final|Native|Static|Public) // @ game+0x59a71b0
};

// Class EmbarkServerEvents.DiscoItemDeadTelemetry
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoItemDeadTelemetry : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	struct FVector ItemLocation; // 0xb0(0x18)
	int64_t GameAssetId; // 0xc8(0x08)
	bool bDestroyed; // 0xd0(0x01)
	char pad_d9[0x7]; // 0xd9(0x07)

	struct TArray<struct UDiscoItemDeadTelemetry*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoItemDeadTelemetry.From // (Final|Native|Static|Public) // @ game+0x59cb7f0
};

// Class EmbarkServerEvents.DiscoItemUsageStat2
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoItemUsageStat2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ItemId; // 0xa0(0x08)
	struct FString Tag; // 0xa8(0x10)
	float Modifier; // 0xb8(0x04)
	float Usage; // 0xbc(0x04)
	struct FString Description; // 0xc0(0x10)
	struct FString Archetype; // 0xd0(0x10)

	struct TArray<struct UDiscoItemUsageStat2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoItemUsageStat2.From // (Final|Native|Static|Public) // @ game+0x5933960
};

// Class EmbarkServerEvents.DiscoItemUse2
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscoItemUse2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString Name; // 0xb8(0x10)
	int64_t ItemId; // 0xc8(0x08)
	int32_t AmountBefore; // 0xd0(0x04)
	int32_t AmountNow; // 0xd4(0x04)
	struct FString DefaultInstigatorTag; // 0xd8(0x10)

	struct TArray<struct UDiscoItemUse2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoItemUse2.From // (Final|Native|Static|Public) // @ game+0x5987970
};

// Class EmbarkServerEvents.DiscoKillAssist
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoKillAssist : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)

	struct TArray<struct UDiscoKillAssist*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoKillAssist.From // (Final|Native|Static|Public) // @ game+0x59d9aa0
};

// Class EmbarkServerEvents.DiscoLoadoutItem3
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoLoadoutItem3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Item; // 0xa0(0x10)
	int64_t ItemId; // 0xb0(0x08)
	struct TArray<int64_t> WeaponAttachmentIds; // 0xb8(0x10)

	struct TArray<struct UDiscoLoadoutItem3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoLoadoutItem3.From // (Final|Native|Static|Public) // @ game+0x59762a0
};

// Class EmbarkServerEvents.DiscoPickupArenaItem
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoPickupArenaItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString ItemName; // 0xb8(0x10)

	struct TArray<struct UDiscoPickupArenaItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPickupArenaItem.From // (Final|Native|Static|Public) // @ game+0x59b4490
};

// Class EmbarkServerEvents.DiscoPlayerAbandonedTournament
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoPlayerAbandonedTournament : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UDiscoPlayerAbandonedTournament*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerAbandonedTournament.From // (Final|Native|Static|Public) // @ game+0x59b9140
};

// Class EmbarkServerEvents.DiscoPlayerDepartedTournament
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoPlayerDepartedTournament : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UDiscoPlayerDepartedTournament*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerDepartedTournament.From // (Final|Native|Static|Public) // @ game+0x592f810
};

// Class EmbarkServerEvents.DiscoPlayerDie
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoPlayerDie : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UDiscoPlayerDie*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerDie.From // (Final|Native|Static|Public) // @ game+0x590a3b0
};

// Class EmbarkServerEvents.DiscoPlayerDisconnect
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPlayerDisconnect : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Reason; // 0xa0(0x10)

	struct TArray<struct UDiscoPlayerDisconnect*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerDisconnect.From // (Final|Native|Static|Public) // @ game+0x599dd50
};

// Class EmbarkServerEvents.DiscoPlayerEliminated
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoPlayerEliminated : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UDiscoPlayerEliminated*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerEliminated.From // (Final|Native|Static|Public) // @ game+0x59d0220
};

// Class EmbarkServerEvents.DiscoPlayerFinishSteal
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPlayerFinishSteal : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t TransferPointId; // 0xa0(0x04)
	int32_t Cash; // 0xa4(0x04)

	struct TArray<struct UDiscoPlayerFinishSteal*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerFinishSteal.From // (Final|Native|Static|Public) // @ game+0x59595a0
};

// Class EmbarkServerEvents.DiscoPlayerHeal
// Size: 0x100 (Inherited: 0xa0)
struct UDiscoPlayerHeal : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	struct FString Causer; // 0xd8(0x10)
	float AmountHealed; // 0xe8(0x04)
	float PreviousHealth; // 0xec(0x04)
	float CurrentHealth; // 0xf0(0x04)
	bool bIsDbno; // 0xf4(0x01)
	char pad_fd[0x3]; // 0xfd(0x03)

	struct TArray<struct UDiscoPlayerHeal*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerHeal.From // (Final|Native|Static|Public) // @ game+0x5976520
};

// Class EmbarkServerEvents.DiscoPlayerHealPlayer
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoPlayerHealPlayer : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	int64_t GameAssetId; // 0xa8(0x08)
	float AmountHealed; // 0xb0(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UDiscoPlayerHealPlayer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerHealPlayer.From // (Final|Native|Static|Public) // @ game+0x596ba50
};

// Class EmbarkServerEvents.DiscoPlayerSpawn2
// Size: 0x110 (Inherited: 0xa0)
struct UDiscoPlayerSpawn2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t SquadId; // 0xa0(0x08)
	struct FString Squad; // 0xa8(0x10)
	struct FVector Location; // 0xb8(0x18)
	struct FString CharacterArchetype; // 0xd0(0x10)
	struct FString GameMode; // 0xe0(0x10)
	struct FString MapName; // 0xf0(0x10)
	struct FString Deck; // 0x100(0x10)

	struct TArray<struct UDiscoPlayerSpawn2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerSpawn2.From // (Final|Native|Static|Public) // @ game+0x5998e70
};

// Class EmbarkServerEvents.DiscoPlayerSquadWiped
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPlayerSquadWiped : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t SquadId; // 0xa0(0x08)

	struct TArray<struct UDiscoPlayerSquadWiped*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerSquadWiped.From // (Final|Native|Static|Public) // @ game+0x5941420
};

// Class EmbarkServerEvents.DiscoPlayerStartSteal
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPlayerStartSteal : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t TransferPointId; // 0xa0(0x04)
	int32_t Cash; // 0xa4(0x04)

	struct TArray<struct UDiscoPlayerStartSteal*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerStartSteal.From // (Final|Native|Static|Public) // @ game+0x59cfba0
};

// Class EmbarkServerEvents.DiscoPlayerStartingInfo
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPlayerStartingInfo : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t StartingRespawnCredits; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UDiscoPlayerStartingInfo*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerStartingInfo.From // (Final|Native|Static|Public) // @ game+0x59d0a90
};

// Class EmbarkServerEvents.DiscoPlayerWorldTourInfo
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPlayerWorldTourInfo : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	bool bIsWorldTourFinals; // 0xa0(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)

	struct TArray<struct UDiscoPlayerWorldTourInfo*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPlayerWorldTourInfo.From // (Final|Native|Static|Public) // @ game+0x590fc80
};

// Class EmbarkServerEvents.DiscoPreLoginEvent
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoPreLoginEvent : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	bool bIsAllowedToConnect; // 0xa0(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)

	struct TArray<struct UDiscoPreLoginEvent*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoPreLoginEvent.From // (Final|Native|Static|Public) // @ game+0x59ab9a0
};

// Class EmbarkServerEvents.DiscoQuestCompleted
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoQuestCompleted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString QuestInstanceId; // 0xa0(0x10)
	int64_t QuestAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoQuestCompleted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoQuestCompleted.From // (Final|Native|Static|Public) // @ game+0x592b030
};

// Class EmbarkServerEvents.DiscoQuestCompleted2
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoQuestCompleted2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString QuestInstanceId; // 0xa0(0x10)
	int64_t QuestAssetId; // 0xb0(0x08)
	int64_t CircuitId; // 0xb8(0x08)
	int64_t StageId; // 0xc0(0x08)

	struct TArray<struct UDiscoQuestCompleted2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoQuestCompleted2.From // (Final|Native|Static|Public) // @ game+0x5973ab0
};

// Class EmbarkServerEvents.DiscoReserveItem2
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoReserveItem2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Item; // 0xa0(0x10)
	int64_t ItemId; // 0xb0(0x08)
	struct TArray<int64_t> WeaponAttachmentIds; // 0xb8(0x10)

	struct TArray<struct UDiscoReserveItem2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoReserveItem2.From // (Final|Native|Static|Public) // @ game+0x599c690
};

// Class EmbarkServerEvents.DiscoRespawn
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoRespawn : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int32_t RemainingRespawnCredits; // 0xb8(0x04)

	struct TArray<struct UDiscoRespawn*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoRespawn.From // (Final|Native|Static|Public) // @ game+0x5927be0
};

// Class EmbarkServerEvents.DiscoRespawnSummary
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoRespawnSummary : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t RemainingRespawnTokens; // 0xa0(0x08)
	bool bUsedRespawnToken; // 0xa8(0x01)
	bool bTeamWipeRespawn; // 0xa9(0x01)
	bool bWasRevivedRespawn; // 0xaa(0x01)
	bool bWasDefibRevived; // 0xab(0x01)
	struct FString RespawnReason; // 0xb0(0x10)

	struct TArray<struct UDiscoRespawnSummary*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoRespawnSummary.From // (Final|Native|Static|Public) // @ game+0x5909230
};

// Class EmbarkServerEvents.DiscoRoundCurrencyChanged2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoRoundCurrencyChanged2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t PreviousRoundCurrency; // 0xa0(0x04)
	int32_t CurrentRoundCurrency; // 0xa4(0x04)
	int32_t RoundCurrencyDelta; // 0xa8(0x04)
	struct FString Source; // 0xb0(0x10)

	struct TArray<struct UDiscoRoundCurrencyChanged2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoRoundCurrencyChanged2.From // (Final|Native|Static|Public) // @ game+0x59072c0
};

// Class EmbarkServerEvents.DiscoRoundTravelToNextStage
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoRoundTravelToNextStage : UServerEventTestBase {
	struct FString NextMatchId; // 0x98(0x10)

	struct TArray<struct UDiscoRoundTravelToNextStage*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoRoundTravelToNextStage.From // (Final|Native|Static|Public) // @ game+0x5957af0
};

// Class EmbarkServerEvents.DiscoSelectedEmote
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedEmote : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedEmote*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedEmote.From // (Final|Native|Static|Public) // @ game+0x59201d0
};

// Class EmbarkServerEvents.DiscoSelectedEmoticon
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedEmoticon : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedEmoticon*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedEmoticon.From // (Final|Native|Static|Public) // @ game+0x5925b90
};

// Class EmbarkServerEvents.DiscoSelectedHandGesture
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedHandGesture : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedHandGesture*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedHandGesture.From // (Final|Native|Static|Public) // @ game+0x5978a00
};

// Class EmbarkServerEvents.DiscoSelectedObjectiveSticker
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedObjectiveSticker : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedObjectiveSticker*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedObjectiveSticker.From // (Final|Native|Static|Public) // @ game+0x5998000
};

// Class EmbarkServerEvents.DiscoSelectedPet
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedPet : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedPet*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedPet.From // (Final|Native|Static|Public) // @ game+0x59bb140
};

// Class EmbarkServerEvents.DiscoSelectedPose
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoSelectedPose : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	struct FString PoseType; // 0xb8(0x10)

	struct TArray<struct UDiscoSelectedPose*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedPose.From // (Final|Native|Static|Public) // @ game+0x5996d00
};

// Class EmbarkServerEvents.DiscoSelectedSoundEffect
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedSoundEffect : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedSoundEffect*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedSoundEffect.From // (Final|Native|Static|Public) // @ game+0x598e6c0
};

// Class EmbarkServerEvents.DiscoSelectedSpray
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedSpray : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedSpray*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedSpray.From // (Final|Native|Static|Public) // @ game+0x59a6f30
};

// Class EmbarkServerEvents.DiscoSelectedWatch
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedWatch : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UDiscoSelectedWatch*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedWatch.From // (Final|Native|Static|Public) // @ game+0x59d6c60
};

// Class EmbarkServerEvents.DiscoSelectedWeaponAnimation2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedWeaponAnimation2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	int64_t WeaponGameAssetId; // 0xb8(0x08)

	struct TArray<struct UDiscoSelectedWeaponAnimation2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedWeaponAnimation2.From // (Final|Native|Static|Public) // @ game+0x59aa5c0
};

// Class EmbarkServerEvents.DiscoSelectedWeaponAttachment2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedWeaponAttachment2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	int64_t WeaponGameAssetId; // 0xb8(0x08)

	struct TArray<struct UDiscoSelectedWeaponAttachment2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedWeaponAttachment2.From // (Final|Native|Static|Public) // @ game+0x593a9f0
};

// Class EmbarkServerEvents.DiscoSelectedWeaponCharm2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedWeaponCharm2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	int64_t WeaponGameAssetId; // 0xb8(0x08)

	struct TArray<struct UDiscoSelectedWeaponCharm2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedWeaponCharm2.From // (Final|Native|Static|Public) // @ game+0x59da160
};

// Class EmbarkServerEvents.DiscoSelectedWeaponSkin2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedWeaponSkin2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	int64_t WeaponGameAssetId; // 0xb8(0x08)

	struct TArray<struct UDiscoSelectedWeaponSkin2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedWeaponSkin2.From // (Final|Native|Static|Public) // @ game+0x59b2330
};

// Class EmbarkServerEvents.DiscoSelectedWeaponSticker2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSelectedWeaponSticker2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	int64_t WeaponGameAssetId; // 0xb8(0x08)

	struct TArray<struct UDiscoSelectedWeaponSticker2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelectedWeaponSticker2.From // (Final|Native|Static|Public) // @ game+0x5969550
};

// Class EmbarkServerEvents.DiscoSelfDamage2
// Size: 0x110 (Inherited: 0xa0)
struct UDiscoSelfDamage2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString Causer; // 0xb8(0x10)
	int64_t CauserId; // 0xc8(0x08)
	float DamageTaken; // 0xd0(0x04)
	float PreviousHealth; // 0xd4(0x04)
	float CurrentHealth; // 0xd8(0x04)
	int32_t DamageType; // 0xdc(0x04)
	bool bIsDbno; // 0xe0(0x01)
	struct FString DamageTypeTag; // 0xe8(0x10)
	struct FString SourceTag; // 0xf8(0x10)
	char pad_109[0x7]; // 0x109(0x07)

	struct TArray<struct UDiscoSelfDamage2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSelfDamage2.From // (Final|Native|Static|Public) // @ game+0x59a8130
};

// Class EmbarkServerEvents.DiscoSquadRoundCurrencyChanged2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoSquadRoundCurrencyChanged2 : UServerEventTestBase {
	int32_t SquadId; // 0x98(0x04)
	int32_t PreviousRoundCurrency; // 0x9c(0x04)
	int32_t CurrentRoundCurrency; // 0xa0(0x04)
	int32_t RoundCurrencyDelta; // 0xa4(0x04)
	struct FString Source; // 0xa8(0x10)

	struct TArray<struct UDiscoSquadRoundCurrencyChanged2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSquadRoundCurrencyChanged2.From // (Final|Native|Static|Public) // @ game+0x59382e0
};

// Class EmbarkServerEvents.DiscoSquadWiped2
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoSquadWiped2 : UServerEventTestBase {
	int64_t SquadId; // 0x98(0x08)

	struct TArray<struct UDiscoSquadWiped2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoSquadWiped2.From // (Final|Native|Static|Public) // @ game+0x59d6e20
};

// Class EmbarkServerEvents.DiscoThingDamage
// Size: 0x120 (Inherited: 0xa0)
struct UDiscoThingDamage : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString Target; // 0xb8(0x10)
	struct FVector TargetLocation; // 0xc8(0x18)
	int64_t WeaponGameAssetId; // 0xe0(0x08)
	float DamageTaken; // 0xe8(0x04)
	float PreviousHealth; // 0xec(0x04)
	float CurrentHealth; // 0xf0(0x04)
	struct FString DamageTypeTag; // 0xf8(0x10)
	struct FString SourceTag; // 0x108(0x10)
	float Distance; // 0x118(0x04)

	struct TArray<struct UDiscoThingDamage*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoThingDamage.From // (Final|Native|Static|Public) // @ game+0x596c320
};

// Class EmbarkServerEvents.DiscoTicketDrop2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTicketDrop2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int32_t TicketIndex; // 0xb8(0x04)

	struct TArray<struct UDiscoTicketDrop2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTicketDrop2.From // (Final|Native|Static|Public) // @ game+0x59c17e0
};

// Class EmbarkServerEvents.DiscoTicketInserted3
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoTicketInserted3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t TicketIndex; // 0xa0(0x04)
	struct FVector Location; // 0xa8(0x18)
	int32_t TransferPointId; // 0xc0(0x04)
	int32_t TransferPointIndex; // 0xc4(0x04)
	int32_t Cash; // 0xc8(0x04)

	struct TArray<struct UDiscoTicketInserted3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTicketInserted3.From // (Final|Native|Static|Public) // @ game+0x59509c0
};

// Class EmbarkServerEvents.DiscoTicketPickup2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTicketPickup2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int32_t TicketIndex; // 0xb8(0x04)

	struct TArray<struct UDiscoTicketPickup2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTicketPickup2.From // (Final|Native|Static|Public) // @ game+0x59ca2a0
};

// Class EmbarkServerEvents.DiscoTicketPosition2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTicketPosition2 : UServerEventTestBase {
	int32_t TicketIndex; // 0x98(0x04)
	struct FVector Location; // 0xa0(0x18)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UDiscoTicketPosition2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTicketPosition2.From // (Final|Native|Static|Public) // @ game+0x5984f00
};

// Class EmbarkServerEvents.DiscoTicketSpawn2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTicketSpawn2 : UServerEventTestBase {
	int32_t TicketIndex; // 0x98(0x04)
	struct FVector Location; // 0xa0(0x18)
	int32_t Cash; // 0xb8(0x04)

	struct TArray<struct UDiscoTicketSpawn2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTicketSpawn2.From // (Final|Native|Static|Public) // @ game+0x59a6b70
};

// Class EmbarkServerEvents.DiscoTombstoneRespawn
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoTombstoneRespawn : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)

	struct TArray<struct UDiscoTombstoneRespawn*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTombstoneRespawn.From // (Final|Native|Static|Public) // @ game+0x5963de0
};

// Class EmbarkServerEvents.DiscoTournamentWon
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoTournamentWon : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UDiscoTournamentWon*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTournamentWon.From // (Final|Native|Static|Public) // @ game+0x5940370
};

// Class EmbarkServerEvents.DiscoTransferCompleted2
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTransferCompleted2 : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	int32_t TransferPointId; // 0xb0(0x04)
	int32_t TransferPointIndex; // 0xb4(0x04)
	int32_t Cash; // 0xb8(0x04)
	int32_t SquadIndex; // 0xbc(0x04)

	struct TArray<struct UDiscoTransferCompleted2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTransferCompleted2.From // (Final|Native|Static|Public) // @ game+0x594d790
};

// Class EmbarkServerEvents.DiscoTransferPointDespawned
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTransferPointDespawned : UServerEventTestBase {
	int32_t TransferPointId; // 0x98(0x04)
	struct FVector Location; // 0xa0(0x18)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UDiscoTransferPointDespawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTransferPointDespawned.From // (Final|Native|Static|Public) // @ game+0x590bd00
};

// Class EmbarkServerEvents.DiscoTransferPointPosition
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTransferPointPosition : UServerEventTestBase {
	int32_t TransferPointId; // 0x98(0x04)
	struct FVector Location; // 0xa0(0x18)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UDiscoTransferPointPosition*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTransferPointPosition.From // (Final|Native|Static|Public) // @ game+0x591a910
};

// Class EmbarkServerEvents.DiscoTransferPointSpawned
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoTransferPointSpawned : UServerEventTestBase {
	int32_t TransferPointId; // 0x98(0x04)
	struct FVector Location; // 0xa0(0x18)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UDiscoTransferPointSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTransferPointSpawned.From // (Final|Native|Static|Public) // @ game+0x59c0e70
};

// Class EmbarkServerEvents.DiscoTransferPointSpawned3
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoTransferPointSpawned3 : UServerEventTestBase {
	int32_t TransferPointId; // 0x98(0x04)
	int32_t TransferPointIndex; // 0x9c(0x04)
	struct FVector Location; // 0xa0(0x18)
	struct FString LocationName; // 0xb8(0x10)
	bool bFromPrioritizedPool; // 0xc8(0x01)
	bool bIsInitialSpawn; // 0xc9(0x01)
	int64_t Seed; // 0xd0(0x08)
	char pad_da[0x6]; // 0xda(0x06)

	struct TArray<struct UDiscoTransferPointSpawned3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTransferPointSpawned3.From // (Final|Native|Static|Public) // @ game+0x598b6f0
};

// Class EmbarkServerEvents.DiscoTriggerRemoteItem
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoTriggerRemoteItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ProjectileName; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)

	struct TArray<struct UDiscoTriggerRemoteItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoTriggerRemoteItem.From // (Final|Native|Static|Public) // @ game+0x59cf0e0
};

// Class EmbarkServerEvents.DiscoUIRoundStateChange
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoUIRoundStateChange : UServerEventTestBase {
	struct FString State; // 0x98(0x10)

	struct TArray<struct UDiscoUIRoundStateChange*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoUIRoundStateChange.From // (Final|Native|Static|Public) // @ game+0x59c6150
};

// Class EmbarkServerEvents.DiscoUpdatedLoadoutItem3
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoUpdatedLoadoutItem3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Item; // 0xa0(0x10)
	int64_t ItemId; // 0xb0(0x08)
	struct FString LoadoutUpdateId; // 0xb8(0x10)
	struct TArray<int64_t> WeaponAttachmentIds; // 0xc8(0x10)
	bool bIsActiveGameplay; // 0xd8(0x01)

	struct TArray<struct UDiscoUpdatedLoadoutItem3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoUpdatedLoadoutItem3.From // (Final|Native|Static|Public) // @ game+0x592e240
};

// Class EmbarkServerEvents.DiscoUseRespawnCredit
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoUseRespawnCredit : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t RemainingRespawnCredits; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UDiscoUseRespawnCredit*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoUseRespawnCredit.From // (Final|Native|Static|Public) // @ game+0x5981e50
};

// Class EmbarkServerEvents.DiscoVaultOpenStarted
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoVaultOpenStarted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int32_t VaultIndex; // 0xb8(0x04)

	struct TArray<struct UDiscoVaultOpenStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoVaultOpenStarted.From // (Final|Native|Static|Public) // @ game+0x59676a0
};

// Class EmbarkServerEvents.DiscoVaultOpened
// Size: 0xc0 (Inherited: 0xa0)
struct UDiscoVaultOpened : UServerEventTestBase {
	int32_t VaultIndex; // 0x98(0x04)
	struct FVector Location; // 0xa0(0x18)
	int32_t CaseAmount; // 0xb8(0x04)

	struct TArray<struct UDiscoVaultOpened*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoVaultOpened.From // (Final|Native|Static|Public) // @ game+0x594ccc0
};

// Class EmbarkServerEvents.DiscoVaultSpawned4
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoVaultSpawned4 : UServerEventTestBase {
	int64_t VaultIndex; // 0x98(0x08)
	int32_t Cash; // 0xa0(0x04)
	struct FVector Location; // 0xa8(0x18)
	struct FString LocationName; // 0xc0(0x10)
	bool bIsInitialSpawn; // 0xd0(0x01)
	char pad_d5[0x3]; // 0xd5(0x03)
	int64_t Seed; // 0xd8(0x08)

	struct TArray<struct UDiscoVaultSpawned4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoVaultSpawned4.From // (Final|Native|Static|Public) // @ game+0x59398f0
};

// Class EmbarkServerEvents.DiscoViewSample2
// Size: 0x100 (Inherited: 0xa0)
struct UDiscoViewSample2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<float> MovementInputX; // 0xa0(0x10)
	struct TArray<float> MovementInputY; // 0xb0(0x10)
	struct TArray<float> MovementInputZ; // 0xc0(0x10)
	struct TArray<float> LookRotationVelocityPitch; // 0xd0(0x10)
	struct TArray<float> LookRotationVelocityYaw; // 0xe0(0x10)
	struct TArray<bool> IsUsingGamepad; // 0xf0(0x10)

	struct TArray<struct UDiscoViewSample2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoViewSample2.From // (Final|Native|Static|Public) // @ game+0x596e6d0
};

// Class EmbarkServerEvents.DiscoViewToKill8
// Size: 0x1d0 (Inherited: 0xa0)
struct UDiscoViewToKill8 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	struct TArray<float> KillerMovementInputX; // 0xa8(0x10)
	struct TArray<float> KillerMovementInputY; // 0xb8(0x10)
	struct TArray<float> KillerMovementInputZ; // 0xc8(0x10)
	struct TArray<float> KillerLookRotationVelocityPitch; // 0xd8(0x10)
	struct TArray<float> KillerLookRotationVelocityYaw; // 0xe8(0x10)
	struct TArray<float> VictimPosInKillerFrustumX; // 0xf8(0x10)
	struct TArray<float> VictimPosInKillerFrustumY; // 0x108(0x10)
	struct TArray<float> VictimPosInKillerFrustumZ; // 0x118(0x10)
	struct TArray<bool> IsUsingGamepad; // 0x128(0x10)
	struct TArray<bool> IsFiring; // 0x138(0x10)
	struct TArray<float> VictimVelocityInKillerFrustumX; // 0x148(0x10)
	struct TArray<float> VictimVelocityInKillerFrustumY; // 0x158(0x10)
	struct TArray<float> VictimVelocityInKillerFrustumZ; // 0x168(0x10)
	struct TArray<float> KillerVelocityInKillerFrustumX; // 0x178(0x10)
	struct TArray<float> KillerVelocityInKillerFrustumY; // 0x188(0x10)
	struct TArray<float> KillerVelocityInKillerFrustumZ; // 0x198(0x10)
	struct TArray<bool> IsAimAssistEnabled; // 0x1a8(0x10)
	struct TArray<float> KillerLatencies; // 0x1b8(0x10)

	struct TArray<struct UDiscoViewToKill8*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoViewToKill8.From // (Final|Native|Static|Public) // @ game+0x59c7df0
};

// Class EmbarkServerEvents.DiscoWeaponHitPlayer3
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoWeaponHitPlayer3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	int64_t WeaponId; // 0xb0(0x08)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	bool bIsEnemy; // 0xd8(0x01)
	bool bIsHeadshot; // 0xd9(0x01)

	struct TArray<struct UDiscoWeaponHitPlayer3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoWeaponHitPlayer3.From // (Final|Native|Static|Public) // @ game+0x59306c0
};

// Class EmbarkServerEvents.DiscoWeaponHitPlayer4
// Size: 0xe0 (Inherited: 0xa0)
struct UDiscoWeaponHitPlayer4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	int64_t WeaponId; // 0xb0(0x08)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	bool bIsEnemy; // 0xd8(0x01)
	bool bIsHeadshot; // 0xd9(0x01)
	float ChargingProgress; // 0xdc(0x04)

	struct TArray<struct UDiscoWeaponHitPlayer4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoWeaponHitPlayer4.From // (Final|Native|Static|Public) // @ game+0x59aaa00
};

// Class EmbarkServerEvents.DiscoWeaponHitThing3
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscoWeaponHitThing3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	int64_t WeaponId; // 0xb0(0x08)
	struct FString Target; // 0xb8(0x10)
	struct FVector TargetLocation; // 0xc8(0x18)
	float ChargingProgress; // 0xe0(0x04)
	char pad_ec[0x4]; // 0xec(0x04)

	struct TArray<struct UDiscoWeaponHitThing3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoWeaponHitThing3.From // (Final|Native|Static|Public) // @ game+0x59c29d0
};

// Class EmbarkServerEvents.DiscoXpRewardTelemetry
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoXpRewardTelemetry : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t BucketId; // 0xa0(0x08)
	int64_t Amount; // 0xa8(0x08)
	struct FString EventTag; // 0xb0(0x10)
	int64_t ItemId; // 0xc0(0x08)

	struct TArray<struct UDiscoXpRewardTelemetry*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DiscoXpRewardTelemetry.From // (Final|Native|Static|Public) // @ game+0x5950c00
};

// Class EmbarkServerEvents.DisqualifiedRespawnGroup2
// Size: 0xf0 (Inherited: 0xa0)
struct UDisqualifiedRespawnGroup2 : UServerEventTestBase {
	struct FString Ctx; // 0x98(0x10)
	struct FString GroupName; // 0xa8(0x10)
	struct FVector Location; // 0xb8(0x18)
	int32_t SquadIndex; // 0xd0(0x04)
	struct FString Reason; // 0xd8(0x10)
	char pad_ec[0x4]; // 0xec(0x04)

	struct TArray<struct UDisqualifiedRespawnGroup2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DisqualifiedRespawnGroup2.From // (Final|Native|Static|Public) // @ game+0x59be330
};

// Class EmbarkServerEvents.DisregardItem
// Size: 0xd0 (Inherited: 0xa0)
struct UDisregardItem : UServerEventTestBase {
	int64_t PlayerId; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FString InstanceId; // 0xa8(0x10)
	int32_t StackSize; // 0xb8(0x04)
	struct FString LootContainer; // 0xc0(0x10)

	struct TArray<struct UDisregardItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DisregardItem.From // (Final|Native|Static|Public) // @ game+0x592e860
};

// Class EmbarkServerEvents.DropCarriable
// Size: 0xd0 (Inherited: 0xa0)
struct UDropCarriable : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString CarriableName; // 0xb8(0x10)

	struct TArray<struct UDropCarriable*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DropCarriable.From // (Final|Native|Static|Public) // @ game+0x5968840
};

// Class EmbarkServerEvents.DropItem
// Size: 0xf0 (Inherited: 0xa0)
struct UDropItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Amount; // 0xa0(0x08)
	struct FVector Location; // 0xa8(0x18)
	int64_t GameAssetId; // 0xc0(0x08)
	struct FString InstanceId; // 0xc8(0x10)
	struct FString Container; // 0xd8(0x10)

	struct TArray<struct UDropItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DropItem.From // (Final|Native|Static|Public) // @ game+0x5991230
};

// Class EmbarkServerEvents.DualBladeDeflect
// Size: 0x110 (Inherited: 0xa0)
struct UDualBladeDeflect : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t DeflectedGameAssetId; // 0xb8(0x08)
	struct FString DeflectedItemName; // 0xc0(0x10)
	struct FString DeflectedItemTag; // 0xd0(0x10)
	int64_t InstigatorPlayer; // 0xe0(0x08)
	struct FVector InstigatorLocation; // 0xe8(0x18)
	int64_t DeflectingItem; // 0x100(0x08)

	struct TArray<struct UDualBladeDeflect*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.DualBladeDeflect.From // (Final|Native|Static|Public) // @ game+0x59cbe30
};

// Class EmbarkServerEvents.EOSProductUserId
// Size: 0xb0 (Inherited: 0xa0)
struct UEOSProductUserId : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ProductUserId; // 0xa0(0x10)

	struct TArray<struct UEOSProductUserId*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EOSProductUserId.From // (Final|Native|Static|Public) // @ game+0x5994530
};

// Class EmbarkServerEvents.EmoteUsed
// Size: 0xb0 (Inherited: 0xa0)
struct UEmoteUsed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString EmoteName; // 0xa0(0x10)

	struct TArray<struct UEmoteUsed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EmoteUsed.From // (Final|Native|Static|Public) // @ game+0x5975c20
};

// Class EmbarkServerEvents.EmoteUsed2
// Size: 0xc0 (Inherited: 0xa0)
struct UEmoteUsed2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString EmoteName; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)

	struct TArray<struct UEmoteUsed2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EmoteUsed2.From // (Final|Native|Static|Public) // @ game+0x599c2d0
};

// Class EmbarkServerEvents.EndUseInstrument
// Size: 0xd0 (Inherited: 0xa0)
struct UEndUseInstrument : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	float Duration; // 0xc0(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)

	struct TArray<struct UEndUseInstrument*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EndUseInstrument.From // (Final|Native|Static|Public) // @ game+0x59b1ff0
};

// Class EmbarkServerEvents.EndedAbility
// Size: 0xd0 (Inherited: 0xa0)
struct UEndedAbility : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Ability; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	bool bWasCancelled; // 0xc8(0x01)

	struct TArray<struct UEndedAbility*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EndedAbility.From // (Final|Native|Static|Public) // @ game+0x5926390
};

// Class EmbarkServerEvents.EnemyAbilityActivated
// Size: 0xe0 (Inherited: 0xa0)
struct UEnemyAbilityActivated : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	int64_t EnemyId; // 0xa8(0x08)
	struct FString AbilityTag; // 0xb0(0x10)
	struct FVector Location; // 0xc0(0x18)

	struct TArray<struct UEnemyAbilityActivated*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyAbilityActivated.From // (Final|Native|Static|Public) // @ game+0x59a8f90
};

// Class EmbarkServerEvents.EnemyAlertNonPlayer
// Size: 0x140 (Inherited: 0xa0)
struct UEnemyAlertNonPlayer : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FString NewAlertness; // 0xa8(0x10)
	int64_t NewAlertnessIndex; // 0xb8(0x08)
	struct FString OldAlertness; // 0xc0(0x10)
	int64_t OldAlertnessIndex; // 0xd0(0x08)
	struct FString AlertnessSource; // 0xd8(0x10)
	struct FString LastTag; // 0xe8(0x10)
	struct FVector Location; // 0xf8(0x18)
	int64_t EnemyId; // 0x110(0x08)
	int64_t TargetGameAssetId; // 0x118(0x08)
	float SightAlertness; // 0x120(0x04)
	float HearingAlertness; // 0x124(0x04)
	float DamageAlertness; // 0x128(0x04)
	float BypassAlertness; // 0x12c(0x04)
	float NetworkAlertness; // 0x130(0x04)
	float TouchAlertness; // 0x134(0x04)

	struct TArray<struct UEnemyAlertNonPlayer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyAlertNonPlayer.From // (Final|Native|Static|Public) // @ game+0x598aad0
};

// Class EmbarkServerEvents.EnemyAlert3
// Size: 0x140 (Inherited: 0xa0)
struct UEnemyAlert3 : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FString NewAlertness; // 0xa8(0x10)
	int64_t NewAlertnessIndex; // 0xb8(0x08)
	struct FString OldAlertness; // 0xc0(0x10)
	int64_t OldAlertnessIndex; // 0xd0(0x08)
	struct FString AlertnessSource; // 0xd8(0x10)
	struct FString LastTag; // 0xe8(0x10)
	struct FVector Location; // 0xf8(0x18)
	int64_t EnemyId; // 0x110(0x08)
	int64_t TargetPlayer; // 0x118(0x08)
	int64_t TargetGameAssetId; // 0x120(0x08)
	float SightAlertness; // 0x128(0x04)
	float HearingAlertness; // 0x12c(0x04)
	float DamageAlertness; // 0x130(0x04)
	float BypassAlertness; // 0x134(0x04)
	float NetworkAlertness; // 0x138(0x04)
	float TouchAlertness; // 0x13c(0x04)

	struct TArray<struct UEnemyAlert3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyAlert3.From // (Final|Native|Static|Public) // @ game+0x59cb170
};

// Class EmbarkServerEvents.EnemyDamagePlayer5
// Size: 0x140 (Inherited: 0xa0)
struct UEnemyDamagePlayer5 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	struct FString Enemy; // 0xc0(0x10)
	struct FVector EnemyLocation; // 0xd0(0x18)
	float HealthBefore; // 0xe8(0x04)
	float HealthAfter; // 0xec(0x04)
	struct FString DamageCauser; // 0xf0(0x10)
	bool bIsDbno; // 0x100(0x01)
	struct FString BoneHit; // 0x108(0x10)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x118(0x10)
	float DbnoHealthBefore; // 0x128(0x04)
	float DbnoHealthAfter; // 0x12c(0x04)
	bool bWasDbno; // 0x130(0x01)
	char pad_132[0x2]; // 0x132(0x02)
	float ArmorHealthBefore; // 0x134(0x04)
	float ArmorHealthAfter; // 0x138(0x04)
	float ArmorMitigatedDamage; // 0x13c(0x04)

	struct TArray<struct UEnemyDamagePlayer5*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyDamagePlayer5.From // (Final|Native|Static|Public) // @ game+0x59d0bd0
};

// Class EmbarkServerEvents.EnemyDamage3
// Size: 0x150 (Inherited: 0xa0)
struct UEnemyDamage3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString DamageCauser; // 0xb8(0x10)
	int64_t WeaponId; // 0xc8(0x08)
	struct FString Weapon; // 0xd0(0x10)
	int64_t ProjectileId; // 0xe0(0x08)
	struct FString Target; // 0xe8(0x10)
	struct FVector TargetLocation; // 0xf8(0x18)
	int64_t EnemyId; // 0x110(0x08)
	int64_t PartID; // 0x118(0x08)
	struct FString PartHit; // 0x120(0x10)
	float DamageTaken; // 0x130(0x04)
	bool bIsCriticalPart; // 0x134(0x01)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x138(0x10)
	char pad_14d[0x3]; // 0x14d(0x03)

	struct TArray<struct UEnemyDamage3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyDamage3.From // (Final|Native|Static|Public) // @ game+0x5951c00
};

// Class EmbarkServerEvents.EnemyDamage4
// Size: 0x160 (Inherited: 0xa0)
struct UEnemyDamage4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString DamageCauser; // 0xb8(0x10)
	int64_t WeaponId; // 0xc8(0x08)
	struct FString Weapon; // 0xd0(0x10)
	int64_t ProjectileId; // 0xe0(0x08)
	struct FString Target; // 0xe8(0x10)
	struct FVector TargetLocation; // 0xf8(0x18)
	int64_t EnemyId; // 0x110(0x08)
	int64_t PartID; // 0x118(0x08)
	struct FString PartHit; // 0x120(0x10)
	float DamageTaken; // 0x130(0x04)
	bool bIsCriticalPart; // 0x134(0x01)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x138(0x10)
	struct FString WeaponInstanceId; // 0x148(0x10)
	char pad_15d[0x3]; // 0x15d(0x03)

	struct TArray<struct UEnemyDamage4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyDamage4.From // (Final|Native|Static|Public) // @ game+0x591f080
};

// Class EmbarkServerEvents.EnemyDestroyed2
// Size: 0xf0 (Inherited: 0xa0)
struct UEnemyDestroyed2 : UServerEventTestBase {
	int64_t EnemySpawnId; // 0x98(0x08)
	int64_t EnemyId; // 0xa0(0x08)
	struct FVector Location; // 0xa8(0x18)
	struct FString Target; // 0xc0(0x10)
	bool bSelfDestoyed; // 0xd0(0x01)
	struct FString HealthChangeReason; // 0xd8(0x10)
	int64_t AffectedPartID; // 0xe8(0x08)

	struct TArray<struct UEnemyDestroyed2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyDestroyed2.From // (Final|Native|Static|Public) // @ game+0x5988060
};

// Class EmbarkServerEvents.EnemyEvict2
// Size: 0xf0 (Inherited: 0xa0)
struct UEnemyEvict2 : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	int64_t EnemyId; // 0xc0(0x08)
	bool bInCombat; // 0xc8(0x01)
	struct FString Reason; // 0xd0(0x10)
	int64_t EnemySpawnId; // 0xe0(0x08)
	char pad_e9[0x7]; // 0xe9(0x07)

	struct TArray<struct UEnemyEvict2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyEvict2.From // (Final|Native|Static|Public) // @ game+0x5993c20
};

// Class EmbarkServerEvents.EnemyForceDestroyParts
// Size: 0x100 (Inherited: 0xa0)
struct UEnemyForceDestroyParts : UServerEventTestBase {
	int64_t EnemySpawnId; // 0x98(0x08)
	int64_t EnemyId; // 0xa0(0x08)
	struct FVector Location; // 0xa8(0x18)
	struct FString Target; // 0xc0(0x10)
	struct FString ExplosionEffectName; // 0xd0(0x10)
	struct FString Querystring; // 0xe0(0x10)
	struct FString TargetType; // 0xf0(0x10)

	struct TArray<struct UEnemyForceDestroyParts*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyForceDestroyParts.From // (Final|Native|Static|Public) // @ game+0x5952560
};

// Class EmbarkServerEvents.EnemyHit4
// Size: 0x110 (Inherited: 0xa0)
struct UEnemyHit4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector PlayerLocation; // 0xa0(0x18)
	int64_t WeaponGameAssetId; // 0xb8(0x08)
	struct FString Enemy; // 0xc0(0x10)
	int64_t EnemyGameAssetId; // 0xd0(0x08)
	struct FVector EnemyLocation; // 0xd8(0x18)
	int64_t PartHitId; // 0xf0(0x08)
	struct FString PartHit; // 0xf8(0x10)
	bool bIsDestroyed; // 0x108(0x01)

	struct TArray<struct UEnemyHit4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyHit4.From // (Final|Native|Static|Public) // @ game+0x5965230
};

// Class EmbarkServerEvents.EnemyHit5
// Size: 0x120 (Inherited: 0xa0)
struct UEnemyHit5 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector PlayerLocation; // 0xa0(0x18)
	int64_t WeaponGameAssetId; // 0xb8(0x08)
	struct FString Enemy; // 0xc0(0x10)
	int64_t EnemyGameAssetId; // 0xd0(0x08)
	struct FVector EnemyLocation; // 0xd8(0x18)
	int64_t PartHitId; // 0xf0(0x08)
	struct FString PartHit; // 0xf8(0x10)
	bool bIsDestroyed; // 0x108(0x01)
	struct FString WeaponInstanceId; // 0x110(0x10)

	struct TArray<struct UEnemyHit5*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyHit5.From // (Final|Native|Static|Public) // @ game+0x59d9c40
};

// Class EmbarkServerEvents.EnemyKill2
// Size: 0xf0 (Inherited: 0xa0)
struct UEnemyKill2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t EnemyId; // 0xa0(0x08)
	int64_t WeaponId; // 0xa8(0x08)
	int64_t ProjectileId; // 0xb0(0x08)
	struct FVector Location; // 0xb8(0x18)
	struct FString DamageCauser; // 0xd0(0x10)
	struct FString Target; // 0xe0(0x10)

	struct TArray<struct UEnemyKill2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyKill2.From // (Final|Native|Static|Public) // @ game+0x5908a10
};

// Class EmbarkServerEvents.EnemyKill3
// Size: 0x100 (Inherited: 0xa0)
struct UEnemyKill3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t EnemyId; // 0xa0(0x08)
	int64_t WeaponId; // 0xa8(0x08)
	int64_t ProjectileId; // 0xb0(0x08)
	struct FVector Location; // 0xb8(0x18)
	struct FString DamageCauser; // 0xd0(0x10)
	struct FString Target; // 0xe0(0x10)
	struct FString WeaponInstanceId; // 0xf0(0x10)

	struct TArray<struct UEnemyKill3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyKill3.From // (Final|Native|Static|Public) // @ game+0x59d6f60
};

// Class EmbarkServerEvents.EnemyPhysicsDamage2
// Size: 0x110 (Inherited: 0xa0)
struct UEnemyPhysicsDamage2 : UServerEventTestBase {
	int64_t EnemyId; // 0x98(0x08)
	float DamageTaken; // 0xa0(0x04)
	struct FString PartHit; // 0xa8(0x10)
	struct FVector Location; // 0xb8(0x18)
	bool bIsCriticalPart; // 0xd0(0x01)
	char pad_d5[0x3]; // 0xd5(0x03)
	struct FString DamageCauser; // 0xd8(0x10)
	struct FString Target; // 0xe8(0x10)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0xf8(0x10)
	char pad_108[0x8]; // 0x108(0x08)

	struct TArray<struct UEnemyPhysicsDamage2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyPhysicsDamage2.From // (Final|Native|Static|Public) // @ game+0x598ed80
};

// Class EmbarkServerEvents.EnemyPhysicsKill
// Size: 0xe0 (Inherited: 0xa0)
struct UEnemyPhysicsKill : UServerEventTestBase {
	int64_t EnemyId; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString DamageCauser; // 0xb8(0x10)
	struct FString Target; // 0xc8(0x10)

	struct TArray<struct UEnemyPhysicsKill*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyPhysicsKill.From // (Final|Native|Static|Public) // @ game+0x5911d70
};

// Class EmbarkServerEvents.EnemyPosition
// Size: 0x100 (Inherited: 0xa0)
struct UEnemyPosition : UServerEventTestBase {
	int64_t EnemySpawnId; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FVector ForwardVector; // 0xb8(0x18)
	struct FVector Velocity; // 0xd0(0x18)
	struct FString Enemy; // 0xe8(0x10)
	int64_t EnemyId; // 0xf8(0x08)

	struct TArray<struct UEnemyPosition*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyPosition.From // (Final|Native|Static|Public) // @ game+0x5977e00
};

// Class EmbarkServerEvents.EnemySpawned3
// Size: 0xf0 (Inherited: 0xa0)
struct UEnemySpawned3 : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	int64_t GroupId; // 0xc0(0x08)
	int64_t EnemyId; // 0xc8(0x08)
	int64_t EnemySpawnId; // 0xd0(0x08)
	struct FString Alertness; // 0xd8(0x10)

	struct TArray<struct UEnemySpawned3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemySpawned3.From // (Final|Native|Static|Public) // @ game+0x5958ab0
};

// Class EmbarkServerEvents.EnemyStuck2
// Size: 0xd0 (Inherited: 0xa0)
struct UEnemyStuck2 : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	int64_t AssetId; // 0xc0(0x08)

	struct TArray<struct UEnemyStuck2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyStuck2.From // (Final|Native|Static|Public) // @ game+0x590ee30
};

// Class EmbarkServerEvents.EnemyWeaponFired2
// Size: 0x110 (Inherited: 0xa0)
struct UEnemyWeaponFired2 : UServerEventTestBase {
	struct FString Weapon; // 0x98(0x10)
	struct FString ProjectileClass; // 0xa8(0x10)
	struct FVector Location; // 0xb8(0x18)
	struct FVector Direction; // 0xd0(0x18)
	struct FString Enemy; // 0xe8(0x10)
	int64_t EnemyId; // 0xf8(0x08)
	int64_t TargetPlayer; // 0x100(0x08)
	int64_t TargetGameAssetId; // 0x108(0x08)

	struct TArray<struct UEnemyWeaponFired2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnemyWeaponFired2.From // (Final|Native|Static|Public) // @ game+0x59bd8b0
};

// Class EmbarkServerEvents.EnvironmentLootSpawned2
// Size: 0xe0 (Inherited: 0xa0)
struct UEnvironmentLootSpawned2 : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	struct TArray<struct FString> Tags; // 0xb0(0x10)
	int64_t ItemAssetId; // 0xc0(0x08)
	int64_t Amount; // 0xc8(0x08)
	struct FString InstanceId; // 0xd0(0x10)

	struct TArray<struct UEnvironmentLootSpawned2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EnvironmentLootSpawned2.From // (Final|Native|Static|Public) // @ game+0x599a4c0
};

// Class EmbarkServerEvents.EquipItemFailure
// Size: 0xd0 (Inherited: 0xa0)
struct UEquipItemFailure : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString SlotName; // 0xa0(0x10)
	struct FString ItemName; // 0xb0(0x10)
	struct FString FailureReason; // 0xc0(0x10)

	struct TArray<struct UEquipItemFailure*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EquipItemFailure.From // (Final|Native|Static|Public) // @ game+0x5907500
};

// Class EmbarkServerEvents.EquippedLoadoutFrame
// Size: 0xb0 (Inherited: 0xa0)
struct UEquippedLoadoutFrame : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t LoadoutFrameGameAssetId; // 0xa0(0x08)
	int64_t AugmentGameAssetId; // 0xa8(0x08)

	struct TArray<struct UEquippedLoadoutFrame*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EquippedLoadoutFrame.From // (Final|Native|Static|Public) // @ game+0x59cd3b0
};

// Class EmbarkServerEvents.EventDropped
// Size: 0xc0 (Inherited: 0xa0)
struct UEventDropped : UServerEventTestBase {
	struct FString EventName; // 0x98(0x10)
	int64_t EventSize; // 0xa8(0x08)
	int64_t StreamSize; // 0xb0(0x08)

	struct TArray<struct UEventDropped*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.EventDropped.From // (Final|Native|Static|Public) // @ game+0x5977310
};

// Class EmbarkServerEvents.ExpectedPlayersProxy
// Size: 0xb0 (Inherited: 0xa0)
struct UExpectedPlayersProxy : UServerEventTestBase {
	int64_t Amount; // 0x98(0x08)
	struct TArray<int64_t> ExpectedPlayerIds; // 0xa0(0x10)

	struct TArray<struct UExpectedPlayersProxy*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExpectedPlayersProxy.From // (Final|Native|Static|Public) // @ game+0x59c6e70
};

// Class EmbarkServerEvents.ExplosiveBarrelSpawned
// Size: 0xc0 (Inherited: 0xa0)
struct UExplosiveBarrelSpawned : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	struct FString Name; // 0xb0(0x10)

	struct TArray<struct UExplosiveBarrelSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExplosiveBarrelSpawned.From // (Final|Native|Static|Public) // @ game+0x5923660
};

// Class EmbarkServerEvents.ExtractedInventorySlot7
// Size: 0xf0 (Inherited: 0xa0)
struct UExtractedInventorySlot7 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Amount; // 0xa0(0x08)
	int64_t GameAssetId; // 0xa8(0x08)
	struct FString InstanceId; // 0xb0(0x10)
	struct FString Container; // 0xc0(0x10)
	float Durability; // 0xd0(0x04)
	float MaxDurability; // 0xd4(0x04)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0xd8(0x10)

	struct TArray<struct UExtractedInventorySlot7*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExtractedInventorySlot7.From // (Final|Native|Static|Public) // @ game+0x59cb980
};

// Class EmbarkServerEvents.ExtractionFinalized
// Size: 0xb0 (Inherited: 0xa0)
struct UExtractionFinalized : UServerEventTestBase {
	struct FString Name; // 0x98(0x10)
	int32_t PlayerAmount; // 0xa8(0x04)
	int32_t ExtractionCycle; // 0xac(0x04)

	struct TArray<struct UExtractionFinalized*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExtractionFinalized.From // (Final|Native|Static|Public) // @ game+0x59c72e0
};

// Class EmbarkServerEvents.ExtractionPointRequiredItems
// Size: 0xd0 (Inherited: 0xa0)
struct UExtractionPointRequiredItems : UServerEventTestBase {
	struct FString ExtractionPointName; // 0x98(0x10)
	struct FString InteractionName; // 0xa8(0x10)
	struct TArray<struct FFieldTypeAssetIdAmount> RequiredItems; // 0xb8(0x10)

	struct TArray<struct UExtractionPointRequiredItems*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExtractionPointRequiredItems.From // (Final|Native|Static|Public) // @ game+0x5991370
};

// Class EmbarkServerEvents.ExtractionPointStateChanged
// Size: 0xf0 (Inherited: 0xa0)
struct UExtractionPointStateChanged : UServerEventTestBase {
	struct FString ExtractionPointName; // 0x98(0x10)
	struct FVector ExtractionPointLocation; // 0xa8(0x18)
	struct FString ExtractionPointType; // 0xc0(0x10)
	struct FString OldState; // 0xd0(0x10)
	struct FString NewState; // 0xe0(0x10)

	struct TArray<struct UExtractionPointStateChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExtractionPointStateChanged.From // (Final|Native|Static|Public) // @ game+0x5943850
};

// Class EmbarkServerEvents.ExtractionPointStateChanged2
// Size: 0x100 (Inherited: 0xa0)
struct UExtractionPointStateChanged2 : UServerEventTestBase {
	struct FString ExtractionPointName; // 0x98(0x10)
	struct FVector ExtractionPointLocation; // 0xa8(0x18)
	struct FString ExtractionPointType; // 0xc0(0x10)
	struct FString OldState; // 0xd0(0x10)
	struct FString NewState; // 0xe0(0x10)
	struct FString GeneratedName; // 0xf0(0x10)

	struct TArray<struct UExtractionPointStateChanged2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExtractionPointStateChanged2.From // (Final|Native|Static|Public) // @ game+0x59a9810
};

// Class EmbarkServerEvents.ExtractionTimerStarted
// Size: 0xb0 (Inherited: 0xa0)
struct UExtractionTimerStarted : UServerEventTestBase {
	struct FString Name; // 0x98(0x10)
	int32_t ExtractionCycle; // 0xa8(0x04)

	struct TArray<struct UExtractionTimerStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ExtractionTimerStarted.From // (Final|Native|Static|Public) // @ game+0x592f260
};

// Class EmbarkServerEvents.FailedToActivateAbility
// Size: 0xe0 (Inherited: 0xa0)
struct UFailedToActivateAbility : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Ability; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	struct FString FailureReason; // 0xc8(0x10)

	struct TArray<struct UFailedToActivateAbility*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.FailedToActivateAbility.From // (Final|Native|Static|Public) // @ game+0x59a9cc0
};

// Class EmbarkServerEvents.FallDamage3
// Size: 0xe0 (Inherited: 0xa0)
struct UFallDamage3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	float DamageTaken; // 0xb8(0x04)
	float HealthBefore; // 0xbc(0x04)
	float HealthAfter; // 0xc0(0x04)
	bool bIsDbno; // 0xc4(0x01)
	float DbnoHealthBefore; // 0xc8(0x04)
	float DbnoHealthAfter; // 0xcc(0x04)
	bool bWasDbno; // 0xd0(0x01)
	char pad_d6[0xa]; // 0xd6(0x0a)

	struct TArray<struct UFallDamage3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.FallDamage3.From // (Final|Native|Static|Public) // @ game+0x5995670
};

// Class EmbarkServerEvents.FoundStartGroup3
// Size: 0xe0 (Inherited: 0xa0)
struct UFoundStartGroup3 : UServerEventTestBase {
	struct FString GroupName; // 0x98(0x10)
	struct FString RestartContext; // 0xa8(0x10)
	struct FString AdditionalInfo; // 0xb8(0x10)
	int32_t GroupSize; // 0xc8(0x04)
	int32_t RequestSize; // 0xcc(0x04)
	int32_t SquadIndex; // 0xd0(0x04)
	int64_t Seed; // 0xd8(0x08)

	struct TArray<struct UFoundStartGroup3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.FoundStartGroup3.From // (Final|Native|Static|Public) // @ game+0x5913c30
};

// Class EmbarkServerEvents.GameCancelStateSet
// Size: 0xb0 (Inherited: 0xa0)
struct UGameCancelStateSet : UServerEventTestBase {
	struct FString Reason; // 0x98(0x10)

	struct TArray<struct UGameCancelStateSet*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameCancelStateSet.From // (Final|Native|Static|Public) // @ game+0x590f7c0
};

// Class EmbarkServerEvents.GameMap
// Size: 0xb0 (Inherited: 0xa0)
struct UGameMap : UServerEventTestBase {
	struct FString GameMap; // 0x98(0x10)

	struct TArray<struct UGameMap*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameMap.From // (Final|Native|Static|Public) // @ game+0x59c3e00
};

// Class EmbarkServerEvents.GameMode2
// Size: 0xe0 (Inherited: 0xa0)
struct UGameMode2 : UServerEventTestBase {
	struct FString Mode; // 0x98(0x10)
	struct FString Difficulty; // 0xa8(0x10)
	struct FString Severity; // 0xb8(0x10)
	struct FString LocationTag; // 0xc8(0x10)

	struct TArray<struct UGameMode2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameMode2.From // (Final|Native|Static|Public) // @ game+0x59c14f0
};

// Class EmbarkServerEvents.GamePassBonusXp
// Size: 0xb0 (Inherited: 0xa0)
struct UGamePassBonusXp : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t GamePassBonusXp; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UGamePassBonusXp*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GamePassBonusXp.From // (Final|Native|Static|Public) // @ game+0x59ac740
};

// Class EmbarkServerEvents.GameplayEffectAdded
// Size: 0xd0 (Inherited: 0xa0)
struct UGameplayEffectAdded : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t InstigatorPlayer; // 0xb8(0x08)
	struct FString Tag; // 0xc0(0x10)

	struct TArray<struct UGameplayEffectAdded*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameplayEffectAdded.From // (Final|Native|Static|Public) // @ game+0x5924790
};

// Class EmbarkServerEvents.GameplayEffectRemoved
// Size: 0xd0 (Inherited: 0xa0)
struct UGameplayEffectRemoved : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t InstigatorPlayer; // 0xb8(0x08)
	struct FString Tag; // 0xc0(0x10)

	struct TArray<struct UGameplayEffectRemoved*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameplayEffectRemoved.From // (Final|Native|Static|Public) // @ game+0x593ed40
};

// Class EmbarkServerEvents.GameplayOver
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayOver : UServerEventTestBase {
	int64_t UnrealTime; // 0x98(0x08)

	struct TArray<struct UGameplayOver*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameplayOver.From // (Final|Native|Static|Public) // @ game+0x59319d0
};

// Class EmbarkServerEvents.GameshowEventStarted
// Size: 0xb0 (Inherited: 0xa0)
struct UGameshowEventStarted : UServerEventTestBase {
	struct FString GameShow; // 0x98(0x10)

	struct TArray<struct UGameshowEventStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameshowEventStarted.From // (Final|Native|Static|Public) // @ game+0x59be840
};

// Class EmbarkServerEvents.GameshowEventStopped
// Size: 0xb0 (Inherited: 0xa0)
struct UGameshowEventStopped : UServerEventTestBase {
	struct FString GameShow; // 0x98(0x10)

	struct TArray<struct UGameshowEventStopped*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GameshowEventStopped.From // (Final|Native|Static|Public) // @ game+0x5926250
};

// Class EmbarkServerEvents.GenesisTeamRoundStartWealth
// Size: 0xc0 (Inherited: 0xa0)
struct UGenesisTeamRoundStartWealth : UServerEventTestBase {
	int64_t Round; // 0x98(0x08)
	struct FString Team; // 0xa0(0x10)
	int64_t Wealth; // 0xb0(0x08)

	struct TArray<struct UGenesisTeamRoundStartWealth*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GenesisTeamRoundStartWealth.From // (Final|Native|Static|Public) // @ game+0x59887a0
};

// Class EmbarkServerEvents.GooSpawned2
// Size: 0xe0 (Inherited: 0xa0)
struct UGooSpawned2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString CauserClass; // 0xa0(0x10)
	struct FString SourceTag; // 0xb0(0x10)
	struct FVector Location; // 0xc0(0x18)
	int64_t NumGooBlobs; // 0xd8(0x08)

	struct TArray<struct UGooSpawned2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GooSpawned2.From // (Final|Native|Static|Public) // @ game+0x5985160
};

// Class EmbarkServerEvents.GravityZoneUpdated
// Size: 0xd0 (Inherited: 0xa0)
struct UGravityZoneUpdated : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector GravityZoneLocation; // 0xa0(0x18)
	int64_t CreationFrame; // 0xb8(0x08)
	int64_t CharactersInZone; // 0xc0(0x08)
	int64_t ComponentsInZone; // 0xc8(0x08)

	struct TArray<struct UGravityZoneUpdated*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.GravityZoneUpdated.From // (Final|Native|Static|Public) // @ game+0x5959aa0
};

// Class EmbarkServerEvents.HarpoonFailure
// Size: 0x100 (Inherited: 0xa0)
struct UHarpoonFailure : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString OwningName; // 0xa0(0x10)
	struct FString FailureReason; // 0xb0(0x10)
	float Ping; // 0xc0(0x04)
	float FloatValue1; // 0xc4(0x04)
	float FloatValue2; // 0xc8(0x04)
	struct FString TargetActorName; // 0xd0(0x10)
	struct FString TargetName; // 0xe0(0x10)
	struct FString TargetBone; // 0xf0(0x10)

	struct TArray<struct UHarpoonFailure*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.HarpoonFailure.From // (Final|Native|Static|Public) // @ game+0x598f3f0
};

// Class EmbarkServerEvents.HarvesterCoreStateChanged
// Size: 0xe0 (Inherited: 0xa0)
struct UHarvesterCoreStateChanged : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	struct FString PreviousState; // 0xc0(0x10)
	struct FString NewState; // 0xd0(0x10)

	struct TArray<struct UHarvesterCoreStateChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.HarvesterCoreStateChanged.From // (Final|Native|Static|Public) // @ game+0x591ecd0
};

// Class EmbarkServerEvents.HealthChange6
// Size: 0x110 (Inherited: 0xa0)
struct UHealthChange6 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	float HealthBefore; // 0xb8(0x04)
	float HealthAfter; // 0xbc(0x04)
	struct FString DamageCauser; // 0xc0(0x10)
	bool bIsDbno; // 0xd0(0x01)
	struct FString BoneHit; // 0xd8(0x10)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0xe8(0x10)
	float DbnoHealthBefore; // 0xf8(0x04)
	float DbnoHealthAfter; // 0xfc(0x04)
	bool bWasDbno; // 0x100(0x01)
	char pad_102[0x2]; // 0x102(0x02)
	float ArmorHealthBefore; // 0x104(0x04)
	float ArmorHealthAfter; // 0x108(0x04)
	float ArmorMitigatedDamage; // 0x10c(0x04)

	struct TArray<struct UHealthChange6*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.HealthChange6.From // (Final|Native|Static|Public) // @ game+0x59c3f40
};

// Class EmbarkServerEvents.HitscanValidationFailed2
// Size: 0x160 (Inherited: 0xa0)
struct UHitscanValidationFailed2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	float PlayerPing; // 0xa8(0x04)
	float TargetPlayerPing; // 0xac(0x04)
	struct FVector AimingLocation; // 0xb0(0x18)
	struct FVector ActorLocation; // 0xc8(0x18)
	struct FVector HitLocation; // 0xe0(0x18)
	struct FVector PelvisLocation; // 0xf8(0x18)
	bool bIsCrouching; // 0x110(0x01)
	struct FString Reason; // 0x118(0x10)
	float FailingValue; // 0x128(0x04)
	char pad_12d[0x3]; // 0x12d(0x03)
	struct FString ExtraContext; // 0x130(0x10)
	int64_t CauserGameAssetId; // 0x140(0x08)
	struct FString CauserItemName; // 0x148(0x10)
	char pad_158[0x8]; // 0x158(0x08)

	struct TArray<struct UHitscanValidationFailed2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.HitscanValidationFailed2.From // (Final|Native|Static|Public) // @ game+0x5976020
};

// Class EmbarkServerEvents.InputBufferOverflow
// Size: 0xa0 (Inherited: 0xa0)
struct UInputBufferOverflow : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UInputBufferOverflow*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InputBufferOverflow.From // (Final|Native|Static|Public) // @ game+0x59d7320
};

// Class EmbarkServerEvents.InputMethodChanged
// Size: 0xb0 (Inherited: 0xa0)
struct UInputMethodChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString InputDevice; // 0xa0(0x10)

	struct TArray<struct UInputMethodChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InputMethodChanged.From // (Final|Native|Static|Public) // @ game+0x596b550
};

// Class EmbarkServerEvents.InstantReplayEnabledOnServer
// Size: 0xb0 (Inherited: 0xa0)
struct UInstantReplayEnabledOnServer : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	bool bIsReplaysEnabled; // 0xa0(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)

	struct TArray<struct UInstantReplayEnabledOnServer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InstantReplayEnabledOnServer.From // (Final|Native|Static|Public) // @ game+0x5912a10
};

// Class EmbarkServerEvents.InteractionEnded
// Size: 0xf0 (Inherited: 0xa0)
struct UInteractionEnded : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString InteractionName; // 0xb8(0x10)
	struct FString ObjectName; // 0xc8(0x10)
	struct FString PromptText; // 0xd8(0x10)
	bool bEndedSuccessfully; // 0xe8(0x01)

	struct TArray<struct UInteractionEnded*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InteractionEnded.From // (Final|Native|Static|Public) // @ game+0x5905c00
};

// Class EmbarkServerEvents.InteractionStarted
// Size: 0xf0 (Inherited: 0xa0)
struct UInteractionStarted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString InteractionName; // 0xb8(0x10)
	struct FString ObjectName; // 0xc8(0x10)
	struct FString PromptText; // 0xd8(0x10)

	struct TArray<struct UInteractionStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InteractionStarted.From // (Final|Native|Static|Public) // @ game+0x5987830
};

// Class EmbarkServerEvents.InventoryContainerFull
// Size: 0xb0 (Inherited: 0xa0)
struct UInventoryContainerFull : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Container; // 0xa0(0x10)

	struct TArray<struct UInventoryContainerFull*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InventoryContainerFull.From // (Final|Native|Static|Public) // @ game+0x598db80
};

// Class EmbarkServerEvents.InventoryUpdateCompleted
// Size: 0xa0 (Inherited: 0xa0)
struct UInventoryUpdateCompleted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UInventoryUpdateCompleted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.InventoryUpdateCompleted.From // (Final|Native|Static|Public) // @ game+0x59b85c0
};

// Class EmbarkServerEvents.ItemBroke2
// Size: 0xc0 (Inherited: 0xa0)
struct UItemBroke2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FString InstanceId; // 0xa8(0x10)
	float MaxDurability; // 0xb8(0x04)

	struct TArray<struct UItemBroke2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemBroke2.From // (Final|Native|Static|Public) // @ game+0x59dcd60
};

// Class EmbarkServerEvents.ItemEquipped3
// Size: 0xe0 (Inherited: 0xa0)
struct UItemEquipped3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	int64_t ItemId; // 0xc8(0x08)
	struct FString InstanceId; // 0xd0(0x10)

	struct TArray<struct UItemEquipped3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemEquipped3.From // (Final|Native|Static|Public) // @ game+0x5989810
};

// Class EmbarkServerEvents.ItemEquipped4
// Size: 0xf0 (Inherited: 0xa0)
struct UItemEquipped4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	int64_t ItemId; // 0xc8(0x08)
	struct FString InstanceId; // 0xd0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0xe0(0x10)

	struct TArray<struct UItemEquipped4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemEquipped4.From // (Final|Native|Static|Public) // @ game+0x592c1c0
};

// Class EmbarkServerEvents.ItemFieldCrafted3
// Size: 0xd0 (Inherited: 0xa0)
struct UItemFieldCrafted3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<struct FFieldTypeAssetInstanceAmounts> ConsumedItems; // 0xa0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmounts> ProducedItems; // 0xb0(0x10)
	int64_t OfferId; // 0xc0(0x08)

	struct TArray<struct UItemFieldCrafted3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemFieldCrafted3.From // (Final|Native|Static|Public) // @ game+0x59ba910
};

// Class EmbarkServerEvents.ItemFieldSalvaged3
// Size: 0xd0 (Inherited: 0xa0)
struct UItemFieldSalvaged3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<struct FFieldTypeAssetInstanceAmounts> ConsumedItems; // 0xa0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmounts> ProducedItems; // 0xb0(0x10)
	int64_t OfferId; // 0xc0(0x08)

	struct TArray<struct UItemFieldSalvaged3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemFieldSalvaged3.From // (Final|Native|Static|Public) // @ game+0x591af60
};

// Class EmbarkServerEvents.ItemFireFailure
// Size: 0xd0 (Inherited: 0xa0)
struct UItemFireFailure : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString FailureReason; // 0xa0(0x10)
	int64_t GameAssetId; // 0xb0(0x08)
	struct FString ItemName; // 0xb8(0x10)
	float DebugFloat1; // 0xc8(0x04)
	float DebugFloat2; // 0xcc(0x04)

	struct TArray<struct UItemFireFailure*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemFireFailure.From // (Final|Native|Static|Public) // @ game+0x5982720
};

// Class EmbarkServerEvents.ItemHit
// Size: 0xf0 (Inherited: 0xa0)
struct UItemHit : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector PlayerLocation; // 0xa0(0x18)
	int64_t WeaponGameAssetId; // 0xb8(0x08)
	struct FString ItemName; // 0xc0(0x10)
	int64_t ItemGameAssetId; // 0xd0(0x08)
	struct FVector ItemLocation; // 0xd8(0x18)

	struct TArray<struct UItemHit*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemHit.From // (Final|Native|Static|Public) // @ game+0x5968d60
};

// Class EmbarkServerEvents.ItemInventoryChange13
// Size: 0x170 (Inherited: 0xa0)
struct UItemInventoryChange13 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemType; // 0xa0(0x10)
	struct FString Rarity; // 0xb0(0x10)
	struct FString ItemSource; // 0xc0(0x10)
	int32_t AmountBefore; // 0xd0(0x04)
	int32_t AmountAfter; // 0xd4(0x04)
	struct FVector Location; // 0xd8(0x18)
	int64_t ItemId; // 0xf0(0x08)
	struct FString InstanceId; // 0xf8(0x10)
	struct FString Container; // 0x108(0x10)
	float Durability; // 0x118(0x04)
	float MaxDurability; // 0x11c(0x04)
	int64_t OccupiedSlots; // 0x120(0x08)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0x128(0x10)
	struct FString SourceInstanceId; // 0x138(0x10)
	struct FString FromContainerOwner; // 0x148(0x10)
	struct FString ToContainerOwner; // 0x158(0x10)

	struct TArray<struct UItemInventoryChange13*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemInventoryChange13.From // (Final|Native|Static|Public) // @ game+0x594bec0
};

// Class EmbarkServerEvents.ItemMaxDurabilityChanged
// Size: 0xc0 (Inherited: 0xa0)
struct UItemMaxDurabilityChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FString InstanceId; // 0xa8(0x10)
	float OldMaxDurability; // 0xb8(0x04)
	float NewMaxDurability; // 0xbc(0x04)

	struct TArray<struct UItemMaxDurabilityChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemMaxDurabilityChanged.From // (Final|Native|Static|Public) // @ game+0x5935450
};

// Class EmbarkServerEvents.ItemTriggered
// Size: 0x100 (Inherited: 0xa0)
struct UItemTriggered : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	struct FString InstanceId; // 0xc0(0x10)
	struct FVector TriggerLocation; // 0xd0(0x18)
	struct FString WorldItemName; // 0xe8(0x10)

	struct TArray<struct UItemTriggered*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemTriggered.From // (Final|Native|Static|Public) // @ game+0x59520a0
};

// Class EmbarkServerEvents.ItemUnequipped2
// Size: 0xe0 (Inherited: 0xa0)
struct UItemUnequipped2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	int64_t GameAssetId; // 0xc8(0x08)
	struct FString InstanceId; // 0xd0(0x10)

	struct TArray<struct UItemUnequipped2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemUnequipped2.From // (Final|Native|Static|Public) // @ game+0x59ae630
};

// Class EmbarkServerEvents.ItemUnequipped3
// Size: 0xf0 (Inherited: 0xa0)
struct UItemUnequipped3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString ItemName; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	int64_t GameAssetId; // 0xc8(0x08)
	struct FString InstanceId; // 0xd0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0xe0(0x10)

	struct TArray<struct UItemUnequipped3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemUnequipped3.From // (Final|Native|Static|Public) // @ game+0x59b0de0
};

// Class EmbarkServerEvents.ItemUsed3
// Size: 0xf0 (Inherited: 0xa0)
struct UItemUsed3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	struct FString Name; // 0xc0(0x10)
	struct FString InstanceId; // 0xd0(0x10)
	float DurabilityBefore; // 0xe0(0x04)
	float DurabilityAfter; // 0xe4(0x04)

	struct TArray<struct UItemUsed3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemUsed3.From // (Final|Native|Static|Public) // @ game+0x59db5b0
};

// Class EmbarkServerEvents.ItemUsed4
// Size: 0x100 (Inherited: 0xa0)
struct UItemUsed4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	struct FString Name; // 0xc0(0x10)
	struct FString InstanceId; // 0xd0(0x10)
	float DurabilityBefore; // 0xe0(0x04)
	float DurabilityAfter; // 0xe4(0x04)
	struct TArray<struct FString> SpawnedItemNames; // 0xe8(0x10)

	struct TArray<struct UItemUsed4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ItemUsed4.From // (Final|Native|Static|Public) // @ game+0x598a010
};

// Class EmbarkServerEvents.KillBoxCarrier
// Size: 0xe0 (Inherited: 0xa0)
struct UKillBoxCarrier : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	int32_t TicketIndex; // 0xd8(0x04)
	int32_t Cash; // 0xdc(0x04)

	struct TArray<struct UKillBoxCarrier*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.KillBoxCarrier.From // (Final|Native|Static|Public) // @ game+0x5910ed0
};

// Class EmbarkServerEvents.KillStealer
// Size: 0xe0 (Inherited: 0xa0)
struct UKillStealer : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	int32_t TransferPointId; // 0xd8(0x04)
	int32_t Cash; // 0xdc(0x04)

	struct TArray<struct UKillStealer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.KillStealer.From // (Final|Native|Static|Public) // @ game+0x59aff60
};

// Class EmbarkServerEvents.LaunchPadUse
// Size: 0xd0 (Inherited: 0xa0)
struct ULaunchPadUse : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	bool bIsStatic; // 0xb8(0x01)
	int64_t PlacingPlayer; // 0xc0(0x08)
	char pad_c9[0x7]; // 0xc9(0x07)

	struct TArray<struct ULaunchPadUse*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LaunchPadUse.From // (Final|Native|Static|Public) // @ game+0x596b810
};

// Class EmbarkServerEvents.LiftableUsageReport
// Size: 0xc0 (Inherited: 0xa0)
struct ULiftableUsageReport : UServerEventTestBase {
	int32_t LiftableActorsSpawned; // 0x98(0x04)
	int32_t LiftableActorsPickedUp; // 0x9c(0x04)
	int32_t LiftableActorThrows; // 0xa0(0x04)
	int32_t ArenaToolkitActorsSpawned; // 0xa4(0x04)
	int32_t ArenaToolkitActorsPickedUp; // 0xa8(0x04)
	int32_t ArenaToolkitActorsThrows; // 0xac(0x04)
	int32_t ArenaToolkitActorsExploded; // 0xb0(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct ULiftableUsageReport*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LiftableUsageReport.From // (Final|Native|Static|Public) // @ game+0x59ca020
};

// Class EmbarkServerEvents.LightingConditionSet
// Size: 0xb0 (Inherited: 0xa0)
struct ULightingConditionSet : UServerEventTestBase {
	struct FString LightingCondition; // 0x98(0x10)
	bool bOverridden; // 0xa8(0x01)

	struct TArray<struct ULightingConditionSet*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LightingConditionSet.From // (Final|Native|Static|Public) // @ game+0x59424f0
};

// Class EmbarkServerEvents.LoadoutConfiguration
// Size: 0xf0 (Inherited: 0xa0)
struct ULoadoutConfiguration : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t LoadoutFrameGameAssetId; // 0xa0(0x08)
	int64_t PrimaryWeaponSlots; // 0xa8(0x08)
	int64_t SecondaryWeaponSlots; // 0xb0(0x08)
	int64_t ArmorSlots; // 0xb8(0x08)
	struct TArray<int64_t> AllowedArmorGameAssetIds; // 0xc0(0x10)
	int64_t GadgetSlots; // 0xd0(0x08)
	int64_t BackpackSlots; // 0xd8(0x08)
	int64_t BeltSlots; // 0xe0(0x08)
	int64_t SafePouchSlots; // 0xe8(0x08)

	struct TArray<struct ULoadoutConfiguration*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LoadoutConfiguration.From // (Final|Native|Static|Public) // @ game+0x5946450
};

// Class EmbarkServerEvents.LootCrateClose3
// Size: 0x140 (Inherited: 0xa0)
struct ULootCrateClose3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString LootCrate; // 0xb8(0x10)
	struct FString PointOfInterest; // 0xc8(0x10)
	struct FString PoiHierarchy; // 0xd8(0x10)
	struct FString LootCrateName; // 0xe8(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmount> Items; // 0xf8(0x10)
	struct FString InteractionId; // 0x108(0x10)
	struct TArray<struct FFieldTypeStringPair> SubItemReferences; // 0x118(0x10)
	struct FVector LootCrateLocation; // 0x128(0x18)

	struct TArray<struct ULootCrateClose3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LootCrateClose3.From // (Final|Native|Static|Public) // @ game+0x59d7db0
};

// Class EmbarkServerEvents.LootCrateOpen7
// Size: 0x140 (Inherited: 0xa0)
struct ULootCrateOpen7 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString LootCrate; // 0xb8(0x10)
	struct FString PointOfInterest; // 0xc8(0x10)
	struct FString PoiHierarchy; // 0xd8(0x10)
	struct FString LootCrateName; // 0xe8(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmount> Items; // 0xf8(0x10)
	struct FString InteractionId; // 0x108(0x10)
	struct TArray<struct FFieldTypeStringPair> SubItemReferences; // 0x118(0x10)
	struct FVector LootCrateLocation; // 0x128(0x18)

	struct TArray<struct ULootCrateOpen7*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LootCrateOpen7.From // (Final|Native|Static|Public) // @ game+0x59299d0
};

// Class EmbarkServerEvents.LootCrateSpawn6
// Size: 0x120 (Inherited: 0xa0)
struct ULootCrateSpawn6 : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	struct FString LootCrate; // 0xb0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmount> Items; // 0xc0(0x10)
	bool bIsArc; // 0xd0(0x01)
	struct FString PoiName; // 0xd8(0x10)
	struct FString Description; // 0xe8(0x10)
	struct FString PoiHierarchy; // 0xf8(0x10)
	struct TArray<struct FFieldTypeStringPair> SubItemReferences; // 0x108(0x10)
	char pad_119[0x7]; // 0x119(0x07)

	struct TArray<struct ULootCrateSpawn6*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LootCrateSpawn6.From // (Final|Native|Static|Public) // @ game+0x5987b70
};

// Class EmbarkServerEvents.LostQuestObjectiveProgress
// Size: 0xc0 (Inherited: 0xa0)
struct ULostQuestObjectiveProgress : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t QuestId; // 0xa0(0x08)
	int64_t ObjectiveId; // 0xa8(0x08)
	int64_t ProgressLost; // 0xb0(0x08)

	struct TArray<struct ULostQuestObjectiveProgress*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.LostQuestObjectiveProgress.From // (Final|Native|Static|Public) // @ game+0x5920fe0
};

// Class EmbarkServerEvents.MapCondition
// Size: 0xb0 (Inherited: 0xa0)
struct UMapCondition : UServerEventTestBase {
	int64_t GameAssetId; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)

	struct TArray<struct UMapCondition*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MapCondition.From // (Final|Native|Static|Public) // @ game+0x5999a20
};

// Class EmbarkServerEvents.MasteryMultiplier
// Size: 0xb0 (Inherited: 0xa0)
struct UMasteryMultiplier : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Multiplier; // 0xa0(0x08)

	struct TArray<struct UMasteryMultiplier*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MasteryMultiplier.From // (Final|Native|Static|Public) // @ game+0x5921980
};

// Class EmbarkServerEvents.MatchId
// Size: 0xb0 (Inherited: 0xa0)
struct UMatchId : UServerEventTestBase {
	struct FString MatchId; // 0x98(0x10)

	struct TArray<struct UMatchId*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MatchId.From // (Final|Native|Static|Public) // @ game+0x59058b0
};

// Class EmbarkServerEvents.MatchmakingScenario
// Size: 0xb0 (Inherited: 0xa0)
struct UMatchmakingScenario : UServerEventTestBase {
	struct FString ScenarioId; // 0x98(0x10)

	struct TArray<struct UMatchmakingScenario*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MatchmakingScenario.From // (Final|Native|Static|Public) // @ game+0x59ccdb0
};

// Class EmbarkServerEvents.MaxSpawnBudgetUpdate
// Size: 0xc0 (Inherited: 0xa0)
struct UMaxSpawnBudgetUpdate : UServerEventTestBase {
	int64_t OldMaxSpawnBudget; // 0x98(0x08)
	int64_t NewMaxSpawnBudget; // 0xa0(0x08)
	int64_t UsedSpawnBudget; // 0xa8(0x08)
	int64_t PlayerCount; // 0xb0(0x08)

	struct TArray<struct UMaxSpawnBudgetUpdate*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MaxSpawnBudgetUpdate.From // (Final|Native|Static|Public) // @ game+0x5906bd0
};

// Class EmbarkServerEvents.MeleeHitValidationFailed
// Size: 0x100 (Inherited: 0xa0)
struct UMeleeHitValidationFailed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	float PlayerPing; // 0xa8(0x04)
	float TargetPlayerPing; // 0xac(0x04)
	struct FVector SwingLocation; // 0xb0(0x18)
	struct FVector HitLocation; // 0xc8(0x18)
	bool bIsCrouching; // 0xe0(0x01)
	struct FString Reason; // 0xe8(0x10)
	float FailingValue; // 0xf8(0x04)
	char pad_fd[0x3]; // 0xfd(0x03)

	struct TArray<struct UMeleeHitValidationFailed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MeleeHitValidationFailed.From // (Final|Native|Static|Public) // @ game+0x59d7770
};

// Class EmbarkServerEvents.MeleeHit2
// Size: 0x140 (Inherited: 0xa0)
struct UMeleeHit2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	struct FString Name; // 0xd8(0x10)
	int64_t GameAssetId; // 0xe8(0x08)
	struct FString SwingTag; // 0xf0(0x10)
	struct FString AttackTag; // 0x100(0x10)
	float ClosestEnemyPlayer; // 0x110(0x04)
	struct FString HitType; // 0x118(0x10)
	struct FString HitAlliance; // 0x128(0x10)
	char pad_13c[0x4]; // 0x13c(0x04)

	struct TArray<struct UMeleeHit2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MeleeHit2.From // (Final|Native|Static|Public) // @ game+0x59d91e0
};

// Class EmbarkServerEvents.MeleeSwingEnd
// Size: 0xe0 (Inherited: 0xa0)
struct UMeleeSwingEnd : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	struct FString SwingTag; // 0xc0(0x10)
	struct FString AttackTag; // 0xd0(0x10)

	struct TArray<struct UMeleeSwingEnd*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MeleeSwingEnd.From // (Final|Native|Static|Public) // @ game+0x5943030
};

// Class EmbarkServerEvents.MeleeSwingStart3
// Size: 0x100 (Inherited: 0xa0)
struct UMeleeSwingStart3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString WeaponName; // 0xb8(0x10)
	int64_t GameAssetId; // 0xc8(0x08)
	struct FString SwingTag; // 0xd0(0x10)
	struct FString AttackTag; // 0xe0(0x10)
	float ClosestEnemy; // 0xf0(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)

	struct TArray<struct UMeleeSwingStart3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MeleeSwingStart3.From // (Final|Native|Static|Public) // @ game+0x593d6c0
};

// Class EmbarkServerEvents.MissedInput
// Size: 0xa0 (Inherited: 0xa0)
struct UMissedInput : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UMissedInput*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MissedInput.From // (Final|Native|Static|Public) // @ game+0x5963100
};

// Class EmbarkServerEvents.MoveItem
// Size: 0x100 (Inherited: 0xa0)
struct UMoveItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Amount; // 0xa0(0x08)
	struct FVector Location; // 0xa8(0x18)
	int64_t GameAssetId; // 0xc0(0x08)
	struct FString InstanceId; // 0xc8(0x10)
	struct FString PreviousContainer; // 0xd8(0x10)
	struct FString NewContainer; // 0xe8(0x10)

	struct TArray<struct UMoveItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MoveItem.From // (Final|Native|Static|Public) // @ game+0x5985f70
};

// Class EmbarkServerEvents.MovementModeChanged
// Size: 0xe0 (Inherited: 0xa0)
struct UMovementModeChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString OldMovementMode; // 0xb8(0x10)
	struct FString NewMovementMode; // 0xc8(0x10)

	struct TArray<struct UMovementModeChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.MovementModeChanged.From // (Final|Native|Static|Public) // @ game+0x597a520
};

// Class EmbarkServerEvents.NoClientTimeoutShutdown
// Size: 0xa0 (Inherited: 0xa0)
struct UNoClientTimeoutShutdown : UServerEventTestBase {
	double TimeWaited; // 0x98(0x08)

	struct TArray<struct UNoClientTimeoutShutdown*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.NoClientTimeoutShutdown.From // (Final|Native|Static|Public) // @ game+0x5910630
};

// Class EmbarkServerEvents.ObjectTransmuted
// Size: 0xe0 (Inherited: 0xa0)
struct UObjectTransmuted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString TargetClass; // 0xa0(0x10)
	struct FString NewClass; // 0xb0(0x10)
	struct FVector TargetLocation; // 0xc0(0x18)

	struct TArray<struct UObjectTransmuted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ObjectTransmuted.From // (Final|Native|Static|Public) // @ game+0x5946090
};

// Class EmbarkServerEvents.OnboardingNPCDamagePlayer2
// Size: 0x120 (Inherited: 0xa0)
struct UOnboardingNPCDamagePlayer2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	float HealthBefore; // 0xb8(0x04)
	float HealthAfter; // 0xbc(0x04)
	struct FString DamageCauser; // 0xc0(0x10)
	struct FVector EnemyLocation; // 0xd0(0x18)
	bool bIsDbno; // 0xe8(0x01)
	struct FString BoneHit; // 0xf0(0x10)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x100(0x10)
	float DbnoHealthBefore; // 0x110(0x04)
	float DbnoHealthAfter; // 0x114(0x04)
	bool bWasDbno; // 0x118(0x01)
	char pad_11a[0x6]; // 0x11a(0x06)

	struct TArray<struct UOnboardingNPCDamagePlayer2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OnboardingNPCDamagePlayer2.From // (Final|Native|Static|Public) // @ game+0x5984190
};

// Class EmbarkServerEvents.OnboardingNpcWeaponFired
// Size: 0xf0 (Inherited: 0xa0)
struct UOnboardingNpcWeaponFired : UServerEventTestBase {
	int64_t TargetPlayer; // 0x98(0x08)
	struct FVector TargetLocation; // 0xa0(0x18)
	struct FVector NpcLocation; // 0xb8(0x18)
	struct FVector Direction; // 0xd0(0x18)

	struct TArray<struct UOnboardingNpcWeaponFired*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OnboardingNpcWeaponFired.From // (Final|Native|Static|Public) // @ game+0x590c670
};

// Class EmbarkServerEvents.OnboardingPlayerRespawn
// Size: 0xc0 (Inherited: 0xa0)
struct UOnboardingPlayerRespawn : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UOnboardingPlayerRespawn*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OnboardingPlayerRespawn.From // (Final|Native|Static|Public) // @ game+0x59087c0
};

// Class EmbarkServerEvents.OnlineTelemetry
// Size: 0xb0 (Inherited: 0xa0)
struct UOnlineTelemetry : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Message; // 0xa0(0x10)

	struct TArray<struct UOnlineTelemetry*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OnlineTelemetry.From // (Final|Native|Static|Public) // @ game+0x59cef60
};

// Class EmbarkServerEvents.OvertimeEnded
// Size: 0xa0 (Inherited: 0xa0)
struct UOvertimeEnded : UServerEventTestBase {
	float ElapsedTime; // 0x98(0x04)
	float RemainingTime; // 0x9c(0x04)

	struct TArray<struct UOvertimeEnded*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OvertimeEnded.From // (Final|Native|Static|Public) // @ game+0x59404b0
};

// Class EmbarkServerEvents.OvertimeSet
// Size: 0xa0 (Inherited: 0xa0)
struct UOvertimeSet : UServerEventTestBase {
	float Duration; // 0x98(0x04)

	struct TArray<struct UOvertimeSet*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OvertimeSet.From // (Final|Native|Static|Public) // @ game+0x59d2130
};

// Class EmbarkServerEvents.OvertimeStarted
// Size: 0xa0 (Inherited: 0xa0)
struct UOvertimeStarted : UServerEventTestBase {
	float Duration; // 0x98(0x04)

	struct TArray<struct UOvertimeStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.OvertimeStarted.From // (Final|Native|Static|Public) // @ game+0x5909ff0
};

// Class EmbarkServerEvents.POIEntered
// Size: 0xf0 (Inherited: 0xa0)
struct UPOIEntered : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString PoiName; // 0xb8(0x10)
	struct FString Description; // 0xc8(0x10)
	struct FString PoiHierarchy; // 0xd8(0x10)

	struct TArray<struct UPOIEntered*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.POIEntered.From // (Final|Native|Static|Public) // @ game+0x5975ae0
};

// Class EmbarkServerEvents.POIExited
// Size: 0xf0 (Inherited: 0xa0)
struct UPOIExited : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString PoiName; // 0xb8(0x10)
	struct FString Description; // 0xc8(0x10)
	struct FString PoiHierarchy; // 0xd8(0x10)

	struct TArray<struct UPOIExited*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.POIExited.From // (Final|Native|Static|Public) // @ game+0x59d3f40
};

// Class EmbarkServerEvents.PartyBonusFans
// Size: 0xb0 (Inherited: 0xa0)
struct UPartyBonusFans : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t PartySize; // 0xa0(0x04)
	int32_t PartyBonusFans; // 0xa4(0x04)
	float Multiplier; // 0xa8(0x04)

	struct TArray<struct UPartyBonusFans*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PartyBonusFans.From // (Final|Native|Static|Public) // @ game+0x592b5f0
};

// Class EmbarkServerEvents.PartyBonusXp2
// Size: 0xc0 (Inherited: 0xa0)
struct UPartyBonusXp2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString BonusType; // 0xa0(0x10)
	int32_t PartySize; // 0xb0(0x04)
	int32_t PartyBonusXp; // 0xb4(0x04)
	float Multiplier; // 0xb8(0x04)

	struct TArray<struct UPartyBonusXp2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PartyBonusXp2.From // (Final|Native|Static|Public) // @ game+0x598eac0
};

// Class EmbarkServerEvents.PickupCarriable
// Size: 0xd0 (Inherited: 0xa0)
struct UPickupCarriable : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString CarriableName; // 0xb8(0x10)

	struct TArray<struct UPickupCarriable*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PickupCarriable.From // (Final|Native|Static|Public) // @ game+0x59c2b10
};

// Class EmbarkServerEvents.Pinging
// Size: 0xf0 (Inherited: 0xa0)
struct UPinging : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PingIntent; // 0xa0(0x10)
	struct FString PingTagname; // 0xb0(0x10)
	struct FVector Location; // 0xc0(0x18)
	struct FVector PingLocation; // 0xd8(0x18)

	struct TArray<struct UPinging*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.Pinging.From // (Final|Native|Static|Public) // @ game+0x59650f0
};

// Class EmbarkServerEvents.PioFixStuckPlayer
// Size: 0xc0 (Inherited: 0xa0)
struct UPioFixStuckPlayer : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	bool bIsStuck; // 0xb8(0x01)

	struct TArray<struct UPioFixStuckPlayer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PioFixStuckPlayer.From // (Final|Native|Static|Public) // @ game+0x59ad000
};

// Class EmbarkServerEvents.PioPlayerStuckStateChanged
// Size: 0xc0 (Inherited: 0xa0)
struct UPioPlayerStuckStateChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	bool bIsStuck; // 0xb8(0x01)

	struct TArray<struct UPioPlayerStuckStateChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PioPlayerStuckStateChanged.From // (Final|Native|Static|Public) // @ game+0x599e750
};

// Class EmbarkServerEvents.PioViewToKill3
// Size: 0x1d0 (Inherited: 0xa0)
struct UPioViewToKill3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	struct TArray<float> KillerMovementInputX; // 0xa8(0x10)
	struct TArray<float> KillerMovementInputY; // 0xb8(0x10)
	struct TArray<float> KillerMovementInputZ; // 0xc8(0x10)
	struct TArray<float> KillerLookRotationVelocityPitch; // 0xd8(0x10)
	struct TArray<float> KillerLookRotationVelocityYaw; // 0xe8(0x10)
	struct TArray<float> VictimPosInKillerFrustumX; // 0xf8(0x10)
	struct TArray<float> VictimPosInKillerFrustumY; // 0x108(0x10)
	struct TArray<float> VictimPosInKillerFrustumZ; // 0x118(0x10)
	struct TArray<bool> IsUsingGamepad; // 0x128(0x10)
	struct TArray<bool> IsFiring; // 0x138(0x10)
	struct TArray<float> VictimVelocityInKillerFrustumX; // 0x148(0x10)
	struct TArray<float> VictimVelocityInKillerFrustumY; // 0x158(0x10)
	struct TArray<float> VictimVelocityInKillerFrustumZ; // 0x168(0x10)
	struct TArray<float> KillerVelocityInKillerFrustumX; // 0x178(0x10)
	struct TArray<float> KillerVelocityInKillerFrustumY; // 0x188(0x10)
	struct TArray<float> KillerVelocityInKillerFrustumZ; // 0x198(0x10)
	struct TArray<bool> IsUsingAimAssist; // 0x1a8(0x10)
	struct TArray<float> KillerLatencies; // 0x1b8(0x10)

	struct TArray<struct UPioViewToKill3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PioViewToKill3.From // (Final|Native|Static|Public) // @ game+0x5938450
};

// Class EmbarkServerEvents.PlayerBackfill
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerBackfill : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerBackfill*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerBackfill.From // (Final|Native|Static|Public) // @ game+0x59852a0
};

// Class EmbarkServerEvents.PlayerBeginAffectedByInstrument
// Size: 0xe0 (Inherited: 0xa0)
struct UPlayerBeginAffectedByInstrument : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t OtherPlayer; // 0xb8(0x08)
	struct FVector OtherLocation; // 0xc0(0x18)
	int64_t GameAssetId; // 0xd8(0x08)

	struct TArray<struct UPlayerBeginAffectedByInstrument*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerBeginAffectedByInstrument.From // (Final|Native|Static|Public) // @ game+0x59c8ff0
};

// Class EmbarkServerEvents.PlayerCloseToCart
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerCloseToCart : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UPlayerCloseToCart*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerCloseToCart.From // (Final|Native|Static|Public) // @ game+0x5939f30
};

// Class EmbarkServerEvents.PlayerConnectIp
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerConnectIp : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Ip; // 0xa0(0x10)

	struct TArray<struct UPlayerConnectIp*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerConnectIp.From // (Final|Native|Static|Public) // @ game+0x5915450
};

// Class EmbarkServerEvents.PlayerConnectTelemetry
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerConnectTelemetry : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerConnectTelemetry*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerConnectTelemetry.From // (Final|Native|Static|Public) // @ game+0x5905680
};

// Class EmbarkServerEvents.PlayerConnect3
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerConnect3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t ManifestId; // 0xa0(0x08)
	struct FString ClientUuid; // 0xa8(0x10)
	int64_t ClientPlatform; // 0xb8(0x08)

	struct TArray<struct UPlayerConnect3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerConnect3.From // (Final|Native|Static|Public) // @ game+0x5957970
};

// Class EmbarkServerEvents.PlayerDamageActor
// Size: 0x100 (Inherited: 0xa0)
struct UPlayerDamageActor : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString TargetName; // 0xb8(0x10)
	struct FVector TargetLocation; // 0xc8(0x18)
	float PreviousHealth; // 0xe0(0x04)
	float CurrentHealth; // 0xe4(0x04)
	int64_t GameAssetId; // 0xe8(0x08)
	struct FString BoneName; // 0xf0(0x10)

	struct TArray<struct UPlayerDamageActor*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerDamageActor.From // (Final|Native|Static|Public) // @ game+0x5964d40
};

// Class EmbarkServerEvents.PlayerDamagePlayer5
// Size: 0x140 (Inherited: 0xa0)
struct UPlayerDamagePlayer5 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	float HealthBefore; // 0xd8(0x04)
	float HealthAfter; // 0xdc(0x04)
	struct FString DamageCauser; // 0xe0(0x10)
	int64_t GameAssetId; // 0xf0(0x08)
	bool bIsDbno; // 0xf8(0x01)
	struct FString BoneHit; // 0x100(0x10)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x110(0x10)
	float DbnoHealthBefore; // 0x120(0x04)
	float DbnoHealthAfter; // 0x124(0x04)
	bool bWasDbno; // 0x128(0x01)
	char pad_12a[0x2]; // 0x12a(0x02)
	float ArmorHealthBefore; // 0x12c(0x04)
	float ArmorHealthAfter; // 0x130(0x04)
	float ArmorMitigatedDamage; // 0x134(0x04)
	char pad_138[0x8]; // 0x138(0x08)

	struct TArray<struct UPlayerDamagePlayer5*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerDamagePlayer5.From // (Final|Native|Static|Public) // @ game+0x59b4a10
};

// Class EmbarkServerEvents.PlayerDamagePlayer6
// Size: 0x150 (Inherited: 0xa0)
struct UPlayerDamagePlayer6 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	float HealthBefore; // 0xd8(0x04)
	float HealthAfter; // 0xdc(0x04)
	struct FString DamageCauser; // 0xe0(0x10)
	int64_t GameAssetId; // 0xf0(0x08)
	bool bIsDbno; // 0xf8(0x01)
	struct FString BoneHit; // 0x100(0x10)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0x110(0x10)
	float DbnoHealthBefore; // 0x120(0x04)
	float DbnoHealthAfter; // 0x124(0x04)
	bool bWasDbno; // 0x128(0x01)
	char pad_12a[0x2]; // 0x12a(0x02)
	float ArmorHealthBefore; // 0x12c(0x04)
	float ArmorHealthAfter; // 0x130(0x04)
	float ArmorMitigatedDamage; // 0x134(0x04)
	struct FString WeaponInstanceId; // 0x138(0x10)
	char pad_148[0x8]; // 0x148(0x08)

	struct TArray<struct UPlayerDamagePlayer6*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerDamagePlayer6.From // (Final|Native|Static|Public) // @ game+0x5981c50
};

// Class EmbarkServerEvents.PlayerDeathItemDecay
// Size: 0xd0 (Inherited: 0xa0)
struct UPlayerDeathItemDecay : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FString Name; // 0xa8(0x10)
	struct FString InstanceId; // 0xb8(0x10)
	float Decay; // 0xc8(0x04)
	float PostDeathDurability; // 0xcc(0x04)

	struct TArray<struct UPlayerDeathItemDecay*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerDeathItemDecay.From // (Final|Native|Static|Public) // @ game+0x593b860
};

// Class EmbarkServerEvents.PlayerDie
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerDie : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerDie*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerDie.From // (Final|Native|Static|Public) // @ game+0x5974630
};

// Class EmbarkServerEvents.PlayerDisconnect
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerDisconnect : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerDisconnect*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerDisconnect.From // (Final|Native|Static|Public) // @ game+0x5968080
};

// Class EmbarkServerEvents.PlayerEndAffectedByInstrument
// Size: 0xe0 (Inherited: 0xa0)
struct UPlayerEndAffectedByInstrument : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t OtherPlayer; // 0xb8(0x08)
	struct FVector OtherLocation; // 0xc0(0x18)
	int64_t GameAssetId; // 0xd8(0x08)

	struct TArray<struct UPlayerEndAffectedByInstrument*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerEndAffectedByInstrument.From // (Final|Native|Static|Public) // @ game+0x59c8db0
};

// Class EmbarkServerEvents.PlayerExpressionUsed
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerExpressionUsed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FString EventTag; // 0xa8(0x10)

	struct TArray<struct UPlayerExpressionUsed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerExpressionUsed.From // (Final|Native|Static|Public) // @ game+0x5996b40
};

// Class EmbarkServerEvents.PlayerExtractionCanceled
// Size: 0xe0 (Inherited: 0xa0)
struct UPlayerExtractionCanceled : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString ExtractionPointName; // 0xb8(0x10)
	struct FString ExtractionPointType; // 0xc8(0x10)
	int32_t ExtractionCycle; // 0xd8(0x04)

	struct TArray<struct UPlayerExtractionCanceled*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerExtractionCanceled.From // (Final|Native|Static|Public) // @ game+0x5990c60
};

// Class EmbarkServerEvents.PlayerExtractionFinalized
// Size: 0xe0 (Inherited: 0xa0)
struct UPlayerExtractionFinalized : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString ExtractionPointName; // 0xb8(0x10)
	struct FString ExtractionPointType; // 0xc8(0x10)
	int32_t ExtractionCycle; // 0xd8(0x04)

	struct TArray<struct UPlayerExtractionFinalized*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerExtractionFinalized.From // (Final|Native|Static|Public) // @ game+0x5974e50
};

// Class EmbarkServerEvents.PlayerExtractionStarted
// Size: 0xe0 (Inherited: 0xa0)
struct UPlayerExtractionStarted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString ExtractionPointName; // 0xb8(0x10)
	struct FString ExtractionPointType; // 0xc8(0x10)
	int32_t ExtractionCycle; // 0xd8(0x04)

	struct TArray<struct UPlayerExtractionStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerExtractionStarted.From // (Final|Native|Static|Public) // @ game+0x59690e0
};

// Class EmbarkServerEvents.PlayerFellOutOfWorld
// Size: 0xd0 (Inherited: 0xa0)
struct UPlayerFellOutOfWorld : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector KillZHitLocation; // 0xa0(0x18)
	struct FVector LastGroundedLocation; // 0xb8(0x18)

	struct TArray<struct UPlayerFellOutOfWorld*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerFellOutOfWorld.From // (Final|Native|Static|Public) // @ game+0x594bd40
};

// Class EmbarkServerEvents.PlayerHeal4
// Size: 0x110 (Inherited: 0xa0)
struct UPlayerHeal4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	int64_t ItemId; // 0xa8(0x08)
	float HealthBefore; // 0xb0(0x04)
	float HealthAfter; // 0xb4(0x04)
	struct FVector TargetLocation; // 0xb8(0x18)
	struct FString ItemUsed; // 0xd0(0x10)
	struct FVector Location; // 0xe0(0x18)
	struct TArray<struct FString> TargetOngoingGameplayEffects; // 0xf8(0x10)
	float DbnoHealthBefore; // 0x108(0x04)
	bool bWasDbno; // 0x10c(0x01)
	bool bIsDbno; // 0x10d(0x01)

	struct TArray<struct UPlayerHeal4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerHeal4.From // (Final|Native|Static|Public) // @ game+0x59d47d0
};

// Class EmbarkServerEvents.PlayerHit2
// Size: 0xf0 (Inherited: 0xa0)
struct UPlayerHit2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector PlayerLocation; // 0xa0(0x18)
	int64_t WeaponGameAssetId; // 0xb8(0x08)
	int64_t TargetPlayer; // 0xc0(0x08)
	struct FVector TargetPlayerLocation; // 0xc8(0x18)
	bool bIsDead; // 0xe0(0x01)
	char pad_e9[0x7]; // 0xe9(0x07)

	struct TArray<struct UPlayerHit2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerHit2.From // (Final|Native|Static|Public) // @ game+0x592e000
};

// Class EmbarkServerEvents.PlayerIndoorStateChange
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerIndoorStateChange : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	bool bIsIndoors; // 0xb8(0x01)

	struct TArray<struct UPlayerIndoorStateChange*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerIndoorStateChange.From // (Final|Native|Static|Public) // @ game+0x595c680
};

// Class EmbarkServerEvents.PlayerInitializationStep
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerInitializationStep : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString InitStepDescription; // 0xa0(0x10)
	bool bWasSuccess; // 0xb0(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)

	struct TArray<struct UPlayerInitializationStep*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerInitializationStep.From // (Final|Native|Static|Public) // @ game+0x59b2860
};

// Class EmbarkServerEvents.PlayerInitialized
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerInitialized : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerInitialized*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerInitialized.From // (Final|Native|Static|Public) // @ game+0x59b3140
};

// Class EmbarkServerEvents.PlayerKickedByServer
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerKickedByServer : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Reason; // 0xa0(0x10)

	struct TArray<struct UPlayerKickedByServer*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerKickedByServer.From // (Final|Native|Static|Public) // @ game+0x591b780
};

// Class EmbarkServerEvents.PlayerNetworkConnectionClose
// Size: 0x120 (Inherited: 0xa0)
struct UPlayerNetworkConnectionClose : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FFieldTypeNetConnectionData ConnectionInfo; // 0xa0(0x70)
	struct FString CloseReason; // 0x110(0x10)

	struct TArray<struct UPlayerNetworkConnectionClose*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerNetworkConnectionClose.From // (Final|Native|Static|Public) // @ game+0x59c9660
};

// Class EmbarkServerEvents.PlayerNetworkLatency
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerNetworkLatency : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float NetworkLatency; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UPlayerNetworkLatency*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerNetworkLatency.From // (Final|Native|Static|Public) // @ game+0x5981b10
};

// Class EmbarkServerEvents.PlayerNetworkResponsive
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerNetworkResponsive : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float Duration; // 0xa0(0x04)
	struct FString UnresponsiveId; // 0xa8(0x10)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UPlayerNetworkResponsive*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerNetworkResponsive.From // (Final|Native|Static|Public) // @ game+0x59aa8c0
};

// Class EmbarkServerEvents.PlayerNetworkUnresponsive3
// Size: 0x130 (Inherited: 0xa0)
struct UPlayerNetworkUnresponsive3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float LastReceiveRealtime; // 0xa0(0x04)
	struct FString UnresponsiveId; // 0xa8(0x10)
	struct FFieldTypeNetConnectionData ConnectionInfo; // 0xb8(0x70)
	char pad_12c[0x4]; // 0x12c(0x04)

	struct TArray<struct UPlayerNetworkUnresponsive3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerNetworkUnresponsive3.From // (Final|Native|Static|Public) // @ game+0x593fb70
};

// Class EmbarkServerEvents.PlayerNotCloseToCart
// Size: 0xc0 (Inherited: 0xa0)
struct UPlayerNotCloseToCart : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UPlayerNotCloseToCart*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerNotCloseToCart.From // (Final|Native|Static|Public) // @ game+0x59ca660
};

// Class EmbarkServerEvents.PlayerPawnAssigned
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerPawnAssigned : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PawnName; // 0xa0(0x10)

	struct TArray<struct UPlayerPawnAssigned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerPawnAssigned.From // (Final|Native|Static|Public) // @ game+0x59c7160
};

// Class EmbarkServerEvents.PlayerPosition
// Size: 0xf0 (Inherited: 0xa0)
struct UPlayerPosition : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FVector ForwardVector; // 0xb8(0x18)
	struct FVector Velocity; // 0xd0(0x18)

	struct TArray<struct UPlayerPosition*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerPosition.From // (Final|Native|Static|Public) // @ game+0x59da2a0
};

// Class EmbarkServerEvents.PlayerReconnect
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerReconnect : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerReconnect*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerReconnect.From // (Final|Native|Static|Public) // @ game+0x5908580
};

// Class EmbarkServerEvents.PlayerRepairExtractionPoint
// Size: 0xf0 (Inherited: 0xa0)
struct UPlayerRepairExtractionPoint : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString ExtractionPointName; // 0xb8(0x10)
	struct FString ExtractionPointType; // 0xc8(0x10)
	struct FVector ExtractionPointLocation; // 0xd8(0x18)

	struct TArray<struct UPlayerRepairExtractionPoint*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerRepairExtractionPoint.From // (Final|Native|Static|Public) // @ game+0x596e590
};

// Class EmbarkServerEvents.PlayerRevive2
// Size: 0xf0 (Inherited: 0xa0)
struct UPlayerRevive2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	struct FVector TargetLocation; // 0xa8(0x18)
	float TargetHealTaken; // 0xc0(0x04)
	float TargetDbnoHealth; // 0xc4(0x04)
	struct FString ItemUsed; // 0xc8(0x10)
	struct FVector Location; // 0xd8(0x18)

	struct TArray<struct UPlayerRevive2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerRevive2.From // (Final|Native|Static|Public) // @ game+0x594ef00
};

// Class EmbarkServerEvents.PlayerRoundID
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerRoundID : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PlayerRoundID; // 0xa0(0x10)

	struct TArray<struct UPlayerRoundID*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerRoundID.From // (Final|Native|Static|Public) // @ game+0x597a220
};

// Class EmbarkServerEvents.PlayerShieldRecharge
// Size: 0xf0 (Inherited: 0xa0)
struct UPlayerShieldRecharge : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	int64_t GameAssetId; // 0xd8(0x08)
	float ArmorHealthBefore; // 0xe0(0x04)
	float ArmorHealthAfter; // 0xe4(0x04)
	int64_t RepairTime; // 0xe8(0x08)

	struct TArray<struct UPlayerShieldRecharge*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerShieldRecharge.From // (Final|Native|Static|Public) // @ game+0x5989010
};

// Class EmbarkServerEvents.PlayerSpawnWorldItem
// Size: 0xf0 (Inherited: 0xa0)
struct UPlayerSpawnWorldItem : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t GameAssetId; // 0xb8(0x08)
	struct FString InstanceId; // 0xc0(0x10)
	struct FVector WorldItemLocation; // 0xd0(0x18)

	struct TArray<struct UPlayerSpawnWorldItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerSpawnWorldItem.From // (Final|Native|Static|Public) // @ game+0x59907e0
};

// Class EmbarkServerEvents.PlayerSpawn4
// Size: 0x110 (Inherited: 0xa0)
struct UPlayerSpawn4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t SquadId; // 0xa0(0x08)
	struct FString Squad; // 0xa8(0x10)
	struct FVector Location; // 0xb8(0x18)
	int64_t CharacterId; // 0xd0(0x08)
	struct FString Difficulty; // 0xd8(0x10)
	struct FString GameMap; // 0xe8(0x10)
	struct FString MapLocation; // 0xf8(0x10)

	struct TArray<struct UPlayerSpawn4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerSpawn4.From // (Final|Native|Static|Public) // @ game+0x595faa0
};

// Class EmbarkServerEvents.PlayerStandingOnMovingFloor
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerStandingOnMovingFloor : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float TimeSpentOnMovingFloor; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct UPlayerStandingOnMovingFloor*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerStandingOnMovingFloor.From // (Final|Native|Static|Public) // @ game+0x59d7b70
};

// Class EmbarkServerEvents.PlayerStartSpectate
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerStartSpectate : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerStartSpectate*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerStartSpectate.From // (Final|Native|Static|Public) // @ game+0x5923f80
};

// Class EmbarkServerEvents.PlayerStateChange
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerStateChange : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t OldState; // 0xa0(0x04)
	int32_t NewState; // 0xa4(0x04)

	struct TArray<struct UPlayerStateChange*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerStateChange.From // (Final|Native|Static|Public) // @ game+0x5967c60
};

// Class EmbarkServerEvents.PlayerStopSpectate
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerStopSpectate : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerStopSpectate*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerStopSpectate.From // (Final|Native|Static|Public) // @ game+0x5960910
};

// Class EmbarkServerEvents.PlayerSurrender
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerSurrender : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UPlayerSurrender*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerSurrender.From // (Final|Native|Static|Public) // @ game+0x59cadb0
};

// Class EmbarkServerEvents.PlayerTeleported
// Size: 0xe0 (Inherited: 0xa0)
struct UPlayerTeleported : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector FromLocation; // 0xa0(0x18)
	struct FVector ToLocation; // 0xb8(0x18)
	bool bFriendlyPortal; // 0xd0(0x01)
	char pad_d9[0x7]; // 0xd9(0x07)

	struct TArray<struct UPlayerTeleported*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PlayerTeleported.From // (Final|Native|Static|Public) // @ game+0x59ac300
};

// Class EmbarkServerEvents.PortalSpawned
// Size: 0xc0 (Inherited: 0xa0)
struct UPortalSpawned : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UPortalSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PortalSpawned.From // (Final|Native|Static|Public) // @ game+0x59a0300
};

// Class EmbarkServerEvents.PotentialTargets
// Size: 0xf0 (Inherited: 0xa0)
struct UPotentialTargets : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	int64_t TargetPlayer; // 0xb8(0x08)
	struct FVector TargetLocation; // 0xc0(0x18)
	float Distance; // 0xd8(0x04)
	float BulletDistance; // 0xdc(0x04)
	int64_t WeaponGameAssetId; // 0xe0(0x08)

	struct TArray<struct UPotentialTargets*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PotentialTargets.From // (Final|Native|Static|Public) // @ game+0x5913010
};

// Class EmbarkServerEvents.ProjectileValidationFailed
// Size: 0x130 (Inherited: 0xa0)
struct UProjectileValidationFailed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TargetPlayer; // 0xa0(0x08)
	float PlayerPing; // 0xa8(0x04)
	float TargetPlayerPing; // 0xac(0x04)
	struct FVector AimingLocation; // 0xb0(0x18)
	struct FVector ActorLocation; // 0xc8(0x18)
	struct FVector HitLocation; // 0xe0(0x18)
	struct FVector PelvisLocation; // 0xf8(0x18)
	bool bIsCrouching; // 0x110(0x01)
	struct FString Reason; // 0x118(0x10)
	float FailingValue; // 0x128(0x04)
	char pad_12d[0x3]; // 0x12d(0x03)

	struct TArray<struct UProjectileValidationFailed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ProjectileValidationFailed.From // (Final|Native|Static|Public) // @ game+0x59a2fb0
};

// Class EmbarkServerEvents.PushObjectivePosition
// Size: 0xc0 (Inherited: 0xa0)
struct UPushObjectivePosition : UServerEventTestBase {
	int32_t ObjectiveIndex; // 0x98(0x04)
	int32_t ScenarioIndex; // 0x9c(0x04)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UPushObjectivePosition*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PushObjectivePosition.From // (Final|Native|Static|Public) // @ game+0x597c5e0
};

// Class EmbarkServerEvents.PushObjectiveStateChange4
// Size: 0x110 (Inherited: 0xa0)
struct UPushObjectiveStateChange4 : UServerEventTestBase {
	int32_t ScenarioIndex; // 0x98(0x04)
	int32_t ObjectiveSpawnIndex; // 0x9c(0x04)
	struct FString ObjectiveLabel; // 0xa0(0x10)
	struct FString PreviousState; // 0xb0(0x10)
	struct FString NewState; // 0xc0(0x10)
	int64_t Player; // 0xd0(0x08)
	int64_t TicketsAtStateChange; // 0xd8(0x08)
	float Duration; // 0xe0(0x04)
	struct FVector Location; // 0xe8(0x18)
	int32_t AddedTickets; // 0x100(0x04)
	char pad_108[0x8]; // 0x108(0x08)

	struct TArray<struct UPushObjectiveStateChange4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PushObjectiveStateChange4.From // (Final|Native|Static|Public) // @ game+0x59962b0
};

// Class EmbarkServerEvents.PushRoundCompleted4
// Size: 0xc0 (Inherited: 0xa0)
struct UPushRoundCompleted4 : UServerEventTestBase {
	int32_t WinningSquadId; // 0x98(0x04)
	struct FString EndReason; // 0xa0(0x10)
	int32_t TotalScenariosCompleted; // 0xb0(0x04)
	int32_t FinalTicketCount; // 0xb4(0x04)
	bool bAttackersWon; // 0xb8(0x01)
	float Duration; // 0xbc(0x04)

	struct TArray<struct UPushRoundCompleted4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PushRoundCompleted4.From // (Final|Native|Static|Public) // @ game+0x59356f0
};

// Class EmbarkServerEvents.PushScenarioCompleted3
// Size: 0xd0 (Inherited: 0xa0)
struct UPushScenarioCompleted3 : UServerEventTestBase {
	int32_t ScenarioIndex; // 0x98(0x04)
	float ScenarioDuration; // 0x9c(0x04)
	int32_t AttackingSquadId; // 0xa0(0x04)
	int32_t DefendingSquadId; // 0xa4(0x04)
	struct FString EndReason; // 0xa8(0x10)
	int32_t AttackerTickets; // 0xb8(0x04)
	int32_t MaxAttackerTickets; // 0xbc(0x04)
	int32_t AddedAttackerTickets; // 0xc0(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)

	struct TArray<struct UPushScenarioCompleted3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PushScenarioCompleted3.From // (Final|Native|Static|Public) // @ game+0x5956610
};

// Class EmbarkServerEvents.PushScenarioStarted2
// Size: 0xc0 (Inherited: 0xa0)
struct UPushScenarioStarted2 : UServerEventTestBase {
	int32_t ScenarioIndex; // 0x98(0x04)
	int64_t ScenarioStartTimestamp; // 0xa0(0x08)
	int32_t AttackingTeamId; // 0xa8(0x04)
	int32_t DefendingTeamId; // 0xac(0x04)
	int32_t AttackerTickets; // 0xb0(0x04)
	int32_t MaxAttackerTickets; // 0xb4(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct UPushScenarioStarted2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PushScenarioStarted2.From // (Final|Native|Static|Public) // @ game+0x59dbdf0
};

// Class EmbarkServerEvents.PushTokenChange
// Size: 0xc0 (Inherited: 0xa0)
struct UPushTokenChange : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t ScenarioIndex; // 0xa0(0x04)
	int32_t OldValue; // 0xa4(0x04)
	int32_t NewValue; // 0xa8(0x04)
	struct FString Reason; // 0xb0(0x10)

	struct TArray<struct UPushTokenChange*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PushTokenChange.From // (Final|Native|Static|Public) // @ game+0x59ab560
};

// Class EmbarkServerEvents.PuzzleCompleted
// Size: 0xd0 (Inherited: 0xa0)
struct UPuzzleCompleted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PuzzleActorName; // 0xa0(0x10)
	struct FVector PuzzleLocation; // 0xb0(0x18)
	int64_t TotalSteps; // 0xc8(0x08)

	struct TArray<struct UPuzzleCompleted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PuzzleCompleted.From // (Final|Native|Static|Public) // @ game+0x592d1b0
};

// Class EmbarkServerEvents.PuzzleReset
// Size: 0xe0 (Inherited: 0xa0)
struct UPuzzleReset : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PuzzleActorName; // 0xa0(0x10)
	struct FVector PuzzleLocation; // 0xb0(0x18)
	int64_t StepAtReset; // 0xc8(0x08)
	int64_t TotalStepsRequired; // 0xd0(0x08)

	struct TArray<struct UPuzzleReset*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PuzzleReset.From // (Final|Native|Static|Public) // @ game+0x59a7070
};

// Class EmbarkServerEvents.PuzzleStepActivated
// Size: 0xf0 (Inherited: 0xa0)
struct UPuzzleStepActivated : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PuzzleActorName; // 0xa0(0x10)
	struct FVector PuzzleLocation; // 0xb0(0x18)
	int64_t CurrentStep; // 0xc8(0x08)
	int64_t TotalStepsRequired; // 0xd0(0x08)
	struct FString ActivatorActorName; // 0xd8(0x10)

	struct TArray<struct UPuzzleStepActivated*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PuzzleStepActivated.From // (Final|Native|Static|Public) // @ game+0x5991bc0
};

// Class EmbarkServerEvents.PuzzleStepDeactivated
// Size: 0xf0 (Inherited: 0xa0)
struct UPuzzleStepDeactivated : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString PuzzleActorName; // 0xa0(0x10)
	struct FVector PuzzleLocation; // 0xb0(0x18)
	int64_t CurrentStep; // 0xc8(0x08)
	int64_t TotalStepsRequired; // 0xd0(0x08)
	struct FString AcctivatorActorName; // 0xd8(0x10)

	struct TArray<struct UPuzzleStepDeactivated*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.PuzzleStepDeactivated.From // (Final|Native|Static|Public) // @ game+0x592a400
};

// Class EmbarkServerEvents.RemoveBounty
// Size: 0xb0 (Inherited: 0xa0)
struct URemoveBounty : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t Amount; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct URemoveBounty*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.RemoveBounty.From // (Final|Native|Static|Public) // @ game+0x5989150
};

// Class EmbarkServerEvents.ReverseGravityZoneSpawned
// Size: 0xc0 (Inherited: 0xa0)
struct UReverseGravityZoneSpawned : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)

	struct TArray<struct UReverseGravityZoneSpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ReverseGravityZoneSpawned.From // (Final|Native|Static|Public) // @ game+0x593b2a0
};

// Class EmbarkServerEvents.RoundCompleted
// Size: 0xa0 (Inherited: 0xa0)
struct URoundCompleted : UServerEventTestBase {
	int64_t UnrealTime; // 0x98(0x08)

	struct TArray<struct URoundCompleted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.RoundCompleted.From // (Final|Native|Static|Public) // @ game+0x59d9760
};

// Class EmbarkServerEvents.RoundDefeat
// Size: 0xb0 (Inherited: 0xa0)
struct URoundDefeat : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t DefeatReason; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct URoundDefeat*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.RoundDefeat.From // (Final|Native|Static|Public) // @ game+0x597e7c0
};

// Class EmbarkServerEvents.RoundStarted
// Size: 0xa0 (Inherited: 0xa0)
struct URoundStarted : UServerEventTestBase {
	int64_t UnrealTime; // 0x98(0x08)

	struct TArray<struct URoundStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.RoundStarted.From // (Final|Native|Static|Public) // @ game+0x59baa50
};

// Class EmbarkServerEvents.RoundWin
// Size: 0xb0 (Inherited: 0xa0)
struct URoundWin : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t WinReason; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)

	struct TArray<struct URoundWin*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.RoundWin.From // (Final|Native|Static|Public) // @ game+0x597c990
};

// Class EmbarkServerEvents.SaturatedFrames
// Size: 0xb0 (Inherited: 0xa0)
struct USaturatedFrames : UServerEventTestBase {
	struct TArray<char> TotalSaturatedConnections; // 0x98(0x10)

	struct TArray<struct USaturatedFrames*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SaturatedFrames.From // (Final|Native|Static|Public) // @ game+0x59a5650
};

// Class EmbarkServerEvents.SelectedEmote
// Size: 0xc0 (Inherited: 0xa0)
struct USelectedEmote : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	struct FString Name; // 0xa8(0x10)

	struct TArray<struct USelectedEmote*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SelectedEmote.From // (Final|Native|Static|Public) // @ game+0x59cebc0
};

// Class EmbarkServerEvents.ServerAgonesReady
// Size: 0xa0 (Inherited: 0xa0)
struct UServerAgonesReady : UServerEventTestBase {
	int64_t UnrealTime; // 0x98(0x08)

	struct TArray<struct UServerAgonesReady*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ServerAgonesReady.From // (Final|Native|Static|Public) // @ game+0x59370c0
};

// Class EmbarkServerEvents.ServerDetectedClientConnectionFailure3
// Size: 0x120 (Inherited: 0xa0)
struct UServerDetectedClientConnectionFailure3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t FromFailureOrigin; // 0xa0(0x04)
	int32_t ErrorType; // 0xa4(0x04)
	struct FFieldTypeNetConnectionData ConnectionInfo; // 0xa8(0x70)

	struct TArray<struct UServerDetectedClientConnectionFailure3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ServerDetectedClientConnectionFailure3.From // (Final|Native|Static|Public) // @ game+0x5921c40
};

// Class EmbarkServerEvents.ServerManifest
// Size: 0xa0 (Inherited: 0xa0)
struct UServerManifest : UServerEventTestBase {
	int64_t ServerManifestId; // 0x98(0x08)

	struct TArray<struct UServerManifest*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ServerManifest.From // (Final|Native|Static|Public) // @ game+0x594dcc0
};

// Class EmbarkServerEvents.ServerNetDriverPerformance
// Size: 0xd0 (Inherited: 0xa0)
struct UServerNetDriverPerformance : UServerEventTestBase {
	struct FString DriverName; // 0x98(0x10)
	int64_t FrameCount; // 0xa8(0x08)
	struct TArray<char> Frames; // 0xb0(0x10)
	int64_t FirstFrame; // 0xc0(0x08)

	struct TArray<struct UServerNetDriverPerformance*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ServerNetDriverPerformance.From // (Final|Native|Static|Public) // @ game+0x590bf40
};

// Class EmbarkServerEvents.ServerPerformance2
// Size: 0xc0 (Inherited: 0xa0)
struct UServerPerformance2 : UServerEventTestBase {
	struct TArray<char> Frametimes; // 0x98(0x10)
	struct TArray<char> TotalSaturatedConnections; // 0xa8(0x10)
	int32_t NumBadFrams; // 0xb8(0x04)
	int32_t StartingFrameNum; // 0xbc(0x04)

	struct TArray<struct UServerPerformance2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ServerPerformance2.From // (Final|Native|Static|Public) // @ game+0x5931f40
};

// Class EmbarkServerEvents.ServerShutdown
// Size: 0xb0 (Inherited: 0xa0)
struct UServerShutdown : UServerEventTestBase {
	struct FString Reason; // 0x98(0x10)

	struct TArray<struct UServerShutdown*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ServerShutdown.From // (Final|Native|Static|Public) // @ game+0x59546c0
};

// Class EmbarkServerEvents.SessionDefeatForceKill
// Size: 0xb0 (Inherited: 0xa0)
struct USessionDefeatForceKill : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString DefeatReason; // 0xa0(0x10)

	struct TArray<struct USessionDefeatForceKill*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SessionDefeatForceKill.From // (Final|Native|Static|Public) // @ game+0x598ec00
};

// Class EmbarkServerEvents.SessionModifier
// Size: 0xb0 (Inherited: 0xa0)
struct USessionModifier : UServerEventTestBase {
	struct TArray<int64_t> ModifierIds; // 0x98(0x10)

	struct TArray<struct USessionModifier*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SessionModifier.From // (Final|Native|Static|Public) // @ game+0x5971880
};

// Class EmbarkServerEvents.SoundTrapActivated
// Size: 0xd0 (Inherited: 0xa0)
struct USoundTrapActivated : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString TrapName; // 0xb8(0x10)
	float ElevationChangedTime; // 0xc8(0x04)

	struct TArray<struct USoundTrapActivated*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SoundTrapActivated.From // (Final|Native|Static|Public) // @ game+0x59ae8b0
};

// Class EmbarkServerEvents.SpawnWorldItem
// Size: 0xe0 (Inherited: 0xa0)
struct USpawnWorldItem : UServerEventTestBase {
	struct FString Instigator; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)
	int64_t GameAssetId; // 0xc0(0x08)
	struct FVector WorldItemLocation; // 0xc8(0x18)

	struct TArray<struct USpawnWorldItem*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SpawnWorldItem.From // (Final|Native|Static|Public) // @ game+0x5913ef0
};

// Class EmbarkServerEvents.SpawnedInventorySlot3
// Size: 0xf0 (Inherited: 0xa0)
struct USpawnedInventorySlot3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Amount; // 0xa0(0x08)
	int64_t GameAssetId; // 0xa8(0x08)
	struct FString InstanceId; // 0xb0(0x10)
	struct FString Container; // 0xc0(0x10)
	float Durability; // 0xd0(0x04)
	float MaxDurability; // 0xd4(0x04)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0xd8(0x10)

	struct TArray<struct USpawnedInventorySlot3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SpawnedInventorySlot3.From // (Final|Native|Static|Public) // @ game+0x5994eb0
};

// Class EmbarkServerEvents.SquadAbandon
// Size: 0xa0 (Inherited: 0xa0)
struct USquadAbandon : UServerEventTestBase {
	int64_t SquadIndex; // 0x98(0x08)

	struct TArray<struct USquadAbandon*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SquadAbandon.From // (Final|Native|Static|Public) // @ game+0x5981250
};

// Class EmbarkServerEvents.StaminaUsed
// Size: 0xd0 (Inherited: 0xa0)
struct UStaminaUsed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float StaminaUsed; // 0xa0(0x04)
	float ActuallyConsumedStamina; // 0xa4(0x04)
	struct FVector Location; // 0xa8(0x18)
	struct FString AbilityName; // 0xc0(0x10)

	struct TArray<struct UStaminaUsed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StaminaUsed.From // (Final|Native|Static|Public) // @ game+0x5937e20
};

// Class EmbarkServerEvents.StanceChanged
// Size: 0xe0 (Inherited: 0xa0)
struct UStanceChanged : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	struct FString OldStance; // 0xb8(0x10)
	struct FString NewStance; // 0xc8(0x10)

	struct TArray<struct UStanceChanged*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StanceChanged.From // (Final|Native|Static|Public) // @ game+0x59bb500
};

// Class EmbarkServerEvents.StartInstantReplayDownload
// Size: 0xc0 (Inherited: 0xa0)
struct UStartInstantReplayDownload : UServerEventTestBase {
	int32_t FileId; // 0x98(0x04)
	int32_t NumPackets; // 0x9c(0x04)
	int32_t CompressedSize; // 0xa0(0x04)
	int32_t UncompressedSize; // 0xa4(0x04)
	int32_t UncompressedCheckpointSize; // 0xa8(0x04)
	int32_t UncompressedStreamChunkSize; // 0xac(0x04)
	int64_t Player; // 0xb0(0x08)

	struct TArray<struct UStartInstantReplayDownload*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StartInstantReplayDownload.From // (Final|Native|Static|Public) // @ game+0x598a990
};

// Class EmbarkServerEvents.StartSpawnSequence
// Size: 0x100 (Inherited: 0xa0)
struct UStartSpawnSequence : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<int64_t> AuxilaryPlayerIds; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	struct FString SpawnSource; // 0xc8(0x10)
	struct FString InstigatorName; // 0xd8(0x10)
	int64_t InstigatorGameAssetId; // 0xe8(0x08)
	int64_t InstigatorEnemySpawnId; // 0xf0(0x08)
	int64_t GroupId; // 0xf8(0x08)

	struct TArray<struct UStartSpawnSequence*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StartSpawnSequence.From // (Final|Native|Static|Public) // @ game+0x593b9e0
};

// Class EmbarkServerEvents.StartSpawnSequenceProxy
// Size: 0x100 (Inherited: 0xa0)
struct UStartSpawnSequenceProxy : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<int64_t> AuxilaryPlayerIds; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	struct FString SpawnSource; // 0xc8(0x10)
	struct FString InstigatorName; // 0xd8(0x10)
	int64_t InstigatorGameAssetId; // 0xe8(0x08)
	int64_t InstigatorEnemySpawnId; // 0xf0(0x08)
	int64_t GroupId; // 0xf8(0x08)

	struct TArray<struct UStartSpawnSequenceProxy*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StartSpawnSequenceProxy.From // (Final|Native|Static|Public) // @ game+0x595d890
};

// Class EmbarkServerEvents.StashItems4
// Size: 0xc0 (Inherited: 0xa0)
struct UStashItems4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<struct FFieldTypeAssetInstanceAmount> StashItems; // 0xa0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmount> AttachedStashItems; // 0xb0(0x10)

	struct TArray<struct UStashItems4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StashItems4.From // (Final|Native|Static|Public) // @ game+0x59b2130
};

// Class EmbarkServerEvents.StashItems5
// Size: 0xc0 (Inherited: 0xa0)
struct UStashItems5 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<struct FFieldTypeAssetInstanceAmountDurability> StashItems; // 0xa0(0x10)
	struct TArray<struct FFieldTypeAssetInstanceAmountDurability> AttachedStashItems; // 0xb0(0x10)

	struct TArray<struct UStashItems5*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StashItems5.From // (Final|Native|Static|Public) // @ game+0x592d6b0
};

// Class EmbarkServerEvents.StashMetaItems2
// Size: 0xb0 (Inherited: 0xa0)
struct UStashMetaItems2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<struct FFieldTypeAssetInstanceAmount> StashMetaItems; // 0xa0(0x10)

	struct TArray<struct UStashMetaItems2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StashMetaItems2.From // (Final|Native|Static|Public) // @ game+0x5933fb0
};

// Class EmbarkServerEvents.StaticSpawnerActivate2
// Size: 0xf0 (Inherited: 0xa0)
struct UStaticSpawnerActivate2 : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	int64_t Player; // 0xb0(0x08)
	struct FVector PlayerLocation; // 0xb8(0x18)
	struct FString Spawner; // 0xd0(0x10)
	struct FString SpawnerUuid; // 0xe0(0x10)

	struct TArray<struct UStaticSpawnerActivate2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StaticSpawnerActivate2.From // (Final|Native|Static|Public) // @ game+0x5946210
};

// Class EmbarkServerEvents.StaticSpawnerCreated2
// Size: 0xf0 (Inherited: 0xa0)
struct UStaticSpawnerCreated2 : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	struct FString Spawner; // 0xb0(0x10)
	struct FString SpawnerParent; // 0xc0(0x10)
	struct FString EnemyTable; // 0xd0(0x10)
	struct FString SpawnerUuid; // 0xe0(0x10)

	struct TArray<struct UStaticSpawnerCreated2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StaticSpawnerCreated2.From // (Final|Native|Static|Public) // @ game+0x5963340
};

// Class EmbarkServerEvents.StaticSpawnerDeactivate2
// Size: 0xd0 (Inherited: 0xa0)
struct UStaticSpawnerDeactivate2 : UServerEventTestBase {
	struct FVector Location; // 0x98(0x18)
	struct FString Spawner; // 0xb0(0x10)
	struct FString SpawnerUuid; // 0xc0(0x10)

	struct TArray<struct UStaticSpawnerDeactivate2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StaticSpawnerDeactivate2.From // (Final|Native|Static|Public) // @ game+0x59b5940
};

// Class EmbarkServerEvents.StaticSpawnerSpawnEnemy2
// Size: 0xd0 (Inherited: 0xa0)
struct UStaticSpawnerSpawnEnemy2 : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FString Spawner; // 0xa8(0x10)
	int64_t EnemySpawnId; // 0xb8(0x08)
	struct FString SpawnerUuid; // 0xc0(0x10)

	struct TArray<struct UStaticSpawnerSpawnEnemy2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StaticSpawnerSpawnEnemy2.From // (Final|Native|Static|Public) // @ game+0x593a590
};

// Class EmbarkServerEvents.StaticSpawnerSpawnEnemy3
// Size: 0xe0 (Inherited: 0xa0)
struct UStaticSpawnerSpawnEnemy3 : UServerEventTestBase {
	struct FString Enemy; // 0x98(0x10)
	struct FString Spawner; // 0xa8(0x10)
	int64_t EnemySpawnId; // 0xb8(0x08)
	struct FString SpawnerUuid; // 0xc0(0x10)
	int64_t EnemyId; // 0xd0(0x08)

	struct TArray<struct UStaticSpawnerSpawnEnemy3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.StaticSpawnerSpawnEnemy3.From // (Final|Native|Static|Public) // @ game+0x59862b0
};

// Class EmbarkServerEvents.SteamApp
// Size: 0xc0 (Inherited: 0xa0)
struct USteamApp : UServerEventTestBase {
	int32_t SteamAppId; // 0x98(0x04)
	struct FString BranchName; // 0xa0(0x10)
	int64_t Player; // 0xb0(0x08)
	char pad_bc[0x4]; // 0xbc(0x04)

	struct TArray<struct USteamApp*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SteamApp.From // (Final|Native|Static|Public) // @ game+0x5904ba0
};

// Class EmbarkServerEvents.SubroundEnded
// Size: 0xc0 (Inherited: 0xa0)
struct USubroundEnded : UServerEventTestBase {
	struct FString SubroundId; // 0x98(0x10)
	struct FString EndReason; // 0xa8(0x10)

	struct TArray<struct USubroundEnded*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SubroundEnded.From // (Final|Native|Static|Public) // @ game+0x596c6e0
};

// Class EmbarkServerEvents.SubroundLoss
// Size: 0xd0 (Inherited: 0xa0)
struct USubroundLoss : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString SubroundId; // 0xa0(0x10)
	struct FString EndReason; // 0xb0(0x10)
	struct FString Team; // 0xc0(0x10)

	struct TArray<struct USubroundLoss*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SubroundLoss.From // (Final|Native|Static|Public) // @ game+0x59b7ec0
};

// Class EmbarkServerEvents.SubroundStarted2
// Size: 0xd0 (Inherited: 0xa0)
struct USubroundStarted2 : UServerEventTestBase {
	struct FString SubroundId; // 0x98(0x10)
	struct FString RoundState; // 0xa8(0x10)
	struct FString AttackDefendScenario; // 0xb8(0x10)

	struct TArray<struct USubroundStarted2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SubroundStarted2.From // (Final|Native|Static|Public) // @ game+0x5992ba0
};

// Class EmbarkServerEvents.SubroundWin
// Size: 0xd0 (Inherited: 0xa0)
struct USubroundWin : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString SubroundId; // 0xa0(0x10)
	struct FString EndReason; // 0xb0(0x10)
	struct FString Team; // 0xc0(0x10)

	struct TArray<struct USubroundWin*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.SubroundWin.From // (Final|Native|Static|Public) // @ game+0x5945f50
};

// Class EmbarkServerEvents.TelemetryStartup
// Size: 0xb0 (Inherited: 0xa0)
struct UTelemetryStartup : UServerEventTestBase {
	struct FString ServerSessionId; // 0x98(0x10)

	struct TArray<struct UTelemetryStartup*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TelemetryStartup.From // (Final|Native|Static|Public) // @ game+0x598ad10
};

// Class EmbarkServerEvents.TournamentState
// Size: 0xc0 (Inherited: 0xa0)
struct UTournamentState : UServerEventTestBase {
	struct FString TournamentId; // 0x98(0x10)
	struct FString MatchId; // 0xa8(0x10)

	struct TArray<struct UTournamentState*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TournamentState.From // (Final|Native|Static|Public) // @ game+0x5964210
};

// Class EmbarkServerEvents.TryActivateAbility
// Size: 0xd0 (Inherited: 0xa0)
struct UTryActivateAbility : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Ability; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)

	struct TArray<struct UTryActivateAbility*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TryActivateAbility.From // (Final|Native|Static|Public) // @ game+0x59ad800
};

// Class EmbarkServerEvents.TugOfWarCartActivationFinished
// Size: 0xc0 (Inherited: 0xa0)
struct UTugOfWarCartActivationFinished : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector CartLocation; // 0xa0(0x18)

	struct TArray<struct UTugOfWarCartActivationFinished*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TugOfWarCartActivationFinished.From // (Final|Native|Static|Public) // @ game+0x59d8d90
};

// Class EmbarkServerEvents.TugOfWarCartActivationStarted
// Size: 0xc0 (Inherited: 0xa0)
struct UTugOfWarCartActivationStarted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector CartLocation; // 0xa0(0x18)

	struct TArray<struct UTugOfWarCartActivationStarted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TugOfWarCartActivationStarted.From // (Final|Native|Static|Public) // @ game+0x5956c10
};

// Class EmbarkServerEvents.TugOfWarCartControlChange
// Size: 0xd0 (Inherited: 0xa0)
struct UTugOfWarCartControlChange : UServerEventTestBase {
	struct FVector CartLocation; // 0x98(0x18)
	int64_t PreviousSquadId; // 0xb0(0x08)
	int64_t NewSquadId; // 0xb8(0x08)
	int64_t PlayersSquad0; // 0xc0(0x08)
	int64_t PlayersSquad1; // 0xc8(0x08)

	struct TArray<struct UTugOfWarCartControlChange*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TugOfWarCartControlChange.From // (Final|Native|Static|Public) // @ game+0x59c4850
};

// Class EmbarkServerEvents.TugOfWarCartDistancePushed
// Size: 0xb0 (Inherited: 0xa0)
struct UTugOfWarCartDistancePushed : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t Distance; // 0xa0(0x08)

	struct TArray<struct UTugOfWarCartDistancePushed*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TugOfWarCartDistancePushed.From // (Final|Native|Static|Public) // @ game+0x5997280
};

// Class EmbarkServerEvents.TugOfWarCartStatus
// Size: 0xf0 (Inherited: 0xa0)
struct UTugOfWarCartStatus : UServerEventTestBase {
	float Distance; // 0x98(0x04)
	float Speed; // 0x9c(0x04)
	struct FVector CartLocation; // 0xa0(0x18)
	struct FVector CartRotation; // 0xb8(0x18)
	int64_t PlayersSquad0; // 0xd0(0x08)
	int64_t PlayersSquad1; // 0xd8(0x08)
	int64_t ControllingSquadId; // 0xe0(0x08)

	struct TArray<struct UTugOfWarCartStatus*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TugOfWarCartStatus.From // (Final|Native|Static|Public) // @ game+0x59d6920
};

// Class EmbarkServerEvents.TurbulenceShieldDamageTaken
// Size: 0xc0 (Inherited: 0xa0)
struct UTurbulenceShieldDamageTaken : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	float AccumulatedShieldDamage; // 0xb8(0x04)

	struct TArray<struct UTurbulenceShieldDamageTaken*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TurbulenceShieldDamageTaken.From // (Final|Native|Static|Public) // @ game+0x59b5b30
};

// Class EmbarkServerEvents.TutorialCompleted
// Size: 0xa0 (Inherited: 0xa0)
struct UTutorialCompleted : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)

	struct TArray<struct UTutorialCompleted*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TutorialCompleted.From // (Final|Native|Static|Public) // @ game+0x591ef40
};

// Class EmbarkServerEvents.TutorialTagAdded
// Size: 0xb0 (Inherited: 0xa0)
struct UTutorialTagAdded : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString TutorialTag; // 0xa0(0x10)

	struct TArray<struct UTutorialTagAdded*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.TutorialTagAdded.From // (Final|Native|Static|Public) // @ game+0x59c5a90
};

// Class EmbarkServerEvents.UnrealServerTime2
// Size: 0xa0 (Inherited: 0xa0)
struct UUnrealServerTime2 : UServerEventTestBase {
	int64_t UnrealTime; // 0x98(0x08)

	struct TArray<struct UUnrealServerTime2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.UnrealServerTime2.From // (Final|Native|Static|Public) // @ game+0x5943710
};

// Class EmbarkServerEvents.UpdateBounty
// Size: 0xb0 (Inherited: 0xa0)
struct UUpdateBounty : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int32_t PrevAmount; // 0xa0(0x04)
	int32_t NewAmount; // 0xa4(0x04)

	struct TArray<struct UUpdateBounty*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.UpdateBounty.From // (Final|Native|Static|Public) // @ game+0x59184c0
};

// Class EmbarkServerEvents.UpdatePlayerStats
// Size: 0xf0 (Inherited: 0xa0)
struct UUpdatePlayerStats : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t TotalScore; // 0xa0(0x08)
	int64_t CombatScore; // 0xa8(0x08)
	int64_t SupportScore; // 0xb0(0x08)
	int64_t ObjectiveScore; // 0xb8(0x08)
	int64_t NumberOfEliminitations; // 0xc0(0x08)
	int64_t NumberOfAssists; // 0xc8(0x08)
	int64_t NumberOfDeaths; // 0xd0(0x08)
	int64_t NumberOfRevives; // 0xd8(0x08)
	int64_t NumberOfObjectives; // 0xe0(0x08)
	int64_t SquadCashCollected; // 0xe8(0x08)

	struct TArray<struct UUpdatePlayerStats*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.UpdatePlayerStats.From // (Final|Native|Static|Public) // @ game+0x594f370
};

// Class EmbarkServerEvents.UsedSpawnBudgetUpdate
// Size: 0xc0 (Inherited: 0xa0)
struct UUsedSpawnBudgetUpdate : UServerEventTestBase {
	int64_t OldUsedSpawnBudget; // 0x98(0x08)
	int64_t NewUsedSpawnBudget; // 0xa0(0x08)
	int64_t MaxSpawnBudget; // 0xa8(0x08)
	int64_t PlayerCount; // 0xb0(0x08)

	struct TArray<struct UUsedSpawnBudgetUpdate*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.UsedSpawnBudgetUpdate.From // (Final|Native|Static|Public) // @ game+0x59b4e50
};

// Class EmbarkServerEvents.ViewSample
// Size: 0x100 (Inherited: 0xa0)
struct UViewSample : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct TArray<float> MovementInputX; // 0xa0(0x10)
	struct TArray<float> MovementInputY; // 0xb0(0x10)
	struct TArray<float> MovementInputZ; // 0xc0(0x10)
	struct TArray<float> LookRotationVelocityPitch; // 0xd0(0x10)
	struct TArray<float> LookRotationVelocityYaw; // 0xe0(0x10)
	struct TArray<bool> IsUsingGamepad; // 0xf0(0x10)

	struct TArray<struct UViewSample*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ViewSample.From // (Final|Native|Static|Public) // @ game+0x599e890
};

// Class EmbarkServerEvents.WeaponFired
// Size: 0x100 (Inherited: 0xa0)
struct UWeaponFired : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	struct FVector Direction; // 0xc8(0x18)
	int64_t BulletsAfter; // 0xe0(0x08)
	bool bUsingCamera; // 0xe8(0x01)
	int64_t WeaponId; // 0xf0(0x08)
	char pad_f9[0x7]; // 0xf9(0x07)

	struct TArray<struct UWeaponFired*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WeaponFired.From // (Final|Native|Static|Public) // @ game+0x59b8a80
};

// Class EmbarkServerEvents.WeaponFired3
// Size: 0x110 (Inherited: 0xa0)
struct UWeaponFired3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	struct FVector Direction; // 0xc8(0x18)
	int64_t BulletsAfter; // 0xe0(0x08)
	bool bUsingCamera; // 0xe8(0x01)
	int64_t WeaponId; // 0xf0(0x08)
	float Dispersion; // 0xf8(0x04)
	float Durability; // 0xfc(0x04)
	float MaxDurability; // 0x100(0x04)
	char pad_105[0xb]; // 0x105(0x0b)

	struct TArray<struct UWeaponFired3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WeaponFired3.From // (Final|Native|Static|Public) // @ game+0x598bab0
};

// Class EmbarkServerEvents.WeaponFired4
// Size: 0x110 (Inherited: 0xa0)
struct UWeaponFired4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	struct FVector Direction; // 0xc8(0x18)
	int64_t BulletsAfter; // 0xe0(0x08)
	bool bUsingCamera; // 0xe8(0x01)
	int64_t WeaponId; // 0xf0(0x08)
	float Dispersion; // 0xf8(0x04)
	float Durability; // 0xfc(0x04)
	struct TArray<struct FFieldTypeAssetInstanceAmount> SubItems; // 0x100(0x10)

	struct TArray<struct UWeaponFired4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WeaponFired4.From // (Final|Native|Static|Public) // @ game+0x59b9910
};

// Class EmbarkServerEvents.WeaponModRemoved4
// Size: 0xf0 (Inherited: 0xa0)
struct UWeaponModRemoved4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t WeaponGameAssetId; // 0xa0(0x08)
	struct FString WeaponName; // 0xa8(0x10)
	struct FString WeaponInstanceId; // 0xb8(0x10)
	int64_t ModGameAssetId; // 0xc8(0x08)
	struct FString ModName; // 0xd0(0x10)
	struct FString ModInstanceId; // 0xe0(0x10)

	struct TArray<struct UWeaponModRemoved4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WeaponModRemoved4.From // (Final|Native|Static|Public) // @ game+0x59a96d0
};

// Class EmbarkServerEvents.WeaponModSet4
// Size: 0xf0 (Inherited: 0xa0)
struct UWeaponModSet4 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t WeaponGameAssetId; // 0xa0(0x08)
	struct FString WeaponName; // 0xa8(0x10)
	struct FString WeaponInstanceId; // 0xb8(0x10)
	int64_t ModGameAssetId; // 0xc8(0x08)
	struct FString ModName; // 0xd0(0x10)
	struct FString ModInstanceId; // 0xe0(0x10)

	struct TArray<struct UWeaponModSet4*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WeaponModSet4.From // (Final|Native|Static|Public) // @ game+0x5984aa0
};

// Class EmbarkServerEvents.WeaponReload
// Size: 0xe0 (Inherited: 0xa0)
struct UWeaponReload : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Weapon; // 0xa0(0x10)
	struct FVector Location; // 0xb0(0x18)
	int64_t BulletsBefore; // 0xc8(0x08)
	int64_t BulletsAfter; // 0xd0(0x08)
	int64_t WeaponId; // 0xd8(0x08)

	struct TArray<struct UWeaponReload*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WeaponReload.From // (Final|Native|Static|Public) // @ game+0x590a9b0
};

// Class EmbarkServerEvents.WorldActivityInteraction
// Size: 0xe0 (Inherited: 0xa0)
struct UWorldActivityInteraction : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Name; // 0xa0(0x10)
	struct FVector ActivityLocation; // 0xb0(0x18)
	struct FString Interaction; // 0xc8(0x10)

	struct TArray<struct UWorldActivityInteraction*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WorldActivityInteraction.From // (Final|Native|Static|Public) // @ game+0x5944550
};

// Class EmbarkServerEvents.WorldActivitySpawned
// Size: 0xc0 (Inherited: 0xa0)
struct UWorldActivitySpawned : UServerEventTestBase {
	struct FString ActivityName; // 0x98(0x10)
	struct FVector Location; // 0xa8(0x18)

	struct TArray<struct UWorldActivitySpawned*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.WorldActivitySpawned.From // (Final|Native|Static|Public) // @ game+0x59ab820
};

// Class EmbarkServerEvents.XPBonusApplied
// Size: 0xc0 (Inherited: 0xa0)
struct UXPBonusApplied : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	float XpMultiplier; // 0xa0(0x04)
	int64_t BaseXp; // 0xa8(0x08)
	int64_t BonusXp; // 0xb0(0x08)
	int64_t TotalXP; // 0xb8(0x08)

	struct TArray<struct UXPBonusApplied*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.XPBonusApplied.From // (Final|Native|Static|Public) // @ game+0x59a6110
};

// Class EmbarkServerEvents.XPBonusApplied2
// Size: 0xd0 (Inherited: 0xa0)
struct UXPBonusApplied2 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FString Reason; // 0xa0(0x10)
	float XpMultiplier; // 0xb0(0x04)
	int64_t BaseXp; // 0xb8(0x08)
	int64_t BonusXp; // 0xc0(0x08)
	int64_t TotalXP; // 0xc8(0x08)

	struct TArray<struct UXPBonusApplied2*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.XPBonusApplied2.From // (Final|Native|Static|Public) // @ game+0x59439d0
};

// Class EmbarkServerEvents.XPEventUpdate3
// Size: 0xc0 (Inherited: 0xa0)
struct UXPEventUpdate3 : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	int64_t CategoryAssetId; // 0xa0(0x08)
	int64_t XpEventId; // 0xa8(0x08)
	int64_t Xp; // 0xb0(0x08)

	struct TArray<struct UXPEventUpdate3*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.XPEventUpdate3.From // (Final|Native|Static|Public) // @ game+0x59788c0
};

// Class EmbarkServerEvents.ZiplineUse
// Size: 0xd0 (Inherited: 0xa0)
struct UZiplineUse : UServerEventTestBase {
	int64_t Player; // 0x98(0x08)
	struct FVector Location; // 0xa0(0x18)
	bool bIsStatic; // 0xb8(0x01)
	int64_t PlacingPlayer; // 0xc0(0x08)
	char pad_c9[0x7]; // 0xc9(0x07)

	struct TArray<struct UZiplineUse*> From(struct TArray<struct UServerEventTestBase*> Events); // Function EmbarkServerEvents.ZiplineUse.From // (Final|Native|Static|Public) // @ game+0x59c9a60
};

