// Enum HiveRuntime.EMLFilterType
enum class EMLFilterType : uint8_t {
	None = 0,
	RecursiveLerp = 1,
	MinJerk = 2,
	EMLFilterType_MAX = 3
};

// Enum HiveRuntime.EObservedType
enum class EObservedType : uint8_t {
	Body = 0,
	Constraint = 1,
	SocketOrBone = 2,
	EObservedType_MAX = 3
};

// ScriptStruct HiveRuntime.MLEffectorModifierItem
// Size: 0x10 (Inherited: 0x00)
struct FMLEffectorModifierItem {
	int32_t Priority; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UMLEffectorModifier* Modifier; // 0x08(0x08)
};

// ScriptStruct HiveRuntime.ObserverState
// Size: 0x310 (Inherited: 0x00)
struct FObserverState {
	struct UActorComponent* Comp; // 0x00(0x08)
	int32_t SegmentIndex; // 0x08(0x04)
	enum class EObservedType Type; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	struct FName Name; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct FTransform LocalTransform; // 0x20(0x60)
	struct FTransform PrevLocalTransform; // 0x80(0x60)
	struct FTransform WorldTransform; // 0xe0(0x60)
	struct FTransform PrevWorldTransform; // 0x140(0x60)
	struct FVector LocalInstantLinearVelocity; // 0x1a0(0x18)
	struct FVector LocalAngularVelocity; // 0x1b8(0x18)
	struct FVector InstantLinearVelocity; // 0x1d0(0x18)
	struct FVector InstantAngularVelocity; // 0x1e8(0x18)
	struct FVector TwistSwingSwing; // 0x200(0x18)
	struct FVector PrevTwistSwingSwing; // 0x218(0x18)
	struct FVector PrevTickTwistSwingSwing; // 0x230(0x18)
	struct FVector InstantTwistSwingSwingVelocity; // 0x248(0x18)
	struct FVector ImpulseNormal; // 0x260(0x18)
	struct FVector ImpulseLocation; // 0x278(0x18)
	struct FVector LinearConstraintOffset; // 0x290(0x18)
	char pad_2a8[0x1]; // 0x2a8(0x01)
	bool bAngularConstraintIsEnabled; // 0x2a9(0x01)
	char pad_2aa[0x6]; // 0x2aa(0x06)
	int64_t LastDownFrame; // 0x2b0(0x08)
	bool bIsValid; // 0x2b8(0x01)
	bool bIsActive; // 0x2b9(0x01)
	char pad_2ba[0x6]; // 0x2ba(0x06)
	struct FVector Extents; // 0x2c0(0x18)
	struct FVector BoundsOrigin; // 0x2d8(0x18)
	int32_t ID; // 0x2f0(0x04)
	int32_t ParentID; // 0x2f4(0x04)
	int32_t GrandParentId; // 0x2f8(0x04)
	char pad_2fc[0x4]; // 0x2fc(0x04)
	struct TArray<int32_t> Children; // 0x300(0x10)
};

// ScriptStruct HiveRuntime.MLPolicyDefinition
// Size: 0x18 (Inherited: 0x00)
struct FMLPolicyDefinition {
	struct UMLModelData* ModelData; // 0x00(0x08)
	struct FName BehaviorName; // 0x08(0x08)
	struct FGameplayTag PolicyTag; // 0x10(0x08)
};

// ScriptStruct HiveRuntime.MLReplicatedPolicyData
// Size: 0x08 (Inherited: 0x00)
struct FMLReplicatedPolicyData {
	int32_t PolicyIndex; // 0x00(0x04)
	int32_t BehaviorIndex; // 0x04(0x04)
};

// ScriptStruct HiveRuntime.MLTickDispatcherPrePhysicsTick
// Size: 0x40 (Inherited: 0x38)
struct FMLTickDispatcherPrePhysicsTick : FTickFunction {
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct HiveRuntime.MLTickDispatcherPostPhysicsTick
// Size: 0x40 (Inherited: 0x38)
struct FMLTickDispatcherPostPhysicsTick : FTickFunction {
	char pad_38[0x8]; // 0x38(0x08)
};

