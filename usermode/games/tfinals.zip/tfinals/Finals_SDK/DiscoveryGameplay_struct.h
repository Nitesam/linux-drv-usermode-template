// Enum DiscoveryGameplay.EDiscoveryPowerState
enum class EDiscoveryPowerState : uint8_t {
	Off = 0,
	On = 1,
	Broken = 2,
	EDiscoveryPowerState_MAX = 3
};

// Enum DiscoveryGameplay.EDoorState
enum class EDoorState : uint8_t {
	Closed = 0,
	Open = 1,
	OpenBashed = 2,
	MAX_NUM = 3,
	EDoorState_MAX = 4
};

// Enum DiscoveryGameplay.EGooOverlapType
enum class EGooOverlapType : uint8_t {
	None = 0,
	Critical = 1,
	Static = 2,
	Dynamic = 4,
	GooStatic = 8,
	GooDynamic = 16,
	EGooOverlapType_MAX = 17
};

// Enum DiscoveryGameplay.EDamageSeverity
enum class EDamageSeverity : uint8_t {
	Normal = 0,
	Critical = 1,
	Minor = 2,
	EDamageSeverity_MAX = 3
};

// Enum DiscoveryGameplay.EDiscoveryReplayInputMode
enum class EDiscoveryReplayInputMode : uint8_t {
	BridgeInputToRealWorld = 0,
	BlockRealWorldInput = 1,
	EDiscoveryReplayInputMode_MAX = 2
};

// ScriptStruct DiscoveryGameplay.DiscoveryReplicatedDamageData
// Size: 0x60 (Inherited: 0x00)
struct FDiscoveryReplicatedDamageData {
	struct FVector ImpactPoint; // 0x00(0x18)
	struct FVector Origin; // 0x18(0x18)
	struct FVector Direction; // 0x30(0x18)
	float MaxHealth; // 0x48(0x04)
	float NewHealth; // 0x4c(0x04)
	float Damage; // 0x50(0x04)
	float Time; // 0x54(0x04)
	enum class EDSMDamageType DamageType; // 0x58(0x01)
	char bHasImpactPoint : 1; // 0x59(0x01)
	char bHasOrigin : 1; // 0x59(0x01)
	char bHasDirection : 1; // 0x59(0x01)
	char bHasHealth : 1; // 0x59(0x01)
	char bHasDamage : 1; // 0x59(0x01)
	char pad_59_5 : 3; // 0x59(0x01)
	char pad_5a[0x6]; // 0x5a(0x06)
};

// ScriptStruct DiscoveryGameplay.DiscoveryAnimationSignificanceDistance
// Size: 0x18 (Inherited: 0x00)
struct FDiscoveryAnimationSignificanceDistance {
	float DistanceSignificanceAdd; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector2D DistanceRange; // 0x08(0x10)
};

// ScriptStruct DiscoveryGameplay.CrouchPredictionParams
// Size: 0x28 (Inherited: 0x00)
struct FCrouchPredictionParams {
	float CapsuleRadius; // 0x00(0x04)
	float CrouchedCapsuleHalfHeight; // 0x04(0x04)
	float StandingCapsuleHalfHeight; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FVector UnCrouchAtLocation; // 0x10(0x18)
};

// ScriptStruct DiscoveryGameplay.DiscoCharMovementStartPhysicsTickFunction
// Size: 0x40 (Inherited: 0x38)
struct FDiscoCharMovementStartPhysicsTickFunction : FTickFunction {
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct DiscoveryGameplay.DiscoCharMovementPostPhysicsTickFunction
// Size: 0x40 (Inherited: 0x38)
struct FDiscoCharMovementPostPhysicsTickFunction : FTickFunction {
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct DiscoveryGameplay.EmbarkJumpState
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkJumpState {
	float JumpStaminaWhenStartedJumping; // 0x00(0x04)
	float StartedJumpingTimeStamp; // 0x04(0x04)
	struct FVector CharacterLocationWhenStartedJumping; // 0x08(0x18)
};

// ScriptStruct DiscoveryGameplay.EmbarkPushCharacterData
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkPushCharacterData {
	struct FVector PushVelocity; // 0x00(0x18)
	struct FVector CurrentVelocityToKeep; // 0x18(0x18)
	bool bSetNewMovementMode; // 0x30(0x01)
	enum class EMovementMode PushMovementMode; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
};

// ScriptStruct DiscoveryGameplay.DiscoveryDematerializeCachedCollisionData
// Size: 0x50 (Inherited: 0x00)
struct FDiscoveryDematerializeCachedCollisionData {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct DiscoveryGameplay.DematerializedItem
// Size: 0x38 (Inherited: 0x0c)
struct FDematerializedItem : FFastArraySerializerItem {
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // 0x0c(0x08)
	int32_t BoneIndex; // 0x14(0x04)
	struct FVector_NetQuantize Direction; // 0x18(0x18)
	char ClusterID; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct DiscoveryGameplay.DematerializedComponentData
// Size: 0x18 (Inherited: 0x00)
struct FDematerializedComponentData {
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // 0x00(0x08)
	int32_t BoneIndex; // 0x08(0x04)
	struct TWeakObjectPtr<struct AActor> Causer; // 0x0c(0x08)
	bool bDirtyFlag; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
};

// ScriptStruct DiscoveryGameplay.DematerializedFastArray
// Size: 0x128 (Inherited: 0x110)
struct FDematerializedFastArray : FFastArraySerializer {
	struct TArray<struct FDematerializedItem> Items; // 0x110(0x10)
	struct ADiscoveryDematerializeToolReplicatorActorBase* DematerializeToolGlobalActor; // 0x120(0x08)
};

// ScriptStruct DiscoveryGameplay.DiscoveryReplicatedDoorSharedData
// Size: 0x08 (Inherited: 0x00)
struct FDiscoveryReplicatedDoorSharedData {
	float ServerStartedTurningTimeStamp; // 0x00(0x04)
	int8_t RotationTargetState; // 0x04(0x01)
	enum class EDoorState State; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
};

// ScriptStruct DiscoveryGameplay.DiscoveryReplicatedDoorData
// Size: 0x10 (Inherited: 0x00)
struct FDiscoveryReplicatedDoorData {
	struct TWeakObjectPtr<struct AActor> DoorActor; // 0x00(0x08)
	struct FDiscoveryReplicatedDoorSharedData Shared; // 0x08(0x08)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastArrayBreakItem
// Size: 0x20 (Inherited: 0x10)
struct FDiscoveryFastArrayBreakItem : FEmbarkFastArrayItemBase {
	struct FEmbarkFastReplicatorActorOrComponent Ref; // 0x10(0x10)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastArrayBreak
// Size: 0x130 (Inherited: 0x120)
struct FDiscoveryFastArrayBreak : FEmbarkFastArrayBase {
	struct TArray<struct FDiscoveryFastArrayBreakItem> Items; // 0x120(0x10)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastArrayDamageItem
// Size: 0x80 (Inherited: 0x10)
struct FDiscoveryFastArrayDamageItem : FEmbarkFastArrayItemBase {
	struct FEmbarkFastReplicatorActorOrComponent Ref; // 0x10(0x10)
	struct FDiscoveryReplicatedDamageData Damage; // 0x20(0x60)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastArrayDamage
// Size: 0x130 (Inherited: 0x120)
struct FDiscoveryFastArrayDamage : FEmbarkFastArrayBase {
	struct TArray<struct FDiscoveryFastArrayDamageItem> Items; // 0x120(0x10)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastArrayGravityGunItem
// Size: 0x28 (Inherited: 0x10)
struct FDiscoveryFastArrayGravityGunItem : FEmbarkFastArrayItemBase {
	struct FEmbarkFastReplicatorActorOrComponent Ref; // 0x10(0x10)
	struct UActorComponent* CarriedPickupable; // 0x20(0x08)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastArrayGravityGun
// Size: 0x130 (Inherited: 0x120)
struct FDiscoveryFastArrayGravityGun : FEmbarkFastArrayBase {
	struct TArray<struct FDiscoveryFastArrayGravityGunItem> Items; // 0x120(0x10)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastReplicatorPowerItem
// Size: 0x28 (Inherited: 0x10)
struct FDiscoveryFastReplicatorPowerItem : FEmbarkFastArrayItemBase {
	struct FEmbarkFastReplicatorActorOrComponent Ref; // 0x10(0x10)
	enum class EDiscoveryPowerState PowerState; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DiscoveryGameplay.DiscoveryFastReplicatorPowerArray
// Size: 0x130 (Inherited: 0x120)
struct FDiscoveryFastReplicatorPowerArray : FEmbarkFastArrayBase {
	struct TArray<struct FDiscoveryFastReplicatorPowerItem> Items; // 0x120(0x10)
};

// ScriptStruct DiscoveryGameplay.DiscoveryInstantReplayPayload
// Size: 0x78 (Inherited: 0x00)
struct FDiscoveryInstantReplayPayload {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct DiscoveryGameplay.DMDamageEventInfo
// Size: 0xf0 (Inherited: 0x00)
struct FDMDamageEventInfo {
	struct FName BoneName; // 0x00(0x08)
	float NewHealth; // 0x08(0x04)
	float PreviousHealth; // 0x0c(0x04)
	float MaxHealth; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FVector Location; // 0x18(0x18)
	struct FVector BoundsExtent; // 0x30(0x18)
	enum class EDSMDamageType DamageType; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float StaleReplicationDataSeconds; // 0x4c(0x04)
	struct FVector_NetQuantize10 Origin; // 0x50(0x18)
	struct FVector_NetQuantize10 ImpactPoint; // 0x68(0x18)
	struct FVector_NetQuantizeNormal Direction; // 0x80(0x18)
	bool bStartSimulating; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct FInstigator Instigator; // 0xa0(0x50)
};

// ScriptStruct DiscoveryGameplay.GooPenetrationData
// Size: 0x30 (Inherited: 0x00)
struct FGooPenetrationData {
	struct FVector Direction; // 0x00(0x18)
	float Distance; // 0x18(0x04)
	enum class EGooOverlapType Type; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
	struct UPrimitiveComponent* Collider; // 0x20(0x08)
	struct FName BoneName; // 0x28(0x08)
};

// ScriptStruct DiscoveryGameplay.DiscoveryHarpoonConstraint
// Size: 0x288 (Inherited: 0x00)
struct FDiscoveryHarpoonConstraint {
	struct FConstraintInstance ConstraintInstance; // 0x00(0x278)
	char pad_278[0x10]; // 0x278(0x10)
};

// ScriptStruct DiscoveryGameplay.DiscoveryClientDamageData
// Size: 0x58 (Inherited: 0x00)
struct FDiscoveryClientDamageData {
	float CurrentHealthUNorm_RoughEstimate; // 0x00(0x04)
	float HealthChangeSNorm_RoughEstimate; // 0x04(0x04)
	struct FVector_NetQuantize Origin; // 0x08(0x18)
	struct FVector_NetQuantize ImpactPoint; // 0x20(0x18)
	struct FVector_NetQuantizeNormal ImpactNormal; // 0x38(0x18)
	bool bHasOrigin; // 0x50(0x01)
	enum class EDamageSeverity Severity; // 0x51(0x01)
	char pad_52[0x6]; // 0x52(0x06)
};

// ScriptStruct DiscoveryGameplay.InventorySlot
// Size: 0x04 (Inherited: 0x00)
struct FInventorySlot {
	int32_t SlotId; // 0x00(0x04)
};

// ScriptStruct DiscoveryGameplay.EventLogPingInfo
// Size: 0x58 (Inherited: 0x00)
struct FEventLogPingInfo {
	struct FText Message; // 0x00(0x18)
	struct TArray<struct FGameplayTag> MessageParameterConcepts; // 0x18(0x10)
	bool bIgnoreEventLogTemplateText; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TSoftObjectPtr<UTexture2D> IconOverride; // 0x30(0x28)
};

// ScriptStruct DiscoveryGameplay.PingEventLogOverrideEntry
// Size: 0xa8 (Inherited: 0x00)
struct FPingEventLogOverrideEntry {
	struct FGameplayTag Object; // 0x00(0x08)
	struct FGameplayTagQuery Query; // 0x08(0x48)
	struct FText Message; // 0x50(0x18)
	struct TArray<struct FGameplayTag> MessageParameterConcepts; // 0x68(0x10)
	bool bIgnoreEventLogTemplateText; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct TSoftObjectPtr<UTexture2D> IconOverride; // 0x80(0x28)
};

// ScriptStruct DiscoveryGameplay.PingEventLogObjectEntry
// Size: 0x10 (Inherited: 0x00)
struct FPingEventLogObjectEntry {
	struct TArray<struct FPingEventLogOverrideEntry> Conditions; // 0x00(0x10)
};

