// Class EmbarkObjectPools.EmbarkObjectPool
// Size: 0x130 (Inherited: 0xa0)
struct UEmbarkObjectPool : UObject {
	char pad_a0[0x90]; // 0xa0(0x90)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkObjectPool.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ea7b0
	bool PoolObject(struct UObject*& Object); // Function EmbarkObjectPools.EmbarkObjectPool.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f3010
	struct UObject* NextOrCreateObject(); // Function EmbarkObjectPools.EmbarkObjectPool.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f6690
	struct UObject* NextObject(); // Function EmbarkObjectPools.EmbarkObjectPool.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f3cb0
	void InitializePool(struct FName& Name, struct UObject* Class, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkObjectPool.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ec130
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkObjectPool.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50f7e10
	void FillPool(int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkObjectPool.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e40a0
};

// Class EmbarkObjectPools.EmbarkActorPool
// Size: 0x130 (Inherited: 0xa0)
struct UEmbarkActorPool : UObject {
	char pad_a0[0x90]; // 0xa0(0x90)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorPool.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ea7b0
	bool PoolObject(struct AActor*& Object); // Function EmbarkObjectPools.EmbarkActorPool.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e8e10
	struct AActor* NextOrCreateObject(); // Function EmbarkObjectPools.EmbarkActorPool.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f7710
	struct AActor* NextObject(); // Function EmbarkObjectPools.EmbarkActorPool.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50ee720
	void InitializePool(struct FName& Name, struct AActor*& Class, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorPool.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50fa9b0
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorPool.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ea510
	void FillPool(int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorPool.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50f4670
};

// Class EmbarkObjectPools.EmbarkActorComponentPool
// Size: 0x130 (Inherited: 0xa0)
struct UEmbarkActorComponentPool : UObject {
	char pad_a0[0x90]; // 0xa0(0x90)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorComponentPool.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ea7b0
	bool PoolObject(struct UActorComponent*& Object); // Function EmbarkObjectPools.EmbarkActorComponentPool.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f2370
	struct UActorComponent* NextOrCreateObject(); // Function EmbarkObjectPools.EmbarkActorComponentPool.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50e7800
	struct UActorComponent* NextObject(); // Function EmbarkObjectPools.EmbarkActorComponentPool.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50ee720
	void InitializePool(struct FName& Name, struct UActorComponent*& Class, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorComponentPool.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e5e60
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorComponentPool.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e7250
	void FillPool(int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorComponentPool.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ee530
};

// Class EmbarkObjectPools.EmbarkObjectVariantPool
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkObjectVariantPool : UObject {
	char pad_a0[0xe0]; // 0xa0(0xe0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkObjectVariantPool.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e1c70
	void PrewarmPool(struct UObject* Class); // Function EmbarkObjectPools.EmbarkObjectVariantPool.PrewarmPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e8400
	bool PoolObject(struct UObject*& Object); // Function EmbarkObjectPools.EmbarkObjectVariantPool.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50eb5c0
	struct UObject* NextOrCreateObject(struct UObject* Class); // Function EmbarkObjectPools.EmbarkObjectVariantPool.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f48d0
	struct UObject* NextObject(struct UObject* Class); // Function EmbarkObjectPools.EmbarkObjectVariantPool.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f2950
	void InitializePool(struct FName& Name, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkObjectVariantPool.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50eda70
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkObjectVariantPool.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50f70d0
	void FillPool(struct UObject* Class, int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkObjectVariantPool.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e3bf0
};

// Class EmbarkObjectPools.EmbarkActorVariantPool
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkActorVariantPool : UObject {
	char pad_a0[0xe0]; // 0xa0(0xe0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorVariantPool.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e1c70
	void PrewarmPool(struct AActor*& Class); // Function EmbarkObjectPools.EmbarkActorVariantPool.PrewarmPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f3460
	bool PoolObject(struct AActor*& Object); // Function EmbarkObjectPools.EmbarkActorVariantPool.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50eefd0
	struct AActor* NextOrCreateObject(struct AActor*& Class); // Function EmbarkObjectPools.EmbarkActorVariantPool.NextOrCreateObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e82d0
	struct AActor* NextObject(struct AActor*& Class); // Function EmbarkObjectPools.EmbarkActorVariantPool.NextObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ef610
	void InitializePool(struct FName& Name, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorVariantPool.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50eda70
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorVariantPool.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e85c0
	void FillPool(struct AActor*& Class, int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorVariantPool.FillPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e35d0
};

// Class EmbarkObjectPools.EmbarkActorComponentVariantPool
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkActorComponentVariantPool : UObject {
	char pad_a0[0xe0]; // 0xa0(0xe0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e1c70
	void PrewarmPool(struct UActorComponent*& Class); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.PrewarmPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f0d20
	bool PoolObject(struct UActorComponent*& Object); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ee2e0
	struct UActorComponent* NextOrCreateObject(struct UActorComponent*& Class); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.NextOrCreateObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e5cb0
	struct UActorComponent* NextObject(struct UActorComponent*& Class); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.NextObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e3a90
	void InitializePool(struct FName& Name, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e4210
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e7770
	void FillPool(struct UActorComponent*& Class, int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorComponentVariantPool.FillPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50eb750
};

// Class EmbarkObjectPools.EmbarkObjectPoolSubsystem
// Size: 0x140 (Inherited: 0xa0)
struct UEmbarkObjectPoolSubsystem : UWorldSubsystem {
	char pad_a0[0xa0]; // 0xa0(0xa0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e1da0
	bool PoolObject(struct UObject*& Object); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f84e0
	void OnInitializeSubsystem(); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.OnInitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitializeSubsystem(); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.OnDeinitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UObject* NextOrCreateObject(); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50e7120
	struct UObject* NextObject(); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f1eb0
	void InitializePool(struct FName& Name, struct UObject* Class, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ef930
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50f2d10
	void FillPool(int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkObjectPoolSubsystem.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50fc020
};

// Class EmbarkObjectPools.EmbarkActorPoolSubsystem
// Size: 0x140 (Inherited: 0xa0)
struct UEmbarkActorPoolSubsystem : UWorldSubsystem {
	char pad_a0[0xa0]; // 0xa0(0xa0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e1da0
	bool PoolObject(struct AActor*& Object); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50fbca0
	void OnInitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.OnInitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.OnDeinitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct AActor* NextOrCreateObject(); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50e9f40
	struct AActor* NextObject(); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50e4bf0
	void InitializePool(struct FName& Name, struct AActor*& Class, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f57b0
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ec030
	void FillPool(int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorPoolSubsystem.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50ecfa0
};

// Class EmbarkObjectPools.EmbarkActorComponentPoolSubsystem
// Size: 0x140 (Inherited: 0xa0)
struct UEmbarkActorComponentPoolSubsystem : UWorldSubsystem {
	char pad_a0[0xa0]; // 0xa0(0xa0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e1da0
	bool PoolObject(struct UActorComponent*& Object); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e7be0
	void OnInitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.OnInitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.OnDeinitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UActorComponent* NextOrCreateObject(); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50ec640
	struct UActorComponent* NextObject(); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50e4bf0
	void InitializePool(struct FName& Name, struct UActorComponent*& Class, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f07c0
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50fb860
	void FillPool(int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorComponentPoolSubsystem.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e8fe0
};

// Class EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkObjectVariantPoolSubsystem : UWorldSubsystem {
	char pad_a0[0xe0]; // 0xa0(0xe0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e4580
	void PrewarmPool(struct UObject* Class); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.PrewarmPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e7ef0
	bool PoolObject(struct UObject*& Object); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f86b0
	void OnInitializeSubsystem(); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.OnInitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitializeSubsystem(); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.OnDeinitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UObject* NextOrCreateObject(struct UObject* Class); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.NextOrCreateObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50ebbb0
	struct UObject* NextObject(struct UObject* Class); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.NextObject // (Final|Native|Public|BlueprintCallable) // @ game+0x50f1740
	void InitializePool(struct FName& Name, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e2920
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e6eb0
	void FillPool(struct UObject* Class, int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkObjectVariantPoolSubsystem.FillPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e8130
};

// Class EmbarkObjectPools.EmbarkActorVariantPoolSubsystem
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkActorVariantPoolSubsystem : UWorldSubsystem {
	char pad_a0[0xe0]; // 0xa0(0xe0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e4580
	void PrewarmPool(struct AActor*& Class); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.PrewarmPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f12e0
	bool PoolObject(struct AActor*& Object); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ee020
	void OnInitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.OnInitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.OnDeinitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct AActor* NextOrCreateObject(struct AActor*& Class); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.NextOrCreateObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f2650
	struct AActor* NextObject(struct AActor*& Class); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.NextObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50fb350
	void InitializePool(struct FName& Name, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e2920
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50eaa80
	void FillPool(struct AActor*& Class, int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorVariantPoolSubsystem.FillPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f0030
};

// Class EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkActorComponentVariantPoolSubsystem : UWorldSubsystem {
	char pad_a0[0xe0]; // 0xa0(0xe0)

	void ResetPool(int32_t Capacity); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.ResetPool // (Final|Native|Public|BlueprintCallable) // @ game+0x50e4580
	void PrewarmPool(struct UActorComponent*& Class); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.PrewarmPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ea6c0
	bool PoolObject(struct UActorComponent*& Object); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.PoolObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50ea100
	void OnInitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.OnInitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitializeSubsystem(); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.OnDeinitializeSubsystem // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UActorComponent* NextOrCreateObject(struct UActorComponent*& Class); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.NextOrCreateObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e6f00
	struct UActorComponent* NextObject(struct UActorComponent*& Class); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.NextObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50e4ad0
	void InitializePool(struct FName& Name, struct FDelegate Delegate, int32_t Capacity, int32_t FillTarget, int32_t FillRate, float FillInterval); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.InitializePool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50f13d0
	void FinalizePool(); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.FinalizePool // (Final|Native|Public|BlueprintCallable) // @ game+0x50f6720
	void FillPool(struct UActorComponent*& Class, int32_t FillTarget, int32_t FillRate); // Function EmbarkObjectPools.EmbarkActorComponentVariantPoolSubsystem.FillPool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50fb110
};

