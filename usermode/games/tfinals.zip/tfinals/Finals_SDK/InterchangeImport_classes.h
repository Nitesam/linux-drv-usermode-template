// Class InterchangeImport.InterchangeAnimationPayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeAnimationPayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeAnimationTrackSetFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UInterchangeAnimationTrackSetFactory : UInterchangeFactoryBase {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class InterchangeImport.InterchangeBlockedTexturePayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeBlockedTexturePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeActorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeActorFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeLightActorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeLightActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeMeshPayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeMeshPayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeSceneImportAssetFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeSceneImportAssetFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeSceneVariantSetsFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UInterchangeSceneVariantSetsFactory : UInterchangeFactoryBase {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class InterchangeImport.InterchangeSlicedTexturePayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeSlicedTexturePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeTextureLightProfilePayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeTextureLightProfilePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeTexturePayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeTexturePayloadInterface : UInterface {
};

// Class InterchangeImport.InterchangeVariantSetPayloadInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeVariantSetPayloadInterface : UInterface {
};

// Class InterchangeImport.MaterialExpressionMaterialXRamp4
// Size: 0x1f0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXRamp4 : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x120(0x28)
	struct FExpressionInput A; // 0x148(0x28)
	struct FExpressionInput B; // 0x170(0x28)
	struct FExpressionInput C; // 0x198(0x28)
	struct FExpressionInput D; // 0x1c0(0x28)
	char ConstCoordinate; // 0x1e8(0x01)
	char pad_1e9[0x7]; // 0x1e9(0x07)
};

// Class InterchangeImport.InterchangeAnimSequenceFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeAnimSequenceFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeFbxTranslator
// Size: 0xd0 (Inherited: 0xb0)
struct UInterchangeFbxTranslator : UInterchangeTranslatorBase {
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class InterchangeImport.InterchangeGLTFTranslator
// Size: 0x2f0 (Inherited: 0xb0)
struct UInterchangeGLTFTranslator : UInterchangeTranslatorBase {
	char pad_b0[0x240]; // 0xb0(0x240)
};

// Class InterchangeImport.InterchangeMaterialXTranslator
// Size: 0xb0 (Inherited: 0xb0)
struct UInterchangeMaterialXTranslator : UInterchangeTranslatorBase {
};

// Class InterchangeImport.MaterialExpressionMaterialXAppend3Vector
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXAppend3Vector : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput C; // 0x170(0x28)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class InterchangeImport.MaterialExpressionMaterialXAppend4Vector
// Size: 0x1c0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXAppend4Vector : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput C; // 0x170(0x28)
	struct FExpressionInput D; // 0x198(0x28)
};

// Class InterchangeImport.MaterialExpressionMaterialXBurn
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXBurn : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXDifference
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXDifference : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXDisjointOver
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXDisjointOver : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXDodge
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXDodge : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXFractal3D
// Size: 0x220 (Inherited: 0x120)
struct UMaterialExpressionMaterialXFractal3D : UMaterialExpression {
	struct FExpressionInput Position; // 0x120(0x28)
	struct FExpressionInput Amplitude; // 0x148(0x28)
	float ConstAmplitude; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	struct FExpressionInput Octaves; // 0x178(0x28)
	int32_t ConstOctaves; // 0x1a0(0x04)
	char pad_1a4[0x4]; // 0x1a4(0x04)
	struct FExpressionInput Lacunarity; // 0x1a8(0x28)
	float ConstLacunarity; // 0x1d0(0x04)
	char pad_1d4[0x4]; // 0x1d4(0x04)
	struct FExpressionInput Diminish; // 0x1d8(0x28)
	float ConstDiminish; // 0x200(0x04)
	float Scale; // 0x204(0x04)
	bool bTurbulence; // 0x208(0x01)
	char pad_209[0x3]; // 0x209(0x03)
	int32_t Levels; // 0x20c(0x04)
	float OutputMin; // 0x210(0x04)
	float OutputMax; // 0x214(0x04)
	char pad_218[0x8]; // 0x218(0x08)
};

// Class InterchangeImport.MaterialExpressionMaterialXIn
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXIn : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXLuminance
// Size: 0x160 (Inherited: 0x120)
struct UMaterialExpressionMaterialXLuminance : UMaterialExpression {
	struct FExpressionInput Input; // 0x120(0x28)
	struct FLinearColor LuminanceFactors; // 0x148(0x10)
	enum class EMaterialXLuminanceMode LuminanceMode; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
};

// Class InterchangeImport.MaterialExpressionMaterialXMask
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXMask : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXMatte
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXMatte : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXMinus
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXMinus : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXOut
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXOut : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXOver
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXOver : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXOverlay
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXOverlay : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXPlace2D
// Size: 0x1f0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXPlace2D : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x120(0x28)
	struct FExpressionInput Pivot; // 0x148(0x28)
	struct FExpressionInput Scale; // 0x170(0x28)
	struct FExpressionInput Offset; // 0x198(0x28)
	struct FExpressionInput RotationAngle; // 0x1c0(0x28)
	float ConstRotationAngle; // 0x1e8(0x04)
	char ConstCoordinate; // 0x1ec(0x01)
	char pad_1ed[0x3]; // 0x1ed(0x03)
};

// Class InterchangeImport.MaterialExpressionMaterialXPlus
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXPlus : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXPremult
// Size: 0x150 (Inherited: 0x120)
struct UMaterialExpressionMaterialXPremult : UMaterialExpression {
	struct FExpressionInput Input; // 0x120(0x28)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class InterchangeImport.MaterialExpressionMaterialXRampLeftRight
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXRampLeftRight : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x120(0x28)
	struct FExpressionInput A; // 0x148(0x28)
	struct FExpressionInput B; // 0x170(0x28)
	char ConstCoordinate; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
};

// Class InterchangeImport.MaterialExpressionMaterialXRampTopBottom
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXRampTopBottom : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x120(0x28)
	struct FExpressionInput A; // 0x148(0x28)
	struct FExpressionInput B; // 0x170(0x28)
	char ConstCoordinate; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
};

// Class InterchangeImport.MaterialExpressionMaterialXRemap
// Size: 0x200 (Inherited: 0x120)
struct UMaterialExpressionMaterialXRemap : UMaterialExpression {
	struct FExpressionInput Input; // 0x120(0x28)
	struct FExpressionInput InputLow; // 0x148(0x28)
	struct FExpressionInput InputHigh; // 0x170(0x28)
	struct FExpressionInput TargetLow; // 0x198(0x28)
	struct FExpressionInput TargetHigh; // 0x1c0(0x28)
	float InputLowDefault; // 0x1e8(0x04)
	float InputHighDefault; // 0x1ec(0x04)
	float TargetLowDefault; // 0x1f0(0x04)
	float TargetHighDefault; // 0x1f4(0x04)
	char pad_1f8[0x8]; // 0x1f8(0x08)
};

// Class InterchangeImport.MaterialExpressionMaterialXRotate2D
// Size: 0x180 (Inherited: 0x120)
struct UMaterialExpressionMaterialXRotate2D : UMaterialExpression {
	struct FExpressionInput Input; // 0x120(0x28)
	struct FExpressionInput RotationAngle; // 0x148(0x28)
	float ConstRotationAngle; // 0x170(0x04)
	char pad_174[0xc]; // 0x174(0x0c)
};

// Class InterchangeImport.MaterialExpressionMaterialXScreen
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXScreen : UMaterialExpression {
	struct FExpressionInput A; // 0x120(0x28)
	struct FExpressionInput B; // 0x148(0x28)
	struct FExpressionInput Alpha; // 0x170(0x28)
	float ConstAlpha; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
};

// Class InterchangeImport.MaterialExpressionMaterialXSplitLeftRight
// Size: 0x1d0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXSplitLeftRight : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x120(0x28)
	struct FExpressionInput A; // 0x148(0x28)
	struct FExpressionInput B; // 0x170(0x28)
	struct FExpressionInput Center; // 0x198(0x28)
	float ConstCenter; // 0x1c0(0x04)
	char ConstCoordinate; // 0x1c4(0x01)
	char pad_1c5[0xb]; // 0x1c5(0x0b)
};

// Class InterchangeImport.MaterialExpressionMaterialXSplitTopBottom
// Size: 0x1d0 (Inherited: 0x120)
struct UMaterialExpressionMaterialXSplitTopBottom : UMaterialExpression {
	struct FExpressionInput Coordinates; // 0x120(0x28)
	struct FExpressionInput A; // 0x148(0x28)
	struct FExpressionInput B; // 0x170(0x28)
	struct FExpressionInput Center; // 0x198(0x28)
	float ConstCenter; // 0x1c0(0x04)
	char ConstCoordinate; // 0x1c4(0x01)
	char pad_1c5[0xb]; // 0x1c5(0x0b)
};

// Class InterchangeImport.MaterialExpressionMaterialXSwizzle
// Size: 0x160 (Inherited: 0x120)
struct UMaterialExpressionMaterialXSwizzle : UMaterialExpression {
	struct FExpressionInput Input; // 0x120(0x28)
	struct FString Channels; // 0x148(0x10)
	char pad_158[0x8]; // 0x158(0x08)
};

// Class InterchangeImport.MaterialExpressionMaterialXTextureSampleParameterBlur
// Size: 0x2c0 (Inherited: 0x2b0)
struct UMaterialExpressionMaterialXTextureSampleParameterBlur : UMaterialExpressionTextureSampleParameter2D {
	enum class EMAterialXTextureSampleBlurKernel KernelSize; // 0x2b0(0x04)
	float FilterSize; // 0x2b4(0x04)
	float FilterOffset; // 0x2b8(0x04)
	enum class EMaterialXTextureSampleBlurFilter Filter; // 0x2bc(0x01)
	char pad_2bd[0x3]; // 0x2bd(0x03)
};

// Class InterchangeImport.MaterialExpressionMaterialXUnpremult
// Size: 0x150 (Inherited: 0x120)
struct UMaterialExpressionMaterialXUnpremult : UMaterialExpression {
	struct FExpressionInput Input; // 0x120(0x28)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class InterchangeImport.InterchangeMaterialFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UInterchangeMaterialFactory : UInterchangeFactoryBase {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class InterchangeImport.InterchangeMaterialFunctionFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UInterchangeMaterialFunctionFactory : UInterchangeFactoryBase {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class InterchangeImport.InterchangeOBJTranslator
// Size: 0xc0 (Inherited: 0xb0)
struct UInterchangeOBJTranslator : UInterchangeTranslatorBase {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class InterchangeImport.InterchangePhysicsAssetFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangePhysicsAssetFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeSkeletalMeshFactory
// Size: 0xd0 (Inherited: 0xa0)
struct UInterchangeSkeletalMeshFactory : UInterchangeFactoryBase {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class InterchangeImport.InterchangeSkeletonFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeSkeletonFactory : UInterchangeFactoryBase {
};

// Class InterchangeImport.InterchangeStaticMeshFactory
// Size: 0xc0 (Inherited: 0xa0)
struct UInterchangeStaticMeshFactory : UInterchangeFactoryBase {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class InterchangeImport.InterchangeCineCameraActorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeCineCameraActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeCameraActorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeCameraActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeSkeletalMeshActorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeSkeletalMeshActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeStaticMeshActorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeStaticMeshActorFactory : UInterchangeActorFactory {
};

// Class InterchangeImport.InterchangeDDSTranslator
// Size: 0xc0 (Inherited: 0xb0)
struct UInterchangeDDSTranslator : UInterchangeTranslatorBase {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class InterchangeImport.InterchangeIESTranslator
// Size: 0xb0 (Inherited: 0xb0)
struct UInterchangeIESTranslator : UInterchangeTranslatorBase {
};

// Class InterchangeImport.InterchangeImageWrapperTranslator
// Size: 0xc0 (Inherited: 0xb0)
struct UInterchangeImageWrapperTranslator : UInterchangeTranslatorBase {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class InterchangeImport.InterchangeJPGTranslator
// Size: 0xb0 (Inherited: 0xb0)
struct UInterchangeJPGTranslator : UInterchangeTranslatorBase {
};

// Class InterchangeImport.InterchangePCXTranslator
// Size: 0xb0 (Inherited: 0xb0)
struct UInterchangePCXTranslator : UInterchangeTranslatorBase {
};

// Class InterchangeImport.InterchangePSDTranslator
// Size: 0xb0 (Inherited: 0xb0)
struct UInterchangePSDTranslator : UInterchangeTranslatorBase {
};

// Class InterchangeImport.InterchangeTextureFactory
// Size: 0x130 (Inherited: 0xa0)
struct UInterchangeTextureFactory : UInterchangeFactoryBase {
	char pad_a0[0x90]; // 0xa0(0x90)
};

