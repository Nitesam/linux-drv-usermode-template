// Class HiveInference.MLInferenceSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UMLInferenceSubsystem : UWorldSubsystem {

	void UnregisterAgent(struct FAgentIdentity Identity); // Function HiveInference.MLInferenceSubsystem.UnregisterAgent // (Final|Native|Public) // @ game+0x9050c80
	struct FAgentIdentity RegisterAgent(struct FName ModelType, int32_t ServerId); // Function HiveInference.MLInferenceSubsystem.RegisterAgent // (Final|Native|Public) // @ game+0x9051270
	void Push(struct FAgentIdentity Identity, struct FMLInferenceInput& Input); // Function HiveInference.MLInferenceSubsystem.Push // (Final|Native|Public|HasOutParms) // @ game+0x9050aa0
	bool Pull(struct FAgentIdentity Identity, struct FMLInferenceOutput& OutResponse); // Function HiveInference.MLInferenceSubsystem.Pull // (Final|Native|Public|HasOutParms) // @ game+0x90504d0
	void LoadModel(struct FName ModelName, struct TArray<char>& ModelData, struct FModelInfo& ModelInfo); // Function HiveInference.MLInferenceSubsystem.LoadModel // (Final|Native|Public|HasOutParms) // @ game+0x9050fd0
	void Dispatch(struct FName ModelName); // Function HiveInference.MLInferenceSubsystem.Dispatch // (Final|Native|Public) // @ game+0x5d5b910
	void CollectBlocking(struct FName ModelName); // Function HiveInference.MLInferenceSubsystem.CollectBlocking // (Final|Native|Public) // @ game+0x5d5b910
	void Collect(struct FName ModelName); // Function HiveInference.MLInferenceSubsystem.Collect // (Final|Native|Public) // @ game+0x5d5b910
};

