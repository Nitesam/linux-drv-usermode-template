// Enum StreamlineBlueprint.EStreamlineFeature
enum class EStreamlineFeature : uint8_t {
	DLSSG = 0,
	Latewarp = 1,
	Reflex = 2,
	DeepDVC = 3,
	Count = 4,
	EStreamlineFeature_MAX = 5
};

// Enum StreamlineBlueprint.EStreamlineFeatureSupport
enum class EStreamlineFeatureSupport : uint8_t {
	Supported = 0,
	NotSupported = 1,
	NotSupportedIncompatibleHardware = 2,
	NotSupportedDriverOutOfDate = 3,
	NotSupportedOperatingSystemOutOfDate = 4,
	NotSupportedHardewareSchedulingDisabled = 5,
	NotSupportedByRHI = 6,
	NotSupportedByPlatformAtBuildTime = 7,
	NotSupportedIncompatibleAPICaptureToolActive = 8,
	EStreamlineFeatureSupport_MAX = 9
};

// Enum StreamlineBlueprint.EStreamlineFeatureRequirementsFlags
enum class EStreamlineFeatureRequirementsFlags : uint8_t {
	None = 0,
	D3D11Supported = 1,
	D3D12Supported = 2,
	VulkanSupported = 4,
	VSyncOffRequired = 8,
	HardwareSchedulingRequired = 16,
	EStreamlineFeatureRequirementsFlags_MAX = 17
};

// ScriptStruct StreamlineBlueprint.StreamlineVersion
// Size: 0x0c (Inherited: 0x00)
struct FStreamlineVersion {
	int32_t Major; // 0x00(0x04)
	int32_t Minor; // 0x04(0x04)
	int32_t Build; // 0x08(0x04)
};

// ScriptStruct StreamlineBlueprint.StreamlineFeatureRequirements
// Size: 0x34 (Inherited: 0x00)
struct FStreamlineFeatureRequirements {
	enum class EStreamlineFeatureSupport Support; // 0x00(0x01)
	enum class EStreamlineFeatureRequirementsFlags Requirements; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	struct FStreamlineVersion RequiredOperatingSystemVersion; // 0x04(0x0c)
	struct FStreamlineVersion DetectedOperatingSystemVersion; // 0x10(0x0c)
	struct FStreamlineVersion RequiredDriverVersion; // 0x1c(0x0c)
	struct FStreamlineVersion DetectedDriverVersion; // 0x28(0x0c)
};

