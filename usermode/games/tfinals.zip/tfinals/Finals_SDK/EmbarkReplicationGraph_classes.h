// Class EmbarkReplicationGraph.ReplicationGraphNode_AlwaysRelevantObjects
// Size: 0xd0 (Inherited: 0xc0)
struct UReplicationGraphNode_AlwaysRelevantObjects : UReplicationGraphNode {
	struct UReplicationGraphNode* ChildNode; // 0xc0(0x08)
	struct UReplicationGraphNode_DormancyNode* DormancyNode; // 0xc8(0x08)
};

// Class EmbarkReplicationGraph.EmbarkNetReplicationGraphConnection
// Size: 0x400 (Inherited: 0x3f0)
struct UEmbarkNetReplicationGraphConnection : UNetReplicationGraphConnection {
	struct TArray<struct FEmbarkSortedActorReplicationEntry> LastFrameSortedActorInfosScaleInfos; // 0x3e8(0x10)
};

// Class EmbarkReplicationGraph.EmbarkReplicationGraph
// Size: 0x750 (Inherited: 0x5e0)
struct UEmbarkReplicationGraph : UReplicationGraph {
	char pad_5e0[0xb0]; // 0x5e0(0xb0)
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // 0x690(0x08)
	struct UReplicationGraphNode_AlwaysRelevantObjects* AlwaysRelevantNode; // 0x698(0x08)
	struct TArray<struct FConnectionAlwaysRelevantPair> AlwaysRelevantForConnectionList; // 0x6a0(0x10)
	struct TArray<struct AActor*> ActorsWithoutNetConnection; // 0x6b0(0x10)
	struct TArray<struct AActor*> ScalableActors; // 0x6c0(0x10)
	struct UEmbarkReplicationGraphSettingsDataAsset* SettingsDataAsset; // 0x6d0(0x08)
	char pad_6d8[0x20]; // 0x6d8(0x20)
	struct TMap<struct UObject*, struct FEmbarkSortedRelevantActorsArrayWrapperEntry> ReplicationActorsToBeSortedByClass; // 0x6f8(0x50)
	char pad_748[0x8]; // 0x748(0x08)
};

// Class EmbarkReplicationGraph.EmbarkReplicationGraphSettingsDataAsset
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkReplicationGraphSettingsDataAsset : UDataAsset {
	double MaxConnectionReplicationFrameTime; // 0xa0(0x08)
	double MaxConnectionReplicationFrameTimeModifierForFirstConnection; // 0xa8(0x08)
	double MaxAckTimeBeforeReplicationStops; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class EmbarkReplicationGraph.EmbarkReplicationGraphSettings
// Size: 0xd0 (Inherited: 0xb0)
struct UEmbarkReplicationGraphSettings : UDeveloperSettings {
	struct TSoftObjectPtr<UEmbarkReplicationGraphSettingsDataAsset> SettingsDataAsset; // 0xa8(0x28)
};

// Class EmbarkReplicationGraph.EmbarkReplicationGraphStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkReplicationGraphStatics : UBlueprintFunctionLibrary {

	void SetReplicationEnabledForActorOnConnection(struct APlayerController* PlayerController, struct AActor* Actor, bool bShouldReplicate); // Function EmbarkReplicationGraph.EmbarkReplicationGraphStatics.SetReplicationEnabledForActorOnConnection // (Final|Native|Static|Public) // @ game+0x5a04780
	void RerouteNetworkActorInRepGraph(struct AActor* Actor); // Function EmbarkReplicationGraph.EmbarkReplicationGraphStatics.RerouteNetworkActorInRepGraph // (Final|Native|Static|Public) // @ game+0x59fd5a0
	void RemoveDependentActor_Server(struct AActor* Parent, struct AActor* Child, struct UObject* WorldContextObject); // Function EmbarkReplicationGraph.EmbarkReplicationGraphStatics.RemoveDependentActor_Server // (Final|Native|Static|Public) // @ game+0x59ff810
	struct TArray<struct FEmbarkSortedActorReplicationEntry> GetLastFrameSortedReplicationEntries(struct APlayerController* InRelevantController); // Function EmbarkReplicationGraph.EmbarkReplicationGraphStatics.GetLastFrameSortedReplicationEntries // (Final|Native|Static|Public) // @ game+0x5a07270
	void AddDependentActor_Server(struct AActor* Parent, struct AActor* Child, struct UObject* WorldContextObject); // Function EmbarkReplicationGraph.EmbarkReplicationGraphStatics.AddDependentActor_Server // (Final|Native|Static|Public) // @ game+0x59fea70
};

// Class EmbarkReplicationGraph.PioneerReplicationGraph
// Size: 0x750 (Inherited: 0x750)
struct UPioneerReplicationGraph : UEmbarkReplicationGraph {
};

// Class EmbarkReplicationGraph.ReplicationSettingsComponent
// Size: 0x170 (Inherited: 0x160)
struct UReplicationSettingsComponent : UActorComponent {
	char bEnableReplicationRateScaling : 1; // 0x158(0x01)
	char bEnableSortedActorRateScaling : 1; // 0x158(0x01)
	float NetFrequencyScalingStart; // 0x15c(0x04)
	float NetFrequencyScalingEnd; // 0x160(0x04)
	float DistancePriorityScale; // 0x164(0x04)
	int32_t ActorChannelFrameTimeout; // 0x168(0x04)
};

