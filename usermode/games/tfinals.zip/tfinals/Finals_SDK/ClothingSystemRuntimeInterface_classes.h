// Class ClothingSystemRuntimeInterface.ClothingAssetBase
// Size: 0xd0 (Inherited: 0xa0)
struct UClothingAssetBase : UObject {
	struct FString ImportedFilePath; // 0x98(0x10)
	struct FGuid AssetGuid; // 0xa8(0x10)
	struct FGuid OriginalAssetGuid; // 0xb8(0x10)
};

// Class ClothingSystemRuntimeInterface.ClothConfigBase
// Size: 0xa0 (Inherited: 0xa0)
struct UClothConfigBase : UObject {
};

// Class ClothingSystemRuntimeInterface.ClothSharedSimConfigBase
// Size: 0xa0 (Inherited: 0xa0)
struct UClothSharedSimConfigBase : UObject {
};

// Class ClothingSystemRuntimeInterface.ClothingSimulationFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UClothingSimulationFactory : UObject {
};

// Class ClothingSystemRuntimeInterface.ClothingInteractor
// Size: 0xa0 (Inherited: 0xa0)
struct UClothingInteractor : UObject {
};

// Class ClothingSystemRuntimeInterface.ClothingSimulationInteractor
// Size: 0x100 (Inherited: 0xa0)
struct UClothingSimulationInteractor : UObject {
	struct TMap<struct FName, struct UClothingInteractor*> ClothingInteractors; // 0x98(0x50)
	char pad_f0[0x10]; // 0xf0(0x10)

	void SetNumSubsteps(int32_t NumSubsteps); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetNumSubsteps // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x1703770
	void SetNumIterations(int32_t NumIterations); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetNumIterations // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x1703300
	void SetMaxNumIterations(int32_t MaxNumIterations); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetMaxNumIterations // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x16fdb50
	void SetAnimDriveSpringStiffness(float InStiffness); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.SetAnimDriveSpringStiffness // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x1703810
	void PhysicsAssetUpdated(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.PhysicsAssetUpdated // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x17031b0
	float GetSimulationTime(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetSimulationTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x17036c0
	int32_t GetNumSubsteps(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumSubsteps // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x16fe370
	int32_t GetNumKinematicParticles(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumKinematicParticles // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1703aa0
	int32_t GetNumIterations(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumIterations // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x16ff5b0
	int32_t GetNumDynamicParticles(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumDynamicParticles // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x17033a0
	int32_t GetNumCloths(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetNumCloths // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1700c90
	struct UClothingInteractor* GetClothingInteractor(struct FString ClothingAssetName); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.GetClothingInteractor // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1700520
	void EnableGravityOverride(struct FVector& InVector); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.EnableGravityOverride // (RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x16feb90
	void DisableGravityOverride(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.DisableGravityOverride // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x16fe6f0
	void ClothConfigUpdated(); // Function ClothingSystemRuntimeInterface.ClothingSimulationInteractor.ClothConfigUpdated // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x16fe8b0
};

// Class ClothingSystemRuntimeInterface.ClothPhysicalMeshDataBase_Legacy
// Size: 0x150 (Inherited: 0xa0)
struct UClothPhysicalMeshDataBase_Legacy : UObject {
	struct TArray<struct FVector3f> Vertices; // 0x98(0x10)
	struct TArray<struct FVector3f> Normals; // 0xa8(0x10)
	struct TArray<uint32_t> Indices; // 0xb8(0x10)
	struct TArray<float> InverseMasses; // 0xc8(0x10)
	struct TArray<struct FClothVertBoneData> BoneData; // 0xd8(0x10)
	int32_t NumFixedVerts; // 0xe8(0x04)
	int32_t MaxBoneWeights; // 0xec(0x04)
	struct TArray<uint32_t> SelfCollisionIndices; // 0xf0(0x10)
	char pad_108[0x48]; // 0x108(0x48)
};

