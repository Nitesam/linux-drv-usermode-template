// Class MovieRenderPipelineRenderPasses.MoviePipelineImagePassBase
// Size: 0x1f0 (Inherited: 0xc0)
struct UMoviePipelineImagePassBase : UMoviePipelineRenderPass {
	char pad_c0[0x130]; // 0xc0(0x130)
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPassBase
// Size: 0x2b0 (Inherited: 0x1f0)
struct UMoviePipelineDeferredPassBase : UMoviePipelineImagePassBase {
	bool bAccumulatorIncludesAlpha; // 0x1e8(0x01)
	bool bDisableMultisampleEffects; // 0x1e9(0x01)
	bool bUse32BitPostProcessMaterials; // 0x1ea(0x01)
	struct TArray<struct FMoviePipelinePostProcessPass> AdditionalPostProcessMaterials; // 0x1f0(0x10)
	bool bRenderMainPass; // 0x200(0x01)
	bool bAddDefaultLayer; // 0x201(0x01)
	char pad_205[0x3]; // 0x205(0x03)
	struct TArray<struct FActorLayer> ActorLayers; // 0x208(0x10)
	char pad_218[0x10]; // 0x218(0x10)
	struct TArray<struct FSoftObjectPath> DataLayers; // 0x228(0x10)
	struct TArray<struct UMaterialInterface*> ActivePostProcessMaterials; // 0x238(0x10)
	struct UMaterialInterface* StencilLayerMaterial; // 0x248(0x08)
	char pad_250[0x60]; // 0x250(0x60)
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_Unlit
// Size: 0x2b0 (Inherited: 0x2b0)
struct UMoviePipelineDeferredPass_Unlit : UMoviePipelineDeferredPassBase {
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_DetailLighting
// Size: 0x2b0 (Inherited: 0x2b0)
struct UMoviePipelineDeferredPass_DetailLighting : UMoviePipelineDeferredPassBase {
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_LightingOnly
// Size: 0x2b0 (Inherited: 0x2b0)
struct UMoviePipelineDeferredPass_LightingOnly : UMoviePipelineDeferredPassBase {
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_ReflectionsOnly
// Size: 0x2b0 (Inherited: 0x2b0)
struct UMoviePipelineDeferredPass_ReflectionsOnly : UMoviePipelineDeferredPassBase {
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineDeferredPass_PathTracer
// Size: 0x2b0 (Inherited: 0x2b0)
struct UMoviePipelineDeferredPass_PathTracer : UMoviePipelineDeferredPassBase {
	bool bReferenceMotionBlur; // 0x2a8(0x01)
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutputBase
// Size: 0xe0 (Inherited: 0xc0)
struct UMoviePipelineImageSequenceOutputBase : UMoviePipelineOutputBase {
	char pad_c0[0x20]; // 0xc0(0x20)
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_EXR
// Size: 0xe0 (Inherited: 0xe0)
struct UMoviePipelineImageSequenceOutput_EXR : UMoviePipelineImageSequenceOutputBase {
	enum class EEXRCompressionFormat Compression; // 0xd8(0x01)
	bool bMultilayer; // 0xd9(0x01)
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_BMP
// Size: 0xe0 (Inherited: 0xe0)
struct UMoviePipelineImageSequenceOutput_BMP : UMoviePipelineImageSequenceOutputBase {
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_PNG
// Size: 0xe0 (Inherited: 0xe0)
struct UMoviePipelineImageSequenceOutput_PNG : UMoviePipelineImageSequenceOutputBase {
	bool bWriteAlpha; // 0xd8(0x01)
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_JPG
// Size: 0xe0 (Inherited: 0xe0)
struct UMoviePipelineImageSequenceOutput_JPG : UMoviePipelineImageSequenceOutputBase {
};

// Class MovieRenderPipelineRenderPasses.MoviePipelineWaveOutput
// Size: 0x130 (Inherited: 0xc0)
struct UMoviePipelineWaveOutput : UMoviePipelineOutputBase {
	struct FString FileNameFormatOverride; // 0xb8(0x10)
	char pad_d0[0x60]; // 0xd0(0x60)
};

