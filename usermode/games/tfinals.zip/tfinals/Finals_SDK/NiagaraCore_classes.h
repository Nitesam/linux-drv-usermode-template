// Class NiagaraCore.NiagaraMergeable
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraMergeable : UObject {
};

// Class NiagaraCore.NiagaraDataInterfaceBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraDataInterfaceBase : UNiagaraMergeable {
};

