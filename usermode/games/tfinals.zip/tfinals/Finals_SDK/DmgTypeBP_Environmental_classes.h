// BlueprintGeneratedClass DmgTypeBP_Environmental.DmgTypeBP_Environmental_C
// Size: 0xb0 (Inherited: 0xb0)
struct UDmgTypeBP_Environmental_C : UDamageType {
};

