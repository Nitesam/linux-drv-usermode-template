// Enum EmbarkSynthesis.EEmbarkAudioNoiseType
enum class EEmbarkAudioNoiseType : uint8_t {
	White = 0,
	Pink = 1,
	Pulse = 2,
	EEmbarkAudioNoiseType_MAX = 3
};

// ScriptStruct EmbarkSynthesis.SourceEffectAdaptiveNoiseSettings
// Size: 0x1c (Inherited: 0x00)
struct FSourceEffectAdaptiveNoiseSettings {
	enum class EEmbarkAudioNoiseType NoiseType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float NoiseLevel; // 0x04(0x04)
	float GateLevel; // 0x08(0x04)
	bool bInverseGate; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	float AttackTime; // 0x10(0x04)
	float DecayTime; // 0x14(0x04)
	float ToneControl; // 0x18(0x04)
};

// ScriptStruct EmbarkSynthesis.SourceEffectBounceCombSettings
// Size: 0x10 (Inherited: 0x00)
struct FSourceEffectBounceCombSettings {
	float DryAmount; // 0x00(0x04)
	float WetAmount; // 0x04(0x04)
	float FilterFrequency; // 0x08(0x04)
	float GroundHeight; // 0x0c(0x04)
};

// ScriptStruct EmbarkSynthesis.SourceEffectMultiChDelaySettings
// Size: 0x24 (Inherited: 0x00)
struct FSourceEffectMultiChDelaySettings {
	float Delay; // 0x00(0x04)
	float DelayGain; // 0x04(0x04)
	float DirectGain; // 0x08(0x04)
	float DelayInterpolationTime; // 0x0c(0x04)
	float DelayInterpolationRate; // 0x10(0x04)
	float GainInterpolationTime; // 0x14(0x04)
	float GainInterpolationRate; // 0x18(0x04)
	bool bEnableLPF; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
	float CutoffFrequency; // 0x20(0x04)
};

// ScriptStruct EmbarkSynthesis.SourceEffectRadioStaticSettings
// Size: 0xd8 (Inherited: 0x00)
struct FSourceEffectRadioStaticSettings {
	float SignalStrength; // 0x00(0x04)
	float DryAmp; // 0x04(0x04)
	struct FVector2D DrySignalStrengthInputRange; // 0x08(0x10)
	struct FVector2D DrySignalStrengthOutputRange; // 0x18(0x10)
	struct FVector2D DrySignalStrengthLPFrequencyInputRange; // 0x28(0x10)
	struct FVector2D DrySignalStrengthLPFrequencyOutputRange; // 0x38(0x10)
	float ModulatedNoiseAmp; // 0x48(0x04)
	char pad_4c[0x4]; // 0x4c(0x04)
	struct FVector2D ModulatedNoiseSignalStrengthInputRange; // 0x50(0x10)
	struct FVector2D ModulatedNoiseSignalStrengthOutputRange; // 0x60(0x10)
	float StaticNoiseAmp; // 0x70(0x04)
	float NoiseLPFilterFrequency; // 0x74(0x04)
	float NoiseHPFilterFrequency; // 0x78(0x04)
	float NoisePeakFilterFreq; // 0x7c(0x04)
	float NoisePeakFilterGain; // 0x80(0x04)
	float NoiseEnvelopeAttackTime; // 0x84(0x04)
	float NoiseEnvelopeReleaseTime; // 0x88(0x04)
	char pad_8c[0x4]; // 0x8c(0x04)
	struct FVector2D NoiseEnvelopeSensitivityInputRange; // 0x90(0x10)
	struct FVector2D NoiseEnvelopeSensitivityOutputRange; // 0xa0(0x10)
	bool bUseDistanceToListener; // 0xb0(0x01)
	char pad_b1[0x7]; // 0xb1(0x07)
	struct FVector2D DistanceSignalStrengthInputRange; // 0xb8(0x10)
	struct FVector2D DistanceSignalStrengthOutputRange; // 0xc8(0x10)
};

// ScriptStruct EmbarkSynthesis.SourceEffectSimpleCompressorSettings
// Size: 0x20 (Inherited: 0x00)
struct FSourceEffectSimpleCompressorSettings {
	float Threshold; // 0x00(0x04)
	float Ratio; // 0x04(0x04)
	float AttackTime; // 0x08(0x04)
	float ReleaseTime; // 0x0c(0x04)
	float InputGain; // 0x10(0x04)
	bool bEnableFilters; // 0x14(0x01)
	bool bFilterControlSignalOnly; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	float HPFCutoff; // 0x18(0x04)
	float LPFCutoff; // 0x1c(0x04)
};

// ScriptStruct EmbarkSynthesis.SourceEffectSoftDistortionSettings
// Size: 0x14 (Inherited: 0x00)
struct FSourceEffectSoftDistortionSettings {
	float BitCrush; // 0x00(0x04)
	float RateCrush; // 0x04(0x04)
	float Overdrive; // 0x08(0x04)
	float Traffo; // 0x0c(0x04)
	float Tube; // 0x10(0x04)
};

// ScriptStruct EmbarkSynthesis.SourceEffectTransientShaperSettings
// Size: 0x10 (Inherited: 0x00)
struct FSourceEffectTransientShaperSettings {
	float Attack; // 0x00(0x04)
	float Decay; // 0x04(0x04)
	float FocusFrequency; // 0x08(0x04)
	float ClipLevel; // 0x0c(0x04)
};

// ScriptStruct EmbarkSynthesis.SourceEffectTunedResonatorSettings
// Size: 0x14 (Inherited: 0x00)
struct FSourceEffectTunedResonatorSettings {
	float Decay; // 0x00(0x04)
	float Dampening; // 0x04(0x04)
	float Softening; // 0x08(0x04)
	float Level; // 0x0c(0x04)
	float MasterTuning; // 0x10(0x04)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectAdaptiveNoiseSettings
// Size: 0x1c (Inherited: 0x00)
struct FSubmixEffectAdaptiveNoiseSettings {
	enum class EEmbarkAudioNoiseType NoiseType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float NoiseLevel; // 0x04(0x04)
	float GateLevel; // 0x08(0x04)
	bool bInverseGate; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	float AttackTime; // 0x10(0x04)
	float DecayTime; // 0x14(0x04)
	float ToneControl; // 0x18(0x04)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectMultiChDelaySettings
// Size: 0x24 (Inherited: 0x00)
struct FSubmixEffectMultiChDelaySettings {
	float Delay; // 0x00(0x04)
	float DelayGain; // 0x04(0x04)
	float DirectGain; // 0x08(0x04)
	float DelayInterpolationTime; // 0x0c(0x04)
	float DelayInterpolationRate; // 0x10(0x04)
	float GainInterpolationTime; // 0x14(0x04)
	float GainInterpolationRate; // 0x18(0x04)
	bool bEnableLPF; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
	float CutoffFrequency; // 0x20(0x04)
};

// ScriptStruct EmbarkSynthesis.EmbarkDelayTapSettings
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkDelayTapSettings {
	float Delay; // 0x00(0x04)
	float Gain; // 0x04(0x04)
	struct FVector Direction; // 0x08(0x18)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectMultitapDelaySettings
// Size: 0x20 (Inherited: 0x00)
struct FSubmixEffectMultitapDelaySettings {
	float DelayInterpolationTime; // 0x00(0x04)
	float DelayInterpolationRate; // 0x04(0x04)
	float GainInterpolationTime; // 0x08(0x04)
	float GainInterpolationRate; // 0x0c(0x04)
	struct TArray<struct FEmbarkDelayTapSettings> Taps; // 0x10(0x10)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectSimpleCompressorSettings
// Size: 0x20 (Inherited: 0x00)
struct FSubmixEffectSimpleCompressorSettings {
	float Threshold; // 0x00(0x04)
	float Ratio; // 0x04(0x04)
	float AttackTime; // 0x08(0x04)
	float ReleaseTime; // 0x0c(0x04)
	float InputGain; // 0x10(0x04)
	bool bEnableFilters; // 0x14(0x01)
	bool bFilterControlSignalOnly; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
	float HPFCutoff; // 0x18(0x04)
	float LPFCutoff; // 0x1c(0x04)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectSoftDistortionSettings
// Size: 0x14 (Inherited: 0x00)
struct FSubmixEffectSoftDistortionSettings {
	float BitCrush; // 0x00(0x04)
	float RateCrush; // 0x04(0x04)
	float Overdrive; // 0x08(0x04)
	float Traffo; // 0x0c(0x04)
	float Tube; // 0x10(0x04)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectTransientShaperSettings
// Size: 0x10 (Inherited: 0x00)
struct FSubmixEffectTransientShaperSettings {
	float Attack; // 0x00(0x04)
	float Decay; // 0x04(0x04)
	float FocusFrequency; // 0x08(0x04)
	float ClipLevel; // 0x0c(0x04)
};

// ScriptStruct EmbarkSynthesis.SubmixEffectTunedResonatorSettings
// Size: 0x14 (Inherited: 0x00)
struct FSubmixEffectTunedResonatorSettings {
	float Decay; // 0x00(0x04)
	float Dampening; // 0x04(0x04)
	float Softening; // 0x08(0x04)
	float Level; // 0x0c(0x04)
	float MasterTuning; // 0x10(0x04)
};

