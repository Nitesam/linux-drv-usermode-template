// Class MediaCompositing.MovieSceneMediaPlayerPropertySection
// Size: 0x170 (Inherited: 0x160)
struct UMovieSceneMediaPlayerPropertySection : UMovieSceneSection {
	struct UMediaSource* MediaSource; // 0x160(0x08)
	bool bLoop; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
};

// Class MediaCompositing.MovieSceneMediaPlayerPropertyTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneMediaPlayerPropertyTrack : UMovieScenePropertyTrack {
};

// Class MediaCompositing.MovieSceneMediaSection
// Size: 0x2c0 (Inherited: 0x160)
struct UMovieSceneMediaSection : UMovieSceneSection {
	struct UMediaSource* MediaSource; // 0x160(0x08)
	int32_t MediaSourceProxyIndex; // 0x168(0x04)
	bool bLooping; // 0x16c(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
	struct FFrameNumber StartFrameOffset; // 0x170(0x04)
	char pad_174[0x4]; // 0x174(0x04)
	struct UMediaTexture* MediaTexture; // 0x178(0x08)
	struct UMediaSoundComponent* MediaSoundComponent; // 0x180(0x08)
	bool bUseExternalMediaPlayer; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	struct UMediaPlayer* ExternalMediaPlayer; // 0x190(0x08)
	struct FMediaSourceCacheSettings CacheSettings; // 0x198(0x08)
	int32_t TextureIndex; // 0x1a0(0x04)
	bool bHasMediaPlayerProxy; // 0x1a4(0x01)
	char pad_1a5[0x3]; // 0x1a5(0x03)
	struct FMovieSceneBoolChannel ChannelCanPlayerBeOpen; // 0x1a8(0x100)
	struct FMovieSceneObjectBindingID MediaSourceProxyBindingID; // 0x2a8(0x18)
};

// Class MediaCompositing.MovieSceneMediaTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneMediaTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> MediaSections; // 0x110(0x10)
};

