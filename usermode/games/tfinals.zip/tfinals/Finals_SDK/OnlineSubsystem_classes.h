// Class OnlineSubsystem.NamedInterfaces
// Size: 0xd0 (Inherited: 0xa0)
struct UNamedInterfaces : UObject {
	struct TArray<struct FNamedInterface> NamedInterfaces; // 0x98(0x10)
	struct TArray<struct FNamedInterfaceDef> NamedInterfaceDefs; // 0xa8(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)
};

// Class OnlineSubsystem.TurnBasedMatchInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UTurnBasedMatchInterface : UInterface {

	void OnMatchReceivedTurn(struct FString Match, bool bDidBecomeActive); // Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchReceivedTurn // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnMatchEnded(struct FString Match); // Function OnlineSubsystem.TurnBasedMatchInterface.OnMatchEnded // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

