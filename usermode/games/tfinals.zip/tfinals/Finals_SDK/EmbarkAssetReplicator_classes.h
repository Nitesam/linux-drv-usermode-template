// Class EmbarkAssetReplicator.EmbarkAssetReplicatorRepositoryDataAsset
// Size: 0xcc0 (Inherited: 0xa0)
struct UEmbarkAssetReplicatorRepositoryDataAsset : UDataAsset {
	struct TArray<struct FEmbarkAssetReplicatorAssetsList> SerializedAssetsCollectionArray; // 0xa0(0x10)
	char pad_b0[0xc10]; // 0xb0(0xc10)
};

// Class EmbarkAssetReplicator.EmbarkAssetReplicatorSubsystem
// Size: 0xd0 (Inherited: 0xa0)
struct UEmbarkAssetReplicatorSubsystem : UEngineSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UEmbarkAssetReplicatorRepositoryDataAsset* Repository; // 0xb0(0x08)
	struct UAssetManager* AssetManager; // 0xb8(0x08)
	char pad_c0[0x10]; // 0xc0(0x10)
};

