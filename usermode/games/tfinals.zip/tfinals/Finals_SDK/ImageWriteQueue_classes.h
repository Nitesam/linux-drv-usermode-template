// Class ImageWriteQueue.ImageWriteBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UImageWriteBlueprintLibrary : UBlueprintFunctionLibrary {

	void ExportToDisk(struct UTexture* Texture, struct FString Filename, struct FImageWriteOptions& Options); // Function ImageWriteQueue.ImageWriteBlueprintLibrary.ExportToDisk // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x1715970
};

