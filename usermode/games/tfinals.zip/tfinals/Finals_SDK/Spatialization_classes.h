// Class Spatialization.ITDSpatializationSourceSettings
// Size: 0x130 (Inherited: 0xa0)
struct UITDSpatializationSourceSettings : USpatializationPluginSourceSettingsBase {
	bool bEnableILD; // 0x98(0x01)
	struct FRuntimeFloatCurve PanningIntensityOverDistance; // 0xa0(0x88)
	char pad_129[0x7]; // 0x129(0x07)
};

