// Class PendulumRuntime.PendulumAutobotUpdateComponent
// Size: 0x15040 (Inherited: 0x160)
struct UPendulumAutobotUpdateComponent : UActorComponent {
	struct UPendulumDataContainer* InputGenerationLogicData; // 0x158(0x08)
	char pad_168[0x14ed8]; // 0x168(0x14ed8)

	void PostInputTick(float DeltaSeconds); // Function PendulumRuntime.PendulumAutobotUpdateComponent.PostInputTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5f7f840
	void InitializePendulumBlackBoards(struct AActor* OwnerActor); // Function PendulumRuntime.PendulumAutobotUpdateComponent.InitializePendulumBlackBoards // (Final|Native|Public|BlueprintCallable) // @ game+0x5f82d60
};

// Class PendulumRuntime.SystemCameraParametersNode
// Size: 0x100 (Inherited: 0xa0)
struct USystemCameraParametersNode : USimBaseClass {
	struct FABBHighCompressedWorldTransform WorldTransform; // 0xa0(0x60)
};

// Class PendulumRuntime.PendulumSimulationFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumSimulationFunctionLibrary : UBlueprintFunctionLibrary {

	int32_t ToTick(float Time); // Function PendulumRuntime.PendulumSimulationFunctionLibrary.ToTick // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5f7e480
	void SimulateDeadCharacter(struct AActor* Actor, float& TimeSinceUpdate, float DeltaSeconds); // Function PendulumRuntime.PendulumSimulationFunctionLibrary.SimulateDeadCharacter // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5f7c0a0
	float GetTickInterval(); // Function PendulumRuntime.PendulumSimulationFunctionLibrary.GetTickInterval // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5f81ab0
	float FromTick(int32_t PendulumTick); // Function PendulumRuntime.PendulumSimulationFunctionLibrary.FromTick // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5f7e800
};

// Class PendulumRuntime.EmbarkBlackBoardCorrectionComponent
// Size: 0x87c0 (Inherited: 0x160)
struct UEmbarkBlackBoardCorrectionComponent : UActorComponent {
	struct UPendulumDataContainer* InputGenerationLogicData; // 0x158(0x08)
	char pad_168[0x18]; // 0x168(0x18)
	struct UEmbarkInputSubsystem* InputSubSystem; // 0x180(0x08)
	struct UDirectReplicationWrapperComponent* DirectReplicationWrapperComp; // 0x188(0x08)
	int32_t RepServerProcessedLatestInputFrame; // 0x190(0x04)
	bool bHandleClientSideCameraTransforms; // 0x194(0x01)
	char pad_195[0x862b]; // 0x195(0x862b)

	void ServerStartRecordHistory(); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.ServerStartRecordHistory // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x3a6dae0
	void ServerSaveHistory(); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.ServerSaveHistory // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x36ad7d0
	void PostInputTick(float DeltaSeconds); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.PostInputTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5f80f60
	void InitializePendulumBlackBoards(struct AActor* OwnerActor); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.InitializePendulumBlackBoards // (Final|Native|Public|BlueprintCallable) // @ game+0x5f7fd40
	struct UObject* GetFirstInputStateOfTypeFromBlackBoard(struct UObject* Class); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.GetFirstInputStateOfTypeFromBlackBoard // (Final|Native|Public) // @ game+0x5f7e750
	void FillInInputToContext(struct FPendulumExecutionContext& SimulationContext); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.FillInInputToContext // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f79310
	void FillInExecutionContexts(struct FPendulumExecutionContext& PresentationContext, struct FPendulumExecutionContext& SimulationContext); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.FillInExecutionContexts // (Final|Native|Public|HasOutParms) // @ game+0x5f81850
	void DebugSkipSendingInput(int32_t Times); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.DebugSkipSendingInput // (Final|Native|Public) // @ game+0x5f7c2d0
	void DebugSkipExecutingInput(float Time); // Function PendulumRuntime.EmbarkBlackBoardCorrectionComponent.DebugSkipExecutingInput // (Net|Native|Event|Public|NetServer) // @ game+0x3f69ce0
};

// Class PendulumRuntime.PendulumBaseNodeData
// Size: 0xc0 (Inherited: 0xa0)
struct UPendulumBaseNodeData : UObject {
	int32_t DataIndex; // 0x98(0x04)
	bool CallBlueprintSimUpdate; // 0x9c(0x01)
	bool bCallBlueprintAnimTreeUpdate; // 0x9d(0x01)
	bool CallBlueprintInit; // 0x9e(0x01)
	bool CallBlueprintRemove; // 0x9f(0x01)
	bool bCallBlueprintSyncWithGameAssets; // 0xa0(0x01)
	bool bCallBlueprintSyncWorldStateToInput; // 0xa1(0x01)
	char pad_aa[0x6]; // 0xaa(0x06)
	struct FSequencedResultStateChanges SequencedResultChanges; // 0xb0(0x10)

	void SyncWorldStateToInputBP(struct UPendulumBaseNode* InputNode, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNodeData.SyncWorldStateToInputBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void SyncWithGameAssetsBP(struct UPendulumBaseNode* RuntimeNode, bool bSyncTo, struct AActor* Actor, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNodeData.SyncWithGameAssetsBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void SimUpdateBP(struct FSimUpdateInput& Inp, struct UPendulumBaseNode* NodeState, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumBaseNodeData.SimUpdateBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	struct UObject* RuntimeClass(); // Function PendulumRuntime.PendulumBaseNodeData.RuntimeClass // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2db2d70
	void OnRemoveBP(struct UPendulumBaseNode* RuntimeNode, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNodeData.OnRemoveBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void InitSpecificBP(struct FSimUpdateInput& Inp, struct UPendulumBaseNode* NodeState, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNodeData.InitSpecificBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void InitNode(struct FSimUpdateInput& Inp, struct UPendulumBaseNode* RuntimeNode, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNodeData.InitNode // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f86a20
	void DebugPrintLogicTree(struct FSimUpdateInput& Inp, struct UPendulumBaseNode* NodeState, struct FPendulumDebugContext& Cont, struct FString& Str, struct FString& IndentStr); // Function PendulumRuntime.PendulumBaseNodeData.DebugPrintLogicTree // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5f83190
	void AnimTreeUpdateBP(struct FAnimUpdateInput& Inp, struct UPendulumBaseNode* NodeState, struct FPendulumAnimationUpdateContext& Cont, struct FAnimEvaluateResult& Result); // Function PendulumRuntime.PendulumBaseNodeData.AnimTreeUpdateBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class PendulumRuntime.PendulumSMStateNodeData
// Size: 0xe0 (Inherited: 0xc0)
struct UPendulumSMStateNodeData : UPendulumBaseNodeData {
	struct UPendulumBaseNodeData* ChildData; // 0xc0(0x08)
	struct TArray<struct FPendulumSMTransitionInfo> Transitions; // 0xc8(0x10)
	bool bRunSimUpdateSelfBP; // 0xd8(0x01)
	bool bRunInitSelfBP; // 0xd9(0x01)
	bool bRunSyncWithGameAssetsSelfBP; // 0xda(0x01)
	char pad_db[0x5]; // 0xdb(0x05)

	void UpdateChild(struct FSimUpdateInput& Inp, struct UPendulumSMStateNode* NodeState, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumSMStateNodeData.UpdateChild // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f9b0a0
	void SyncWithGameAssetsSelfBP(bool bSyncToActor, struct UPendulumSMStateNode* NodeState, struct AActor* Actor, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumSMStateNodeData.SyncWithGameAssetsSelfBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void SimUpdateSelfBP(struct FSimUpdateInput& Inp, struct UPendulumSMStateNode* NodeState, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumSMStateNodeData.SimUpdateSelfBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void InitSelfBP(struct FSimUpdateInput& Inp, struct UPendulumSMStateNode* NodeState, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumSMStateNodeData.InitSelfBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class PendulumRuntime.PendulumMoveOnGroundNodeData
// Size: 0x130 (Inherited: 0xe0)
struct UPendulumMoveOnGroundNodeData : UPendulumSMStateNodeData {
	struct FOnGroundAccelerationParams TemplateGroundAccelerationParams; // 0xe0(0x28)
	struct FInAirAccelerationParams TemplateInAirAccelerationParams; // 0x108(0x24)
	float MinAnalogSpeed; // 0x12c(0x04)

	bool GetMovementParameterModifications(struct FMovementParameterModifications& Out, struct FSimUpdateInput& Inp, struct UPendulumBaseNode* NodeState, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumMoveOnGroundNodeData.GetMovementParameterModifications // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5f7f960
};

// Class PendulumRuntime.PendulumBaseNode
// Size: 0xb0 (Inherited: 0xa0)
struct UPendulumBaseNode : USimBaseClass {
	int32_t AssetIndex; // 0xa0(0x04)
	char pad_a4[0xc]; // 0xa4(0x0c)

	void SyncWorldStateToInput(struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNode.SyncWorldStateToInput // (Final|Native|Public|HasOutParms) // @ game+0x5f89050
	void SyncWithGameAssets(bool bSyncTo, struct AActor* Actor, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNode.SyncWithGameAssets // (Final|Native|Public|HasOutParms) // @ game+0x5f89280
	void SimUpdate(struct FSimUpdateInput& Inp, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumBaseNode.SimUpdate // (Final|Native|Public|HasOutParms) // @ game+0x5f83700
	void OnRemove(struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNode.OnRemove // (Final|Native|Public|HasOutParms) // @ game+0x5f8e130
	void Init(struct FSimUpdateInput& Inp, struct UPendulumBaseNodeData* Data, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumBaseNode.Init // (Final|Native|Public|HasOutParms) // @ game+0x5f8aa70
	struct FPendulumNodeHandle GetOwnHandle(); // Function PendulumRuntime.PendulumBaseNode.GetOwnHandle // (Final|Native|Public|Const) // @ game+0x32a8840
	void DebugPrintLogicTree(struct FSimUpdateInput& Inp, struct FPendulumDebugContext& Cont, struct FString& Str, struct FString& IndentStr); // Function PendulumRuntime.PendulumBaseNode.DebugPrintLogicTree // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f8c2d0
	void AnimTreeUpdate(struct FAnimUpdateInput& Inp, struct FPendulumAnimationUpdateContext& Cont, struct FAnimEvaluateResult& Result); // Function PendulumRuntime.PendulumBaseNode.AnimTreeUpdate // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f87840
};

// Class PendulumRuntime.PendulumSMStateNode
// Size: 0xb0 (Inherited: 0xb0)
struct UPendulumSMStateNode : UPendulumBaseNode {
	struct FPendulumNodeHandle ChildNode; // 0xa8(0x01)
	int32_t EnterNodeTick; // 0xac(0x04)
};

// Class PendulumRuntime.PendulumMoveOnGroundNode
// Size: 0xc0 (Inherited: 0xb0)
struct UPendulumMoveOnGroundNode : UPendulumSMStateNode {
	bool bIsInJump; // 0xb0(0x01)
	char pad_b1[0xf]; // 0xb1(0x0f)
};

// Class PendulumRuntime.PendulumStateMachineNodeData
// Size: 0xd0 (Inherited: 0xc0)
struct UPendulumStateMachineNodeData : UPendulumBaseNodeData {
	struct UPendulumSMStateNodeData* ChildData; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)

	void UpdateChildWithoutTempState(struct FSimUpdateInput& Inp, struct UPendulumStateMachineNode* SpecificState, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumStateMachineNodeData.UpdateChildWithoutTempState // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f9c5d0
	void InitChild(struct FSimUpdateInput& Inp, struct UPendulumBaseNode* NodeState, struct FPendulumExecutionContext& Cont); // Function PendulumRuntime.PendulumStateMachineNodeData.InitChild // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f9bef0
};

// Class PendulumRuntime.PendulumMovementStateMachineNodeData
// Size: 0xf0 (Inherited: 0xd0)
struct UPendulumMovementStateMachineNodeData : UPendulumStateMachineNodeData {
	float DATA_CapsuleHalfHeightCrouching; // 0xc8(0x04)
	float DATA_CapsuleHalfHeightStanding; // 0xcc(0x04)
	float DATA_CapsuleRadius; // 0xd0(0x04)
	float DATA_StandingKneeheight; // 0xd4(0x04)
	float LowMaxSlopeAngle; // 0xd8(0x04)
	float NormalMaxSlopeAngle; // 0xdc(0x04)
	struct FGroundTraceDistances GroundTraceDistances; // 0xe0(0x0c)
};

// Class PendulumRuntime.PendulumStateMachineNode
// Size: 0xb0 (Inherited: 0xb0)
struct UPendulumStateMachineNode : UPendulumBaseNode {
	struct FPendulumNodeHandle ChildNode; // 0xa8(0x01)
};

// Class PendulumRuntime.PendulumMovementStateMachineNode
// Size: 0x230 (Inherited: 0xb0)
struct UPendulumMovementStateMachineNode : UPendulumStateMachineNode {
	struct FObjectRelativeLocation Loc; // 0xb0(0x60)
	struct FABBUltraLowCompressedQuat Rotation; // 0x110(0x20)
	struct FABBLowCompressedVectorMaxLen2000 VelocityDiv3; // 0x130(0x18)
	struct FABBLowCompressedVectorMaxLen2000 ImpactVelocityDiv3; // 0x148(0x18)
	struct FABBLowCompressedVectorMaxLen2000 GroundVelocityDiv3; // 0x160(0x18)
	char pad_178[0x8]; // 0x178(0x08)
	struct FABBHighCompressedQuat GroundNormalAsQuat; // 0x180(0x20)
	bool bCollidedAboveStepHeight; // 0x1a0(0x01)
	enum class EMovementMode RoughMovementMode; // 0x1a1(0x01)
	char pad_1a2[0x2]; // 0x1a2(0x02)
	struct FABFloat Stamina; // 0x1a4(0x10)
	struct FABFloat DistanceToGround; // 0x1b4(0x10)
	enum class EGroundTraceDistanceType GroundTraceDistanceType; // 0x1c4(0x01)
	char pad_1c5[0x3]; // 0x1c5(0x03)
	struct FFallThroughGroundInfo FallThroughGroundState; // 0x1c8(0x58)
	bool bIsInCrouch; // 0x220(0x01)
	bool bIsFloorWalkable; // 0x221(0x01)
	bool bGroundAngleWalkable; // 0x222(0x01)
	bool bCollidedWithBottomOfPill; // 0x223(0x01)
	bool bCollided; // 0x224(0x01)
	bool bIsFeetUnderTerrain; // 0x225(0x01)
	char CharacterStance; // 0x226(0x01)
	char LocoMode; // 0x227(0x01)
	bool bDisableSteepSlopeTraversal; // 0x228(0x01)
	enum class EPhysicalSurface SurfaceType; // 0x229(0x01)
	bool bIsStuck; // 0x22a(0x01)
	char pad_22b[0x5]; // 0x22b(0x05)

	void SetGroundNormal(struct FVector& GroundNormal); // Function PendulumRuntime.PendulumMovementStateMachineNode.SetGroundNormal // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5f81af0
	struct FVector GetVelocity(); // Function PendulumRuntime.PendulumMovementStateMachineNode.GetVelocity // (Final|Native|Public|HasDefaults|Const) // @ game+0x5f802b0
	struct FVector GetGroundNormal(); // Function PendulumRuntime.PendulumMovementStateMachineNode.GetGroundNormal // (Final|Native|Public|HasDefaults|Const) // @ game+0x5f803c0
};

// Class PendulumRuntime.PendulumMovementUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumMovementUtils : UBlueprintFunctionLibrary {

	struct FPendulumMovementStateMachineNodeTempState GetTempDataFromInput(struct FSimUpdateInput& Inp); // Function PendulumRuntime.PendulumMovementUtils.GetTempDataFromInput // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f80510
};

// Class PendulumRuntime.LogicResultMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULogicResultMixinLibrary : UObject {

	void SetValueFromTransientStateEnumId(struct FPendulumLogicResult& Array, enum class LogicTransientStateBoolIndices BoolEnum, bool Value); // Function PendulumRuntime.LogicResultMixinLibrary.SetValueFromTransientStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7bcb0
	void SetValueFromTagNameId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FName& TagName, bool Value); // Function PendulumRuntime.LogicResultMixinLibrary.SetValueFromTagNameId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f79640
	void SetValueFromTagId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FGameplayTag& Tag, bool Value); // Function PendulumRuntime.LogicResultMixinLibrary.SetValueFromTagId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7ff40
	void SetValueFromDynamicStateEnumId(struct FPendulumLogicResult& Array, enum class LogicDynamicStateBoolIndices BoolEnum, bool Value); // Function PendulumRuntime.LogicResultMixinLibrary.SetValueFromDynamicStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f812c0
	void MergeResultInvertOther(struct FPendulumLogicResult& Array, struct FPendulumLogicResult& WithArray); // Function PendulumRuntime.LogicResultMixinLibrary.MergeResultInvertOther // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f80d40
	void MergeResult(struct FPendulumLogicResult& Array, struct FPendulumLogicResult& WithArray); // Function PendulumRuntime.LogicResultMixinLibrary.MergeResult // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7c8b0
	bool HasAnyTagExact(struct FPendulumLogicResult& Result, struct FPendulumVariableTableMapping& VarTableMapping, struct FGameplayTagContainer& Tags); // Function PendulumRuntime.LogicResultMixinLibrary.HasAnyTagExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7b6f0
	bool HasAllTagsExact(struct FPendulumLogicResult& Result, struct FPendulumVariableTableMapping& VarTableMapping, struct FGameplayTagContainer& Tags); // Function PendulumRuntime.LogicResultMixinLibrary.HasAllTagsExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f80990
	bool GetValueFromTransientStateEnumId(struct FPendulumLogicResult& Array, enum class LogicTransientStateBoolIndices BoolEnum); // Function PendulumRuntime.LogicResultMixinLibrary.GetValueFromTransientStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f83000
	bool GetValueFromTagNameId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FName& TagName); // Function PendulumRuntime.LogicResultMixinLibrary.GetValueFromTagNameId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7b970
	bool GetValueFromTagId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FGameplayTag& Tag); // Function PendulumRuntime.LogicResultMixinLibrary.GetValueFromTagId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7f3e0
	bool GetValueFromDynamicStateEnumId(struct FPendulumLogicResult& Array, enum class LogicDynamicStateBoolIndices BoolEnum); // Function PendulumRuntime.LogicResultMixinLibrary.GetValueFromDynamicStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7d890
	bool GetEnabledAndDirtyFromTransientStateEnumId(struct FPendulumLogicResult& Array, enum class LogicTransientStateBoolIndices BoolEnum); // Function PendulumRuntime.LogicResultMixinLibrary.GetEnabledAndDirtyFromTransientStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f829d0
	bool GetEnabledAndDirtyFromTagNameId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FName& TagName); // Function PendulumRuntime.LogicResultMixinLibrary.GetEnabledAndDirtyFromTagNameId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7f620
	bool GetEnabledAndDirtyFromTagId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FGameplayTag& Tag); // Function PendulumRuntime.LogicResultMixinLibrary.GetEnabledAndDirtyFromTagId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f80790
	bool GetEnabledAndDirtyFromDynamicStateEnumId(struct FPendulumLogicResult& Array, enum class LogicDynamicStateBoolIndices BoolEnum); // Function PendulumRuntime.LogicResultMixinLibrary.GetEnabledAndDirtyFromDynamicStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7d2c0
	bool GetDirtyValueFromTransientStateEnumId(struct FPendulumLogicResult& Array, enum class LogicTransientStateBoolIndices BoolEnum); // Function PendulumRuntime.LogicResultMixinLibrary.GetDirtyValueFromTransientStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f78d40
	bool GetDirtyValueFromTagNameId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FName& TagName); // Function PendulumRuntime.LogicResultMixinLibrary.GetDirtyValueFromTagNameId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f81c20
	bool GetDirtyValueFromTagId(struct FPendulumLogicResult& Array, struct FPendulumVariableTableMapping& VarTableMapping, struct FGameplayTag& Tag); // Function PendulumRuntime.LogicResultMixinLibrary.GetDirtyValueFromTagId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f79e60
	bool GetDirtyValueFromDynamicStateEnumId(struct FPendulumLogicResult& Array, enum class LogicDynamicStateBoolIndices BoolEnum); // Function PendulumRuntime.LogicResultMixinLibrary.GetDirtyValueFromDynamicStateEnumId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f7fde0
};

// Class PendulumRuntime.MovementInputClaimsNode
// Size: 0xf0 (Inherited: 0xb0)
struct UMovementInputClaimsNode : UPendulumBaseNode {
	int8_t ThrottleRaw; // 0xa8(0x01)
	int8_t StrafeRaw; // 0xa9(0x01)
	bool bJump; // 0xaa(0x01)
	bool bRequestUnstick; // 0xab(0x01)
	bool bCrouch; // 0xac(0x01)
	bool bActionMove; // 0xad(0x01)
	bool bLastJump; // 0xae(0x01)
	bool bLastCrouch; // 0xaf(0x01)
	bool bLastActionMove; // 0xb0(0x01)
	bool bSprint; // 0xb1(0x01)
	bool bBlendToReplication; // 0xb2(0x01)
	char pad_bb[0x5]; // 0xbb(0x05)
	struct FABBUltraLowCompressedQuat ControlRotation; // 0xc0(0x20)
	int16_t SteeringAngleSmoothRaw; // 0xe0(0x02)
	bool bUsingGamepad; // 0xe2(0x01)
	bool bLastUsingGamepad; // 0xe3(0x01)
	char pad_e4[0xc]; // 0xe4(0x0c)

	void SetThrottle(float Throttle); // Function PendulumRuntime.MovementInputClaimsNode.SetThrottle // (Final|Native|Public) // @ game+0x5f8b5c0
	void SetStrafe(float Throttle); // Function PendulumRuntime.MovementInputClaimsNode.SetStrafe // (Final|Native|Public) // @ game+0x5f8cc60
	void SetSteeringAngleSmooth(float Throttle); // Function PendulumRuntime.MovementInputClaimsNode.SetSteeringAngleSmooth // (Final|Native|Public) // @ game+0x5f8aeb0
	struct FQuat GetYawOnlyControlRotation(); // Function PendulumRuntime.MovementInputClaimsNode.GetYawOnlyControlRotation // (Final|Native|Public|HasDefaults|Const) // @ game+0x5f86530
	float GetThrottle(); // Function PendulumRuntime.MovementInputClaimsNode.GetThrottle // (Final|Native|Public|Const) // @ game+0x5f8a730
	float GetStrafe(); // Function PendulumRuntime.MovementInputClaimsNode.GetStrafe // (Final|Native|Public|Const) // @ game+0x5f87c40
	float GetSteeringAngleSmooth(); // Function PendulumRuntime.MovementInputClaimsNode.GetSteeringAngleSmooth // (Final|Native|Public|Const) // @ game+0x5f8bcb0
};

// Class PendulumRuntime.InteractionInputClaimsNode
// Size: 0xb0 (Inherited: 0xb0)
struct UInteractionInputClaimsNode : UPendulumBaseNode {
	struct TWeakObjectPtr<struct UObject> Ptr; // 0xa8(0x08)

	void SetInteraction(struct UObject* Obj); // Function PendulumRuntime.InteractionInputClaimsNode.SetInteraction // (Final|Native|Public) // @ game+0x5f8e340
	struct UObject* GetInteraction(); // Function PendulumRuntime.InteractionInputClaimsNode.GetInteraction // (Final|Native|Public|Const) // @ game+0x5f84600
};

// Class PendulumRuntime.MovementInputClaimsNodeData
// Size: 0xc0 (Inherited: 0xc0)
struct UMovementInputClaimsNodeData : UPendulumBaseNodeData {
};

// Class PendulumRuntime.PendulumAnimationUpdateContextMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumAnimationUpdateContextMixinLibrary : UObject {

	bool GetTagValue(struct FPendulumAnimationUpdateContext& MemContainer, struct FGameplayTag& Tag); // Function PendulumRuntime.PendulumAnimationUpdateContextMixinLibrary.GetTagValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5f874f0
	bool GetTagNameValue(struct FPendulumAnimationUpdateContext& MemContainer, struct FName& Tag); // Function PendulumRuntime.PendulumAnimationUpdateContextMixinLibrary.GetTagNameValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5f8b340
	struct FTransform GetPhysicsTransform(struct FPendulumAnimationUpdateContext& MemContainer); // Function PendulumRuntime.PendulumAnimationUpdateContextMixinLibrary.GetPhysicsTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f8c5b0
	struct UObject* GetFirstSimulationStateOfType(struct FPendulumAnimationUpdateContext& MemContainer, struct UObject* ClassObj); // Function PendulumRuntime.PendulumAnimationUpdateContextMixinLibrary.GetFirstSimulationStateOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8e000
	struct UPendulumBaseNodeData* GetDataForState(struct FPendulumAnimationUpdateContext& MemContainer, struct UPendulumBaseNode* State); // Function PendulumRuntime.PendulumAnimationUpdateContextMixinLibrary.GetDataForState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8a1f0
};

// Class PendulumRuntime.BlendedTreeUpdateResultMixin
// Size: 0xa0 (Inherited: 0xa0)
struct UBlendedTreeUpdateResultMixin : UObject {

	void SetVelocity(struct FBlendedTreeUpdateResult& res, struct FVector& NewVelocity); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.SetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f89e60
	void SetVector(struct FBlendedTreeUpdateResult& res, enum class BlendedResultVectorIndices Index, struct FVector& NewValue); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.SetVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f84a20
	void SetQuat(struct FBlendedTreeUpdateResult& res, enum class BlendedResultQuatIndices Index, struct FQuat& NewValue); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.SetQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f83b10
	void SetAngularDelta(struct FBlendedTreeUpdateResult& res, struct FQuat& NewAngularDelta); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.SetAngularDelta // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f88980
	struct FVector GetVelocity(struct FBlendedTreeUpdateResult& res); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.GetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f85e20
	struct FVector GetVector(struct FBlendedTreeUpdateResult& res, enum class BlendedResultVectorIndices Index); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.GetVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f84050
	struct FQuat GetQuat(struct FBlendedTreeUpdateResult& res, enum class BlendedResultQuatIndices Index); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.GetQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f88ab0
	struct FQuat GetAngularDelta(struct FBlendedTreeUpdateResult& res); // Function PendulumRuntime.BlendedTreeUpdateResultMixin.GetAngularDelta // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5f87dc0
};

// Class PendulumRuntime.SimUpdateInputMixin
// Size: 0xa0 (Inherited: 0xa0)
struct USimUpdateInputMixin : UObject {

	struct FPendulumNodeHandle GetParentNodeHandle(struct FSimUpdateInput& Inp); // Function PendulumRuntime.SimUpdateInputMixin.GetParentNodeHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f856d0
	void AddSimStateObjectToExecutionStack(struct FSimUpdateInput& Inp, struct USimBaseClass* Obj); // Function PendulumRuntime.SimUpdateInputMixin.AddSimStateObjectToExecutionStack // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f841c0
	void AddSimStateHandleToExecutionStack(struct FSimUpdateInput& Inp, struct FPendulumNodeHandle Handle); // Function PendulumRuntime.SimUpdateInputMixin.AddSimStateHandleToExecutionStack // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8d820
};

// Class PendulumRuntime.PendulumClipNodeData
// Size: 0x180 (Inherited: 0xc0)
struct UPendulumClipNodeData : UPendulumBaseNodeData {
	struct FClipCurvesInfo CurvesInfo; // 0xc0(0x90)
	struct UAnimSequence* Anim; // 0x150(0x08)
	bool bLooping; // 0x158(0x01)
	bool bRunRootMotion; // 0x159(0x01)
	bool bDisplayPose; // 0x15a(0x01)
	char pad_15b[0x1]; // 0x15b(0x01)
	int32_t AuxRootBoneIndex; // 0x15c(0x04)
	bool bUseWarping; // 0x160(0x01)
	bool bUseFixedOrientation; // 0x161(0x01)
	char pad_162[0x2]; // 0x162(0x02)
	float EndBranchEndOffsetTime; // 0x164(0x04)
	int32_t EndBranchCurveIndex; // 0x168(0x04)
	bool bUseGravity; // 0x16c(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
	float ScaleMovementFactor; // 0x170(0x04)
	char pad_174[0xc]; // 0x174(0x0c)

	void SimUpdateStateLess(struct FSimUpdateInput& Inp, struct FStatelessClipUpdateContext& ClipContext, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& Result); // Function PendulumRuntime.PendulumClipNodeData.SimUpdateStateLess // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f87ea0
	void OptimizeSequencedTags(struct UPendulumDataContainer* DataContainer); // Function PendulumRuntime.PendulumClipNodeData.OptimizeSequencedTags // (Final|Native|Private) // @ game+0x5f8bac0
	void DebugPrintLogicTreeStateLess(struct FSimUpdateInput& Inp, int32_t TickOffset, struct FPendulumDebugContext& Cont, struct FString& Str, struct FString& IndentStr); // Function PendulumRuntime.PendulumClipNodeData.DebugPrintLogicTreeStateLess // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f8cf60
	void AnimTreeUpdateStateLess(struct FAnimUpdateInput& Inp, int32_t TickOffset, struct FPendulumAnimationUpdateContext& Cont, struct FAnimEvaluateResult& Result); // Function PendulumRuntime.PendulumClipNodeData.AnimTreeUpdateStateLess // (Final|Native|Public|HasOutParms|Const) // @ game+0x5f85850
};

// Class PendulumRuntime.PendulumClipNode
// Size: 0xc0 (Inherited: 0xb0)
struct UPendulumClipNode : UPendulumBaseNode {
	struct FABInt TickOffset; // 0xa8(0x10)

	void SetTimeOffset(float TOffset); // Function PendulumRuntime.PendulumClipNode.SetTimeOffset // (Final|Native|Public) // @ game+0x5f8e2a0
};

// Class PendulumRuntime.PendulumWarpedClipNode
// Size: 0x120 (Inherited: 0xc0)
struct UPendulumWarpedClipNode : UPendulumClipNode {
	struct FABBHighCompressedWorldTransform WarpTargetTransform; // 0xc0(0x60)
};

// Class PendulumRuntime.PendulumFixedOrientationClipNode
// Size: 0xe0 (Inherited: 0xc0)
struct UPendulumFixedOrientationClipNode : UPendulumClipNode {
	struct FABBHighCompressedQuat Rotation; // 0xc0(0x20)
};

// Class PendulumRuntime.PendulumAnimTag
// Size: 0xd0 (Inherited: 0xa0)
struct UPendulumAnimTag : UAnimNotifyState {
	struct FGameplayTagContainer GameplayTags; // 0xa0(0x20)
	bool bResetWhenLeaving; // 0xc0(0x01)
	char pad_c1[0xf]; // 0xc1(0x0f)
};

// Class PendulumRuntime.PendulumAnimBranchTag
// Size: 0xb0 (Inherited: 0xa0)
struct UPendulumAnimBranchTag : UAnimNotifyState {
	enum class LogicDynamicStateBoolIndices DynamicBranchTag; // 0xa0(0x01)
	enum class LogicTransientStateBoolIndices TransientBranchTag; // 0xa1(0x01)
	bool bResetWhenLeaving; // 0xa2(0x01)
	char pad_a3[0xd]; // 0xa3(0x0d)
};

// Class PendulumRuntime.PendulumDataContainer
// Size: 0x110 (Inherited: 0xa0)
struct UPendulumDataContainer : UPrimaryDataAsset {
	struct TArray<struct UPendulumBaseNodeData*> NodeList; // 0xa0(0x10)
	struct FPendulumVariableTableMapping TableMapping; // 0xb0(0x60)

	struct FPendulumVariableTableMapping GetTableMapping(); // Function PendulumRuntime.PendulumDataContainer.GetTableMapping // (Final|Native|Public|Const) // @ game+0x5f8e9c0
	struct UPendulumBaseNodeData* GetDataFromIndex(int32_t Index); // Function PendulumRuntime.PendulumDataContainer.GetDataFromIndex // (Final|Native|Public|Const) // @ game+0x5f90700
	void GetAllCDOsWithBase(struct TArray<struct UObject*>& ResultArray, struct UObject* ClassType, bool bOnlyTemplates); // Function PendulumRuntime.PendulumDataContainer.GetAllCDOsWithBase // (Final|Native|Protected|HasOutParms) // @ game+0x5f947d0
	void GenerateStateMachine(); // Function PendulumRuntime.PendulumDataContainer.GenerateStateMachine // (Native|Event|Protected|BlueprintEvent) // @ game+0x2b96540
	struct FPendulumVariableTableMapping EditTableMapping(); // Function PendulumRuntime.PendulumDataContainer.EditTableMapping // (Final|Native|Public) // @ game+0x5f8e9c0
	void CleanupPIEData(); // Function PendulumRuntime.PendulumDataContainer.CleanupPIEData // (Native|Event|Protected|BlueprintEvent) // @ game+0x2b95cb0
	struct UPendulumTransitionNodeData* AddTransitionOfTypeWithConditionsStruct(struct UObject* ClassType, struct UPendulumSMStateNodeData* From, struct UPendulumSMStateNodeData* To, float SimulationBlendTime, float AnimationBlendTime, struct FSimpleTransitionCondition& Conditions); // Function PendulumRuntime.PendulumDataContainer.AddTransitionOfTypeWithConditionsStruct // (Final|Native|Protected|HasOutParms) // @ game+0x5f95420
	struct UPendulumTransitionNodeData* AddTransitionOfType(struct UObject* ClassType, struct UPendulumSMStateNodeData* From, struct UPendulumSMStateNodeData* To, float SimulationBlendTime, float AnimationBlendTime); // Function PendulumRuntime.PendulumDataContainer.AddTransitionOfType // (Final|Native|Protected) // @ game+0x5f90930
	struct UPendulumTransitionNodeData* AddTransitionOfDefaultTypeWithConditionsStruct(struct UPendulumSMStateNodeData* From, struct UPendulumSMStateNodeData* To, float SimulationBlendTime, float AnimationBlendTime, struct FSimpleTransitionCondition& Conditions); // Function PendulumRuntime.PendulumDataContainer.AddTransitionOfDefaultTypeWithConditionsStruct // (Final|Native|Protected|HasOutParms) // @ game+0x5f93130
	struct UPendulumTransitionNodeData* AddTransitionOfDefaultType(struct UPendulumSMStateNodeData* From, struct UPendulumSMStateNodeData* To, float SimulationBlendTime, float AnimationBlendTime); // Function PendulumRuntime.PendulumDataContainer.AddTransitionOfDefaultType // (Final|Native|Protected) // @ game+0x5f8e7d0
	struct UPendulumBaseNodeData* AddNodeDataOfType(struct UObject* ClassType); // Function PendulumRuntime.PendulumDataContainer.AddNodeDataOfType // (Final|Native|Public) // @ game+0x5f91300
};

// Class PendulumRuntime.PendulumRuntimeFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumRuntimeFunctionLibrary : UBlueprintFunctionLibrary {

	void GetAllCDOsWithBase(struct TArray<struct UObject*>& ResultArray, struct UObject* ClassType, bool bOnlyTemplates); // Function PendulumRuntime.PendulumRuntimeFunctionLibrary.GetAllCDOsWithBase // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5f92e10
};

// Class PendulumRuntime.PendulumExecutionContextMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumExecutionContextMixinLibrary : UObject {

	int32_t TimeToPendulumTick(struct FPendulumExecutionContext& MemContainer, float Time); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.TimeToPendulumTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f949c0
	void RemoveStateByIndex(struct FPendulumExecutionContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.RemoveStateByIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f952b0
	void RemoveStateByHandle(struct FPendulumExecutionContext& MemContainer, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.RemoveStateByHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f907b0
	void RemoveStateAndResetHandle(struct FPendulumExecutionContext& MemContainer, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.RemoveStateAndResetHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8fb10
	void RemoveState(struct FPendulumExecutionContext& MemContainer, struct USimBaseClass* Ass); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.RemoveState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f93d50
	float PendulumTickToTime(struct FPendulumExecutionContext& MemContainer, int32_t Tick); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.PendulumTickToTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f91ae0
	void MarkLowLatencyEvent(struct FPendulumExecutionContext& MemContainer); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.MarkLowLatencyEvent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f96580
	bool HasAnyTagExact(struct FPendulumExecutionContext& MemContainer, struct FGameplayTagContainer& Tags); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.HasAnyTagExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f93b90
	bool HasAllTagsExact(struct FPendulumExecutionContext& MemContainer, struct FGameplayTagContainer& Tags); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.HasAllTagsExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f92b90
	bool GetValueFromTag(struct FPendulumExecutionContext& MemContainer, struct FGameplayTag& TagName); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetValueFromTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f926f0
	struct FPendulumVariableTableMapping GetTableMapping(struct FPendulumExecutionContext& MemContainer); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetTableMapping // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f919b0
	struct USimBaseClass* GetStateFromIndex(struct FPendulumExecutionContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetStateFromIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f92570
	struct USimBaseClass* GetStateFromHandle(struct FPendulumExecutionContext& MemContainer, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetStateFromHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f92880
	struct UPendulumBaseNode* GetPendulumStateFromIndex(struct FPendulumExecutionContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetPendulumStateFromIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f92570
	int32_t GetLatestAppliedInputId(struct FPendulumExecutionContext& MemContainer); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetLatestAppliedInputId // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f95030
	int32_t GetLastSyncFrameTick(struct FPendulumExecutionContext& MemContainer); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetLastSyncFrameTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f937b0
	struct FPendulumNodeHandle GetHandleFromSimulationState(struct FPendulumExecutionContext& MemContainer, struct USimBaseClass* Obj); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetHandleFromSimulationState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f94550
	struct UObject* GetFirstTempStateOfTypeFromParentHierarchy(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj, struct FSimUpdateInput& Inp); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetFirstTempStateOfTypeFromParentHierarchy // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8f630
	struct UObject* GetFirstTempStateOfType(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetFirstTempStateOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f91f90
	struct UObject* GetFirstSimulationStateOfTypeFromParentHierarchy(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj, struct FSimUpdateInput& Inp); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetFirstSimulationStateOfTypeFromParentHierarchy // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f93540
	struct UObject* GetFirstSimulationStateOfType(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetFirstSimulationStateOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8ed60
	struct UObject* GetFirstInputOfType(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetFirstInputOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f96030
	struct UPendulumBaseNodeData* GetDataForState(struct FPendulumExecutionContext& MemContainer, struct UPendulumBaseNode* State); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetDataForState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f91670
	int32_t GetCurrentPendulumTick(struct FPendulumExecutionContext& MemContainer); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.GetCurrentPendulumTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f90180
	struct USimBaseClass* EditStateFromIndex(struct FPendulumExecutionContext& MemContainer, int32_t Index, bool bSetDirty); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditStateFromIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f94330
	struct USimBaseClass* EditStateFromHandle(struct FPendulumExecutionContext& MemContainer, struct FPendulumNodeHandle& Handle, bool bSetDirty); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditStateFromHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f963a0
	struct UPendulumBaseNode* EditPendulumStateFromIndex(struct FPendulumExecutionContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditPendulumStateFromIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f923b0
	struct UObject* EditFirstTempStateOfTypeFromParentHierarchy(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj, struct FSimUpdateInput& Inp); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditFirstTempStateOfTypeFromParentHierarchy // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f94c00
	struct UObject* EditFirstTempStateOfType(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditFirstTempStateOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f93f50
	struct UObject* EditFirstSimulationStateOfTypeFromParentHierarchy(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj, struct FSimUpdateInput& Inp); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditFirstSimulationStateOfTypeFromParentHierarchy // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8f3a0
	struct UObject* EditFirstSimulationStateOfType(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj, bool bSetDirty); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditFirstSimulationStateOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f94e50
	struct UObject* EditFirstOrCreateSimulationStateOfType(struct FPendulumExecutionContext& MemContainer, struct UObject* ClassObj); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.EditFirstOrCreateSimulationStateOfType // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f90d00
	void DirtyStateByIndex(struct FPendulumExecutionContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.DirtyStateByIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f93920
	void DirtyStateByHandle(struct FPendulumExecutionContext& MemContainer, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.DirtyStateByHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8e5d0
	void DirtyState(struct FPendulumExecutionContext& MemContainer, struct USimBaseClass* Ass); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.DirtyState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f90b90
	struct USimBaseClass* CreateNewTempStateOfClassForChildren(struct FPendulumExecutionContext& MemContainer, struct UObject* TypeToCreate, struct FSimUpdateInput& Inp); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.CreateNewTempStateOfClassForChildren // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8f880
	struct USimBaseClass* CreateNewTempStateOfClass(struct FPendulumExecutionContext& MemContainer, struct FSimUpdateInput& Inp, struct UObject* TypeToCreate); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.CreateNewTempStateOfClass // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f91020
	struct UPendulumBaseNode* CreateNewStateSetHandle(struct FPendulumExecutionContext& MemContainer, struct FSimUpdateInput& Inp, struct UPendulumBaseNodeData* Ass, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.CreateNewStateSetHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8f060
	struct USimBaseClass* CreateNewStateOfClassSetHandle(struct FPendulumExecutionContext& MemContainer, struct FSimUpdateInput& Inp, struct UObject* TypeToCreate, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.CreateNewStateOfClassSetHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f903f0
	struct USimBaseClass* CreateNewStateOfClass(struct FPendulumExecutionContext& MemContainer, struct FSimUpdateInput& Inp, struct UObject* TypeToCreate); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.CreateNewStateOfClass // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f92110
	struct UPendulumBaseNode* CreateNewState(struct FPendulumExecutionContext& MemContainer, struct FSimUpdateInput& Inp, struct UPendulumBaseNodeData* Ass); // Function PendulumRuntime.PendulumExecutionContextMixinLibrary.CreateNewState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f95830
};

// Class PendulumRuntime.PendulumDebugContextMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumDebugContextMixinLibrary : UObject {

	int32_t TimeToPendulumTick(struct FPendulumDebugContext& MemContainer, float Time); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.TimeToPendulumTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f91d20
	float PendulumTickToTime(struct FPendulumDebugContext& MemContainer, int32_t Tick); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.PendulumTickToTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f91e70
	struct USimBaseClass* GetStateFromIndex(struct FPendulumDebugContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.GetStateFromIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8e9e0
	struct USimBaseClass* GetStateFromHandle(struct FPendulumDebugContext& MemContainer, struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.GetStateFromHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8eb00
	struct UPendulumBaseNode* GetPendulumStateFromIndex(struct FPendulumDebugContext& MemContainer, int32_t Index); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.GetPendulumStateFromIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f95710
	struct FPendulumNodeHandle GetHandleFromSimulationState(struct FPendulumDebugContext& MemContainer, struct USimBaseClass* Obj); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.GetHandleFromSimulationState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f96280
	int32_t GetCurrentPendulumTick(struct FPendulumDebugContext& MemContainer); // Function PendulumRuntime.PendulumDebugContextMixinLibrary.GetCurrentPendulumTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f8ef60
};

// Class PendulumRuntime.PendulumLayerNodeData
// Size: 0xd0 (Inherited: 0xc0)
struct UPendulumLayerNodeData : UPendulumBaseNodeData {
	struct TArray<struct UPendulumBaseNodeData*> LayerRows; // 0xc0(0x10)
};

// Class PendulumRuntime.PendulumLayerNode
// Size: 0xb0 (Inherited: 0xb0)
struct UPendulumLayerNode : UPendulumBaseNode {
	struct FPendulumNodeHandle NodeHandles[0x5]; // 0xa8(0x05)
};

// Class PendulumRuntime.PendulumNodeHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumNodeHandleMixinLibrary : UObject {

	void ResetNodeHandle(struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumNodeHandleMixinLibrary.ResetNodeHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9e670
	bool opEquals(struct FPendulumNodeHandle& LHS, struct FPendulumNodeHandle& RHS); // Function PendulumRuntime.PendulumNodeHandleMixinLibrary.opEquals // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9b8f0
	bool IsNodeHandleValid(struct FPendulumNodeHandle& Handle); // Function PendulumRuntime.PendulumNodeHandleMixinLibrary.IsNodeHandleValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9e050
};

// Class PendulumRuntime.PendulumRootNodeData
// Size: 0xd0 (Inherited: 0xc0)
struct UPendulumRootNodeData : UPendulumBaseNodeData {
	struct UPendulumBaseNodeData* ChildNode; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)
};

// Class PendulumRuntime.PendulumRootNode
// Size: 0x100 (Inherited: 0xb0)
struct UPendulumRootNode : UPendulumBaseNode {
	int32_t PendulumDataIndex; // 0xa8(0x04)
	struct FABInt LatestAppliedInput; // 0xac(0x10)
	struct FPendulumNodeHandle ChildNode; // 0xbc(0x01)
	struct FPendulumBoolArray PendulumTagState; // 0xc0(0x20)
	struct FABInt TotalTime; // 0xe0(0x10)
	int32_t TimeCorrection; // 0xf0(0x04)
	char pad_f9[0x7]; // 0xf9(0x07)

	void SetTagFromFName(struct FName& Tag, struct FPendulumExecutionContext& Cont, bool bVal); // Function PendulumRuntime.PendulumRootNode.SetTagFromFName // (Final|Native|Public|HasOutParms) // @ game+0x5f9ad00
	void SetTag(struct FGameplayTag& Tag, struct FPendulumExecutionContext& Cont, bool bVal); // Function PendulumRuntime.PendulumRootNode.SetTag // (Final|Native|Public|HasOutParms) // @ game+0x5f97320
	void SetLatestAppliedInput(int32_t LastAppliedInput); // Function PendulumRuntime.PendulumRootNode.SetLatestAppliedInput // (Final|Native|Public) // @ game+0x5f985a0
	float GetRootTimeWithCorrection(); // Function PendulumRuntime.PendulumRootNode.GetRootTimeWithCorrection // (Final|Native|Public|Const) // @ game+0x5f9d6d0
	int32_t GetLatestAppliedInput(); // Function PendulumRuntime.PendulumRootNode.GetLatestAppliedInput // (Final|Native|Public|Const) // @ game+0x32aeb20
	int32_t GetLastPendulumSyncTick(); // Function PendulumRuntime.PendulumRootNode.GetLastPendulumSyncTick // (Final|Native|Public|Const) // @ game+0x1703aa0
};

// Class PendulumRuntime.TimeValidStateChangeMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UTimeValidStateChangeMixinLibrary : UObject {

	void SetupTimingTicks(struct FTimeValidStateChange& Change, int32_t StartTicks, int32_t EndTicks, bool bInResetWhenLeave); // Function PendulumRuntime.TimeValidStateChangeMixinLibrary.SetupTimingTicks // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9e380
	void SetupTimingSeconds(struct FTimeValidStateChange& Change, float StartSeconds, float EndSeconds, bool bInResetWhenLeave); // Function PendulumRuntime.TimeValidStateChangeMixinLibrary.SetupTimingSeconds // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9a830
	void ApplyChanges(struct FTimeValidStateChange& Change, struct FPendulumLogicResult& ToResult, int32_t StartTime, int32_t EndTime, struct UPendulumDataContainer* DataContainer); // Function PendulumRuntime.TimeValidStateChangeMixinLibrary.ApplyChanges // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9c350
};

// Class PendulumRuntime.SimpleTransitionConditionMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USimpleTransitionConditionMixinLibrary : UObject {

	void SetValueToTransientStateCondition(struct FSimpleTransitionCondition& ToResult, enum class LogicTransientStateBoolIndices Index, bool Value); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.SetValueToTransientStateCondition // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f98f10
	void SetValueToGPTagNameCondition(struct FSimpleTransitionCondition& ToResult, struct UPendulumDataContainer* DataCont, struct FName& TagName, bool Value); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.SetValueToGPTagNameCondition // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f99aa0
	void SetValueToGPTagCondition(struct FSimpleTransitionCondition& ToResult, struct UPendulumDataContainer* DataCont, struct FGameplayTag& Tag, bool Value); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.SetValueToGPTagCondition // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f98d40
	void SetValueToDynamicStateCondition(struct FSimpleTransitionCondition& ToResult, enum class LogicDynamicStateBoolIndices Index, bool Value); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.SetValueToDynamicStateCondition // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f99510
	bool SatisfiedByState(struct FSimpleTransitionCondition& ToResult, struct FPendulumLogicResult& ToCompare); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.SatisfiedByState // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f96a90
	void Reset(struct FSimpleTransitionCondition& ToResult); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f9d970
	void MergeFrom(struct FSimpleTransitionCondition& ToResult, struct FSimpleTransitionCondition& FromResult); // Function PendulumRuntime.SimpleTransitionConditionMixinLibrary.MergeFrom // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f983b0
};

// Class PendulumRuntime.PendulumDataContainerLibrary
// Size: 0xb0 (Inherited: 0xa0)
struct UPendulumDataContainerLibrary : UPrimaryDataAsset {
	struct TArray<struct UPendulumDataContainer*> DataContainerList; // 0xa0(0x10)
};

// Class PendulumRuntime.PendulumSubsystem
// Size: 0xc0 (Inherited: 0xa0)
struct UPendulumSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class PendulumRuntime.PendulumTester
// Size: 0x36940 (Inherited: 0xa0)
struct UPendulumTester : UObject {
	char pad_a0[0x368a0]; // 0xa0(0x368a0)

	void Tick(float DeltaTime); // Function PendulumRuntime.PendulumTester.Tick // (Final|Native|Public|BlueprintCallable) // @ game+0x5f9d7d0
	void SetValueFromTag(struct FGameplayTag& Tag, bool bValue); // Function PendulumRuntime.PendulumTester.SetValueFromTag // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5f97700
	void Init(struct AActor* OwnerActor, struct UPendulumDataContainer* PendulumDataContainer); // Function PendulumRuntime.PendulumTester.Init // (Final|Native|Public|BlueprintCallable) // @ game+0x5f9cd40
	struct FPendulumExecutionContext GetExecutionContext(); // Function PendulumRuntime.PendulumTester.GetExecutionContext // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5f9bb40
	void FakeTransmit(); // Function PendulumRuntime.PendulumTester.FakeTransmit // (Final|Native|Public|BlueprintCallable) // @ game+0x5f99430
	struct USimBaseClass* CreateNewInputOfClass(struct UObject* TypeToCreate); // Function PendulumRuntime.PendulumTester.CreateNewInputOfClass // (Final|Native|Public|BlueprintCallable) // @ game+0x5f9dfa0
};

// Class PendulumRuntime.PendulumTransitionNodeData
// Size: 0xe0 (Inherited: 0xc0)
struct UPendulumTransitionNodeData : UPendulumBaseNodeData {
	struct UPendulumSMStateNodeData* Target; // 0xc0(0x08)
	int32_t AnimationTransitionTicks; // 0xc8(0x04)
	int32_t SimulationTransitionTicks; // 0xcc(0x04)
	int32_t NestedTransitionAllowCount; // 0xd0(0x04)
	bool bHasComplexTransitionCondition; // 0xd4(0x01)
	char pad_d5[0xb]; // 0xd5(0x0b)

	void SetupAdditionalSimpleTransitionConditions(struct UPendulumDataContainer* DataContainer, struct FSimpleTransitionCondition& ConditionToAlter); // Function PendulumRuntime.PendulumTransitionNodeData.SetupAdditionalSimpleTransitionConditions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void SetSimulationTransitionTime(float Time); // Function PendulumRuntime.PendulumTransitionNodeData.SetSimulationTransitionTime // (Final|Native|Public) // @ game+0x5f9d3e0
	void SetAnimationTransitionTime(float Time); // Function PendulumRuntime.PendulumTransitionNodeData.SetAnimationTransitionTime // (Final|Native|Public) // @ game+0x5f96d00
};

// Class PendulumRuntime.PendulumTransitionToVaultData
// Size: 0xe0 (Inherited: 0xe0)
struct UPendulumTransitionToVaultData : UPendulumTransitionNodeData {
};

// Class PendulumRuntime.PendulumTransitionToLedgeGrabData
// Size: 0xe0 (Inherited: 0xe0)
struct UPendulumTransitionToLedgeGrabData : UPendulumTransitionNodeData {
};

// Class PendulumRuntime.PendulumTransitionSampleDefault
// Size: 0xe0 (Inherited: 0xe0)
struct UPendulumTransitionSampleDefault : UPendulumTransitionNodeData {
};

// Class PendulumRuntime.SMSampleDataContainer
// Size: 0x110 (Inherited: 0x110)
struct USMSampleDataContainer : UPendulumDataContainer {
};

// Class PendulumRuntime.PendulumTransitionNodeBPData
// Size: 0xe0 (Inherited: 0xe0)
struct UPendulumTransitionNodeBPData : UPendulumTransitionNodeData {

	bool EvaluateTransitionBP(struct FSimUpdateInput& Inp, struct FPendulumExecutionContext& Cont, struct FSimUpdateResult& SimUpdateResult); // Function PendulumRuntime.PendulumTransitionNodeBPData.EvaluateTransitionBP // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class PendulumRuntime.PendulumTransitionNode
// Size: 0xb0 (Inherited: 0xb0)
struct UPendulumTransitionNode : UPendulumBaseNode {
	struct FPendulumNodeHandle FromRuntimeNode; // 0xa8(0x01)
	struct FPendulumNodeHandle ToRuntimeNode; // 0xa9(0x01)
	int32_t EnterNodeTick; // 0xac(0x04)
};

// Class PendulumRuntime.PendulumVariableTableMappingMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPendulumVariableTableMappingMixinLibrary : UObject {

	void TrackGameplayTag(struct FPendulumVariableTableMapping& Mapping, struct FGameplayTag& Tag, bool bIsAuthoredByPendulum, bool bSyncToGAS, bool bSyncFromGAS, enum class PendulumSetEveryFrameMode SetEveryFrameMode); // Function PendulumRuntime.PendulumVariableTableMappingMixinLibrary.TrackGameplayTag // (Final|Native|Static|Private|HasOutParms) // @ game+0x5f9bc30
	void TrackCurve(struct FPendulumVariableTableMapping& Mapping, struct FName CurveName); // Function PendulumRuntime.PendulumVariableTableMappingMixinLibrary.TrackCurve // (Final|Native|Static|Private|HasOutParms) // @ game+0x5f9a520
	int32_t GetCurvePendulumIndex(struct FPendulumVariableTableMapping& Mapping, struct FName CurveName); // Function PendulumRuntime.PendulumVariableTableMappingMixinLibrary.GetCurvePendulumIndex // (Final|Native|Static|Private|HasOutParms) // @ game+0x5f9ef90
	void GenerateResetEveryFrameState(struct FPendulumVariableTableMapping& Mapping); // Function PendulumRuntime.PendulumVariableTableMappingMixinLibrary.GenerateResetEveryFrameState // (Final|Native|Static|Private|HasOutParms) // @ game+0x5f99ca0
};

// Class PendulumRuntime.WeaponInputClaims
// Size: 0xb0 (Inherited: 0xa0)
struct UWeaponInputClaims : USimBaseClass {
	int32_t Time; // 0xa0(0x04)
	bool SelectPrimaryWeapon; // 0xa4(0x01)
	bool SelectSecondaryWeapon; // 0xa5(0x01)
	bool SelectThrowableWeapon; // 0xa6(0x01)
	bool FireDown; // 0xa7(0x01)
	bool FireDownOld; // 0xa8(0x01)
	bool ReloadDown; // 0xa9(0x01)
	bool ReloadDownOld; // 0xaa(0x01)
	char pad_ab[0x5]; // 0xab(0x05)
};

