// Enum EmbarkFXDirector.EEmbarkFXSignificance
enum class EEmbarkFXSignificance : uint8_t {
	None = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	Critical = 4,
	EEmbarkFXSignificance_MAX = 5
};

// Enum EmbarkFXDirector.EEmbarkFXCastShadowQualityThreshold
enum class EEmbarkFXCastShadowQualityThreshold : uint8_t {
	Always = 0,
	MediumAndAbove = 1,
	HighAndAbove = 2,
	EpicAndAbove = 3,
	EEmbarkFXCastShadowQualityThreshold_MAX = 4
};

// Enum EmbarkFXDirector.EEmbarkFXAutoPosition
enum class EEmbarkFXAutoPosition : uint8_t {
	None = 0,
	Snap = 1,
	Interpolate = 2,
	EEmbarkFXAutoPosition_MAX = 3
};

// Enum EmbarkFXDirector.EEmbarkFXAutoPositionFunc
enum class EEmbarkFXAutoPositionFunc : uint8_t {
	Point = 0,
	Average = 1,
	Nearest = 2,
	NearestOnLine = 3,
	NearestOnLineTowardsListenerOrDiscard = 4,
	EEmbarkFXAutoPositionFunc_MAX = 5
};

// Enum EmbarkFXDirector.EEmbarkFXForegroundFlags
enum class EEmbarkFXForegroundFlags : uint8_t {
	None = 0,
	FieldOfView = 1,
	Stencil = 2,
	EEmbarkFXForegroundFlags_MAX = 3
};

// Enum EmbarkFXDirector.EEmbarkFXBinding
enum class EEmbarkFXBinding : uint8_t {
	None = 0,
	Particle = 1,
	ParticleDataChannel = 2,
	Audio = 4,
	All = 7,
	EEmbarkFXBinding_MAX = 8
};

// Enum EmbarkFXDirector.EEmbarkFXFlags
enum class EEmbarkFXFlags : uint8_t {
	None = 0,
	Update = 1,
	Retry = 2,
	Discarded = 4,
	Debug = 8,
	Watch = 16,
	AutoPosition = 32,
	AutoSpatialHash = 64,
	UpdateRotation = 128,
	EEmbarkFXFlags_MAX = 129
};

// Enum EmbarkFXDirector.EEmbarkFXReactivation
enum class EEmbarkFXReactivation : uint8_t {
	DontReactivate = 0,
	ReactivateButDontReset = 1,
	ReactivateAndReset = 2,
	EEmbarkFXReactivation_MAX = 3
};

// Enum EmbarkFXDirector.EEmbarkFXParticleDataChannelFlags
enum class EEmbarkFXParticleDataChannelFlags : uint8_t {
	None = 0,
	VisibleToGame = 1,
	VisibleToCPU = 2,
	VisibleToGPU = 4,
	All = 7,
	EEmbarkFXParticleDataChannelFlags_MAX = 8
};

// ScriptStruct EmbarkFXDirector.EmbarkFXHandle
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkFXHandle {
	int64_t Value; // 0x00(0x08)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXAttachmentParams
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkFXAttachmentParams {
	struct USceneComponent* AttachToComponent; // 0x00(0x08)
	struct FName AttachToName; // 0x08(0x08)
	enum class EAttachLocation AttachLocation; // 0x10(0x01)
	bool bForceWorldRotation; // 0x11(0x01)
	bool bForceWorldScale; // 0x12(0x01)
	char pad_13[0x25]; // 0x13(0x25)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXParticleDataChannelParams
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkFXParticleDataChannelParams {
	struct UNiagaraDataChannelAsset* DataChannel; // 0x00(0x08)
	enum class EEmbarkFXParticleDataChannelFlags DataChannelFlags; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXParticleParams
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkFXParticleParams {
	struct UNiagaraSystem* NiagaraSystem; // 0x00(0x08)
	char Cost; // 0x08(0x01)
	int8_t TranslucentSortPriority; // 0x09(0x01)
	bool bPreCullCheck; // 0x0a(0x01)
	bool bCastShadow; // 0x0b(0x01)
	enum class EEmbarkFXCastShadowQualityThreshold CastShadowQualityThreshold; // 0x0c(0x01)
	bool bCanAttach; // 0x0d(0x01)
	bool bForceTickLast; // 0x0e(0x01)
	bool bPreOcclusionCull; // 0x0f(0x01)
	uint16_t PreOcclusionCullRadius; // 0x10(0x02)
	uint16_t PreOcclusionCullMinDistance; // 0x12(0x02)
	uint16_t PreOcclusionCullMaxDistance; // 0x14(0x02)
	char pad_16[0x2]; // 0x16(0x02)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXAudioParams
// Size: 0x58 (Inherited: 0x00)
struct FEmbarkFXAudioParams {
	struct USoundBase* Sound; // 0x00(0x08)
	struct USoundAttenuation* AttenuationSettings; // 0x08(0x08)
	struct USoundConcurrency* ConcurrencySettings; // 0x10(0x08)
	struct USoundClass* SoundClassOverride; // 0x18(0x08)
	struct FVector WorldLocationOffset; // 0x20(0x18)
	float VolumeMultiplier; // 0x38(0x04)
	float PitchMultiplier; // 0x3c(0x04)
	float StartTime; // 0x40(0x04)
	float FadeInSeconds; // 0x44(0x04)
	bool bStopWhenOwnerDestroyed; // 0x48(0x01)
	bool bCanAttach; // 0x49(0x01)
	bool bAllowSpatialization; // 0x4a(0x01)
	bool bIsUISound; // 0x4b(0x01)
	bool bIgnoreForFlushing; // 0x4c(0x01)
	char pad_4d[0x3]; // 0x4d(0x03)
	float OcclusionCheckInterval; // 0x50(0x04)
	float LowPassFilterFreq; // 0x54(0x04)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXDecalParams
// Size: 0x58 (Inherited: 0x00)
struct FEmbarkFXDecalParams {
	struct UMaterialInterface* Material; // 0x00(0x08)
	struct FVector DecalSize; // 0x08(0x18)
	float LifeTimeSeconds; // 0x20(0x04)
	float FadeInTime; // 0x24(0x04)
	float FadeOutTime; // 0x28(0x04)
	float FadeScreenSize; // 0x2c(0x04)
	float RandomScaleFactor; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FRotator DecalRotation; // 0x38(0x18)
	bool bRandomRotation; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXCallbackParams
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkFXCallbackParams {
	struct UObject* Object; // 0x00(0x08)
	struct FName FunctionName; // 0x08(0x08)
	int64_t UserData; // 0x10(0x08)
	bool bAsyncTask; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXCameraShakeParams
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkFXCameraShakeParams {
	bool bOrientShakeTowardsEpicenter; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	ClassPtrProperty CameraShakeClass; // 0x08(0x08)
	float CameraShakeInnerRadius; // 0x10(0x04)
	float CameraShakeOuterRadius; // 0x14(0x04)
	float Falloff; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXForceFeedbackParams
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkFXForceFeedbackParams {
	struct UForceFeedbackEffect* ForceFeedbackEffect; // 0x00(0x08)
	struct UForceFeedbackAttenuation* ForceFeedbackAttenuation; // 0x08(0x08)
	bool bLooping; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float IntensityMultiplier; // 0x14(0x04)
	float StartTime; // 0x18(0x04)
	bool bAttachToComponent; // 0x1c(0x01)
	bool bStopWhenAttachedToDestroyed; // 0x1d(0x01)
	bool bAutoDestroy; // 0x1e(0x01)
	char pad_1f[0x1]; // 0x1f(0x01)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXStopParams
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkFXStopParams {
	bool bNiagaraImmediate; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FadeOutSeconds; // 0x04(0x04)
	float AudioFadeOutVolume; // 0x08(0x04)
	enum class EAudioFaderCurve AudioFadeOutCurve; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXCue
// Size: 0x2f0 (Inherited: 0x00)
struct FEmbarkFXCue {
	struct FEmbarkFXHandle Handle; // 0x00(0x08)
	struct UObject* TickPrerequisite; // 0x08(0x08)
	char pad_10[0x10]; // 0x10(0x10)
	struct FVector Location; // 0x20(0x18)
	struct FRotator Rotation; // 0x38(0x18)
	struct FVector Scale; // 0x50(0x18)
	float StartTimeSeconds; // 0x68(0x04)
	float RelevantTimeSeconds; // 0x6c(0x04)
	float SignificanceDecayDistance; // 0x70(0x04)
	enum class EEmbarkFXSignificance Significance; // 0x74(0x01)
	char pad_75[0xb]; // 0x75(0x0b)
	int32_t HeatmapID; // 0x80(0x04)
	enum class EEmbarkFXReactivation Reactivate; // 0x84(0x01)
	char pad_85[0x26b]; // 0x85(0x26b)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXDirectorHeatmap
// Size: 0x70 (Inherited: 0x00)
struct FEmbarkFXDirectorHeatmap {
	struct FName Name; // 0x00(0x08)
	float CellSize; // 0x08(0x04)
	float DecayTimeSeconds; // 0x0c(0x04)
	float ClampAndNormalize; // 0x10(0x04)
	struct FName ParameterName; // 0x14(0x08)
	bool bCullCue; // 0x1c(0x01)
	char pad_1d[0x53]; // 0x1d(0x53)
};

// ScriptStruct EmbarkFXDirector.EmbarkFXDirectorContext
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkFXDirectorContext {
	struct UEmbarkFXDirector* FXDirector; // 0x00(0x08)
	struct FName DefaultHeatmapAffinity; // 0x08(0x08)
	char pad_10[0x28]; // 0x10(0x28)
};

