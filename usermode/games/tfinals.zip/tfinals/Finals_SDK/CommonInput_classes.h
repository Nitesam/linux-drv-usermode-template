// Class CommonInput.CommonInputActionDomain
// Size: 0xb0 (Inherited: 0xa0)
struct UCommonInputActionDomain : UDataAsset {
	enum class ECommonInputEventFlowBehavior Behavior; // 0xa0(0x04)
	enum class ECommonInputEventFlowBehavior InnerBehavior; // 0xa4(0x04)
	bool bUseActionDomainDesiredInputConfig; // 0xa8(0x01)
	enum class ECommonInputMode InputMode; // 0xa9(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0xaa(0x01)
	char pad_ab[0x5]; // 0xab(0x05)
};

// Class CommonInput.CommonInputActionDomainTable
// Size: 0xc0 (Inherited: 0xa0)
struct UCommonInputActionDomainTable : UDataAsset {
	struct TArray<struct UCommonInputActionDomain*> ActionDomains; // 0xa0(0x10)
	enum class ECommonInputMode InputMode; // 0xb0(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0xb1(0x01)
	char pad_b2[0xe]; // 0xb2(0x0e)
};

// Class CommonInput.CommonUIInputData
// Size: 0xf0 (Inherited: 0xa0)
struct UCommonUIInputData : UObject {
	struct FDataTableRowHandle DefaultClickAction; // 0x98(0x10)
	struct FDataTableRowHandle DefaultBackAction; // 0xa8(0x10)
	struct TSoftClassPtr<UObject> DefaultHoldData; // 0xb8(0x28)
	struct UInputAction* EnhancedInputClickAction; // 0xe0(0x08)
	struct UInputAction* EnhancedInputBackAction; // 0xe8(0x08)
};

// Class CommonInput.CommonUIHoldData
// Size: 0xb0 (Inherited: 0xa0)
struct UCommonUIHoldData : UObject {
	struct FInputHoldData KeyboardAndMouse; // 0x98(0x08)
	struct FInputHoldData Gamepad; // 0xa0(0x08)
	struct FInputHoldData Touch; // 0xa8(0x08)
};

// Class CommonInput.CommonInputBaseControllerData
// Size: 0x170 (Inherited: 0xa0)
struct UCommonInputBaseControllerData : UObject {
	enum class ECommonInputType InputType; // 0x98(0x01)
	struct FName GamepadName; // 0x9c(0x08)
	struct FText GamepadDisplayName; // 0xa8(0x18)
	struct FText GamepadCategory; // 0xc0(0x18)
	struct FText GamepadPlatformName; // 0xd8(0x18)
	struct TArray<struct FInputDeviceIdentifierPair> GamepadHardwareIdMapping; // 0xf0(0x10)
	struct TSoftObjectPtr<UTexture2D> ControllerTexture; // 0x100(0x28)
	struct TSoftObjectPtr<UTexture2D> ControllerButtonMaskTexture; // 0x128(0x28)
	struct TArray<struct FCommonInputKeyBrushConfiguration> InputBrushDataMap; // 0x150(0x10)
	struct TArray<struct FCommonInputKeySetBrushConfiguration> InputBrushKeySets; // 0x160(0x10)

	struct TArray<struct FName> GetRegisteredGamepads(); // Function CommonInput.CommonInputBaseControllerData.GetRegisteredGamepads // (Final|Native|Static|Public) // @ game+0x5027450
};

// Class CommonInput.CommonInputPlatformSettings
// Size: 0xe0 (Inherited: 0xb0)
struct UCommonInputPlatformSettings : UPlatformSettings {
	enum class ECommonInputType DefaultInputType; // 0xb0(0x01)
	bool bSupportsMouseAndKeyboard; // 0xb1(0x01)
	bool bSupportsTouch; // 0xb2(0x01)
	bool bSupportsGamepad; // 0xb3(0x01)
	struct FName DefaultGamepadName; // 0xb4(0x08)
	bool bCanChangeGamepadType; // 0xbc(0x01)
	char pad_bd[0x3]; // 0xbd(0x03)
	struct TArray<struct TSoftClassPtr<UObject>> ControllerData; // 0xc0(0x10)
	struct TArray<struct UCommonInputBaseControllerData*> ControllerDataClasses; // 0xd0(0x10)
};

// Class CommonInput.CommonInputSettings
// Size: 0x190 (Inherited: 0xb0)
struct UCommonInputSettings : UDeveloperSettings {
	struct TSoftClassPtr<UObject> InputData; // 0xa8(0x28)
	struct FPerPlatformSettings PlatformInput; // 0xd0(0x10)
	struct TMap<struct FName, struct FCommonInputPlatformBaseData> CommonInputPlatformData; // 0xe0(0x50)
	bool bEnableInputMethodThrashingProtection; // 0x130(0x01)
	int32_t InputMethodThrashingLimit; // 0x134(0x04)
	double InputMethodThrashingWindowInSeconds; // 0x138(0x08)
	double InputMethodThrashingCooldownInSeconds; // 0x140(0x08)
	bool bAllowOutOfFocusDeviceInput; // 0x148(0x01)
	bool bEnableDefaultInputConfig; // 0x149(0x01)
	bool bEnableEnhancedInputSupport; // 0x14a(0x01)
	struct TSoftObjectPtr<UCommonInputActionDomainTable> ActionDomainTable; // 0x150(0x28)
	char pad_178[0x8]; // 0x178(0x08)
	struct UCommonUIInputData* InputDataClass; // 0x180(0x08)
	struct UCommonInputActionDomainTable* ActionDomainTablePtr; // 0x188(0x08)

	bool IsEnhancedInputSupportEnabled(); // Function CommonInput.CommonInputSettings.IsEnhancedInputSupportEnabled // (Final|Native|Static|Public) // @ game+0x5030270
};

// Class CommonInput.CommonInputSubsystem
// Size: 0x190 (Inherited: 0xa0)
struct UCommonInputSubsystem : ULocalPlayerSubsystem {
	char pad_a0[0x38]; // 0xa0(0x38)
	struct FMulticastInlineDelegate OnInputMethodChanged; // 0xd8(0x10)
	int32_t NumberOfInputMethodChangesRecently; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
	double LastInputMethodChangeTime; // 0xf0(0x08)
	double LastTimeInputMethodThrashingBegan; // 0xf8(0x08)
	enum class ECommonInputType LastInputType; // 0x100(0x01)
	enum class ECommonInputType CurrentInputType; // 0x101(0x01)
	char pad_102[0x2]; // 0x102(0x02)
	struct FName GamepadInputType; // 0x104(0x08)
	char pad_10c[0x4]; // 0x10c(0x04)
	struct TMap<struct FName, enum class ECommonInputType> CurrentInputLocks; // 0x110(0x50)
	char pad_160[0x8]; // 0x160(0x08)
	struct UCommonInputActionDomainTable* ActionDomainTable; // 0x168(0x08)
	bool bIsGamepadSimulatedClick; // 0x170(0x01)
	char pad_171[0x1f]; // 0x171(0x1f)

	bool ShouldShowInputKeys(); // Function CommonInput.CommonInputSubsystem.ShouldShowInputKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5031740
	void SetGamepadInputType(struct FName InGamepadInputType); // Function CommonInput.CommonInputSubsystem.SetGamepadInputType // (Final|Native|Public|BlueprintCallable) // @ game+0x5026970
	void SetCurrentInputType(enum class ECommonInputType NewInputType); // Function CommonInput.CommonInputSubsystem.SetCurrentInputType // (Final|Native|Public|BlueprintCallable) // @ game+0x5031310
	bool IsUsingPointerInput(); // Function CommonInput.CommonInputSubsystem.IsUsingPointerInput // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5030030
	bool IsInputMethodActive(enum class ECommonInputType InputMethod); // Function CommonInput.CommonInputSubsystem.IsInputMethodActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5030560
	enum class ECommonInputType GetDefaultInputType(); // Function CommonInput.CommonInputSubsystem.GetDefaultInputType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x502ca10
	enum class ECommonInputType GetCurrentInputType(); // Function CommonInput.CommonInputSubsystem.GetCurrentInputType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x502a160
	struct FName GetCurrentGamepadName(); // Function CommonInput.CommonInputSubsystem.GetCurrentGamepadName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5030050
	void BroadcastInputMethodChanged(); // Function CommonInput.CommonInputSubsystem.BroadcastInputMethodChanged // (Final|Native|Protected) // @ game+0x502c060
};

