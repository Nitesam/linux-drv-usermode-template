// Class StreamlineBlueprint.StreamlineLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UStreamlineLibrary : UBlueprintFunctionLibrary {

	enum class EStreamlineFeatureSupport QueryStreamlineFeatureSupport(enum class EStreamlineFeature Feature); // Function StreamlineBlueprint.StreamlineLibrary.QueryStreamlineFeatureSupport // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c1da0
	bool IsStreamlineFeatureSupported(enum class EStreamlineFeature Feature); // Function StreamlineBlueprint.StreamlineLibrary.IsStreamlineFeatureSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c2710
	struct FStreamlineFeatureRequirements GetStreamlineFeatureInformation(enum class EStreamlineFeature Feature); // Function StreamlineBlueprint.StreamlineLibrary.GetStreamlineFeatureInformation // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c2090
	void BreakStreamlineFeatureRequirements(enum class EStreamlineFeatureRequirementsFlags Requirements, bool& D3D11Supported, bool& D3D12Supported, bool& VulkanSupported, bool& VSyncOffRequired, bool& HardwareSchedulingRequired); // Function StreamlineBlueprint.StreamlineLibrary.BreakStreamlineFeatureRequirements // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x54c1390
};

