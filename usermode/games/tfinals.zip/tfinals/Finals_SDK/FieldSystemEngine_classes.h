// Class FieldSystemEngine.FieldSystemActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AFieldSystemActor : AActor {
	struct UFieldSystemComponent* FieldSystemComponent; // 0x398(0x08)
};

// Class FieldSystemEngine.FieldSystem
// Size: 0xb0 (Inherited: 0xa0)
struct UFieldSystem : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class FieldSystemEngine.FieldSystemComponent
// Size: 0x790 (Inherited: 0x6c0)
struct UFieldSystemComponent : UPrimitiveComponent {
	struct UFieldSystem* FieldSystem; // 0x6b8(0x08)
	bool bIsWorldField; // 0x6c0(0x01)
	bool bIsChaosField; // 0x6c1(0x01)
	struct TArray<struct TSoftObjectPtr<AChaosSolverActor>> SupportedSolvers; // 0x6c8(0x10)
	struct FFieldObjectCommands ConstructionCommands; // 0x6d8(0x30)
	struct FFieldObjectCommands BufferCommands; // 0x708(0x30)
	char pad_73a[0x56]; // 0x73a(0x56)

	void ResetFieldSystem(); // Function FieldSystemEngine.FieldSystemComponent.ResetFieldSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2563d70
	void RemovePersistentFields(); // Function FieldSystemEngine.FieldSystemComponent.RemovePersistentFields // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2562b80
	void ApplyUniformVectorFalloffForce(bool Enabled, struct FVector Position, struct FVector Direction, float Radius, float Magnitude); // Function FieldSystemEngine.FieldSystemComponent.ApplyUniformVectorFalloffForce // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2560a10
	void ApplyStrainField(bool Enabled, struct FVector Position, float Radius, float Magnitude, int32_t Iterations); // Function FieldSystemEngine.FieldSystemComponent.ApplyStrainField // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x255d430
	void ApplyStayDynamicField(bool Enabled, struct FVector Position, float Radius); // Function FieldSystemEngine.FieldSystemComponent.ApplyStayDynamicField // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x25608a0
	void ApplyRadialVectorFalloffForce(bool Enabled, struct FVector Position, float Radius, float Magnitude); // Function FieldSystemEngine.FieldSystemComponent.ApplyRadialVectorFalloffForce // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2558d30
	void ApplyRadialForce(bool Enabled, struct FVector Position, float Magnitude); // Function FieldSystemEngine.FieldSystemComponent.ApplyRadialForce // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x255e980
	void ApplyPhysicsField(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Function FieldSystemEngine.FieldSystemComponent.ApplyPhysicsField // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2560fd0
	void ApplyLinearForce(bool Enabled, struct FVector Direction, float Magnitude); // Function FieldSystemEngine.FieldSystemComponent.ApplyLinearForce // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x25671d0
	void AddPersistentField(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Function FieldSystemEngine.FieldSystemComponent.AddPersistentField // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2562db0
	void AddFieldCommand(bool Enabled, enum class EFieldPhysicsType Target, struct UFieldSystemMetaData* MetaData, struct UFieldNodeBase* Field); // Function FieldSystemEngine.FieldSystemComponent.AddFieldCommand // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x255cef0
};

// Class FieldSystemEngine.FieldSystemMetaData
// Size: 0x160 (Inherited: 0x160)
struct UFieldSystemMetaData : UActorComponent {
};

// Class FieldSystemEngine.FieldSystemMetaDataIteration
// Size: 0x160 (Inherited: 0x160)
struct UFieldSystemMetaDataIteration : UFieldSystemMetaData {
	int32_t Iterations; // 0x158(0x04)

	struct UFieldSystemMetaDataIteration* SetMetaDataIteration(int32_t Iterations); // Function FieldSystemEngine.FieldSystemMetaDataIteration.SetMetaDataIteration // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2563270
};

// Class FieldSystemEngine.FieldSystemMetaDataProcessingResolution
// Size: 0x160 (Inherited: 0x160)
struct UFieldSystemMetaDataProcessingResolution : UFieldSystemMetaData {
	enum class EFieldResolutionType ResolutionType; // 0x158(0x01)

	struct UFieldSystemMetaDataProcessingResolution* SetMetaDataaProcessingResolutionType(enum class EFieldResolutionType ResolutionType); // Function FieldSystemEngine.FieldSystemMetaDataProcessingResolution.SetMetaDataaProcessingResolutionType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2565670
};

// Class FieldSystemEngine.FieldSystemMetaDataFilter
// Size: 0x160 (Inherited: 0x160)
struct UFieldSystemMetaDataFilter : UFieldSystemMetaData {
	enum class EFieldFilterType FilterType; // 0x158(0x01)
	enum class EFieldObjectType ObjectType; // 0x159(0x01)
	enum class EFieldPositionType PositionType; // 0x15a(0x01)

	struct UFieldSystemMetaDataFilter* SetMetaDataFilterType(enum class EFieldFilterType FilterType, enum class EFieldObjectType ObjectType, enum class EFieldPositionType PositionType); // Function FieldSystemEngine.FieldSystemMetaDataFilter.SetMetaDataFilterType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2564640
};

// Class FieldSystemEngine.FieldNodeBase
// Size: 0x160 (Inherited: 0x160)
struct UFieldNodeBase : UActorComponent {
};

// Class FieldSystemEngine.FieldNodeInt
// Size: 0x160 (Inherited: 0x160)
struct UFieldNodeInt : UFieldNodeBase {
};

// Class FieldSystemEngine.FieldNodeFloat
// Size: 0x160 (Inherited: 0x160)
struct UFieldNodeFloat : UFieldNodeBase {
};

// Class FieldSystemEngine.FieldNodeVector
// Size: 0x160 (Inherited: 0x160)
struct UFieldNodeVector : UFieldNodeBase {
};

// Class FieldSystemEngine.UniformInteger
// Size: 0x160 (Inherited: 0x160)
struct UUniformInteger : UFieldNodeInt {
	int32_t Magnitude; // 0x158(0x04)

	struct UUniformInteger* SetUniformInteger(int32_t Magnitude); // Function FieldSystemEngine.UniformInteger.SetUniformInteger // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2563270
};

// Class FieldSystemEngine.RadialIntMask
// Size: 0x190 (Inherited: 0x160)
struct URadialIntMask : UFieldNodeInt {
	float Radius; // 0x158(0x04)
	struct FVector Position; // 0x160(0x18)
	int32_t InteriorValue; // 0x178(0x04)
	int32_t ExteriorValue; // 0x17c(0x04)
	enum class ESetMaskConditionType SetMaskCondition; // 0x180(0x01)
	char pad_185[0xb]; // 0x185(0x0b)

	struct URadialIntMask* SetRadialIntMask(float Radius, struct FVector Position, int32_t InteriorValue, int32_t ExteriorValue, enum class ESetMaskConditionType SetMaskConditionIn); // Function FieldSystemEngine.RadialIntMask.SetRadialIntMask // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x255a0b0
};

// Class FieldSystemEngine.UniformScalar
// Size: 0x160 (Inherited: 0x160)
struct UUniformScalar : UFieldNodeFloat {
	float Magnitude; // 0x158(0x04)

	struct UUniformScalar* SetUniformScalar(float Magnitude); // Function FieldSystemEngine.UniformScalar.SetUniformScalar // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x255d0b0
};

// Class FieldSystemEngine.WaveScalar
// Size: 0x190 (Inherited: 0x160)
struct UWaveScalar : UFieldNodeFloat {
	float Magnitude; // 0x158(0x04)
	struct FVector Position; // 0x160(0x18)
	float Wavelength; // 0x178(0x04)
	float Period; // 0x17c(0x04)
	enum class EWaveFunctionType Function; // 0x180(0x01)
	enum class EFieldFalloffType Falloff; // 0x181(0x01)
	char pad_186[0xa]; // 0x186(0x0a)

	struct UWaveScalar* SetWaveScalar(float Magnitude, struct FVector Position, float Wavelength, float Period, float Time, enum class EWaveFunctionType Function, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.WaveScalar.SetWaveScalar // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2563550
};

// Class FieldSystemEngine.RadialFalloff
// Size: 0x190 (Inherited: 0x160)
struct URadialFalloff : UFieldNodeFloat {
	float Magnitude; // 0x158(0x04)
	float MinRange; // 0x15c(0x04)
	float MaxRange; // 0x160(0x04)
	float Default; // 0x164(0x04)
	float Radius; // 0x168(0x04)
	struct FVector Position; // 0x170(0x18)
	enum class EFieldFalloffType Falloff; // 0x188(0x01)
	char pad_18d[0x3]; // 0x18d(0x03)

	struct URadialFalloff* SetRadialFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Radius, struct FVector Position, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.RadialFalloff.SetRadialFalloff // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x255efe0
};

// Class FieldSystemEngine.PlaneFalloff
// Size: 0x1b0 (Inherited: 0x160)
struct UPlaneFalloff : UFieldNodeFloat {
	float Magnitude; // 0x158(0x04)
	float MinRange; // 0x15c(0x04)
	float MaxRange; // 0x160(0x04)
	float Default; // 0x164(0x04)
	float Distance; // 0x168(0x04)
	struct FVector Position; // 0x170(0x18)
	struct FVector Normal; // 0x188(0x18)
	enum class EFieldFalloffType Falloff; // 0x1a0(0x01)
	char pad_1a5[0xb]; // 0x1a5(0x0b)

	struct UPlaneFalloff* SetPlaneFalloff(float Magnitude, float MinRange, float MaxRange, float Default, float Distance, struct FVector Position, struct FVector Normal, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.PlaneFalloff.SetPlaneFalloff // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2557650
};

// Class FieldSystemEngine.BoxFalloff
// Size: 0x1e0 (Inherited: 0x160)
struct UBoxFalloff : UFieldNodeFloat {
	float Magnitude; // 0x158(0x04)
	float MinRange; // 0x15c(0x04)
	float MaxRange; // 0x160(0x04)
	float Default; // 0x164(0x04)
	struct FTransform Transform; // 0x170(0x60)
	enum class EFieldFalloffType Falloff; // 0x1d0(0x01)
	char pad_1d1[0xf]; // 0x1d1(0x0f)

	struct UBoxFalloff* SetBoxFalloff(float Magnitude, float MinRange, float MaxRange, float Default, struct FTransform Transform, enum class EFieldFalloffType Falloff); // Function FieldSystemEngine.BoxFalloff.SetBoxFalloff // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2565d80
};

// Class FieldSystemEngine.NoiseField
// Size: 0x1c0 (Inherited: 0x160)
struct UNoiseField : UFieldNodeFloat {
	float MinRange; // 0x158(0x04)
	float MaxRange; // 0x15c(0x04)
	struct FTransform Transform; // 0x160(0x60)

	struct UNoiseField* SetNoiseField(float MinRange, float MaxRange, struct FTransform Transform); // Function FieldSystemEngine.NoiseField.SetNoiseField // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x2559090
};

// Class FieldSystemEngine.UniformVector
// Size: 0x180 (Inherited: 0x160)
struct UUniformVector : UFieldNodeVector {
	float Magnitude; // 0x158(0x04)
	struct FVector Direction; // 0x160(0x18)
	char pad_17c[0x4]; // 0x17c(0x04)

	struct UUniformVector* SetUniformVector(float Magnitude, struct FVector Direction); // Function FieldSystemEngine.UniformVector.SetUniformVector // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x255a4b0
};

// Class FieldSystemEngine.RadialVector
// Size: 0x180 (Inherited: 0x160)
struct URadialVector : UFieldNodeVector {
	float Magnitude; // 0x158(0x04)
	struct FVector Position; // 0x160(0x18)
	char pad_17c[0x4]; // 0x17c(0x04)

	struct URadialVector* SetRadialVector(float Magnitude, struct FVector Position); // Function FieldSystemEngine.RadialVector.SetRadialVector // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x255a4b0
};

// Class FieldSystemEngine.RandomVector
// Size: 0x160 (Inherited: 0x160)
struct URandomVector : UFieldNodeVector {
	float Magnitude; // 0x158(0x04)

	struct URandomVector* SetRandomVector(float Magnitude); // Function FieldSystemEngine.RandomVector.SetRandomVector // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x255d0b0
};

// Class FieldSystemEngine.OperatorField
// Size: 0x180 (Inherited: 0x160)
struct UOperatorField : UFieldNodeBase {
	float Magnitude; // 0x158(0x04)
	struct UFieldNodeBase* RightField; // 0x160(0x08)
	struct UFieldNodeBase* LeftField; // 0x168(0x08)
	enum class EFieldOperationType Operation; // 0x170(0x01)
	char pad_175[0xb]; // 0x175(0x0b)

	struct UOperatorField* SetOperatorField(float Magnitude, struct UFieldNodeBase* LeftField, struct UFieldNodeBase* RightField, enum class EFieldOperationType Operation); // Function FieldSystemEngine.OperatorField.SetOperatorField // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x25571a0
};

// Class FieldSystemEngine.ToIntegerField
// Size: 0x160 (Inherited: 0x160)
struct UToIntegerField : UFieldNodeInt {
	struct UFieldNodeFloat* FloatField; // 0x158(0x08)

	struct UToIntegerField* SetToIntegerField(struct UFieldNodeFloat* FloatField); // Function FieldSystemEngine.ToIntegerField.SetToIntegerField // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x25575a0
};

// Class FieldSystemEngine.ToFloatField
// Size: 0x160 (Inherited: 0x160)
struct UToFloatField : UFieldNodeFloat {
	struct UFieldNodeInt* IntField; // 0x158(0x08)

	struct UToFloatField* SetToFloatField(struct UFieldNodeInt* IntegerField); // Function FieldSystemEngine.ToFloatField.SetToFloatField // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x25575a0
};

// Class FieldSystemEngine.CullingField
// Size: 0x170 (Inherited: 0x160)
struct UCullingField : UFieldNodeBase {
	struct UFieldNodeBase* Culling; // 0x158(0x08)
	struct UFieldNodeBase* Field; // 0x160(0x08)
	enum class EFieldCullingOperationType Operation; // 0x168(0x01)

	struct UCullingField* SetCullingField(struct UFieldNodeBase* Culling, struct UFieldNodeBase* Field, enum class EFieldCullingOperationType Operation); // Function FieldSystemEngine.CullingField.SetCullingField // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2563ac0
};

// Class FieldSystemEngine.ReturnResultsTerminal
// Size: 0x160 (Inherited: 0x160)
struct UReturnResultsTerminal : UFieldNodeBase {

	struct UReturnResultsTerminal* SetReturnResultsTerminal(); // Function FieldSystemEngine.ReturnResultsTerminal.SetReturnResultsTerminal // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x25675b0
};

