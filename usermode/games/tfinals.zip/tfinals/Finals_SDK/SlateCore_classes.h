// Class SlateCore.SlateWidgetStyleAsset
// Size: 0xa0 (Inherited: 0xa0)
struct USlateWidgetStyleAsset : UObject {
	struct USlateWidgetStyleContainerBase* CustomStyle; // 0x98(0x08)
};

// Class SlateCore.FontBulkData
// Size: 0xf0 (Inherited: 0xa0)
struct UFontBulkData : UObject {
	char pad_a0[0x50]; // 0xa0(0x50)
};

// Class SlateCore.FontFaceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UFontFaceInterface : UInterface {
};

// Class SlateCore.FontProviderInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UFontProviderInterface : UInterface {
};

// Class SlateCore.SlateTypes
// Size: 0xa0 (Inherited: 0xa0)
struct USlateTypes : UObject {
};

// Class SlateCore.SlateWidgetStyleContainerBase
// Size: 0xa0 (Inherited: 0xa0)
struct USlateWidgetStyleContainerBase : UObject {
};

// Class SlateCore.SlateWidgetStyleContainerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct USlateWidgetStyleContainerInterface : UInterface {
};

// Class SlateCore.SlateThemeManager
// Size: 0xa30 (Inherited: 0xa0)
struct USlateThemeManager : UObject {
	struct FGuid CurrentThemeId; // 0x98(0x10)
	struct FStyleColorList ActiveColors; // 0xa8(0x988)
};

