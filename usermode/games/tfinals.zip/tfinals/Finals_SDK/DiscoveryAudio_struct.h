// Enum DiscoveryAudio.EAsyncOperationState
enum class EAsyncOperationState : uint8_t {
	InProgress = 0,
	Succeeded = 1,
	Failed = 2,
	Cancelled = 3,
	TimedOut = 4,
	EAsyncOperationState_MAX = 5
};

// Enum DiscoveryAudio.EDynamicCommentaryAudioContainer
enum class EDynamicCommentaryAudioContainer : uint8_t {
	Unknown = 0,
	Ogg = 1,
	Wav = 2,
	EDynamicCommentaryAudioContainer_MAX = 3
};

// ScriptStruct DiscoveryAudio.DynamicCommentaryConfig
// Size: 0x40 (Inherited: 0x00)
struct FDynamicCommentaryConfig {
	struct FString OpenAIModel; // 0x00(0x10)
	float Temperature; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString ElevenLabsModel; // 0x18(0x10)
	struct FString VoiceId; // 0x28(0x10)
	enum class EApiGatewayDiscoveryServerDynamicCommentaryAudioOutputFormat OutputFormat; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float TimeoutSeconds; // 0x3c(0x04)
};

// ScriptStruct DiscoveryAudio.DynamicCommentaryResult
// Size: 0x20 (Inherited: 0x00)
struct FDynamicCommentaryResult {
	struct FString GeneratedText; // 0x00(0x10)
	struct FString AudioUrl; // 0x10(0x10)
};

// ScriptStruct DiscoveryAudio.AudioDownloadFuture
// Size: 0x10 (Inherited: 0x00)
struct FAudioDownloadFuture {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct DiscoveryAudio.DynamicCommentaryFuture
// Size: 0x10 (Inherited: 0x00)
struct FDynamicCommentaryFuture {
	char pad_0[0x10]; // 0x00(0x10)
};

