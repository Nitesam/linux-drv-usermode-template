// Class ModelingOperators.RecomputeUVsToolProperties
// Size: 0x150 (Inherited: 0x120)
struct URecomputeUVsToolProperties : UInteractiveToolPropertySet {
	bool bEnablePolygroupSupport; // 0x118(0x01)
	enum class ERecomputeUVsPropertiesIslandMode IslandGeneration; // 0x11c(0x04)
	enum class ERecomputeUVsPropertiesUnwrapType UnwrapType; // 0x120(0x04)
	enum class ERecomputeUVsToolOrientationMode AutoRotation; // 0x124(0x04)
	bool bPreserveIrregularity; // 0x128(0x01)
	int32_t SmoothingSteps; // 0x12c(0x04)
	float SmoothingAlpha; // 0x130(0x04)
	float MergingDistortionThreshold; // 0x134(0x04)
	float MergingAngleThreshold; // 0x138(0x04)
	enum class ERecomputeUVsPropertiesLayoutType LayoutType; // 0x13c(0x04)
	int32_t TextureResolution; // 0x140(0x04)
	float NormalizeScale; // 0x144(0x04)
	bool bEnableUDIMLayout; // 0x148(0x01)
	bool bUDIMCVAREnabled; // 0x149(0x01)
	char pad_14c[0x4]; // 0x14c(0x04)
};

// Class ModelingOperators.UVLayoutProperties
// Size: 0x140 (Inherited: 0x120)
struct UUVLayoutProperties : UInteractiveToolPropertySet {
	enum class EUVLayoutType LayoutType; // 0x118(0x04)
	int32_t TextureResolution; // 0x11c(0x04)
	float Scale; // 0x120(0x04)
	struct FVector2D Translation; // 0x128(0x10)
	bool bAllowFlips; // 0x138(0x01)
	bool bEnableUDIMLayout; // 0x139(0x01)
	bool bUDIMCVAREnabled; // 0x13a(0x01)
	char pad_13f[0x1]; // 0x13f(0x01)
};

// Class ModelingOperators.RecomputeUVsOpFactory
// Size: 0x1b0 (Inherited: 0xa0)
struct URecomputeUVsOpFactory : UObject {
	struct URecomputeUVsToolProperties* Settings; // 0xa0(0x08)
	char pad_a8[0x108]; // 0xa8(0x108)
};

// Class ModelingOperators.UVLayoutOperatorFactory
// Size: 0x210 (Inherited: 0xa0)
struct UUVLayoutOperatorFactory : UObject {
	struct UUVLayoutProperties* Settings; // 0xa0(0x08)
	char pad_a8[0x168]; // 0xa8(0x168)
};

