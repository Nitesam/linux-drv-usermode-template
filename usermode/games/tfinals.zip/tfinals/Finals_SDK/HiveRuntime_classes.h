// Class HiveRuntime.ActuatorBase
// Size: 0xd0 (Inherited: 0xd0)
struct UActuatorBase : UReplicatedSubobject {
	bool bUseActionsOverride; // 0xc8(0x01)
	bool bUseOverrideForces; // 0xc9(0x01)
	bool bUseFilteredTarget; // 0xca(0x01)
	bool bDrawJointSpaces; // 0xcb(0x01)
	bool bIsEnabled; // 0xcc(0x01)

	void UpdatePhysics(float DeltaSeconds); // Function HiveRuntime.ActuatorBase.UpdatePhysics // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void UpdateForces(float DeltaSeconds); // Function HiveRuntime.ActuatorBase.UpdateForces // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void UpdateFilter(float DeltaSeconds, enum class EMLFilterType FilterType, float FilterTimeHorizon); // Function HiveRuntime.ActuatorBase.UpdateFilter // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ShowDebugInfo(float DeltaSeconds); // Function HiveRuntime.ActuatorBase.ShowDebugInfo // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void OnEnable(); // Function HiveRuntime.ActuatorBase.OnEnable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDisable(); // Function HiveRuntime.ActuatorBase.OnDisable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ObserveState(struct UObservationSet* Observation); // Function HiveRuntime.ActuatorBase.ObserveState // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct FName GetActuatorName(); // Function HiveRuntime.ActuatorBase.GetActuatorName // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	int32_t GetActionCount(); // Function HiveRuntime.ActuatorBase.GetActionCount // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void ExtractActions(struct TArray<float>& Actions, int32_t& Offset, float ActionDeltaDeadZone); // Function HiveRuntime.ActuatorBase.ExtractActions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void CollectLimitsAndEnable(); // Function HiveRuntime.ActuatorBase.CollectLimitsAndEnable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class HiveRuntime.MLEffectorState
// Size: 0xa0 (Inherited: 0xa0)
struct UMLEffectorState : UObject {
};

// Class HiveRuntime.MLEffector
// Size: 0xb0 (Inherited: 0xa0)
struct UMLEffector : UObject {
	bool bIsEnabled; // 0x98(0x01)
	struct TArray<struct FMLEffectorModifierItem> Modifiers; // 0xa0(0x10)

	void RemoveModifier(struct UMLEffectorModifier* Modifier); // Function HiveRuntime.MLEffector.RemoveModifier // (Final|Native|Public) // @ game+0x902f980
	void Execute(); // Function HiveRuntime.MLEffector.Execute // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ApplyModifiers(struct UMLEffectorState* State); // Function HiveRuntime.MLEffector.ApplyModifiers // (Final|Native|Protected) // @ game+0x902f180
	void AddModifier(struct UMLEffectorModifier* Modifier, int32_t Priority); // Function HiveRuntime.MLEffector.AddModifier // (Final|Native|Public) // @ game+0x9025ce0
};

// Class HiveRuntime.MLEffectorModifier
// Size: 0xa0 (Inherited: 0xa0)
struct UMLEffectorModifier : UObject {

	void Apply(struct UMLEffectorState* State); // Function HiveRuntime.MLEffectorModifier.Apply // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class HiveRuntime.MLInspectorPolicyComponent
// Size: 0x160 (Inherited: 0x160)
struct UMLInspectorPolicyComponent : UActorComponent {

	bool Uninitialize(); // Function HiveRuntime.MLInspectorPolicyComponent.Uninitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x9030c60
	void SoftReset(); // Function HiveRuntime.MLInspectorPolicyComponent.SoftReset // (Native|Event|Public|BlueprintEvent) // @ game+0x3edb670
	bool Initialize(struct UMLModelData* ModelData); // Function HiveRuntime.MLInspectorPolicyComponent.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x903ca80
	struct UMLTrainingPolicy* GetTrainingPolicy(); // Function HiveRuntime.MLInspectorPolicyComponent.GetTrainingPolicy // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x902d620
};

// Class HiveRuntime.MLObservedComponentsConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UMLObservedComponentsConfig : UObject {

	struct UMLObservedComponents* GetObserverClass(); // Function HiveRuntime.MLObservedComponentsConfig.GetObserverClass // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x9029240
};

// Class HiveRuntime.MLObservedComponents
// Size: 0x170 (Inherited: 0xa0)
struct UMLObservedComponents : UObject {
	int32_t RootId; // 0x98(0x04)
	struct TArray<struct FObserverState> ObservedStates; // 0xa0(0x10)
	struct FGameplayTagContainer ObservedGameplayTags; // 0xb0(0x20)
	struct TMap<int32_t, struct UActuatorBase*> ObservedActuators; // 0xd0(0x50)
	struct TMap<int32_t, struct UMLEffector*> ObservedEffectors; // 0x120(0x50)

	void UnregisterWithTickDispatcher(); // Function HiveRuntime.MLObservedComponents.UnregisterWithTickDispatcher // (Final|Native|Public) // @ game+0x9030160
	void Tick_Native(double Delta); // Function HiveRuntime.MLObservedComponents.Tick_Native // (Native|Public) // @ game+0x9031e50
	void Tick(double Delta); // Function HiveRuntime.MLObservedComponents.Tick // (Native|Event|Public|BlueprintEvent) // @ game+0x9031e50
	void SetStateActive(int32_t& StateId, bool bIsActive); // Function HiveRuntime.MLObservedComponents.SetStateActive // (Final|Native|Public|HasOutParms) // @ game+0x903bcb0
	void RegisterWithTickDispatcher(); // Function HiveRuntime.MLObservedComponents.RegisterWithTickDispatcher // (Final|Native|Public) // @ game+0x9025370
	void RegisterTag(struct FGameplayTag& Tag); // Function HiveRuntime.MLObservedComponents.RegisterTag // (Final|Native|Public|HasOutParms) // @ game+0x902d8d0
	void RegisterActuator(struct UActuatorBase* Actuator); // Function HiveRuntime.MLObservedComponents.RegisterActuator // (Final|Native|Public) // @ game+0x902e650
	void PopulateImpl(struct AActor* Actor, struct UMLObservedComponentsConfig* InConfig, int32_t& OutRootId); // Function HiveRuntime.MLObservedComponents.PopulateImpl // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x902eea0
	void PopulateEffectors(); // Function HiveRuntime.MLObservedComponents.PopulateEffectors // (Native|Event|Protected|BlueprintEvent) // @ game+0x16fe6f0
	void Populate(struct AActor* Actor, struct UMLObservedComponentsConfig* InConfig); // Function HiveRuntime.MLObservedComponents.Populate // (Final|Native|Public) // @ game+0x9029500
	void PartCollided_Native(struct UPrimitiveComponent* LocalComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComponent, struct FVector Impulse, struct FHitResult& Hit); // Function HiveRuntime.MLObservedComponents.PartCollided_Native // (Native|Public|HasOutParms|HasDefaults) // @ game+0x902f4b0
	void PartCollided(struct UPrimitiveComponent* LocalComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComponent, struct FVector Impulse, struct FHitResult& Hit); // Function HiveRuntime.MLObservedComponents.PartCollided // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x9036360
	void OnPartBroken_Native(int32_t& StateId); // Function HiveRuntime.MLObservedComponents.OnPartBroken_Native // (Native|Public|HasOutParms) // @ game+0x9031180
	void OnPartBroken(int32_t& StateId); // Function HiveRuntime.MLObservedComponents.OnPartBroken // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x9031180
	bool IsValidId(int32_t& ID); // Function HiveRuntime.MLObservedComponents.IsValidId // (Final|Native|Public|HasOutParms|Const) // @ game+0x9032ca0
	bool IsActiveId(int32_t& ID); // Function HiveRuntime.MLObservedComponents.IsActiveId // (Final|Native|Public|HasOutParms|Const) // @ game+0x9035ae0
	bool HasTag(int32_t ObservedStateId, struct FGameplayTag& Tag); // Function HiveRuntime.MLObservedComponents.HasTag // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x9037a10
	struct TArray<struct FObserverState> GetStates_Const(); // Function HiveRuntime.MLObservedComponents.GetStates_Const // (Final|Native|Public|Const) // @ game+0x9025490
	struct FObserverState GetStateByName_NonConst(struct FName& InName, enum class EObservedType InType); // Function HiveRuntime.MLObservedComponents.GetStateByName_NonConst // (Final|Native|Public|HasOutParms) // @ game+0x903b3a0
	struct FObserverState GetStateByName(struct FName& InName, enum class EObservedType InType); // Function HiveRuntime.MLObservedComponents.GetStateByName // (Final|Native|Public|HasOutParms|Const) // @ game+0x903b3a0
	struct FObserverState GetState_NonConst(int32_t ID); // Function HiveRuntime.MLObservedComponents.GetState_NonConst // (Final|Native|Public) // @ game+0x902be30
	struct FObserverState GetState(int32_t ID); // Function HiveRuntime.MLObservedComponents.GetState // (Final|Native|Public|Const) // @ game+0x902be30
	int32_t GetRootId(); // Function HiveRuntime.MLObservedComponents.GetRootId // (Final|Native|Public|Const) // @ game+0x90265f0
	bool GetObservedIDs(struct FGameplayTag& Tag, struct TArray<int32_t>& OutIDs); // Function HiveRuntime.MLObservedComponents.GetObservedIDs // (Final|Native|Public|HasOutParms) // @ game+0x90350e0
	int32_t GetObservedIdByName(struct FName& InName, enum class EObservedType Type); // Function HiveRuntime.MLObservedComponents.GetObservedIdByName // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x9034bb0
	int32_t GetNumberOFObserverStates(); // Function HiveRuntime.MLObservedComponents.GetNumberOFObserverStates // (Final|Native|Public|Const) // @ game+0x325ee70
	struct UMLEffector* GetEffectorByName(struct FName& StateName, enum class EObservedType Ty); // Function HiveRuntime.MLObservedComponents.GetEffectorByName // (Final|Native|Public|HasOutParms|Const) // @ game+0x9037040
	struct UMLEffector* GetEffectorById(int32_t& StateId); // Function HiveRuntime.MLObservedComponents.GetEffectorById // (Final|Native|Public|HasOutParms|Const) // @ game+0x9034db0
	void GetChildren(int32_t& StateId, bool bRecursive, struct TArray<int32_t>& OutChildren); // Function HiveRuntime.MLObservedComponents.GetChildren // (Final|Native|Public|HasOutParms|Const) // @ game+0x90302c0
	void GetAllParentIDsByTypeRecursive(int32_t& ChildID, enum class EObservedType Type, struct TArray<int32_t>& OutParentIDs); // Function HiveRuntime.MLObservedComponents.GetAllParentIDsByTypeRecursive // (Final|Native|Public|HasOutParms|Const) // @ game+0x9028e40
	bool GetAllParentIDsByType(int32_t& ChildID, enum class EObservedType Type, struct TArray<int32_t>& OutParentIDs); // Function HiveRuntime.MLObservedComponents.GetAllParentIDsByType // (Final|Native|Public|HasOutParms|Const) // @ game+0x9034800
	bool GetAllParentIDs(int32_t& ChildID, struct TArray<int32_t>& OutParentIDs); // Function HiveRuntime.MLObservedComponents.GetAllParentIDs // (Final|Native|Public|HasOutParms|Const) // @ game+0x902fc80
	struct TMap<int32_t, struct UActuatorBase*> GetActuators(); // Function HiveRuntime.MLObservedComponents.GetActuators // (Final|Native|Public|Const) // @ game+0x9035c60
	struct UActuatorBase* GetActuator(int32_t& StateId); // Function HiveRuntime.MLObservedComponents.GetActuator // (Final|Native|Public|HasOutParms|Const) // @ game+0x90248a0
};

// Class HiveRuntime.MLObservedSkeletalComponentsConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UMLObservedSkeletalComponentsConfig : UMLObservedComponentsConfig {
};

// Class HiveRuntime.MLObservedSkeletalComponents
// Size: 0x220 (Inherited: 0x170)
struct UMLObservedSkeletalComponents : UMLObservedComponents {
	char pad_170[0xb0]; // 0x170(0xb0)

	struct UConstructableSkeletalMeshStyleComponent* GetSkeletal(); // Function HiveRuntime.MLObservedSkeletalComponents.GetSkeletal // (Final|Native|Private|Const) // @ game+0x557a8c0
};

// Class HiveRuntime.MLPolicy
// Size: 0x100 (Inherited: 0xd0)
struct UMLPolicy : UReplicatedSubobject {
	struct TArray<struct UMLBehaviorState*> Behaviors; // 0xc8(0x10)
	int32_t ActiveBehaviorIndex; // 0xd8(0x04)
	struct FName ModelTypeName; // 0xdc(0x08)
	int32_t DecisionFrequency; // 0xe4(0x04)
	struct FMLPostInitData PostInitData; // 0xe8(0x04)
	char pad_f4[0xc]; // 0xf4(0x0c)

	bool InitFromConfig(struct UMLDataAssetBase* InConfig, struct FName InModelTypeName, bool bInjectDebugModules, struct AActor* InOwningActor); // Function HiveRuntime.MLPolicy.InitFromConfig // (Native|Public) // @ game+0x903be80
	struct UMLBehaviorState* GetActiveBehavior(); // Function HiveRuntime.MLPolicy.GetActiveBehavior // (Final|Native|Public|Const) // @ game+0x902bfb0
	void EnableWithBehavior(int32_t BehaviorIndex); // Function HiveRuntime.MLPolicy.EnableWithBehavior // (Final|Native|Public) // @ game+0x9036c30
	void Disable(); // Function HiveRuntime.MLPolicy.Disable // (Final|Native|Public) // @ game+0x9031750
	int32_t BehaviorNameToBehaviorIndex(struct FName BehaviorName); // Function HiveRuntime.MLPolicy.BehaviorNameToBehaviorIndex // (Final|Native|Public|Const) // @ game+0x9038b60
};

// Class HiveRuntime.MLTrainingPolicy
// Size: 0x100 (Inherited: 0x100)
struct UMLTrainingPolicy : UMLPolicy {

	enum class EHiveTerminalReason IsTerminal(); // Function HiveRuntime.MLTrainingPolicy.IsTerminal // (Final|Native|Public|Const) // @ game+0x902c3e0
	enum class EAgentResetFlags GetResetFlags(); // Function HiveRuntime.MLTrainingPolicy.GetResetFlags // (Final|Native|Public|Const) // @ game+0x9033bc0
};

// Class HiveRuntime.MLPolicySelectorConfig
// Size: 0xa0 (Inherited: 0xa0)
struct UMLPolicySelectorConfig : UObject {

	struct UMLPolicySelector* GetSelectorClass(); // Function HiveRuntime.MLPolicySelectorConfig.GetSelectorClass // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x9029240
};

// Class HiveRuntime.MLPolicySelector
// Size: 0xa0 (Inherited: 0xa0)
struct UMLPolicySelector : UObject {

	void Tick_Native(float Delta); // Function HiveRuntime.MLPolicySelector.Tick_Native // (Native|Public) // @ game+0x1703810
	void Tick(float Delta); // Function HiveRuntime.MLPolicySelector.Tick // (Native|Event|Public|BlueprintEvent) // @ game+0x902c2f0
	struct FGameplayTag QueryActivePolicy_Native(); // Function HiveRuntime.MLPolicySelector.QueryActivePolicy_Native // (Native|Public|Const) // @ game+0x9033db0
	struct FGameplayTag QueryActivePolicy(); // Function HiveRuntime.MLPolicySelector.QueryActivePolicy // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x9029240
	bool Init_Native(struct UMLPolicySelectorConfig* InConfig, struct TSet<struct FGameplayTag>& AvailablePolicies); // Function HiveRuntime.MLPolicySelector.Init_Native // (Native|Public|HasOutParms) // @ game+0x903ad50
	bool Init(struct UMLPolicySelectorConfig* InConfig, struct TSet<struct FGameplayTag>& AvailablePolicies); // Function HiveRuntime.MLPolicySelector.Init // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x9030690
};

// Class HiveRuntime.MLPolicyReplicatorComponent
// Size: 0x190 (Inherited: 0x170)
struct UMLPolicyReplicatorComponent : UActorComponentReplicatedSubobjects {
	struct TArray<struct TWeakObjectPtr<struct UMLPolicy>> Policies; // 0x170(0x10)
	char pad_180[0x10]; // 0x180(0x10)

	void UnregisterPolicy_Server(struct UMLPolicy* Policy); // Function HiveRuntime.MLPolicyReplicatorComponent.UnregisterPolicy_Server // (Final|Native|Public) // @ game+0x257bb60
	void RegisterPolicy_Server(struct UMLPolicy* Policy); // Function HiveRuntime.MLPolicyReplicatorComponent.RegisterPolicy_Server // (Final|Native|Public) // @ game+0x257bb60
	void OnRep_Policies(struct TArray<struct TWeakObjectPtr<struct UMLPolicy>>& Prev); // Function HiveRuntime.MLPolicyReplicatorComponent.OnRep_Policies // (Final|Native|Private|HasOutParms) // @ game+0x9025510
	void GetAllRegisteredPolicies(struct TArray<struct UMLPolicy*>& OutPolicies); // Function HiveRuntime.MLPolicyReplicatorComponent.GetAllRegisteredPolicies // (Final|Native|Public|HasOutParms|Const) // @ game+0x9035210
};

// Class HiveRuntime.MLTickableMultiPolicyComponent
// Size: 0x2f0 (Inherited: 0x160)
struct UMLTickableMultiPolicyComponent : UActorComponent {
	struct TArray<struct FMLPolicyDefinition> PolicyDefinitions; // 0x160(0x10)
	struct TArray<struct UMLPolicy*> Policies; // 0x170(0x10)
	struct UMLPolicySelectorConfig* PolicySelectorConfig; // 0x180(0x08)
	char pad_188[0x60]; // 0x188(0x60)
	struct UMLPolicySelector* Selector; // 0x1e8(0x08)
	struct UObservationSet* ObservationSet; // 0x1f0(0x08)
	char pad_1f8[0xf8]; // 0x1f8(0xf8)

	bool Initialize(); // Function HiveRuntime.MLTickableMultiPolicyComponent.Initialize // (Final|Native|Public) // @ game+0x9035a90
	struct UMLPolicy* GetActivePolicy(); // Function HiveRuntime.MLTickableMultiPolicyComponent.GetActivePolicy // (Final|Native|Public|Const) // @ game+0x2f822c0
};

// Class HiveRuntime.MLTickableInspectorPolicyComponent
// Size: 0x3c0 (Inherited: 0x160)
struct UMLTickableInspectorPolicyComponent : UMLInspectorPolicyComponent {
	struct UMLTrainingPolicy* Policy; // 0x160(0x08)
	struct UObservationSet* ObservationSet; // 0x168(0x08)
	char pad_170[0x248]; // 0x170(0x248)
	enum class EHiveTerminalReason TerminalReason; // 0x3b8(0x01)
	enum class EAgentResetFlags ResetFlags; // 0x3b9(0x01)
	char pad_3ba[0x6]; // 0x3ba(0x06)
};

// Class HiveRuntime.MLTickDispatcherSubsystem
// Size: 0x1e0 (Inherited: 0xa0)
struct UMLTickDispatcherSubsystem : UWorldSubsystem {
	char pad_a0[0x140]; // 0xa0(0x140)

	void Uses(struct FName ModelType); // Function HiveRuntime.MLTickDispatcherSubsystem.Uses // (Final|Native|Public|Const) // @ game+0x902e730
	bool ShouldInfer(struct FName ModelType); // Function HiveRuntime.MLTickDispatcherSubsystem.ShouldInfer // (Final|Native|Public|Const) // @ game+0x90317e0
	void SetModelDecisionFrequency(struct FName ModelType, int32_t DecisionFrequency); // Function HiveRuntime.MLTickDispatcherSubsystem.SetModelDecisionFrequency // (Final|Native|Public) // @ game+0x9033c40
	void SetModelBlockingCollect(struct FName ModelType, bool bBlockOnCollect); // Function HiveRuntime.MLTickDispatcherSubsystem.SetModelBlockingCollect // (Final|Native|Public) // @ game+0x902f380
};

