// Class NiagaraShader.NiagaraScriptBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraScriptBase : UObject {
};

