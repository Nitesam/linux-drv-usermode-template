// ScriptStruct KantanChartsUMG.SeriesStyleManualMapping
// Size: 0x28 (Inherited: 0x00)
struct FSeriesStyleManualMapping {
	struct FName SeriesId; // 0x00(0x08)
	struct FKantanSeriesStyle Style; // 0x08(0x20)
};

// ScriptStruct KantanChartsUMG.CategoryStyleManualMapping
// Size: 0x20 (Inherited: 0x00)
struct FCategoryStyleManualMapping {
	struct FName CategoryId; // 0x00(0x08)
	struct FKantanCategoryStyle Style; // 0x08(0x18)
};

