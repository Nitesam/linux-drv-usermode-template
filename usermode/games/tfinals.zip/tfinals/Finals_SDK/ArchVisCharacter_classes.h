// Class ArchVisCharacter.ArchVisCharacter
// Size: 0x7e0 (Inherited: 0x780)
struct AArchVisCharacter : ACharacter {
	struct FString LookUpAxisName; // 0x778(0x10)
	struct FString LookUpAtRateAxisName; // 0x788(0x10)
	struct FString TurnAxisName; // 0x798(0x10)
	struct FString TurnAtRateAxisName; // 0x7a8(0x10)
	struct FString MoveForwardAxisName; // 0x7b8(0x10)
	struct FString MoveRightAxisName; // 0x7c8(0x10)
	float MouseSensitivityScale_Pitch; // 0x7d8(0x04)
	float MouseSensitivityScale_Yaw; // 0x7dc(0x04)
};

// Class ArchVisCharacter.ArchVisCharMovementComponent
// Size: 0x10c0 (Inherited: 0x1030)
struct UArchVisCharMovementComponent : UCharacterMovementComponent {
	struct FRotator RotationalAcceleration; // 0x1028(0x18)
	struct FRotator RotationalDeceleration; // 0x1040(0x18)
	struct FRotator MaxRotationalVelocity; // 0x1058(0x18)
	float MinPitch; // 0x1070(0x04)
	float MaxPitch; // 0x1074(0x04)
	float WalkingFriction; // 0x1078(0x04)
	float WalkingSpeed; // 0x107c(0x04)
	float WalkingAcceleration; // 0x1080(0x04)
	char pad_108c[0x34]; // 0x108c(0x34)
};

