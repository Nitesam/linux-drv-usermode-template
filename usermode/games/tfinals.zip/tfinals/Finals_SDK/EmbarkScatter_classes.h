// Class EmbarkScatter.EmbarkMergeScatterRuntimeCellTransformer
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMergeScatterRuntimeCellTransformer : UWorldPartitionRuntimeCellTransformer {
};

// Class EmbarkScatter.EmbarkSkipMergeScatterWorldSettingsExtension
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkSkipMergeScatterWorldSettingsExtension : UEmbarkWorldSettingsExtension {
};

// Class EmbarkScatter.MergedScatterActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AMergedScatterActor : AActor {
};

// Class EmbarkScatter.ScatterBlockingComponent
// Size: 0x700 (Inherited: 0x700)
struct UScatterBlockingComponent : UBoxComponent {
	bool bAllowNonCollidingScatter; // 0x6f8(0x01)
};

// Class EmbarkScatter.ScatterComponent
// Size: 0x3d0 (Inherited: 0x3c0)
struct UScatterComponent : USceneComponent {
	float ScatterSize; // 0x3c0(0x04)
	char pad_3c4[0xc]; // 0x3c4(0x0c)
};

// Class EmbarkScatter.ScatterDataAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UScatterDataAsset : UDataAsset {
};

// Class EmbarkScatter.ScatterMeshComponent
// Size: 0xa70 (Inherited: 0xa70)
struct UScatterMeshComponent : UHierarchicalInstancedStaticMeshComponent {
};

