// Class AntiCheatArgus.ArgusTelemetry
// Size: 0xa0 (Inherited: 0xa0)
struct UArgusTelemetry : UObject {

	void OnViewAngleUpdate(struct FRotator& View, bool bIsCrosshairOnTarget, bool bIsTargetVisible); // Function AntiCheatArgus.ArgusTelemetry.OnViewAngleUpdate // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x44a5380
	void OnPositionUpdate(struct FVector& Pos); // Function AntiCheatArgus.ArgusTelemetry.OnPositionUpdate // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x44a5ec0
	void OnKill(struct FString TargetId); // Function AntiCheatArgus.ArgusTelemetry.OnKill // (Final|RequiredAPI|Native|Static|Public) // @ game+0x44a6e20
	void OnHit(double Damage, struct FString Weapon, struct FString HitBox, struct FString TargetId, double RemainingHealth); // Function AntiCheatArgus.ArgusTelemetry.OnHit // (Final|RequiredAPI|Native|Static|Public) // @ game+0x44a2380
	void OnEvent(struct FString Name, struct FString MetaData); // Function AntiCheatArgus.ArgusTelemetry.OnEvent // (Final|RequiredAPI|Native|Static|Public) // @ game+0x44a7c50
	void OnDeath(struct FString AttackerId); // Function AntiCheatArgus.ArgusTelemetry.OnDeath // (Final|RequiredAPI|Native|Static|Public) // @ game+0x44a6140
	void OnAttack(struct FString Ability); // Function AntiCheatArgus.ArgusTelemetry.OnAttack // (Final|RequiredAPI|Native|Static|Public) // @ game+0x44a7930
	void OnAction(struct FString Name, struct FString MetaData); // Function AntiCheatArgus.ArgusTelemetry.OnAction // (Final|RequiredAPI|Native|Static|Public) // @ game+0x44a6910
};

