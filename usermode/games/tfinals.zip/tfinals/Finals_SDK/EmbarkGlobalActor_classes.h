// Class EmbarkGlobalActor.EmbarkGlobalActorFactorySubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkGlobalActorFactorySubsystem : UEmbarkGlobalActorFactorySubsystemInterface {
	struct TArray<struct AEmbarkGlobalActor*> InitializeActorClasses; // 0xa0(0x10)
	struct TMap<struct UObject*, struct AEmbarkGlobalActor*> CreatedActors; // 0xb0(0x50)

	bool ReceiveShouldCreateSubsystem(struct UObject* Outer); // Function EmbarkGlobalActor.EmbarkGlobalActorFactorySubsystem.ReceiveShouldCreateSubsystem // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x53bc850
	void ReceivePostInitialize(); // Function EmbarkGlobalActor.EmbarkGlobalActorFactorySubsystem.ReceivePostInitialize // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnInitialize(); // Function EmbarkGlobalActor.EmbarkGlobalActorFactorySubsystem.ReceiveOnInitialize // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGlobalActor.EmbarkGameplayGlobalActorFactorySubsystemBase
// Size: 0x110 (Inherited: 0x100)
struct UEmbarkGameplayGlobalActorFactorySubsystemBase : UEmbarkGlobalActorFactorySubsystem {
	struct AEmbarkCharacterMovementGlobalActorBase* EmbarkCharacterMovementGlobalActorClass; // 0x100(0x08)
	char pad_108[0x8]; // 0x108(0x08)

	struct AEmbarkFastReplicatorTransform* GetTransformFastReplicator(); // Function EmbarkGlobalActor.EmbarkGameplayGlobalActorFactorySubsystemBase.GetTransformFastReplicator // (Final|Native|Public|BlueprintCallable) // @ game+0x5f77fb0
};

