// Class EmbarkActivities.EmbarkSlimActivitiesSubsystem
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkSlimActivitiesSubsystem : ULocalPlayerSubsystem {
	struct FMulticastInlineDelegate OnActivitiesSet; // 0xa0(0x10)
	char pad_b0[0x40]; // 0xb0(0x40)

	bool TryConsumeLaunchActivity(struct FString& OutActivityId); // Function EmbarkActivities.EmbarkSlimActivitiesSubsystem.TryConsumeLaunchActivity // (Final|Native|Public|HasOutParms) // @ game+0x6973730
	void SetActivityAvailability(struct FString ActivityId, bool bAvailability); // Function EmbarkActivities.EmbarkSlimActivitiesSubsystem.SetActivityAvailability // (Native|Event|Public|BlueprintEvent) // @ game+0x6975e60
};

