// ScriptStruct EmbarkInstigator.Instigator
// Size: 0x50 (Inherited: 0x00)
struct FInstigator {
	struct TWeakObjectPtr<struct APlayerState> InstigatorPlayerState; // 0x00(0x08)
	struct TWeakObjectPtr<struct AActor> Instigator; // 0x08(0x08)
	struct TWeakObjectPtr<struct AActor> InstigatingItem; // 0x10(0x08)
	struct TWeakObjectPtr<struct AActor> Causer; // 0x18(0x08)
	struct FVector_NetQuantize PointOfOrigin; // 0x20(0x18)
	int32_t TeamId; // 0x38(0x04)
	struct FGameplayTag Source; // 0x3c(0x08)
	bool bAlwaysFriendlyFire; // 0x44(0x01)
	bool bAllowSelfDamage; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	float CreationTimestamp_Server; // 0x48(0x04)
	char pad_4c[0x4]; // 0x4c(0x04)
};

