// Enum AngelscriptCode.EAngelscriptPropertyEditSpecifier
enum class EAngelscriptPropertyEditSpecifier : uint8_t {
	EditAnywhere = 0,
	EditInstanceOnly = 1,
	EditDefaultsOnly = 2,
	NotEditable = 3,
	EAngelscriptPropertyEditSpecifier_MAX = 4
};

// Enum AngelscriptCode.EAngelscriptPropertyBlueprintSpecifier
enum class EAngelscriptPropertyBlueprintSpecifier : uint8_t {
	BlueprintReadWrite = 0,
	BlueprintReadOnly = 1,
	BlueprintHidden = 2,
	EAngelscriptPropertyBlueprintSpecifier_MAX = 3
};

// Enum AngelscriptCode.EAngelscriptMathNamespace
enum class EAngelscriptMathNamespace : uint8_t {
	Math = 0,
	FMath = 1,
	EAngelscriptMathNamespace_MAX = 2
};

// Enum AngelscriptCode.EAngelscriptStaticClassMode
enum class EAngelscriptStaticClassMode : uint8_t {
	Allowed = 0,
	Deprecated = 1,
	Disallowed = 2,
	EAngelscriptStaticClassMode_MAX = 3
};

// ScriptStruct AngelscriptCode.CurveKeyHandle
// Size: 0x04 (Inherited: 0x00)
struct FCurveKeyHandle {
	char pad_0[0x4]; // 0x00(0x04)
};

