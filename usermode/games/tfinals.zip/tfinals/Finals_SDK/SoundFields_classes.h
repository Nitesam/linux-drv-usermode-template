// Class SoundFields.AmbisonicsEncodingSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAmbisonicsEncodingSettings : USoundfieldEncodingSettingsBase {
	int32_t AmbisonicsOrder; // 0x98(0x04)
};

