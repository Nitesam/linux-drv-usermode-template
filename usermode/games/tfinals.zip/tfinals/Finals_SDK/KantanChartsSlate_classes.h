// Class KantanChartsSlate.KantanBarChartWidgetStyle
// Size: 0x220 (Inherited: 0xa0)
struct UKantanBarChartWidgetStyle : USlateWidgetStyleContainerBase {
	struct FKantanBarChartStyle ChartStyle; // 0xa0(0x180)
};

// Class KantanChartsSlate.KantanCartesianChartWidgetStyle
// Size: 0x220 (Inherited: 0xa0)
struct UKantanCartesianChartWidgetStyle : USlateWidgetStyleContainerBase {
	struct FKantanCartesianChartStyle ChartStyle; // 0xa0(0x180)
};

// Class KantanChartsSlate.KantanCategoryStyleSet
// Size: 0xb0 (Inherited: 0xa0)
struct UKantanCategoryStyleSet : UDataAsset {
	struct TArray<struct FKantanCategoryStyle> Styles; // 0xa0(0x10)
};

// Class KantanChartsSlate.KantanPointStyle
// Size: 0xc0 (Inherited: 0xa0)
struct UKantanPointStyle : UDataAsset {
	struct UTexture2D* DataPointTexture; // 0xa0(0x08)
	struct FIntPoint PointSizeTextureOffsets[0x3]; // 0xa8(0x18)
};

// Class KantanChartsSlate.KantanSeriesStyleSet
// Size: 0xb0 (Inherited: 0xa0)
struct UKantanSeriesStyleSet : UDataAsset {
	struct TArray<struct FKantanSeriesStyle> Styles; // 0xa0(0x10)
};

