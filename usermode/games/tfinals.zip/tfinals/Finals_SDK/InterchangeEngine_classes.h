// Class InterchangeEngine.InterchangeBlueprintPipelineBase
// Size: 0x120 (Inherited: 0x120)
struct UInterchangeBlueprintPipelineBase : UBlueprint {
};

// Class InterchangeEngine.InterchangeFilePickerBase
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeFilePickerBase : UObject {

	bool ScriptedFilePickerForTranslatorType(enum class EInterchangeTranslatorType TranslatorType, struct FInterchangeFilePickerParameters& Parameters, struct TArray<struct FString>& OutFilenames); // Function InterchangeEngine.InterchangeFilePickerBase.ScriptedFilePickerForTranslatorType // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x996ea30
	bool ScriptedFilePickerForTranslatorAssetType(enum class EInterchangeTranslatorAssetType TranslatorAssetType, struct FInterchangeFilePickerParameters& Parameters, struct TArray<struct FString>& OutFilenames); // Function InterchangeEngine.InterchangeFilePickerBase.ScriptedFilePickerForTranslatorAssetType // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x9973ca0
};

// Class InterchangeEngine.InterchangePipelineConfigurationBase
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangePipelineConfigurationBase : UObject {

	enum class EInterchangePipelineConfigurationDialogResult ScriptedShowScenePipelineConfigurationDialog(struct TArray<struct FInterchangeStackInfo>& PipelineStacks, struct TArray<struct UInterchangePipelineBase*>& OutPipelines, struct UInterchangeSourceData* SourceData); // Function InterchangeEngine.InterchangePipelineConfigurationBase.ScriptedShowScenePipelineConfigurationDialog // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x9977fb0
	enum class EInterchangePipelineConfigurationDialogResult ScriptedShowReimportPipelineConfigurationDialog(struct TArray<struct FInterchangeStackInfo>& PipelineStacks, struct TArray<struct UInterchangePipelineBase*>& OutPipelines, struct UInterchangeSourceData* SourceData); // Function InterchangeEngine.InterchangePipelineConfigurationBase.ScriptedShowReimportPipelineConfigurationDialog // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x99517b0
	enum class EInterchangePipelineConfigurationDialogResult ScriptedShowPipelineConfigurationDialog(struct TArray<struct FInterchangeStackInfo>& PipelineStacks, struct TArray<struct UInterchangePipelineBase*>& OutPipelines, struct UInterchangeSourceData* SourceData); // Function InterchangeEngine.InterchangePipelineConfigurationBase.ScriptedShowPipelineConfigurationDialog // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x994f450
};

// Class InterchangeEngine.InterchangeProjectSettings
// Size: 0x2b0 (Inherited: 0xb0)
struct UInterchangeProjectSettings : UDeveloperSettings {
	struct FInterchangeContentImportSettings ContentImportSettings; // 0xa8(0x128)
	struct FInterchangeImportSettings SceneImportSettings; // 0x1d0(0x88)
	struct TSoftClassPtr<UObject> FilePickerClass; // 0x258(0x28)
	bool bStaticMeshUseSmoothEdgesIfSmoothingInformationIsMissing; // 0x280(0x01)
	struct TSoftClassPtr<UObject> GenericPipelineClass; // 0x288(0x28)
};

// Class InterchangeEngine.InterchangePythonPipelineBase
// Size: 0x160 (Inherited: 0x160)
struct UInterchangePythonPipelineBase : UInterchangePipelineBase {
};

// Class InterchangeEngine.InterchangePythonPipelineAsset
// Size: 0xe0 (Inherited: 0xa0)
struct UInterchangePythonPipelineAsset : UObject {
	struct TSoftClassPtr<UObject> PythonClass; // 0x98(0x28)
	struct UInterchangePythonPipelineBase* GeneratedPipeline; // 0xc0(0x08)
	struct FString JsonDefaultProperties; // 0xc8(0x10)
};

// Class InterchangeEngine.InterchangeSceneImportAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeSceneImportAsset : UObject {
};

// Class InterchangeEngine.InterchangeAssetImportData
// Size: 0x120 (Inherited: 0xa0)
struct UInterchangeAssetImportData : UAssetImportData {
	struct FSoftObjectPath SceneImportAsset; // 0x98(0x20)
	struct FString NodeUniqueID; // 0xb8(0x10)
	struct UInterchangeBaseNodeContainer* NodeContainer; // 0xc8(0x08)
	struct TArray<struct UObject*> Pipelines; // 0xd0(0x10)
	struct UInterchangeBaseNodeContainer* TransientNodeContainer; // 0xe0(0x08)
	struct TArray<struct UObject*> TransientPipelines; // 0xe8(0x10)
	char pad_100[0x20]; // 0x100(0x20)

	void SetPipelines(struct TArray<struct UObject*>& InPipelines); // Function InterchangeEngine.InterchangeAssetImportData.SetPipelines // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x994fa20
	void SetNodeContainer(struct UInterchangeBaseNodeContainer* InNodeContainer); // Function InterchangeEngine.InterchangeAssetImportData.SetNodeContainer // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x9965560
	struct FString ScriptGetFirstFilename(); // Function InterchangeEngine.InterchangeAssetImportData.ScriptGetFirstFilename // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3389d20
	struct TArray<struct FString> ScriptExtractFilenames(); // Function InterchangeEngine.InterchangeAssetImportData.ScriptExtractFilenames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bd5670
	struct TArray<struct FString> ScriptExtractDisplayLabels(); // Function InterchangeEngine.InterchangeAssetImportData.ScriptExtractDisplayLabels // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5bd5670
	struct UInterchangeBaseNode* GetStoredNode(struct FString InNodeUniqueId); // Function InterchangeEngine.InterchangeAssetImportData.GetStoredNode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x995d150
	struct UInterchangeFactoryBaseNode* GetStoredFactoryNode(struct FString InNodeUniqueId); // Function InterchangeEngine.InterchangeAssetImportData.GetStoredFactoryNode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x995bdf0
	struct TArray<struct UObject*> GetPipelines(); // Function InterchangeEngine.InterchangeAssetImportData.GetPipelines // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x996bba0
	int32_t GetNumberOfPipelines(); // Function InterchangeEngine.InterchangeAssetImportData.GetNumberOfPipelines // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9960a80
	struct UInterchangeBaseNodeContainer* GetNodeContainer(); // Function InterchangeEngine.InterchangeAssetImportData.GetNodeContainer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x994f910
};

// Class InterchangeEngine.InterchangePipelineStackOverride
// Size: 0xb0 (Inherited: 0xa0)
struct UInterchangePipelineStackOverride : UObject {
	struct TArray<struct FSoftObjectPath> OverridePipelines; // 0x98(0x10)

	void AddPythonPipeline(struct UInterchangePythonPipelineBase* PipelineBase); // Function InterchangeEngine.InterchangePipelineStackOverride.AddPythonPipeline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x995f4f0
	void AddPipeline(struct UInterchangePipelineBase* PipelineBase); // Function InterchangeEngine.InterchangePipelineStackOverride.AddPipeline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x995f4f0
	void AddBlueprintPipeline(struct UInterchangeBlueprintPipelineBase* PipelineBase); // Function InterchangeEngine.InterchangePipelineStackOverride.AddBlueprintPipeline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x995f4f0
};

// Class InterchangeEngine.InterchangeManager
// Size: 0x250 (Inherited: 0xa0)
struct UInterchangeManager : UObject {
	char pad_a0[0xa8]; // 0xa0(0xa8)
	struct TSet<ClassPtrProperty> RegisteredTranslatorsClass; // 0x148(0x50)
	struct TMap<ClassPtrProperty, ClassPtrProperty> RegisteredFactoryClasses; // 0x198(0x50)
	struct TMap<ClassPtrProperty, struct UInterchangeWriterBase*> RegisteredWriters; // 0x1e8(0x50)
	char pad_238[0x18]; // 0x238(0x18)

	bool ImportScene(struct FString ContentPath, struct UInterchangeSourceData* SourceData, struct FImportAssetParameters& ImportAssetParameters); // Function InterchangeEngine.InterchangeManager.ImportScene // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9972c80
	bool ImportAsset(struct FString ContentPath, struct UInterchangeSourceData* SourceData, struct FImportAssetParameters& ImportAssetParameters); // Function InterchangeEngine.InterchangeManager.ImportAsset // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x995de90
	struct UObject* GetRegisteredFactoryClass(struct UObject* ClassToMake); // Function InterchangeEngine.InterchangeManager.GetRegisteredFactoryClass // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9966130
	struct UInterchangeManager* GetInterchangeManagerScripted(); // Function InterchangeEngine.InterchangeManager.GetInterchangeManagerScripted // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9966a20
	bool ExportScene(struct UObject* World, bool bIsAutomated); // Function InterchangeEngine.InterchangeManager.ExportScene // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x994d5b0
	bool ExportAsset(struct UObject* Asset, bool bIsAutomated); // Function InterchangeEngine.InterchangeManager.ExportAsset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x994d5b0
	struct UInterchangeSourceData* CreateSourceData(struct FString InFilename); // Function InterchangeEngine.InterchangeManager.CreateSourceData // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x9976bc0
};

// Class InterchangeEngine.InterchangeMeshUtilities
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeMeshUtilities : UObject {
};

