// Class AngelscriptGAS.AbilityAsyncMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAbilityAsyncMixinLibrary : UObject {

	void Activate(struct UAbilityAsync* Async); // Function AngelscriptGAS.AbilityAsyncMixinLibrary.Activate // (Final|Native|Static|Private) // @ game+0x4f8d920
};

// Class AngelscriptGAS.AbilitySystemComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAbilitySystemComponentMixinLibrary : UObject {

	void SetReplicatedLooseGameplayTagCount(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag& GameplayTag, int32_t NewCount); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.SetReplicatedLooseGameplayTagCount // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8e8d0
	void SetLooseGameplayTagCount(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag& GameplayTag, int32_t NewCount); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.SetLooseGameplayTagCount // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f95240
	void SetGenerateTryActivateAbilityFailureReason(struct UAbilitySystemComponent* AbilitySystemComponent, bool bEnabled); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.SetGenerateTryActivateAbilityFailureReason // (Final|Native|Static|Public) // @ game+0x4f90350
	void SendGameplayEvent(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag EventTag, struct FGameplayEventData& Payload); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.SendGameplayEvent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8d300
	void RemoveSpawnedAttribute(struct UAbilitySystemComponent* AbilitySystemComponent, struct UAttributeSet* Attribute); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveSpawnedAttribute // (Final|Native|Static|Public) // @ game+0x4f93b20
	void RemoveReplicatedLooseGameplayTags(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& GameplayTags); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveReplicatedLooseGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8e340
	void RemoveReplicatedLooseGameplayTag(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag& GameplayTag); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveReplicatedLooseGameplayTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8fdb0
	void RemoveLooseGameplayTags(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& GameplayTags, int32_t Count); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveLooseGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f93550
	void RemoveLooseGameplayTag(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag& GameplayTag, int32_t Count); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveLooseGameplayTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8f560
	void RemoveGameplayCue(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag GameplayCueTag); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveGameplayCue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4f8d730
	void RemoveAllSpawnedAttributes(struct UAbilitySystemComponent* AbilitySystemComponent); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveAllSpawnedAttributes // (Final|Native|Static|Public) // @ game+0x4f95b00
	void RemoveAllGameplayCues(struct UAbilitySystemComponent* AbilitySystemComponent); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.RemoveAllGameplayCues // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4f97280
	void MarkAbilitySpecDirty(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpec& Spec, bool bWasAddOrRemove); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.MarkAbilitySpecDirty // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f97990
	void InitDefaultGameplayCueParameters(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayCueParameters& Parameters); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.InitDefaultGameplayCueParameters // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f91f50
	struct FGameplayAbilitySpecHandle GiveAbilityAndActivateOnceWithEventData(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpec& Spec, struct FGameplayEventData& EventData); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GiveAbilityAndActivateOnceWithEventData // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f94c40
	struct FGameplayAbilitySpecHandle GiveAbilityAndActivateOnce(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpec& Spec); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GiveAbilityAndActivateOnce // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f90790
	struct FGameplayAbilitySpecHandle GiveAbility(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpec& Spec); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GiveAbility // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f97790
	struct TArray<struct UAttributeSet*> GetSpawnedAttributes(struct UAbilitySystemComponent* AbilitySystemComponent); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GetSpawnedAttributes // (Final|Native|Static|Public) // @ game+0x4f8c6d0
	void GetOwnedGameplayTags(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& TagContainer); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GetOwnedGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8dba0
	bool GetGenerateTryActivateAbilityFailureReason(struct UAbilitySystemComponent* AbilitySystemComponent); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GetGenerateTryActivateAbilityFailureReason // (Final|Native|Static|Public) // @ game+0x4f95f00
	struct FActiveGameplayEffect GetActiveGameplayEffect(struct UAbilitySystemComponent* AbilitySystemComponent, struct FActiveGameplayEffectHandle& Handle); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.GetActiveGameplayEffect // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8e4a0
	bool FindAbilitySpecFromInputID(struct UAbilitySystemComponent* AbilitySystemComponent, int32_t InputID, struct FGameplayAbilitySpec& OutSpec); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.FindAbilitySpecFromInputID // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f966a0
	bool FindAbilitySpecFromHandle(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpecHandle Handle, struct FGameplayAbilitySpec& OutSpec); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.FindAbilitySpecFromHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8e680
	bool FindAbilitySpecFromGEHandle(struct UAbilitySystemComponent* AbilitySystemComponent, struct FActiveGameplayEffectHandle Handle, struct FGameplayAbilitySpec& OutSpec); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.FindAbilitySpecFromGEHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8cde0
	bool FindAbilitySpecFromClass(struct UAbilitySystemComponent* AbilitySystemComponent, struct UGameplayAbility* InAbilityClass, struct FGameplayAbilitySpec& OutSpec); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.FindAbilitySpecFromClass // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8b1b0
	void ExecuteGameplayCueWithParameters(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameters); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.ExecuteGameplayCueWithParameters // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8a790
	void ExecuteGameplayCueWithEffectContext(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle& EffectContext); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.ExecuteGameplayCueWithEffectContext // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8bc20
	bool ConsumeTryActivateAbilityFailureReasonString(struct UAbilitySystemComponent* AbilitySystemComponent, struct FString& OutFailureReasonString); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.ConsumeTryActivateAbilityFailureReasonString // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8dfe0
	bool AreAbilityTagsBlocked(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& Tags); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AreAbilityTagsBlocked // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8aa30
	void AddSpawnedAttribute(struct UAbilitySystemComponent* AbilitySystemComponent, struct UAttributeSet* Attribute); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddSpawnedAttribute // (Final|Native|Static|Public) // @ game+0x4f8ea20
	void AddReplicatedLooseGameplayTags(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& GameplayTags); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddReplicatedLooseGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8ac70
	void AddReplicatedLooseGameplayTag(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag& GameplayTag); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddReplicatedLooseGameplayTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f94b50
	void AddLooseGameplayTags(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& GameplayTags, int32_t Count); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddLooseGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f975d0
	void AddLooseGameplayTag(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag& GameplayTag, int32_t Count); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddLooseGameplayTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8ed20
	void AddGameplayCueWithParameters(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& GameplayCueParameters); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddGameplayCueWithParameters // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8b400
	void AddGameplayCueWithEffectContext(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTag GameplayCueTag, struct FGameplayEffectContextHandle& EffectContext); // Function AngelscriptGAS.AbilitySystemComponentMixinLibrary.AddGameplayCueWithEffectContext // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8eb60
};

// Class AngelscriptGAS.ActiveGameplayEffecteMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UActiveGameplayEffecteMixinLibrary : UObject {

	struct FGameplayEffectSpec GetSpec(struct FActiveGameplayEffect& ActiveGameplayEffect); // Function AngelscriptGAS.ActiveGameplayEffecteMixinLibrary.GetSpec // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4f93ff0
};

// Class AngelscriptGAS.AngelscriptAbilityAsyncLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptAbilityAsyncLibrary : UBlueprintFunctionLibrary {

	struct UAbilityAsync_WaitGameplayTagRemoved* WaitGameplayTagRemoveFromActor(struct AActor* TargetActor, struct FGameplayTag Tag, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityAsyncLibrary.WaitGameplayTagRemoveFromActor // (Final|Native|Static|Private) // @ game+0x4f926f0
	struct UAbilityAsync_WaitGameplayTagQuery* WaitGameplayTagQueryOnActor(struct AActor* TargetActor, struct FGameplayTagQuery& Query, enum class EWaitGameplayTagQueryTriggerCondition TriggerCondition, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityAsyncLibrary.WaitGameplayTagQueryOnActor // (Final|Native|Static|Private|HasOutParms) // @ game+0x4f956e0
	struct UAbilityAsync_WaitGameplayTagAdded* WaitGameplayTagAddToActor(struct AActor* TargetActor, struct FGameplayTag Tag, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityAsyncLibrary.WaitGameplayTagAddToActor // (Final|Native|Static|Private) // @ game+0x4f8c1a0
	struct UAbilityAsync_WaitGameplayEvent* WaitGameplayEventToActor(struct AActor* TargetActor, struct FGameplayTag Tag, bool bTriggerOnce, bool bMatchExact); // Function AngelscriptGAS.AngelscriptAbilityAsyncLibrary.WaitGameplayEventToActor // (Final|Native|Static|Private) // @ game+0x4f8c370
	struct UAbilityAsync_WaitAttributeChanged* WaitForAttributeChanged(struct AActor* TargetActor, struct FGameplayAttribute& Attribute, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityAsyncLibrary.WaitForAttributeChanged // (Final|Native|Static|Private|HasOutParms) // @ game+0x4f92310
};

// Class AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptAttributeChangedDataMixinLibrary : UObject {

	struct UAbilitySystemComponent* GetTargetAbilitySystemComponent(struct FAngelscriptAttributeChangedData& Data); // Function AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary.GetTargetAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f90650
	float GetOldValue(struct FAngelscriptAttributeChangedData& Data); // Function AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary.GetOldValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8d610
	float GetNewValue(struct FAngelscriptAttributeChangedData& Data); // Function AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary.GetNewValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8cc10
	struct FGameplayModifierEvaluatedData GetGameplayModifierEvaluatedData(struct FAngelscriptAttributeChangedData& Data, bool& bIsValid); // Function AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary.GetGameplayModifierEvaluatedData // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f96f70
	struct FGameplayAttribute GetGameplayAttribute(struct FAngelscriptAttributeChangedData& Data); // Function AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary.GetGameplayAttribute // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f939c0
	struct FGameplayEffectSpec GetEffectSpec(struct FAngelscriptAttributeChangedData& Data, bool& bIsValid); // Function AngelscriptGAS.AngelscriptAttributeChangedDataMixinLibrary.GetEffectSpec // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f8d020
};

// Class AngelscriptGAS.AngelscriptAbilitySystemComponent
// Size: 0x1400 (Inherited: 0x1350)
struct UAngelscriptAbilitySystemComponent : UAbilitySystemComponent {
	struct FMulticastInlineDelegate OnInitAbilityActorInfo; // 0x1350(0x10)
	struct FMulticastInlineDelegate OnAbilityGiven; // 0x1360(0x10)
	struct FMulticastInlineDelegate OnAbilityRemoved; // 0x1370(0x10)
	struct FMulticastInlineDelegate OnAttributeChanged; // 0x1380(0x10)
	struct FMulticastInlineDelegate OnOwnedTagUpdated; // 0x1390(0x10)
	struct FMulticastInlineDelegate OnAbilityActivatedDynamic; // 0x13a0(0x10)
	struct FMulticastInlineDelegate OnAbilityCommittedDynamic; // 0x13b0(0x10)
	struct FMulticastInlineDelegate OnAbilityEndedDynamic; // 0x13c0(0x10)
	struct FMulticastInlineDelegate OnAbilityEndedWithDataDynamic; // 0x13d0(0x10)
	struct FMulticastInlineDelegate OnAbilityFailedDynamic; // 0x13e0(0x10)
	char pad_13f0[0x10]; // 0x13f0(0x10)

	bool TrySetAttributeBaseValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float NewBaseValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.TrySetAttributeBaseValue // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8c840
	bool TryGetFilteredAttributeValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, struct FGameplayTagRequirements& SourceTags, struct FGameplayTagContainer& TargetTags, float& OutValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.TryGetFilteredAttributeValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4f93710
	bool TryGetAttributeCurrentValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float& OutCurrentValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.TryGetAttributeCurrentValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f96dd0
	bool TryGetAttributeBaseValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float& OutBaseValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.TryGetAttributeBaseValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f94390
	bool TryActivateAbilitySpec(struct FGameplayAbilitySpecHandle& Handle, bool bAllowRemoteActivation); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.TryActivateAbilitySpec // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4f90230
	void SetAttributeBaseValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float NewBaseValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.SetAttributeBaseValue // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8d9c0
	void SetAbilitySpecSourceObject(struct FGameplayAbilitySpecHandle AbilitySpecHandle, struct UObject* NewSourceObject); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.SetAbilitySpecSourceObject // (Final|Native|Public|BlueprintCallable) // @ game+0x4f900b0
	void RegisterCallbackForAttribute(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.RegisterCallbackForAttribute // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8dcc0
	struct UAngelscriptAttributeSet* RegisterAttributeSet(struct UAngelscriptAttributeSet* AttributeSetClass); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.RegisterAttributeSet // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8f760
	void RegisterAttributeChangedCallback(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, struct UObject* CallbackObject, struct FName CallbackFunctionName_FAngelscriptAttributeChangedData); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.RegisterAttributeChangedCallback // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8c9b0
	void OnAttributeSetRegistered(struct UObject* InObject, struct FName InFunctionName); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.OnAttributeSetRegistered // (Final|Native|Public|BlueprintCallable) // @ game+0x4f97c00
	void ModAttributeUnsafe(struct FGameplayAttribute GameplayAttribute, enum class EGameplayModOp ModifierOp, float ModifierMagnitude); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.ModAttributeUnsafe // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8fb20
	bool IsAbilitySpecActive(struct FGameplayAbilitySpecHandle AbilitySpecHandle); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.IsAbilitySpecActive // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f8bde0
	bool IsAbilityActive(struct UGameplayAbility* InAbilityClass); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.IsAbilityActive // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f8b8e0
	bool HasGameplayTag(struct FGameplayTag TagToCheck); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.HasGameplayTag // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f95ba0
	bool HasAnyGameplayTags(struct FGameplayTagContainer& TagContainer); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.HasAnyGameplayTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8d1f0
	bool HasAllGameplayTags(struct FGameplayTagContainer& TagContainer); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.HasAllGameplayTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f92240
	bool HasAbilitySpec(struct FGameplayAbilitySpecHandle AbilitySpecHandle); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.HasAbilitySpec // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f928d0
	bool HasAbility(struct UGameplayAbility* InAbilityClass); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.HasAbility // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f93c60
	struct APlayerController* GetPlayerController(); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetPlayerController // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8f810
	float GetCooldownTimeRemaining(struct UGameplayAbility* InAbilityClass); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetCooldownTimeRemaining // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f942a0
	struct AActor* GetAvatar(); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAvatar // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8c340
	float GetAttributeCurrentValueChecked(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAttributeCurrentValueChecked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8e1b0
	float GetAttributeCurrentValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float DefaultValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAttributeCurrentValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f95fb0
	float GetAttributeBaseValueChecked(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAttributeBaseValueChecked // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8ba10
	float GetAttributeBaseValue(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float DefaultValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAttributeBaseValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f93270
	void GetAndRegisterCallbackForAttribute(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, float& OutCurrentValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAndRegisterCallbackForAttribute // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8de00
	void GetAndRegisterAttributeChangedCallback(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, struct UObject* CallbackObject, struct FName CallbackFunctionName_FAngelscriptAttributeChangedData, float& OutCurrentValue); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAndRegisterAttributeChangedCallback // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4f8f160
	void GetActiveAbilitiesWithTags(struct FGameplayTagContainer& GameplayTagContainer, struct TArray<struct UGameplayAbility*>& ActiveAbilities); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetActiveAbilitiesWithTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8feb0
	struct UObject* GetAbilitySpecSourceObject(struct FGameplayAbilitySpecHandle AbilitySpecHandle); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAbilitySpecSourceObject // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f93f00
	struct FGameplayAbilityActorInfo GetAbilityActorInfo(); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAbilityActorInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8eea0
	void GetAbilitiesWithTags(struct FGameplayTagContainer& GameplayTagContainer, struct TArray<struct UGameplayAbility*>& Abilities); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.GetAbilitiesWithTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f924f0
	void CancelAbilityByHandle(struct FGameplayAbilitySpecHandle& AbilityHandle); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CancelAbilityByHandle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4f95630
	void CancelAbility(struct UGameplayAbility* InAbilityClass); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CancelAbility // (Final|Native|Public|BlueprintCallable) // @ game+0x4f8b110
	void CancelAbilitiesByTags(struct FGameplayTagContainer& WithTags, struct FGameplayTagContainer& WithoutTags, struct UGameplayAbility* Ignore); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CancelAbilitiesByTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4f96a20
	bool CanActivateAnyAbilityWithTags(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CanActivateAnyAbilityWithTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8b6a0
	bool CanActivateAnyAbilityWithTag(struct FGameplayTag& GameplayTag); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CanActivateAnyAbilityWithTag // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f941e0
	bool CanActivateAbilitySpec(struct FGameplayAbilitySpecHandle AbilitySpecHandle); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CanActivateAbilitySpec // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f94870
	bool CanActivateAbilityByClass(struct UGameplayAbility* InAbilityToActivate); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.CanActivateAbilityByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f8bb20
	void BP_SetRemoveAbilityOnEnd(struct FGameplayAbilitySpecHandle AbilitySpecHandle); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BP_SetRemoveAbilityOnEnd // (Final|Native|Public|BlueprintCallable) // @ game+0x4f96cf0
	void BP_InitAbilityActorInfo(struct AActor* InOwnerActor, struct AActor* InAvatarActor); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BP_InitAbilityActorInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x4f974d0
	struct FGameplayAbilitySpecHandle BP_GiveAbilityWithSourceObject(struct UGameplayAbility* InAbilityClass, int32_t Level, int32_t OptionalInputID, struct UObject* OptionalSourceObject); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BP_GiveAbilityWithSourceObject // (Final|Native|Public|BlueprintCallable) // @ game+0x4f94920
	struct FGameplayAbilitySpecHandle BP_GiveAbilityAndActivateOnceWithSourceObject(struct UGameplayAbility* InAbilityClass, int32_t Level, int32_t OptionalInputID, struct UObject* OptionalSourceObject); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BP_GiveAbilityAndActivateOnceWithSourceObject // (Final|Native|Public|BlueprintCallable) // @ game+0x4f95440
	bool BlueprintUnRegisterGameplayTagEvent(struct FDelegateHandleWrapper Handle, struct FGameplayTag Tag, enum class EGameplayTagEventType EventType); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BlueprintUnRegisterGameplayTagEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x4f95cd0
	struct FDelegateHandleWrapper BlueprintRegisterGameplayTagEvent(struct FDelegate Delegate, struct FGameplayTag Tag, enum class EGameplayTagEventType EventType); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BlueprintRegisterGameplayTagEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x4f90450
	struct FDelegateHandleWrapper BlueprintRegisterAndCallGameplayTagEvent(struct FDelegate Delegate, struct FGameplayTag Tag, enum class EGameplayTagEventType EventType); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BlueprintRegisterAndCallGameplayTagEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x4f96370
	void BindInput(struct UInputComponent* InputComponent, struct FAngelscriptInputBindData BindData); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.BindInput // (Final|Native|Public|BlueprintCallable) // @ game+0x4f91e30
	bool ActivateAbilitiesUsingTags(struct FGameplayTagContainer& GameplayTagContainer, bool bAllowRemoteActivation); // Function AngelscriptGAS.AngelscriptAbilitySystemComponent.ActivateAbilitiesUsingTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4f93420
};

// Class AngelscriptGAS.AngelscriptAbilityTask
// Size: 0xf0 (Inherited: 0xf0)
struct UAngelscriptAbilityTask : UAbilityTask {

	void SetIsTickingTask(bool bNewState); // Function AngelscriptGAS.AngelscriptAbilityTask.SetIsTickingTask // (Final|Native|Public|BlueprintCallable) // @ game+0x4f9d630
	void SetIsSimulatedTask(bool bNewState); // Function AngelscriptGAS.AngelscriptAbilityTask.SetIsSimulatedTask // (Final|Native|Public|BlueprintCallable) // @ game+0x4fa12c0
	void SetIsPausable(bool bNewState); // Function AngelscriptGAS.AngelscriptAbilityTask.SetIsPausable // (Final|Native|Public|BlueprintCallable) // @ game+0x4f9c240
	bool GetIsTickingTask(); // Function AngelscriptGAS.AngelscriptAbilityTask.GetIsTickingTask // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4fa17c0
	bool GetIsSimulating(); // Function AngelscriptGAS.AngelscriptAbilityTask.GetIsSimulating // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f9b950
	bool GetIsSimulatedTask(); // Function AngelscriptGAS.AngelscriptAbilityTask.GetIsSimulatedTask // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f9a270
	bool GetIsPausable(); // Function AngelscriptGAS.AngelscriptAbilityTask.GetIsPausable // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f98ff0
	struct UAngelscriptAbilityTask* CreateAbilityTaskAndRunIt(struct UAngelscriptAbilityTask* TaskType, struct UGameplayAbility* ThisAbility, struct FName NewInstanceName); // Function AngelscriptGAS.AngelscriptAbilityTask.CreateAbilityTaskAndRunIt // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4f9cbe0
	struct UAngelscriptAbilityTask* CreateAbilityTask(struct UAngelscriptAbilityTask* TaskType, struct UGameplayAbility* ThisAbility, struct FName NewInstanceName); // Function AngelscriptGAS.AngelscriptAbilityTask.CreateAbilityTask // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4f98190
	void BP_TickTask(float DeltaTimeSecs); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_TickTask // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool BP_ShouldBroadcastAbilityTaskDelegates(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_ShouldBroadcastAbilityTaskDelegates // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fa1e70
	void BP_SetWaitingOnRemotePlayerData(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_SetWaitingOnRemotePlayerData // (Final|Native|Public|BlueprintCallable) // @ game+0x4f9b690
	void BP_SetWaitingOnAvatar(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_SetWaitingOnAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0x4f9a960
	void BP_SetAbilitySystemComponent(struct UAbilitySystemComponent* InAbilitySystemComponent); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_SetAbilitySystemComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x4f9f7c0
	void BP_OnDestroy(bool bInOwnerFinished); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_OnDestroy // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool BP_IsWaitingOnRemotePlayerdata(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_IsWaitingOnRemotePlayerdata // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x31d1f50
	bool BP_IsWaitingOnAvatar(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_IsWaitingOnAvatar // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x15c6d40
	bool BP_IsPredictingClient(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_IsPredictingClient // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f9ee50
	bool BP_IsLocallyControlled(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_IsLocallyControlled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f9f750
	bool BP_IsForRemoteClient(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_IsForRemoteClient // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f9a570
	void BP_InitSimulatedTask(struct UGameplayTasksComponent* InGameplayTasksComponent); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_InitSimulatedTask // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UAbilitySystemComponent* BP_GetAbilitySystemComponent(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_GetAbilitySystemComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4f9cd70
	struct FGameplayAbilitySpecHandle BP_GetAbilitySpecHandle(bool bInOwnerFinished); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_GetAbilitySpecHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f9a8a0
	struct UGameplayAbility* BP_GetAbility(bool bInOwnerFinished); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_GetAbility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4f9fcc0
	void BP_ClearWaitingOnRemotePlayerData(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_ClearWaitingOnRemotePlayerData // (Final|Native|Public|BlueprintCallable) // @ game+0x4fa4700
	void BP_ClearWaitingOnAvatar(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_ClearWaitingOnAvatar // (Final|Native|Public|BlueprintCallable) // @ game+0x4fa0d90
	void BP_Activate(); // Function AngelscriptGAS.AngelscriptAbilityTask.BP_Activate // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptGAS.AngelscriptAbilityTaskLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptAbilityTaskLibrary : UBlueprintFunctionLibrary {

	struct UAbilityTask_WaitVelocityChange* WaitVelocityChange(struct UGameplayAbility* OwningAbility, struct FVector& Direction, float MinimumMagnitude); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitVelocityChange // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4fa3b10
	struct UAbilityTask_WaitTargetData* WaitTargetDataUsingActor(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* TargetActor); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitTargetDataUsingActor // (Final|Native|Static|Public) // @ game+0x4f9f420
	struct UAbilityTask_WaitTargetData* WaitTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, enum class EGameplayTargetingConfirmation ConfirmationType, struct AGameplayAbilityTargetActor* TargetClass); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitTargetData // (Final|Native|Static|Public) // @ game+0x4f9c060
	struct UAbilityTask_NetworkSyncPoint* WaitNetSync(struct UGameplayAbility* OwningAbility, enum class EAbilityTaskNetSyncType SyncType); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitNetSync // (Final|Native|Static|Public) // @ game+0x4f97eb0
	struct UAbilityTask_WaitMovementModeChange* WaitMovementModeChange(struct UGameplayAbility* OwningAbility, enum class EMovementMode NewMode); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitMovementModeChange // (Final|Native|Static|Public) // @ game+0x4f9c6c0
	struct UAbilityTask_WaitInputRelease* WaitInputRelease(struct UGameplayAbility* OwningAbility, bool bTestAlreadyReleased); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitInputRelease // (Final|Native|Static|Public) // @ game+0x4f9a170
	struct UAbilityTask_WaitInputPress* WaitInputPress(struct UGameplayAbility* OwningAbility, bool bTestAlreadyPressed); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitInputPress // (Final|Native|Static|Public) // @ game+0x4f9ec30
	struct UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* ExternalTarget, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayTagRemove // (Final|Native|Static|Public) // @ game+0x4fa3c70
	struct UAbilityTask_WaitGameplayTagQuery* WaitGameplayTagQuery(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery& Query, struct AActor* ExternalTarget, enum class EWaitGameplayTagQueryTriggerCondition TriggerCondition, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayTagQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f9a2e0
	struct UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* ExternalTarget, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayTagAdd // (Final|Native|Static|Public) // @ game+0x4f9aac0
	struct UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* ExternalTarget, bool bTriggerOnce, bool bMatchExact); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayEvent // (Final|Native|Static|Public) // @ game+0x4fa0860
	struct UAbilityTask_WaitGameplayEffectBlockedImmunity* WaitGameplayEffectBlockedByImmunity(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements& SourceTagRequirements, struct FGameplayTagRequirements& TargetTagRequirements, struct AActor* ExternalTarget, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayEffectBlockedByImmunity // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f9d250
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTargetQuery(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle& Filter, struct FGameplayTagQuery& SourceTagQuery, struct FGameplayTagQuery& TargetTagQuery, bool bTriggerOnce, struct AActor* ExternalOwner, bool bListenForPeriodicEffect); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayEffectAppliedToTargetQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa13a0
	struct UAbilityTask_WaitGameplayEffectApplied_Target* WaitGameplayEffectAppliedToTarget(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle& Filter, struct FGameplayTagRequirements& SourceTagRequirements, struct FGameplayTagRequirements& TargetTagRequirements, bool bTriggerOnce, struct AActor* ExternalOwner, bool bListenForPeriodicEffect); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayEffectAppliedToTarget // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa3150
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelfQuery(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle& Filter, struct FGameplayTagQuery& SourceTagQuery, struct FGameplayTagQuery& TargetTagQuery, bool bTriggerOnce, struct AActor* ExternalOwner, bool bListenForPeriodicEffect); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayEffectAppliedToSelfQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f99420
	struct UAbilityTask_WaitGameplayEffectApplied_Self* WaitGameplayEffectAppliedToSelf(struct UGameplayAbility* OwningAbility, struct FGameplayTargetDataFilterHandle& Filter, struct FGameplayTagRequirements& SourceTagRequirements, struct FGameplayTagRequirements& TargetTagRequirements, bool bTriggerOnce, struct AActor* ExternalOwner, bool bListenForPeriodicEffect); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitGameplayEffectAppliedToSelf // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f9ace0
	struct UAbilityTask_WaitOverlap* WaitForOverlap(struct UGameplayAbility* OwningAbility); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForOverlap // (Final|Native|Static|Public) // @ game+0x4fa3530
	struct UAbilityTask_WaitAbilityCommit* WaitForNewAbilityCommitQuery(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery& Query, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForNewAbilityCommitQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f99060
	struct UAbilityTask_WaitAbilityCommit* WaitForNewAbilityCommit(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForNewAbilityCommit // (Final|Native|Static|Public) // @ game+0x4fa19d0
	struct UAbilityTask_WaitGameplayEffectStackChange* WaitForGameplayEffectStackChange(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForGameplayEffectStackChange // (Final|Native|Static|Public) // @ game+0x4f9a080
	struct UAbilityTask_WaitGameplayEffectRemoved* WaitForGameplayEffectRemoved(struct UGameplayAbility* OwningAbility, struct FActiveGameplayEffectHandle Handle); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForGameplayEffectRemoved // (Final|Native|Static|Public) // @ game+0x4f97dc0
	struct UAbilityTask_WaitConfirm* WaitForConfirmInput(struct UGameplayAbility* OwningAbility); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForConfirmInput // (Final|Native|Static|Public) // @ game+0x4fa17f0
	struct UAbilityTask_WaitCancel* WaitForCancelInput(struct UGameplayAbility* OwningAbility); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForCancelInput // (Final|Native|Static|Public) // @ game+0x4f9bbe0
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChangeWithComparison(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute& Attribute, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* ExternalOwner); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAttributeChangeWithComparison // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f9bc80
	struct UAbilityTask_WaitAttributeChangeThreshold* WaitForAttributeChangeThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute& Attribute, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* ExternalOwner); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAttributeChangeThreshold // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa20d0
	struct UAbilityTask_WaitAttributeChangeRatioThreshold* WaitForAttributeChangeRatioThreshold(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute& AttributeNumerator, struct FGameplayAttribute& AttributeDenominator, enum class EWaitAttributeChangeComparison ComparisonType, float ComparisonValue, bool bTriggerOnce, struct AActor* ExternalOwner); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAttributeChangeRatioThreshold // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f9c2e0
	struct UAbilityTask_WaitAttributeChange* WaitForAttributeChange(struct UGameplayAbility* OwningAbility, struct FGameplayAttribute& Attribute, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool bTriggerOnce, struct AActor* ExternalOwner); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAttributeChange // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f9ce10
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateWithTagRequirements(struct UGameplayAbility* OwningAbility, struct FGameplayTagRequirements& TagRequirements, bool bIncludeTriggeredAbilities, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAbilityActivateWithTagRequirements // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa3790
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivateQuery(struct UGameplayAbility* OwningAbility, struct FGameplayTagQuery& Query, bool bIncludeTriggeredAbilities, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAbilityActivateQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x4f99210
	struct UAbilityTask_WaitAbilityActivate* WaitForAbilityActivate(struct UGameplayAbility* OwningAbility, struct FGameplayTag WithTag, struct FGameplayTag WithoutTag, bool bIncludeTriggeredAbilities, bool bTriggerOnce); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitForAbilityActivate // (Final|Native|Static|Public) // @ game+0x4fa1ea0
	struct UAbilityTask_WaitDelay* WaitDelay(struct UGameplayAbility* OwningAbility, float Time); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitDelay // (Final|Native|Static|Public) // @ game+0x4f9bae0
	struct UAbilityTask_WaitConfirmCancel* WaitConfirmCancel(struct UGameplayAbility* OwningAbility); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.WaitConfirmCancel // (Final|Native|Static|Public) // @ game+0x4fa0df0
	struct UAbilityTask_VisualizeTargeting* VisualizeTargetingUsingActor(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* TargetActor, struct FName TaskInstanceName, float Duration); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.VisualizeTargetingUsingActor // (Final|Native|Static|Public) // @ game+0x4f9ddc0
	struct UAbilityTask_VisualizeTargeting* VisualizeTargeting(struct UGameplayAbility* OwningAbility, struct AGameplayAbilityTargetActor* TargetClass, struct FName TaskInstanceName, float Duration); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.VisualizeTargeting // (Final|Native|Static|Public) // @ game+0x4f98940
	struct UAbilityTask_StartAbilityState* StartAbilityState(struct UGameplayAbility* OwningAbility, struct FName StateName, bool bEndCurrentState); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.StartAbilityState // (Final|Native|Static|Public) // @ game+0x4f9b980
	struct UAbilityTask_SpawnActor* SpawnActor(struct UGameplayAbility* OwningAbility, struct FGameplayAbilityTargetDataHandle& TargetData, struct AActor* Class); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.SpawnActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa0e90
	struct UAbilityTask_Repeat* RepeatAction(struct UGameplayAbility* OwningAbility, float TimeBetweenActions, int32_t TotalActionCount); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.RepeatAction // (Final|Native|Static|Public) // @ game+0x4f9dc10
	struct UAbilityTask_PlayMontageAndWait* PlayMontageAndWait(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale, float StartTimeSeconds); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.PlayMontageAndWait // (Final|Native|Static|Public) // @ game+0x4f9d880
	struct UAbilityTask_MoveToLocation* MoveToLocation(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector& Location, float Duration, struct UCurveFloat* InterpolationCurve, struct UCurveVector* VectorInterpolationCurve); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.MoveToLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4f9f180
	struct UAbilityTask_ApplyRootMotionRadialForce* ApplyRootMotionRadialForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector& Location, struct AActor* LocationActor, float Strength, float Duration, float Radius, bool bIsPush, bool bIsAdditive, bool bNoZForce, struct UCurveFloat* StrengthDistanceFalloff, struct UCurveFloat* StrengthOverTime, bool bUseFixedWorldDirection, struct FRotator& FixedWorldDirection, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector& SetVelocityOnFinish, float ClampVelocityOnFinish); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.ApplyRootMotionRadialForce // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4f9fd70
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToTargetDataActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FGameplayAbilityTargetDataHandle& TargetDataHandle, int32_t TargetDataIndex, int32_t TargetActorIndex, struct FVector& TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector& SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.ApplyRootMotionMoveToTargetDataActorForce // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4f9e0b0
	struct UAbilityTask_ApplyRootMotionMoveToForce* ApplyRootMotionMoveToForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector& TargetLocation, float Duration, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector& SetVelocityOnFinish, float ClampVelocityOnFinish); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.ApplyRootMotionMoveToForce // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4fa23c0
	struct UAbilityTask_ApplyRootMotionMoveToActorForce* ApplyRootMotionMoveToActorForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct AActor* TargetActor, struct FVector& TargetLocationOffset, enum class ERootMotionMoveToActorTargetOffsetType OffsetAlignment, float Duration, struct UCurveFloat* TargetLerpSpeedHorizontal, struct UCurveFloat* TargetLerpSpeedVertical, bool bSetNewMovementMode, enum class EMovementMode MovementMode, bool bRestrictSpeedToExpected, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector& SetVelocityOnFinish, float ClampVelocityOnFinish, bool bDisableDestinationReachedInterrupt); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.ApplyRootMotionMoveToActorForce // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4f99840
	struct UAbilityTask_ApplyRootMotionJumpForce* ApplyRootMotionJumpForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FRotator& Rotation, float Distance, float Height, float Duration, float MinimumLandedTriggerTime, bool bFinishOnLanded, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector& SetVelocityOnFinish, float ClampVelocityOnFinish, struct UCurveVector* PathOffsetCurve, struct UCurveFloat* TimeMappingCurve); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.ApplyRootMotionJumpForce // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4fa3e60
	struct UAbilityTask_ApplyRootMotionConstantForce* ApplyRootMotionConstantForce(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct FVector& WorldDirection, float Strength, float Duration, bool bIsAdditive, struct UCurveFloat* StrengthOverTime, enum class ERootMotionFinishVelocityMode VelocityOnFinishMode, struct FVector& SetVelocityOnFinish, float ClampVelocityOnFinish, bool bEnableGravity); // Function AngelscriptGAS.AngelscriptAbilityTaskLibrary.ApplyRootMotionConstantForce // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x4f983c0
};

// Class AngelscriptGAS.AngelscriptAttributeSet
// Size: 0xb0 (Inherited: 0xa0)
struct UAngelscriptAttributeSet : UAttributeSet {
	struct TArray<struct FName> ReplicatedAttributeBlackList; // 0xa0(0x10)

	bool TrySetAttributeBaseValue(struct FName AttributeName, float NewBaseValue); // Function AngelscriptGAS.AngelscriptAttributeSet.TrySetAttributeBaseValue // (Final|Native|Public|BlueprintCallable) // @ game+0x4fabc80
	bool TryGetGameplayAttribute(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName, struct FGameplayAttribute& OutGameplayAttribute); // Function AngelscriptGAS.AngelscriptAttributeSet.TryGetGameplayAttribute // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fadce0
	bool TryGetAttributeCurrentValue(struct FName AttributeName, float& OutCurrentValue); // Function AngelscriptGAS.AngelscriptAttributeSet.TryGetAttributeCurrentValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fa8230
	bool TryGetAttributeBaseValue(struct FName AttributeName, float& OutBaseValue); // Function AngelscriptGAS.AngelscriptAttributeSet.TryGetAttributeBaseValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fa5a30
	void OnRep_Attribute(struct FAngelscriptGameplayAttributeData& OldAttributeData); // Function AngelscriptGAS.AngelscriptAttributeSet.OnRep_Attribute // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa4a10
	void InitFromMetaDataTable(struct UDataTable* DataTable); // Function AngelscriptGAS.AngelscriptAttributeSet.InitFromMetaDataTable // (Native|Public|BlueprintCallable) // @ game+0x4fad190
	struct FGameplayAttribute GetGameplayAttribute(struct UAngelscriptAttributeSet* AttributeSetClass, struct FName AttributeName); // Function AngelscriptGAS.AngelscriptAttributeSet.GetGameplayAttribute // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4fa8e40
	bool CompareGameplayAttributes(struct FGameplayAttribute& First, struct FGameplayAttribute& Second); // Function AngelscriptGAS.AngelscriptAttributeSet.CompareGameplayAttributes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fad4b0
	bool BP_PreGameplayEffectExecute(struct FGameplayEffectSpec& EffectSpec, struct FGameplayModifierEvaluatedData& EvaluatedData, struct UAngelscriptAbilitySystemComponent* AbilitySystemComponent); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_PreGameplayEffectExecute // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4fa69e0
	void BP_PreAttributeChange(struct FGameplayAttribute& Attribute, float& NewValue); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_PreAttributeChange // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void BP_PreAttributeBaseChange(struct FGameplayAttribute& Attribute, float& NewValue); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_PreAttributeBaseChange // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void BP_PostGameplayEffectExecute(struct FGameplayEffectSpec& EffectSpec, struct FGameplayModifierEvaluatedData& EvaluatedData, struct UAngelscriptAbilitySystemComponent* AbilitySystemComponent); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_PostGameplayEffectExecute // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void BP_PostAttributeChange(struct FGameplayAttribute& Attribute, float OldValue, float NewValue); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_PostAttributeChange // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void BP_PostAttributeBaseChange(struct FGameplayAttribute& Attribute, float OldValue, float NewValue); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_PostAttributeBaseChange // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	bool BP_OnInitFromMetaDataTable(struct UDataTable* DataTable); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_OnInitFromMetaDataTable // (Native|Event|Public|BlueprintEvent) // @ game+0x4faf1c0
	struct AActor* BP_GetOwningActor(); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_GetOwningActor // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x4fa4fd0
	struct UAngelscriptAbilitySystemComponent* BP_GetOwningAbilitySystemComponent(); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_GetOwningAbilitySystemComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fa9f70
	struct FGameplayAbilityActorInfo BP_GetActorInfo(); // Function AngelscriptGAS.AngelscriptAttributeSet.BP_GetActorInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fa8df0
};

// Class AngelscriptGAS.AngelscriptGameplayAttributeDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptGameplayAttributeDataMixinLibrary : UObject {

	void SetCurrentValue(struct FAngelscriptGameplayAttributeData& Data, float NewValue); // Function AngelscriptGAS.AngelscriptGameplayAttributeDataMixinLibrary.SetCurrentValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fae300
	void SetBaseValue(struct FAngelscriptGameplayAttributeData& Data, float NewValue); // Function AngelscriptGAS.AngelscriptGameplayAttributeDataMixinLibrary.SetBaseValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa8b40
	void Initialize(struct FAngelscriptGameplayAttributeData& Data, float InitialData); // Function AngelscriptGAS.AngelscriptGameplayAttributeDataMixinLibrary.Initialize // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4faebf0
	float GetCurrentValue(struct FAngelscriptGameplayAttributeData& Data); // Function AngelscriptGAS.AngelscriptGameplayAttributeDataMixinLibrary.GetCurrentValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4faf5d0
	float GetBaseValue(struct FAngelscriptGameplayAttributeData& Data); // Function AngelscriptGAS.AngelscriptGameplayAttributeDataMixinLibrary.GetBaseValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fabf10
};

// Class AngelscriptGAS.AngelscriptGameplayCueUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptGameplayCueUtils : UBlueprintFunctionLibrary {

	void RemoveLocalGameplayCue(struct AActor* TargetActor, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& Parameters); // Function AngelscriptGAS.AngelscriptGameplayCueUtils.RemoveLocalGameplayCue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fad890
	struct AGameplayCueNotify_Actor* FindInstancedCueActor(struct AActor* TargetActor, struct FGameplayTag& Tag, struct AActor* InstigatorActor, struct UObject* SourceObj); // Function AngelscriptGAS.AngelscriptGameplayCueUtils.FindInstancedCueActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa4c80
	void ExecuteLocalGameplayCue(struct AActor* TargetActor, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& Parameters); // Function AngelscriptGAS.AngelscriptGameplayCueUtils.ExecuteLocalGameplayCue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fae070
	void AddLocalGameplayCue(struct AActor* TargetActor, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& Parameters); // Function AngelscriptGAS.AngelscriptGameplayCueUtils.AddLocalGameplayCue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4faa590
};

// Class AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectExecutionParametersMixinLibrary : UObject {

	void SetTargetTags(struct FGameplayEffectExecutionParameters& Data, struct FGameplayTagContainer& TargetTags); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.SetTargetTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x4faa860
	void SetSourceTags(struct FGameplayEffectExecutionParameters& Data, struct FGameplayTagContainer& SourceTags); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.SetSourceTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fab3f0
	void SetIncludePredictiveMods(struct FGameplayEffectExecutionParameters& Data, bool bShouldIncludePredictiveMods); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.SetIncludePredictiveMods // (Final|Native|Static|Public|HasOutParms) // @ game+0x4faee40
	void SetCapturedSourceTagsFromSpec(struct FGameplayEffectExecutionParameters& Data, struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.SetCapturedSourceTagsFromSpec // (Final|Native|Static|Public|HasOutParms) // @ game+0x4faca50
	bool GetIncludePredictiveMods(struct FGameplayEffectExecutionParameters& Data); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.GetIncludePredictiveMods // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa4e70
	struct TArray<struct FActiveGameplayEffectHandle> GetIgnoreHandles(struct FGameplayEffectExecutionParameters& Data); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.GetIgnoreHandles // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fadb20
	struct FGameplayTagContainer GetAppliedTargetTagFilter(struct FGameplayEffectExecutionParameters& Data); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.GetAppliedTargetTagFilter // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fad380
	struct FGameplayTagContainer GetAppliedSourceTagFilter(struct FGameplayEffectExecutionParameters& Data); // Function AngelscriptGAS.GameplayEffectExecutionParametersMixinLibrary.GetAppliedSourceTagFilter // (Final|Native|Static|Public|HasOutParms) // @ game+0x4faf410
};

// Class AngelscriptGAS.AngelscriptGameplayEffectUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptGameplayEffectUtils : UBlueprintFunctionLibrary {

	struct FGameplayModifierEvaluatedData MakeGameplayModifierEvaluationData(struct FGameplayAttribute& InAttribute, enum class EGameplayModOp InModOp, float InMagnitude); // Function AngelscriptGAS.AngelscriptGameplayEffectUtils.MakeGameplayModifierEvaluationData // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fab0d0
	struct FGameplayEffectExecutionScopedModifierInfo MakeGameplayEffectExecutionScopedModifierInfo(struct FGameplayEffectAttributeCaptureDefinition& InCaptureDef); // Function AngelscriptGAS.AngelscriptGameplayEffectUtils.MakeGameplayEffectExecutionScopedModifierInfo // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa7f30
	struct FGameplayEffectAttributeCaptureDefinition CaptureGameplayAttribute(struct UStruct* AttributeSetType, struct FName AttributeName, enum class EGameplayEffectAttributeCaptureSource InSource, bool bIsSnapshot); // Function AngelscriptGAS.AngelscriptGameplayEffectUtils.CaptureGameplayAttribute // (Final|Native|Static|Public) // @ game+0x4faad40
};

// Class AngelscriptGAS.AngelscriptGASAbility
// Size: 0x460 (Inherited: 0x460)
struct UAngelscriptGASAbility : UGameplayAbility {

	void K2_RemoveGameplayCue_Static(struct UGameplayCueNotify_Static* GameplayCue); // Function AngelscriptGAS.AngelscriptGASAbility.K2_RemoveGameplayCue_Static // (Native|Public|BlueprintCallable) // @ game+0x4fa5cc0
	void K2_RemoveGameplayCue_Actor(struct AGameplayCueNotify_Actor* GameplayCue); // Function AngelscriptGAS.AngelscriptGASAbility.K2_RemoveGameplayCue_Actor // (Native|Public|BlueprintCallable) // @ game+0x4fac960
	void K2_ExecuteGameplayCueWithParams_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayCueParameters& GameplayCueParameters); // Function AngelscriptGAS.AngelscriptGASAbility.K2_ExecuteGameplayCueWithParams_Static // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa73a0
	void K2_ExecuteGameplayCueWithParams_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayCueParameters& GameplayCueParameters); // Function AngelscriptGAS.AngelscriptGASAbility.K2_ExecuteGameplayCueWithParams_Actor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fae980
	void K2_ExecuteGameplayCue_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayEffectContextHandle Context); // Function AngelscriptGAS.AngelscriptGASAbility.K2_ExecuteGameplayCue_Static // (Native|Public|BlueprintCallable) // @ game+0x4faf270
	void K2_ExecuteGameplayCue_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayEffectContextHandle Context); // Function AngelscriptGAS.AngelscriptGASAbility.K2_ExecuteGameplayCue_Actor // (Native|Public|BlueprintCallable) // @ game+0x4fa76b0
	void K2_AddGameplayCueWithParams_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayCueParameters& GameplayCueParameter, bool bRemoveOnAbilityEnd); // Function AngelscriptGAS.AngelscriptGASAbility.K2_AddGameplayCueWithParams_Static // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa8330
	void K2_AddGameplayCueWithParams_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayCueParameters& GameplayCueParameter, bool bRemoveOnAbilityEnd); // Function AngelscriptGAS.AngelscriptGASAbility.K2_AddGameplayCueWithParams_Actor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fac0b0
	void K2_AddGameplayCue_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // Function AngelscriptGAS.AngelscriptGASAbility.K2_AddGameplayCue_Static // (Native|Public|BlueprintCallable) // @ game+0x4fac3f0
	void K2_AddGameplayCue_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // Function AngelscriptGAS.AngelscriptGASAbility.K2_AddGameplayCue_Actor // (Native|Public|BlueprintCallable) // @ game+0x4fa8c40
};

// Class AngelscriptGAS.AngelscriptGASActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct AAngelscriptGASActor : AActor {
	struct UAngelscriptAbilitySystemComponent* AbilitySystem; // 0x3a0(0x08)
	char pad_3a8[0x8]; // 0x3a8(0x08)
};

// Class AngelscriptGAS.AngelscriptGASCharacter
// Size: 0x790 (Inherited: 0x780)
struct AAngelscriptGASCharacter : ACharacter {
	char pad_780[0x8]; // 0x780(0x08)
	struct UAngelscriptAbilitySystemComponent* AbilitySystem; // 0x788(0x08)

	void SetupCharacterInput(struct UInputComponent* PlayerInputComponent); // Function AngelscriptGAS.AngelscriptGASCharacter.SetupCharacterInput // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptGAS.AngelscriptGASPawn
// Size: 0x430 (Inherited: 0x420)
struct AAngelscriptGASPawn : APawn {
	char pad_420[0x8]; // 0x420(0x08)
	struct UAngelscriptAbilitySystemComponent* AbilitySystem; // 0x428(0x08)

	void SetupPawnInput(struct UInputComponent* PlayerInputComponent); // Function AngelscriptGAS.AngelscriptGASPawn.SetupPawnInput // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayAbilityActorInfoMixinLibrary : UObject {

	void SetSkeletalMeshComponent(struct FGameplayAbilityActorInfo& Info, struct USkeletalMeshComponent* Component); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetSkeletalMeshComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa5550
	void SetPlayerController(struct FGameplayAbilityActorInfo& Info, struct APlayerController* Controller); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetPlayerController // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa6810
	void SetOwnerActor(struct FGameplayAbilityActorInfo& Info, struct AActor* Actor); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetOwnerActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa8950
	void SetMovementComponent(struct FGameplayAbilityActorInfo& Info, struct UMovementComponent* Instance); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetMovementComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4facf70
	void SetAvatarActor(struct FGameplayAbilityActorInfo& Info, struct AActor* Actor); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetAvatarActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa92b0
	void SetAnimInstance(struct FGameplayAbilityActorInfo& Info, struct UAnimInstance* Instance); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetAnimInstance // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fad080
	void SetAffectedAnimInstanceTag(struct FGameplayAbilityActorInfo& Info, struct FName Name); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetAffectedAnimInstanceTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa8600
	void SetAbilitySystemComponent(struct FGameplayAbilityActorInfo& Info, struct UAbilitySystemComponent* Component); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.SetAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa4ad0
	bool IsNetAuthority(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.IsNetAuthority // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa8a70
	bool IsLocallyControlledPlayer(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.IsLocallyControlledPlayer // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa9450
	bool IsLocallyControlled(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.IsLocallyControlled // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa9510
	void InitFromActor(struct FGameplayAbilityActorInfo& Info, struct AActor* OwnerActor, struct AActor* AvatarActor, struct UAbilitySystemComponent* InAbilitySystemComponent); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.InitFromActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa62b0
	struct USkeletalMeshComponent* GetSkeletalMeshComponent(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetSkeletalMeshComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa75d0
	struct APlayerController* GetPlayerController(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetPlayerController // (Final|Native|Static|Public|HasOutParms) // @ game+0x4facc10
	struct AActor* GetOwnerActor(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetOwnerActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fae7a0
	struct UMovementComponent* GetMovementComponent(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetMovementComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa9680
	struct AActor* GetAvatarActor(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetAvatarActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x4faaa00
	struct UAnimInstance* GetAnimInstanceFromSkeletalMesh(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetAnimInstanceFromSkeletalMesh // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa5bf0
	struct UAnimInstance* GetAnimInstance(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetAnimInstance // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fab880
	struct FName GetAffectedAnimInstanceTag(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetAffectedAnimInstanceTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa8fb0
	struct UAbilitySystemComponent* GetAbilitySystemComponent(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.GetAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fa5230
	void ClearActorInfo(struct FGameplayAbilityActorInfo& Info); // Function AngelscriptGAS.GameplayAbilityActorInfoMixinLibrary.ClearActorInfo // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fad240
};

// Class AngelscriptGAS.GameplayAbilityMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayAbilityMixinLibrary : UObject {

	struct UObject* GetSourceObject(struct UGameplayAbility* Ability, struct FGameplayAbilitySpecHandle Handle, struct FGameplayAbilityActorInfo& ActorInfo); // Function AngelscriptGAS.GameplayAbilityMixinLibrary.GetSourceObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb2a40
};

// Class AngelscriptGAS.GameplayCueParametersMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayCueParametersMixinLibrary : UObject {

	void SetTargetAttachComponent(struct FGameplayCueParameters& GameplayCueParams, struct USceneComponent* TargetAttachComponent); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.SetTargetAttachComponent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb2e70
	void SetSourceObject(struct FGameplayCueParameters& GameplayCueParams, struct UObject* SourceObject); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.SetSourceObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb52e0
	void SetPhysicalMaterial(struct FGameplayCueParameters& GameplayCueParams, struct UPhysicalMaterial* PhysicalMaterial); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.SetPhysicalMaterial // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb25f0
	void SetInstigator(struct FGameplayCueParameters& GameplayCueParams, struct AActor* Instigator); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.SetInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4faf6b0
	void SetEffectCauser(struct FGameplayCueParameters& GameplayCueParams, struct AActor* EffectCauser); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.SetEffectCauser // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb63b0
	struct USceneComponent* GetTargetAttachComponent(struct FGameplayCueParameters& GameplayCueParams); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.GetTargetAttachComponent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fafde0
	struct UObject* GetSourceObject(struct FGameplayCueParameters& GameplayCueParams); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.GetSourceObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb2310
	struct UPhysicalMaterial* GetPhysicalMaterial(struct FGameplayCueParameters& GameplayCueParams); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.GetPhysicalMaterial // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb2130
	struct AActor* GetInstigator(struct FGameplayCueParameters& GameplayCueParams); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.GetInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb5b80
	struct AActor* GetEffectCauser(struct FGameplayCueParameters& GameplayCueParams); // Function AngelscriptGAS.GameplayCueParametersMixinLibrary.GetEffectCauser // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb4430
};

// Class AngelscriptGAS.GameplayEffectContextHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectContextHandleMixinLibrary : UObject {

	void SetEffectCauser(struct FGameplayEffectContextHandle& Handle, struct AActor* NewEffectCauser); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.SetEffectCauser // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb2860
	void SetAbility(struct FGameplayEffectContextHandle& Handle, struct UGameplayAbility* InGameplayAbility); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.SetAbility // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb11d0
	bool IsValid(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb1310
	bool IsLocallyControlledPlayer(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.IsLocallyControlledPlayer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb5940
	bool IsLocallyControlled(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.IsLocallyControlled // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb24f0
	bool HasOrigin(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.HasOrigin // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb5a80
	struct UObject* GetSourceObject(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetSourceObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb0a50
	void GetOwnedGameplayTags(struct FGameplayEffectContextHandle& Handle, struct FGameplayTagContainer& ActorTagContainer, struct FGameplayTagContainer& SpecTagContainer); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetOwnedGameplayTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb3320
	struct UAbilitySystemComponent* GetOriginalInstigatorAbilitySystemComponent(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetOriginalInstigatorAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb3a70
	struct AActor* GetOriginalInstigator(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetOriginalInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb5510
	struct FVector GetOrigin(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetOrigin // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x4fb1d70
	struct AActor* GetInstigator(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb4600
	bool GetHitResult(struct FGameplayEffectContextHandle& Handle, struct FHitResult& OutHitResult); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetHitResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb1670
	struct AActor* GetEffectCauser(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetEffectCauser // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb0750
	struct TArray<struct AActor*> GetActors(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetActors // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4faffc0
	int32_t GetAbilityLevel(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetAbilityLevel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb4d50
	struct UGameplayAbility* GetAbility(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.GetAbility // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fafb30
	void Clear(struct FGameplayEffectContextHandle& Handle); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.Clear // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb4950
	void AddSourceObject(struct FGameplayEffectContextHandle& Handle, struct UObject* NewSourceObject); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.AddSourceObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb1c30
	void AddOrigin(struct FGameplayEffectContextHandle& Handle, struct FVector InOrigin); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.AddOrigin // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4fb5d50
	void AddInstigator(struct FGameplayEffectContextHandle& Handle, struct AActor* InInstigator, struct AActor* InEffectCauser); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.AddInstigator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb4750
	void AddHitResult(struct FGameplayEffectContextHandle& Handle, struct FHitResult& InHitResult, bool bReset); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.AddHitResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb3df0
	void AddActors(struct FGameplayEffectContextHandle& Handle, struct TArray<struct AActor*>& InActors, bool bReset); // Function AngelscriptGAS.GameplayEffectContextHandleMixinLibrary.AddActors // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb5ff0
};

// Class AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectCustomExecutionOutputMixinLibrary : UObject {

	bool ShouldTriggerConditionalGameplayEffects(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.ShouldTriggerConditionalGameplayEffects // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb3b70
	void MarkStackCountHandledManually(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.MarkStackCountHandledManually // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb3930
	void MarkGameplayCuesHandledManually(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.MarkGameplayCuesHandledManually // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb30a0
	void MarkConditionalGameplayEffectsToTrigger(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.MarkConditionalGameplayEffectsToTrigger // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb0850
	bool IsStackCountHandledManually(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.IsStackCountHandledManually // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fafcd0
	struct TArray<struct FGameplayModifierEvaluatedData> GetOutputModifiersRef(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.GetOutputModifiersRef // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb3820
	struct TArray<struct FGameplayModifierEvaluatedData> GetOutputModifiers(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.GetOutputModifiers // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb2d60
	bool AreGameplayCuesHandledManually(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.AreGameplayCuesHandledManually // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb4ad0
	void AddOutputModifier(struct FGameplayEffectCustomExecutionOutput& CustomExecutionOutput, struct FGameplayModifierEvaluatedData& InOutputMod); // Function AngelscriptGAS.GameplayEffectCustomExecutionOutputMixinLibrary.AddOutputModifier // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb0180
};

// Class AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectCustomExecutionParametersMixinLibrary : UObject {

	struct UAbilitySystemComponent* GetTargetAbilitySystemComponent(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetTargetAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb1450
	struct UAbilitySystemComponent* GetSourceAbilitySystemComponent(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetSourceAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x4faf960
	struct FPredictionKey GetPredictionKey(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetPredictionKey // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb0b90
	struct FGameplayTagContainer GetPassedInTags(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetPassedInTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb2c40
	struct FGameplayEffectSpec GetOwningSpecForPreExecuteMod(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetOwningSpecForPreExecuteMod // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb0c70
	struct FGameplayEffectSpec GetOwningSpec(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetOwningSpec // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb0c70
	struct TArray<struct FActiveGameplayEffectHandle> GetIgnoreHandles(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.GetIgnoreHandles // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb65e0
	void AttemptCalculateTransientAggregatorMagnitude(struct FGameplayEffectCustomExecutionParameters& ExecutionParameters, struct FGameplayTag& InAggregatorIdentifier, struct FGameplayEffectExecutionParameters& InParams, float& OutMagnitude); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.AttemptCalculateTransientAggregatorMagnitude // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb4090
	bool AttemptCalculateCapturedAttributeMagnitudeWithBase(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters, struct FGameplayEffectAttributeCaptureDefinition& InCaptureDef, struct FGameplayEffectExecutionParameters& InParams, float InBaseValue, float& OutMagnitude); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.AttemptCalculateCapturedAttributeMagnitudeWithBase // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb4fd0
	bool AttemptCalculateCapturedAttributeMagnitude(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters, struct FGameplayEffectAttributeCaptureDefinition& InCaptureDef, struct FGameplayEffectExecutionParameters& InParams, float& OutMagnitude); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.AttemptCalculateCapturedAttributeMagnitude // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb1e80
	bool AttemptCalculateCapturedAttributeBonusMagnitude(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters, struct FGameplayEffectAttributeCaptureDefinition& InCaptureDef, struct FGameplayEffectExecutionParameters& InParams, float& OutBonusMagnitude); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.AttemptCalculateCapturedAttributeBonusMagnitude // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb0320
	bool AttemptCalculateCapturedAttributeBaseValue(struct FGameplayEffectCustomExecutionParameters& CustomExecutionParameters, struct FGameplayEffectAttributeCaptureDefinition& InCaptureDef, float& OutBaseValue); // Function AngelscriptGAS.GameplayEffectCustomExecutionParametersMixinLibrary.AttemptCalculateCapturedAttributeBaseValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb5700
};

// Class AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectExecutionDefinitionMixinLibrary : UObject {

	void SetPassedInTags(struct FGameplayEffectExecutionDefinition& Def, struct FGameplayTagContainer& PassedInTags); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.SetPassedInTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbad50
	void SetConditionalGameplayEffects(struct FGameplayEffectExecutionDefinition& Def, struct TArray<struct FConditionalGameplayEffect>& ConditionalGameplayEffects); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.SetConditionalGameplayEffects // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7c60
	void SetCalculationModifiers(struct FGameplayEffectExecutionDefinition& Def, struct TArray<struct FGameplayEffectExecutionScopedModifierInfo>& CalculationModifiers); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.SetCalculationModifiers // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbdd00
	void SetCalculationClass(struct FGameplayEffectExecutionDefinition& Def, struct UGameplayEffectExecutionCalculation*& CalculationClass); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.SetCalculationClass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb76b0
	struct FGameplayTagContainer GetPassedInTags(struct FGameplayEffectExecutionDefinition& Def); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.GetPassedInTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbb800
	struct TArray<struct FConditionalGameplayEffect> GetConditionalGameplayEffects(struct FGameplayEffectExecutionDefinition& Def); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.GetConditionalGameplayEffects // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb9730
	struct TArray<struct FGameplayEffectExecutionScopedModifierInfo> GetCalculationModifiers(struct FGameplayEffectExecutionDefinition& Def); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.GetCalculationModifiers // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb9f70
	struct UGameplayEffectExecutionCalculation* GetCalculationClass(struct FGameplayEffectExecutionDefinition& Def); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.GetCalculationClass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbcd50
	void AddConditionalGameplayEffect(struct FGameplayEffectExecutionDefinition& Def, struct FConditionalGameplayEffect& ConditionalGameplayEffect); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.AddConditionalGameplayEffect // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb77e0
	void AddCalculationModifier(struct FGameplayEffectExecutionDefinition& Def, struct FGameplayEffectExecutionScopedModifierInfo& CalculationModifier); // Function AngelscriptGAS.GameplayEffectExecutionDefinitionMixinLibrary.AddCalculationModifier // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fba890
};

// Class AngelscriptGAS.GameplayEffectExecutionScopedModifierInfoMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectExecutionScopedModifierInfoMixinLibrary : UObject {

	struct FGameplayTag GetTransientAggregatorIdentifier(struct FGameplayEffectExecutionScopedModifierInfo& Handle); // Function AngelscriptGAS.GameplayEffectExecutionScopedModifierInfoMixinLibrary.GetTransientAggregatorIdentifier // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7fa0
	struct FGameplayEffectAttributeCaptureDefinition GetCapturedAttribute(struct FGameplayEffectExecutionScopedModifierInfo& Handle); // Function AngelscriptGAS.GameplayEffectExecutionScopedModifierInfoMixinLibrary.GetCapturedAttribute // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb68a0
	enum class EGameplayEffectScopedModifierAggregatorType GetAggregatorType(struct FGameplayEffectExecutionScopedModifierInfo& Handle); // Function AngelscriptGAS.GameplayEffectExecutionScopedModifierInfoMixinLibrary.GetAggregatorType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb6b80
};

// Class AngelscriptGAS.GameplayEffectSpecHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectSpecHandleMixinLibrary : UObject {

	bool IsValid(struct FGameplayEffectSpecHandle& Handle); // Function AngelscriptGAS.GameplayEffectSpecHandleMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbb030
	struct FGameplayEffectSpec GetSpec_Const(struct FGameplayEffectSpecHandle& Handle); // Function AngelscriptGAS.GameplayEffectSpecHandleMixinLibrary.GetSpec_Const // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb9460
	struct FGameplayEffectSpec GetSpec(struct FGameplayEffectSpecHandle& Handle); // Function AngelscriptGAS.GameplayEffectSpecHandleMixinLibrary.GetSpec // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb9460
	void AddDynamicAssetTags(struct FGameplayEffectSpecHandle& Handle, struct FGameplayTagContainer TagsToAdd); // Function AngelscriptGAS.GameplayEffectSpecHandleMixinLibrary.AddDynamicAssetTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbabd0
	void AddDynamicAssetTag(struct FGameplayEffectSpecHandle& Handle, struct FGameplayTag TagToAdd); // Function AngelscriptGAS.GameplayEffectSpecHandleMixinLibrary.AddDynamicAssetTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbc8f0
};

// Class AngelscriptGAS.GameplayEffectSpecMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectSpecMixinLibrary : UObject {

	struct FString ToSimpleString(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.ToSimpleString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb8470
	void SetupAttributeCaptureDefinitions(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.SetupAttributeCaptureDefinitions // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb7ee0
	void SetLevel(struct FGameplayEffectSpec& Spec, float InLevel); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.SetLevel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fbd120
	void SetContext(struct FGameplayEffectSpec& Spec, struct FGameplayEffectContextHandle NewEffectContextHandle); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.SetContext // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fbd4b0
	void SetByCallerMagnitude(struct FGameplayEffectSpec& Spec, struct FGameplayTag DataTag, float Magnitude); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.SetByCallerMagnitude // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb8a30
	void RecaptureSourceActorTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.RecaptureSourceActorTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fbc540
	void RecaptureAttributeDataForClone(struct FGameplayEffectSpec& Spec, struct UAbilitySystemComponent* OriginalASC, struct UAbilitySystemComponent* NewASC); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.RecaptureAttributeDataForClone // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fbd7b0
	void PrintAll(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.PrintAll // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fbd9e0
	bool HasSetByCallerMagnitudeTag(struct FGameplayEffectSpec& Spec, struct FGameplayTag DataTag); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.HasSetByCallerMagnitudeTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbc740
	int32_t GetStackCount(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetStackCount // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7e20
	float GetSetByCallerMagnitude(struct FGameplayEffectSpec& Spec, struct FGameplayTag DataTag, bool bWarnIfNotFound, float DefaultIfNotFound); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetSetByCallerMagnitude // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbdaa0
	float GetPeriod(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetPeriod // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb6e70
	float GetModifierMagnitude(struct FGameplayEffectSpec& Spec, int32_t ModifierIdx, bool bFactorInStackCount); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetModifierMagnitude // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbbd20
	float GetModifiedAttributeMagnitude(struct FGameplayEffectSpec& Spec, struct FGameplayAttribute& Attribute); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetModifiedAttributeMagnitude // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbe1e0
	float GetLevel(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetLevel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7180
	struct TArray<struct FGameplayAbilitySpecDef> GetGrantedAbilitySpecs(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetGrantedAbilitySpecs // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbb6a0
	struct FGameplayTagContainer GetDynamicGrantedTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetDynamicGrantedTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbb250
	struct FGameplayTagContainer GetDynamicAssetTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetDynamicAssetTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbe090
	int32_t GetDurationLocked(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetDurationLocked // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbbbc0
	float GetDuration(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetDuration // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb8f90
	struct UGameplayEffect* GetDefinitionEffectCDO(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetDefinitionEffectCDO // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7ba0
	struct FGameplayEffectContextHandle GetContext(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetContext // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7530
	int32_t GetCompletedTargetAttributeCapture(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetCompletedTargetAttributeCapture // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb6780
	int32_t GetCompletedSourceAttributeCapture(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetCompletedSourceAttributeCapture // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb9bf0
	float GetChanceToApplyToTarget(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetChanceToApplyToTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb9ec0
	struct FAngelscriptTagContainerAggregator GetCapturedTargetTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetCapturedTargetTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb8260
	struct FAngelscriptTagContainerAggregator GetCapturedSourceTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetCapturedSourceTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbb910
	struct FGameplayTagContainer GetAllGrantedTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetAllGrantedTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb7a50
	struct FGameplayTagContainer GetAllAssetTags(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.GetAllAssetTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb9120
	void CaptureAttributeDataFromTarget(struct FGameplayEffectSpec& Spec, struct UAbilitySystemComponent* TargetAbilitySystemComponent); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.CaptureAttributeDataFromTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb8be0
	void CalculateModifierMagnitudes(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.CalculateModifierMagnitudes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fb8680
	float CalculateModifiedDuration(struct FGameplayEffectSpec& Spec); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.CalculateModifiedDuration // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fb8e40
	void ApplyExecutorModifiersForDefinition(struct FGameplayEffectSpec& Spec, struct UObject* CalculationClass, struct FGameplayEffectAttributeCaptureDefinition& InCaptureDef, float& ValueToModify); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.ApplyExecutorModifiersForDefinition // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fba090
	void AppendDynamicAssetTags(struct FGameplayEffectSpec& Spec, struct FGameplayTagContainer& ContainerToAdd); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.AppendDynamicAssetTags // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fba410
	void AddDynamicAssetTag(struct FGameplayEffectSpec& Spec, struct FGameplayTag& TagToAdd); // Function AngelscriptGAS.GameplayEffectSpecMixinLibrary.AddDynamicAssetTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fbb130
};

// Class AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayModifierEvaluatedDataMixinLibrary : UObject {

	struct FString ToSimpleString(struct FGameplayModifierEvaluatedData& Data); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.ToSimpleString // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbdf10
	void SetModifierOp(struct FGameplayModifierEvaluatedData& Data, enum class EGameplayModOp NewValue); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.SetModifierOp // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbce60
	void SetMagnitude(struct FGameplayModifierEvaluatedData& Data, float NewValue); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.SetMagnitude // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbd670
	void SetIsValid(struct FGameplayModifierEvaluatedData& Data, bool NewValue); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.SetIsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbb3a0
	void SetHandle(struct FGameplayModifierEvaluatedData& Data, struct FActiveGameplayEffectHandle NewValue); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.SetHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb7030
	void SetAttribute(struct FGameplayModifierEvaluatedData& Data, struct FGameplayAttribute& NewValue); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.SetAttribute // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb9270
	enum class EGameplayModOp GetModifierOp(struct FGameplayModifierEvaluatedData& Data); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.GetModifierOp // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbca20
	float GetMagnitude(struct FGameplayModifierEvaluatedData& Data); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.GetMagnitude // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbc010
	bool GetIsValid(struct FGameplayModifierEvaluatedData& Data); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.GetIsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fbc450
	struct FActiveGameplayEffectHandle GetHandle(struct FGameplayModifierEvaluatedData& Data); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.GetHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fb95c0
	struct FGameplayAttribute GetAttribute(struct FGameplayModifierEvaluatedData& Data); // Function AngelscriptGAS.GameplayModifierEvaluatedDataMixinLibrary.GetAttribute // (Final|Native|Static|Public|HasOutParms) // @ game+0x4fba280
};

// Class AngelscriptGAS.GameplayTaskMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayTaskMixinLibrary : UObject {

	void ReadyForActivation(struct UGameplayTask* Task); // Function AngelscriptGAS.GameplayTaskMixinLibrary.ReadyForActivation // (Final|Native|Static|Private) // @ game+0x4fbf9a0
};

// Class AngelscriptGAS.InheritedTagContainerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UInheritedTagContainerMixinLibrary : UObject {

	void RemoveTag(struct FInheritedTagContainer& Container, struct FGameplayTag& TagToRemove); // Function AngelscriptGAS.InheritedTagContainerMixinLibrary.RemoveTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fc0080
	void AddTag(struct FInheritedTagContainer& Container, struct FGameplayTag& TagToAdd); // Function AngelscriptGAS.InheritedTagContainerMixinLibrary.AddTag // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fbf2f0
};

