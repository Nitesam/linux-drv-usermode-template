// Enum OnlineSubsystemAngelscript.EArrangePartyResult
enum class EArrangePartyResult : uint8_t {
	Ok = 0,
	InvalidUsers = 1,
	Unknown = 2,
	EArrangePartyResult_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EMatchmakingCancelResult
enum class EMatchmakingCancelResult : uint8_t {
	Success = 0,
	AlreadyHasAssignment = 1,
	PrerequisitesFailure = 2,
	Error = 3,
	EMatchmakingCancelResult_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EServiceFriendRequestResult
enum class EServiceFriendRequestResult : uint8_t {
	Success = 0,
	Fail = 1,
	NotFound = 2,
	AlreadyFriends = 3,
	AlreadySent = 4,
	SelfRequest = 5,
	PlayerBlocked = 6,
	TooManyOutgoingRequests = 7,
	RateLimited = 8,
	EServiceFriendRequestResult_MAX = 9
};

// Enum OnlineSubsystemAngelscript.EServiceKickPartyMemberResult
enum class EServiceKickPartyMemberResult : uint8_t {
	Success = 0,
	Fail = 1,
	NotInParty = 2,
	NotPartyLeader = 3,
	EServiceKickPartyMemberResult_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EClientModelState
enum class EClientModelState : uint8_t {
	Down = 0,
	LoggingIn = 1,
	Up = 2,
	EClientModelState_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EAuthErrorCode
enum class EAuthErrorCode : uint8_t {
	UnknownError = 0,
	NetworkError = 1,
	AuthenticationError = 2,
	UserNotSignedIn = 3,
	UserSuspended = 4,
	NoAccountLinked = 5,
	InLoginQueue = 6,
	CountryBlocked = 7,
	EmbarkAuthLinkingCodeFailedToParse = 8,
	UserAlreadyAuthenticated = 9,
	ClientInternalError = 10,
	PlatformLoginError = 11,
	PlatformUIError = 12,
	PlatformPrivilegesMissing = 13,
	PlatformCredentialsMissing = 14,
	PlatformUserIdNotFound = 15,
	PlatformLinkedAccountAuthTokenNotFound = 16,
	PlatformUserOffline = 17,
	PlatformInvalidToken = 18,
	PlatformCannotVerifyToken = 19,
	ClientRequestForbidden = 20,
	EmbarkAuthNetworkError = 21,
	EmbarkAuthInternalServerError = 22,
	EmbarkAuthTokenErrorFailedToParse = 23,
	EmbarkAuthTokenFailedToParse = 24,
	EmbarkAuthTokenExpired = 25,
	UserProfileNetworkError = 26,
	ManifestNotFound = 27,
	ManifestNetworkError = 28,
	EOSLoginFailed = 29,
	EOSCreateUserFailed = 30,
	PlatformRequiredPatchAvailable = 31,
	PlatformRequiredSystemUpdate = 32,
	PlatformAgeRestrictionFailure = 33,
	OwnershipMissing = 34,
	LicenseRestricted = 35,
	EAuthErrorCode_MAX = 36
};

// Enum OnlineSubsystemAngelscript.EMatchmakingResult
enum class EMatchmakingResult : uint8_t {
	Success = 0,
	Redirected = 1,
	Fail = 2,
	InvalidParameters = 3,
	BackendSystemError = 4,
	PermissionDenied = 5,
	Restricted = 6,
	Unavailable = 7,
	Overloaded = 8,
	PartyIsTooLarge = 9,
	GameServerExpired = 10,
	ScenarioExpired = 11,
	GameServerAllocationError = 12,
	GameServerInitializationError = 13,
	ScenarioMapConditionExpired = 14,
	PlayerActivityStateValidationFailed = 15,
	ScenarioIsNotSupportedForPlatform = 16,
	EMatchmakingResult_MAX = 17
};

// Enum OnlineSubsystemAngelscript.EMatchmakingEstimationStatus
enum class EMatchmakingEstimationStatus : uint8_t {
	NotAvailable = 0,
	Valid = 1,
	Faulty = 2,
	NoData = 3,
	EMatchmakingEstimationStatus_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EMatchmakingStatus
enum class EMatchmakingStatus : uint8_t {
	Idle = 0,
	Waiting = 1,
	Matching = 2,
	Completed = 3,
	RequestingServer = 4,
	Skipping = 5,
	Cancelling = 6,
	EMatchmakingStatus_MAX = 7
};

// Enum OnlineSubsystemAngelscript.EMatchmakingPrerequisitesStatus
enum class EMatchmakingPrerequisitesStatus : uint8_t {
	Success = 0,
	Suspended = 1,
	NoValidPlatforms = 2,
	EMatchmakingPrerequisitesStatus_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EServicePartyInviteResult
enum class EServicePartyInviteResult : uint8_t {
	Success = 0,
	Fail = 1,
	PartyFull = 2,
	GameOutOfDate = 3,
	EServicePartyInviteResult_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EServicePartyJoinResult
enum class EServicePartyJoinResult : uint8_t {
	Success = 0,
	Fail = 1,
	PartyFull = 2,
	CrossplayIncompatibility = 3,
	GameOutOfDate = 4,
	PartyLeaderGameOutOfDate = 5,
	EServicePartyJoinResult_MAX = 6
};

// Enum OnlineSubsystemAngelscript.EPartyMatchmakingCompletedResult
enum class EPartyMatchmakingCompletedResult : uint8_t {
	Success = 0,
	Cancelled = 1,
	PartyNotReady = 2,
	PartyTooLarge = 3,
	ManifestIsInvalid = 4,
	PartyMemberHasPlayedRoundsRestriction = 5,
	PartySkillDifferenceIsTooBroad = 6,
	DuoPartyRankScoreDifferenceIsTooBig = 7,
	EPartyMatchmakingCompletedResult_MAX = 8
};

// Enum OnlineSubsystemAngelscript.EServicePartyMemberRemovedReason
enum class EServicePartyMemberRemovedReason : uint8_t {
	Left = 0,
	Kicked = 1,
	Unknown = 2,
	EServicePartyMemberRemovedReason_MAX = 3
};

// Enum OnlineSubsystemAngelscript.ESyncInventoryResult
enum class ESyncInventoryResult : uint8_t {
	Success = 0,
	InvalidRealm = 1,
	InvalidFunctionCall = 2,
	InvalidParameters = 3,
	SerializationError = 4,
	BackendSystemError = 5,
	BackendRequestError = 6,
	Failed = 7,
	ESyncInventoryResult_MAX = 8
};

// Enum OnlineSubsystemAngelscript.ESyncManifestResult
enum class ESyncManifestResult : uint8_t {
	Success = 0,
	NoManifest = 1,
	BackendSystemError = 2,
	PlaytestNotActive = 3,
	ESyncManifestResult_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EServicePlayerOnlineState
enum class EServicePlayerOnlineState : uint8_t {
	Unknown = 0,
	Online = 1,
	Offline = 2,
	EServicePlayerOnlineState_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EEmbarkUpdateGameMatchStatus
enum class EEmbarkUpdateGameMatchStatus : uint8_t {
	Invalid = 0,
	InProgress = 1,
	Paused = 2,
	Aborted = 3,
	EEmbarkUpdateGameMatchStatus_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EClanErrorTypes
enum class EClanErrorTypes : uint8_t {
	Ok = 0,
	NameConflict = 1,
	NameInvalidLength = 2,
	NameInvalidCharacters = 3,
	NameInvalidSymbolPosition = 4,
	NameInvalidCommunityStandardsViolation = 5,
	TagConflict = 6,
	TagInvalidLength = 7,
	TagInvalidCharacter = 8,
	TagInvalidCommunityStandardsViolation = 9,
	ClanNotFound = 10,
	Unknown = 11,
	EClanErrorTypes_MAX = 12
};

// Enum OnlineSubsystemAngelscript.EVoiceChannel
enum class EVoiceChannel : uint8_t {
	None = 0,
	Party = 1,
	Squad = 2,
	Proximity = 3,
	EVoiceChannel_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EVoiceRoomError
enum class EVoiceRoomError : uint8_t {
	Default = 0,
	Input = 1,
	Output = 2,
	ChannelInfo = 3,
	EVoiceRoomError_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EVoiceRoomParticipantStatus
enum class EVoiceRoomParticipantStatus : uint8_t {
	None = 0,
	Idle = 1,
	Active = 2,
	EVoiceRoomParticipantStatus_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EVoiceRoomParticipantJoinStatus
enum class EVoiceRoomParticipantJoinStatus : uint8_t {
	Joined = 0,
	Left = 1,
	EVoiceRoomParticipantJoinStatus_MAX = 2
};

// Enum OnlineSubsystemAngelscript.EUpdateProfileErrorCode
enum class EUpdateProfileErrorCode : uint8_t {
	UnknownError = 0,
	EmailValidationError = 1,
	EmailConflictError = 2,
	InvalidDateOfBirthError = 3,
	InvalidCountryError = 4,
	EUpdateProfileErrorCode_MAX = 5
};

// Enum OnlineSubsystemAngelscript.EEmbarkGameMatchLeaveReason
enum class EEmbarkGameMatchLeaveReason : uint8_t {
	Invalid = 0,
	Disconnect = 1,
	Finished = 2,
	Quit = 3,
	EEmbarkGameMatchLeaveReason_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EEmbarkMatchGroupType
enum class EEmbarkMatchGroupType : uint8_t {
	Invalid = 0,
	Teams = 1,
	NonTeams = 2,
	EEmbarkMatchGroupType_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EEmbarkMatchCoopResults
enum class EEmbarkMatchCoopResults : uint8_t {
	Invalid = 0,
	Complete = 1,
	NotComplete = 2,
	Failed = 3,
	EEmbarkMatchCoopResults_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EEmbarkGameMatchType
enum class EEmbarkGameMatchType : uint8_t {
	Cooperative = 0,
	Competitive = 1,
	EEmbarkGameMatchType_MAX = 2
};

// Enum OnlineSubsystemAngelscript.EClanPrivacy
enum class EClanPrivacy : uint8_t {
	OPEN = 0,
	PRIVATE = 1,
	REQUEST_ONLY = 2,
	EClanPrivacy_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EClanSearchView
enum class EClanSearchView : uint8_t {
	NEWEST = 0,
	LARGEST = 1,
	RISING = 2,
	EClanSearchView_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EReportClanReason
enum class EReportClanReason : uint8_t {
	InappropriateNameOrTag = 0,
	OffensiveDescription = 1,
	RecruitmentScam = 2,
	CoordinatedHarassment = 3,
	MatchFixingOrBoosting = 4,
	Other = 5,
	EReportClanReason_MAX = 6
};

// Enum OnlineSubsystemAngelscript.EClanTimelineMessageType
enum class EClanTimelineMessageType : uint8_t {
	PartyUp = 0,
	MemberJoined = 1,
	MemberLeft = 2,
	MemberRoleChanged = 3,
	EClanTimelineMessageType_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EServiceRelationshipType
enum class EServiceRelationshipType : uint8_t {
	Unknown = 0,
	Mutual = 1,
	NonMutualOutgoing = 2,
	NonMutualIncoming = 3,
	Blocked = 4,
	Suggested = 5,
	EServiceRelationshipType_MAX = 6
};

// Enum OnlineSubsystemAngelscript.EServiceFriendUpdateType
enum class EServiceFriendUpdateType : uint8_t {
	Unknown = 0,
	Added = 1,
	Removed = 2,
	OnlineState = 3,
	EServiceFriendUpdateType_MAX = 4
};

// Enum OnlineSubsystemAngelscript.ESetActiveContestantPackResult
enum class ESetActiveContestantPackResult : uint8_t {
	Success = 0,
	MissingLoadout = 1,
	InventoryError = 2,
	BackendError = 3,
	ESetActiveContestantPackResult_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EInventorySyncInventoryReason
enum class EInventorySyncInventoryReason : uint8_t {
	InitialSync = 0,
	ExplicitSync = 1,
	MutationSync = 2,
	EInventorySyncInventoryReason_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EMatchmakingPlatform
enum class EMatchmakingPlatform : uint8_t {
	All = 0,
	XBox = 1,
	PlayStation = 2,
	Pc = 3,
	EMatchmakingPlatform_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EMatchmakingStoppedReason
enum class EMatchmakingStoppedReason : uint8_t {
	Unknown = 0,
	BadRequest = 1,
	Forbidden = 2,
	NotFound = 3,
	ServerError = 4,
	InvalidTenancyUser = 5,
	InvalidManifestId = 6,
	InvalidScenarioId = 7,
	TicketNotFound = 8,
	InvalidTicketOwner = 9,
	PartyNotFound = 10,
	PartyIsTooLarge = 11,
	PartyTenancyUsersNotFound = 12,
	MatchmakingUnhandledError = 13,
	MatchmakingUnsupportedPlatform = 14,
	ScenarioExpired = 15,
	ScenarioMapConditionExpired = 16,
	PlayerActivityStateValidationFailed = 17,
	ScenarioIsNotSupportedForPlatform = 18,
	MatchmakingUnavailable = 19,
	MatchmakingRestricted = 20,
	MatchmakingOverloaded = 21,
	EMatchmakingStoppedReason_MAX = 22
};

// Enum OnlineSubsystemAngelscript.EPlayerActivityState
enum class EPlayerActivityState : uint8_t {
	Unspecified = 0,
	Idle = 1,
	Matchmaking = 2,
	InMatch = 3,
	EPlayerActivityState_MAX = 4
};

// Enum OnlineSubsystemAngelscript.ESquadMemberConnectionState
enum class ESquadMemberConnectionState : uint8_t {
	UNKNOWN = 0,
	CONNECTED = 1,
	DISCONNECTED = 2,
	ABANDONED = 3,
	DEPARTED = 4,
	ESquadMemberConnectionState_MAX = 5
};

// Enum OnlineSubsystemAngelscript.EVoiceChatMode
enum class EVoiceChatMode : uint8_t {
	OpenMic = 0,
	PushToTalk = 1,
	ToggleToTalk = 2,
	EVoiceChatMode_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EVoiceConversionHeardBy
enum class EVoiceConversionHeardBy : uint8_t {
	Off = 0,
	Everyone = 1,
	Proximity = 2,
	EVoiceConversionHeardBy_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EVoiceChatGameState
enum class EVoiceChatGameState : uint8_t {
	FrontEnd = 0,
	Game = 1,
	EVoiceChatGameState_MAX = 2
};

// Enum OnlineSubsystemAngelscript.EVoiceRoomState
enum class EVoiceRoomState : uint8_t {
	None = 0,
	Joining = 1,
	FailedJoin = 2,
	Idle = 3,
	Active = 4,
	Leaving = 5,
	EVoiceRoomState_MAX = 6
};

// Enum OnlineSubsystemAngelscript.EVoiceRoomResultCategory
enum class EVoiceRoomResultCategory : uint8_t {
	Success = 0,
	Suppressed = 1,
	Failure = 2,
	Disconnected = 3,
	Kicked = 4,
	EVoiceRoomResultCategory_MAX = 5
};

// Enum OnlineSubsystemAngelscript.EVoiceChatErrorSource
enum class EVoiceChatErrorSource : uint8_t {
	Unknown = 0,
	EOS = 1,
	Backend = 2,
	Audio = 3,
	EVoiceChatErrorSource_MAX = 4
};

// Enum OnlineSubsystemAngelscript.EAudioOutputStatus
enum class EAudioOutputStatus : uint8_t {
	Idle = 0,
	Playing = 1,
	Failed = 2,
	EAudioOutputStatus_MAX = 3
};

// Enum OnlineSubsystemAngelscript.EAudioInputStatus
enum class EAudioInputStatus : uint8_t {
	Idle = 0,
	Recording = 1,
	RecordingSilent = 2,
	RecordingDisconnected = 3,
	Failed = 4,
	RecordingAccessDenied = 100,
	EAudioInputStatus_MAX = 101
};

// Enum OnlineSubsystemAngelscript.EAudioStatus
enum class EAudioStatus : uint8_t {
	Unsupported = 0,
	Enabled = 1,
	Disabled = 2,
	AdminDisabled = 3,
	NotListeningDisabled = 4,
	EAudioStatus_MAX = 5
};

// Enum OnlineSubsystemAngelscript.EReportPlayerReason
enum class EReportPlayerReason : uint8_t {
	Cheating = 0,
	Exploiting = 1,
	OffensiveProfile = 2,
	VerbalAbuse = 3,
	Scamming = 4,
	Spamming = 5,
	Other = 6,
	Griefing = 7,
	EReportPlayerReason_MAX = 8
};

// Enum OnlineSubsystemAngelscript.EEmbarkApplicationStatus
enum class EEmbarkApplicationStatus : uint8_t {
	Foreground = 0,
	BackgroundUnconstrained = 1,
	Other = 2,
	EEmbarkApplicationStatus_MAX = 3
};

// ScriptStruct OnlineSubsystemAngelscript.GameServer
// Size: 0xd0 (Inherited: 0x00)
struct FGameServer {
	struct FString Name; // 0x00(0x10)
	struct FString Host; // 0x10(0x10)
	int32_t Port; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FString SecretKey; // 0x28(0x10)
	struct FString RoutingToken; // 0x38(0x10)
	struct FInGameVoiceChannel SquadChannel; // 0x48(0x38)
	struct FInGameVoiceChannel ServerChannel; // 0x80(0x38)
	struct FString IcaoCode; // 0xb8(0x10)
	bool ProxyEnabled; // 0xc8(0x01)
	char pad_c9[0x7]; // 0xc9(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.InGameVoiceChannel
// Size: 0x38 (Inherited: 0x00)
struct FInGameVoiceChannel {
	bool bIsValid; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString RoomId; // 0x08(0x10)
	struct FString AccessToken; // 0x18(0x10)
	struct FString ClientBaseUrl; // 0x28(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingSession
// Size: 0x40 (Inherited: 0x00)
struct FMatchmakingSession {
	int32_t PlayerCount; // 0x00(0x04)
	int32_t PlayerCountMax; // 0x04(0x04)
	int32_t SquadSize; // 0x08(0x04)
	int32_t SquadCountMax; // 0x0c(0x04)
	struct TArray<struct FMatchmakingSessionSquad> Squads; // 0x10(0x10)
	struct FMatchmakingTimeEstimate MatchmakingTimeEstimate; // 0x20(0x10)
	struct FString ScenarioName; // 0x30(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingTimeEstimate
// Size: 0x10 (Inherited: 0x00)
struct FMatchmakingTimeEstimate {
	enum class EMatchmakingEstimationStatus MatchmakingEstimationStatus; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t EstimatedTimeSeconds; // 0x08(0x08)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingSessionSquad
// Size: 0x18 (Inherited: 0x00)
struct FMatchmakingSessionSquad {
	int32_t SquadId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FMatchmakingSessionPlayer> Players; // 0x08(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingSessionPlayer
// Size: 0x28 (Inherited: 0x00)
struct FMatchmakingSessionPlayer {
	struct FTenancyUserId PlayerId; // 0x00(0x10)
	struct FString PlayerName; // 0x10(0x10)
	bool bIsLocalPlayer; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingTimeEstimates
// Size: 0x50 (Inherited: 0x00)
struct FMatchmakingTimeEstimates {
	struct TMap<struct FString, struct FMatchmakingTimeEstimateEntry> Entries; // 0x00(0x50)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingTimeEstimateEntry
// Size: 0x10 (Inherited: 0x00)
struct FMatchmakingTimeEstimateEntry {
	enum class EMatchmakingEstimationStatus Status; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	int64_t Estimate; // 0x08(0x08)
};

// ScriptStruct OnlineSubsystemAngelscript.PresenceInfo
// Size: 0x68 (Inherited: 0x00)
struct FPresenceInfo {
	enum class EServicePlayerOnlineState OnlineState; // 0x00(0x01)
	enum class EServicePlayerOnlineState PlatformOnlineState; // 0x01(0x01)
	enum class EServicePlayerOnlineState DiscordOnlineState; // 0x02(0x01)
	char pad_3[0x5]; // 0x03(0x05)
	struct FString RichPresenceString; // 0x08(0x10)
	struct TMap<struct FString, struct FString> RichPresenceAttributes; // 0x18(0x50)
};

// ScriptStruct OnlineSubsystemAngelscript.VoiceChannelInfo
// Size: 0x30 (Inherited: 0x00)
struct FVoiceChannelInfo {
	struct FString RoomId; // 0x00(0x10)
	struct FString AccessToken; // 0x10(0x10)
	struct FString ClientBaseUrl; // 0x20(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.ClanRole
// Size: 0x58 (Inherited: 0x00)
struct FClanRole {
	struct TSet<struct FString> Permissions; // 0x00(0x50)
	int32_t AllowedLimit; // 0x50(0x04)
	int32_t Priority; // 0x54(0x04)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkOnlineModelConnectionParameters
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkOnlineModelConnectionParameters {
	struct TMap<struct FString, struct FString> OptionalURLParameters; // 0x00(0x50)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkMatchStatsInt
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkMatchStatsInt {
	struct FString Key; // 0x00(0x10)
	int32_t Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkJoinGameMatchPlayer
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkJoinGameMatchPlayer {
	struct FUniqueNetIdRepl PlayerId; // 0x00(0x30)
	struct FString PlayerName; // 0x30(0x10)
	struct FString TeamId; // 0x40(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkLeaveGameMatchPlayer
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkLeaveGameMatchPlayer {
	struct FUniqueNetIdRepl PlayerId; // 0x00(0x30)
	enum class EEmbarkGameMatchLeaveReason LeaveReason; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkMatchPlayerData
// Size: 0x60 (Inherited: 0x00)
struct FEmbarkMatchPlayerData {
	struct FUniqueNetIdRepl PlayerId; // 0x00(0x30)
	struct FString PlayerName; // 0x30(0x10)
	int32_t Rank; // 0x40(0x04)
	float Score; // 0x44(0x04)
	bool bJoinMatch; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TArray<struct FEmbarkMatchStatsInt> Stats; // 0x50(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkMatchPlayerTeamData
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkMatchPlayerTeamData {
	struct FString TeamId; // 0x00(0x10)
	struct FString TeamName; // 0x10(0x10)
	int32_t Rank; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	double Score; // 0x28(0x08)
	struct TArray<struct FEmbarkMatchStatsInt> Stats; // 0x30(0x10)
	struct TArray<struct FEmbarkMatchPlayerData> Members; // 0x40(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkGameMatchRoster
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkGameMatchRoster {
	struct TArray<struct FEmbarkMatchPlayerTeamData> Teams; // 0x00(0x10)
	struct TArray<struct FEmbarkMatchPlayerData> Players; // 0x10(0x10)
	enum class EEmbarkMatchCoopResults CoopResult; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkFinalGameMatchReport
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkFinalGameMatchReport {
	enum class EEmbarkMatchGroupType GroupType; // 0x00(0x01)
	enum class EEmbarkGameMatchType MatchType; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FEmbarkGameMatchRoster Roster; // 0x08(0x28)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkGameMatchesData
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkGameMatchesData {
	struct FString ActivityId; // 0x00(0x10)
	struct FString ZoneId; // 0x10(0x10)
	int32_t ExpirationTimeSeconds; // 0x20(0x04)
	int32_t CancellationTimeSeconds; // 0x24(0x04)
	struct FEmbarkGameMatchRoster Roster; // 0x28(0x28)
};

// ScriptStruct OnlineSubsystemAngelscript.PlayerPersistentKeysMap
// Size: 0x50 (Inherited: 0x00)
struct FPlayerPersistentKeysMap {
	struct TMap<struct FGameplayTag, struct FString> Keys; // 0x00(0x50)
};

// ScriptStruct OnlineSubsystemAngelscript.DiscordJoinSecret
// Size: 0x30 (Inherited: 0x00)
struct FDiscordJoinSecret {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct OnlineSubsystemAngelscript.BlockedPlayerProfile
// Size: 0x10 (Inherited: 0x00)
struct FBlockedPlayerProfile {
	struct UServicePlayerProfile* PlayerProfile; // 0x00(0x08)
	bool bIsBlockedOnPlatform; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.RecentPlayer
// Size: 0x10 (Inherited: 0x00)
struct FRecentPlayer {
	struct UServicePlayerProfile* Profile; // 0x00(0x08)
	struct FDateTime LastSeen; // 0x08(0x08)
};

// ScriptStruct OnlineSubsystemAngelscript.DiscordUserDataView
// Size: 0x60 (Inherited: 0x00)
struct FDiscordUserDataView {
	char pad_0[0x10]; // 0x00(0x10)
	struct FString DisplayName; // 0x10(0x10)
	struct FString GlobalName; // 0x20(0x10)
	struct FString DiscordUserId; // 0x30(0x10)
	bool bIsProvisional; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FString AvatarURL; // 0x48(0x10)
	bool bHasDiscordLinked; // 0x58(0x01)
	bool bIsDiscordFriend; // 0x59(0x01)
	bool bIsOnline; // 0x5a(0x01)
	char pad_5b[0x5]; // 0x5b(0x05)
};

// ScriptStruct OnlineSubsystemAngelscript.PrivateProfileInformation
// Size: 0x48 (Inherited: 0x00)
struct FPrivateProfileInformation {
	struct FString EmailAddress; // 0x00(0x10)
	bool bHasVerifiedEmailAddress; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct FDateTime DateOfBirth; // 0x18(0x08)
	struct FString Country; // 0x20(0x10)
	struct FString TosVersionSeen; // 0x30(0x10)
	struct FDateTime DisplayNameCooldownEndsAt; // 0x40(0x08)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingParameters
// Size: 0x70 (Inherited: 0x00)
struct FMatchmakingParameters {
	struct FString MatchmakingScenarioName; // 0x00(0x10)
	struct TMap<struct FString, struct FString> PartitioningGameServerSettings; // 0x10(0x50)
	int64_t PreferredSquadSize; // 0x60(0x08)
	float ArtificialDelay; // 0x68(0x04)
	bool bEnableVoice; // 0x6c(0x01)
	bool bStreamerMode; // 0x6d(0x01)
	bool bLonewolf; // 0x6e(0x01)
	char pad_6f[0x1]; // 0x6f(0x01)
};

// ScriptStruct OnlineSubsystemAngelscript.UserMatchmakingPlatform
// Size: 0x18 (Inherited: 0x00)
struct FUserMatchmakingPlatform {
	struct TArray<enum class EApiGatewaySharedMatchmakingPlatform> Platforms; // 0x00(0x10)
	enum class EApiGatewaySharedMatchmakingPlatform HostPlatform; // 0x10(0x01)
	bool bHasCrossplayEnabled; // 0x11(0x01)
	char pad_12[0x6]; // 0x12(0x06)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingCancelParamaters
// Size: 0x28 (Inherited: 0x00)
struct FMatchmakingCancelParamaters {
	struct FString Cause; // 0x00(0x10)
	bool bIsManual; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	struct FDelegate OnRequestCompleted; // 0x14(0x10)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingDataCenter
// Size: 0x18 (Inherited: 0x00)
struct FMatchmakingDataCenter {
	struct FString IcaoCode; // 0x00(0x10)
	int64_t LatencyNs; // 0x10(0x08)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingLatencyInfo
// Size: 0x10 (Inherited: 0x00)
struct FMatchmakingLatencyInfo {
	struct TArray<struct FMatchmakingDataCenter> DataCenters; // 0x00(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.MatchmakingSearchSettings
// Size: 0x02 (Inherited: 0x00)
struct FMatchmakingSearchSettings {
	enum class ECommonInputType InputDevice; // 0x00(0x01)
	bool GeneratedLoadout; // 0x01(0x01)
};

// ScriptStruct OnlineSubsystemAngelscript.PlayerActivityScenarioMetaData
// Size: 0x18 (Inherited: 0x00)
struct FPlayerActivityScenarioMetaData {
	struct FString ScenarioName; // 0x00(0x10)
	bool AllowReconnects; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.PlayerActivity
// Size: 0x80 (Inherited: 0x00)
struct FPlayerActivity {
	enum class EPlayerActivityState State; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Etag; // 0x08(0x10)
	struct FString MatchId; // 0x18(0x10)
	struct FString TournamentId; // 0x28(0x10)
	struct FString CurrentState; // 0x38(0x10)
	struct FPlayerActivityScenarioMetaData ScenarioMetadata; // 0x48(0x18)
	struct FString LobbyId; // 0x60(0x10)
	struct FString TicketId; // 0x70(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.OnlineSquadInfo
// Size: 0x60 (Inherited: 0x00)
struct FOnlineSquadInfo {
	struct FString SquadId; // 0x00(0x10)
	struct TSet<struct FUniqueNetIdRepl> MemberIds; // 0x10(0x50)
};

// ScriptStruct OnlineSubsystemAngelscript.OnlineMatchReportSquadMemberScoreEntry
// Size: 0x30 (Inherited: 0x00)
struct FOnlineMatchReportSquadMemberScoreEntry {
	int64_t CombatScore; // 0x00(0x08)
	int64_t SupportScore; // 0x08(0x08)
	int64_t ObjectiveScore; // 0x10(0x08)
	int64_t Kills; // 0x18(0x08)
	int64_t Deaths; // 0x20(0x08)
	int64_t Assists; // 0x28(0x08)
};

// ScriptStruct OnlineSubsystemAngelscript.OnlineMatchReportSquadMemberEntry
// Size: 0x88 (Inherited: 0x00)
struct FOnlineMatchReportSquadMemberEntry {
	struct FUniqueNetIdRepl PlayerId; // 0x00(0x30)
	enum class ESquadMemberConnectionState ConnectionState; // 0x30(0x01)
	bool bWasBackfilled; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
	struct FString PartyId; // 0x38(0x10)
	float ConnectionPercentage; // 0x48(0x04)
	char pad_4c[0x4]; // 0x4c(0x04)
	struct FOnlineMatchReportSquadMemberScoreEntry ScoreEntry; // 0x50(0x30)
	bool bApplyPenalty; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

// ScriptStruct OnlineSubsystemAngelscript.OnlineMatchReportSquadEntry
// Size: 0x20 (Inherited: 0x00)
struct FOnlineMatchReportSquadEntry {
	struct TArray<struct FOnlineMatchReportSquadMemberEntry> OnlineSquadEntries; // 0x00(0x10)
	struct FString SquadId; // 0x10(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.VoiceChatFailure
// Size: 0x18 (Inherited: 0x00)
struct FVoiceChatFailure {
	enum class EVoiceChannel Channel; // 0x00(0x01)
	enum class EVoiceRoomError Error; // 0x01(0x01)
	enum class EVoiceChatErrorSource Source; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	int32_t SourceResult; // 0x04(0x04)
	struct FString StatusCode; // 0x08(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.VoiceDeviceInfo
// Size: 0x20 (Inherited: 0x00)
struct FVoiceDeviceInfo {
	struct FString DisplayName; // 0x00(0x10)
	struct FString ID; // 0x10(0x10)
};

// ScriptStruct OnlineSubsystemAngelscript.EmbarkVoiceRoomParticipantState
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkVoiceRoomParticipantState {
	enum class EVoiceRoomParticipantStatus Status; // 0x00(0x01)
	bool bIsTalking; // 0x01(0x01)
	bool bIsBlocked; // 0x02(0x01)
	bool bIsMuted; // 0x03(0x01)
	bool bIsSelectivelyMuted; // 0x04(0x01)
	bool bIsBlockedByProximityCulling; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
	float AmplitudeDb; // 0x08(0x04)
};

// ScriptStruct OnlineSubsystemAngelscript.UpdateProfileArguments
// Size: 0x58 (Inherited: 0x00)
struct FUpdateProfileArguments {
	bool bUpdateEmail; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Email; // 0x08(0x10)
	bool bUpdateDateOfBirth; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
	struct FDateTime DateOfBirth; // 0x20(0x08)
	bool bUpdateCountry; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString Country; // 0x30(0x10)
	bool bUpdateTosVersionSeen; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FString TosVersionSeen; // 0x48(0x10)
};

