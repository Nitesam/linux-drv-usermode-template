// ScriptStruct EmbarkUtilities.EmbarkComponentInitializationRules
// Size: 0x04 (Inherited: 0x00)
struct FEmbarkComponentInitializationRules {
	enum class EComponentMobility SceneComponentMobility; // 0x00(0x01)
	bool bNetAddressable; // 0x01(0x01)
	bool bEditorOnlySubobject; // 0x02(0x01)
	bool bForceDisableReplication; // 0x03(0x01)
};

// ScriptStruct EmbarkUtilities.EncodeSettings
// Size: 0x20 (Inherited: 0x00)
struct FEncodeSettings {
	bool bObjectTypeWrap; // 0x00(0x01)
	bool bStandardizeCase; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	int64_t CheckFlags; // 0x08(0x08)
	int64_t SkipFlags; // 0x10(0x08)
	int32_t Indent; // 0x18(0x04)
	bool bPrettyPrint; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
};

