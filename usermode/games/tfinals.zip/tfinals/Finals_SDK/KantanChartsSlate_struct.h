// Enum KantanChartsSlate.EChartAxisPosition
enum class EChartAxisPosition : uint8_t {
	LeftBottom = 0,
	RightTop = 1,
	Floating = 2,
	EChartAxisPosition_MAX = 3
};

// Enum KantanChartsSlate.ECartesianScalingType
enum class ECartesianScalingType : uint8_t {
	FixedScale = 0,
	FixedRange = 1,
	ECartesianScalingType_MAX = 2
};

// Enum KantanChartsSlate.ECartesianRangeBoundType
enum class ECartesianRangeBoundType : uint8_t {
	FixedValue = 0,
	FitToData = 1,
	FitToDataRounded = 2,
	ECartesianRangeBoundType_MAX = 3
};

// Enum KantanChartsSlate.EKantanDataPointSize
enum class EKantanDataPointSize : uint8_t {
	Small = 0,
	Medium = 1,
	Large = 2,
	EKantanDataPointSize_MAX = 3
};

// Enum KantanChartsSlate.EKantanBarChartOrientation
enum class EKantanBarChartOrientation : uint8_t {
	Vertical = 0,
	Horizontal = 1,
	EKantanBarChartOrientation_MAX = 2
};

// Enum KantanChartsSlate.EKantanBarLabelPosition
enum class EKantanBarLabelPosition : uint8_t {
	NoLabels = 0,
	Standard = 1,
	Overlaid = 2,
	EKantanBarLabelPosition_MAX = 3
};

// Enum KantanChartsSlate.EKantanBarValueExtents
enum class EKantanBarValueExtents : uint8_t {
	NoValueLines = 0,
	ZeroLineOnly = 1,
	ZeroAndMaxLines = 2,
	EKantanBarValueExtents_MAX = 3
};

// ScriptStruct KantanChartsSlate.CartesianAxisInstanceConfig
// Size: 0x04 (Inherited: 0x00)
struct FCartesianAxisInstanceConfig {
	bool bEnabled; // 0x00(0x01)
	bool bShowTitle; // 0x01(0x01)
	bool bShowMarkers; // 0x02(0x01)
	bool bShowLabels; // 0x03(0x01)
};

// ScriptStruct KantanChartsSlate.CartesianAxisConfig
// Size: 0x48 (Inherited: 0x00)
struct FCartesianAxisConfig {
	struct FText Title; // 0x00(0x18)
	struct FText Unit; // 0x18(0x18)
	float MarkerSpacing; // 0x30(0x04)
	int32_t MaxValueDigits; // 0x34(0x04)
	struct FCartesianAxisInstanceConfig LeftBottomAxis; // 0x38(0x04)
	struct FCartesianAxisInstanceConfig RightTopAxis; // 0x3c(0x04)
	struct FCartesianAxisInstanceConfig FloatingAxis; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct KantanChartsSlate.KantanChartStyle
// Size: 0x170 (Inherited: 0x08)
struct FKantanChartStyle : FSlateWidgetStyle {
	char pad_8[0x8]; // 0x08(0x08)
	struct FSlateBrush Background; // 0x10(0xd0)
	struct FLinearColor ChartLineColor; // 0xe0(0x10)
	float ChartLineThickness; // 0xf0(0x04)
	char pad_f4[0x4]; // 0xf4(0x04)
	struct FSlateFontInfo BaseFont; // 0xf8(0x58)
	int32_t TitleFontSize; // 0x150(0x04)
	int32_t AxisDescriptionFontSize; // 0x154(0x04)
	int32_t AxisValueFontSize; // 0x158(0x04)
	struct FLinearColor FontColor; // 0x15c(0x10)
	char pad_16c[0x4]; // 0x16c(0x04)
};

// ScriptStruct KantanChartsSlate.KantanBarChartStyle
// Size: 0x180 (Inherited: 0x170)
struct FKantanBarChartStyle : FKantanChartStyle {
	float BarOpacity; // 0x170(0x04)
	float BarOutlineOpacity; // 0x174(0x04)
	float BarOutlineThickness; // 0x178(0x04)
	char pad_17c[0x4]; // 0x17c(0x04)
};

// ScriptStruct KantanChartsSlate.KantanCartesianChartStyle
// Size: 0x180 (Inherited: 0x170)
struct FKantanCartesianChartStyle : FKantanChartStyle {
	float DataOpacity; // 0x170(0x04)
	float DataLineThickness; // 0x174(0x04)
	char pad_178[0x8]; // 0x178(0x08)
};

// ScriptStruct KantanChartsSlate.CartesianAxisRange
// Size: 0x08 (Inherited: 0x00)
struct FCartesianAxisRange {
	float Min; // 0x00(0x04)
	float Max; // 0x04(0x04)
};

// ScriptStruct KantanChartsSlate.KantanCartesianPlotScale
// Size: 0x38 (Inherited: 0x00)
struct FKantanCartesianPlotScale {
	enum class ECartesianScalingType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector2D Scale; // 0x08(0x10)
	struct FVector2D FocalCoordinates; // 0x18(0x10)
	struct FCartesianAxisRange RangeX; // 0x28(0x08)
	struct FCartesianAxisRange RangeY; // 0x30(0x08)
};

// ScriptStruct KantanChartsSlate.CartesianRangeBound
// Size: 0x08 (Inherited: 0x00)
struct FCartesianRangeBound {
	enum class ECartesianRangeBoundType Type; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FixedBoundValue; // 0x04(0x04)
};

// ScriptStruct KantanChartsSlate.KantanCategoryStyle
// Size: 0x18 (Inherited: 0x00)
struct FKantanCategoryStyle {
	struct FName CategoryStyleId; // 0x00(0x08)
	struct FLinearColor Color; // 0x08(0x10)
};

// ScriptStruct KantanChartsSlate.KantanSeriesStyle
// Size: 0x20 (Inherited: 0x00)
struct FKantanSeriesStyle {
	struct FName StyleId; // 0x00(0x08)
	struct UKantanPointStyle* PointStyle; // 0x08(0x08)
	struct FLinearColor Color; // 0x10(0x10)
};

