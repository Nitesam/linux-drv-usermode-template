// Class Niagara.NDIRenderTargetVolumeSimCacheData
// Size: 0xb0 (Inherited: 0xa0)
struct UNDIRenderTargetVolumeSimCacheData : UObject {
	struct FName CompressionType; // 0x98(0x08)
	struct TArray<struct FNDIRenderTargetVolumeSimCacheFrame> Frames; // 0xa0(0x10)
};

// Class Niagara.NiagaraConvertInPlaceUtilityBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraConvertInPlaceUtilityBase : UObject {
};

// Class Niagara.NiagaraDataChannelReader
// Size: 0xc0 (Inherited: 0xa0)
struct UNiagaraDataChannelReader : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UNiagaraDataChannelHandler* Owner; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)

	struct FVector4 ReadVector4(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadVector4 // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x499f640
	struct FVector2D ReadVector2D(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadVector2D // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x49943c0
	struct FVector ReadVector(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadVector // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x499afd0
	struct FQuat ReadQuat(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadQuat // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x49976c0
	struct FVector ReadPosition(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadPosition // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4995710
	struct FLinearColor ReadLinearColor(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadLinearColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x499c600
	int32_t ReadInt(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadInt // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x49955c0
	double ReadFloat(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadFloat // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4996060
	bool ReadBool(struct FName VarName, int32_t Index); // Function Niagara.NiagaraDataChannelReader.ReadBool // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4993e80
	int32_t Num(); // Function Niagara.NiagaraDataChannelReader.Num // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4995b20
	bool InitAccess(struct FNiagaraDataChannelSearchParameters SearchParams, bool bReadPrevFrameData); // Function Niagara.NiagaraDataChannelReader.InitAccess // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x499a670
};

// Class Niagara.NiagaraDataChannelWriter
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraDataChannelWriter : UObject {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct UNiagaraDataChannelHandler* Owner; // 0xa8(0x08)

	void WriteVector4(struct FName VarName, int32_t Index, struct FVector4 InData); // Function Niagara.NiagaraDataChannelWriter.WriteVector4 // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x499f150
	void WriteVector2D(struct FName VarName, int32_t Index, struct FVector2D InData); // Function Niagara.NiagaraDataChannelWriter.WriteVector2D // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x499ee10
	void WriteVector(struct FName VarName, int32_t Index, struct FVector InData); // Function Niagara.NiagaraDataChannelWriter.WriteVector // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4998130
	void WriteSpawnInfo(struct FName VarName, int32_t Index, struct FNiagaraSpawnInfo InData); // Function Niagara.NiagaraDataChannelWriter.WriteSpawnInfo // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x49992f0
	void WriteQuat(struct FName VarName, int32_t Index, struct FQuat InData); // Function Niagara.NiagaraDataChannelWriter.WriteQuat // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x499a2e0
	void WritePosition(struct FName VarName, int32_t Index, struct FVector InData); // Function Niagara.NiagaraDataChannelWriter.WritePosition // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x499e4e0
	void WriteLinearColor(struct FName VarName, int32_t Index, struct FLinearColor InData); // Function Niagara.NiagaraDataChannelWriter.WriteLinearColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x499e760
	void WriteInt(struct FName VarName, int32_t Index, int32_t InData); // Function Niagara.NiagaraDataChannelWriter.WriteInt // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x499da70
	void WriteFloat(struct FName VarName, int32_t Index, double InData); // Function Niagara.NiagaraDataChannelWriter.WriteFloat // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x499dd50
	void WriteBool(struct FName VarName, int32_t Index, bool InData); // Function Niagara.NiagaraDataChannelWriter.WriteBool // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4997530
	int32_t Num(); // Function Niagara.NiagaraDataChannelWriter.Num // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4996270
	bool InitWrite(struct FNiagaraDataChannelSearchParameters SearchParams, int32_t Count, bool bVisibleToGame, bool bVisibleToCPU, bool bVisibleToGPU); // Function Niagara.NiagaraDataChannelWriter.InitWrite // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x499bb10
};

// Class Niagara.NiagaraDataChannelHandler
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraDataChannelHandler : UObject {
	struct TWeakObjectPtr<struct UNiagaraDataChannel> DataChannel; // 0x98(0x08)
	struct UNiagaraDataChannelWriter* Writer; // 0xa0(0x08)
	struct UNiagaraDataChannelReader* Reader; // 0xa8(0x08)

	struct UNiagaraDataChannelWriter* GetDataChannelWriter(); // Function Niagara.NiagaraDataChannelHandler.GetDataChannelWriter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x49a8820
	struct UNiagaraDataChannelReader* GetDataChannelReader(); // Function Niagara.NiagaraDataChannelHandler.GetDataChannelReader // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x49a2a70
};

// Class Niagara.NiagaraDataChannelAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraDataChannelAsset : UObject {
	struct UNiagaraDataChannel* DataChannel; // 0x98(0x08)
};

// Class Niagara.NiagaraDataChannel
// Size: 0x1a0 (Inherited: 0xa0)
struct UNiagaraDataChannel : UObject {
	struct TArray<struct FNiagaraVariable> Variables; // 0x98(0x10)
	bool bKeepPreviousFrameData; // 0xa8(0x01)
	struct FNiagaraDataSetCompiledData CompiledData; // 0xb0(0x48)
	struct FNiagaraDataSetCompiledData CompiledDataGPU; // 0xf8(0x48)
	char pad_141[0x5f]; // 0x141(0x5f)
};

// Class Niagara.NiagaraDataChannel_Global
// Size: 0x1a0 (Inherited: 0x1a0)
struct UNiagaraDataChannel_Global : UNiagaraDataChannel {
};

// Class Niagara.NiagaraDataChannelHandler_Global
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataChannelHandler_Global : UNiagaraDataChannelHandler {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class Niagara.NiagaraDataChannel_Islands
// Size: 0x220 (Inherited: 0x1a0)
struct UNiagaraDataChannel_Islands : UNiagaraDataChannel {
	enum class ENiagraDataChannel_IslandMode Mode; // 0x1a0(0x01)
	char pad_1a1[0x7]; // 0x1a1(0x07)
	struct FVector InitialExtents; // 0x1a8(0x18)
	struct FVector MaxExtents; // 0x1c0(0x18)
	struct FVector PerElementExtents; // 0x1d8(0x18)
	struct TArray<struct TSoftObjectPtr<UNiagaraSystem>> Systems; // 0x1f0(0x10)
	int32_t IslandPoolSize; // 0x200(0x04)
	struct FNDCIslandDebugDrawSettings DebugDrawSettings; // 0x204(0x04)
	struct TArray<struct UNiagaraSystem*> SystemsInternal; // 0x208(0x10)
	char pad_218[0x8]; // 0x218(0x08)
};

// Class Niagara.NiagaraDataChannelHandler_Islands
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataChannelHandler_Islands : UNiagaraDataChannelHandler {
	struct TArray<int32_t> ActiveIslands; // 0xb0(0x10)
	struct TArray<int32_t> FreeIslands; // 0xc0(0x10)
	struct TArray<struct FNDCIsland> IslandPool; // 0xd0(0x10)
};

// Class Niagara.NiagaraDataInterface
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraDataInterface : UNiagaraDataInterfaceBase {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class Niagara.NiagaraDataInterfaceRWBase
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceRWBase : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceDataChannelRead
// Size: 0x130 (Inherited: 0xb0)
struct UNiagaraDataInterfaceDataChannelRead : UNiagaraDataInterfaceRWBase {
	struct UNiagaraDataChannelAsset* Channel; // 0xa8(0x08)
	struct FNiagaraDataInterfaceEmitterBinding EmitterBinding; // 0xb0(0x0c)
	bool bReadCurrentFrame; // 0xbc(0x01)
	bool bUpdateSourceDataEveryTick; // 0xbd(0x01)
	bool bOverrideSpawnGroupToDataChannelIndex; // 0xbe(0x01)
	struct FName SpawnInfoName; // 0xc0(0x08)
	struct FNDIDataChannelCompiledData CompiledData; // 0xc8(0x68)
};

// Class Niagara.NiagaraDataInterfaceDataChannelWrite
// Size: 0x170 (Inherited: 0xb0)
struct UNiagaraDataInterfaceDataChannelWrite : UNiagaraDataInterface {
	enum class ENiagaraDataChannelAllocationMode AllocationMode; // 0xa8(0x01)
	uint32_t AllocationCount; // 0xac(0x04)
	bool bPublishToGame; // 0xb0(0x01)
	bool bPublishToCPU; // 0xb1(0x01)
	bool bPublishToGPU; // 0xb2(0x01)
	bool bUpdateDestinationDataEveryTick; // 0xb3(0x01)
	struct UNiagaraDataChannelAsset* Channel; // 0xb8(0x08)
	struct FNDIDataChannelWriteCompiledData CompiledData; // 0xc0(0xb0)
};

// Class Niagara.NiagaraMessageDataBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraMessageDataBase : UObject {
};

// Class Niagara.NiagaraParameterDefinitionsBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraParameterDefinitionsBase : UObject {
};

// Class Niagara.NiagaraRenderableMeshInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraRenderableMeshInterface : UInterface {
};

// Class Niagara.NiagaraScriptSourceBase
// Size: 0xc0 (Inherited: 0xa0)
struct UNiagaraScriptSourceBase : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class Niagara.NiagaraSettings
// Size: 0x1b0 (Inherited: 0xb0)
struct UNiagaraSettings : UDeveloperSettings {
	bool bSystemsSupportLargeWorldCoordinates; // 0xa8(0x01)
	bool bEnforceStrictStackTypes; // 0xa9(0x01)
	bool bExperimentalVMEnabled; // 0xaa(0x01)
	bool bLimitDeltaTime; // 0xab(0x01)
	float MaxDeltaTimePerTick; // 0xac(0x04)
	struct FSoftObjectPath DefaultEffectType; // 0xb0(0x20)
	struct FSoftObjectPath RequiredEffectType; // 0xd0(0x20)
	struct FLinearColor PositionPinTypeColor; // 0xf0(0x10)
	struct TArray<struct FText> QualityLevels; // 0x100(0x10)
	struct TMap<struct FString, struct FText> ComponentRendererWarningsPerClass; // 0x110(0x50)
	enum class ETextureRenderTargetFormat DefaultRenderTargetFormat; // 0x160(0x01)
	enum class ENiagaraGpuBufferFormat DefaultGridFormat; // 0x161(0x01)
	enum class ENiagaraDefaultRendererMotionVectorSetting DefaultRendererMotionVectorSetting; // 0x164(0x04)
	enum class ENiagaraDefaultRendererPixelCoverageMode DefaultPixelCoverageMode; // 0x168(0x01)
	enum class ENiagaraDefaultSortPrecision DefaultSortPrecision; // 0x169(0x01)
	enum class ENiagaraDefaultGpuTranslucentLatency DefaultGpuTranslucentLatency; // 0x16a(0x01)
	float DefaultLightInverseExposureBlend; // 0x16c(0x04)
	enum class ENDISkelMesh_GpuMaxInfluences NDISkelMesh_GpuMaxInfluences; // 0x170(0x01)
	enum class ENDISkelMesh_GpuUniformSamplingFormat NDISkelMesh_GpuUniformSamplingFormat; // 0x171(0x01)
	enum class ENDISkelMesh_AdjacencyTriangleIndexFormat NDISkelMesh_AdjacencyTriangleIndexFormat; // 0x172(0x01)
	bool NDIStaticMesh_AllowDistanceFields; // 0x173(0x01)
	struct TArray<enum class ENDICollisionQuery_AsyncGpuTraceProvider> NDICollisionQuery_AsyncGpuTraceProviderOrder; // 0x178(0x10)
	struct FString SimCacheAuxiliaryFileBasePath; // 0x188(0x10)
	int64_t SimCacheMaxCPUMemoryVolumetrics; // 0x198(0x08)
	struct TArray<struct FNiagaraPlatformSetRedirect> PlatformSetRedirects; // 0x1a0(0x10)
};

// Class Niagara.NiagaraSimCacheCustomStorageInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraSimCacheCustomStorageInterface : UInterface {
};

// Class Niagara.NiagaraValidationRuleSet
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraValidationRuleSet : UObject {
	struct TArray<struct UNiagaraValidationRule*> ValidationRules; // 0x98(0x10)
};

// Class Niagara.NiagaraDataInterfaceActorComponent
// Size: 0xf0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceActorComponent : UNiagaraDataInterface {
	enum class ENDIActorComponentSourceMode SourceMode; // 0xa8(0x01)
	int32_t LocalPlayerIndex; // 0xac(0x04)
	LazyObjectProperty SourceActor; // 0xb0(0x18)
	struct FNiagaraUserParameterBinding ActorOrComponentParameter; // 0xc8(0x20)
	bool bRequireCurrentFrameData; // 0xe8(0x01)
	char pad_ee[0x2]; // 0xee(0x02)
};

// Class Niagara.NiagaraDataInterfaceAsyncGpuTrace
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceAsyncGpuTrace : UNiagaraDataInterface {
	int32_t MaxTracesPerParticle; // 0xa8(0x04)
	int32_t MaxRetraces; // 0xac(0x04)
	enum class ENDICollisionQuery_AsyncGpuTraceProvider TraceProvider; // 0xb0(0x01)
	char pad_b9[0x7]; // 0xb9(0x07)
};

// Class Niagara.NiagaraDataInterfaceDebugDraw
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceDebugDraw : UNiagaraDataInterface {
	uint32_t OverrideMaxLineInstances; // 0xa8(0x04)
};

// Class Niagara.NiagaraDataInterfaceDynamicMesh
// Size: 0x120 (Inherited: 0xb0)
struct UNiagaraDataInterfaceDynamicMesh : UNiagaraDataInterface {
	struct TArray<struct FNiagaraDynamicMeshSection> Sections; // 0xb0(0x10)
	struct TArray<struct FNiagaraDynamicMeshMaterial> Materials; // 0xc0(0x10)
	int32_t NumVertices; // 0xd0(0x04)
	int32_t NumTexCoords; // 0xd4(0x04)
	bool bHasColors; // 0xd8(0x01)
	bool bHasTangentBasis; // 0xd9(0x01)
	bool bClearTrianglesPerFrame; // 0xda(0x01)
	char pad_db[0x5]; // 0xdb(0x05)
	struct FBox DefaultBounds; // 0xe0(0x38)
	char pad_118[0x8]; // 0x118(0x08)
};

// Class Niagara.NiagaraDataInterfaceEmitterProperties
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceEmitterProperties : UNiagaraDataInterface {
	struct FNiagaraDataInterfaceEmitterBinding EmitterBinding; // 0xa8(0x0c)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// Class Niagara.NiagaraDataInterfaceGBuffer
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceGBuffer : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfacePhysicsAsset
// Size: 0x120 (Inherited: 0xb0)
struct UNiagaraDataInterfacePhysicsAsset : UNiagaraDataInterface {
	struct UPhysicsAsset* DefaultSource; // 0xa8(0x08)
	struct TSoftObjectPtr<AActor> SoftSourceActor; // 0xb0(0x28)
	struct FNiagaraUserParameterBinding MeshUserParameter; // 0xd8(0x20)
	char pad_100[0x20]; // 0x100(0x20)
};

// Class Niagara.NiagaraPhysicsAssetDICollectorInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraPhysicsAssetDICollectorInterface : UInterface {
};

// Class Niagara.NiagaraDataInterfaceSceneCapture2D
// Size: 0x1a0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSceneCapture2D : UNiagaraDataInterface {
	enum class ENDISceneCapture2DSourceMode SourceMode; // 0xa8(0x01)
	struct FNiagaraUserParameterBinding SceneCaptureUserParameter; // 0xb0(0x20)
	bool bAutoMoveWithComponent; // 0xd0(0x01)
	enum class ENDISceneCapture2DOffsetMode AutoMoveOffsetLocationMode; // 0xd1(0x01)
	char pad_d3[0x5]; // 0xd3(0x05)
	struct FVector AutoMoveOffsetLocation; // 0xd8(0x18)
	enum class ENDISceneCapture2DOffsetMode AutoMoveOffsetRotationMode; // 0xf0(0x01)
	char pad_f1[0x7]; // 0xf1(0x07)
	struct FRotator AutoMoveOffsetRotation; // 0xf8(0x18)
	enum class ESceneCaptureSource ManagedCaptureSource; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	struct FIntPoint ManagedTextureSize; // 0x114(0x08)
	enum class ETextureRenderTargetFormat ManagedTextureFormat; // 0x11c(0x01)
	enum class ECameraProjectionMode ManagedProjectionType; // 0x11d(0x01)
	char pad_11e[0x2]; // 0x11e(0x02)
	float ManagedFOVAngle; // 0x120(0x04)
	float ManagedOrthoWidth; // 0x124(0x04)
	bool bManagedCaptureEveryFrame; // 0x128(0x01)
	bool bManagedCaptureOnMovement; // 0x129(0x01)
	char pad_12a[0x6]; // 0x12a(0x06)
	struct TArray<struct AActor*> ManagedShowOnlyActors; // 0x130(0x10)
	char pad_140[0x8]; // 0x140(0x08)
	struct TMap<uint64_t, struct USceneCaptureComponent2D*> ManagedCaptureComponents; // 0x148(0x50)
	char pad_198[0x8]; // 0x198(0x08)

	void SetSceneCapture2DManagedShowOnlyActors(struct UNiagaraComponent* NiagaraSystem, struct FName ParameterName, struct TArray<struct AActor*> ShowOnlyActors); // Function Niagara.NiagaraDataInterfaceSceneCapture2D.SetSceneCapture2DManagedShowOnlyActors // (Final|RequiredAPI|Native|Static|Protected|BlueprintCallable) // @ game+0x49f3190
};

// Class Niagara.NiagaraDataInterfaceSimCacheReader
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSimCacheReader : UNiagaraDataInterface {
	struct FNiagaraUserParameterBinding SimCacheBinding; // 0xa8(0x20)
	struct UNiagaraSimCache* SimCache; // 0xc8(0x08)
	struct FName EmitterBinding; // 0xd0(0x08)
};

// Class Niagara.NiagaraDataInterfaceSimpleCounter
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSimpleCounter : UNiagaraDataInterfaceRWBase {
	enum class ENiagaraGpuSyncMode GpuSyncMode; // 0xa8(0x04)
	int32_t InitialValue; // 0xac(0x04)
};

// Class Niagara.NiagaraDataInterfaceStaticMesh
// Size: 0x140 (Inherited: 0xb0)
struct UNiagaraDataInterfaceStaticMesh : UNiagaraDataInterface {
	enum class ENDIStaticMesh_SourceMode SourceMode; // 0xa8(0x01)
	struct UStaticMesh* DefaultMesh; // 0xb0(0x08)
	struct TSoftObjectPtr<AActor> SoftSourceActor; // 0xb8(0x28)
	struct UStaticMeshComponent* SourceComponent; // 0xe0(0x08)
	struct FNDIStaticMeshSectionFilter SectionFilter; // 0xe8(0x10)
	bool bCaptureTransformsPerFrame; // 0xf8(0x01)
	bool bUsePhysicsBodyVelocity; // 0xf9(0x01)
	bool bAllowSamplingFromStreamingLODs; // 0xfa(0x01)
	int32_t LODIndex; // 0xfc(0x04)
	struct FNiagaraUserParameterBinding LODIndexUserParameter; // 0x100(0x20)
	int32_t InstanceIndex; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct TArray<struct FName> FilteredSockets; // 0x128(0x10)
	char pad_138[0x8]; // 0x138(0x08)

	void SetNiagaraStaticMeshDIInstanceIndex(struct UNiagaraComponent* NiagaraSystem, struct FName UserParameterName, int32_t NewInstanceIndex); // Function Niagara.NiagaraDataInterfaceStaticMesh.SetNiagaraStaticMeshDIInstanceIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4acfa50
	void OnSourceEndPlay(struct AActor* InSource, enum class EEndPlayReason Reason); // Function Niagara.NiagaraDataInterfaceStaticMesh.OnSourceEndPlay // (Final|RequiredAPI|Native|Protected) // @ game+0x4acf930
};

// Class Niagara.NiagaraDataInterfaceUObjectPropertyReader
// Size: 0x120 (Inherited: 0xb0)
struct UNiagaraDataInterfaceUObjectPropertyReader : UNiagaraDataInterface {
	enum class ENDIObjectPropertyReaderSourceMode SourceMode; // 0xa8(0x01)
	struct FNiagaraUserParameterBinding UObjectParameterBinding; // 0xb0(0x20)
	struct TArray<struct FNiagaraUObjectPropertyReaderRemap> PropertyRemap; // 0xd0(0x10)
	struct TSoftObjectPtr<AActor> SourceActor; // 0xe0(0x28)
	ClassPtrProperty SourceActorComponentClass; // 0x108(0x08)
	char pad_111[0xf]; // 0x111(0x0f)

	void SetUObjectReaderPropertyRemap(struct UNiagaraComponent* NiagaraComponent, struct FName UserParameterName, struct FName GraphName, struct FName RemapName); // Function Niagara.NiagaraDataInterfaceUObjectPropertyReader.SetUObjectReaderPropertyRemap // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4a628f0
};

// Class Niagara.NiagaraDataInterfaceVirtualTexture
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceVirtualTexture : UNiagaraDataInterface {
	struct URuntimeVirtualTexture* Texture; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding TextureUserParameter; // 0xb0(0x20)
};

// Class Niagara.MovieSceneNiagaraSystemSpawnSection
// Size: 0x170 (Inherited: 0x160)
struct UMovieSceneNiagaraSystemSpawnSection : UMovieSceneSection {
	enum class ENiagaraSystemSpawnSectionStartBehavior SectionStartBehavior; // 0x160(0x04)
	enum class ENiagaraSystemSpawnSectionEvaluateBehavior SectionEvaluateBehavior; // 0x164(0x04)
	enum class ENiagaraSystemSpawnSectionEndBehavior SectionEndBehavior; // 0x168(0x04)
	enum class ENiagaraAgeUpdateMode AgeUpdateMode; // 0x16c(0x01)
	bool bAllowScalability; // 0x16d(0x01)
	char pad_16e[0x2]; // 0x16e(0x02)
};

// Class Niagara.MovieSceneNiagaraTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneNiagaraTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
};

// Class Niagara.MovieSceneNiagaraSystemTrack
// Size: 0x120 (Inherited: 0x120)
struct UMovieSceneNiagaraSystemTrack : UMovieSceneNiagaraTrack {
};

// Class Niagara.MovieSceneNiagaraParameterTrack
// Size: 0x140 (Inherited: 0x120)
struct UMovieSceneNiagaraParameterTrack : UMovieSceneNiagaraTrack {
	struct FNiagaraVariable Parameter; // 0x118(0x20)
};

// Class Niagara.MovieSceneNiagaraBoolParameterTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneNiagaraBoolParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraColorParameterTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneNiagaraColorParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraFloatParameterTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneNiagaraFloatParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraIntegerParameterTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneNiagaraIntegerParameterTrack : UMovieSceneNiagaraParameterTrack {
};

// Class Niagara.MovieSceneNiagaraVectorParameterTrack
// Size: 0x150 (Inherited: 0x140)
struct UMovieSceneNiagaraVectorParameterTrack : UMovieSceneNiagaraParameterTrack {
	int32_t ChannelsUsed; // 0x140(0x04)
	char pad_144[0xc]; // 0x144(0x0c)
};

// Class Niagara.NiagaraActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ANiagaraActor : AActor {
	struct UNiagaraComponent* NiagaraComponent; // 0x398(0x08)
	char bDestroyOnSystemFinish : 1; // 0x3a0(0x01)
	char pad_3a8_1 : 7; // 0x3a8(0x01)
	char pad_3a9[0x7]; // 0x3a9(0x07)

	void SetDestroyOnSystemFinish(bool bShouldDestroyOnSystemFinish); // Function Niagara.NiagaraActor.SetDestroyOnSystemFinish // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b16650
	void OnNiagaraSystemFinished(struct UNiagaraComponent* FinishedComponent); // Function Niagara.NiagaraActor.OnNiagaraSystemFinished // (Final|RequiredAPI|Native|Private) // @ game+0x4b37d40
	bool GetDestroyOnSystemFinish(); // Function Niagara.NiagaraActor.GetDestroyOnSystemFinish // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b2d720
};

// Class Niagara.NiagaraBakerOutput
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraBakerOutput : UObject {
	struct FString OutputName; // 0x98(0x10)
};

// Class Niagara.NiagaraBakerOutputSimCache
// Size: 0x110 (Inherited: 0xb0)
struct UNiagaraBakerOutputSimCache : UNiagaraBakerOutput {
	struct FString SimCacheAssetPathFormat; // 0xa8(0x10)
	struct FNiagaraSimCacheCreateParameters CreateParameters; // 0xb8(0x58)
};

// Class Niagara.NiagaraBakerOutputTexture2D
// Size: 0x110 (Inherited: 0xb0)
struct UNiagaraBakerOutputTexture2D : UNiagaraBakerOutput {
	struct FNiagaraBakerTextureSource SourceBinding; // 0xa8(0x18)
	char bGenerateAtlas : 1; // 0xc0(0x01)
	char bGenerateFrames : 1; // 0xc0(0x01)
	char bExportFrames : 1; // 0xc0(0x01)
	char bSetTextureAddressX : 1; // 0xc0(0x01)
	char bSetTextureAddressY : 1; // 0xc0(0x01)
	struct FIntPoint FrameSize; // 0xc4(0x08)
	struct FIntPoint AtlasTextureSize; // 0xcc(0x08)
	char pad_d8_5 : 3; // 0xd8(0x01)
	char pad_d9[0x3]; // 0xd9(0x03)
	enum class TextureAddress TextureAddressX; // 0xdc(0x01)
	enum class TextureAddress TextureAddressY; // 0xdd(0x01)
	char pad_de[0x2]; // 0xde(0x02)
	struct FString AtlasAssetPathFormat; // 0xe0(0x10)
	struct FString FramesAssetPathFormat; // 0xf0(0x10)
	struct FString FramesExportPathFormat; // 0x100(0x10)
};

// Class Niagara.NiagaraBakerOutputVolumeTexture
// Size: 0x100 (Inherited: 0xb0)
struct UNiagaraBakerOutputVolumeTexture : UNiagaraBakerOutput {
	struct FNiagaraBakerTextureSource SourceBinding; // 0xa8(0x18)
	char bGenerateAtlas : 1; // 0xc0(0x01)
	char bGenerateFrames : 1; // 0xc0(0x01)
	char bExportFrames : 1; // 0xc0(0x01)
	struct FString AtlasAssetPathFormat; // 0xc8(0x10)
	struct FString FramesAssetPathFormat; // 0xd8(0x10)
	struct FString FramesExportPathFormat; // 0xe8(0x10)
	char pad_f8_3 : 5; // 0xf8(0x01)
	char pad_f9[0x7]; // 0xf9(0x07)
};

// Class Niagara.NiagaraBakerSettings
// Size: 0x260 (Inherited: 0xa0)
struct UNiagaraBakerSettings : UObject {
	float StartSeconds; // 0x98(0x04)
	float DurationSeconds; // 0x9c(0x04)
	int32_t FramesPerSecond; // 0xa0(0x04)
	char bPreviewLooping : 1; // 0xa4(0x01)
	struct FIntPoint FramesPerDimension; // 0xa8(0x08)
	struct TArray<struct UNiagaraBakerOutput*> Outputs; // 0xb0(0x10)
	struct TArray<struct FNiagaraBakerCameraSettings> CameraSettings; // 0xc0(0x10)
	int32_t CurrentCameraIndex; // 0xd0(0x04)
	struct FName BakeQualityLevel; // 0xd4(0x08)
	char bRenderComponentOnly : 1; // 0xdc(0x01)
	struct TArray<struct FNiagaraBakerTextureSettings> OutputTextures; // 0xe0(0x10)
	enum class ENiagaraBakerViewMode CameraViewportMode; // 0xf0(0x04)
	char pad_f4_2 : 6; // 0xf4(0x01)
	char pad_f5[0x3]; // 0xf5(0x03)
	struct FVector CameraViewportLocation[0x7]; // 0xf8(0xa8)
	struct FRotator CameraViewportRotation[0x7]; // 0x1a0(0xa8)
	float CameraOrbitDistance; // 0x248(0x04)
	float CameraFOV; // 0x24c(0x04)
	float CameraOrthoWidth; // 0x250(0x04)
	char bUseCameraAspectRatio : 1; // 0x254(0x01)
	char pad_254_1 : 7; // 0x254(0x01)
	char pad_255[0x3]; // 0x255(0x03)
	float CameraAspectRatio; // 0x258(0x04)
	char pad_25c[0x4]; // 0x25c(0x04)
};

// Class Niagara.NiagaraComponent
// Size: 0x960 (Inherited: 0x6c0)
struct UNiagaraComponent : UFXSystemComponent {
	struct UNiagaraSystem* Asset; // 0x6b8(0x08)
	enum class ENiagaraTickBehavior TickBehavior; // 0x6c0(0x01)
	int32_t RandomSeedOffset; // 0x6c4(0x04)
	struct FNiagaraUserRedirectionParameterStore OverrideParameters; // 0x6c8(0xd8)
	char bForceSolo : 1; // 0x7a0(0x01)
	char bEnableGpuComputeDebug : 1; // 0x7a0(0x01)
	char bOverrideWarmupSettings : 1; // 0x7a0(0x01)
	int32_t WarmupTickCount; // 0x7a4(0x04)
	float WarmupTickDelta; // 0x7a8(0x04)
	char pad_7ad_3 : 5; // 0x7ad(0x01)
	char pad_7ae[0x32]; // 0x7ae(0x32)
	char bAutoDestroy : 1; // 0x7e0(0x01)
	char bRenderingEnabled : 1; // 0x7e0(0x01)
	char bAutoManageAttachment : 1; // 0x7e0(0x01)
	char bAutoAttachWeldSimulatedBodies : 1; // 0x7e0(0x01)
	char pad_7e0_4 : 4; // 0x7e0(0x01)
	char pad_7e1[0x3]; // 0x7e1(0x03)
	float MaxTimeBeforeForceUpdateTransform; // 0x7e4(0x04)
	char pad_7e8[0x1]; // 0x7e8(0x01)
	enum class ENiagaraOcclusionQueryMode OcclusionQueryMode; // 0x7e9(0x01)
	char pad_7ea[0x6]; // 0x7ea(0x06)
	struct FMulticastInlineDelegate OnSystemFinished; // 0x7f0(0x10)
	struct TWeakObjectPtr<struct USceneComponent> AutoAttachParent; // 0x800(0x08)
	struct FName AutoAttachSocketName; // 0x808(0x08)
	enum class EAttachmentRule AutoAttachLocationRule; // 0x810(0x01)
	enum class EAttachmentRule AutoAttachRotationRule; // 0x811(0x01)
	enum class EAttachmentRule AutoAttachScaleRule; // 0x812(0x01)
	char pad_813[0x9]; // 0x813(0x09)
	char pad_81c_0 : 4; // 0x81c(0x01)
	char bAllowScalability : 1; // 0x81c(0x01)
	char pad_81c_5 : 3; // 0x81c(0x01)
	char pad_81d[0x12b]; // 0x81d(0x12b)
	struct UNiagaraSimCache* SimCache; // 0x948(0x08)
	struct UNiagaraCullProxyComponent* CullProxy; // 0x950(0x08)
	char pad_958[0x8]; // 0x958(0x08)

	void SetVariableVec4(struct FName InVariableName, struct FVector4& InValue); // Function Niagara.NiagaraComponent.SetVariableVec4 // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b20200
	void SetVariableVec3(struct FName InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetVariableVec3 // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b36ea0
	void SetVariableVec2(struct FName InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetVariableVec2 // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b359e0
	void SetVariableTextureRenderTarget(struct FName InVariableName, struct UTextureRenderTarget* TextureRenderTarget); // Function Niagara.NiagaraComponent.SetVariableTextureRenderTarget // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b3c280
	void SetVariableTexture(struct FName InVariableName, struct UTexture* Texture); // Function Niagara.NiagaraComponent.SetVariableTexture // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4afb050
	void SetVariableStaticMesh(struct FName InVariableName, struct UStaticMesh* InValue); // Function Niagara.NiagaraComponent.SetVariableStaticMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b2ed80
	void SetVariableQuat(struct FName InVariableName, struct FQuat& InValue); // Function Niagara.NiagaraComponent.SetVariableQuat // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4af05d0
	void SetVariablePosition(struct FName InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetVariablePosition // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b39b10
	void SetVariableObject(struct FName InVariableName, struct UObject* Object); // Function Niagara.NiagaraComponent.SetVariableObject // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4aef830
	void SetVariableMatrix(struct FName InVariableName, struct FMatrix& InValue); // Function Niagara.NiagaraComponent.SetVariableMatrix // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b34740
	void SetVariableMaterial(struct FName InVariableName, struct UMaterialInterface* Object); // Function Niagara.NiagaraComponent.SetVariableMaterial // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b33360
	void SetVariableLinearColor(struct FName InVariableName, struct FLinearColor& InValue); // Function Niagara.NiagaraComponent.SetVariableLinearColor // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4ae5ee0
	void SetVariableInt(struct FName InVariableName, int32_t InValue); // Function Niagara.NiagaraComponent.SetVariableInt // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b366d0
	void SetVariableFloat(struct FName InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetVariableFloat // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4afc3b0
	void SetVariableBool(struct FName InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetVariableBool // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b17350
	void SetVariableActor(struct FName InVariableName, struct AActor* Actor); // Function Niagara.NiagaraComponent.SetVariableActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4aef830
	void SetTickBehavior(enum class ENiagaraTickBehavior NewTickBehavior); // Function Niagara.NiagaraComponent.SetTickBehavior // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b1fd40
	void SetSystemFixedBounds(struct FBox LocalBounds); // Function Niagara.NiagaraComponent.SetSystemFixedBounds // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b136c0
	void SetSimCache(struct UNiagaraSimCache* SimCache, bool bResetSystem); // Function Niagara.NiagaraComponent.SetSimCache // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4af66a0
	void SetSeekDelta(float InSeekDelta); // Function Niagara.NiagaraComponent.SetSeekDelta // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b35be0
	void SetRenderingEnabled(bool bInRenderingEnabled); // Function Niagara.NiagaraComponent.SetRenderingEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4afb430
	void SetRandomSeedOffset(int32_t NewRandomSeedOffset); // Function Niagara.NiagaraComponent.SetRandomSeedOffset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4ae47e0
	void SetPreviewLODDistance(bool bEnablePreviewLODDistance, float PreviewLODDistance, float PreviewMaxDistance); // Function Niagara.NiagaraComponent.SetPreviewLODDistance // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b131d0
	void SetPaused(bool bInPaused); // Function Niagara.NiagaraComponent.SetPaused // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b22e70
	void SetOcclusionQueryMode(enum class ENiagaraOcclusionQueryMode Mode); // Function Niagara.NiagaraComponent.SetOcclusionQueryMode // (Final|Native|Public|BlueprintCallable) // @ game+0x4b2b370
	void SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec4 // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b2abe0
	void SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec3 // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b2d540
	void SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec2 // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b1d540
	void SetNiagaraVariableQuat(struct FString InVariableName, struct FQuat& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableQuat // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b1f1d0
	void SetNiagaraVariablePosition(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariablePosition // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4ae2260
	void SetNiagaraVariableObject(struct FString InVariableName, struct UObject* Object); // Function Niagara.NiagaraComponent.SetNiagaraVariableObject // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b167d0
	void SetNiagaraVariableMatrix(struct FString InVariableName, struct FMatrix& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableMatrix // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b24a50
	void SetNiagaraVariableLinearColor(struct FString InVariableName, struct FLinearColor& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableLinearColor // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b30ce0
	void SetNiagaraVariableInt(struct FString InVariableName, int32_t InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableInt // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b17450
	void SetNiagaraVariableFloat(struct FString InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableFloat // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b17fe0
	void SetNiagaraVariableBool(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableBool // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4ae8c90
	void SetNiagaraVariableActor(struct FString InVariableName, struct AActor* Actor); // Function Niagara.NiagaraComponent.SetNiagaraVariableActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b167d0
	void SetMaxSimTime(float InMaxTime); // Function Niagara.NiagaraComponent.SetMaxSimTime // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4aefef0
	void SetLockDesiredAgeDeltaTimeToSeekDelta(bool bLock); // Function Niagara.NiagaraComponent.SetLockDesiredAgeDeltaTimeToSeekDelta // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b23360
	void SetGpuComputeDebug(bool bEnableDebug); // Function Niagara.NiagaraComponent.SetGpuComputeDebug // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b32ad0
	void SetForceSolo(bool bInForceSolo); // Function Niagara.NiagaraComponent.SetForceSolo // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b34f60
	void SetForceLocalPlayerEffect(bool bIsPlayerEffect); // Function Niagara.NiagaraComponent.SetForceLocalPlayerEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b0c0a0
	void SetEmitterFixedBounds(struct FName EmitterName, struct FBox LocalBounds); // Function Niagara.NiagaraComponent.SetEmitterFixedBounds // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4b27d30
	void SetDesiredAge(float InDesiredAge); // Function Niagara.NiagaraComponent.SetDesiredAge // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b3add0
	void SetCustomTimeDilation(float Dilation); // Function Niagara.NiagaraComponent.SetCustomTimeDilation // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b2ada0
	void SetCanRenderWhileSeeking(bool bInCanRenderWhileSeeking); // Function Niagara.NiagaraComponent.SetCanRenderWhileSeeking // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b0b030
	void SetAutoDestroy(bool bInAutoDestroy); // Function Niagara.NiagaraComponent.SetAutoDestroy // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b31c90
	void SetAsset(struct UNiagaraSystem* InAsset, bool bResetExistingOverrideParameters); // Function Niagara.NiagaraComponent.SetAsset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b27af0
	void SetAllowScalability(bool bAllow); // Function Niagara.NiagaraComponent.SetAllowScalability // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b0b970
	void SetAgeUpdateMode(enum class ENiagaraAgeUpdateMode InAgeUpdateMode); // Function Niagara.NiagaraComponent.SetAgeUpdateMode // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4afb620
	void SeekToDesiredAge(float InDesiredAge); // Function Niagara.NiagaraComponent.SeekToDesiredAge // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4ae5e30
	void ResetSystem(); // Function Niagara.NiagaraComponent.ResetSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4af67d0
	void ReinitializeSystem(); // Function Niagara.NiagaraComponent.ReinitializeSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4ae4360
	bool IsPaused(); // Function Niagara.NiagaraComponent.IsPaused // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b35430
	void InitForPerformanceBaseline(); // Function Niagara.NiagaraComponent.InitForPerformanceBaseline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b0be50
	enum class ENiagaraTickBehavior GetTickBehavior(); // Function Niagara.NiagaraComponent.GetTickBehavior // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b19000
	struct FBox GetSystemFixedBounds(); // Function Niagara.NiagaraComponent.GetSystemFixedBounds // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b18bf0
	struct UNiagaraSimCache* GetSimCache(); // Function Niagara.NiagaraComponent.GetSimCache // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4af0c30
	float GetSeekDelta(); // Function Niagara.NiagaraComponent.GetSeekDelta // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x30ca670
	int32_t GetRandomSeedOffset(); // Function Niagara.NiagaraComponent.GetRandomSeedOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b07da0
	bool GetPreviewLODDistanceEnabled(); // Function Niagara.NiagaraComponent.GetPreviewLODDistanceEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ae8690
	float GetPreviewLODDistance(); // Function Niagara.NiagaraComponent.GetPreviewLODDistance // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b2bd70
	enum class ENiagaraOcclusionQueryMode GetOcclusionQueryMode(); // Function Niagara.NiagaraComponent.GetOcclusionQueryMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b2b660
	struct TArray<struct FVector> GetNiagaraParticleValueVec3_DebugOnly(struct FString InEmitterName, struct FString InValueName); // Function Niagara.NiagaraComponent.GetNiagaraParticleValueVec3_DebugOnly // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b3a4f0
	struct TArray<float> GetNiagaraParticleValues_DebugOnly(struct FString InEmitterName, struct FString InValueName); // Function Niagara.NiagaraComponent.GetNiagaraParticleValues_DebugOnly // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b18600
	struct TArray<struct FVector> GetNiagaraParticlePositions_DebugOnly(struct FString InEmitterName); // Function Niagara.NiagaraComponent.GetNiagaraParticlePositions_DebugOnly // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b2fad0
	float GetMaxSimTime(); // Function Niagara.NiagaraComponent.GetMaxSimTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4aec640
	bool GetLockDesiredAgeDeltaTimeToSeekDelta(); // Function Niagara.NiagaraComponent.GetLockDesiredAgeDeltaTimeToSeekDelta // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4aed680
	bool GetForceSolo(); // Function Niagara.NiagaraComponent.GetForceSolo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4aeb990
	bool GetForceLocalPlayerEffect(); // Function Niagara.NiagaraComponent.GetForceLocalPlayerEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ae9a40
	struct FBox GetEmitterFixedBounds(struct FName EmitterName); // Function Niagara.NiagaraComponent.GetEmitterFixedBounds // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4af8310
	float GetDesiredAge(); // Function Niagara.NiagaraComponent.GetDesiredAge // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ae9a20
	struct UNiagaraDataInterface* GetDataInterface(struct FString Name); // Function Niagara.NiagaraComponent.GetDataInterface // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b1a370
	float GetCustomTimeDilation(); // Function Niagara.NiagaraComponent.GetCustomTimeDilation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b25080
	struct UNiagaraSystem* GetAsset(); // Function Niagara.NiagaraComponent.GetAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b0f5b0
	bool GetAllowScalability(); // Function Niagara.NiagaraComponent.GetAllowScalability // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b27570
	enum class ENiagaraAgeUpdateMode GetAgeUpdateMode(); // Function Niagara.NiagaraComponent.GetAgeUpdateMode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4b31e70
	void ClearSystemFixedBounds(); // Function Niagara.NiagaraComponent.ClearSystemFixedBounds // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b197a0
	void ClearSimCache(bool bResetSystem); // Function Niagara.NiagaraComponent.ClearSimCache // (Final|Native|Public|BlueprintCallable) // @ game+0x4b0ec00
	void ClearEmitterFixedBounds(struct FName EmitterName); // Function Niagara.NiagaraComponent.ClearEmitterFixedBounds // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b21ae0
	void AdvanceSimulationByTime(float SimulateTime, float TickDeltaSeconds); // Function Niagara.NiagaraComponent.AdvanceSimulationByTime // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b2aaa0
	void AdvanceSimulation(int32_t TickCount, float TickDeltaSeconds); // Function Niagara.NiagaraComponent.AdvanceSimulation // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4afa340
};

// Class Niagara.NiagaraComponentPool
// Size: 0xf0 (Inherited: 0xa0)
struct UNiagaraComponentPool : UObject {
	struct TMap<struct UNiagaraSystem*, struct FNCPool> WorldParticleSystemPools; // 0x98(0x50)
};

// Class Niagara.NiagaraRendererProperties
// Size: 0x130 (Inherited: 0xa0)
struct UNiagaraRendererProperties : UNiagaraMergeable {
	struct FNiagaraPlatformSet Platforms; // 0x98(0x30)
	int32_t SortOrderHint; // 0xc8(0x04)
	enum class ENiagaraRendererMotionVectorSetting MotionVectorSetting; // 0xcc(0x04)
	struct FNiagaraVariableAttributeBinding RendererEnabledBinding; // 0xd0(0x38)
	bool bIsEnabled; // 0x108(0x01)
	bool bAllowInCullProxies; // 0x109(0x01)
	struct FGuid OuterEmitterVersion; // 0x10c(0x10)
	char pad_122[0xe]; // 0x122(0x0e)
};

// Class Niagara.NiagaraComponentRendererProperties
// Size: 0x240 (Inherited: 0x130)
struct UNiagaraComponentRendererProperties : UNiagaraRendererProperties {
	struct USceneComponent* ComponentType; // 0x130(0x08)
	uint32_t ComponentCountLimit; // 0x138(0x04)
	char pad_13c[0x4]; // 0x13c(0x04)
	struct FNiagaraVariableAttributeBinding EnabledBinding; // 0x140(0x38)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x178(0x38)
	bool bAssignComponentsOnParticleID; // 0x1b0(0x01)
	bool bCreateComponentFirstParticleFrame; // 0x1b1(0x01)
	bool bOnlyActivateNewlyAquiredComponents; // 0x1b2(0x01)
	char pad_1b3[0x1]; // 0x1b3(0x01)
	int32_t RendererVisibility; // 0x1b4(0x04)
	struct USceneComponent* TemplateComponent; // 0x1b8(0x08)
	struct TArray<struct FNiagaraComponentPropertyBinding> PropertyBindings; // 0x1c0(0x10)
	char pad_1d0[0x70]; // 0x1d0(0x70)
};

// Class Niagara.NiagaraCullProxyComponent
// Size: 0x970 (Inherited: 0x960)
struct UNiagaraCullProxyComponent : UNiagaraComponent {
	struct TArray<struct FNiagaraCulledComponentInfo> Instances; // 0x958(0x10)
};

// Class Niagara.NiagaraDataChannelLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraDataChannelLibrary : UBlueprintFunctionLibrary {

	struct UNiagaraDataChannelWriter* WriteToNiagaraDataChannel(struct UObject* WorldContextObject, struct UNiagaraDataChannelAsset* Channel, struct FNiagaraDataChannelSearchParameters SearchParams, int32_t Count, bool bVisibleToGame, bool bVisibleToCPU, bool bVisibleToGPU); // Function Niagara.NiagaraDataChannelLibrary.WriteToNiagaraDataChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4b217e0
	struct UNiagaraDataChannelReader* ReadFromNiagaraDataChannel(struct UObject* WorldContextObject, struct UNiagaraDataChannelAsset* Channel, struct FNiagaraDataChannelSearchParameters SearchParams, bool bReadPreviousFrame); // Function Niagara.NiagaraDataChannelLibrary.ReadFromNiagaraDataChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4ae1940
	struct UNiagaraDataChannelHandler* GetNiagaraDataChannel(struct UObject* WorldContextObject, struct UNiagaraDataChannelAsset* Channel); // Function Niagara.NiagaraDataChannelLibrary.GetNiagaraDataChannel // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4b36d90
};

// Class Niagara.NiagaraDataInterface2DArrayTexture
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterface2DArrayTexture : UNiagaraDataInterface {
	struct UTexture* Texture; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding TextureUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDataInterfaceArray
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceArray : UNiagaraDataInterfaceRWBase {
	enum class ENiagaraGpuSyncMode GpuSyncMode; // 0xb0(0x04)
	int32_t MaxElements; // 0xb4(0x04)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class Niagara.NiagaraDataInterfaceArrayFloat
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayFloat : UNiagaraDataInterfaceArray {
	struct TArray<float> FloatData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayFloat2
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayFloat2 : UNiagaraDataInterfaceArray {
	struct TArray<struct FVector2f> InternalFloatData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayFloat3
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayFloat3 : UNiagaraDataInterfaceArray {
	struct TArray<struct FVector3f> InternalFloatData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayPosition
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayPosition : UNiagaraDataInterfaceArray {
	struct TArray<struct FNiagaraPosition> PositionData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayFloat4
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayFloat4 : UNiagaraDataInterfaceArray {
	struct TArray<struct FVector4f> InternalFloatData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayColor
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayColor : UNiagaraDataInterfaceArray {
	struct TArray<struct FLinearColor> ColorData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayQuat
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayQuat : UNiagaraDataInterfaceArray {
	struct TArray<struct FQuat4f> InternalQuatData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayMatrix
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayMatrix : UNiagaraDataInterfaceArray {
	struct TArray<struct FMatrix44f> InternalMatrixData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraDataInterfaceArrayFunctionLibrary : UBlueprintFunctionLibrary {

	void SetNiagaraArrayVectorValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FVector& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayVectorValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4bc86a0
	void SetNiagaraArrayVector4Value(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FVector4& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayVector4Value // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4bd1270
	void SetNiagaraArrayVector4(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FVector4>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayVector4 // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4ba68b0
	void SetNiagaraArrayVector2DValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FVector2D& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayVector2DValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b75680
	void SetNiagaraArrayVector2D(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FVector2D>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayVector2D // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4b631f0
	void SetNiagaraArrayVector(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FVector>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayVector // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4be3180
	void SetNiagaraArrayUInt8Value(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, int32_t Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayUInt8Value // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b68be0
	void SetNiagaraArrayUInt8(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<int32_t>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayUInt8 // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4ba4600
	void SetNiagaraArrayQuatValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FQuat& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayQuatValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b71bf0
	void SetNiagaraArrayQuat(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FQuat>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayQuat // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4be5ef0
	void SetNiagaraArrayPositionValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FVector& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayPositionValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4bb2b30
	void SetNiagaraArrayPosition(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FVector>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayPosition // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4b485f0
	void SetNiagaraArrayMatrixValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FMatrix& Value, bool bSizeToFit, bool bApplyLWCRebase); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayMatrixValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b8eb10
	void SetNiagaraArrayMatrix(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FMatrix>& ArrayData, bool bApplyLWCRebase); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayMatrix // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4b61940
	void SetNiagaraArrayInt32Value(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, int32_t Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayInt32Value // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b7f4d0
	void SetNiagaraArrayInt32(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<int32_t>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayInt32 // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4b54bd0
	void SetNiagaraArrayFloatValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, float Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayFloatValue // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b907c0
	void SetNiagaraArrayFloat(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<float>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayFloat // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4be4230
	void SetNiagaraArrayColorValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, struct FLinearColor& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayColorValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4b545e0
	void SetNiagaraArrayColor(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct FLinearColor>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayColor // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4bc8ad0
	void SetNiagaraArrayBoolValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, bool& Value, bool bSizeToFit); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayBoolValue // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4b74450
	void SetNiagaraArrayBool(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<bool>& ArrayData); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.SetNiagaraArrayBool // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4bd7560
	struct FVector GetNiagaraArrayVectorValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayVectorValue // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4b63740
	struct FVector4 GetNiagaraArrayVector4Value(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayVector4Value // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4b8a400
	struct TArray<struct FVector4> GetNiagaraArrayVector4(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayVector4 // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bc1fd0
	struct FVector2D GetNiagaraArrayVector2DValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayVector2DValue // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4b7df70
	struct TArray<struct FVector2D> GetNiagaraArrayVector2D(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayVector2D // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bcb490
	struct TArray<struct FVector> GetNiagaraArrayVector(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayVector // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b425e0
	int32_t GetNiagaraArrayUInt8Value(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayUInt8Value // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bb5790
	struct TArray<int32_t> GetNiagaraArrayUInt8(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayUInt8 // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bcc140
	struct FQuat GetNiagaraArrayQuatValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayQuatValue // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4bd5500
	struct TArray<struct FQuat> GetNiagaraArrayQuat(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayQuat // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b82570
	struct FVector GetNiagaraArrayPositionValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayPositionValue // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4b7e1f0
	struct TArray<struct FVector> GetNiagaraArrayPosition(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayPosition // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bb1880
	struct FMatrix GetNiagaraArrayMatrixValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index, bool bApplyLWCRebase); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayMatrixValue // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4bdfa70
	struct TArray<struct FMatrix> GetNiagaraArrayMatrix(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, bool bApplyLWCRebase); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayMatrix // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bc2390
	int32_t GetNiagaraArrayInt32Value(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayInt32Value // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b6cf00
	struct TArray<int32_t> GetNiagaraArrayInt32(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayInt32 // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bd20e0
	float GetNiagaraArrayFloatValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayFloatValue // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4b4c160
	struct TArray<float> GetNiagaraArrayFloat(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayFloat // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4be15b0
	struct FLinearColor GetNiagaraArrayColorValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayColorValue // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4be5bc0
	struct TArray<struct FLinearColor> GetNiagaraArrayColor(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayColor // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bd94b0
	bool GetNiagaraArrayBoolValue(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, int32_t Index); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayBoolValue // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4ba4ec0
	struct TArray<bool> GetNiagaraArrayBool(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName); // Function Niagara.NiagaraDataInterfaceArrayFunctionLibrary.GetNiagaraArrayBool // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4bdfff0
};

// Class Niagara.NiagaraDataInterfaceArrayInt32
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayInt32 : UNiagaraDataInterfaceArray {
	struct TArray<int32_t> IntData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayUInt8
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayUInt8 : UNiagaraDataInterfaceArray {
	struct TArray<char> InternalIntData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayBool
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayBool : UNiagaraDataInterfaceArray {
	struct TArray<bool> BoolData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceArrayNiagaraID
// Size: 0xd0 (Inherited: 0xc0)
struct UNiagaraDataInterfaceArrayNiagaraID : UNiagaraDataInterfaceArray {
	struct TArray<struct FNiagaraID> IntData; // 0xb8(0x10)
};

// Class Niagara.NiagaraDataInterfaceAudioSubmix
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceAudioSubmix : UNiagaraDataInterface {
	struct USoundSubmix* Submix; // 0xa8(0x08)
};

// Class Niagara.NiagaraDataInterfaceAudioOscilloscope
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceAudioOscilloscope : UNiagaraDataInterface {
	struct USoundSubmix* Submix; // 0xa8(0x08)
	int32_t Resolution; // 0xb0(0x04)
	float ScopeInMilliseconds; // 0xb4(0x04)
};

// Class Niagara.NiagaraDataInterfaceAudioPlayerSettings
// Size: 0x480 (Inherited: 0xa0)
struct UNiagaraDataInterfaceAudioPlayerSettings : UObject {
	bool bOverrideConcurrency; // 0x98(0x01)
	struct USoundConcurrency* Concurrency; // 0xa0(0x08)
	bool bOverrideAttenuationSettings; // 0xa8(0x01)
	char pad_aa[0x6]; // 0xaa(0x06)
	struct FSoundAttenuationSettings AttenuationSettings; // 0xb0(0x3d0)
};

// Class Niagara.NiagaraDataInterfaceAudioPlayer
// Size: 0x100 (Inherited: 0xb0)
struct UNiagaraDataInterfaceAudioPlayer : UNiagaraDataInterface {
	struct USoundBase* SoundToPlay; // 0xa8(0x08)
	struct USoundAttenuation* Attenuation; // 0xb0(0x08)
	struct USoundConcurrency* Concurrency; // 0xb8(0x08)
	struct TArray<struct FName> ParameterNames; // 0xc0(0x10)
	struct FNiagaraUserParameterBinding ConfigurationUserParameter; // 0xd0(0x20)
	bool bLimitPlaysPerTick; // 0xf0(0x01)
	int32_t MaxPlaysPerTick; // 0xf4(0x04)
	bool bStopWhenComponentIsDestroyed; // 0xf8(0x01)
	bool bAllowLoopingOneShotSounds; // 0xf9(0x01)
	char pad_ff[0x1]; // 0xff(0x01)
};

// Class Niagara.NiagaraDataInterfaceAudioSpectrum
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceAudioSpectrum : UNiagaraDataInterfaceAudioSubmix {
	int32_t Resolution; // 0xb0(0x04)
	float MinimumFrequency; // 0xb4(0x04)
	float MaximumFrequency; // 0xb8(0x04)
	float NoiseFloorDb; // 0xbc(0x04)
};

// Class Niagara.NiagaraDataInterfaceCamera
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceCamera : UNiagaraDataInterface {
	int32_t PlayerControllerIndex; // 0xa8(0x04)
	bool bRequireCurrentFrameData; // 0xac(0x01)
};

// Class Niagara.NiagaraDataInterfaceCollisionQuery
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceCollisionQuery : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceCurveBase
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceCurveBase : UNiagaraDataInterface {
	struct TArray<float> ShaderLUT; // 0xa8(0x10)
	float LUTMinTime; // 0xb8(0x04)
	float LUTMaxTime; // 0xbc(0x04)
	float LUTInvTimeRange; // 0xc0(0x04)
	float LUTNumSamplesMinusOne; // 0xc4(0x04)
	char bUseLUT : 1; // 0xcc(0x01)
	char bExposeCurve : 1; // 0xcc(0x01)
	struct FName ExposedName; // 0xd0(0x08)
	struct UTexture2D* ExposedTexture; // 0xd8(0x08)
};

// Class Niagara.NiagaraDataInterfaceColorCurve
// Size: 0x2e0 (Inherited: 0xe0)
struct UNiagaraDataInterfaceColorCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve RedCurve; // 0xe0(0x80)
	struct FRichCurve GreenCurve; // 0x160(0x80)
	struct FRichCurve BlueCurve; // 0x1e0(0x80)
	struct FRichCurve AlphaCurve; // 0x260(0x80)
};

// Class Niagara.NiagaraDataInterfaceCubeTexture
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceCubeTexture : UNiagaraDataInterface {
	struct UTexture* Texture; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding TextureUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDataInterfaceCurlNoise
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceCurlNoise : UNiagaraDataInterface {
	uint32_t Seed; // 0xa8(0x04)
	char pad_b4[0xc]; // 0xb4(0x0c)
};

// Class Niagara.NiagaraDataInterfaceCurve
// Size: 0x160 (Inherited: 0xe0)
struct UNiagaraDataInterfaceCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve Curve; // 0xe0(0x80)
};

// Class Niagara.NiagaraParticleCallbackHandler
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraParticleCallbackHandler : UInterface {

	void ReceiveParticleData(struct TArray<struct FBasicParticleData>& Data, struct UNiagaraSystem* NiagaraSystem, struct FVector& SimulationPositionOffset); // Function Niagara.NiagaraParticleCallbackHandler.ReceiveParticleData // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x4b6d3a0
};

// Class Niagara.NiagaraDataInterfaceExport
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceExport : UNiagaraDataInterface {
	struct FNiagaraUserParameterBinding CallbackHandlerParameter; // 0xa8(0x20)
	enum class ENDIExport_GPUAllocationMode GPUAllocationMode; // 0xc8(0x01)
	int32_t GPUAllocationFixedSize; // 0xcc(0x04)
	float GPUAllocationPerParticleSize; // 0xd0(0x04)
	char pad_d9[0x7]; // 0xd9(0x07)
};

// Class Niagara.NiagaraDataInterfaceGrid2D
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceGrid2D : UNiagaraDataInterfaceRWBase {
	bool ClearBeforeNonIterationStage; // 0xa8(0x01)
	int32_t NumCellsX; // 0xac(0x04)
	int32_t NumCellsY; // 0xb0(0x04)
	int32_t NumCellsMaxAxis; // 0xb4(0x04)
	int32_t NumAttributes; // 0xb8(0x04)
	bool SetGridFromMaxAxis; // 0xbc(0x01)
	struct FVector2D WorldBBoxSize; // 0xc0(0x10)
};

// Class Niagara.NiagaraDataInterfaceGrid2DCollection
// Size: 0x1a0 (Inherited: 0xd0)
struct UNiagaraDataInterfaceGrid2DCollection : UNiagaraDataInterfaceGrid2D {
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xd0(0x20)
	enum class ENiagaraGpuBufferFormat OverrideBufferFormat; // 0xf0(0x01)
	char bOverrideFormat : 1; // 0xf1(0x01)
	char pad_f1_1 : 7; // 0xf1(0x01)
	char pad_f2[0x56]; // 0xf2(0x56)
	struct TMap<uint64_t, struct UTextureRenderTarget2DArray*> ManagedRenderTargets; // 0x148(0x50)
	char pad_198[0x8]; // 0x198(0x08)

	void GetTextureSize(struct UNiagaraComponent* Component, int32_t& SizeX, int32_t& SizeY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetTextureSize // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4b8b630
	void GetRawTextureSize(struct UNiagaraComponent* Component, int32_t& SizeX, int32_t& SizeY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetRawTextureSize // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4bcbfa0
	bool FillTexture2D(struct UNiagaraComponent* Component, struct UTextureRenderTarget2D* Dest, int32_t AttributeIndex); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillTexture2D // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b69a50
	bool FillRawTexture2D(struct UNiagaraComponent* Component, struct UTextureRenderTarget2D* Dest, int32_t& TilesX, int32_t& TilesY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillRawTexture2D // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4bb4a70
};

// Class Niagara.NiagaraDataInterfaceGrid2DCollectionReader
// Size: 0x1c0 (Inherited: 0x1a0)
struct UNiagaraDataInterfaceGrid2DCollectionReader : UNiagaraDataInterfaceGrid2DCollection {
	struct FString EmitterName; // 0x198(0x10)
	struct FString DIName; // 0x1a8(0x10)
};

// Class Niagara.NiagaraDataInterfaceGrid3D
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceGrid3D : UNiagaraDataInterfaceRWBase {
	bool ClearBeforeNonIterationStage; // 0xa8(0x01)
	struct FIntVector NumCells; // 0xac(0x0c)
	float CellSize; // 0xb8(0x04)
	int32_t NumCellsMaxAxis; // 0xbc(0x04)
	enum class ESetResolutionMethod SetResolutionMethod; // 0xc0(0x04)
	struct FVector WorldBBoxSize; // 0xc8(0x18)
};

// Class Niagara.NiagaraDataInterfaceGrid3DCollection
// Size: 0x160 (Inherited: 0xe0)
struct UNiagaraDataInterfaceGrid3DCollection : UNiagaraDataInterfaceGrid3D {
	int32_t NumAttributes; // 0xe0(0x04)
	char pad_e4[0x4]; // 0xe4(0x04)
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xe8(0x20)
	enum class ENiagaraGpuBufferFormat OverrideBufferFormat; // 0x108(0x01)
	char bOverrideFormat : 1; // 0x109(0x01)
	char pad_109_1 : 7; // 0x109(0x01)
	char pad_10a[0x56]; // 0x10a(0x56)

	void GetTextureSize(struct UNiagaraComponent* Component, int32_t& SizeX, int32_t& SizeY, int32_t& SizeZ); // Function Niagara.NiagaraDataInterfaceGrid3DCollection.GetTextureSize // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4c407a0
	void GetRawTextureSize(struct UNiagaraComponent* Component, int32_t& SizeX, int32_t& SizeY, int32_t& SizeZ); // Function Niagara.NiagaraDataInterfaceGrid3DCollection.GetRawTextureSize // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4c1ba00
	bool FillVolumeTexture(struct UNiagaraComponent* Component, struct UVolumeTexture* Dest, int32_t AttributeIndex); // Function Niagara.NiagaraDataInterfaceGrid3DCollection.FillVolumeTexture // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4b69a50
	bool FillRawVolumeTexture(struct UNiagaraComponent* Component, struct UVolumeTexture* Dest, int32_t& TilesX, int32_t& TilesY, int32_t& TileZ); // Function Niagara.NiagaraDataInterfaceGrid3DCollection.FillRawVolumeTexture // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4c3d050
};

// Class Niagara.NiagaraDataInterfaceGrid3DCollectionReader
// Size: 0x180 (Inherited: 0x160)
struct UNiagaraDataInterfaceGrid3DCollectionReader : UNiagaraDataInterfaceGrid3DCollection {
	struct FString EmitterName; // 0x160(0x10)
	struct FString DIName; // 0x170(0x10)
};

// Class Niagara.NiagaraDataInterfaceIntRenderTarget2D
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceIntRenderTarget2D : UNiagaraDataInterfaceRWBase {
	struct FIntPoint Size; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDataInterfaceLandscape
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceLandscape : UNiagaraDataInterface {
	struct AActor* SourceLandscape; // 0xa8(0x08)
	enum class ENDILandscape_SourceMode SourceMode; // 0xb0(0x01)
	struct TArray<struct UPhysicalMaterial*> PhysicalMaterials; // 0xb8(0x10)
	char pad_c9[0x7]; // 0xc9(0x07)
};

// Class Niagara.NiagaraDataInterfaceMeshRendererInfo
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceMeshRendererInfo : UNiagaraDataInterface {
	struct UNiagaraMeshRendererProperties* MeshRenderer; // 0xa8(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class Niagara.NiagaraDataInterfaceNeighborGrid3D
// Size: 0xf0 (Inherited: 0xe0)
struct UNiagaraDataInterfaceNeighborGrid3D : UNiagaraDataInterfaceGrid3D {
	uint32_t MaxNeighborsPerCell; // 0xe0(0x04)
	char pad_e4[0xc]; // 0xe4(0x0c)
};

// Class Niagara.NiagaraDataInterfaceOcclusion
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceOcclusion : UNiagaraDataInterface {
};

// Class Niagara.NiagaraDataInterfaceParticleRead
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceParticleRead : UNiagaraDataInterfaceRWBase {
	struct FString EmitterName; // 0xa8(0x10)
};

// Class Niagara.NiagaraDataInterfacePlatformSet
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfacePlatformSet : UNiagaraDataInterface {
	struct FNiagaraPlatformSet Platforms; // 0xa8(0x30)
};

// Class Niagara.NiagaraDataInterfaceRasterizationGrid3D
// Size: 0xf0 (Inherited: 0xe0)
struct UNiagaraDataInterfaceRasterizationGrid3D : UNiagaraDataInterfaceGrid3D {
	int32_t NumAttributes; // 0xe0(0x04)
	float Precision; // 0xe4(0x04)
	int32_t ResetValue; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// Class Niagara.NiagaraDataInterfaceRenderTarget2D
// Size: 0x130 (Inherited: 0xb0)
struct UNiagaraDataInterfaceRenderTarget2D : UNiagaraDataInterfaceRWBase {
	struct FIntPoint Size; // 0xa8(0x08)
	enum class ENiagaraMipMapGeneration MipMapGeneration; // 0xb0(0x01)
	enum class ENiagaraMipMapGenerationType MipMapGenerationType; // 0xb1(0x01)
	enum class ETextureRenderTargetFormat OverrideRenderTargetFormat; // 0xb2(0x01)
	enum class TextureFilter OverrideRenderTargetFilter; // 0xb3(0x01)
	char bInheritUserParameterSettings : 1; // 0xb4(0x01)
	char bOverrideFormat : 1; // 0xb4(0x01)
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xb8(0x20)
	char pad_dc_2 : 6; // 0xdc(0x01)
	char pad_dd[0x53]; // 0xdd(0x53)
};

// Class Niagara.NiagaraDataInterfaceRenderTarget2DArray
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceRenderTarget2DArray : UNiagaraDataInterfaceRWBase {
	struct FIntVector Size; // 0xa8(0x0c)
	enum class ETextureRenderTargetFormat OverrideRenderTargetFormat; // 0xb4(0x01)
	enum class TextureFilter OverrideRenderTargetFilter; // 0xb5(0x01)
	char bInheritUserParameterSettings : 1; // 0xb6(0x01)
	char bOverrideFormat : 1; // 0xb6(0x01)
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xb8(0x20)
	char pad_de_2 : 6; // 0xde(0x01)
	char pad_df[0x1]; // 0xdf(0x01)
};

// Class Niagara.NiagaraDataInterfaceRenderTargetCube
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceRenderTargetCube : UNiagaraDataInterfaceRWBase {
	int32_t Size; // 0xa8(0x04)
	enum class ETextureRenderTargetFormat OverrideRenderTargetFormat; // 0xac(0x01)
	enum class TextureFilter OverrideRenderTargetFilter; // 0xad(0x01)
	char bInheritUserParameterSettings : 1; // 0xae(0x01)
	char bOverrideFormat : 1; // 0xae(0x01)
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDataInterfaceRenderTargetVolume
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceRenderTargetVolume : UNiagaraDataInterfaceRWBase {
	struct FIntVector Size; // 0xb0(0x0c)
	enum class ETextureRenderTargetFormat OverrideRenderTargetFormat; // 0xbc(0x01)
	enum class TextureFilter OverrideRenderTargetFilter; // 0xbd(0x01)
	char bInheritUserParameterSettings : 1; // 0xbe(0x01)
	char bOverrideFormat : 1; // 0xbe(0x01)
	char pad_be_2 : 6; // 0xbe(0x01)
	char pad_bf[0x1]; // 0xbf(0x01)
	struct FNiagaraUserParameterBinding RenderTargetUserParameter; // 0xc0(0x20)
};

// Class Niagara.NiagaraDataInterfaceRigidMeshCollisionQuery
// Size: 0xf0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceRigidMeshCollisionQuery : UNiagaraDataInterface {
	struct TArray<struct FName> ActorTags; // 0xa8(0x10)
	struct TArray<struct FName> ComponentTags; // 0xb8(0x10)
	struct TArray<struct TSoftObjectPtr<AActor>> SourceActors; // 0xc8(0x10)
	bool OnlyUseMoveable; // 0xd8(0x01)
	bool UseComplexCollisions; // 0xd9(0x01)
	bool GlobalSearchAllowed; // 0xda(0x01)
	bool GlobalSearchForced; // 0xdb(0x01)
	bool GlobalSearchFallback_Unscripted; // 0xdc(0x01)
	int32_t MaxNumPrimitives; // 0xe0(0x04)
	char pad_e9[0x7]; // 0xe9(0x07)
};

// Class Niagara.NiagaraDIRigidMeshCollisionFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraDIRigidMeshCollisionFunctionLibrary : UBlueprintFunctionLibrary {

	void SetSourceActors(struct UNiagaraComponent* NiagaraSystem, struct FName OverrideName, struct TArray<struct AActor*>& SourceActors); // Function Niagara.NiagaraDIRigidMeshCollisionFunctionLibrary.SetSourceActors // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4c56890
};

// Class Niagara.NiagaraDataInterfaceSkeletalMesh
// Size: 0x170 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSkeletalMesh : UNiagaraDataInterface {
	enum class ENDISkeletalMesh_SourceMode SourceMode; // 0xa8(0x01)
	struct TSoftObjectPtr<AActor> SoftSourceActor; // 0xb0(0x28)
	struct TArray<struct FName> ComponentTags; // 0xd8(0x10)
	struct USkeletalMeshComponent* SourceComponent; // 0xe8(0x08)
	struct FNiagaraUserParameterBinding MeshUserParameter; // 0xf0(0x20)
	enum class ENDISkeletalMesh_SkinningMode SkinningMode; // 0x110(0x01)
	char pad_112[0x6]; // 0x112(0x06)
	struct TArray<struct FName> SamplingRegions; // 0x118(0x10)
	int32_t WholeMeshLOD; // 0x128(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)
	struct TArray<struct FName> FilteredBones; // 0x130(0x10)
	struct TArray<struct FName> FilteredSockets; // 0x140(0x10)
	struct FName ExcludeBoneName; // 0x150(0x08)
	char bExcludeBone : 1; // 0x158(0x01)
	char pad_158_1 : 7; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	int32_t UvSetIndex; // 0x15c(0x04)
	bool bRequireCurrentFrameData; // 0x160(0x01)
	char pad_161[0xf]; // 0x161(0x0f)

	void OnSourceEndPlay(struct AActor* InSource, enum class EEndPlayReason Reason); // Function Niagara.NiagaraDataInterfaceSkeletalMesh.OnSourceEndPlay // (Final|RequiredAPI|Native|Protected) // @ game+0x4c9f250
};

// Class Niagara.NiagaraDataInterfaceSparseVolumeTexture
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSparseVolumeTexture : UNiagaraDataInterface {
	struct USparseVolumeTexture* SparseVolumeTexture; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding SparseVolumeTextureUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDataInterfaceSpline
// Size: 0x130 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSpline : UNiagaraDataInterface {
	struct AActor* Source; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding SplineUserParameter; // 0xb0(0x20)
	bool bUseLUT; // 0xd0(0x01)
	int32_t NumLUTSteps; // 0xd4(0x04)
	char pad_dd[0x53]; // 0xdd(0x53)
};

// Class Niagara.NiagaraDataInterfaceSpriteRendererInfo
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceSpriteRendererInfo : UNiagaraDataInterface {
	struct UNiagaraSpriteRendererProperties* SpriteRenderer; // 0xa8(0x08)
};

// Class Niagara.NiagaraDataInterfaceTexture
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceTexture : UNiagaraDataInterface {
	struct UTexture* Texture; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding TextureUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDataInterfaceVector2DCurve
// Size: 0x1e0 (Inherited: 0xe0)
struct UNiagaraDataInterfaceVector2DCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0xe0(0x80)
	struct FRichCurve YCurve; // 0x160(0x80)
};

// Class Niagara.NiagaraDataInterfaceVector4Curve
// Size: 0x2e0 (Inherited: 0xe0)
struct UNiagaraDataInterfaceVector4Curve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0xe0(0x80)
	struct FRichCurve YCurve; // 0x160(0x80)
	struct FRichCurve ZCurve; // 0x1e0(0x80)
	struct FRichCurve WCurve; // 0x260(0x80)
};

// Class Niagara.NiagaraDataInterfaceVectorCurve
// Size: 0x260 (Inherited: 0xe0)
struct UNiagaraDataInterfaceVectorCurve : UNiagaraDataInterfaceCurveBase {
	struct FRichCurve XCurve; // 0xe0(0x80)
	struct FRichCurve YCurve; // 0x160(0x80)
	struct FRichCurve ZCurve; // 0x1e0(0x80)
};

// Class Niagara.NiagaraDataInterfaceVectorField
// Size: 0xc0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceVectorField : UNiagaraDataInterface {
	struct UVectorField* Field; // 0xa8(0x08)
	bool bTileX; // 0xb0(0x01)
	bool bTileY; // 0xb1(0x01)
	bool bTileZ; // 0xb2(0x01)
	char pad_bb[0x5]; // 0xbb(0x05)
};

// Class Niagara.NiagaraDataInterfaceVolumeCache
// Size: 0x100 (Inherited: 0xb0)
struct UNiagaraDataInterfaceVolumeCache : UNiagaraDataInterface {
	struct UVolumeCache* VolumeCache; // 0xa8(0x08)
	char pad_b8[0x48]; // 0xb8(0x48)
};

// Class Niagara.NiagaraDataInterfaceVolumeTexture
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraDataInterfaceVolumeTexture : UNiagaraDataInterface {
	struct UTexture* Texture; // 0xa8(0x08)
	struct FNiagaraUserParameterBinding TextureUserParameter; // 0xb0(0x20)
};

// Class Niagara.NiagaraDebugHUDSettings
// Size: 0x300 (Inherited: 0xa0)
struct UNiagaraDebugHUDSettings : UObject {
	char pad_a0[0x18]; // 0xa0(0x18)
	struct FNiagaraDebugHUDSettingsData Data; // 0xb8(0x248)
};

// Class Niagara.NiagaraDecalRendererProperties
// Size: 0x3a0 (Inherited: 0x130)
struct UNiagaraDecalRendererProperties : UNiagaraRendererProperties {
	struct UMaterialInterface* Material; // 0x130(0x08)
	struct FNiagaraParameterBinding MaterialParameterBinding; // 0x138(0x0c)
	enum class ENiagaraRendererSourceDataMode SourceMode; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	int32_t RendererVisibility; // 0x148(0x04)
	float DecalScreenSizeFade; // 0x14c(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x150(0x38)
	struct FNiagaraVariableAttributeBinding DecalOrientationBinding; // 0x188(0x38)
	struct FNiagaraVariableAttributeBinding DecalSizeBinding; // 0x1c0(0x38)
	struct FNiagaraVariableAttributeBinding DecalFadeBinding; // 0x1f8(0x38)
	struct FNiagaraVariableAttributeBinding DecalSortOrderBinding; // 0x230(0x38)
	struct FNiagaraVariableAttributeBinding DecalColorBinding; // 0x268(0x38)
	struct FNiagaraVariableAttributeBinding DecalVisibleBinding; // 0x2a0(0x38)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x2d8(0x38)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x310(0x50)
	char pad_360[0x40]; // 0x360(0x40)
};

// Class Niagara.NiagaraEditorDataBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraEditorDataBase : UObject {
};

// Class Niagara.NiagaraEditorParametersAdapterBase
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraEditorParametersAdapterBase : UObject {
};

// Class Niagara.NiagaraSignificanceHandler
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraSignificanceHandler : UObject {
};

// Class Niagara.NiagaraSignificanceHandlerDistance
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraSignificanceHandlerDistance : UNiagaraSignificanceHandler {
};

// Class Niagara.NiagaraSignificanceHandlerAge
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraSignificanceHandlerAge : UNiagaraSignificanceHandler {
};

// Class Niagara.NiagaraEffectType
// Size: 0x110 (Inherited: 0xa0)
struct UNiagaraEffectType : UObject {
	bool bAllowCullingForLocalPlayers; // 0x98(0x01)
	enum class ENiagaraScalabilityUpdateFrequency UpdateFrequency; // 0x9c(0x04)
	enum class ENiagaraCullReaction CullReaction; // 0xa0(0x04)
	struct UNiagaraSignificanceHandler* SignificanceHandler; // 0xa8(0x08)
	struct TArray<struct FNiagaraSystemScalabilitySettings> DetailLevelScalabilitySettings; // 0xb0(0x10)
	struct FNiagaraSystemScalabilitySettingsArray SystemScalabilitySettings; // 0xc0(0x10)
	struct FNiagaraEmitterScalabilitySettingsArray EmitterScalabilitySettings; // 0xd0(0x10)
	char pad_e1[0x7]; // 0xe1(0x07)
	struct UNiagaraBaselineController* PerformanceBaselineController; // 0xe8(0x08)
	struct FNiagaraPerfBaselineStats PerfBaselineStats; // 0xf0(0x10)
	struct FGuid PerfBaselineVersion; // 0x100(0x10)
};

// Class Niagara.NiagaraEmitter
// Size: 0xe0 (Inherited: 0xa0)
struct UNiagaraEmitter : UObject {
	struct FGuid ExposedVersion; // 0xa0(0x10)
	bool bVersioningEnabled; // 0xb0(0x01)
	char pad_b1[0x7]; // 0xb1(0x07)
	struct TArray<struct FVersionedNiagaraEmitterData> VersionData; // 0xb8(0x10)
	char pad_c8[0x8]; // 0xc8(0x08)
	struct FString UniqueEmitterName; // 0xd0(0x10)
};

// Class Niagara.NiagaraEventReceiverEmitterAction
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraEventReceiverEmitterAction : UObject {
};

// Class Niagara.NiagaraEventReceiverEmitterAction_SpawnParticles
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraEventReceiverEmitterAction_SpawnParticles : UNiagaraEventReceiverEmitterAction {
	uint32_t NumParticles; // 0x98(0x04)
};

// Class Niagara.NiagaraFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraFunctionLibrary : UBlueprintFunctionLibrary {

	struct UNiagaraComponent* SpawnSystemAttachedWithParams(struct FFXSystemSpawnParameters& SpawnParams); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAttachedWithParams // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4d32790
	struct UNiagaraComponent* SpawnSystemAttached(struct UNiagaraSystem* SystemTemplate, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, enum class EAttachLocation LocationType, bool bAutoDestroy, bool bAutoActivate, enum class ENCPoolMethod PoolingMethod, bool bPreCullCheck); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAttached // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4d31df0
	struct UNiagaraComponent* SpawnSystemAtLocationWithParams(struct FFXSystemSpawnParameters& SpawnParams); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAtLocationWithParams // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4d18fb0
	struct UNiagaraComponent* SpawnSystemAtLocation(struct UObject* WorldContextObject, struct UNiagaraSystem* SystemTemplate, struct FVector Location, struct FRotator Rotation, struct FVector Scale, bool bAutoDestroy, bool bAutoActivate, enum class ENCPoolMethod PoolingMethod, bool bPreCullCheck); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAtLocation // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4d34e60
	void SetVolumeTextureObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UVolumeTexture* Texture); // Function Niagara.NiagaraFunctionLibrary.SetVolumeTextureObject // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d20290
	void SetTextureObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UTexture* Texture); // Function Niagara.NiagaraFunctionLibrary.SetTextureObject // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d20290
	void SetTexture2DArrayObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UTexture2DArray* Texture); // Function Niagara.NiagaraFunctionLibrary.SetTexture2DArrayObject // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d20290
	void SetSkeletalMeshDataInterfaceSamplingRegions(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct TArray<struct FName>& SamplingRegions); // Function Niagara.NiagaraFunctionLibrary.SetSkeletalMeshDataInterfaceSamplingRegions // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4d1ea60
	void SetSkeletalMeshDataInterfaceFilteredSockets(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct TArray<struct FName>& FilteredSockets); // Function Niagara.NiagaraFunctionLibrary.SetSkeletalMeshDataInterfaceFilteredSockets // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4d37710
	void SetSkeletalMeshDataInterfaceFilteredBones(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct TArray<struct FName>& FilteredBones); // Function Niagara.NiagaraFunctionLibrary.SetSkeletalMeshDataInterfaceFilteredBones // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4d16650
	void SetComponentNiagaraGPURayTracedCollisionGroup(struct UObject* WorldContextObject, struct UPrimitiveComponent* Primitive, int32_t CollisionGroup); // Function Niagara.NiagaraFunctionLibrary.SetComponentNiagaraGPURayTracedCollisionGroup // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d36050
	void SetActorNiagaraGPURayTracedCollisionGroup(struct UObject* WorldContextObject, struct AActor* Actor, int32_t CollisionGroup); // Function Niagara.NiagaraFunctionLibrary.SetActorNiagaraGPURayTracedCollisionGroup // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d32280
	void ReleaseNiagaraGPURayTracedCollisionGroup(struct UObject* WorldContextObject, int32_t CollisionGroup); // Function Niagara.NiagaraFunctionLibrary.ReleaseNiagaraGPURayTracedCollisionGroup // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d19270
	void OverrideSystemUserVariableStaticMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMeshComponent* StaticMeshComponent); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMeshComponent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d2ed60
	void OverrideSystemUserVariableStaticMesh(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMesh* StaticMesh); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMesh // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d15410
	void OverrideSystemUserVariableSkeletalMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct USkeletalMeshComponent* SkeletalMeshComponent); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableSkeletalMeshComponent // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d310c0
	struct UNiagaraParameterCollectionInstance* GetNiagaraParameterCollection(struct UObject* WorldContextObject, struct UNiagaraParameterCollection* Collection); // Function Niagara.NiagaraFunctionLibrary.GetNiagaraParameterCollection // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d2e9f0
	int32_t AcquireNiagaraGPURayTracedCollisionGroup(struct UObject* WorldContextObject); // Function Niagara.NiagaraFunctionLibrary.AcquireNiagaraGPURayTracedCollisionGroup // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4d15be0
};

// Class Niagara.NiagaraLensEffectBase
// Size: 0x430 (Inherited: 0x3b0)
struct ANiagaraLensEffectBase : ANiagaraActor {
	struct FTransform DesiredRelativeTransform; // 0x3b0(0x60)
	float BaseAuthoredFOV; // 0x410(0x04)
	char bAllowMultipleInstances : 1; // 0x414(0x01)
	char bResetWhenRetriggered : 1; // 0x414(0x01)
	char pad_414_2 : 6; // 0x414(0x01)
	char pad_415[0x3]; // 0x415(0x03)
	struct TArray<struct AActor*> EmittersToTreatAsSame; // 0x418(0x10)
	struct APlayerCameraManager* OwningCameraManager; // 0x428(0x08)
};

// Class Niagara.NiagaraLightRendererProperties
// Size: 0x310 (Inherited: 0x130)
struct UNiagaraLightRendererProperties : UNiagaraRendererProperties {
	enum class ENiagaraRendererSourceDataMode SourceMode; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	char bUseInverseSquaredFalloff : 1; // 0x134(0x01)
	char bAffectsTranslucency : 1; // 0x134(0x01)
	char bAlphaScalesBrightness : 1; // 0x134(0x01)
	char bOverrideInverseExposureBlend : 1; // 0x134(0x01)
	char pad_134_4 : 4; // 0x134(0x01)
	char pad_135[0x3]; // 0x135(0x03)
	float RadiusScale; // 0x138(0x04)
	float DefaultExponent; // 0x13c(0x04)
	struct FVector3f ColorAdd; // 0x140(0x0c)
	float InverseExposureBlend; // 0x14c(0x04)
	int32_t RendererVisibility; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct FNiagaraVariableAttributeBinding LightRenderingEnabledBinding; // 0x158(0x38)
	struct FNiagaraVariableAttributeBinding LightExponentBinding; // 0x190(0x38)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x1c8(0x38)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x200(0x38)
	struct FNiagaraVariableAttributeBinding RadiusBinding; // 0x238(0x38)
	struct FNiagaraVariableAttributeBinding VolumetricScatteringBinding; // 0x270(0x38)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x2a8(0x38)
	char pad_2e0[0x30]; // 0x2e0(0x30)
};

// Class Niagara.NiagaraMeshRendererProperties
// Size: 0x700 (Inherited: 0x130)
struct UNiagaraMeshRendererProperties : UNiagaraRendererProperties {
	struct TArray<struct FNiagaraMeshRendererMeshProperties> Meshes; // 0x130(0x10)
	enum class ENiagaraRendererSourceDataMode SourceMode; // 0x140(0x01)
	enum class ENiagaraSortMode SortMode; // 0x141(0x01)
	enum class ENiagaraRendererSortPrecision SortPrecision; // 0x142(0x01)
	enum class ENiagaraRendererGpuTranslucentLatency GpuTranslucentLatency; // 0x143(0x01)
	char bOverrideMaterials : 1; // 0x144(0x01)
	char bUseHeterogeneousVolumes : 1; // 0x144(0x01)
	char bSortOnlyWhenTranslucent : 1; // 0x144(0x01)
	char bSubImageBlend : 1; // 0x144(0x01)
	char bEnableFrustumCulling : 1; // 0x144(0x01)
	char bEnableCameraDistanceCulling : 1; // 0x144(0x01)
	char bEnableMeshFlipbook : 1; // 0x144(0x01)
	char bLockedAxisEnable : 1; // 0x144(0x01)
	char pad_145[0x3]; // 0x145(0x03)
	struct TArray<struct FNiagaraMeshMaterialOverride> OverrideMaterials; // 0x148(0x10)
	struct TArray<struct FNiagaraMeshMICOverride> MICOverrideMaterials; // 0x158(0x10)
	struct FVector2D SubImageSize; // 0x168(0x10)
	struct FVector LockedAxis; // 0x178(0x18)
	struct FVector MeshBoundsScale; // 0x190(0x18)
	enum class ENiagaraMeshFacingMode FacingMode; // 0x1a8(0x01)
	enum class ENiagaraMeshLockedAxisSpace LockedAxisSpace; // 0x1a9(0x01)
	char pad_1aa[0x2]; // 0x1aa(0x02)
	float MinCameraDistance; // 0x1ac(0x04)
	float MaxCameraDistance; // 0x1b0(0x04)
	uint32_t RendererVisibility; // 0x1b4(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x1b8(0x38)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x1f0(0x38)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x228(0x38)
	struct FNiagaraVariableAttributeBinding MeshOrientationBinding; // 0x260(0x38)
	struct FNiagaraVariableAttributeBinding ScaleBinding; // 0x298(0x38)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding; // 0x2d0(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x308(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x340(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x378(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x3b0(0x38)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x3e8(0x38)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x420(0x38)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x458(0x38)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding; // 0x490(0x38)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x4c8(0x38)
	struct FNiagaraVariableAttributeBinding MeshIndexBinding; // 0x500(0x38)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x538(0x50)
	struct FNiagaraVariableAttributeBinding PrevPositionBinding; // 0x588(0x38)
	struct FNiagaraVariableAttributeBinding PrevScaleBinding; // 0x5c0(0x38)
	struct FNiagaraVariableAttributeBinding PrevMeshOrientationBinding; // 0x5f8(0x38)
	struct FNiagaraVariableAttributeBinding PrevCameraOffsetBinding; // 0x630(0x38)
	struct FNiagaraVariableAttributeBinding PrevVelocityBinding; // 0x668(0x38)
	uint32_t MaterialParamValidMask; // 0x6a0(0x04)
	char pad_6a4[0x5c]; // 0x6a4(0x5c)
};

// Class Niagara.NiagaraParameterCollectionInstance
// Size: 0x160 (Inherited: 0xa0)
struct UNiagaraParameterCollectionInstance : UObject {
	struct UNiagaraParameterCollection* Collection; // 0x98(0x08)
	struct TArray<struct FNiagaraVariable> OverridenParameters; // 0xa0(0x10)
	struct FNiagaraParameterStore ParameterStorage; // 0xb0(0x88)
	char pad_140[0x20]; // 0x140(0x20)

	void SetVectorParameter(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVectorParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d837e0
	void SetVector4Parameter(struct FString InVariableName, struct FVector4& InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVector4Parameter // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4d73830
	void SetVector2DParameter(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVector2DParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d73400
	void SetQuatParameter(struct FString InVariableName, struct FQuat& InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetQuatParameter // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4d55ac0
	void SetIntParameter(struct FString InVariableName, int32_t InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetIntParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4d57010
	void SetFloatParameter(struct FString InVariableName, float InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetFloatParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4d66be0
	void SetColorParameter(struct FString InVariableName, struct FLinearColor InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetColorParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d76dc0
	void SetBoolParameter(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetBoolParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4d5bab0
	struct FVector GetVectorParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVectorParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d617a0
	struct FVector4 GetVector4Parameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVector4Parameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d48620
	struct FVector2D GetVector2DParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVector2DParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d63320
	struct FQuat GetQuatParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetQuatParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d634e0
	int32_t GetIntParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetIntParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4d75c90
	float GetFloatParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetFloatParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4d51e40
	struct FLinearColor GetColorParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetColorParameter // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x4d63b40
	bool GetBoolParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetBoolParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x4d48990
};

// Class Niagara.NiagaraParameterCollection
// Size: 0xd0 (Inherited: 0xa0)
struct UNiagaraParameterCollection : UObject {
	struct FName Namespace; // 0x98(0x08)
	struct TArray<struct FNiagaraVariable> Parameters; // 0xa0(0x10)
	struct UMaterialParameterCollection* SourceMaterialCollection; // 0xb0(0x08)
	struct UNiagaraParameterCollectionInstance* DefaultInstance; // 0xb8(0x08)
	struct FGuid CompileId; // 0xc0(0x10)
};

// Class Niagara.NiagaraBaselineController
// Size: 0xe0 (Inherited: 0xa0)
struct UNiagaraBaselineController : UObject {
	float TestDuration; // 0x98(0x04)
	struct UNiagaraEffectType* EffectType; // 0xa0(0x08)
	struct ANiagaraPerfBaselineActor* Owner; // 0xa8(0x08)
	struct TSoftObjectPtr<UNiagaraSystem> System; // 0xb0(0x28)
	char pad_dc[0x4]; // 0xdc(0x04)

	bool OnTickTest(); // Function Niagara.NiagaraBaselineController.OnTickTest // (RequiredAPI|Native|Event|Public|BlueprintEvent) // @ game+0x3acf850
	void OnOwnerTick(float DeltaTime); // Function Niagara.NiagaraBaselineController.OnOwnerTick // (RequiredAPI|Native|Event|Public|BlueprintEvent) // @ game+0x4d73990
	void OnEndTest(struct FNiagaraPerfBaselineStats Stats); // Function Niagara.NiagaraBaselineController.OnEndTest // (RequiredAPI|Native|Event|Public|BlueprintEvent) // @ game+0x4d5d3b0
	void OnBeginTest(); // Function Niagara.NiagaraBaselineController.OnBeginTest // (RequiredAPI|Native|Event|Public|BlueprintEvent) // @ game+0x16fe8b0
	struct UNiagaraSystem* GetSystem(); // Function Niagara.NiagaraBaselineController.GetSystem // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2f822c0
};

// Class Niagara.NiagaraBaselineController_Basic
// Size: 0xf0 (Inherited: 0xe0)
struct UNiagaraBaselineController_Basic : UNiagaraBaselineController {
	int32_t NumInstances; // 0xd8(0x04)
	struct TArray<struct UNiagaraComponent*> SpawnedComponents; // 0xe0(0x10)
};

// Class Niagara.NiagaraPerfBaselineActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ANiagaraPerfBaselineActor : AActor {
	struct UNiagaraBaselineController* Controller; // 0x398(0x08)
	struct UTextRenderComponent* Label; // 0x3a0(0x08)
};

// Class Niagara.NiagaraPrecompileContainer
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraPrecompileContainer : UObject {
	struct TArray<struct UNiagaraScript*> Scripts; // 0x98(0x10)
	struct UNiagaraSystem* System; // 0xa8(0x08)
};

// Class Niagara.NiagaraPreviewBase
// Size: 0x3a0 (Inherited: 0x3a0)
struct ANiagaraPreviewBase : AActor {

	void SetSystem(struct UNiagaraSystem* InSystem); // Function Niagara.NiagaraPreviewBase.SetSystem // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x4abfe0
	void SetLabelText(struct FText& InXAxisText, struct FText& InYAxisText); // Function Niagara.NiagaraPreviewBase.SetLabelText // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x4abfe0
};

// Class Niagara.NiagaraPreviewAxis
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraPreviewAxis : UObject {

	int32_t Num(); // Function Niagara.NiagaraPreviewAxis.Num // (Native|Event|Public|BlueprintEvent) // @ game+0x2c808c0
	void ApplyToPreview(struct UNiagaraComponent* PreviewComponent, int32_t PreviewIndex, bool bIsXAxis, struct FString& OutLabelText); // Function Niagara.NiagaraPreviewAxis.ApplyToPreview // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4d790b0
};

// Class Niagara.NiagaraPreviewAxis_InterpParamBase
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraPreviewAxis_InterpParamBase : UNiagaraPreviewAxis {
	struct FName Param; // 0x98(0x08)
	int32_t Count; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamInt32
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraPreviewAxis_InterpParamInt32 : UNiagaraPreviewAxis_InterpParamBase {
	int32_t Min; // 0xa8(0x04)
	int32_t Max; // 0xac(0x04)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamFloat
// Size: 0xb0 (Inherited: 0xb0)
struct UNiagaraPreviewAxis_InterpParamFloat : UNiagaraPreviewAxis_InterpParamBase {
	float Min; // 0xa8(0x04)
	float Max; // 0xac(0x04)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamVector2D
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraPreviewAxis_InterpParamVector2D : UNiagaraPreviewAxis_InterpParamBase {
	struct FVector2D Min; // 0xa8(0x10)
	struct FVector2D Max; // 0xb8(0x10)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamVector
// Size: 0xe0 (Inherited: 0xb0)
struct UNiagaraPreviewAxis_InterpParamVector : UNiagaraPreviewAxis_InterpParamBase {
	struct FVector Min; // 0xa8(0x18)
	struct FVector Max; // 0xc0(0x18)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamVector4
// Size: 0xf0 (Inherited: 0xb0)
struct UNiagaraPreviewAxis_InterpParamVector4 : UNiagaraPreviewAxis_InterpParamBase {
	struct FVector4 Min; // 0xb0(0x20)
	struct FVector4 Max; // 0xd0(0x20)
};

// Class Niagara.NiagaraPreviewAxis_InterpParamLinearColor
// Size: 0xd0 (Inherited: 0xb0)
struct UNiagaraPreviewAxis_InterpParamLinearColor : UNiagaraPreviewAxis_InterpParamBase {
	struct FLinearColor Min; // 0xa8(0x10)
	struct FLinearColor Max; // 0xb8(0x10)
};

// Class Niagara.NiagaraPreviewGrid
// Size: 0x3f0 (Inherited: 0x3a0)
struct ANiagaraPreviewGrid : AActor {
	struct UNiagaraSystem* System; // 0x398(0x08)
	enum class ENiagaraPreviewGridResetMode ResetMode; // 0x3a0(0x01)
	struct UNiagaraPreviewAxis* PreviewAxisX; // 0x3a8(0x08)
	struct UNiagaraPreviewAxis* PreviewAxisY; // 0x3b0(0x08)
	struct ANiagaraPreviewBase* PreviewClass; // 0x3b8(0x08)
	float SpacingX; // 0x3c0(0x04)
	float SpacingY; // 0x3c4(0x04)
	int32_t NumX; // 0x3c8(0x04)
	int32_t NumY; // 0x3cc(0x04)
	struct TArray<struct UChildActorComponent*> PreviewComponents; // 0x3d0(0x10)
	char pad_3e1[0xf]; // 0x3e1(0x0f)

	void SetPaused(bool bPaused); // Function Niagara.NiagaraPreviewGrid.SetPaused // (Final|Native|Public|BlueprintCallable) // @ game+0x4d6f000
	void GetPreviews(struct TArray<struct UNiagaraComponent*>& OutPreviews); // Function Niagara.NiagaraPreviewGrid.GetPreviews // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4d4ff60
	void DeactivatePreviews(); // Function Niagara.NiagaraPreviewGrid.DeactivatePreviews // (Final|Native|Public|BlueprintCallable) // @ game+0x4d75820
	void ActivatePreviews(bool bReset); // Function Niagara.NiagaraPreviewGrid.ActivatePreviews // (Final|Native|Public|BlueprintCallable) // @ game+0x4d581e0
};

// Class Niagara.NiagaraRibbonRendererProperties
// Size: 0x7e0 (Inherited: 0x130)
struct UNiagaraRibbonRendererProperties : UNiagaraRendererProperties {
	struct UMaterialInterface* Material; // 0x130(0x08)
	struct FNiagaraUserParameterBinding MaterialUserParamBinding; // 0x138(0x20)
	struct FNiagaraRibbonUVSettings UV0Settings; // 0x158(0x28)
	struct FNiagaraRibbonUVSettings UV1Settings; // 0x180(0x28)
	enum class ENiagaraRibbonFacingMode FacingMode; // 0x1a8(0x01)
	char pad_1a9[0x3]; // 0x1a9(0x03)
	int32_t MaxNumRibbons; // 0x1ac(0x04)
	enum class ENiagaraRibbonDrawDirection DrawDirection; // 0x1b0(0x01)
	enum class ENiagaraRibbonShapeMode Shape; // 0x1b1(0x01)
	char bEnableAccurateGeometry : 1; // 0x1b2(0x01)
	char bUseMaterialBackfaceCulling : 1; // 0x1b2(0x01)
	char bUseGPUInit : 1; // 0x1b2(0x01)
	char bUseConstantFactor : 1; // 0x1b2(0x01)
	char bScreenSpaceTessellation : 1; // 0x1b2(0x01)
	char bLinkOrderUseUniqueID : 1; // 0x1b2(0x01)
	char pad_1b2_6 : 2; // 0x1b2(0x01)
	char pad_1b3[0x1]; // 0x1b3(0x01)
	int32_t WidthSegmentationCount; // 0x1b4(0x04)
	int32_t MultiPlaneCount; // 0x1b8(0x04)
	int32_t TubeSubdivisions; // 0x1bc(0x04)
	struct TArray<struct FNiagaraRibbonShapeCustomVertex> CustomVertices; // 0x1c0(0x10)
	enum class ENiagaraRibbonTessellationMode TessellationMode; // 0x1d0(0x01)
	char pad_1d1[0x3]; // 0x1d1(0x03)
	float CurveTension; // 0x1d4(0x04)
	int32_t TessellationFactor; // 0x1d8(0x04)
	float TessellationAngle; // 0x1dc(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x1e0(0x38)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x218(0x38)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x250(0x38)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x288(0x38)
	struct FNiagaraVariableAttributeBinding RibbonTwistBinding; // 0x2c0(0x38)
	struct FNiagaraVariableAttributeBinding RibbonWidthBinding; // 0x2f8(0x38)
	struct FNiagaraVariableAttributeBinding RibbonFacingBinding; // 0x330(0x38)
	struct FNiagaraVariableAttributeBinding RibbonIdBinding; // 0x368(0x38)
	struct FNiagaraVariableAttributeBinding RibbonLinkOrderBinding; // 0x3a0(0x38)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x3d8(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x410(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x448(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x480(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x4b8(0x38)
	struct FNiagaraVariableAttributeBinding RibbonUVDistance; // 0x4f0(0x38)
	struct FNiagaraVariableAttributeBinding U0OverrideBinding; // 0x528(0x38)
	struct FNiagaraVariableAttributeBinding V0RangeOverrideBinding; // 0x560(0x38)
	struct FNiagaraVariableAttributeBinding U1OverrideBinding; // 0x598(0x38)
	struct FNiagaraVariableAttributeBinding V1RangeOverrideBinding; // 0x5d0(0x38)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x608(0x50)
	struct FNiagaraVariableAttributeBinding PrevPositionBinding; // 0x658(0x38)
	struct FNiagaraVariableAttributeBinding PrevRibbonWidthBinding; // 0x690(0x38)
	struct FNiagaraVariableAttributeBinding PrevRibbonFacingBinding; // 0x6c8(0x38)
	struct FNiagaraVariableAttributeBinding PrevRibbonTwistBinding; // 0x700(0x38)
	uint32_t MaterialParamValidMask; // 0x738(0x04)
	char pad_73c[0xa4]; // 0x73c(0xa4)
};

// Class Niagara.NiagaraScratchPadContainer
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraScratchPadContainer : UObject {
};

// Class Niagara.NiagaraScript
// Size: 0x450 (Inherited: 0xa0)
struct UNiagaraScript : UNiagaraScriptBase {
	enum class ENiagaraScriptUsage Usage; // 0xa0(0x01)
	char pad_a1[0x3]; // 0xa1(0x03)
	struct FGuid UsageId; // 0xa4(0x10)
	char pad_b4[0x4]; // 0xb4(0x04)
	struct FNiagaraParameterStore RapidIterationParameters; // 0xb8(0x88)
	struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStore; // 0x140(0xa8)
	struct TArray<struct FNiagaraBoundParameter> ScriptExecutionBoundParameters; // 0x1e8(0x10)
	struct FNiagaraVMExecutableDataId CachedScriptVMId; // 0x1f8(0x58)
	char pad_250[0x18]; // 0x250(0x18)
	struct FNiagaraVMExecutableData CachedScriptVM; // 0x268(0x1a0)
	struct TArray<struct UNiagaraParameterCollection*> CachedParameterCollectionReferences; // 0x408(0x10)
	struct TArray<struct FNiagaraScriptResolvedDataInterfaceInfo> ResolvedDataInterfaces; // 0x418(0x10)
	struct TArray<struct FNiagaraResolvedUserDataInterfaceBinding> ResolvedUserDataInterfaceBindings; // 0x428(0x10)
	struct TArray<struct FNiagaraResolvedUObjectInfo> ResolvedUObjectInfos; // 0x438(0x10)
	char pad_448[0x8]; // 0x448(0x08)

	void RaiseOnGPUCompilationComplete(); // Function Niagara.NiagaraScript.RaiseOnGPUCompilationComplete // (Final|Native|Public) // @ game+0x29fb8f0
};

// Class Niagara.NiagaraSimCache
// Size: 0x270 (Inherited: 0xa0)
struct UNiagaraSimCache : UObject {
	struct FGuid CacheGuid; // 0x98(0x10)
	struct TSoftObjectPtr<UNiagaraSystem> SoftNiagaraSystem; // 0xa8(0x28)
	float StartSeconds; // 0xd0(0x04)
	float DurationSeconds; // 0xd4(0x04)
	struct FNiagaraSimCacheCreateParameters CreateParameters; // 0xd8(0x58)
	bool bNeedsReadComponentMappingRecache; // 0x130(0x01)
	struct FNiagaraSimCacheLayout CacheLayout; // 0x138(0xc8)
	struct TArray<struct FNiagaraSimCacheFrame> CacheFrames; // 0x200(0x10)
	struct TMap<struct FNiagaraVariableBase, struct UObject*> DataInterfaceStorage; // 0x210(0x50)
	char pad_261[0xf]; // 0x261(0x0f)

	void ReadVectorAttribute(struct TArray<struct FVector>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadVectorAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4dac200
	void ReadVector4Attribute(struct TArray<struct FVector4>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadVector4Attribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d93df0
	void ReadVector2Attribute(struct TArray<struct FVector2D>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadVector2Attribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d91af0
	void ReadQuatAttributeWithRebase(struct TArray<struct FQuat>& OutValues, struct FQuat Quat, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadQuatAttributeWithRebase // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4db4b00
	void ReadQuatAttribute(struct TArray<struct FQuat>& OutValues, struct FName AttributeName, struct FName EmitterName, bool bLocalSpaceToWorld, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadQuatAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4da3c70
	void ReadPositionAttributeWithRebase(struct TArray<struct FVector>& OutValues, struct FTransform Transform, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadPositionAttributeWithRebase // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d917c0
	void ReadPositionAttribute(struct TArray<struct FVector>& OutValues, struct FName AttributeName, struct FName EmitterName, bool bLocalSpaceToWorld, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadPositionAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d969d0
	void ReadIntAttribute(struct TArray<int32_t>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadIntAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4dbd5e0
	void ReadIDAttribute(struct TArray<struct FNiagaraID>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadIDAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4da41d0
	void ReadFloatAttribute(struct TArray<float>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadFloatAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4dc2f40
	void ReadColorAttribute(struct TArray<struct FLinearColor>& OutValues, struct FName AttributeName, struct FName EmitterName, int32_t FrameIndex); // Function Niagara.NiagaraSimCache.ReadColorAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d980c0
	bool IsEmpty(); // Function Niagara.NiagaraSimCache.IsEmpty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d962b0
	bool IsCacheValid(); // Function Niagara.NiagaraSimCache.IsCacheValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d9d110
	float GetStartSeconds(); // Function Niagara.NiagaraSimCache.GetStartSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4da06a0
	int32_t GetNumFrames(); // Function Niagara.NiagaraSimCache.GetNumFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4d980a0
	int32_t GetNumEmitters(); // Function Niagara.NiagaraSimCache.GetNumEmitters // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x29792c0
	struct TArray<struct FName> GetEmitterNames(); // Function Niagara.NiagaraSimCache.GetEmitterNames // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4da63a0
	struct FName GetEmitterName(int32_t EmitterIndex); // Function Niagara.NiagaraSimCache.GetEmitterName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4db5a30
	enum class ENiagaraSimCacheAttributeCaptureMode GetAttributeCaptureMode(); // Function Niagara.NiagaraSimCache.GetAttributeCaptureMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4dc6770
};

// Class Niagara.AsyncNiagaraCaptureSimCache
// Size: 0x1a0 (Inherited: 0xa0)
struct UAsyncNiagaraCaptureSimCache : UCancellableAsyncAction {
	struct UNiagaraSimCache* CaptureSimCache; // 0xa0(0x08)
	struct UNiagaraComponent* CaptureComponent; // 0xa8(0x08)
	struct FMulticastInlineDelegate CaptureComplete; // 0xb0(0x10)
	char pad_c0[0xe0]; // 0xc0(0xe0)

	void OnCaptureComplete__DelegateSignature(bool bSuccess); // DelegateFunction Niagara.AsyncNiagaraCaptureSimCache.OnCaptureComplete__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	struct UAsyncNiagaraCaptureSimCache* CaptureNiagaraSimCacheUntilComplete(struct UNiagaraSimCache* SimCache, struct FNiagaraSimCacheCreateParameters CreateParameters, struct UNiagaraComponent* NiagaraComponent, struct UNiagaraSimCache*& OutSimCache, int32_t CaptureRate, bool bAdvanceSimulation, float AdvanceDeltaTime); // Function Niagara.AsyncNiagaraCaptureSimCache.CaptureNiagaraSimCacheUntilComplete // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4dae9f0
	struct UAsyncNiagaraCaptureSimCache* CaptureNiagaraSimCacheMultiFrame(struct UNiagaraSimCache* SimCache, struct FNiagaraSimCacheCreateParameters CreateParameters, struct UNiagaraComponent* NiagaraComponent, struct UNiagaraSimCache*& OutSimCache, int32_t NumFrames, int32_t CaptureRate, bool bAdvanceSimulation, float AdvanceDeltaTime); // Function Niagara.AsyncNiagaraCaptureSimCache.CaptureNiagaraSimCacheMultiFrame // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4db53e0
	struct UAsyncNiagaraCaptureSimCache* CaptureNiagaraSimCache(struct UNiagaraSimCache* SimCache, struct FNiagaraSimCacheCreateParameters CreateParameters, struct UNiagaraComponent* NiagaraComponent, struct FNiagaraSimCacheCaptureParameters CaptureParameters, struct UNiagaraSimCache*& OutSimCache); // Function Niagara.AsyncNiagaraCaptureSimCache.CaptureNiagaraSimCache // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4da00b0
};

// Class Niagara.NiagaraSimCacheFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraSimCacheFunctionLibrary : UBlueprintFunctionLibrary {

	struct UNiagaraSimCache* CreateNiagaraSimCache(struct UObject* WorldContextObject); // Function Niagara.NiagaraSimCacheFunctionLibrary.CreateNiagaraSimCache // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x4db37f0
	bool CaptureNiagaraSimCacheImmediate(struct UNiagaraSimCache* SimCache, struct FNiagaraSimCacheCreateParameters CreateParameters, struct UNiagaraComponent* NiagaraComponent, struct UNiagaraSimCache*& OutSimCache, bool bAdvanceSimulation, float AdvanceDeltaTime); // Function Niagara.NiagaraSimCacheFunctionLibrary.CaptureNiagaraSimCacheImmediate // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4d98310
};

// Class Niagara.NiagaraSimulationStageBase
// Size: 0xb0 (Inherited: 0xa0)
struct UNiagaraSimulationStageBase : UNiagaraMergeable {
	struct UNiagaraScript* Script; // 0x98(0x08)
	struct FName SimulationStageName; // 0xa0(0x08)
	char bEnabled : 1; // 0xa8(0x01)
};

// Class Niagara.NiagaraSimulationStageGeneric
// Size: 0x250 (Inherited: 0xb0)
struct UNiagaraSimulationStageGeneric : UNiagaraSimulationStageBase {
	struct FNiagaraVariableAttributeBinding EnabledBinding; // 0xb0(0x38)
	enum class ENiagaraIterationSource IterationSource; // 0xe8(0x01)
	char pad_e9[0x7]; // 0xe9(0x07)
	struct FNiagaraParameterBindingWithValue NumIterations; // 0xf0(0x20)
	enum class ENiagaraSimStageExecuteBehavior ExecuteBehavior; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	char bDisablePartialParticleUpdate : 1; // 0x114(0x01)
	char pad_114_1 : 7; // 0x114(0x01)
	char pad_115[0x3]; // 0x115(0x03)
	struct FNiagaraVariableDataInterfaceBinding DataInterface; // 0x118(0x20)
	char bParticleIterationStateEnabled : 1; // 0x138(0x01)
	char pad_138_1 : 7; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	struct FNiagaraVariableAttributeBinding ParticleIterationStateBinding; // 0x140(0x38)
	struct FIntPoint ParticleIterationStateRange; // 0x178(0x08)
	char bGpuDispatchForceLinear : 1; // 0x180(0x01)
	char bOverrideGpuDispatchNumThreads : 1; // 0x180(0x01)
	char pad_180_2 : 6; // 0x180(0x01)
	char pad_181[0x7]; // 0x181(0x07)
	struct FNiagaraParameterBindingWithValue OverrideGpuDispatchNumThreadsX; // 0x188(0x20)
	struct FNiagaraParameterBindingWithValue OverrideGpuDispatchNumThreadsY; // 0x1a8(0x20)
	struct FNiagaraParameterBindingWithValue OverrideGpuDispatchNumThreadsZ; // 0x1c8(0x20)
	enum class ENiagaraGpuDispatchType DirectDispatchType; // 0x1e8(0x01)
	enum class ENiagaraDirectDispatchElementType DirectDispatchElementType; // 0x1e9(0x01)
	char pad_1ea[0x6]; // 0x1ea(0x06)
	struct FNiagaraParameterBindingWithValue ElementCountX; // 0x1f0(0x20)
	struct FNiagaraParameterBindingWithValue ElementCountY; // 0x210(0x20)
	struct FNiagaraParameterBindingWithValue ElementCountZ; // 0x230(0x20)
};

// Class Niagara.NiagaraSpriteRendererProperties
// Size: 0x840 (Inherited: 0x130)
struct UNiagaraSpriteRendererProperties : UNiagaraRendererProperties {
	struct UMaterialInterface* Material; // 0x130(0x08)
	struct FNiagaraUserParameterBinding MaterialUserParamBinding; // 0x138(0x20)
	enum class ENiagaraRendererSourceDataMode SourceMode; // 0x158(0x01)
	enum class ENiagaraSpriteAlignment Alignment; // 0x159(0x01)
	enum class ENiagaraSpriteFacingMode FacingMode; // 0x15a(0x01)
	enum class ENiagaraSortMode SortMode; // 0x15b(0x01)
	float MacroUVRadius; // 0x15c(0x04)
	struct FVector2D PivotInUVSpace; // 0x160(0x10)
	struct FVector2D SubImageSize; // 0x170(0x10)
	char bSubImageBlend : 1; // 0x180(0x01)
	char bRemoveHMDRollInVR : 1; // 0x180(0x01)
	char bSortOnlyWhenTranslucent : 1; // 0x180(0x01)
	char bEnableCameraDistanceCulling : 1; // 0x180(0x01)
	char pad_180_4 : 4; // 0x180(0x01)
	enum class ENiagaraRendererSortPrecision SortPrecision; // 0x181(0x01)
	enum class ENiagaraRendererGpuTranslucentLatency GpuTranslucentLatency; // 0x182(0x01)
	enum class ENiagaraRendererPixelCoverageMode PixelCoverageMode; // 0x183(0x01)
	float PixelCoverageBlend; // 0x184(0x04)
	float MinFacingCameraBlendDistance; // 0x188(0x04)
	float MaxFacingCameraBlendDistance; // 0x18c(0x04)
	float MinCameraDistance; // 0x190(0x04)
	float MaxCameraDistance; // 0x194(0x04)
	uint32_t RendererVisibility; // 0x198(0x04)
	char pad_19c[0x4]; // 0x19c(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x1a0(0x38)
	struct FNiagaraVariableAttributeBinding ColorBinding; // 0x1d8(0x38)
	struct FNiagaraVariableAttributeBinding VelocityBinding; // 0x210(0x38)
	struct FNiagaraVariableAttributeBinding SpriteRotationBinding; // 0x248(0x38)
	struct FNiagaraVariableAttributeBinding SpriteSizeBinding; // 0x280(0x38)
	struct FNiagaraVariableAttributeBinding SpriteFacingBinding; // 0x2b8(0x38)
	struct FNiagaraVariableAttributeBinding SpriteAlignmentBinding; // 0x2f0(0x38)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding; // 0x328(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding; // 0x360(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding; // 0x398(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding; // 0x3d0(0x38)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding; // 0x408(0x38)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding; // 0x440(0x38)
	struct FNiagaraVariableAttributeBinding UVScaleBinding; // 0x478(0x38)
	struct FNiagaraVariableAttributeBinding PivotOffsetBinding; // 0x4b0(0x38)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding; // 0x4e8(0x38)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding; // 0x520(0x38)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding; // 0x558(0x38)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x590(0x38)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x5c8(0x50)
	struct FNiagaraVariableAttributeBinding PrevPositionBinding; // 0x618(0x38)
	struct FNiagaraVariableAttributeBinding PrevVelocityBinding; // 0x650(0x38)
	struct FNiagaraVariableAttributeBinding PrevSpriteRotationBinding; // 0x688(0x38)
	struct FNiagaraVariableAttributeBinding PrevSpriteSizeBinding; // 0x6c0(0x38)
	struct FNiagaraVariableAttributeBinding PrevSpriteFacingBinding; // 0x6f8(0x38)
	struct FNiagaraVariableAttributeBinding PrevSpriteAlignmentBinding; // 0x730(0x38)
	struct FNiagaraVariableAttributeBinding PrevCameraOffsetBinding; // 0x768(0x38)
	struct FNiagaraVariableAttributeBinding PrevPivotOffsetBinding; // 0x7a0(0x38)
	uint32_t MaterialParamValidMask; // 0x7d8(0x04)
	char pad_7dc[0x64]; // 0x7dc(0x64)
};

// Class Niagara.NiagaraSystem
// Size: 0x560 (Inherited: 0xc0)
struct UNiagaraSystem : UFXSystemAsset {
	char bSupportLargeWorldCoordinates : 1; // 0xb8(0x01)
	char bOverrideCastShadow : 1; // 0xb8(0x01)
	char bOverrideReceivesDecals : 1; // 0xb8(0x01)
	char bOverrideRenderCustomDepth : 1; // 0xb8(0x01)
	char bOverrideCustomDepthStencilValue : 1; // 0xb8(0x01)
	char bOverrideCustomDepthStencilWriteMask : 1; // 0xb8(0x01)
	char bOverrideTranslucencySortPriority : 1; // 0xb8(0x01)
	char bOverrideTranslucencySortDistanceOffset : 1; // 0xb8(0x01)
	char bCastShadow : 1; // 0xb9(0x01)
	char bReceivesDecals : 1; // 0xb9(0x01)
	char bRenderCustomDepth : 1; // 0xb9(0x01)
	char bDisableExperimentalVM : 1; // 0xb9(0x01)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0xba(0x01)
	int32_t CustomDepthStencilValue; // 0xbc(0x04)
	int32_t TranslucencySortPriority; // 0xc0(0x04)
	float TranslucencySortDistanceOffset; // 0xc4(0x04)
	bool bDumpDebugSystemInfo; // 0xc8(0x01)
	bool bDumpDebugEmitterInfo; // 0xc9(0x01)
	bool bRequireCurrentFrameData; // 0xcb(0x01)
	char bFixedBounds : 1; // 0xcc(0x01)
	struct UNiagaraEffectType* EffectType; // 0xd0(0x08)
	bool bOverrideScalabilitySettings; // 0xd8(0x01)
	char pad_da_5 : 3; // 0xda(0x01)
	char pad_db[0x1]; // 0xdb(0x01)
	char bOverrideAllowCullingForLocalPlayers : 1; // 0xdc(0x01)
	char bAllowCullingForLocalPlayersOverride : 1; // 0xdc(0x01)
	char pad_dc_2 : 6; // 0xdc(0x01)
	char pad_dd[0x3]; // 0xdd(0x03)
	struct FNiagaraSystemScalabilityOverrides SystemScalabilityOverrides; // 0xe0(0x10)
	struct TArray<struct FNiagaraEmitterHandle> EmitterHandles; // 0xf0(0x10)
	struct TArray<struct UNiagaraParameterCollectionInstance*> ParameterCollectionOverrides; // 0x100(0x10)
	struct UNiagaraScript* SystemSpawnScript; // 0x110(0x08)
	struct UNiagaraScript* SystemUpdateScript; // 0x118(0x08)
	char pad_120[0x10]; // 0x120(0x10)
	struct FNiagaraSystemCompiledData SystemCompiledData; // 0x130(0x240)
	struct FNiagaraUserRedirectionParameterStore ExposedParameters; // 0x370(0xd8)
	struct FBox FixedBounds; // 0x448(0x38)
	bool bAutoDeactivate; // 0x480(0x01)
	bool bDeterminism; // 0x481(0x01)
	char pad_482[0x2]; // 0x482(0x02)
	int32_t RandomSeed; // 0x484(0x04)
	float WarmupTime; // 0x488(0x04)
	int32_t WarmupTickCount; // 0x48c(0x04)
	float WarmupTickDelta; // 0x490(0x04)
	bool bFixedTickDelta; // 0x494(0x01)
	char pad_495[0x3]; // 0x495(0x03)
	float FixedTickDeltaTime; // 0x498(0x04)
	bool bNeedsGPUContextInitForDataInterfaces; // 0x49c(0x01)
	char pad_49d[0xc3]; // 0x49d(0xc3)
};

// Class Niagara.NiagaraValidationRule
// Size: 0xa0 (Inherited: 0xa0)
struct UNiagaraValidationRule : UObject {
};

// Class Niagara.NiagaraVolumeRendererProperties
// Size: 0x330 (Inherited: 0x130)
struct UNiagaraVolumeRendererProperties : UNiagaraRendererProperties {
	struct UMaterialInterface* Material; // 0x130(0x08)
	struct FNiagaraParameterBinding MaterialParameterBinding; // 0x138(0x0c)
	char pad_144[0x4]; // 0x144(0x04)
	int32_t RendererVisibility; // 0x148(0x04)
	float StepFactor; // 0x14c(0x04)
	float LightingDownsampleFactor; // 0x150(0x04)
	float ShadowStepFactor; // 0x154(0x04)
	float ShadowBiasFactor; // 0x158(0x04)
	char pad_15c[0xac]; // 0x15c(0xac)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x208(0x38)
	struct FNiagaraVariableAttributeBinding VolumeResolutionMaxAxisBinding; // 0x240(0x38)
	struct FNiagaraVariableAttributeBinding VolumeWorldSpaceSizeBinding; // 0x278(0x38)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x2b0(0x50)
	char pad_300[0x30]; // 0x300(0x30)
};

// Class Niagara.VolumeCache
// Size: 0xd0 (Inherited: 0xa0)
struct UVolumeCache : UObject {
	struct FString FilePath; // 0x98(0x10)
	enum class EVolumeCacheType CacheType; // 0xa8(0x01)
	struct FIntVector Resolution; // 0xac(0x0c)
	int32_t FrameRangeStart; // 0xb8(0x04)
	int32_t FrameRangeEnd; // 0xbc(0x04)
	char pad_c5[0xb]; // 0xc5(0x0b)
};

