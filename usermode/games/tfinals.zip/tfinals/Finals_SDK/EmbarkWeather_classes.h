// Class EmbarkWeather.EmbarkNiagaraDataInterfaceWeather
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkNiagaraDataInterfaceWeather : UNiagaraDataInterface {
	struct FGameplayTag WeatherTag; // 0xa8(0x08)
};

// Class EmbarkWeather.EmbarkWeatherManager
// Size: 0x3c0 (Inherited: 0x3a0)
struct AEmbarkWeatherManager : AActor {
	struct FGameplayTagContainer WeatherTags; // 0x398(0x20)

	bool ShouldEffectBeActive(struct UNiagaraSystem* NiagaraSystem); // Function EmbarkWeather.EmbarkWeatherManager.ShouldEffectBeActive // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x695d0a0
	struct FGameplayTagContainer GetWeatherTags(); // Function EmbarkWeather.EmbarkWeatherManager.GetWeatherTags // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x695f4d0
};

// Class EmbarkWeather.EmbarkWeatherSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkWeatherSubsystem : UWorldSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)

	struct AEmbarkWeatherManager* GetWeatherManager(); // Function EmbarkWeather.EmbarkWeatherSubsystem.GetWeatherManager // (Final|Native|Public|BlueprintCallable) // @ game+0x695c680
};

