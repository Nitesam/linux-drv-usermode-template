// Class OnlineTestFramework.EventListenerBase
// Size: 0xb0 (Inherited: 0xa0)
struct UEventListenerBase : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class OnlineTestFramework.SimpleEventListener
// Size: 0xb0 (Inherited: 0xb0)
struct USimpleEventListener : UEventListenerBase {

	void OnEvent(); // Function OnlineTestFramework.SimpleEventListener.OnEvent // (Final|Native|Public) // @ game+0x52da440
};

