// Class AudioAnalyzer.AudioAnalyzerAssetBase
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioAnalyzerAssetBase : UObject {
};

// Class AudioAnalyzer.AudioAnalyzerSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioAnalyzerSettings : UAudioAnalyzerAssetBase {
};

// Class AudioAnalyzer.AudioAnalyzer
// Size: 0x100 (Inherited: 0xa0)
struct UAudioAnalyzer : UObject {
	struct UAudioBus* AudioBus; // 0x98(0x08)
	struct UAudioAnalyzerSubsystem* AudioAnalyzerSubsystem; // 0xa8(0x08)
	char pad_b0[0x50]; // 0xb0(0x50)

	void StopAnalyzing(struct UObject* WorldContextObject); // Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing // (Final|RequiredAPI|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x8d4bdd0
	void StartAnalyzing(struct UObject* WorldContextObject, struct UAudioBus* AudioBusToAnalyze); // Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing // (Final|RequiredAPI|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x8d48690
};

// Class AudioAnalyzer.AudioAnalyzerNRTSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioAnalyzerNRTSettings : UAudioAnalyzerAssetBase {
};

// Class AudioAnalyzer.AudioAnalyzerNRT
// Size: 0xf0 (Inherited: 0xa0)
struct UAudioAnalyzerNRT : UAudioAnalyzerAssetBase {
	struct USoundWave* Sound; // 0x98(0x08)
	float DurationInSeconds; // 0xa0(0x04)
	char pad_ac[0x44]; // 0xac(0x44)
};

// Class AudioAnalyzer.AudioAnalyzerSubsystem
// Size: 0xc0 (Inherited: 0xa0)
struct UAudioAnalyzerSubsystem : UEngineSubsystem {
	struct TArray<struct UAudioAnalyzer*> AudioAnalyzers; // 0xa0(0x10)
	char pad_b0[0x10]; // 0xb0(0x10)
};

