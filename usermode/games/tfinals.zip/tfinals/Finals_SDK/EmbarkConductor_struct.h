// Enum EmbarkConductor.EEmbarkConductorTickCohortFlags
enum class EEmbarkConductorTickCohortFlags : uint8_t {
	None = 0,
	ThreadSafe = 1,
	StrictOrdering = 2,
	OneShot = 4,
	EEmbarkConductorTickCohortFlags_MAX = 5
};

// ScriptStruct EmbarkConductor.EmbarkConductorTickHandle
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkConductorTickHandle {
	bool bIsValid; // 0x00(0x01)
	char pad_1[0x13]; // 0x01(0x13)
};

// ScriptStruct EmbarkConductor.EmbarkConductorRequestedTickCohort
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkConductorRequestedTickCohort {
	struct UObject* Tag; // 0x00(0x08)
	enum class EEmbarkConductorTickCohortFlags Flags; // 0x08(0x01)
	char FunctionOffset; // 0x09(0x01)
	char pad_a[0x6]; // 0x0a(0x06)
};

// ScriptStruct EmbarkConductor.EmbarkConductorRequestedTickCohorts
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkConductorRequestedTickCohorts {
	struct TArray<struct FEmbarkConductorRequestedTickCohort> Cohorts; // 0x00(0x10)
};

