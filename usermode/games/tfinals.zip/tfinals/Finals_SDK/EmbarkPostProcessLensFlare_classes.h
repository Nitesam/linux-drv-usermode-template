// Class EmbarkPostProcessLensFlare.EmbarkPostProcessLensFlareAsset
// Size: 0x200 (Inherited: 0xa0)
struct UEmbarkPostProcessLensFlareAsset : UDataAsset {
	float Intensity; // 0xa0(0x04)
	struct FLinearColor Tint; // 0xa4(0x10)
	char pad_b4[0x4]; // 0xb4(0x04)
	struct UTexture2D* Gradient; // 0xb8(0x08)
	float ThresholdLevel; // 0xc0(0x04)
	float ThresholdRange; // 0xc4(0x04)
	bool bClampIntensity; // 0xc8(0x01)
	char pad_c9[0x3]; // 0xc9(0x03)
	float MaxIntensityValue; // 0xcc(0x04)
	float GhostIntensity; // 0xd0(0x04)
	float GhostChromaShift; // 0xd4(0x04)
	struct FLensFlareGhostSettings Ghost1; // 0xd8(0x14)
	struct FLensFlareGhostSettings Ghost2; // 0xec(0x14)
	struct FLensFlareGhostSettings Ghost3; // 0x100(0x14)
	struct FLensFlareGhostSettings Ghost4; // 0x114(0x14)
	struct FLensFlareGhostSettings Ghost5; // 0x128(0x14)
	struct FLensFlareGhostSettings Ghost6; // 0x13c(0x14)
	struct FLensFlareGhostSettings Ghost7; // 0x150(0x14)
	struct FLensFlareGhostSettings Ghost8; // 0x164(0x14)
	float HaloIntensity; // 0x178(0x04)
	float HaloWidth; // 0x17c(0x04)
	float HaloMask; // 0x180(0x04)
	float HaloCompression; // 0x184(0x04)
	float HaloChromaShift; // 0x188(0x04)
	float GlareIntensity; // 0x18c(0x04)
	float GlareDivider; // 0x190(0x04)
	char pad_194[0x4]; // 0x194(0x04)
	struct FVector GlareScalesLength; // 0x198(0x18)
	struct FVector GlareScalesWidth; // 0x1b0(0x18)
	struct FVector GlareAngles; // 0x1c8(0x18)
	float GlareScreenPositionBasedAngle; // 0x1e0(0x04)
	struct FLinearColor GlareTint; // 0x1e4(0x10)
	char pad_1f4[0x4]; // 0x1f4(0x04)
	struct UTexture2D* GlareLineMask; // 0x1f8(0x08)
};

// Class EmbarkPostProcessLensFlare.EmbarkPostProcessLensFlareConfigLoaderActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct AEmbarkPostProcessLensFlareConfigLoaderActor : AActor {
	struct UEmbarkPostProcessLensFlareAsset* ConfigAsset; // 0x398(0x08)
	char pad_3a8[0x8]; // 0x3a8(0x08)
};

// Class EmbarkPostProcessLensFlare.EmbarkPostProcessLensFlareSubsystem
// Size: 0x290 (Inherited: 0xa0)
struct UEmbarkPostProcessLensFlareSubsystem : UEngineSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct FSoftObjectPath DefaultConfigAssetPath; // 0xb0(0x20)
	struct TArray<struct AEmbarkPostProcessLensFlareConfigLoaderActor*> ConfigLoaderActors; // 0xd0(0x10)
	struct UEmbarkPostProcessLensFlareAsset* DefaultConfigAsset; // 0xe0(0x08)
	char pad_e8[0x1a8]; // 0xe8(0x1a8)
};

