// Class DiscoveryGameplay.DiscoveryAmortizedReplicationBucket_Damage
// Size: 0xb0 (Inherited: 0xb0)
struct UDiscoveryAmortizedReplicationBucket_Damage : UEmbarkAmortizedReplicationConnectionSortingBucket {
};

// Class DiscoveryGameplay.DiscoveryAnimationSignificanceSystemBase
// Size: 0x4e0 (Inherited: 0x3a0)
struct ADiscoveryAnimationSignificanceSystemBase : AEmbarkGlobalActor {
	float RenderedSignificanceAdd; // 0x3a0(0x04)
	char pad_3a4[0x4]; // 0x3a4(0x04)
	struct TArray<struct FDiscoveryAnimationSignificanceDistance> DistanceRanges; // 0x3a8(0x10)
	float LookAtSignificanceAdd; // 0x3b8(0x04)
	char pad_3bc[0x4]; // 0x3bc(0x04)
	struct FVector2D LookAtRangeDeg; // 0x3c0(0x10)
	float OwningSignificanceAdd; // 0x3d0(0x04)
	char pad_3d4[0x4]; // 0x3d4(0x04)
	struct TMap<struct AActor*, float> CachedSignificancePerActor; // 0x3d8(0x50)
	struct TSet<struct USkeletalMeshComponentBudgeted*> CalculatePrerequisitedLookup; // 0x428(0x50)
	char pad_478[0x68]; // 0x478(0x68)

	void ReceiveTickDebug(float DeltaSeconds); // Function DiscoveryGameplay.DiscoveryAnimationSignificanceSystemBase.ReceiveTickDebug // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void GetTopRankComponentsByFilter(struct TArray<struct USkeletalMeshComponentBudgeted*>& FilterByComponents, struct TArray<struct USkeletalMeshComponentBudgeted*>& OutTopRankComponent, int32_t MaxNumComponentToReturn); // Function DiscoveryGameplay.DiscoveryAnimationSignificanceSystemBase.GetTopRankComponentsByFilter // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5ffa320
	float GetMaxNumEnabledClothSimulationsScaling(); // Function DiscoveryGameplay.DiscoveryAnimationSignificanceSystemBase.GetMaxNumEnabledClothSimulationsScaling // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6000370
	struct TMap<struct AActor*, float> GetCachedSignificancePerActor(); // Function DiscoveryGameplay.DiscoveryAnimationSignificanceSystemBase.GetCachedSignificancePerActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ff2930
	bool GetCachedSignificanceForActor(struct AActor* Actor, float& Significance); // Function DiscoveryGameplay.DiscoveryAnimationSignificanceSystemBase.GetCachedSignificanceForActor // (Final|Native|Public|HasOutParms|Const) // @ game+0x5ff6dc0
};

// Class DiscoveryGameplay.DiscoveryCharacterBase
// Size: 0xb50 (Inherited: 0xb30)
struct ADiscoveryCharacterBase : AEmbarkCharacterBase {
	struct UDiscoveryCharacterMovementComponent* DiscoveryCharacterMovement; // 0xb28(0x08)
	struct UEmbarkCharacterMovementSettings* CharacterMovementSettings; // 0xb30(0x08)
	struct ADiscoveryCharacterMovementGlobalActorBase* MovementSystem; // 0xb38(0x08)
	char pad_b48[0x8]; // 0xb48(0x08)

	void BlueprintSimulatePhysWalking(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintSimulatePhysWalking // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x5ff9960
	void BlueprintSimulatePhysFlying(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintSimulatePhysFlying // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x5ff72a0
	void BlueprintSimulatePhysFalling(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintSimulatePhysFalling // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x60003a0
	bool BlueprintSimulatePhysCustom(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintSimulatePhysCustom // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x5ffaaf0
	void BlueprintRecalculateBaseEyeHeight(); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintRecalculateBaseEyeHeight // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	float BlueprintGetStandingCapsuleHalfHeight(); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintGetStandingCapsuleHalfHeight // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void BlueprintGetDeltaMoveFromMovingFloor(struct FVector& ProposedMoveDelta, float DeltaSeconds, struct FVector& SafeMoveDelta); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintGetDeltaMoveFromMovingFloor // (Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x4abfe0
	float BlueprintGetCrouchingCapsuleHalfHeight(); // Function DiscoveryGameplay.DiscoveryCharacterBase.BlueprintGetCrouchingCapsuleHalfHeight // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class DiscoveryGameplay.DiscoveryCharacterMovementComponent
// Size: 0x25c0 (Inherited: 0x2100)
struct UDiscoveryCharacterMovementComponent : UEmbarkCharacterMovementComponent {
	char pad_2100[0x18]; // 0x2100(0x18)
	struct UPrimitiveComponent* CachedFloorComponentStartPhysics; // 0x2118(0x08)
	char pad_2120[0x28]; // 0x2120(0x28)
	struct FDiscoCharMovementStartPhysicsTickFunction DiscoMovementStartPhysicsTickFunction_Server; // 0x2148(0x40)
	struct FDiscoCharMovementPostPhysicsTickFunction DiscoMovementPostPhysicsTickFunction_Server; // 0x2188(0x40)
	struct UPrimitiveComponent* FloorComponent; // 0x21c8(0x08)
	struct FName FloorBoneName; // 0x21d0(0x08)
	char pad_21d8[0x8]; // 0x21d8(0x08)
	struct FEmbarkCharacterMovementBaseState ReplicatedMovementBaseState; // 0x21e0(0x3b0)
	char pad_2590[0x8]; // 0x2590(0x08)
	struct UPhysicalMaterial* FloorPhysMaterial; // 0x2598(0x08)
	struct ADiscoveryCharacterBase* DiscoveryCharacterOwner; // 0x25a0(0x08)
	struct UEmbarkCharacterMovementSettings* MovementSettings; // 0x25a8(0x08)
	char pad_25b0[0x10]; // 0x25b0(0x10)

	void SetNewFloor(struct FFindFloorResult& NewFloor); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.SetNewFloor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5ff36a0
	void OnRep_ReplicatedMovementBaseState(struct FEmbarkCharacterMovementBaseState& PrevState); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.OnRep_ReplicatedMovementBaseState // (Final|Native|Private|HasOutParms) // @ game+0x5ff6f00
	bool IsVaulting(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.IsVaulting // (Final|Native|Public|Const) // @ game+0x5ffb7d0
	bool IsJumping(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.IsJumping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ffce00
	bool IsInWater(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.IsInWater // (Final|Native|Public|Const) // @ game+0x3ee9ce0
	struct FPendulumVaultSimState GetVaultSimState(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.GetVaultSimState // (Final|Native|Public) // @ game+0x5ffcf50
	float GetTimeSinceMovementModeChange_Server(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.GetTimeSinceMovementModeChange_Server // (Final|Native|Public|Const) // @ game+0x252dab0
	struct FPendulumRootMotionState GetRootMotionState(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.GetRootMotionState // (Final|Native|Public|Const) // @ game+0x5ffa220
	struct FTransform GetFloorTransform(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.GetFloorTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ffff90
	struct UPhysicalMaterial* GetFloorPhysMaterial(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.GetFloorPhysMaterial // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ff8b20
	float BlueprintGetMinAnalogSpeed(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.BlueprintGetMinAnalogSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ffcfb0
	float BlueprintGetMaxSpeed(); // Function DiscoveryGameplay.DiscoveryCharacterMovementComponent.BlueprintGetMaxSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ff3e60
};

// Class DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase
// Size: 0x510 (Inherited: 0x3b0)
struct ADiscoveryCharacterMovementGlobalActorBase : AEmbarkCharacterMovementGlobalActorBase {
	struct FMulticastInlineDelegate PreUpdateEvent; // 0x3a8(0x10)
	struct FMulticastInlineDelegate PostUpdateEvent; // 0x3b8(0x10)
	struct UGameplayAbility* JumpAbilityClassServer; // 0x3c8(0x08)
	struct UGameplayAbility* CrouchAbilityClassServer; // 0x3d0(0x08)
	struct UGameplayAbility* CrouchAbilityClassClient; // 0x3d8(0x08)
	struct FGameplayTagContainer TagsThatCountAsGrounded; // 0x3e0(0x20)
	struct UEmbarkCharacterMovementStaticCallerBase* StaticCallerClass; // 0x400(0x08)
	struct FGameplayTag VaultingAbilityTag; // 0x408(0x08)
	struct FGameplayTag VaultingAbilityBlockedTag; // 0x410(0x08)
	char pad_420[0xd8]; // 0x420(0xd8)
	struct UEmbarkCharacterMovementStaticCallerBase* StaticCallerInstance; // 0x4f8(0x08)
	char pad_500[0x10]; // 0x500(0x10)

	void UpdateExternalCrouchState(struct AEmbarkCharacterBase* Character, struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.UpdateExternalCrouchState // (Final|Native|Public|HasOutParms) // @ game+0x5ffe2f0
	void UpdateAbilityStatesFromDynamics_Client(struct ACharacter* Character, struct FEmbarkMovementParamsDynamic& Dynamics); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.UpdateAbilityStatesFromDynamics_Client // (Final|Native|Public|HasOutParms) // @ game+0x5ff7f80
	void StopCrouchingImmediately(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.StopCrouchingImmediately // (Final|Native|Public) // @ game+0x5ff6cb0
	void StopCrouching(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.StopCrouching // (Final|Native|Public) // @ game+0x5ffc5d0
	void StartCrouchingImmediately(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.StartCrouchingImmediately // (Final|Native|Public) // @ game+0x5ffcbe0
	void StartCrouching(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.StartCrouching // (Final|Native|Public) // @ game+0x5ffcbe0
	void SetCustomTimeSinceGrounded_Server(struct ACharacter* Character, float TimeSinceGrounded); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.SetCustomTimeSinceGrounded_Server // (Final|Native|Public) // @ game+0x5fff5d0
	void RegisterControlledCharacter(struct AEmbarkCharacterBase* Character, struct AController* Controller); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.RegisterControlledCharacter // (Final|Native|Public) // @ game+0x5ffcd00
	void ReceivePostControlledCharacterUnregistered(struct AEmbarkCharacterBase* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.ReceivePostControlledCharacterUnregistered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostControlledCharacterRegistered(struct AEmbarkCharacterBase* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.ReceivePostControlledCharacterRegistered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveGetUnCrouchHeightAdjustment(struct ADiscoveryCharacterBase* Character, float StandingCapsuleHalfHeight, float& OutHeightAdjustment); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.ReceiveGetUnCrouchHeightAdjustment // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveGetCrouchHeightAdjustment(struct ADiscoveryCharacterBase* Character, float CrouchCapsuleHalfHeight, float& OutHeightAdjustment); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.ReceiveGetCrouchHeightAdjustment // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveCanMoveWithFloor(struct ACharacter* Character, struct FFindFloorResult& NewFloor); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.ReceiveCanMoveWithFloor // (Native|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x5fffaf0
	void PushCharacter_Server(struct ACharacter* Character, struct FEmbarkPushCharacterData& PushData); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.PushCharacter_Server // (Final|Native|Public|HasOutParms) // @ game+0x5fff6d0
	void JumpImmediately(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.JumpImmediately // (Final|Native|Public) // @ game+0x6000f40
	void Jump(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.Jump // (Final|Native|Public) // @ game+0x5ffb8c0
	bool IsCharacterRegisteredAsControlled(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.IsCharacterRegisteredAsControlled // (Final|Native|Public|Const) // @ game+0x6001210
	bool GetTimeSpentOnMovingFloors_Server(struct ACharacter* Character, float& OutTimeSpent); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetTimeSpentOnMovingFloors_Server // (Final|Native|Public|HasOutParms|Const) // @ game+0x5ffe1b0
	struct TArray<struct AEmbarkCharacterBase*> GetRegisteredSimulatedProxyCharacters_Client(); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetRegisteredSimulatedProxyCharacters_Client // (Final|Native|Public|Const) // @ game+0x5ff8b40
	struct TArray<struct AEmbarkCharacterBase*> GetRegisteredControlledCharacters(); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetRegisteredControlledCharacters // (Final|Native|Public|Const) // @ game+0x5ffc460
	struct FPendulumClaims GetMutablePendulumClaims_AutoBot(struct AEmbarkCharacterBase* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetMutablePendulumClaims_AutoBot // (Final|Native|Public) // @ game+0x5ff3c90
	bool GetMaxSpeed_Server(struct ACharacter* Character, float& OutMaxSpeed); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetMaxSpeed_Server // (Final|Native|Public|HasOutParms|Const) // @ game+0x5ffb690
	bool GetLatestStatics(struct ACharacter* Character, struct FEmbarkMovementParamsStatic& OutLatestStatics); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetLatestStatics // (Final|Native|Public|HasOutParms) // @ game+0x5ff23f0
	bool GetLatestJumpState(struct ACharacter* Character, struct FEmbarkJumpState& JumpState); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetLatestJumpState // (Final|Native|Public|HasOutParms|Const) // @ game+0x5ffb570
	bool GetLatestDynamics(struct ACharacter* Character, struct FEmbarkMovementParamsDynamic& OutLatestDynamics); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.GetLatestDynamics // (Final|Native|Public|HasOutParms) // @ game+0x5ff5910
	void DeactivateMovement(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.DeactivateMovement // (Final|Native|Public) // @ game+0x5ffc0e0
	void CacheSlideJumpState(struct ACharacter* Character, struct FVector& SlideJumpVelocity, float Timestamp); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.CacheSlideJumpState // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5ff43e0
	void CacheJumpState_Client(struct ACharacter* Character, struct FVector& JumpStartCharacterLocation, float JumpStartTime, float JumpStartStamina); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.CacheJumpState_Client // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5ff8440
	void BlueprintSimulateRootMotion(struct UEmbarkDataAsset* RootMotionContainer, struct FEmbarkMovementParamsStatic& Statics, struct FEmbarkMovementParamsDynamic& Dynamics); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.BlueprintSimulateRootMotion // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void BlueprintReflectDynamicsToAbilitySystem(struct AEmbarkCharacterBase* Character, struct FEmbarkMovementParamsDynamic& Dynamics); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.BlueprintReflectDynamicsToAbilitySystem // (Event|Protected|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	struct ADiscoveryWaterSystemBase* BlueprintGetWaterSystem(); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.BlueprintGetWaterSystem // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	void ActivateMovement(struct ACharacter* Character); // Function DiscoveryGameplay.DiscoveryCharacterMovementGlobalActorBase.ActivateMovement // (Final|Native|Public) // @ game+0x5ff5830
};

// Class DiscoveryGameplay.EmbarkCharacterMovementPrediction
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkCharacterMovementPrediction : UBlueprintFunctionLibrary {

	void PredictionPreMoveLogic(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.EmbarkCharacterMovementPrediction.PredictionPreMoveLogic // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ff61b0
	void PredictionPostMoveLogic(struct FEmbarkMovementParamsDynamic& Dynamics, struct FEmbarkMovementParamsStatic& Statics); // Function DiscoveryGameplay.EmbarkCharacterMovementPrediction.PredictionPostMoveLogic // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ffec00
};

// Class DiscoveryGameplay.MockDiscoveryCharacterMovementGlobalActorBase
// Size: 0x510 (Inherited: 0x510)
struct AMockDiscoveryCharacterMovementGlobalActorBase : ADiscoveryCharacterMovementGlobalActorBase {
};

// Class DiscoveryGameplay.MockDiscoveryCharacterMovementComponent
// Size: 0x25c0 (Inherited: 0x25c0)
struct UMockDiscoveryCharacterMovementComponent : UDiscoveryCharacterMovementComponent {
};

// Class DiscoveryGameplay.MockDiscoveryCharacterBase
// Size: 0xb50 (Inherited: 0xb50)
struct AMockDiscoveryCharacterBase : ADiscoveryCharacterBase {
};

// Class DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryCharacterMovementStaticCallerBase : UEmbarkCharacterMovementStaticCallerBase {
	enum class ECollisionChannel VaultableTraceChannel; // 0x98(0x01)

	void SampleRootMotion(struct UEmbarkDataAsset* RootMotionDefinitions, float CurrentTime, float DeltaTime, float CharacterScale, struct FPendulumRootMotionState& RootMotionState, struct FPendulumRootMotionSampleResult& SampleResult); // Function DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase.SampleRootMotion // (Final|Native|Public|HasOutParms|Const) // @ game+0x6014790
	bool IsComponentValidForMovement(struct UPrimitiveComponent* FloorComp, struct FName FloorBone); // Function DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase.IsComponentValidForMovement // (Final|Native|Public|Const) // @ game+0x6004570
	bool GetLinearVelocityInFloor(struct UPrimitiveComponent* FloorComp, struct FName FloorBone, struct FVector& PlayerLocation, struct FVector& OutVelocity); // Function DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase.GetLinearVelocityInFloor // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x60017f0
	void BlueprintRootMotionHandleToSequence(struct UEmbarkDataAsset* RootMotionContainer, struct FPendulumRootMotionHandle& Handle, struct FPendulumSequencePair& SequencePair); // Function DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase.BlueprintRootMotionHandleToSequence // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void BlueprintProcessPendulumClaims(struct UEmbarkDataAsset* RootMotionContainer, struct FVector& RootMotionSourceLoc, struct FRotator& RootMotionSourceRot, struct FEmbarkMovementParamsStatic& Statics, struct FEmbarkMovementParamsDynamic& Dynamics); // Function DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase.BlueprintProcessPendulumClaims // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent|Const) // @ game+0x4abfe0
	void BlueprintEndVault(struct FEmbarkMovementParamsStatic& Statics, struct FEmbarkMovementParamsDynamic& Dynamics); // Function DiscoveryGameplay.DiscoveryCharacterMovementStaticCallerBase.BlueprintEndVault // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class DiscoveryGameplay.MockDiscoveryCharacterMovementStaticCallerBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMockDiscoveryCharacterMovementStaticCallerBase : UDiscoveryCharacterMovementStaticCallerBase {
};

// Class DiscoveryGameplay.DiscoveryCheatManagerBase
// Size: 0x180 (Inherited: 0x180)
struct UDiscoveryCheatManagerBase : UEmbarkCheatManager {

	void ServerWalk(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerWalk // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6010220
	void ServerTeleport(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerTeleport // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x50bd660
	void ServerSummon(struct FString ClassName); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerSummon // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x60089f0
	void ServerSlomo(float NewTimeDilation); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerSlomo // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x600d7b0
	void ServerGod(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerGod // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6013d00
	void ServerGhost(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerGhost // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6012550
	void ServerFly(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerFly // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x600ae40
	void ServerDestroyTarget(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerDestroyTarget // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2ff11a0
	void ServerDestroyPawns(struct APawn* aClass); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerDestroyPawns // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3633ca0
	void ServerDestroyAllPawnsExceptTarget(); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerDestroyAllPawnsExceptTarget // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x36ad7d0
	void ServerDestroyAll(struct AActor* aClass); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerDestroyAll // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6003210
	void ServerDamageTarget(float DamageAmount); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerDamageTarget // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6008940
	void ServerChangeSize(float F); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.ServerChangeSize // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x6008200
	void MulticastSlomo(float NewTimeDilation); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.MulticastSlomo // (Final|Net|NetReliableNative|Event|NetMulticast|Private) // @ game+0x600d700
	struct ULevel* FindLevelByName(struct FString InLevelShortPackageName); // Function DiscoveryGameplay.DiscoveryCheatManagerBase.FindLevelByName // (Final|Native|Public) // @ game+0x600b420
};

// Class DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent
// Size: 0x840 (Inherited: 0x810)
struct UDiscoveryDematerializedFracturedDestructibleMeshComponent : UEmbarkCompositeMeshComponent {
	char pad_810[0x30]; // 0x810(0x30)

	void ShowBone(int32_t BoneIndex); // Function DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent.ShowBone // (Final|Native|Public) // @ game+0x600a8f0
	void SetTrackedComponentWithMaterial(struct UEmbarkFracturedDestructibleMeshComponent* MeshComponent, struct UMaterialInterface* Material); // Function DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent.SetTrackedComponentWithMaterial // (Final|Native|Public) // @ game+0x60030d0
	void SetCollisionProfile(struct UEmbarkFracturedDestructibleMeshComponent* Target, int32_t BoneIndex, struct FName CollisionProfile, struct FDiscoveryDematerializeCachedCollisionData& OldSimData); // Function DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent.SetCollisionProfile // (Final|Native|Static|Public|HasOutParms) // @ game+0x600cef0
	void SetCollision(struct UEmbarkFracturedDestructibleMeshComponent* Target, int32_t BoneIndex, struct FDiscoveryDematerializeCachedCollisionData& SimData); // Function DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent.SetCollision // (Final|Native|Static|Public|HasOutParms) // @ game+0x600d1e0
	void HideBone(int32_t BoneIndex); // Function DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent.HideBone // (Final|Native|Public) // @ game+0x600ce50
	void ClearTrackedComponent(); // Function DiscoveryGameplay.DiscoveryDematerializedFracturedDestructibleMeshComponent.ClearTrackedComponent // (Final|Native|Public) // @ game+0x6015170
};

// Class DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase
// Size: 0x4c0 (Inherited: 0x3a0)
struct ADiscoveryDematerializeToolReplicatorActorBase : AActor {
	struct FDematerializedFastArray DematerializedFastArray; // 0x398(0x128)

	void UpdateDematerializedItemCluster(struct UPrimitiveComponent* Component, int32_t BoneIndex, char ClusterID); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.UpdateDematerializedItemCluster // (Final|Native|Public) // @ game+0x6008090
	void RetriggerAllItemsAddedToFastArray_Client(); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.RetriggerAllItemsAddedToFastArray_Client // (Final|Native|Public) // @ game+0x6009c90
	void RemoveDematerializedItemFromFastArray_Server(struct UPrimitiveComponent* Component, int32_t BoneIndex); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.RemoveDematerializedItemFromFastArray_Server // (Final|Native|Public) // @ game+0x60090f0
	void OnDematerializeItemRemovedFromFastArray_Client(struct UPrimitiveComponent* Component, int32_t BoneIndex); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.OnDematerializeItemRemovedFromFastArray_Client // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDematerializeItemAddedToFastArray_Client(struct UPrimitiveComponent* Component, int32_t BoneIndex, struct FVector Direction); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.OnDematerializeItemAddedToFastArray_Client // (Event|Public|HasDefaults|BlueprintEvent) // @ game+0x4abfe0
	struct TArray<struct FDematerializedItem> GetDematerializedItems(); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.GetDematerializedItems // (Final|Native|Public|Const) // @ game+0x6009f10
	void AddDematerializedItemToFastArray_Server(struct UPrimitiveComponent* Component, int32_t BoneIndex, struct FVector Direction, char ClusterID); // Function DiscoveryGameplay.DiscoveryDematerializeToolReplicatorActorBase.AddDematerializedItemToFastArray_Server // (Final|Native|Public|HasDefaults) // @ game+0x60035e0
};

// Class DiscoveryGameplay.DiscoveryReplicatedDoorDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryReplicatedDoorDataMixinLibrary : UObject {

	void SetDoorActor(struct FDiscoveryReplicatedDoorData& Data, struct AActor* DoorActor); // Function DiscoveryGameplay.DiscoveryReplicatedDoorDataMixinLibrary.SetDoorActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x600c4e0
	struct AActor* GetDoorActor(struct FDiscoveryReplicatedDoorData& Data); // Function DiscoveryGameplay.DiscoveryReplicatedDoorDataMixinLibrary.GetDoorActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x6014ee0
};

// Class DiscoveryGameplay.EmbarkFastReplicatorBucketBreak
// Size: 0x540 (Inherited: 0x410)
struct AEmbarkFastReplicatorBucketBreak : AEmbarkFastReplicatorBucketFastArray {
	struct FDiscoveryFastArrayBreak BreakArray; // 0x408(0x130)
};

// Class DiscoveryGameplay.DiscoveryFastReplicatorBreak
// Size: 0x5f0 (Inherited: 0x5f0)
struct ADiscoveryFastReplicatorBreak : AEmbarkFastReplicatorCallback {

	void RegisterCallback_Client(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FDelegate Callback); // Function DiscoveryGameplay.DiscoveryFastReplicatorBreak.RegisterCallback_Client // (Final|Native|Public|HasOutParms) // @ game+0x6010ef0
};

// Class DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryReplicatedDamageDataScriptMixinLibrary : UObject {

	void SetTime(struct FDiscoveryReplicatedDamageData& DamageData, float Time); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x600a570
	void SetOrigin(struct FDiscoveryReplicatedDamageData& DamageData, struct FVector& InOrigin); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetOrigin // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x6003310
	void SetImpactPoint(struct FDiscoveryReplicatedDamageData& DamageData, struct FVector& InImpactPoint); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetImpactPoint // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x60125b0
	void SetHealth(struct FDiscoveryReplicatedDamageData& DamageData, float InMaxHealth, float InNewHealth); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetHealth // (Final|Native|Static|Public|HasOutParms) // @ game+0x6012960
	void SetDirection(struct FDiscoveryReplicatedDamageData& DamageData, struct FVector& InDirection); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetDirection // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x6009560
	void SetDamageValue(struct FDiscoveryReplicatedDamageData& DamageData, float InDamage); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetDamageValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x600bdd0
	void SetDamageType(struct FDiscoveryReplicatedDamageData& DamageData, enum class EDSMDamageType InDamageType); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetDamageType // (Final|Native|Static|Public|HasOutParms) // @ game+0x60037d0
	void SetDamage(struct FDiscoveryReplicatedDamageData& DamageData, float InDamage, enum class EDSMDamageType InDamageType); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.SetDamage // (Final|Native|Static|Public|HasOutParms) // @ game+0x6002030
	bool IsRecentTime(struct FDiscoveryReplicatedDamageData& DamageData, float CurrentTime); // Function DiscoveryGameplay.DiscoveryReplicatedDamageDataScriptMixinLibrary.IsRecentTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x600a420
};

// Class DiscoveryGameplay.EmbarkFastReplicatorBucketDamage
// Size: 0x540 (Inherited: 0x410)
struct AEmbarkFastReplicatorBucketDamage : AEmbarkFastReplicatorBucketFastArray {
	struct FDiscoveryFastArrayDamage Damages; // 0x408(0x130)
};

// Class DiscoveryGameplay.DiscoveryFastReplicatorDamage
// Size: 0x5f0 (Inherited: 0x5f0)
struct ADiscoveryFastReplicatorDamage : AEmbarkFastReplicatorCallback {

	void UpdateData_Server(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FDiscoveryReplicatedDamageData& NewDamage); // Function DiscoveryGameplay.DiscoveryFastReplicatorDamage.UpdateData_Server // (Final|Native|Public|HasOutParms) // @ game+0x6004b00
	void RegisterCallback_Client(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FDelegate Callback); // Function DiscoveryGameplay.DiscoveryFastReplicatorDamage.RegisterCallback_Client // (Final|Native|Public|HasOutParms) // @ game+0x6010ef0
};

// Class DiscoveryGameplay.EmbarkFastReplicatorBucketGravityGun
// Size: 0x540 (Inherited: 0x410)
struct AEmbarkFastReplicatorBucketGravityGun : AEmbarkFastReplicatorBucketFastArray {
	struct FDiscoveryFastArrayGravityGun DataArray; // 0x408(0x130)
};

// Class DiscoveryGameplay.DiscoveryFastReplicatorGravityGun
// Size: 0x5f0 (Inherited: 0x5f0)
struct ADiscoveryFastReplicatorGravityGun : AEmbarkFastReplicatorCallback {

	void UpdateCarriedPickupable_Server(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct UActorComponent* CarriedPickupable); // Function DiscoveryGameplay.DiscoveryFastReplicatorGravityGun.UpdateCarriedPickupable_Server // (Final|Native|Public|HasOutParms) // @ game+0x601c070
	void RegisterCallback_Client(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FDelegate Callback); // Function DiscoveryGameplay.DiscoveryFastReplicatorGravityGun.RegisterCallback_Client // (Final|Native|Public|HasOutParms) // @ game+0x6010ef0
};

// Class DiscoveryGameplay.EmbarkFastReplicatorBucketPower
// Size: 0x540 (Inherited: 0x410)
struct AEmbarkFastReplicatorBucketPower : AEmbarkFastReplicatorBucketFastArray {
	struct FDiscoveryFastReplicatorPowerArray DataArray; // 0x408(0x130)
};

// Class DiscoveryGameplay.DiscoveryFastReplicatorPower
// Size: 0x5f0 (Inherited: 0x5f0)
struct ADiscoveryFastReplicatorPower : AEmbarkFastReplicatorCallback {

	void UpdatePowerState_Server(struct FEmbarkFastReplicatorActorOrComponent& Ref, enum class EDiscoveryPowerState NewPowerState); // Function DiscoveryGameplay.DiscoveryFastReplicatorPower.UpdatePowerState_Server // (Final|Native|Public|HasOutParms) // @ game+0x6015400
	void RegisterCallback_Client(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FDelegate Callback); // Function DiscoveryGameplay.DiscoveryFastReplicatorPower.RegisterCallback_Client // (Final|Native|Public|HasOutParms) // @ game+0x6010ef0
};

// Class DiscoveryGameplay.DiscoveryFileDownloadComponent
// Size: 0x370 (Inherited: 0x310)
struct UDiscoveryFileDownloadComponent : UEmbarkFileDownloadComponent {
	char pad_310[0x60]; // 0x310(0x60)

	int32_t StartInstantReplayTransmission_Server(float StartTimeStamp, float EndTimestamp, uint64_t DebugViewTarget, bool bInIsEarlyInit, struct FGameplayAbilityTargetDataHandle& OptionalPayload); // Function DiscoveryGameplay.DiscoveryFileDownloadComponent.StartInstantReplayTransmission_Server // (Final|Native|Public|HasOutParms) // @ game+0x60201f0
	void ServerAckHasReceivedDestructionGraph(); // Function DiscoveryGameplay.DiscoveryFileDownloadComponent.ServerAckHasReceivedDestructionGraph // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x36ad7d0
	void SendDestructionGraph_Server(struct TArray<struct ULevel*>& ClientSpecificLevels); // Function DiscoveryGameplay.DiscoveryFileDownloadComponent.SendDestructionGraph_Server // (Final|Native|Public|HasOutParms) // @ game+0x6018470
};

// Class DiscoveryGameplay.DiscoveryGameplayUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryGameplayUtils : UBlueprintFunctionLibrary {

	void UnloadStreamLevelDebug(struct UObject* WorldContextObject, struct FName LevelName, struct FLatentActionInfo LatentInfo, bool bShouldBlockOnUnload); // Function DiscoveryGameplay.DiscoveryGameplayUtils.UnloadStreamLevelDebug // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6016210
	void LoadStreamLevelDebug(struct UObject* WorldContextObject, struct FName LevelName, bool bMakeVisibleAfterLoad, bool bShouldBlockOnLoad, struct FLatentActionInfo LatentInfo); // Function DiscoveryGameplay.DiscoveryGameplayUtils.LoadStreamLevelDebug // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6020b80
	double GetTimeSinceReceiveNetworkDataFromController(struct APlayerController* InController); // Function DiscoveryGameplay.DiscoveryGameplayUtils.GetTimeSinceReceiveNetworkDataFromController // (Final|Native|Static|Public) // @ game+0x6022c90
	int32_t GetCutoutScalabilityOption(); // Function DiscoveryGameplay.DiscoveryGameplayUtils.GetCutoutScalabilityOption // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6015b90
	struct FName GetBoneNameFromBodyIndex(struct UPrimitiveComponent* InPrimitiveComponent, int32_t InIndex); // Function DiscoveryGameplay.DiscoveryGameplayUtils.GetBoneNameFromBodyIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6017f10
	void ApplyDamageToDestructible(struct TArray<struct FBoneDamage>& DamagedBones, struct UActorComponent* TargetDestructible); // Function DiscoveryGameplay.DiscoveryGameplayUtils.ApplyDamageToDestructible // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6017b90
};

// Class DiscoveryGameplay.DiscoveryGameplayTelemetryUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryGameplayTelemetryUtils : UBlueprintFunctionLibrary {

	void SendThrottledFailedToActivateAbilityClient(struct UObject* WorldContextObject, struct FString Ability, struct FString FailureReason); // Function DiscoveryGameplay.DiscoveryGameplayTelemetryUtils.SendThrottledFailedToActivateAbilityClient // (Final|Native|Static|Public) // @ game+0x6016910
};

// Class DiscoveryGameplay.DiscoveryGameViewportClient
// Size: 0x710 (Inherited: 0x700)
struct UDiscoveryGameViewportClient : UGameViewportClient {
	char pad_700[0x10]; // 0x700(0x10)
};

// Class DiscoveryGameplay.DiscoveryGlobalActorFactorySubsystemBase
// Size: 0x110 (Inherited: 0x110)
struct UDiscoveryGlobalActorFactorySubsystemBase : UEmbarkGameplayGlobalActorFactorySubsystemBase {

	struct ADiscoveryFastReplicatorPower* GetPowerFastReplicator(); // Function DiscoveryGameplay.DiscoveryGlobalActorFactorySubsystemBase.GetPowerFastReplicator // (Final|Native|Public|BlueprintCallable) // @ game+0x60201c0
	struct ADiscoveryFastReplicatorGravityGun* GetGravityGunFastReplicator(); // Function DiscoveryGameplay.DiscoveryGlobalActorFactorySubsystemBase.GetGravityGunFastReplicator // (Final|Native|Public|BlueprintCallable) // @ game+0x60221d0
	struct ADiscoveryFastReplicatorDamage* GetDamageFastReplicator(); // Function DiscoveryGameplay.DiscoveryGlobalActorFactorySubsystemBase.GetDamageFastReplicator // (Final|Native|Public|BlueprintCallable) // @ game+0x6017a20
	struct ADiscoveryFastReplicatorBreak* GetBreakFastReplicator(); // Function DiscoveryGameplay.DiscoveryGlobalActorFactorySubsystemBase.GetBreakFastReplicator // (Final|Native|Public|BlueprintCallable) // @ game+0x60178c0
};

// Class DiscoveryGameplay.GooSpawnConfiguration
// Size: 0x180 (Inherited: 0xa0)
struct UGooSpawnConfiguration : UDataAsset {
	float CollisionRadius; // 0xa0(0x04)
	float AllowedPenetrationFraction; // 0xa4(0x04)
	float PenetrationSafetyMargin; // 0xa8(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
	struct TSet<struct UObject*> AvoidClasses; // 0xb0(0x50)
	struct TSet<struct TSoftClassPtr<UObject>> AvoidSoftClasses; // 0x100(0x50)
	struct UObject* GooActorClass; // 0x150(0x08)
	float CollisionGracePeriod; // 0x158(0x04)
	int32_t CollisionCountLimit; // 0x15c(0x04)
	float ContactImpulseLimit; // 0x160(0x04)
	float BadSpawnLifetime; // 0x164(0x04)
	float BadSpawnPenetrationLimit; // 0x168(0x04)
	float CritDetectionPenetrationLimit; // 0x16c(0x04)
	int32_t CritDetectionPenetrationCountLimit; // 0x170(0x04)
	float CritDetectionDotLimit; // 0x174(0x04)
	bool bCorrectCritical; // 0x178(0x01)
	char pad_179[0x3]; // 0x179(0x03)
	int32_t OverlapCheckRate; // 0x17c(0x04)
};

// Class DiscoveryGameplay.DiscoveryGooSettings
// Size: 0xd0 (Inherited: 0xb0)
struct UDiscoveryGooSettings : UDeveloperSettings {
	struct TSoftObjectPtr<UGooSpawnConfiguration> GooSettingsAsset; // 0xa8(0x28)

	struct UGooSpawnConfiguration* GetSettings(); // Function DiscoveryGameplay.DiscoveryGooSettings.GetSettings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x601a930
};

// Class DiscoveryGameplay.DiscoveryGooHelperSubsystem
// Size: 0x190 (Inherited: 0xa0)
struct UDiscoveryGooHelperSubsystem : UWorldSubsystem {
	char pad_a0[0xc8]; // 0xa0(0xc8)
	struct TArray<struct FOverlapResult> LastOverlaps; // 0x168(0x10)
	struct TArray<struct FGooPenetrationData> Depenetration; // 0x178(0x10)
	struct UGooSpawnConfiguration* SettingsAsset; // 0x188(0x08)

	void OnSettingsLoaded(); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.OnSettingsLoaded // (Final|Native|Public) // @ game+0x6015600
	bool GetStrongestPenetration(struct FVector DesiredLocation, struct FGooPenetrationData& CorrectionVector); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.GetStrongestPenetration // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x601f4c0
	struct TArray<struct FGooPenetrationData> GetLastPenetrationData(); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.GetLastPenetrationData // (Final|Native|Public|BlueprintCallable) // @ game+0x601f680
	bool GetAttachedGoo(struct AActor* BaseActor, struct TArray<struct AActor*>& OutAttachedGooActors, bool bRecursive); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.GetAttachedGoo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x601cc50
	struct TArray<struct AActor*> FindOverlappingGoo(struct FVector Center, struct FVector Extent, struct FQuat Orientation); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.FindOverlappingGoo // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6023020
	bool DetectCriticalWedge(); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.DetectCriticalWedge // (Final|Native|Public|BlueprintCallable) // @ game+0x6018970
	bool CalculateOverlaps(struct FVector Location); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.CalculateOverlaps // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x601c180
	bool CalculateCorrection(struct FVector DesiredLocation, struct FVector& CorrectionVector); // Function DiscoveryGameplay.DiscoveryGooHelperSubsystem.CalculateCorrection // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6015cc0
};

// Class DiscoveryGameplay.DiscoveryHarpoonConstraintMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryHarpoonConstraintMixinLibrary : UObject {

	void UpdateConstraint(struct FDiscoveryHarpoonConstraint& Constraint, struct FVector& AnchorWorldLocation); // Function DiscoveryGameplay.DiscoveryHarpoonConstraintMixinLibrary.UpdateConstraint // (Final|Native|Static|Private|HasOutParms|HasDefaults) // @ game+0x60206a0
	void StopConstraint(struct FDiscoveryHarpoonConstraint& Constraint); // Function DiscoveryGameplay.DiscoveryHarpoonConstraintMixinLibrary.StopConstraint // (Final|Native|Static|Private|HasOutParms) // @ game+0x60180d0
	void StartConstraint(struct FDiscoveryHarpoonConstraint& Constraint, struct UPrimitiveComponent* PulledComponent, struct FVector& AnchorWorldLocation, struct UObject* HarpoonDebugContextObj); // Function DiscoveryGameplay.DiscoveryHarpoonConstraintMixinLibrary.StartConstraint // (Final|Native|Static|Private|HasOutParms|HasDefaults) // @ game+0x6022d90
	bool IsConstraintActive(struct FDiscoveryHarpoonConstraint& Constraint); // Function DiscoveryGameplay.DiscoveryHarpoonConstraintMixinLibrary.IsConstraintActive // (Final|Native|Static|Private|HasOutParms) // @ game+0x601fff0
};

// Class DiscoveryGameplay.DiscoveryItemBalanceOverrideSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UDiscoveryItemBalanceOverrideSettings : UDeveloperSettings {
	struct FDirectoryPath FolderPath; // 0xa8(0x10)
};

// Class DiscoveryGameplay.DiscoveryLocalPlayer
// Size: 0x440 (Inherited: 0x440)
struct UDiscoveryLocalPlayer : ULocalPlayer {
};

// Class DiscoveryGameplay.DiscoveryPlayerControllerBase
// Size: 0x1090 (Inherited: 0x1070)
struct ADiscoveryPlayerControllerBase : AEmbarkReplayController {
	struct FMulticastInlineDelegate OnPlayerStateUpdated; // 0x1070(0x10)
	struct UEmbarkInputSubsystem* EmbarkInputSubsystem; // 0x1080(0x08)
	char pad_1088[0x8]; // 0x1088(0x08)
};

// Class DiscoveryGameplay.DiscoveryPlayerStateBase
// Size: 0x4c0 (Inherited: 0x4c0)
struct ADiscoveryPlayerStateBase : AEmbarkPlayerStateBase {

	int32_t GetUniqueIdHash(); // Function DiscoveryGameplay.DiscoveryPlayerStateBase.GetUniqueIdHash // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60416b0
};

// Class DiscoveryGameplay.DiscoveryReplaySpectatorController
// Size: 0x10b0 (Inherited: 0x1090)
struct ADiscoveryReplaySpectatorController : ADiscoveryPlayerControllerBase {
	enum class EDiscoveryReplayInputMode ReplayInputMode; // 0x1088(0x04)
	struct TArray<struct FUpdateLevelStreamingLevelStatus> ReplayLevelStatuses; // 0x1090(0x10)
	struct APlayerState* ReplayPlayerState; // 0x10a0(0x08)
	char pad_10ac[0x4]; // 0x10ac(0x04)

	void SetPlayerStateIsReadyForReplay(); // Function DiscoveryGameplay.DiscoveryReplaySpectatorController.SetPlayerStateIsReadyForReplay // (Final|Native|Public|BlueprintCallable) // @ game+0x603bfb0
	void OnRep_ReplayLevelStatuses(); // Function DiscoveryGameplay.DiscoveryReplaySpectatorController.OnRep_ReplayLevelStatuses // (Final|Native|Protected) // @ game+0x602dc40
	struct APlayerState* GetReplayPlayerState(); // Function DiscoveryGameplay.DiscoveryReplaySpectatorController.GetReplayPlayerState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x602e590
};

// Class DiscoveryGameplay.DiscoveryWaterSystemBase
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADiscoveryWaterSystemBase : AEmbarkGlobalActor {

	bool IsActorInWater(struct AActor* Actor); // Function DiscoveryGameplay.DiscoveryWaterSystemBase.IsActorInWater // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x603baf0
};

// Class DiscoveryGameplay.EventLogPingInfoMixin
// Size: 0xa0 (Inherited: 0xa0)
struct UEventLogPingInfoMixin : UObject {

	bool NeedsToResolveMessageParameters(struct FEventLogPingInfo& Info); // Function DiscoveryGameplay.EventLogPingInfoMixin.NeedsToResolveMessageParameters // (Final|Native|Static|Public|HasOutParms) // @ game+0x603d260
	bool IsValid(struct FEventLogPingInfo& Info); // Function DiscoveryGameplay.EventLogPingInfoMixin.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x6038210
};

