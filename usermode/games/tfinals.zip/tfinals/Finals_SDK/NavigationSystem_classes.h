// Class NavigationSystem.CrowdManagerBase
// Size: 0xa0 (Inherited: 0xa0)
struct UCrowdManagerBase : UObject {
};

// Class NavigationSystem.NavigationGraphNode
// Size: 0x3a0 (Inherited: 0x3a0)
struct ANavigationGraphNode : AActor {
};

// Class NavigationSystem.NavigationGraphNodeComponent
// Size: 0x3f0 (Inherited: 0x3c0)
struct UNavigationGraphNodeComponent : USceneComponent {
	struct FNavGraphNode Node; // 0x3c0(0x18)
	struct UNavigationGraphNodeComponent* NextNodeComponent; // 0x3d8(0x08)
	struct UNavigationGraphNodeComponent* PrevNodeComponent; // 0x3e0(0x08)
	char pad_3e8[0x8]; // 0x3e8(0x08)
};

// Class NavigationSystem.NavigationPathGenerator
// Size: 0xa0 (Inherited: 0xa0)
struct UNavigationPathGenerator : UInterface {
};

// Class NavigationSystem.NavLinkCustomInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UNavLinkCustomInterface : UInterface {
};

// Class NavigationSystem.NavLinkHostInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UNavLinkHostInterface : UInterface {
};

// Class NavigationSystem.NavLinkTrivial
// Size: 0xc0 (Inherited: 0xc0)
struct UNavLinkTrivial : UNavLinkDefinition {
};

// Class NavigationSystem.NavNodeInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UNavNodeInterface : UInterface {
};

// Class NavigationSystem.NavigationData
// Size: 0x5b0 (Inherited: 0x3a0)
struct ANavigationData : AActor {
	struct UPrimitiveComponent* RenderingComp; // 0x3a0(0x08)
	struct FNavDataConfig NavDataConfig; // 0x3a8(0x88)
	char bEnableDrawing : 1; // 0x430(0x01)
	char bForceRebuildOnLoad : 1; // 0x430(0x01)
	char bAutoDestroyWhenNoNavigation : 1; // 0x430(0x01)
	char bCanBeMainNavData : 1; // 0x430(0x01)
	char bCanSpawnOnRebuild : 1; // 0x430(0x01)
	char bRebuildAtRuntime : 1; // 0x430(0x01)
	char pad_430_6 : 2; // 0x430(0x01)
	char pad_431[0x3]; // 0x431(0x03)
	enum class ERuntimeGenerationType RuntimeGeneration; // 0x434(0x01)
	char pad_435[0x3]; // 0x435(0x03)
	float ObservedPathsTickInterval; // 0x438(0x04)
	uint32_t DataVersion; // 0x43c(0x04)
	char pad_440[0x108]; // 0x440(0x108)
	struct TArray<struct FSupportedAreaData> SupportedAreas; // 0x548(0x10)
	char pad_558[0x58]; // 0x558(0x58)
};

// Class NavigationSystem.AbstractNavData
// Size: 0x5b0 (Inherited: 0x5b0)
struct AAbstractNavData : ANavigationData {
};

// Class NavigationSystem.NavArea
// Size: 0xc0 (Inherited: 0xa0)
struct UNavArea : UNavAreaBase {
	float DefaultCost; // 0xa0(0x04)
	float FixedAreaEnteringCost; // 0xa4(0x04)
	struct FColor DrawColor; // 0xa8(0x04)
	struct FNavAgentSelector SupportedAgents; // 0xac(0x04)
	char bSupportsAgent0 : 1; // 0xb0(0x01)
	char bSupportsAgent1 : 1; // 0xb0(0x01)
	char bSupportsAgent2 : 1; // 0xb0(0x01)
	char bSupportsAgent3 : 1; // 0xb0(0x01)
	char bSupportsAgent4 : 1; // 0xb0(0x01)
	char bSupportsAgent5 : 1; // 0xb0(0x01)
	char bSupportsAgent6 : 1; // 0xb0(0x01)
	char bSupportsAgent7 : 1; // 0xb0(0x01)
	char bSupportsAgent8 : 1; // 0xb1(0x01)
	char bSupportsAgent9 : 1; // 0xb1(0x01)
	char bSupportsAgent10 : 1; // 0xb1(0x01)
	char bSupportsAgent11 : 1; // 0xb1(0x01)
	char bSupportsAgent12 : 1; // 0xb1(0x01)
	char bSupportsAgent13 : 1; // 0xb1(0x01)
	char bSupportsAgent14 : 1; // 0xb1(0x01)
	char bSupportsAgent15 : 1; // 0xb1(0x01)
	char pad_b2[0xe]; // 0xb2(0x0e)
};

// Class NavigationSystem.NavAreaMeta
// Size: 0xc0 (Inherited: 0xc0)
struct UNavAreaMeta : UNavArea {
};

// Class NavigationSystem.NavAreaMeta_SwitchByAgent
// Size: 0x140 (Inherited: 0xc0)
struct UNavAreaMeta_SwitchByAgent : UNavAreaMeta {
	struct UNavArea* Agent0Area; // 0xb8(0x08)
	struct UNavArea* Agent1Area; // 0xc0(0x08)
	struct UNavArea* Agent2Area; // 0xc8(0x08)
	struct UNavArea* Agent3Area; // 0xd0(0x08)
	struct UNavArea* Agent4Area; // 0xd8(0x08)
	struct UNavArea* Agent5Area; // 0xe0(0x08)
	struct UNavArea* Agent6Area; // 0xe8(0x08)
	struct UNavArea* Agent7Area; // 0xf0(0x08)
	struct UNavArea* Agent8Area; // 0xf8(0x08)
	struct UNavArea* Agent9Area; // 0x100(0x08)
	struct UNavArea* Agent10Area; // 0x108(0x08)
	struct UNavArea* Agent11Area; // 0x110(0x08)
	struct UNavArea* Agent12Area; // 0x118(0x08)
	struct UNavArea* Agent13Area; // 0x120(0x08)
	struct UNavArea* Agent14Area; // 0x128(0x08)
	struct UNavArea* Agent15Area; // 0x130(0x08)
};

// Class NavigationSystem.NavArea_Default
// Size: 0xc0 (Inherited: 0xc0)
struct UNavArea_Default : UNavArea {
};

// Class NavigationSystem.NavArea_LowHeight
// Size: 0xc0 (Inherited: 0xc0)
struct UNavArea_LowHeight : UNavArea {
};

// Class NavigationSystem.NavArea_Null
// Size: 0xc0 (Inherited: 0xc0)
struct UNavArea_Null : UNavArea {
};

// Class NavigationSystem.NavArea_Obstacle
// Size: 0xc0 (Inherited: 0xc0)
struct UNavArea_Obstacle : UNavArea {
};

// Class NavigationSystem.NavCollision
// Size: 0x140 (Inherited: 0xe0)
struct UNavCollision : UNavCollisionBase {
	char pad_e0[0x10]; // 0xe0(0x10)
	struct TArray<struct FNavCollisionCylinder> CylinderCollision; // 0xf0(0x10)
	struct TArray<struct FNavCollisionBox> BoxCollision; // 0x100(0x10)
	struct UNavArea* AreaClass; // 0x110(0x08)
	char bGatherConvexGeometry : 1; // 0x118(0x01)
	char bCreateOnClient : 1; // 0x118(0x01)
	char pad_118_2 : 6; // 0x118(0x01)
	char pad_119[0x27]; // 0x119(0x27)
};

// Class NavigationSystem.NavigationQueryFilter
// Size: 0xc0 (Inherited: 0xa0)
struct UNavigationQueryFilter : UObject {
	struct TArray<struct FNavigationFilterArea> Areas; // 0x98(0x10)
	struct FNavigationFilterFlags IncludeFlags; // 0xa8(0x04)
	struct FNavigationFilterFlags ExcludeFlags; // 0xac(0x04)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class NavigationSystem.RecastFilter_UseDefaultArea
// Size: 0xc0 (Inherited: 0xc0)
struct URecastFilter_UseDefaultArea : UNavigationQueryFilter {
};

// Class NavigationSystem.NavigationGraph
// Size: 0x5b0 (Inherited: 0x5b0)
struct ANavigationGraph : ANavigationData {
};

// Class NavigationSystem.NavigationInvokerComponent
// Size: 0x170 (Inherited: 0x160)
struct UNavigationInvokerComponent : UActorComponent {
	float TileGenerationRadius; // 0x158(0x04)
	float TileRemovalRadius; // 0x15c(0x04)
	struct FNavAgentSelector SupportedAgents; // 0x160(0x04)
	enum class ENavigationInvokerPriority Priority; // 0x164(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
};

// Class NavigationSystem.NavigationPath
// Size: 0x100 (Inherited: 0xa0)
struct UNavigationPath : UObject {
	struct FMulticastInlineDelegate PathUpdatedNotifier; // 0x98(0x10)
	struct TArray<struct FVector> PathPoints; // 0xa8(0x10)
	enum class ENavigationOptionFlag RecalculateOnInvalidation; // 0xb8(0x01)
	char pad_c1[0x3f]; // 0xc1(0x3f)

	bool IsValid(); // Function NavigationSystem.NavigationPath.IsValid // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e051b0
	bool IsStringPulled(); // Function NavigationSystem.NavigationPath.IsStringPulled // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3338f20
	bool IsPartial(); // Function NavigationSystem.NavigationPath.IsPartial // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e126b0
	double GetPathLength(); // Function NavigationSystem.NavigationPath.GetPathLength // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e05e50
	double GetPathCost(); // Function NavigationSystem.NavigationPath.GetPathCost // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3e01f80
	struct FString GetDebugString(); // Function NavigationSystem.NavigationPath.GetDebugString // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3df5360
	void EnableRecalculationOnInvalidation(enum class ENavigationOptionFlag DoRecalculation); // Function NavigationSystem.NavigationPath.EnableRecalculationOnInvalidation // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e1de00
	void EnableDebugDrawing(bool bShouldDrawDebugData, struct FLinearColor PathColor); // Function NavigationSystem.NavigationPath.EnableDebugDrawing // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3e14930
};

// Class NavigationSystem.NavigationSystemV1
// Size: 0x1600 (Inherited: 0xa0)
struct UNavigationSystemV1 : UNavigationSystemBase {
	struct ANavigationData* MainNavData; // 0x98(0x08)
	struct ANavigationData* AbstractNavData; // 0xa0(0x08)
	struct FName DefaultAgentName; // 0xa8(0x08)
	struct TSoftClassPtr<UObject> CrowdManagerClass; // 0xb0(0x28)
	char bAutoCreateNavigationData : 1; // 0xd8(0x01)
	char bSpawnNavDataInNavBoundsLevel : 1; // 0xd8(0x01)
	char bAllowClientSideNavigation : 1; // 0xd8(0x01)
	char bShouldDiscardSubLevelNavData : 1; // 0xd8(0x01)
	char bTickWhilePaused : 1; // 0xd8(0x01)
	char bSupportRebuilding : 1; // 0xd8(0x01)
	char bInitialBuildingLocked : 1; // 0xd8(0x01)
	char bSkipAgentHeightCheckWhenPickingNavData : 1; // 0xd9(0x01)
	int32_t GeometryExportTriangleCountWarningThreshold; // 0xdc(0x04)
	char bGenerateNavigationOnlyAroundNavigationInvokers : 1; // 0xe0(0x01)
	float ActiveTilesUpdateInterval; // 0xe4(0x04)
	enum class ENavDataGatheringModeConfig DataGatheringMode; // 0xe8(0x01)
	char pad_ea_1 : 7; // 0xea(0x01)
	char pad_eb[0x1]; // 0xeb(0x01)
	float DirtyAreaWarningSizeThreshold; // 0xec(0x04)
	float GatheringNavModifiersWarningLimitTime; // 0xf0(0x04)
	char pad_f4[0x4]; // 0xf4(0x04)
	struct TArray<struct FNavDataConfig> SupportedAgents; // 0xf8(0x10)
	struct FNavAgentSelector SupportedAgentsMask; // 0x108(0x04)
	char pad_10c[0x4]; // 0x10c(0x04)
	struct FBox BuildBounds; // 0x110(0x38)
	struct TArray<struct ANavigationData*> NavDataSet; // 0x148(0x10)
	struct TArray<struct ANavigationData*> NavDataRegistrationQueue; // 0x158(0x10)
	char pad_168[0x10]; // 0x168(0x10)
	struct FMulticastInlineDelegate OnNavDataRegisteredEvent; // 0x178(0x10)
	struct FMulticastInlineDelegate OnNavigationGenerationFinishedDelegate; // 0x188(0x10)
	char pad_198[0xe0]; // 0x198(0xe0)
	enum class FNavigationSystemRunMode OperationMode; // 0x278(0x01)
	char pad_279[0x1387]; // 0x279(0x1387)

	void UnregisterNavigationInvoker(struct AActor* Invoker); // Function NavigationSystem.NavigationSystemV1.UnregisterNavigationInvoker // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e03f50
	void SetMaxSimultaneousTileGenerationJobsCount(int32_t MaxNumberOfJobs); // Function NavigationSystem.NavigationSystemV1.SetMaxSimultaneousTileGenerationJobsCount // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e2caa0
	void SetGeometryGatheringMode(enum class ENavDataGatheringModeConfig NewMode); // Function NavigationSystem.NavigationSystemV1.SetGeometryGatheringMode // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e0e340
	void ResetMaxSimultaneousTileGenerationJobsCount(); // Function NavigationSystem.NavigationSystemV1.ResetMaxSimultaneousTileGenerationJobsCount // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e2a470
	void RegisterNavigationInvoker(struct AActor* Invoker, float TileGenerationRadius, float TileRemovalRadius); // Function NavigationSystem.NavigationSystemV1.RegisterNavigationInvoker // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e1c570
	void OnNavigationBoundsUpdated(struct ANavMeshBoundsVolume* NavVolume); // Function NavigationSystem.NavigationSystemV1.OnNavigationBoundsUpdated // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e12f80
	bool NavigationRaycast(struct UObject* WorldContextObject, struct FVector& RayStart, struct FVector& RayEnd, struct FVector& HitLocation, struct UNavigationQueryFilter* FilterClass, struct AController* Querier); // Function NavigationSystem.NavigationSystemV1.NavigationRaycast // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3dfe400
	bool K2_ReplaceAreaInOctreeData(struct UObject* Object, struct UNavArea* OldArea, struct UNavArea* NewArea); // Function NavigationSystem.NavigationSystemV1.K2_ReplaceAreaInOctreeData // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e13cc0
	bool K2_ProjectPointToNavigation(struct UObject* WorldContextObject, struct FVector& Point, struct FVector& ProjectedLocation, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass, struct FVector QueryExtent); // Function NavigationSystem.NavigationSystemV1.K2_ProjectPointToNavigation // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3df6840
	bool K2_GetRandomReachablePointInRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.K2_GetRandomReachablePointInRadius // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3e130f0
	bool K2_GetRandomPointInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.K2_GetRandomPointInNavigableRadius // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3e0fb10
	bool K2_GetRandomLocationInNavigableRadius(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.K2_GetRandomLocationInNavigableRadius // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3e0fb10
	bool IsNavigationBeingBuiltOrLocked(struct UObject* WorldContextObject); // Function NavigationSystem.NavigationSystemV1.IsNavigationBeingBuiltOrLocked // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3e2d670
	bool IsNavigationBeingBuilt(struct UObject* WorldContextObject); // Function NavigationSystem.NavigationSystemV1.IsNavigationBeingBuilt // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3e18080
	bool GetRandomLocationInNavigableCyliner(struct UObject* WorldContextObject, struct FVector& Origin, struct FVector& RandomLocation, float Radius, float HalfHeight, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.GetRandomLocationInNavigableCyliner // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3e0ebf0
	enum class ENavigationQueryResult GetPathLength(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, double& PathLength, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.GetPathLength // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3e27ae0
	enum class ENavigationQueryResult GetPathCost(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, double& PathCost, struct ANavigationData* NavData, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.GetPathCost // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3e16e30
	struct UNavigationSystemV1* GetNavigationSystem(struct UObject* WorldContextObject); // Function NavigationSystem.NavigationSystemV1.GetNavigationSystem // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x3e077a0
	struct UNavigationPath* FindPathToLocationSynchronously(struct UObject* WorldContextObject, struct FVector& PathStart, struct FVector& PathEnd, struct AActor* PathfindingContext, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.FindPathToLocationSynchronously // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3e261b0
	struct UNavigationPath* FindPathToActorSynchronously(struct UObject* WorldContextObject, struct FVector& PathStart, struct AActor* GoalActor, float TetherDistance, struct AActor* PathfindingContext, struct UNavigationQueryFilter* FilterClass); // Function NavigationSystem.NavigationSystemV1.FindPathToActorSynchronously // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x3e00840
};

// Class NavigationSystem.NavigationSystemModuleConfig
// Size: 0xd0 (Inherited: 0xd0)
struct UNavigationSystemModuleConfig : UNavigationSystemConfig {
	char bStrictlyStatic : 1; // 0xc8(0x01)
	char bCreateOnClient : 1; // 0xc8(0x01)
	char bAutoSpawnMissingNavData : 1; // 0xc8(0x01)
	char bSpawnNavDataInNavBoundsLevel : 1; // 0xc8(0x01)
};

// Class NavigationSystem.NavigationTestingActor
// Size: 0x4c0 (Inherited: 0x3a0)
struct ANavigationTestingActor : AActor {
	char pad_3a0[0x8]; // 0x3a0(0x08)
	struct UCapsuleComponent* CapsuleComponent; // 0x3a8(0x08)
	struct UNavigationInvokerComponent* InvokerComponent; // 0x3b0(0x08)
	char bActAsNavigationInvoker : 1; // 0x3b8(0x01)
	char pad_3b8_1 : 7; // 0x3b8(0x01)
	char pad_3b9[0x7]; // 0x3b9(0x07)
	struct FNavAgentProperties NavAgentProps; // 0x3c0(0x38)
	struct FVector QueryingExtent; // 0x3f8(0x18)
	struct ANavigationData* MyNavData; // 0x410(0x08)
	struct FVector ProjectedLocation; // 0x418(0x18)
	char bProjectedLocationValid : 1; // 0x430(0x01)
	char bSearchStart : 1; // 0x430(0x01)
	char pad_430_2 : 6; // 0x430(0x01)
	char pad_431[0x3]; // 0x431(0x03)
	float CostLimitFactor; // 0x434(0x04)
	float MinimumCostLimit; // 0x438(0x04)
	char bBacktracking : 1; // 0x43c(0x01)
	char bUseHierarchicalPathfinding : 1; // 0x43c(0x01)
	char bGatherDetailedInfo : 1; // 0x43c(0x01)
	char bRequireNavigableEndLocation : 1; // 0x43c(0x01)
	char bDrawDistanceToWall : 1; // 0x43c(0x01)
	char bShowNodePool : 1; // 0x43c(0x01)
	char bShowBestPath : 1; // 0x43c(0x01)
	char bShowDiffWithPreviousStep : 1; // 0x43c(0x01)
	char bShouldBeVisibleInGame : 1; // 0x43d(0x01)
	char pad_43d_1 : 7; // 0x43d(0x01)
	char pad_43e[0x2]; // 0x43e(0x02)
	enum class ENavCostDisplay CostDisplayMode; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct FVector2D TextCanvasOffset; // 0x448(0x10)
	char bPathExist : 1; // 0x458(0x01)
	char bPathIsPartial : 1; // 0x458(0x01)
	char bPathSearchOutOfNodes : 1; // 0x458(0x01)
	char pad_458_3 : 5; // 0x458(0x01)
	char pad_459[0x3]; // 0x459(0x03)
	float PathfindingTime; // 0x45c(0x04)
	double PathCost; // 0x460(0x08)
	int32_t PathfindingSteps; // 0x468(0x04)
	char pad_46c[0x4]; // 0x46c(0x04)
	struct ANavigationTestingActor* OtherActor; // 0x470(0x08)
	struct UNavigationQueryFilter* FilterClass; // 0x478(0x08)
	int32_t ShowStepIndex; // 0x480(0x04)
	float OffsetFromCornersDistance; // 0x484(0x04)
	char pad_488[0x38]; // 0x488(0x38)
};

// Class NavigationSystem.NavLinkComponent
// Size: 0x6d0 (Inherited: 0x6c0)
struct UNavLinkComponent : UPrimitiveComponent {
	struct TArray<struct FNavigationLink> Links; // 0x6c0(0x10)
};

// Class NavigationSystem.NavRelevantComponent
// Size: 0x1b0 (Inherited: 0x160)
struct UNavRelevantComponent : UActorComponent {
	char pad_160[0x38]; // 0x160(0x38)
	char bAttachToOwnersRoot : 1; // 0x198(0x01)
	char pad_198_1 : 7; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
	struct UObject* CachedNavParent; // 0x1a0(0x08)
	char pad_1a8[0x8]; // 0x1a8(0x08)

	void SetNavigationRelevancy(bool bRelevant); // Function NavigationSystem.NavRelevantComponent.SetNavigationRelevancy // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e7ce00
};

// Class NavigationSystem.NavLinkCustomComponent
// Size: 0x2a0 (Inherited: 0x1b0)
struct UNavLinkCustomComponent : UNavRelevantComponent {
	uint32_t NavLinkUserId; // 0x1b0(0x04)
	char pad_1b4[0x4]; // 0x1b4(0x04)
	struct FNavLinkId CustomLinkId; // 0x1b8(0x08)
	struct FNavLinkAuxiliaryId AuxiliaryCustomLinkId; // 0x1c0(0x08)
	struct UNavArea* EnabledAreaClass; // 0x1c8(0x08)
	struct UNavArea* DisabledAreaClass; // 0x1d0(0x08)
	struct FNavAgentSelector SupportedAgents; // 0x1d8(0x04)
	char pad_1dc[0x4]; // 0x1dc(0x04)
	struct FVector LinkRelativeStart; // 0x1e0(0x18)
	struct FVector LinkRelativeEnd; // 0x1f8(0x18)
	enum class ENavLinkDirection LinkDirection; // 0x210(0x01)
	char pad_211[0x3]; // 0x211(0x03)
	char bLinkEnabled : 1; // 0x214(0x01)
	char bNotifyWhenEnabled : 1; // 0x214(0x01)
	char bNotifyWhenDisabled : 1; // 0x214(0x01)
	char bCreateBoxObstacle : 1; // 0x214(0x01)
	char pad_214_4 : 4; // 0x214(0x01)
	char pad_215[0x3]; // 0x215(0x03)
	struct FVector ObstacleOffset; // 0x218(0x18)
	struct FVector ObstacleExtent; // 0x230(0x18)
	struct UNavArea* ObstacleAreaClass; // 0x248(0x08)
	float BroadcastRadius; // 0x250(0x04)
	float BroadcastInterval; // 0x254(0x04)
	enum class ECollisionChannel BroadcastChannel; // 0x258(0x01)
	char pad_259[0x47]; // 0x259(0x47)
};

// Class NavigationSystem.NavLinkRenderingComponent
// Size: 0x6c0 (Inherited: 0x6c0)
struct UNavLinkRenderingComponent : UPrimitiveComponent {
};

// Class NavigationSystem.NavMeshBoundsVolume
// Size: 0x3e0 (Inherited: 0x3d0)
struct ANavMeshBoundsVolume : AVolume {
	struct FNavAgentSelector SupportedAgents; // 0x3d0(0x04)
	char pad_3d4[0xc]; // 0x3d4(0x0c)
};

// Class NavigationSystem.NavMeshRenderingComponent
// Size: 0x720 (Inherited: 0x710)
struct UNavMeshRenderingComponent : UDebugDrawComponent {
	char pad_710[0x10]; // 0x710(0x10)
};

// Class NavigationSystem.NavTestRenderingComponent
// Size: 0x710 (Inherited: 0x710)
struct UNavTestRenderingComponent : UDebugDrawComponent {
};

// Class NavigationSystem.RecastNavMesh
// Size: 0x6d0 (Inherited: 0x5b0)
struct ARecastNavMesh : ANavigationData {
	char bDrawTriangleEdges : 1; // 0x5b0(0x01)
	char bDrawPolyEdges : 1; // 0x5b0(0x01)
	char bDrawFilledPolys : 1; // 0x5b0(0x01)
	char bDrawNavMeshEdges : 1; // 0x5b0(0x01)
	char bDrawTileBounds : 1; // 0x5b0(0x01)
	char bDrawTileResolutions : 1; // 0x5b0(0x01)
	char bDrawPathCollidingGeometry : 1; // 0x5b0(0x01)
	char bDrawTileLabels : 1; // 0x5b0(0x01)
	char bDrawTileBuildTimes : 1; // 0x5b1(0x01)
	char bDrawTileBuildTimesHeatMap : 1; // 0x5b1(0x01)
	char bDrawPolygonLabels : 1; // 0x5b1(0x01)
	char bDrawDefaultPolygonCost : 1; // 0x5b1(0x01)
	char bDrawPolygonFlags : 1; // 0x5b1(0x01)
	char bDrawLabelsOnPathNodes : 1; // 0x5b1(0x01)
	char bDrawNavLinks : 1; // 0x5b1(0x01)
	char bDrawFailedNavLinks : 1; // 0x5b1(0x01)
	char bDrawClusters : 1; // 0x5b2(0x01)
	char bDrawOctree : 1; // 0x5b2(0x01)
	char bDrawOctreeDetails : 1; // 0x5b2(0x01)
	char bDrawMarkedForbiddenPolys : 1; // 0x5b2(0x01)
	char bDistinctlyDrawTilesBeingBuilt : 1; // 0x5b2(0x01)
	char pad_5b2_5 : 3; // 0x5b2(0x01)
	char pad_5b3[0x1]; // 0x5b3(0x01)
	float DrawOffset; // 0x5b4(0x04)
	struct FRecastNavMeshTileGenerationDebug TileGenerationDebug; // 0x5b8(0x1c)
	char bFixedTilePoolSize : 1; // 0x5d4(0x01)
	char pad_5d4_1 : 7; // 0x5d4(0x01)
	char pad_5d5[0x3]; // 0x5d5(0x03)
	int32_t TilePoolSize; // 0x5d8(0x04)
	float TileSizeUU; // 0x5dc(0x04)
	float CellSize; // 0x5e0(0x04)
	float CellHeight; // 0x5e4(0x04)
	struct FNavMeshResolutionParam NavMeshResolutionParams[0x3]; // 0x5e8(0x24)
	float AgentRadius; // 0x60c(0x04)
	float AgentHeight; // 0x610(0x04)
	float AgentMaxSlope; // 0x614(0x04)
	float AgentMaxStepHeight; // 0x618(0x04)
	float MinRegionArea; // 0x61c(0x04)
	float MergeRegionSize; // 0x620(0x04)
	float MaxSimplificationError; // 0x624(0x04)
	int32_t MaxSimultaneousTileGenerationJobsCount; // 0x628(0x04)
	int32_t TileNumberHardLimit; // 0x62c(0x04)
	int32_t PolyRefTileBits; // 0x630(0x04)
	int32_t PolyRefNavPolyBits; // 0x634(0x04)
	int32_t PolyRefSaltBits; // 0x638(0x04)
	char pad_63c[0x4]; // 0x63c(0x04)
	struct FVector NavMeshOriginOffset; // 0x640(0x18)
	float DefaultDrawDistance; // 0x658(0x04)
	float DefaultMaxSearchNodes; // 0x65c(0x04)
	float DefaultMaxHierarchicalSearchNodes; // 0x660(0x04)
	enum class ERecastPartitioning RegionPartitioning; // 0x664(0x01)
	enum class ERecastPartitioning LayerPartitioning; // 0x665(0x01)
	char pad_666[0x2]; // 0x666(0x02)
	int32_t RegionChunkSplits; // 0x668(0x04)
	int32_t LayerChunkSplits; // 0x66c(0x04)
	char bSortNavigationAreasByCost : 1; // 0x670(0x01)
	char bIsWorldPartitioned : 1; // 0x670(0x01)
	char bPerformVoxelFiltering : 1; // 0x670(0x01)
	char bMarkLowHeightAreas : 1; // 0x670(0x01)
	char bUseExtraTopCellWhenMarkingAreas : 1; // 0x670(0x01)
	char bFilterLowSpanSequences : 1; // 0x670(0x01)
	char bFilterLowSpanFromTileCache : 1; // 0x670(0x01)
	char bDoFullyAsyncNavDataGathering : 1; // 0x670(0x01)
	char bUseBetterOffsetsFromCorners : 1; // 0x671(0x01)
	char bStoreEmptyTileLayers : 1; // 0x671(0x01)
	char bUseVirtualFilters : 1; // 0x671(0x01)
	char bUseVirtualGeometryFilteringAndDirtying : 1; // 0x671(0x01)
	char bAllowNavLinkAsPathEnd : 1; // 0x671(0x01)
	char pad_671_5 : 3; // 0x671(0x01)
	char pad_672[0x2]; // 0x672(0x02)
	int32_t TimeSliceFilterLedgeSpansMaxYProcess; // 0x674(0x04)
	double TimeSliceLongDurationDebug; // 0x678(0x08)
	uint32_t InvokerTilePriorityBumpDistanceThresholdInTileUnits; // 0x680(0x04)
	char InvokerTilePriorityBumpIncrease; // 0x684(0x01)
	char pad_685[0x3]; // 0x685(0x03)
	char bUseVoxelCache : 1; // 0x688(0x01)
	char pad_688_1 : 7; // 0x688(0x01)
	char pad_689[0x3]; // 0x689(0x03)
	float TileSetUpdateInterval; // 0x68c(0x04)
	float HeuristicScale; // 0x690(0x04)
	float VerticalDeviationFromGroundCompensation; // 0x694(0x04)
	char pad_698[0x38]; // 0x698(0x38)

	bool K2_ReplaceAreaInTileBounds(struct FBox Bounds, struct UNavArea* OldArea, struct UNavArea* NewArea, bool ReplaceLinks); // Function NavigationSystem.RecastNavMesh.K2_ReplaceAreaInTileBounds // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3e332d0
};

// Class NavigationSystem.RecastNavMeshDataChunk
// Size: 0xb0 (Inherited: 0xa0)
struct URecastNavMeshDataChunk : UNavigationDataChunk {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class NavigationSystem.NavModifierComponent
// Size: 0x250 (Inherited: 0x1b0)
struct UNavModifierComponent : UNavRelevantComponent {
	struct UNavArea* AreaClass; // 0x1a8(0x08)
	struct FVector FailsafeExtent; // 0x1b0(0x18)
	enum class ENavigationDataResolution NavMeshResolution; // 0x1c8(0x01)
	char bIncludeAgentHeight : 1; // 0x1c9(0x01)
	char pad_1d1_1 : 7; // 0x1d1(0x01)
	char pad_1d2[0x7e]; // 0x1d2(0x7e)

	void SetAreaClass(struct UNavArea* NewAreaClass); // Function NavigationSystem.NavModifierComponent.SetAreaClass // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e69740
};

// Class NavigationSystem.NavModifierVolume
// Size: 0x3f0 (Inherited: 0x3d0)
struct ANavModifierVolume : AVolume {
	char pad_3d0[0x8]; // 0x3d0(0x08)
	struct UNavArea* AreaClass; // 0x3d8(0x08)
	bool bMaskFillCollisionUnderneathForNavmesh; // 0x3e0(0x01)
	enum class ENavigationDataResolution NavMeshResolution; // 0x3e1(0x01)
	char pad_3e2[0xe]; // 0x3e2(0x0e)

	void SetAreaClass(struct UNavArea* NewAreaClass); // Function NavigationSystem.NavModifierVolume.SetAreaClass // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x3e63910
};

// Class NavigationSystem.NavSystemConfigOverride
// Size: 0x3b0 (Inherited: 0x3a0)
struct ANavSystemConfigOverride : AActor {
	struct UNavigationSystemConfig* NavigationSystemConfig; // 0x398(0x08)
	enum class ENavSystemOverridePolicy OverridePolicy; // 0x3a0(0x01)
	char bLoadOnClient : 1; // 0x3a1(0x01)
	char pad_3a9_1 : 7; // 0x3a9(0x01)
	char pad_3aa[0x6]; // 0x3aa(0x06)
};

