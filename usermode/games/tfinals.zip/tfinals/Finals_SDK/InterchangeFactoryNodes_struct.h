// Enum InterchangeFactoryNodes.EInterchangeSkeletalMeshContentType
enum class EInterchangeSkeletalMeshContentType : uint8_t {
	All = 0,
	Geometry = 1,
	SkinningWeights = 2,
	MAX = 3
};

