// Class MetasoundFrontend.MetaSoundDocumentInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMetaSoundDocumentInterface : UInterface {
};

// Class MetasoundFrontend.MetasoundParameterPack
// Size: 0xb0 (Inherited: 0xa0)
struct UMetasoundParameterPack : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)

	enum class ESetParamResult SetTrigger(struct FName ParameterName, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetTrigger // (Final|Native|Public|BlueprintCallable) // @ game+0x617d020
	enum class ESetParamResult SetString(struct FName ParameterName, struct FString InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetString // (Final|Native|Public|BlueprintCallable) // @ game+0x6173470
	enum class ESetParamResult SetInt(struct FName ParameterName, int32_t InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetInt // (Final|Native|Public|BlueprintCallable) // @ game+0x619b8d0
	enum class ESetParamResult SetFloat(struct FName ParameterName, float InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x61acca0
	enum class ESetParamResult SetBool(struct FName ParameterName, bool InValue, bool OnlyIfExists); // Function MetasoundFrontend.MetasoundParameterPack.SetBool // (Final|Native|Public|BlueprintCallable) // @ game+0x6174980
	struct UMetasoundParameterPack* MakeMetasoundParameterPack(); // Function MetasoundFrontend.MetasoundParameterPack.MakeMetasoundParameterPack // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x61ad750
	bool HasTrigger(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasTrigger // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x616b430
	bool HasString(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x616bee0
	bool HasInt(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasInt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x61a7320
	bool HasFloat(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x617f9e0
	bool HasBool(struct FName ParameterName); // Function MetasoundFrontend.MetasoundParameterPack.HasBool // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x61ac8e0
	bool GetTrigger(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetTrigger // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6171ff0
	struct FString GetString(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetString // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x618ac00
	int32_t GetInt(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6189e10
	float GetFloat(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x617c9e0
	bool GetBool(struct FName ParameterName, enum class ESetParamResult& Result); // Function MetasoundFrontend.MetasoundParameterPack.GetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x618b3c0
};

// Class MetasoundFrontend.MetaSoundBuilderDocument
// Size: 0x270 (Inherited: 0xa0)
struct UMetaSoundBuilderDocument : UObject {
	struct FMetasoundFrontendDocument Document; // 0xa0(0x1c8)
	ClassPtrProperty MetaSoundUClass; // 0x268(0x08)
};

