// Enum MLLocomotion.EMLVisionSamplingType
enum class EMLVisionSamplingType : uint8_t {
	Linear = 0,
	Custom = 1,
	EMLVisionSamplingType_MAX = 2
};

// ScriptStruct MLLocomotion.MLObsDebugReplication
// Size: 0x18 (Inherited: 0x00)
struct FMLObsDebugReplication {
	char ReplicationKey; // 0x00(0x01)
	char pad_1[0x17]; // 0x01(0x17)
};

// ScriptStruct MLLocomotion.VisionChannel
// Size: 0x30 (Inherited: 0x00)
struct FVisionChannel {
	struct TArray<struct FVector> Points; // 0x00(0x10)
	struct TArray<float> Values; // 0x10(0x10)
	struct FName Channel; // 0x20(0x08)
	float FillValue; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
};

// ScriptStruct MLLocomotion.MLVisionDebug
// Size: 0x88 (Inherited: 0x00)
struct FMLVisionDebug {
	char Points; // 0x00(0x01)
	char pad_1[0x37]; // 0x01(0x37)
	struct FVector_NetQuantize100 GridOrigin; // 0x38(0x18)
	struct FVector_NetQuantize100 StepSide; // 0x50(0x18)
	struct FVector_NetQuantize100 StepUp; // 0x68(0x18)
	bool bIsDirty; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
};

