// Class HoudiniEngineRuntime.HoudiniAsset
// Size: 0xc0 (Inherited: 0xa0)
struct UHoudiniAsset : UObject {
	struct FString AssetFileName; // 0x98(0x10)
	struct TArray<char> AssetBytes; // 0xa8(0x10)
	uint32_t AssetBytesCount; // 0xb8(0x04)
	bool bAssetLimitedCommercial; // 0xbc(0x01)
	bool bAssetNonCommercial; // 0xbd(0x01)
	bool bAssetExpanded; // 0xbe(0x01)
};

// Class HoudiniEngineRuntime.HoudiniAssetActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AHoudiniAssetActor : AActor {
	struct UHoudiniAssetComponent* HoudiniAssetComponent; // 0x398(0x08)
};

// Class HoudiniEngineRuntime.HoudiniAssetComponent
// Size: 0xc20 (Inherited: 0x6c0)
struct UHoudiniAssetComponent : UPrimitiveComponent {
	struct UHoudiniAsset* HoudiniAsset; // 0x6c0(0x08)
	bool bCookOnParameterChange; // 0x6c8(0x01)
	bool bUploadTransformsToHoudiniEngine; // 0x6c9(0x01)
	bool bCookOnTransformChange; // 0x6ca(0x01)
	bool bCookOnAssetInputCook; // 0x6cb(0x01)
	bool bOutputless; // 0x6cc(0x01)
	bool bOutputTemplateGeos; // 0x6cd(0x01)
	bool bUseOutputNodes; // 0x6ce(0x01)
	char pad_6cf[0x1]; // 0x6cf(0x01)
	struct FDirectoryPath TemporaryCookFolder; // 0x6d0(0x10)
	struct FDirectoryPath BakeFolder; // 0x6e0(0x10)
	bool bSplitMeshSupport; // 0x6f0(0x01)
	char pad_6f1[0x7]; // 0x6f1(0x07)
	struct FHoudiniStaticMeshGenerationProperties StaticMeshGenerationProperties; // 0x6f8(0x1e0)
	struct FMeshBuildSettings StaticMeshBuildSettings; // 0x8d8(0x48)
	bool bOverrideGlobalProxyStaticMeshSettings; // 0x920(0x01)
	bool bEnableProxyStaticMeshOverride; // 0x921(0x01)
	bool bEnableProxyStaticMeshRefinementByTimerOverride; // 0x922(0x01)
	char pad_923[0x1]; // 0x923(0x01)
	float ProxyMeshAutoRefineTimeoutSecondsOverride; // 0x924(0x04)
	bool bEnableProxyStaticMeshRefinementOnPreSaveWorldOverride; // 0x928(0x01)
	bool bEnableProxyStaticMeshRefinementOnPreBeginPIEOverride; // 0x929(0x01)
	char pad_92a[0x2]; // 0x92a(0x02)
	int32_t AssetId; // 0x92c(0x04)
	struct TArray<int32_t> NodeIdsToCook; // 0x930(0x10)
	struct TMap<int32_t, int32_t> OutputNodeCookCounts; // 0x940(0x50)
	struct TSet<struct UHoudiniAssetComponent*> DownstreamHoudiniAssets; // 0x990(0x50)
	struct FGuid ComponentGUID; // 0x9e0(0x10)
	struct FGuid HapiGUID; // 0x9f0(0x10)
	struct FString HapiAssetName; // 0xa00(0x10)
	enum class EHoudiniAssetState AssetState; // 0xa10(0x01)
	enum class EHoudiniAssetState DebugLastAssetState; // 0xa11(0x01)
	enum class EHoudiniAssetStateResult AssetStateResult; // 0xa12(0x01)
	char pad_a13[0xd]; // 0xa13(0x0d)
	struct FTransform LastComponentTransform; // 0xa20(0x60)
	uint32_t SubAssetIndex; // 0xa80(0x04)
	int32_t AssetCookCount; // 0xa84(0x04)
	bool bHasBeenLoaded; // 0xa88(0x01)
	bool bHasBeenDuplicated; // 0xa89(0x01)
	bool bPendingDelete; // 0xa8a(0x01)
	bool bRecookRequested; // 0xa8b(0x01)
	bool bRebuildRequested; // 0xa8c(0x01)
	bool bEnableCooking; // 0xa8d(0x01)
	bool bForceNeedUpdate; // 0xa8e(0x01)
	bool bLastCookSuccess; // 0xa8f(0x01)
	bool bParameterDefinitionUpdateNeeded; // 0xa90(0x01)
	bool bBlueprintStructureModified; // 0xa91(0x01)
	bool bBlueprintModified; // 0xa92(0x01)
	char pad_a93[0x5]; // 0xa93(0x05)
	struct TArray<struct UHoudiniParameter*> Parameters; // 0xa98(0x10)
	struct TArray<struct UHoudiniInput*> Inputs; // 0xaa8(0x10)
	struct TArray<struct UHoudiniOutput*> Outputs; // 0xab8(0x10)
	struct TArray<struct FHoudiniBakedOutput> BakedOutputs; // 0xac8(0x10)
	struct TArray<struct TWeakObjectPtr<struct AActor>> UntrackedOutputs; // 0xad8(0x10)
	struct TArray<struct UHoudiniHandleComponent*> HandleComponents; // 0xae8(0x10)
	bool bHasComponentTransformChanged; // 0xaf8(0x01)
	bool bFullyLoaded; // 0xaf9(0x01)
	char pad_afa[0x6]; // 0xafa(0x06)
	struct UHoudiniPDGAssetLink* PDGAssetLink; // 0xb00(0x08)
	struct FTimerHandle RefineMeshesTimer; // 0xb08(0x08)
	char pad_b10[0x18]; // 0xb10(0x18)
	bool bNoProxyMeshNextCookRequested; // 0xb28(0x01)
	enum class EHoudiniBakeAfterNextCook BakeAfterNextCook; // 0xb29(0x01)
	char pad_b2a[0xae]; // 0xb2a(0xae)
	bool bCachedIsPreview; // 0xbd8(0x01)
	char pad_bd9[0x7]; // 0xbd9(0x07)
	double LastTickTime; // 0xbe0(0x08)
	double LastLiveSyncPingTime; // 0xbe8(0x08)
	char pad_bf0[0x30]; // 0xbf0(0x30)
};

// Class HoudiniEngineRuntime.HoudiniAssetBlueprintComponent
// Size: 0xd10 (Inherited: 0xc20)
struct UHoudiniAssetBlueprintComponent : UHoudiniAssetComponent {
	char pad_c20[0x40]; // 0xc20(0x40)
	bool FauxBPProperty; // 0xc60(0x01)
	bool bHoudiniAssetChanged; // 0xc61(0x01)
	bool bUpdatedFromTemplate; // 0xc62(0x01)
	bool bIsInBlueprintEditor; // 0xc63(0x01)
	bool bCanDeleteHoudiniNodes; // 0xc64(0x01)
	bool bHasRegisteredComponentTemplate; // 0xc65(0x01)
	char pad_c66[0xa]; // 0xc66(0x0a)
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FGuid> CachedOutputNodes; // 0xc70(0x50)
	struct TMap<struct FGuid, struct FGuid> CachedInputNodes; // 0xcc0(0x50)

	void SetToggleValueAt(struct FString Name, bool Value, int32_t Index); // Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.SetToggleValueAt // (Final|Native|Public|BlueprintCallable) // @ game+0x9c7b780
	void SetFloatParameter(struct FString Name, float Value, int32_t Index); // Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.SetFloatParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x9c76b50
	bool HasParameter(struct FString Name); // Function HoudiniEngineRuntime.HoudiniAssetBlueprintComponent.HasParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x9c77a20
};

// Class HoudiniEngineRuntime.HoudiniEngineCopyPropertiesInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UHoudiniEngineCopyPropertiesInterface : UInterface {
};

// Class HoudiniEngineRuntime.HoudiniEngineEditorSettings
// Size: 0xb0 (Inherited: 0xb0)
struct UHoudiniEngineEditorSettings : UDeveloperSettings {
};

// Class HoudiniEngineRuntime.HoudiniHandleParameter
// Size: 0xb0 (Inherited: 0xa0)
struct UHoudiniHandleParameter : UObject {
	struct UHoudiniParameter* AssetParameter; // 0x98(0x08)
	int32_t TupleIndex; // 0xa0(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
};

// Class HoudiniEngineRuntime.HoudiniHandleComponent
// Size: 0x460 (Inherited: 0x3c0)
struct UHoudiniHandleComponent : USceneComponent {
	struct TArray<struct UHoudiniHandleParameter*> XformParms; // 0x3c0(0x10)
	struct UHoudiniHandleParameter* RSTParm; // 0x3d0(0x08)
	struct UHoudiniHandleParameter* RotOrderParm; // 0x3d8(0x08)
	struct FTransform LastSentTransform; // 0x3e0(0x60)
	char pad_440[0x1]; // 0x440(0x01)
	enum class EHoudiniHandleType HandleType; // 0x441(0x01)
	char pad_442[0x6]; // 0x442(0x06)
	struct FString HandleName; // 0x448(0x10)
	char pad_458[0x8]; // 0x458(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInput
// Size: 0x280 (Inherited: 0xa0)
struct UHoudiniInput : UObject {
	struct FString Name; // 0x98(0x10)
	struct FString Label; // 0xa8(0x10)
	enum class EHoudiniInputType Type; // 0xb8(0x01)
	enum class EHoudiniInputType PreviousType; // 0xb9(0x01)
	int32_t AssetNodeId; // 0xbc(0x04)
	int32_t InputNodeId; // 0xc0(0x04)
	int32_t InputIndex; // 0xc4(0x04)
	int32_t ParmId; // 0xc8(0x04)
	bool bIsObjectPathParameter; // 0xcc(0x01)
	struct TArray<int32_t> CreatedDataNodeIds; // 0xd0(0x10)
	bool bHasChanged; // 0xe0(0x01)
	bool bNeedsToTriggerUpdate; // 0xe1(0x01)
	char pad_e5[0x3]; // 0xe5(0x03)
	struct FBox CachedBounds; // 0xe8(0x38)
	struct FString Help; // 0x120(0x10)
	bool bPackBeforeMerge; // 0x130(0x01)
	bool bDirectlyConnectHdas; // 0x131(0x01)
	bool bExportOptionsMenuExpanded; // 0x132(0x01)
	bool bGeometryInputsMenuExpanded; // 0x133(0x01)
	bool bLandscapeOptionsMenuExpanded; // 0x134(0x01)
	bool bWorldInputsMenuExpanded; // 0x135(0x01)
	bool bCurveInputsMenuExpanded; // 0x136(0x01)
	bool bCurvePointSelectionMenuExpanded; // 0x137(0x01)
	bool bCurvePointSelectionUseAbsLocation; // 0x138(0x01)
	bool bCurvePointSelectionUseAbsRotation; // 0x139(0x01)
	bool bCookOnCurveChanged; // 0x13a(0x01)
	char pad_13b[0x5]; // 0x13b(0x05)
	struct TArray<struct UHoudiniInputObject*> GeometryInputObjects; // 0x140(0x10)
	bool bStaticMeshChanged; // 0x150(0x01)
	bool bInputAssetConnectedInHoudini; // 0x151(0x01)
	char pad_152[0x6]; // 0x152(0x06)
	struct TArray<struct UHoudiniInputObject*> CurveInputObjects; // 0x158(0x10)
	float DefaultCurveOffset; // 0x168(0x04)
	bool bLandscapeHasExportTypeChanged; // 0x16c(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
	struct TArray<struct UHoudiniInputObject*> WorldInputObjects; // 0x170(0x10)
	struct TArray<struct AActor*> WorldInputBoundSelectorObjects; // 0x180(0x10)
	bool bIsWorldInputBoundSelector; // 0x190(0x01)
	bool bWorldInputBoundSelectorAutoUpdate; // 0x191(0x01)
	char pad_192[0x6]; // 0x192(0x06)
	struct TSet<struct ULandscapeComponent*> LandscapeSelectedComponents; // 0x198(0x50)
	struct TSet<int32_t> InputNodesPendingDelete; // 0x1e8(0x50)
	struct TArray<struct UHoudiniInputHoudiniSplineComponent*> LastInsertedInputs; // 0x238(0x10)
	struct TArray<struct UHoudiniInputObject*> LastUndoDeletedInputs; // 0x248(0x10)
	bool bLandscapeControlVisiblity; // 0x258(0x01)
	bool bCanDeleteHoudiniNodes; // 0x259(0x01)
	bool bLandscapeSplinesExportOptionsMenuExpanded; // 0x25a(0x01)
	char pad_25b[0x1]; // 0x25b(0x01)
	struct FHoudiniInputObjectSettings InputSettings; // 0x25c(0x20)
	char pad_27c[0x4]; // 0x27c(0x04)
};

// Class HoudiniEngineRuntime.HoudiniInputObject
// Size: 0x290 (Inherited: 0xa0)
struct UHoudiniInputObject : UObject {
	struct TSoftObjectPtr<UObject> InputObject; // 0x98(0x28)
	enum class EHoudiniInputObjectType Type; // 0xc0(0x01)
	struct FGuid Guid; // 0xc4(0x10)
	char pad_d9[0xf7]; // 0xd9(0xf7)
	bool bHasChanged; // 0x1d0(0x01)
	bool bNeedsToTriggerUpdate; // 0x1d1(0x01)
	bool bTransformChanged; // 0x1d2(0x01)
	char pad_1d3[0x5]; // 0x1d3(0x05)
	struct TArray<struct FString> MaterialReferences; // 0x1d8(0x10)
	struct FHoudiniInputObjectSettings CachedInputSettings; // 0x1e8(0x20)
	bool bCanDeleteHoudiniNodes; // 0x208(0x01)
	bool bInputNodeHandleOverridesNodeIds; // 0x209(0x01)
	char pad_20a[0x6]; // 0x20a(0x06)
	struct FTransform Transform; // 0x210(0x60)
	struct FRotator UserInputRotator; // 0x270(0x18)
	int32_t InputNodeId; // 0x288(0x04)
	int32_t InputObjectNodeId; // 0x28c(0x04)
};

// Class HoudiniEngineRuntime.HoudiniInputStaticMesh
// Size: 0x290 (Inherited: 0x290)
struct UHoudiniInputStaticMesh : UHoudiniInputObject {
};

// Class HoudiniEngineRuntime.HoudiniInputSkeletalMesh
// Size: 0x290 (Inherited: 0x290)
struct UHoudiniInputSkeletalMesh : UHoudiniInputObject {
};

// Class HoudiniEngineRuntime.HoudiniInputAnimation
// Size: 0x290 (Inherited: 0x290)
struct UHoudiniInputAnimation : UHoudiniInputObject {
};

// Class HoudiniEngineRuntime.HoudiniInputGeometryCollection
// Size: 0x290 (Inherited: 0x290)
struct UHoudiniInputGeometryCollection : UHoudiniInputObject {
};

// Class HoudiniEngineRuntime.HoudiniInputSceneComponent
// Size: 0x300 (Inherited: 0x290)
struct UHoudiniInputSceneComponent : UHoudiniInputObject {
	struct FTransform ActorTransform; // 0x290(0x60)
	struct UHoudiniInputActor* ParentInputActor; // 0x2f0(0x08)
	char pad_2f8[0x8]; // 0x2f8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInputMeshComponent
// Size: 0x320 (Inherited: 0x300)
struct UHoudiniInputMeshComponent : UHoudiniInputSceneComponent {
	struct TSoftObjectPtr<UStaticMesh> StaticMesh; // 0x2f8(0x28)
};

// Class HoudiniEngineRuntime.HoudiniInputInstancedMeshComponent
// Size: 0x330 (Inherited: 0x320)
struct UHoudiniInputInstancedMeshComponent : UHoudiniInputMeshComponent {
	struct TArray<struct FTransform> InstanceTransforms; // 0x320(0x10)
};

// Class HoudiniEngineRuntime.HoudiniInputSplineComponent
// Size: 0x320 (Inherited: 0x300)
struct UHoudiniInputSplineComponent : UHoudiniInputSceneComponent {
	int32_t NumberOfSplineControlPoints; // 0x2f8(0x04)
	float SplineLength; // 0x2fc(0x04)
	float SplineResolution; // 0x300(0x04)
	bool SplineClosed; // 0x304(0x01)
	struct TArray<struct FTransform> SplineControlPoints; // 0x308(0x10)
	char pad_31d[0x3]; // 0x31d(0x03)
};

// Class HoudiniEngineRuntime.HoudiniInputGeometryCollectionComponent
// Size: 0x300 (Inherited: 0x300)
struct UHoudiniInputGeometryCollectionComponent : UHoudiniInputSceneComponent {
};

// Class HoudiniEngineRuntime.HoudiniInputSkeletalMeshComponent
// Size: 0x300 (Inherited: 0x300)
struct UHoudiniInputSkeletalMeshComponent : UHoudiniInputSceneComponent {
};

// Class HoudiniEngineRuntime.HoudiniInputHoudiniSplineComponent
// Size: 0x2a0 (Inherited: 0x290)
struct UHoudiniInputHoudiniSplineComponent : UHoudiniInputObject {
	enum class EHoudiniCurveType CurveType; // 0x290(0x01)
	enum class EHoudiniCurveMethod CurveMethod; // 0x291(0x01)
	bool Reversed; // 0x292(0x01)
	char pad_293[0x5]; // 0x293(0x05)
	struct UHoudiniSplineComponent* CachedComponent; // 0x298(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInputCameraComponent
// Size: 0x310 (Inherited: 0x300)
struct UHoudiniInputCameraComponent : UHoudiniInputSceneComponent {
	float FOV; // 0x2f8(0x04)
	float AspectRatio; // 0x2fc(0x04)
	bool bIsOrthographic; // 0x300(0x01)
	float OrthoWidth; // 0x304(0x04)
	float OrthoNearClipPlane; // 0x308(0x04)
	float OrthoFarClipPlane; // 0x30c(0x04)
};

// Class HoudiniEngineRuntime.HoudiniInputHoudiniAsset
// Size: 0x2a0 (Inherited: 0x290)
struct UHoudiniInputHoudiniAsset : UHoudiniInputObject {
	int32_t AssetOutputIndex; // 0x290(0x04)
	int32_t AssetId; // 0x294(0x04)
	char pad_298[0x8]; // 0x298(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInputActor
// Size: 0x420 (Inherited: 0x290)
struct UHoudiniInputActor : UHoudiniInputObject {
	int32_t SplinesMeshObjectNodeId; // 0x290(0x04)
	int32_t SplinesMeshNodeId; // 0x294(0x04)
	char pad_298[0xf8]; // 0x298(0xf8)
	struct TArray<struct UHoudiniInputSceneComponent*> ActorComponents; // 0x390(0x10)
	struct TSet<struct TSoftObjectPtr<UObject>> ActorSceneComponents; // 0x3a0(0x50)
	int32_t LastUpdateNumComponentsAdded; // 0x3f0(0x04)
	int32_t LastUpdateNumComponentsRemoved; // 0x3f4(0x04)
	int32_t NumSplineMeshComponents; // 0x3f8(0x04)
	struct FGuid GeneratedSplinesMeshPackageGuid; // 0x3fc(0x10)
	char pad_40c[0x4]; // 0x40c(0x04)
	struct UStaticMesh* GeneratedSplinesMesh; // 0x410(0x08)
	bool bUsedMergeSplinesMeshAtLastTranslate; // 0x418(0x01)
	char pad_419[0x7]; // 0x419(0x07)
};

// Class HoudiniEngineRuntime.HoudiniInputLevelInstance
// Size: 0x480 (Inherited: 0x420)
struct UHoudiniInputLevelInstance : UHoudiniInputActor {
	struct TMap<struct TSoftObjectPtr<AActor>, struct UHoudiniInputObject*> TrackedActorObjects; // 0x420(0x50)
	int32_t NumActorsAddedLastUpdate; // 0x470(0x04)
	int32_t NumActorsRemovedLastUpdate; // 0x474(0x04)
	char pad_478[0x8]; // 0x478(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInputLandscape
// Size: 0x430 (Inherited: 0x420)
struct UHoudiniInputLandscape : UHoudiniInputActor {
	int32_t CachedNumLandscapeComponents; // 0x420(0x04)
	char pad_424[0xc]; // 0x424(0x0c)
};

// Class HoudiniEngineRuntime.HoudiniInputBrush
// Size: 0x440 (Inherited: 0x420)
struct UHoudiniInputBrush : UHoudiniInputActor {
	struct TArray<struct FHoudiniBrushInfo> BrushesInfo; // 0x420(0x10)
	struct UModel* CombinedModel; // 0x430(0x08)
	bool bIgnoreInputObject; // 0x438(0x01)
	enum class EBrushType CachedInputBrushType; // 0x439(0x01)
	char pad_43a[0x6]; // 0x43a(0x06)
};

// Class HoudiniEngineRuntime.HoudiniInputDataTable
// Size: 0x290 (Inherited: 0x290)
struct UHoudiniInputDataTable : UHoudiniInputObject {
};

// Class HoudiniEngineRuntime.HoudiniInputFoliageType_InstancedStaticMesh
// Size: 0x290 (Inherited: 0x290)
struct UHoudiniInputFoliageType_InstancedStaticMesh : UHoudiniInputStaticMesh {
};

// Class HoudiniEngineRuntime.HoudiniInputBlueprint
// Size: 0x300 (Inherited: 0x290)
struct UHoudiniInputBlueprint : UHoudiniInputObject {
	struct TArray<struct UHoudiniInputSceneComponent*> BPComponents; // 0x290(0x10)
	struct TSet<struct TSoftObjectPtr<UObject>> BPSceneComponents; // 0x2a0(0x50)
	int32_t LastUpdateNumComponentsAdded; // 0x2f0(0x04)
	int32_t LastUpdateNumComponentsRemoved; // 0x2f4(0x04)
	char pad_2f8[0x8]; // 0x2f8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInputPackedLevelActor
// Size: 0x430 (Inherited: 0x420)
struct UHoudiniInputPackedLevelActor : UHoudiniInputActor {
	struct UHoudiniInputBlueprint* BlueprintInputObject; // 0x420(0x08)
	char pad_428[0x8]; // 0x428(0x08)
};

// Class HoudiniEngineRuntime.HoudiniInputLandscapeSplineActor
// Size: 0x420 (Inherited: 0x420)
struct UHoudiniInputLandscapeSplineActor : UHoudiniInputActor {
};

// Class HoudiniEngineRuntime.HoudiniInputLandscapeSplinesComponent
// Size: 0x370 (Inherited: 0x300)
struct UHoudiniInputLandscapeSplinesComponent : UHoudiniInputSceneComponent {
	struct TArray<struct FHoudiniLandscapeSplineControlPointData> CachedControlPoints; // 0x2f8(0x10)
	struct TArray<struct FHoudiniLandscapeSplineSegmentData> CachedSegments; // 0x308(0x10)
	struct TMap<struct TSoftObjectPtr<ULandscapeSplineControlPoint>, int32_t> ControlPointIdMap; // 0x318(0x50)
	int32_t NextControlPointId; // 0x368(0x04)
};

// Class HoudiniEngineRuntime.HoudiniInputSplineMeshComponent
// Size: 0x420 (Inherited: 0x320)
struct UHoudiniInputSplineMeshComponent : UHoudiniInputMeshComponent {
	struct FGuid MeshPackageGuid; // 0x320(0x10)
	struct UStaticMesh* GeneratedMesh; // 0x330(0x08)
	enum class ESplineMeshAxis CachedForwardAxis; // 0x338(0x01)
	char pad_339[0x7]; // 0x339(0x07)
	struct FSplineMeshParams CachedSplineParams; // 0x340(0xb0)
	struct FVector CachedSplineUpDir; // 0x3f0(0x18)
	float CachedSplineBoundaryMax; // 0x408(0x04)
	float CachedSplineBoundaryMin; // 0x40c(0x04)
	char CachedbSmoothInterpRollScale : 1; // 0x410(0x01)
	char pad_410_1 : 7; // 0x410(0x01)
	char pad_411[0xf]; // 0x411(0x0f)
};

// Class HoudiniEngineRuntime.HoudiniInstancedActorComponent
// Size: 0x3e0 (Inherited: 0x3c0)
struct UHoudiniInstancedActorComponent : USceneComponent {
	struct UObject* InstancedObject; // 0x3c0(0x08)
	struct TArray<struct AActor*> InstancedActors; // 0x3c8(0x10)
	char pad_3d8[0x8]; // 0x3d8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniMeshSplitInstancerComponent
// Size: 0x3f0 (Inherited: 0x3c0)
struct UHoudiniMeshSplitInstancerComponent : USceneComponent {
	struct TArray<struct UStaticMeshComponent*> Instances; // 0x3c0(0x10)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x3d0(0x10)
	struct UStaticMesh* InstancedMesh; // 0x3e0(0x08)
	char pad_3e8[0x8]; // 0x3e8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniNodeSyncComponent
// Size: 0xc50 (Inherited: 0xc20)
struct UHoudiniNodeSyncComponent : UHoudiniAssetComponent {
	char pad_c20[0x10]; // 0xc20(0x10)
	struct FString FetchNodePath; // 0xc30(0x10)
	bool bLiveSyncEnabled; // 0xc40(0x01)
	char pad_c41[0xf]; // 0xc41(0x0f)
};

// Class HoudiniEngineRuntime.HoudiniLandscapePtr
// Size: 0xd0 (Inherited: 0xa0)
struct UHoudiniLandscapePtr : UObject {
	struct TSoftObjectPtr<ALandscapeProxy> LandscapeSoftPtr; // 0x98(0x28)
	enum class EHoudiniLandscapeOutputBakeType BakeType; // 0xc0(0x01)
	struct FName EditLayerName; // 0xc4(0x08)
};

// Class HoudiniEngineRuntime.HoudiniLandscapeTargetLayerOutput
// Size: 0x140 (Inherited: 0xa0)
struct UHoudiniLandscapeTargetLayerOutput : UObject {
	struct ALandscape* Landscape; // 0x98(0x08)
	struct ALandscapeProxy* LandscapeProxy; // 0xa0(0x08)
	struct FString BakedEditLayer; // 0xa8(0x10)
	struct FString CookedEditLayer; // 0xb8(0x10)
	struct FString TargetLayer; // 0xc8(0x10)
	struct FHoudiniExtents Extents; // 0xd8(0x10)
	bool bClearLayer; // 0xe8(0x01)
	bool bCreatedLandscape; // 0xe9(0x01)
	bool bCookedLayerRequiresBaking; // 0xea(0x01)
	struct FString BakedLandscapeName; // 0xf0(0x10)
	struct TArray<struct ULandscapeLayerInfoObject*> LayerInfoObjects; // 0x100(0x10)
	struct FString BakeFolder; // 0x110(0x10)
	struct UMaterialInterface* MaterialInstance; // 0x120(0x08)
	bool bWriteLockedLayers; // 0x128(0x01)
	bool bLockLayer; // 0x129(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
	struct TArray<struct FHoudiniGenericAttribute> PropertyAttributes; // 0x130(0x10)
};

// Class HoudiniEngineRuntime.HoudiniLandscapeOutput
// Size: 0xd0 (Inherited: 0xa0)
struct UHoudiniLandscapeOutput : UObject {
	struct ALandscape* Landscape; // 0x98(0x08)
	struct FString BakedName; // 0xa0(0x10)
	struct TArray<struct UHoudiniLandscapeTargetLayerOutput*> Layers; // 0xb0(0x10)
	bool bCreated; // 0xc0(0x01)
	char pad_c9[0x7]; // 0xc9(0x07)
};

// Class HoudiniEngineRuntime.HoudiniLandscapeSplineTargetLayerOutput
// Size: 0x160 (Inherited: 0x140)
struct UHoudiniLandscapeSplineTargetLayerOutput : UHoudiniLandscapeTargetLayerOutput {
	struct FName AfterEditLayer; // 0x140(0x08)
	struct TArray<struct ULandscapeSplineSegment*> Segments; // 0x148(0x10)
	char pad_158[0x8]; // 0x158(0x08)
};

// Class HoudiniEngineRuntime.HoudiniLandscapeSplinesOutput
// Size: 0x130 (Inherited: 0xa0)
struct UHoudiniLandscapeSplinesOutput : UObject {
	struct ALandscape* Landscape; // 0x98(0x08)
	struct ALandscapeProxy* LandscapeProxy; // 0xa0(0x08)
	struct ALandscapeSplineActor* LandscapeSplineActor; // 0xa8(0x08)
	struct ULandscapeSplinesComponent* LandscapeSplinesComponent; // 0xb0(0x08)
	struct TMap<struct FName, struct UHoudiniLandscapeSplineTargetLayerOutput*> LayerOutputs; // 0xb8(0x50)
	struct TArray<struct ULandscapeSplineSegment*> Segments; // 0x108(0x10)
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // 0x118(0x10)
};

// Class HoudiniEngineRuntime.HoudiniOutput
// Size: 0x220 (Inherited: 0xa0)
struct UHoudiniOutput : UObject {
	enum class EHoudiniOutputType Type; // 0x98(0x01)
	struct TArray<struct FHoudiniGeoPartObject> HoudiniGeoPartObjects; // 0xa0(0x10)
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniOutputObject> OutputObjects; // 0xb0(0x50)
	struct TMap<struct FHoudiniOutputObjectIdentifier, struct FHoudiniInstancedOutput> InstancedOutputs; // 0x100(0x50)
	struct TMap<struct FHoudiniMaterialIdentifier, struct UMaterialInterface*> AssignmentMaterialsById; // 0x150(0x50)
	struct TMap<struct FHoudiniMaterialIdentifier, struct UMaterialInterface*> ReplacementMaterialsById; // 0x1a0(0x50)
	char pad_1f1[0x3]; // 0x1f1(0x03)
	bool bLandscapeWorldComposition; // 0x1f4(0x01)
	char pad_1f5[0x3]; // 0x1f5(0x03)
	struct TArray<struct AActor*> HoudiniCreatedSocketActors; // 0x1f8(0x10)
	struct TArray<struct AActor*> HoudiniAttachedSocketActors; // 0x208(0x10)
	bool bIsEditableNode; // 0x218(0x01)
	bool bHasEditableNodeBuilt; // 0x219(0x01)
	bool bIsUpdating; // 0x21a(0x01)
	bool bCanDeleteHoudiniNodes; // 0x21b(0x01)
	char pad_21c[0x4]; // 0x21c(0x04)
};

// Class HoudiniEngineRuntime.HoudiniParameter
// Size: 0x180 (Inherited: 0xa0)
struct UHoudiniParameter : UObject {
	struct FString Name; // 0x98(0x10)
	struct FString Label; // 0xa8(0x10)
	enum class EHoudiniParameterType ParmType; // 0xb8(0x01)
	enum class EHoudiniParameterChoiceListType ChoiceListType; // 0xb9(0x01)
	uint32_t TupleSize; // 0xbc(0x04)
	int32_t NodeId; // 0xc0(0x04)
	int32_t ParmId; // 0xc4(0x04)
	int32_t ParentParmId; // 0xc8(0x04)
	int32_t ChildIndex; // 0xcc(0x04)
	bool bIsVisible; // 0xd0(0x01)
	bool bIsParentFolderVisible; // 0xd1(0x01)
	bool bIsDisabled; // 0xd2(0x01)
	bool bHasChanged; // 0xd3(0x01)
	bool bNeedsToTriggerUpdate; // 0xd4(0x01)
	bool bIsDefault; // 0xd5(0x01)
	bool bIsSpare; // 0xd6(0x01)
	bool bJoinNext; // 0xd7(0x01)
	bool bIsLabelVisible; // 0xd8(0x01)
	bool bIsChildOfMultiParm; // 0xd9(0x01)
	bool bIsDirectChildOfMultiParm; // 0xda(0x01)
	bool bPendingRevertToDefault; // 0xdb(0x01)
	struct TArray<int32_t> TuplePendingRevertToDefault; // 0xe0(0x10)
	struct FString Help; // 0xf0(0x10)
	uint32_t TagCount; // 0x100(0x04)
	int32_t ValueIndex; // 0x104(0x04)
	bool bHasExpression; // 0x108(0x01)
	bool bShowExpression; // 0x109(0x01)
	char pad_10c[0x4]; // 0x10c(0x04)
	struct FString ParamExpression; // 0x110(0x10)
	struct TMap<struct FString, struct FString> Tags; // 0x120(0x50)
	bool bAutoUpdate; // 0x170(0x01)
	char pad_171[0xf]; // 0x171(0x0f)
};

// Class HoudiniEngineRuntime.HoudiniParameterButton
// Size: 0x180 (Inherited: 0x180)
struct UHoudiniParameterButton : UHoudiniParameter {
};

// Class HoudiniEngineRuntime.HoudiniParameterButtonStrip
// Size: 0x190 (Inherited: 0x180)
struct UHoudiniParameterButtonStrip : UHoudiniParameter {
	struct TArray<struct FString> Labels; // 0x178(0x10)
	uint32_t Value; // 0x188(0x04)
	uint32_t DefaultValue; // 0x18c(0x04)
};

// Class HoudiniEngineRuntime.HoudiniParameterChoice
// Size: 0x1f0 (Inherited: 0x180)
struct UHoudiniParameterChoice : UHoudiniParameter {
	int32_t IntValue; // 0x178(0x04)
	int32_t DefaultIntValue; // 0x17c(0x04)
	struct FString StringValue; // 0x180(0x10)
	struct FString DefaultStringValue; // 0x190(0x10)
	struct TArray<struct FString> StringChoiceValues; // 0x1a0(0x10)
	struct TArray<struct FString> StringChoiceLabels; // 0x1b0(0x10)
	char pad_1c8[0x8]; // 0x1c8(0x08)
	bool bIsChildOfRamp; // 0x1d0(0x01)
	char pad_1d1[0x7]; // 0x1d1(0x07)
	struct TArray<int32_t> IntValuesArray; // 0x1d8(0x10)
	char pad_1e8[0x8]; // 0x1e8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniParameterColor
// Size: 0x1a0 (Inherited: 0x180)
struct UHoudiniParameterColor : UHoudiniParameter {
	struct FLinearColor Color; // 0x178(0x10)
	struct FLinearColor DefaultColor; // 0x188(0x10)
	bool bIsChildOfRamp; // 0x198(0x01)
};

// Class HoudiniEngineRuntime.HoudiniParameterFile
// Size: 0x1b0 (Inherited: 0x180)
struct UHoudiniParameterFile : UHoudiniParameter {
	struct TArray<struct FString> Values; // 0x178(0x10)
	struct TArray<struct FString> DefaultValues; // 0x188(0x10)
	struct FString Filters; // 0x198(0x10)
	bool bIsReadOnly; // 0x1a8(0x01)
};

// Class HoudiniEngineRuntime.HoudiniParameterFloat
// Size: 0x1d0 (Inherited: 0x180)
struct UHoudiniParameterFloat : UHoudiniParameter {
	struct TArray<float> Values; // 0x178(0x10)
	struct TArray<float> DefaultValues; // 0x188(0x10)
	struct FString Unit; // 0x198(0x10)
	bool bNoSwap; // 0x1a8(0x01)
	bool bHasMin; // 0x1a9(0x01)
	bool bHasMax; // 0x1aa(0x01)
	bool bHasUIMin; // 0x1ab(0x01)
	bool bHasUIMax; // 0x1ac(0x01)
	bool bIsLogarithmic; // 0x1ad(0x01)
	float Min; // 0x1b0(0x04)
	float Max; // 0x1b4(0x04)
	float UIMin; // 0x1b8(0x04)
	float UIMax; // 0x1bc(0x04)
	bool bIsChildOfRamp; // 0x1c0(0x01)
	char pad_1c7[0x9]; // 0x1c7(0x09)
};

// Class HoudiniEngineRuntime.HoudiniParameterFolder
// Size: 0x190 (Inherited: 0x180)
struct UHoudiniParameterFolder : UHoudiniParameter {
	enum class EHoudiniFolderParameterType FolderType; // 0x178(0x01)
	bool bExpanded; // 0x179(0x01)
	bool bChosen; // 0x17a(0x01)
	int32_t ChildCounter; // 0x17c(0x04)
	bool bIsContentShown; // 0x180(0x01)
	char pad_188[0x8]; // 0x188(0x08)
};

// Class HoudiniEngineRuntime.HoudiniParameterFolderList
// Size: 0x190 (Inherited: 0x180)
struct UHoudiniParameterFolderList : UHoudiniParameter {
	bool bIsTabMenu; // 0x178(0x01)
	bool bIsTabsShown; // 0x179(0x01)
	struct TArray<struct UHoudiniParameterFolder*> TabFolders; // 0x180(0x10)
};

// Class HoudiniEngineRuntime.HoudiniParameterInt
// Size: 0x1c0 (Inherited: 0x180)
struct UHoudiniParameterInt : UHoudiniParameter {
	struct TArray<int32_t> Values; // 0x178(0x10)
	struct TArray<int32_t> DefaultValues; // 0x188(0x10)
	struct FString Unit; // 0x198(0x10)
	bool bHasMin; // 0x1a8(0x01)
	bool bHasMax; // 0x1a9(0x01)
	bool bHasUIMin; // 0x1aa(0x01)
	bool bHasUIMax; // 0x1ab(0x01)
	bool bIsLogarithmic; // 0x1ac(0x01)
	int32_t Min; // 0x1b0(0x04)
	int32_t Max; // 0x1b4(0x04)
	int32_t UIMin; // 0x1b8(0x04)
	int32_t UIMax; // 0x1bc(0x04)
};

// Class HoudiniEngineRuntime.HoudiniParameterLabel
// Size: 0x190 (Inherited: 0x180)
struct UHoudiniParameterLabel : UHoudiniParameter {
	struct TArray<struct FString> LabelStrings; // 0x178(0x10)
};

// Class HoudiniEngineRuntime.HoudiniParameterMultiParm
// Size: 0x1c0 (Inherited: 0x180)
struct UHoudiniParameterMultiParm : UHoudiniParameter {
	bool bIsShown; // 0x178(0x01)
	int32_t Value; // 0x17c(0x04)
	struct FString TemplateName; // 0x180(0x10)
	int32_t MultiparmValue; // 0x190(0x04)
	uint32_t MultiParmInstanceNum; // 0x194(0x04)
	uint32_t MultiParmInstanceLength; // 0x198(0x04)
	uint32_t MultiParmInstanceCount; // 0x19c(0x04)
	uint32_t InstanceStartOffset; // 0x1a0(0x04)
	struct TArray<enum class EHoudiniMultiParmModificationType> MultiParmInstanceLastModifyArray; // 0x1a8(0x10)
	int32_t DefaultInstanceCount; // 0x1b8(0x04)
	char pad_1bd[0x3]; // 0x1bd(0x03)
};

// Class HoudiniEngineRuntime.HoudiniParameterOperatorPath
// Size: 0x180 (Inherited: 0x180)
struct UHoudiniParameterOperatorPath : UHoudiniParameter {
	struct TWeakObjectPtr<struct UHoudiniInput> HoudiniInput; // 0x178(0x08)
};

// Class HoudiniEngineRuntime.HoudiniParameterRampModificationEvent
// Size: 0xc0 (Inherited: 0xa0)
struct UHoudiniParameterRampModificationEvent : UObject {
	bool bIsInsertEvent; // 0x98(0x01)
	bool bIsFloatRamp; // 0x99(0x01)
	int32_t DeleteInstanceIndex; // 0x9c(0x04)
	float InsertPosition; // 0xa0(0x04)
	float InsertFloat; // 0xa4(0x04)
	struct FLinearColor InsertColor; // 0xa8(0x10)
	enum class EHoudiniRampInterpolationType InsertInterpolation; // 0xb8(0x01)
	char pad_bf[0x1]; // 0xbf(0x01)
};

// Class HoudiniEngineRuntime.HoudiniParameterRampFloatPoint
// Size: 0xc0 (Inherited: 0xa0)
struct UHoudiniParameterRampFloatPoint : UObject {
	float Position; // 0x98(0x04)
	float Value; // 0x9c(0x04)
	enum class EHoudiniRampInterpolationType Interpolation; // 0xa0(0x01)
	int32_t InstanceIndex; // 0xa4(0x04)
	struct UHoudiniParameterFloat* PositionParentParm; // 0xa8(0x08)
	struct UHoudiniParameterFloat* ValueParentParm; // 0xb0(0x08)
	struct UHoudiniParameterChoice* InterpolationParentParm; // 0xb8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniParameterRampColorPoint
// Size: 0xd0 (Inherited: 0xa0)
struct UHoudiniParameterRampColorPoint : UObject {
	float Position; // 0x98(0x04)
	struct FLinearColor Value; // 0x9c(0x10)
	enum class EHoudiniRampInterpolationType Interpolation; // 0xac(0x01)
	int32_t InstanceIndex; // 0xb0(0x04)
	struct UHoudiniParameterFloat* PositionParentParm; // 0xb8(0x08)
	struct UHoudiniParameterColor* ValueParentParm; // 0xc0(0x08)
	struct UHoudiniParameterChoice* InterpolationParentParm; // 0xc8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniParameterRampFloat
// Size: 0x230 (Inherited: 0x1c0)
struct UHoudiniParameterRampFloat : UHoudiniParameterMultiParm {
	struct TArray<struct UHoudiniParameterRampFloatPoint*> Points; // 0x1c0(0x10)
	struct TArray<struct UHoudiniParameterRampFloatPoint*> CachedPoints; // 0x1d0(0x10)
	struct TArray<float> DefaultPositions; // 0x1e0(0x10)
	struct TArray<float> DefaultValues; // 0x1f0(0x10)
	struct TArray<int32_t> DefaultChoices; // 0x200(0x10)
	int32_t NumDefaultPoints; // 0x210(0x04)
	bool bCaching; // 0x214(0x01)
	char pad_215[0x3]; // 0x215(0x03)
	struct TArray<struct UHoudiniParameterRampModificationEvent*> ModificationEvents; // 0x218(0x10)
	char pad_228[0x8]; // 0x228(0x08)
};

// Class HoudiniEngineRuntime.HoudiniParameterRampColor
// Size: 0x230 (Inherited: 0x1c0)
struct UHoudiniParameterRampColor : UHoudiniParameterMultiParm {
	struct TArray<struct UHoudiniParameterRampColorPoint*> Points; // 0x1c0(0x10)
	bool bCaching; // 0x1d0(0x01)
	char pad_1d1[0x7]; // 0x1d1(0x07)
	struct TArray<struct UHoudiniParameterRampColorPoint*> CachedPoints; // 0x1d8(0x10)
	struct TArray<float> DefaultPositions; // 0x1e8(0x10)
	struct TArray<struct FLinearColor> DefaultValues; // 0x1f8(0x10)
	struct TArray<int32_t> DefaultChoices; // 0x208(0x10)
	int32_t NumDefaultPoints; // 0x218(0x04)
	char pad_21c[0x4]; // 0x21c(0x04)
	struct TArray<struct UHoudiniParameterRampModificationEvent*> ModificationEvents; // 0x220(0x10)
};

// Class HoudiniEngineRuntime.HoudiniParameterSeparator
// Size: 0x180 (Inherited: 0x180)
struct UHoudiniParameterSeparator : UHoudiniParameter {
};

// Class HoudiniEngineRuntime.HoudiniParameterString
// Size: 0x1b0 (Inherited: 0x180)
struct UHoudiniParameterString : UHoudiniParameter {
	struct TArray<struct FString> Values; // 0x178(0x10)
	struct TArray<struct FString> DefaultValues; // 0x188(0x10)
	struct TArray<struct UObject*> ChosenAssets; // 0x198(0x10)
	bool bIsAssetRef; // 0x1a8(0x01)
};

// Class HoudiniEngineRuntime.HoudiniParameterToggle
// Size: 0x1a0 (Inherited: 0x180)
struct UHoudiniParameterToggle : UHoudiniParameter {
	struct TArray<int32_t> Values; // 0x178(0x10)
	struct TArray<int32_t> DefaultValues; // 0x188(0x10)
};

// Class HoudiniEngineRuntime.TOPNode
// Size: 0x410 (Inherited: 0xa0)
struct UTOPNode : UObject {
	int32_t NodeId; // 0x98(0x04)
	struct FString NodeName; // 0xa0(0x10)
	struct FString NodePath; // 0xb0(0x10)
	struct FString ParentName; // 0xc0(0x10)
	struct UObject* WorkResultParent; // 0xd0(0x08)
	struct TArray<struct FTOPWorkResult> WorkResult; // 0xd8(0x10)
	bool bHidden; // 0xe8(0x01)
	bool bAutoLoad; // 0xe9(0x01)
	enum class EPDGNodeState NodeState; // 0xea(0x01)
	bool bCachedHaveNotLoadedWorkResults; // 0xeb(0x01)
	bool bCachedHaveLoadedWorkResults; // 0xec(0x01)
	bool bHasChildNodes; // 0xed(0x01)
	struct FHoudiniClearedEditLayers ClearedLayers; // 0xf0(0x50)
	bool bShow; // 0x140(0x01)
	char pad_143[0x5]; // 0x143(0x05)
	struct TMap<struct FString, struct FHoudiniPDGWorkResultObjectBakedOutput> BakedWorkResultObjectOutputs; // 0x148(0x50)
	struct FWorkItemTally WorkItemTally; // 0x198(0x238)
	struct FAggregatedWorkItemTally AggregatedWorkItemTally; // 0x3d0(0x28)
	bool bHasReceivedCookCompleteEvent; // 0x3f8(0x01)
	char pad_3f9[0x7]; // 0x3f9(0x07)
	struct FOutputActorOwner OutputActorOwner; // 0x400(0x10)
};

// Class HoudiniEngineRuntime.TOPNetwork
// Size: 0x110 (Inherited: 0xa0)
struct UTOPNetwork : UObject {
	int32_t NodeId; // 0x98(0x04)
	struct FString NodeName; // 0xa0(0x10)
	struct FString NodePath; // 0xb0(0x10)
	struct TArray<struct UTOPNode*> AllTOPNodes; // 0xc0(0x10)
	int32_t SelectedTOPIndex; // 0xd0(0x04)
	struct FString ParentName; // 0xd8(0x10)
	bool bShowResults; // 0xe8(0x01)
	bool bAutoLoadResults; // 0xe9(0x01)
	char pad_ea[0x26]; // 0xea(0x26)
};

// Class HoudiniEngineRuntime.HoudiniPDGAssetLink
// Size: 0x1b0 (Inherited: 0xa0)
struct UHoudiniPDGAssetLink : UObject {
	struct FString AssetName; // 0x98(0x10)
	struct FString AssetNodePath; // 0xa8(0x10)
	int32_t AssetId; // 0xb8(0x04)
	struct TArray<struct UTOPNetwork*> AllTOPNetworks; // 0xc0(0x10)
	int32_t SelectedTOPNetworkIndex; // 0xd0(0x04)
	enum class EPDGLinkState LinkState; // 0xd4(0x01)
	bool bAutoCook; // 0xd5(0x01)
	bool bUseTOPNodeFilter; // 0xd6(0x01)
	bool bUseTOPOutputFilter; // 0xd7(0x01)
	struct FString TOPNodeFilter; // 0xd8(0x10)
	struct FString TOPOutputFilter; // 0xe8(0x10)
	int32_t NumWorkItems; // 0xf8(0x04)
	struct FAggregatedWorkItemTally WorkItemTally; // 0x100(0x28)
	struct FString OutputCachePath; // 0x128(0x10)
	bool bNeedsUIRefresh; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	struct AActor* OutputParentActor; // 0x140(0x08)
	struct FDirectoryPath BakeFolder; // 0x148(0x10)
	char pad_158[0x48]; // 0x158(0x48)
	int32_t NumAttemptedNodeAutoBakes; // 0x1a0(0x04)
	int32_t NumSuccessfulNodeAutoBakes; // 0x1a4(0x04)
	char pad_1a8[0x8]; // 0x1a8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniRuntimeSettings
// Size: 0x3d0 (Inherited: 0xa0)
struct UHoudiniRuntimeSettings : UObject {
	enum class EHoudiniRuntimeSettingsSessionType SessionType; // 0x98(0x01)
	int32_t NumSessions; // 0x9c(0x04)
	struct FString ServerHost; // 0xa0(0x10)
	int32_t ServerPort; // 0xb0(0x04)
	struct FString ServerPipeName; // 0xb8(0x10)
	int64_t SharedMemoryBufferSize; // 0xc8(0x08)
	bool bSharedMemoryBufferCyclic; // 0xd0(0x01)
	bool bStartAutomaticServer; // 0xd1(0x01)
	char pad_d3[0x1]; // 0xd3(0x01)
	float AutomaticServerTimeout; // 0xd4(0x04)
	bool bSyncWithHoudiniCook; // 0xd8(0x01)
	bool bCookUsingHoudiniTime; // 0xd9(0x01)
	bool bSyncViewport; // 0xda(0x01)
	bool bSyncHoudiniViewport; // 0xdb(0x01)
	bool bSyncUnrealViewport; // 0xdc(0x01)
	bool bShowMultiAssetDialog; // 0xdd(0x01)
	bool bPreferHdaMemoryCopyOverHdaSourceFile; // 0xde(0x01)
	bool bPauseCookingOnStart; // 0xdf(0x01)
	bool bDisplaySlateCookingNotifications; // 0xe0(0x01)
	char pad_e1[0x7]; // 0xe1(0x07)
	struct FString DefaultTemporaryCookFolder; // 0xe8(0x10)
	struct FString DefaultBakeFolder; // 0xf8(0x10)
	bool bEnableDeprecatedInstanceVariations; // 0x108(0x01)
	bool MarshallingLandscapesUseDefaultUnrealScaling; // 0x109(0x01)
	bool MarshallingLandscapesUseFullResolution; // 0x10a(0x01)
	bool MarshallingLandscapesForceMinMaxValues; // 0x10b(0x01)
	float MarshallingLandscapesForcedMinValue; // 0x10c(0x04)
	float MarshallingLandscapesForcedMaxValue; // 0x110(0x04)
	bool bAddRotAndScaleAttributesOnCurves; // 0x114(0x01)
	bool bUseLegacyInputCurves; // 0x115(0x01)
	char pad_116[0x2]; // 0x116(0x02)
	float MarshallingSplineResolution; // 0x118(0x04)
	bool bEnableProxyStaticMesh; // 0x11c(0x01)
	bool bShowDefaultMesh; // 0x11d(0x01)
	bool bPreferNaniteFallbackMesh; // 0x11e(0x01)
	bool bEnableProxyStaticMeshRefinementByTimer; // 0x11f(0x01)
	float ProxyMeshAutoRefineTimeoutSeconds; // 0x120(0x04)
	bool bEnableProxyStaticMeshRefinementOnPreSaveWorld; // 0x124(0x01)
	bool bEnableProxyStaticMeshRefinementOnPreBeginPIE; // 0x125(0x01)
	char pad_126[0x2]; // 0x126(0x02)
	char bDoubleSidedGeometry : 1; // 0x128(0x01)
	char pad_128_1 : 7; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
	struct UPhysicalMaterial* PhysMaterial; // 0x130(0x08)
	struct FBodyInstance DefaultBodyInstance; // 0x138(0x190)
	enum class ECollisionTraceFlag CollisionTraceFlag; // 0x2c8(0x01)
	char pad_2c9[0x3]; // 0x2c9(0x03)
	int32_t LightMapResolution; // 0x2cc(0x04)
	float LpvBiasMultiplier; // 0x2d0(0x04)
	float GeneratedDistanceFieldResolutionScale; // 0x2d4(0x04)
	struct FWalkableSlopeOverride WalkableSlopeOverride; // 0x2d8(0x10)
	int32_t LightMapCoordinateIndex; // 0x2e8(0x04)
	char bUseMaximumStreamingTexelRatio : 1; // 0x2ec(0x01)
	char pad_2ec_1 : 7; // 0x2ec(0x01)
	char pad_2ed[0x3]; // 0x2ed(0x03)
	float StreamingDistanceMultiplier; // 0x2f0(0x04)
	char pad_2f4[0x4]; // 0x2f4(0x04)
	struct UFoliageType_InstancedStaticMesh* FoliageDefaultSettings; // 0x2f8(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x300(0x10)
	bool bUseFullPrecisionUVs; // 0x310(0x01)
	char pad_311[0x3]; // 0x311(0x03)
	int32_t SrcLightmapIndex; // 0x314(0x04)
	int32_t DstLightmapIndex; // 0x318(0x04)
	int32_t MinLightmapResolution; // 0x31c(0x04)
	bool bRemoveDegenerates; // 0x320(0x01)
	enum class EHoudiniRuntimeSettingsRecomputeFlag GenerateLightmapUVsFlag; // 0x321(0x01)
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeNormalsFlag; // 0x322(0x01)
	enum class EHoudiniRuntimeSettingsRecomputeFlag RecomputeTangentsFlag; // 0x323(0x01)
	bool bUseMikkTSpace; // 0x324(0x01)
	bool bBuildAdjacencyBuffer; // 0x325(0x01)
	char bComputeWeightedNormals : 1; // 0x326(0x01)
	char bBuildReversedIndexBuffer : 1; // 0x326(0x01)
	char bUseHighPrecisionTangentBasis : 1; // 0x326(0x01)
	char pad_326_3 : 5; // 0x326(0x01)
	char pad_327[0x1]; // 0x327(0x01)
	float DistanceFieldResolutionScale; // 0x328(0x04)
	char bGenerateDistanceFieldAsIfTwoSided : 1; // 0x32c(0x01)
	char bSupportFaceRemap : 1; // 0x32c(0x01)
	char pad_32c_2 : 6; // 0x32c(0x01)
	bool bPDGAsyncCommandletImportEnabled; // 0x32d(0x01)
	char pad_32e[0x2]; // 0x32e(0x02)
	struct TArray<struct FString> HoudiniToolsSearchPath; // 0x330(0x10)
	bool bUseCustomHoudiniLocation; // 0x340(0x01)
	char pad_341[0x7]; // 0x341(0x07)
	struct FDirectoryPath CustomHoudiniLocation; // 0x348(0x10)
	enum class EHoudiniExecutableType HoudiniExecutable; // 0x358(0x01)
	char pad_359[0x7]; // 0x359(0x07)
	struct FDirectoryPath CustomHoudiniHomeLocation; // 0x360(0x10)
	int32_t CookingThreadStackSize; // 0x370(0x04)
	char pad_374[0x4]; // 0x374(0x04)
	struct FString HoudiniEnvironmentFiles; // 0x378(0x10)
	struct FString OtlSearchPath; // 0x388(0x10)
	struct FString DsoSearchPath; // 0x398(0x10)
	struct FString ImageDsoSearchPath; // 0x3a8(0x10)
	struct FString AudioDsoSearchPath; // 0x3b8(0x10)
	char pad_3c8[0x8]; // 0x3c8(0x08)
};

// Class HoudiniEngineRuntime.HoudiniSplineComponent
// Size: 0x710 (Inherited: 0x3c0)
struct UHoudiniSplineComponent : USceneComponent {
	char pad_3c0[0x8]; // 0x3c0(0x08)
	struct TArray<struct FTransform> CurvePoints; // 0x3c8(0x10)
	struct TArray<struct FVector3d> DisplayPoints; // 0x3d8(0x10)
	struct TArray<int32_t> DisplayPointIndexDivider; // 0x3e8(0x10)
	struct FString HoudiniSplineName; // 0x3f8(0x10)
	bool bClosed; // 0x408(0x01)
	bool bReversed; // 0x409(0x01)
	char pad_40a[0x2]; // 0x40a(0x02)
	int32_t CurveOrder; // 0x40c(0x04)
	bool bIsHoudiniSplineVisible; // 0x410(0x01)
	enum class EHoudiniCurveType CurveType; // 0x411(0x01)
	enum class EHoudiniCurveMethod CurveMethod; // 0x412(0x01)
	enum class EHoudiniCurveBreakpointParameterization CurveBreakpointParameterization; // 0x413(0x01)
	bool bIsOutputCurve; // 0x414(0x01)
	bool bCookOnCurveChanged; // 0x415(0x01)
	bool bIsLegacyInputCurve; // 0x416(0x01)
	char pad_417[0x2d9]; // 0x417(0x2d9)
	bool bHasChanged; // 0x6f0(0x01)
	bool bNeedsToTriggerUpdate; // 0x6f1(0x01)
	bool bIsInputCurve; // 0x6f2(0x01)
	bool bIsEditableOutputCurve; // 0x6f3(0x01)
	int32_t NodeId; // 0x6f4(0x04)
	struct FString PartName; // 0x6f8(0x10)
	char pad_708[0x8]; // 0x708(0x08)
};

// Class HoudiniEngineRuntime.HoudiniStaticMesh
// Size: 0x140 (Inherited: 0xa0)
struct UHoudiniStaticMesh : UObject {
	bool bHasNormals; // 0x98(0x01)
	bool bHasTangents; // 0x99(0x01)
	bool bHasColors; // 0x9a(0x01)
	uint32_t NumUVLayers; // 0x9c(0x04)
	bool bHasPerFaceMaterials; // 0xa0(0x01)
	struct TArray<struct FVector3f> VertexPositions; // 0xa8(0x10)
	struct TArray<struct FIntVector> TriangleIndices; // 0xb8(0x10)
	struct TArray<struct FColor> VertexInstanceColors; // 0xc8(0x10)
	struct TArray<struct FVector3f> VertexInstanceNormals; // 0xd8(0x10)
	struct TArray<struct FVector3f> VertexInstanceUTangents; // 0xe8(0x10)
	struct TArray<struct FVector3f> VertexInstanceVTangents; // 0xf8(0x10)
	struct TArray<struct FVector2f> VertexInstanceUVs; // 0x108(0x10)
	struct TArray<int32_t> MaterialIDsPerTriangle; // 0x118(0x10)
	struct TArray<struct FStaticMaterial> StaticMaterials; // 0x128(0x10)
	char pad_138[0x8]; // 0x138(0x08)

	void SetVertexPosition(uint32_t InVertexIndex, struct FVector3f& InPosition); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetVertexPosition // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c8f9e0
	void SetTriangleVertexVTangent(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector3f& InVTangent); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexVTangent // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c90a00
	void SetTriangleVertexUV(uint32_t InTriangleIndex, char InTriangleVertexIndex, char InUVLayer, struct FVector2f& InUV); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexUV // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c904f0
	void SetTriangleVertexUTangent(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector3f& InUTangent); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexUTangent // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c92900
	void SetTriangleVertexNormal(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FVector3f& InNormal); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexNormal // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c926f0
	void SetTriangleVertexIndices(uint32_t InTriangleIndex, struct FIntVector& InTriangleVertexIndices); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexIndices // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c92570
	void SetTriangleVertexColor(uint32_t InTriangleIndex, char InTriangleVertexIndex, struct FColor& InColor); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleVertexColor // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x9c8f130
	void SetTriangleMaterialID(uint32_t InTriangleIndex, int32_t InMaterialID); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetTriangleMaterialID // (Final|Native|Public) // @ game+0x9c910c0
	void SetStaticMaterial(uint32_t InMaterialIndex, struct FStaticMaterial& InStaticMaterial); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetStaticMaterial // (Final|Native|Public|HasOutParms) // @ game+0x9c8fae0
	void SetNumUVLayers(uint32_t InNumUVLayers); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetNumUVLayers // (Final|Native|Public) // @ game+0x9c90920
	void SetNumStaticMaterials(uint32_t InNumStaticMaterials); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetNumStaticMaterials // (Final|Native|Public) // @ game+0x9c92a50
	void SetHasTangents(bool bInHasTangents); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasTangents // (Final|Native|Public) // @ game+0x9c91300
	void SetHasPerFaceMaterials(bool bInHasPerFaceMaterials); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasPerFaceMaterials // (Final|Native|Public) // @ game+0x9c90880
	void SetHasNormals(bool bInHasNormals); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasNormals // (Final|Native|Public) // @ game+0x9c90430
	void SetHasColors(bool bInHasColors); // Function HoudiniEngineRuntime.HoudiniStaticMesh.SetHasColors // (Final|Native|Public) // @ game+0x9c911c0
	void Optimize(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.Optimize // (Final|Native|Public) // @ game+0x9c90cc0
	bool IsValid(bool bInSkipVertexIndicesCheck); // Function HoudiniEngineRuntime.HoudiniStaticMesh.IsValid // (Final|Native|Public|Const) // @ game+0x9c8f890
	void Initialize(uint32_t InNumVertices, uint32_t InNumTriangles, uint32_t InNumUVLayers, uint32_t InInitialNumStaticMaterials, bool bInHasNormals, bool bInHasTangents, bool bInHasColors, bool bInHasPerFaceMaterials); // Function HoudiniEngineRuntime.HoudiniStaticMesh.Initialize // (Final|Native|Public) // @ game+0x9c8e7f0
	bool HasTangents(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.HasTangents // (Final|Native|Public|Const) // @ game+0x9c8e2b0
	bool HasPerFaceMaterials(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.HasPerFaceMaterials // (Final|Native|Public|Const) // @ game+0x9c90e30
	bool HasNormals(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.HasNormals // (Final|Native|Public|Const) // @ game+0x32a8840
	bool HasColors(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.HasColors // (Final|Native|Public|Const) // @ game+0x9c904d0
	struct TArray<struct FVector3f> GetVertexPositions(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexPositions // (Final|Native|Public|Const) // @ game+0x9c8eb30
	struct TArray<struct FVector3f> GetVertexInstanceVTangents(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceVTangents // (Final|Native|Public|Const) // @ game+0x9c8e220
	struct TArray<struct FVector2f> GetVertexInstanceUVs(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceUVs // (Final|Native|Public|Const) // @ game+0x9c91280
	struct TArray<struct FVector3f> GetVertexInstanceUTangents(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceUTangents // (Final|Native|Public|Const) // @ game+0x9c90db0
	struct TArray<struct FVector3f> GetVertexInstanceNormals(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceNormals // (Final|Native|Public|Const) // @ game+0x9c8f740
	struct TArray<struct FColor> GetVertexInstanceColors(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetVertexInstanceColors // (Final|Native|Public|Const) // @ game+0x9c906c0
	struct TArray<struct FIntVector> GetTriangleIndices(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetTriangleIndices // (Final|Native|Public|Const) // @ game+0x9c8fd00
	struct TArray<struct FStaticMaterial> GetStaticMaterials(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetStaticMaterials // (Final|Native|Public|Const) // @ game+0x9c8ff80
	uint32_t GetNumVertices(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumVertices // (Final|Native|Public|Const) // @ game+0x32a7e30
	uint32_t GetNumVertexInstances(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumVertexInstances // (Final|Native|Public|Const) // @ game+0x9c90400
	uint32_t GetNumUVLayers(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumUVLayers // (Final|Native|Public|Const) // @ game+0x3aeb670
	uint32_t GetNumTriangles(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumTriangles // (Final|Native|Public|Const) // @ game+0x327a8b0
	uint32_t GetNumStaticMaterials(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetNumStaticMaterials // (Final|Native|Public|Const) // @ game+0x9c92e20
	int32_t GetMaterialIndex(struct FName InMaterialSlotName); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterialIndex // (Final|Native|Public|Const) // @ game+0x9c90f50
	struct TArray<int32_t> GetMaterialIDsPerTriangle(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterialIDsPerTriangle // (Final|Native|Public|Const) // @ game+0x9c913d0
	struct UMaterialInterface* GetMaterial(int32_t InMaterialIndex); // Function HoudiniEngineRuntime.HoudiniStaticMesh.GetMaterial // (Final|Native|Public) // @ game+0x9c92c30
	void CalculateTangents(bool bInComputeWeightedNormals); // Function HoudiniEngineRuntime.HoudiniStaticMesh.CalculateTangents // (Final|Native|Public) // @ game+0x9c90ce0
	void CalculateNormals(bool bInComputeWeightedNormals); // Function HoudiniEngineRuntime.HoudiniStaticMesh.CalculateNormals // (Final|Native|Public) // @ game+0x9c91540
	struct FBox CalcBounds(); // Function HoudiniEngineRuntime.HoudiniStaticMesh.CalcBounds // (Final|Native|Public|HasDefaults|Const) // @ game+0x9c8e6c0
	uint32_t AddStaticMaterial(struct FStaticMaterial& InStaticMaterial); // Function HoudiniEngineRuntime.HoudiniStaticMesh.AddStaticMaterial // (Final|Native|Public|HasOutParms) // @ game+0x9c92d00
};

// Class HoudiniEngineRuntime.HoudiniStaticMeshComponent
// Size: 0x740 (Inherited: 0x6f0)
struct UHoudiniStaticMeshComponent : UMeshComponent {
	struct UHoudiniStaticMesh* Mesh; // 0x6f0(0x08)
	struct FBox LocalBounds; // 0x6f8(0x38)
	bool bHoudiniIconVisible; // 0x730(0x01)
	char pad_731[0xf]; // 0x731(0x0f)

	void SetMesh(struct UHoudiniStaticMesh* InMesh); // Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.SetMesh // (Final|Native|Public) // @ game+0x9c96690
	void SetHoudiniIconVisible(bool bInHoudiniIconVisible); // Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.SetHoudiniIconVisible // (Final|Native|Public) // @ game+0x9c94310
	void NotifyMeshUpdated(); // Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.NotifyMeshUpdated // (Final|Native|Public) // @ game+0x9c9b9a0
	bool IsHoudiniIconVisible(); // Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.IsHoudiniIconVisible // (Final|Native|Public|Const) // @ game+0x9c98340
	struct UHoudiniStaticMesh* GetMesh(); // Function HoudiniEngineRuntime.HoudiniStaticMeshComponent.GetMesh // (Final|Native|Public) // @ game+0x9c93570
};

// Class HoudiniEngineRuntime.HoudiniToolData
// Size: 0x120 (Inherited: 0xa0)
struct UHoudiniToolData : UObject {
	struct FString Name; // 0x98(0x10)
	struct FString ToolTip; // 0xa8(0x10)
	struct FHImageData IconImageData; // 0xb8(0x30)
	struct FFilePath IconSourcePath; // 0xe8(0x10)
	struct FString HelpURL; // 0xf8(0x10)
	enum class EHoudiniToolType Type; // 0x108(0x01)
	bool DefaultTool; // 0x109(0x01)
	enum class EHoudiniToolSelectionType SelectionType; // 0x10a(0x01)
	struct FFilePath SourceAssetPath; // 0x110(0x10)

	bool SaveToJSONFile(struct FString JsonFilePath); // Function HoudiniEngineRuntime.HoudiniToolData.SaveToJSONFile // (Final|Native|Public|BlueprintCallable) // @ game+0x9c943b0
	bool PopulateFromJSONFile(struct FString JsonFilePath); // Function HoudiniEngineRuntime.HoudiniToolData.PopulateFromJSONFile // (Final|Native|Public|BlueprintCallable) // @ game+0x9c943b0
	bool PopulateFromJSONData(struct FString JSONData); // Function HoudiniEngineRuntime.HoudiniToolData.PopulateFromJSONData // (Final|Native|Public|BlueprintCallable) // @ game+0x9c943b0
	bool ConvertToJSONData(struct FString& JSONData); // Function HoudiniEngineRuntime.HoudiniToolData.ConvertToJSONData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9c9e760
};

// Class HoudiniEngineRuntime.HoudiniToolsPackageAsset
// Size: 0x100 (Inherited: 0xa0)
struct UHoudiniToolsPackageAsset : UObject {
	struct TMap<struct FString, struct FCategoryRules> Categories; // 0x98(0x50)
	struct FDirectoryPath ExternalPackageDir; // 0xe8(0x10)
	bool bReimportPackageDescription; // 0xf8(0x01)
	bool bExportPackageDescription; // 0xf9(0x01)
	bool bReimportToolsDescription; // 0xfa(0x01)
	bool bExportToolsDescription; // 0xfb(0x01)
};

// Class HoudiniEngineRuntime.HoudiniAssetStateEvents
// Size: 0xa0 (Inherited: 0xa0)
struct UHoudiniAssetStateEvents : UInterface {
};

