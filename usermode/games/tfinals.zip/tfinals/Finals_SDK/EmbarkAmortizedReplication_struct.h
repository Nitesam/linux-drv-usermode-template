// Enum EmbarkAmortizedReplication.EConnectionSortingMethod
enum class EConnectionSortingMethod : uint8_t {
	Distance = 0,
	EConnectionSortingMethod_MAX = 1
};

