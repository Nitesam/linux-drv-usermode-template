// Enum EmbarkPreLoadScreen.EEmbarkPreLoadScreenType
enum class EEmbarkPreLoadScreenType : uint8_t {
	Spinner = 0,
	Flipbook = 1,
	EEmbarkPreLoadScreenType_MAX = 2
};

// Enum EmbarkPreLoadScreen.EEmbarkPreLoadScreenHorizontalAlignment
enum class EEmbarkPreLoadScreenHorizontalAlignment : uint8_t {
	Left = 0,
	Center = 1,
	Right = 2,
	EEmbarkPreLoadScreenHorizontalAlignment_MAX = 3
};

// Enum EmbarkPreLoadScreen.EEmbarkPreLoadScreenVerticalAlignment
enum class EEmbarkPreLoadScreenVerticalAlignment : uint8_t {
	Top = 0,
	Center = 1,
	Bottom = 2,
	EEmbarkPreLoadScreenVerticalAlignment_MAX = 3
};

