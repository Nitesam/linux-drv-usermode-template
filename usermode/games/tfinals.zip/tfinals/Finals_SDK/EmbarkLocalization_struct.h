// ScriptStruct EmbarkLocalization.EmbarkLocalizationSourceConfig
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkLocalizationSourceConfig {
	struct FString Namespace; // 0x00(0x10)
	struct FName TableId; // 0x10(0x08)
	struct FString FilePath; // 0x18(0x10)
};

