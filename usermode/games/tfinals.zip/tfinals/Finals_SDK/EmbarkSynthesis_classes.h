// Class EmbarkSynthesis.SourceEffectAdaptiveNoisePreset
// Size: 0x140 (Inherited: 0xe0)
struct USourceEffectAdaptiveNoisePreset : USoundEffectSourcePreset {
	char pad_e0[0x3c]; // 0xe0(0x3c)
	struct FSourceEffectAdaptiveNoiseSettings Settings; // 0x11c(0x1c)
	char pad_138[0x8]; // 0x138(0x08)

	void SetSettings(struct FSourceEffectAdaptiveNoiseSettings& InSettings); // Function EmbarkSynthesis.SourceEffectAdaptiveNoisePreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67a3220
};

// Class EmbarkSynthesis.SourceEffectBounceCombPreset
// Size: 0x120 (Inherited: 0xe0)
struct USourceEffectBounceCombPreset : USoundEffectSourcePreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSourceEffectBounceCombSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSourceEffectBounceCombSettings& InSettings); // Function EmbarkSynthesis.SourceEffectBounceCombPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67d13f0
};

// Class EmbarkSynthesis.SourceEffectMultiChDelayPreset
// Size: 0x150 (Inherited: 0xe0)
struct USourceEffectMultiChDelayPreset : USoundEffectSourcePreset {
	char pad_e0[0x44]; // 0xe0(0x44)
	struct FSourceEffectMultiChDelaySettings Settings; // 0x124(0x24)
	char pad_148[0x8]; // 0x148(0x08)

	void SetSettings(struct FSourceEffectMultiChDelaySettings& InSettings); // Function EmbarkSynthesis.SourceEffectMultiChDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67ad4d0
	float GetMaxDelayTime(); // Function EmbarkSynthesis.SourceEffectMultiChDelayPreset.GetMaxDelayTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67c5ca0
};

// Class EmbarkSynthesis.SourceEffectRadioStaticPreset
// Size: 0x2b0 (Inherited: 0xe0)
struct USourceEffectRadioStaticPreset : USoundEffectSourcePreset {
	char pad_e0[0xf8]; // 0xe0(0xf8)
	struct FSourceEffectRadioStaticSettings Settings; // 0x1d8(0xd8)

	void SetSettings(struct FSourceEffectRadioStaticSettings& InSettings); // Function EmbarkSynthesis.SourceEffectRadioStaticPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67a3530
};

// Class EmbarkSynthesis.SourceEffectSimpleCompressorPreset
// Size: 0x140 (Inherited: 0xe0)
struct USourceEffectSimpleCompressorPreset : USoundEffectSourcePreset {
	char pad_e0[0x40]; // 0xe0(0x40)
	struct FSourceEffectSimpleCompressorSettings Settings; // 0x120(0x20)

	void SetSettings(struct FSourceEffectSimpleCompressorSettings& InSettings); // Function EmbarkSynthesis.SourceEffectSimpleCompressorPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67d3430
};

// Class EmbarkSynthesis.SourceEffectSoftDistortionPreset
// Size: 0x130 (Inherited: 0xe0)
struct USourceEffectSoftDistortionPreset : USoundEffectSourcePreset {
	char pad_e0[0x34]; // 0xe0(0x34)
	struct FSourceEffectSoftDistortionSettings Settings; // 0x114(0x14)
	char pad_128[0x8]; // 0x128(0x08)

	void SetSettings(struct FSourceEffectSoftDistortionSettings& InSettings); // Function EmbarkSynthesis.SourceEffectSoftDistortionPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67b4ec0
};

// Class EmbarkSynthesis.SourceEffectTransientShaperPreset
// Size: 0x120 (Inherited: 0xe0)
struct USourceEffectTransientShaperPreset : USoundEffectSourcePreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSourceEffectTransientShaperSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSourceEffectTransientShaperSettings& InSettings); // Function EmbarkSynthesis.SourceEffectTransientShaperPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67b2d20
};

// Class EmbarkSynthesis.SourceEffectTunedResonatorPreset
// Size: 0x130 (Inherited: 0xe0)
struct USourceEffectTunedResonatorPreset : USoundEffectSourcePreset {
	char pad_e0[0x34]; // 0xe0(0x34)
	struct FSourceEffectTunedResonatorSettings Settings; // 0x114(0x14)
	char pad_128[0x8]; // 0x128(0x08)

	void SetSettings(struct FSourceEffectTunedResonatorSettings& InSettings); // Function EmbarkSynthesis.SourceEffectTunedResonatorPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67afbd0
};

// Class EmbarkSynthesis.SubmixEffectAdaptiveNoisePreset
// Size: 0x140 (Inherited: 0xe0)
struct USubmixEffectAdaptiveNoisePreset : USoundEffectSubmixPreset {
	char pad_e0[0x3c]; // 0xe0(0x3c)
	struct FSubmixEffectAdaptiveNoiseSettings Settings; // 0x11c(0x1c)
	char pad_138[0x8]; // 0x138(0x08)

	void SetSettings(struct FSubmixEffectAdaptiveNoiseSettings& InSettings); // Function EmbarkSynthesis.SubmixEffectAdaptiveNoisePreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67a3220
};

// Class EmbarkSynthesis.SubmixEffectMultiChDelayPreset
// Size: 0x170 (Inherited: 0xe0)
struct USubmixEffectMultiChDelayPreset : USoundEffectSubmixPreset {
	char pad_e0[0x44]; // 0xe0(0x44)
	struct FSubmixEffectMultiChDelaySettings Settings; // 0x124(0x24)
	char pad_148[0x28]; // 0x148(0x28)

	void SetSettings(struct FSubmixEffectMultiChDelaySettings& InSettings); // Function EmbarkSynthesis.SubmixEffectMultiChDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67ad4d0
	void SetDelayTime(float DelayInSeconds); // Function EmbarkSynthesis.SubmixEffectMultiChDelayPreset.SetDelayTime // (Final|Native|Public|BlueprintCallable) // @ game+0x67cbea0
	float GetMaxDelayTime(); // Function EmbarkSynthesis.SubmixEffectMultiChDelayPreset.GetMaxDelayTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67c5ca0
};

// Class EmbarkSynthesis.SubmixEffectMultitapDelayPreset
// Size: 0x160 (Inherited: 0xe0)
struct USubmixEffectMultitapDelayPreset : USoundEffectSubmixPreset {
	char pad_e0[0x40]; // 0xe0(0x40)
	struct FSubmixEffectMultitapDelaySettings Settings; // 0x120(0x20)
	char pad_140[0x20]; // 0x140(0x20)

	void SetSettings(struct FSubmixEffectMultitapDelaySettings& InSettings); // Function EmbarkSynthesis.SubmixEffectMultitapDelayPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67d2280
	int32_t GetMaxTapCount(); // Function EmbarkSynthesis.SubmixEffectMultitapDelayPreset.GetMaxTapCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67a7240
	float GetMaxDelayTime(); // Function EmbarkSynthesis.SubmixEffectMultitapDelayPreset.GetMaxDelayTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67bf970
};

// Class EmbarkSynthesis.SubmixEffectSimpleCompressorPreset
// Size: 0x140 (Inherited: 0xe0)
struct USubmixEffectSimpleCompressorPreset : USoundEffectSubmixPreset {
	char pad_e0[0x40]; // 0xe0(0x40)
	struct FSubmixEffectSimpleCompressorSettings Settings; // 0x120(0x20)

	void SetSettings(struct FSubmixEffectSimpleCompressorSettings& InSettings); // Function EmbarkSynthesis.SubmixEffectSimpleCompressorPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67a8080
};

// Class EmbarkSynthesis.SubmixEffectSoftDistortionPreset
// Size: 0x130 (Inherited: 0xe0)
struct USubmixEffectSoftDistortionPreset : USoundEffectSubmixPreset {
	char pad_e0[0x34]; // 0xe0(0x34)
	struct FSubmixEffectSoftDistortionSettings Settings; // 0x114(0x14)
	char pad_128[0x8]; // 0x128(0x08)

	void SetSettings(struct FSubmixEffectSoftDistortionSettings& InSettings); // Function EmbarkSynthesis.SubmixEffectSoftDistortionPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67b4ec0
};

// Class EmbarkSynthesis.SubmixEffectTransientShaperPreset
// Size: 0x120 (Inherited: 0xe0)
struct USubmixEffectTransientShaperPreset : USoundEffectSubmixPreset {
	char pad_e0[0x30]; // 0xe0(0x30)
	struct FSubmixEffectTransientShaperSettings Settings; // 0x110(0x10)

	void SetSettings(struct FSubmixEffectTransientShaperSettings& InSettings); // Function EmbarkSynthesis.SubmixEffectTransientShaperPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67b2d20
};

// Class EmbarkSynthesis.SubmixEffectTunedResonatorPreset
// Size: 0x130 (Inherited: 0xe0)
struct USubmixEffectTunedResonatorPreset : USoundEffectSubmixPreset {
	char pad_e0[0x34]; // 0xe0(0x34)
	struct FSubmixEffectTunedResonatorSettings Settings; // 0x114(0x14)
	char pad_128[0x8]; // 0x128(0x08)

	void SetSettings(struct FSubmixEffectTunedResonatorSettings& InSettings); // Function EmbarkSynthesis.SubmixEffectTunedResonatorPreset.SetSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67afbd0
};

