// Enum NiagaraCore.ENiagaraIterationSource
enum class ENiagaraIterationSource : uint8_t {
	Particles = 0,
	DataInterface = 1,
	DirectSet = 2,
	ENiagaraIterationSource_MAX = 3
};

// ScriptStruct NiagaraCore.NiagaraVariableCommonReference
// Size: 0x10 (Inherited: 0x00)
struct FNiagaraVariableCommonReference {
	struct FName Name; // 0x00(0x08)
	struct UObject* UnderlyingType; // 0x08(0x08)
};

// ScriptStruct NiagaraCore.NiagaraCompileHash
// Size: 0x10 (Inherited: 0x00)
struct FNiagaraCompileHash {
	struct TArray<char> DataHash; // 0x00(0x10)
};

