// Class MovieSceneCapture.MovieSceneCaptureProtocolBase
// Size: 0xd0 (Inherited: 0xa0)
struct UMovieSceneCaptureProtocolBase : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	enum class EMovieSceneCaptureProtocolState State; // 0xc0(0x01)
	char pad_c1[0xf]; // 0xc1(0x0f)

	bool IsCapturing(); // Function MovieSceneCapture.MovieSceneCaptureProtocolBase.IsCapturing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b29840
	enum class EMovieSceneCaptureProtocolState GetState(); // Function MovieSceneCapture.MovieSceneCaptureProtocolBase.GetState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b1c7c0
};

// Class MovieSceneCapture.MovieSceneAudioCaptureProtocolBase
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneAudioCaptureProtocolBase : UMovieSceneCaptureProtocolBase {
};

// Class MovieSceneCapture.NullAudioCaptureProtocol
// Size: 0xd0 (Inherited: 0xd0)
struct UNullAudioCaptureProtocol : UMovieSceneAudioCaptureProtocolBase {
};

// Class MovieSceneCapture.MasterAudioSubmixCaptureProtocol
// Size: 0x100 (Inherited: 0xd0)
struct UMasterAudioSubmixCaptureProtocol : UMovieSceneAudioCaptureProtocolBase {
	struct FString Filename; // 0xc8(0x10)
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class MovieSceneCapture.MovieSceneImageCaptureProtocolBase
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneImageCaptureProtocolBase : UMovieSceneCaptureProtocolBase {
};

// Class MovieSceneCapture.CompositionGraphCaptureProtocol
// Size: 0x140 (Inherited: 0xd0)
struct UCompositionGraphCaptureProtocol : UMovieSceneImageCaptureProtocolBase {
	struct FCompositionGraphCapturePasses IncludeRenderPasses; // 0xc8(0x10)
	bool bCaptureFramesInHDR; // 0xd8(0x01)
	int32_t HDRCompressionQuality; // 0xdc(0x04)
	enum class EHDRCaptureGamut CaptureGamut; // 0xe0(0x01)
	char pad_e6[0x2]; // 0xe6(0x02)
	struct FSoftObjectPath PostProcessingMaterial; // 0xe8(0x20)
	bool bDisableScreenPercentage; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct UMaterialInterface* PostProcessingMaterialPtr; // 0x110(0x08)
	char pad_118[0x28]; // 0x118(0x28)
};

// Class MovieSceneCapture.MovieSceneCaptureInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneCaptureInterface : UInterface {
};

// Class MovieSceneCapture.FrameGrabberProtocol
// Size: 0xe0 (Inherited: 0xd0)
struct UFrameGrabberProtocol : UMovieSceneImageCaptureProtocolBase {
	char pad_d0[0x10]; // 0xd0(0x10)
};

// Class MovieSceneCapture.ImageSequenceProtocol
// Size: 0x150 (Inherited: 0xe0)
struct UImageSequenceProtocol : UFrameGrabberProtocol {
	char pad_e0[0x70]; // 0xe0(0x70)
};

// Class MovieSceneCapture.CompressedImageSequenceProtocol
// Size: 0x150 (Inherited: 0x150)
struct UCompressedImageSequenceProtocol : UImageSequenceProtocol {
	int32_t CompressionQuality; // 0x148(0x04)
};

// Class MovieSceneCapture.ImageSequenceProtocol_BMP
// Size: 0x150 (Inherited: 0x150)
struct UImageSequenceProtocol_BMP : UImageSequenceProtocol {
};

// Class MovieSceneCapture.ImageSequenceProtocol_PNG
// Size: 0x150 (Inherited: 0x150)
struct UImageSequenceProtocol_PNG : UCompressedImageSequenceProtocol {
};

// Class MovieSceneCapture.ImageSequenceProtocol_JPG
// Size: 0x150 (Inherited: 0x150)
struct UImageSequenceProtocol_JPG : UCompressedImageSequenceProtocol {
};

// Class MovieSceneCapture.ImageSequenceProtocol_EXR
// Size: 0x160 (Inherited: 0x150)
struct UImageSequenceProtocol_EXR : UImageSequenceProtocol {
	bool bCompressed; // 0x148(0x01)
	enum class EHDRCaptureGamut CaptureGamut; // 0x149(0x01)
	char pad_152[0xe]; // 0x152(0x0e)
};

// Class MovieSceneCapture.MovieSceneCapture
// Size: 0x2b0 (Inherited: 0xa0)
struct UMovieSceneCapture : UObject {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct FSoftClassPath ImageCaptureProtocolType; // 0xa8(0x20)
	struct FSoftClassPath AudioCaptureProtocolType; // 0xc8(0x20)
	struct UMovieSceneImageCaptureProtocolBase* ImageCaptureProtocol; // 0xe8(0x08)
	struct UMovieSceneAudioCaptureProtocolBase* AudioCaptureProtocol; // 0xf0(0x08)
	struct FMovieSceneCaptureSettings Settings; // 0xf8(0x70)
	bool bUseSeparateProcess; // 0x168(0x01)
	bool bCloseEditorWhenCaptureStarts; // 0x169(0x01)
	char pad_16a[0x6]; // 0x16a(0x06)
	struct FString AdditionalCommandLineArguments; // 0x170(0x10)
	struct FString InheritedCommandLineArguments; // 0x180(0x10)
	char pad_190[0x120]; // 0x190(0x120)

	void SetImageCaptureProtocolType(struct UMovieSceneCaptureProtocolBase* ProtocolType); // Function MovieSceneCapture.MovieSceneCapture.SetImageCaptureProtocolType // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b114c0
	void SetAudioCaptureProtocolType(struct UMovieSceneCaptureProtocolBase* ProtocolType); // Function MovieSceneCapture.MovieSceneCapture.SetAudioCaptureProtocolType // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b16490
	struct UMovieSceneCaptureProtocolBase* GetImageCaptureProtocol(); // Function MovieSceneCapture.MovieSceneCapture.GetImageCaptureProtocol // (Final|Native|Public|BlueprintCallable) // @ game+0x2b1a2e0
	struct UMovieSceneCaptureProtocolBase* GetAudioCaptureProtocol(); // Function MovieSceneCapture.MovieSceneCapture.GetAudioCaptureProtocol // (Final|Native|Public|BlueprintCallable) // @ game+0x2b14cb0
};

// Class MovieSceneCapture.LevelCapture
// Size: 0x2d0 (Inherited: 0x2b0)
struct ULevelCapture : UMovieSceneCapture {
	bool bAutoStartCapture; // 0x2a8(0x01)
	char pad_2b1[0x3]; // 0x2b1(0x03)
	struct FGuid PrerequisiteActorId; // 0x2b4(0x10)
	char pad_2c4[0xc]; // 0x2c4(0x0c)
};

// Class MovieSceneCapture.MovieSceneCaptureEnvironment
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneCaptureEnvironment : UObject {

	bool IsCaptureInProgress(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.IsCaptureInProgress // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2b27830
	int32_t GetCaptureFrameNumber(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureFrameNumber // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b16090
	float GetCaptureElapsedTime(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.GetCaptureElapsedTime // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x2b19740
	struct UMovieSceneImageCaptureProtocolBase* FindImageCaptureProtocol(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.FindImageCaptureProtocol // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2b27ba0
	struct UMovieSceneAudioCaptureProtocolBase* FindAudioCaptureProtocol(); // Function MovieSceneCapture.MovieSceneCaptureEnvironment.FindAudioCaptureProtocol // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2b1f450
};

// Class MovieSceneCapture.UserDefinedCaptureProtocol
// Size: 0x150 (Inherited: 0xd0)
struct UUserDefinedCaptureProtocol : UMovieSceneImageCaptureProtocolBase {
	struct UWorld* World; // 0xc8(0x08)
	char pad_d8[0x78]; // 0xd8(0x78)

	void StopCapturingFinalPixels(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.StopCapturingFinalPixels // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b22a30
	void StartCapturingFinalPixels(struct FCapturedPixelsID& StreamID); // Function MovieSceneCapture.UserDefinedCaptureProtocol.StartCapturingFinalPixels // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b23de0
	void ResolveBuffer(struct UTexture* Buffer, struct FCapturedPixelsID& BufferID); // Function MovieSceneCapture.UserDefinedCaptureProtocol.ResolveBuffer // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b29690
	void OnWarmUp(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnWarmUp // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnTick(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnStartCapture(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnStartCapture // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool OnSetup(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnSetup // (RequiredAPI|Native|Event|Protected|BlueprintEvent) // @ game+0x2b1c860
	void OnPreTick(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPreTick // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnPixelsReceived(struct FCapturedPixels& Pixels, struct FCapturedPixelsID& ID, struct FFrameMetrics FrameMetrics); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPixelsReceived // (RequiredAPI|Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnPauseCapture(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnPauseCapture // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnFinalize(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnFinalize // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnCaptureFrame(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnCaptureFrame // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool OnCanFinalize(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnCanFinalize // (RequiredAPI|Native|Event|Protected|BlueprintEvent|Const) // @ game+0x2b24420
	void OnBeginFinalize(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.OnBeginFinalize // (RequiredAPI|Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	struct FFrameMetrics GetCurrentFrameMetrics(); // Function MovieSceneCapture.UserDefinedCaptureProtocol.GetCurrentFrameMetrics // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b11330
	struct FString GenerateFilename(struct FFrameMetrics& InFrameMetrics); // Function MovieSceneCapture.UserDefinedCaptureProtocol.GenerateFilename // (RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b1ab10
};

// Class MovieSceneCapture.UserDefinedImageCaptureProtocol
// Size: 0x150 (Inherited: 0x150)
struct UUserDefinedImageCaptureProtocol : UUserDefinedCaptureProtocol {
	enum class EDesiredImageFormat Format; // 0x148(0x01)
	bool bEnableCompression; // 0x149(0x01)
	int32_t CompressionQuality; // 0x14c(0x04)

	void WriteImageToDisk(struct FCapturedPixels& PixelData, struct FCapturedPixelsID& StreamID, struct FFrameMetrics& FrameMetrics, bool bCopyImageData); // Function MovieSceneCapture.UserDefinedImageCaptureProtocol.WriteImageToDisk // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b21770
	struct FString GenerateFilenameForCurrentFrame(); // Function MovieSceneCapture.UserDefinedImageCaptureProtocol.GenerateFilenameForCurrentFrame // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b19e80
	struct FString GenerateFilenameForBuffer(struct UTexture* Buffer, struct FCapturedPixelsID& StreamID); // Function MovieSceneCapture.UserDefinedImageCaptureProtocol.GenerateFilenameForBuffer // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b15290
};

// Class MovieSceneCapture.VideoCaptureProtocol
// Size: 0xf0 (Inherited: 0xe0)
struct UVideoCaptureProtocol : UFrameGrabberProtocol {
	bool bUseCompression; // 0xd8(0x01)
	float CompressionQuality; // 0xdc(0x04)
	char pad_e5[0xb]; // 0xe5(0x0b)
};

