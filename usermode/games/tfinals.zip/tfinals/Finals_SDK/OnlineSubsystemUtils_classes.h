// Class OnlineSubsystemUtils.AchievementBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAchievementBlueprintLibrary : UBlueprintFunctionLibrary {

	void GetCachedAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, float& Progress); // Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementProgress // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x42f8a90
	void GetCachedAchievementDescription(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementID, bool& bFoundID, struct FText& Title, struct FText& LockedDescription, struct FText& UnlockedDescription, bool& bHidden); // Function OnlineSubsystemUtils.AchievementBlueprintLibrary.GetCachedAchievementDescription // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4325990
};

// Class OnlineSubsystemUtils.AchievementQueryCallbackProxy
// Size: 0xe0 (Inherited: 0xa0)
struct UAchievementQueryCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x20]; // 0xc0(0x20)

	struct UAchievementQueryCallbackProxy* CacheAchievements(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievements // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x430caf0
	struct UAchievementQueryCallbackProxy* CacheAchievementDescriptions(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.AchievementQueryCallbackProxy.CacheAchievementDescriptions // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43257a0
};

// Class OnlineSubsystemUtils.AchievementWriteCallbackProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UAchievementWriteCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x30]; // 0xc0(0x30)

	struct UAchievementWriteCallbackProxy* WriteAchievementProgress(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FName AchievementName, float Progress, int32_t UserTag); // Function OnlineSubsystemUtils.AchievementWriteCallbackProxy.WriteAchievementProgress // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43144b0
};

// Class OnlineSubsystemUtils.ConnectionCallbackProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UConnectionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x30]; // 0xc0(0x30)

	struct UConnectionCallbackProxy* ConnectToService(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.ConnectionCallbackProxy.ConnectToService // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x430e5b0
};

// Class OnlineSubsystemUtils.CreateSessionCallbackProxy
// Size: 0x110 (Inherited: 0xa0)
struct UCreateSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x50]; // 0xc0(0x50)

	struct UCreateSessionCallbackProxy* CreateSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t PublicConnections, bool bUseLAN); // Function OnlineSubsystemUtils.CreateSessionCallbackProxy.CreateSession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x42f2cd0
};

// Class OnlineSubsystemUtils.DestroySessionCallbackProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UDestroySessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x30]; // 0xc0(0x30)

	struct UDestroySessionCallbackProxy* DestroySession(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.DestroySessionCallbackProxy.DestroySession // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4301d70
};

// Class OnlineSubsystemUtils.EndMatchCallbackProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UEndMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x30]; // 0xc0(0x30)

	struct UEndMatchCallbackProxy* EndMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, struct FString MatchId, enum class EMPMatchOutcome LocalPlayerOutcome, enum class EMPMatchOutcome OtherPlayersOutcome); // Function OnlineSubsystemUtils.EndMatchCallbackProxy.EndMatch // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x42ff390
};

// Class OnlineSubsystemUtils.EndTurnCallbackProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UEndTurnCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x30]; // 0xc0(0x30)

	struct UEndTurnCallbackProxy* EndTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, struct TScriptInterface<ITurnBasedMatchInterface> TurnBasedMatchInterface); // Function OnlineSubsystemUtils.EndTurnCallbackProxy.EndTurn // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4324db0
};

// Class OnlineSubsystemUtils.FindSessionsCallbackProxy
// Size: 0x100 (Inherited: 0xa0)
struct UFindSessionsCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x40]; // 0xc0(0x40)

	struct FString GetServerName(struct FBlueprintSessionResult& Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetServerName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x42f8ca0
	int32_t GetPingInMs(struct FBlueprintSessionResult& Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetPingInMs // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x430cc30
	int32_t GetMaxPlayers(struct FBlueprintSessionResult& Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetMaxPlayers // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x432c620
	int32_t GetCurrentPlayers(struct FBlueprintSessionResult& Result); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.GetCurrentPlayers // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x43105d0
	struct UFindSessionsCallbackProxy* FindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t MaxResults, bool bUseLAN); // Function OnlineSubsystemUtils.FindSessionsCallbackProxy.FindSessions // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x430c8d0
};

// Class OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy
// Size: 0x100 (Inherited: 0xa0)
struct UFindTurnBasedMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x40]; // 0xc0(0x40)

	struct UFindTurnBasedMatchCallbackProxy* FindTurnBasedMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct TScriptInterface<ITurnBasedMatchInterface> MatchActor, int32_t MinPlayers, int32_t MaxPlayers, int32_t PlayerGroup, bool ShowExistingMatches); // Function OnlineSubsystemUtils.FindTurnBasedMatchCallbackProxy.FindTurnBasedMatch // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43019b0
};

// Class OnlineSubsystemUtils.InAppPurchaseCallbackProxy2
// Size: 0x120 (Inherited: 0xa0)
struct UInAppPurchaseCallbackProxy2 : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x60]; // 0xc0(0x60)

	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchaseUnprocessedPurchases(struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchaseUnprocessedPurchases // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x431d6e0
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchaseQueryOwned(struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchaseQueryOwned // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43041e0
	struct UInAppPurchaseCallbackProxy2* CreateProxyObjectForInAppPurchase(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest2& ProductRequest); // Function OnlineSubsystemUtils.InAppPurchaseCallbackProxy2.CreateProxyObjectForInAppPurchase // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x42f99b0
};

// Class OnlineSubsystemUtils.InAppPurchaseCheckoutCallbackProxy
// Size: 0x110 (Inherited: 0xa0)
struct UInAppPurchaseCheckoutCallbackProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x50]; // 0xc0(0x50)

	struct UInAppPurchaseCheckoutCallbackProxy* CreateProxyObjectForInAppPurchaseCheckout(struct APlayerController* PlayerController, struct FInAppPurchaseProductRequest2& ProductRequest); // Function OnlineSubsystemUtils.InAppPurchaseCheckoutCallbackProxy.CreateProxyObjectForInAppPurchaseCheckout // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x43049a0
};

// Class OnlineSubsystemUtils.InAppPurchaseFinalizeProxy
// Size: 0xa0 (Inherited: 0xa0)
struct UInAppPurchaseFinalizeProxy : UObject {

	struct UInAppPurchaseFinalizeProxy* CreateProxyObjectForInAppPurchaseFinalize(struct FInAppPurchaseReceiptInfo2& InAppPurchaseReceipt, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseFinalizeProxy.CreateProxyObjectForInAppPurchaseFinalize // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4312470
};

// Class OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy2
// Size: 0xe0 (Inherited: 0xa0)
struct UInAppPurchaseQueryCallbackProxy2 : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x20]; // 0xc0(0x20)

	struct UInAppPurchaseQueryCallbackProxy2* CreateProxyObjectForInAppPurchaseQuery(struct APlayerController* PlayerController, struct TArray<struct FString>& ProductIdentifiers); // Function OnlineSubsystemUtils.InAppPurchaseQueryCallbackProxy2.CreateProxyObjectForInAppPurchaseQuery // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4322510
};

// Class OnlineSubsystemUtils.InAppPurchaseReceiptsCallbackProxy
// Size: 0x100 (Inherited: 0xa0)
struct UInAppPurchaseReceiptsCallbackProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x40]; // 0xc0(0x40)

	struct UInAppPurchaseReceiptsCallbackProxy* CreateProxyObjectForInAppPurchaseRestoreOwnedProducts(struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseReceiptsCallbackProxy.CreateProxyObjectForInAppPurchaseRestoreOwnedProducts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x431ece0
	struct UInAppPurchaseReceiptsCallbackProxy* CreateProxyObjectForInAppPurchaseQueryOwnedProducts(struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseReceiptsCallbackProxy.CreateProxyObjectForInAppPurchaseQueryOwnedProducts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43036d0
	struct UInAppPurchaseReceiptsCallbackProxy* CreateProxyObjectForInAppPurchaseGetKnownReceipts(struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseReceiptsCallbackProxy.CreateProxyObjectForInAppPurchaseGetKnownReceipts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4317f90
};

// Class OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy2
// Size: 0x120 (Inherited: 0xa0)
struct UInAppPurchaseRestoreCallbackProxy2 : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x60]; // 0xc0(0x60)

	struct UInAppPurchaseRestoreCallbackProxy2* CreateProxyObjectForInAppPurchaseRestore(struct TArray<struct FInAppPurchaseProductRequest2>& ConsumableProductFlags, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.InAppPurchaseRestoreCallbackProxy2.CreateProxyObjectForInAppPurchaseRestore // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x430d890
};

// Class OnlineSubsystemUtils.IpConnection
// Size: 0x1f00 (Inherited: 0x1e70)
struct UIpConnection : UNetConnection {
	char pad_1e70[0x74]; // 0x1e70(0x74)
	float SocketErrorDisconnectDelay; // 0x1ee4(0x04)
	char pad_1ee8[0x18]; // 0x1ee8(0x18)
};

// Class OnlineSubsystemUtils.IpNetDriver
// Size: 0x8f0 (Inherited: 0x840)
struct UIpNetDriver : UNetDriver {
	char LogPortUnreach : 1; // 0x838(0x01)
	char AllowPlayerPortUnreach : 1; // 0x838(0x01)
	char bExitOnBindFailure : 1; // 0x838(0x01)
	uint32_t MaxPortCountToTry; // 0x83c(0x04)
	uint32_t ServerDesiredSocketReceiveBufferBytes; // 0x844(0x04)
	uint32_t ServerDesiredSocketSendBufferBytes; // 0x848(0x04)
	uint32_t ClientDesiredSocketReceiveBufferBytes; // 0x84c(0x04)
	uint32_t ClientDesiredSocketSendBufferBytes; // 0x850(0x04)
	char pad_854_3 : 5; // 0x854(0x01)
	char pad_855[0x3]; // 0x855(0x03)
	double MaxSecondsInReceive; // 0x858(0x08)
	int32_t NbPacketsBetweenReceiveTimeTest; // 0x860(0x04)
	float ResolutionConnectionTimeout; // 0x864(0x04)
	char pad_868[0x88]; // 0x868(0x88)
};

// Class OnlineSubsystemUtils.JoinSessionCallbackProxy
// Size: 0x210 (Inherited: 0xa0)
struct UJoinSessionCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x150]; // 0xc0(0x150)

	struct UJoinSessionCallbackProxy* JoinSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBlueprintSessionResult& SearchResult); // Function OnlineSubsystemUtils.JoinSessionCallbackProxy.JoinSession // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x43211b0
};

// Class OnlineSubsystemUtils.LeaderboardBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULeaderboardBlueprintLibrary : UBlueprintFunctionLibrary {

	bool WriteLeaderboardInteger(struct APlayerController* PlayerController, struct FName StatName, int32_t StatValue); // Function OnlineSubsystemUtils.LeaderboardBlueprintLibrary.WriteLeaderboardInteger // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43178b0
};

// Class OnlineSubsystemUtils.LeaderboardFlushCallbackProxy
// Size: 0xe0 (Inherited: 0xa0)
struct ULeaderboardFlushCallbackProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x20]; // 0xc0(0x20)

	struct ULeaderboardFlushCallbackProxy* CreateProxyObjectForFlush(struct APlayerController* PlayerController, struct FName SessionName); // Function OnlineSubsystemUtils.LeaderboardFlushCallbackProxy.CreateProxyObjectForFlush // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43168d0
};

// Class OnlineSubsystemUtils.LeaderboardQueryCallbackProxy
// Size: 0x110 (Inherited: 0xa0)
struct ULeaderboardQueryCallbackProxy : UObject {
	struct FMulticastInlineDelegate OnSuccess; // 0x98(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xa8(0x10)
	char pad_c0[0x50]; // 0xc0(0x50)

	struct ULeaderboardQueryCallbackProxy* CreateProxyObjectForIntQuery(struct APlayerController* PlayerController, struct FName StatName); // Function OnlineSubsystemUtils.LeaderboardQueryCallbackProxy.CreateProxyObjectForIntQuery // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x430eb50
};

// Class OnlineSubsystemUtils.LogoutCallbackProxy
// Size: 0xe0 (Inherited: 0xa0)
struct ULogoutCallbackProxy : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x20]; // 0xc0(0x20)

	struct ULogoutCallbackProxy* Logout(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function OnlineSubsystemUtils.LogoutCallbackProxy.Logout // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x42f5d00
};

// Class OnlineSubsystemUtils.OnlineBeacon
// Size: 0x3d0 (Inherited: 0x3a0)
struct AOnlineBeacon : AActor {
	float BeaconConnectionInitialTimeout; // 0x3a0(0x04)
	float BeaconConnectionTimeout; // 0x3a4(0x04)
	struct UNetDriver* NetDriver; // 0x3a8(0x08)
	char pad_3b0[0x20]; // 0x3b0(0x20)
};

// Class OnlineSubsystemUtils.OnlineBeaconClient
// Size: 0x430 (Inherited: 0x3d0)
struct AOnlineBeaconClient : AOnlineBeacon {
	struct AOnlineBeaconHostObject* BeaconOwner; // 0x3c8(0x08)
	struct UNetConnection* BeaconConnection; // 0x3d0(0x08)
	enum class EBeaconConnectionState ConnectionState; // 0x3d8(0x01)
	char pad_3e1[0x4f]; // 0x3e1(0x4f)

	void ClientOnConnected(); // Function OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x2c82670
};

// Class OnlineSubsystemUtils.OnlineBeaconHost
// Size: 0x4e0 (Inherited: 0x3d0)
struct AOnlineBeaconHost : AOnlineBeacon {
	int32_t ListenPort; // 0x3c8(0x04)
	bool bReuseAddressAndPort; // 0x3cc(0x01)
	bool bAuthRequired; // 0x3cd(0x01)
	uint32_t MaxAuthTokenSize; // 0x3d0(0x04)
	char pad_3da[0x4e]; // 0x3da(0x4e)
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // 0x428(0x10)
	char pad_438[0xa8]; // 0x438(0xa8)
};

// Class OnlineSubsystemUtils.OnlineBeaconHostObject
// Size: 0x3c0 (Inherited: 0x3a0)
struct AOnlineBeaconHostObject : AActor {
	struct FString BeaconTypeName; // 0x398(0x10)
	struct AOnlineBeaconClient* ClientBeaconActorClass; // 0x3a8(0x08)
	struct TArray<struct AOnlineBeaconClient*> ClientActors; // 0x3b0(0x10)
};

// Class OnlineSubsystemUtils.OnlineEngineInterfaceImpl
// Size: 0x200 (Inherited: 0xa0)
struct UOnlineEngineInterfaceImpl : UOnlineEngineInterface {
	struct TMap<struct FName, struct FName> MappedUniqueNetIdTypes; // 0x98(0x50)
	struct TArray<struct FName> CompatibleUniqueNetIdTypes; // 0xe8(0x10)
	struct FName VoiceSubsystemNameOverride; // 0xf8(0x08)
	char pad_108[0xf8]; // 0x108(0xf8)
};

// Class OnlineSubsystemUtils.OnlinePIESettings
// Size: 0xc0 (Inherited: 0xb0)
struct UOnlinePIESettings : UDeveloperSettings {
	bool bOnlinePIEEnabled; // 0xa8(0x01)
	struct TArray<struct FPIELoginSettingsInternal> Logins; // 0xb0(0x10)
};

// Class OnlineSubsystemUtils.OnlineServicesEngineInterfaceImpl
// Size: 0xa0 (Inherited: 0xa0)
struct UOnlineServicesEngineInterfaceImpl : UOnlineEngineInterface {
};

// Class OnlineSubsystemUtils.OnlineSessionClient
// Size: 0x250 (Inherited: 0xa0)
struct UOnlineSessionClient : UOnlineSession {
	char pad_a0[0x1a8]; // 0xa0(0x1a8)
	bool bIsFromInvite; // 0x248(0x01)
	bool bHandlingDisconnect; // 0x249(0x01)
	char pad_24a[0x6]; // 0x24a(0x06)
};

// Class OnlineSubsystemUtils.PartyBeaconClient
// Size: 0x4f0 (Inherited: 0x430)
struct APartyBeaconClient : AOnlineBeaconClient {
	char pad_430[0x28]; // 0x430(0x28)
	struct FString DestSessionId; // 0x458(0x10)
	struct FPartyReservation PendingReservation; // 0x468(0x58)
	enum class EClientRequestType RequestType; // 0x4c0(0x01)
	bool bPendingReservationSent; // 0x4c1(0x01)
	bool bCancelReservation; // 0x4c2(0x01)
	char pad_4c3[0x2d]; // 0x4c3(0x2d)

	void ServerUpdateReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerUpdateReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4336a90
	void ServerReservationRequest(struct FString SessionId, struct FPartyReservation Reservation); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4341880
	void ServerRemoveMemberFromReservationRequest(struct FString SessionId, struct FPartyReservation ReservationUpdate); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerRemoveMemberFromReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x43346a0
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl PartyLeader); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerCancelReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x43398a0
	void ServerAddOrUpdateReservationRequest(struct FString SessionId, struct FPartyReservation Reservation); // Function OnlineSubsystemUtils.PartyBeaconClient.ServerAddOrUpdateReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x4343ab0
	void ClientSendReservationUpdates(int32_t NumRemainingReservations); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationUpdates // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x43337a0
	void ClientSendReservationFull(); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientSendReservationFull // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x4344410
	void ClientReservationResponse(enum class EPartyReservationResult ReservationResponse); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientReservationResponse // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x43343c0
	void ClientCancelReservationResponse(enum class EPartyReservationResult ReservationResponse); // Function OnlineSubsystemUtils.PartyBeaconClient.ClientCancelReservationResponse // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x433b1e0
};

// Class OnlineSubsystemUtils.PartyBeaconHost
// Size: 0x440 (Inherited: 0x3c0)
struct APartyBeaconHost : AOnlineBeaconHostObject {
	struct UPartyBeaconState* State; // 0x3c0(0x08)
	char pad_3c8[0x60]; // 0x3c8(0x60)
	bool bLogoutOnSessionTimeout; // 0x428(0x01)
	bool bIsValidationStrRequired; // 0x429(0x01)
	char pad_42a[0x2]; // 0x42a(0x02)
	float SessionTimeoutSecs; // 0x42c(0x04)
	float TravelSessionTimeoutSecs; // 0x430(0x04)
	char pad_434[0xc]; // 0x434(0x0c)
};

// Class OnlineSubsystemUtils.PartyBeaconState
// Size: 0x110 (Inherited: 0xa0)
struct UPartyBeaconState : UObject {
	struct FName SessionName; // 0x98(0x08)
	int32_t NumConsumedReservations; // 0xa0(0x04)
	int32_t MaxReservations; // 0xa4(0x04)
	int32_t NumTeams; // 0xa8(0x04)
	int32_t NumPlayersPerTeam; // 0xac(0x04)
	struct FName TeamAssignmentMethod; // 0xb0(0x08)
	int32_t ReservedHostTeamNum; // 0xb8(0x04)
	int32_t ForceTeamNum; // 0xbc(0x04)
	bool bRestrictCrossConsole; // 0xc0(0x01)
	struct TArray<struct FString> PlatformCrossplayRestrictions; // 0xc8(0x10)
	struct TArray<struct FPartyBeaconCrossplayPlatformMapping> PlatformTypeMapping; // 0xd8(0x10)
	bool bEnableRemovalRequests; // 0xe8(0x01)
	bool bRespectCompetitiveIntegrity; // 0xe9(0x01)
	char pad_eb[0x5]; // 0xeb(0x05)
	struct TArray<struct FPartyReservation> Reservations; // 0xf0(0x10)
	char pad_100[0x10]; // 0x100(0x10)
};

// Class OnlineSubsystemUtils.QuitMatchCallbackProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UQuitMatchCallbackProxy : UOnlineBlueprintCallProxyBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x30]; // 0xc0(0x30)

	struct UQuitMatchCallbackProxy* QuitMatch(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, enum class EMPMatchOutcome Outcome, int32_t TurnTimeoutInSeconds); // Function OnlineSubsystemUtils.QuitMatchCallbackProxy.QuitMatch // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43456c0
};

// Class OnlineSubsystemUtils.ShowLoginUICallbackProxy
// Size: 0xd0 (Inherited: 0xa0)
struct UShowLoginUICallbackProxy : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnFailure; // 0xb0(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)

	struct UShowLoginUICallbackProxy* ShowExternalLoginUI(struct UObject* WorldContextObject, struct APlayerController* InPlayerController); // Function OnlineSubsystemUtils.ShowLoginUICallbackProxy.ShowExternalLoginUI // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43436d0
};

// Class OnlineSubsystemUtils.SpectatorBeaconClient
// Size: 0x520 (Inherited: 0x430)
struct ASpectatorBeaconClient : AOnlineBeaconClient {
	char pad_430[0x28]; // 0x430(0x28)
	struct FString DestSessionId; // 0x458(0x10)
	struct FSpectatorReservation PendingReservation; // 0x468(0x88)
	enum class ESpectatorClientRequestType RequestType; // 0x4f0(0x01)
	bool bPendingReservationSent; // 0x4f1(0x01)
	bool bCancelReservation; // 0x4f2(0x01)
	char pad_4f3[0x2d]; // 0x4f3(0x2d)

	void ServerReservationRequest(struct FString SessionId, struct FSpectatorReservation Reservation); // Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x432e250
	void ServerCancelReservationRequest(struct FUniqueNetIdRepl Spectator); // Function OnlineSubsystemUtils.SpectatorBeaconClient.ServerCancelReservationRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x43398a0
	void ClientSendReservationUpdates(int32_t NumRemainingReservations); // Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationUpdates // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x434d890
	void ClientSendReservationFull(); // Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientSendReservationFull // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x30de940
	void ClientReservationResponse(enum class ESpectatorReservationResult ReservationResponse); // Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientReservationResponse // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x4335ce0
	void ClientCancelReservationResponse(enum class ESpectatorReservationResult ReservationResponse); // Function OnlineSubsystemUtils.SpectatorBeaconClient.ClientCancelReservationResponse // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x4344510
};

// Class OnlineSubsystemUtils.SpectatorBeaconHost
// Size: 0x440 (Inherited: 0x3c0)
struct ASpectatorBeaconHost : AOnlineBeaconHostObject {
	struct USpectatorBeaconState* State; // 0x3c0(0x08)
	char pad_3c8[0x60]; // 0x3c8(0x60)
	bool bLogoutOnSessionTimeout; // 0x428(0x01)
	bool bIsValidationStrRequired; // 0x429(0x01)
	char pad_42a[0x2]; // 0x42a(0x02)
	float SessionTimeoutSecs; // 0x42c(0x04)
	float TravelSessionTimeoutSecs; // 0x430(0x04)
	char pad_434[0xc]; // 0x434(0x0c)
};

// Class OnlineSubsystemUtils.SpectatorBeaconState
// Size: 0xd0 (Inherited: 0xa0)
struct USpectatorBeaconState : UObject {
	struct FName SessionName; // 0x98(0x08)
	int32_t NumConsumedReservations; // 0xa0(0x04)
	int32_t MaxReservations; // 0xa4(0x04)
	bool bRestrictCrossConsole; // 0xa8(0x01)
	struct TArray<struct FSpectatorReservation> Reservations; // 0xb0(0x10)
	char pad_c1[0xf]; // 0xc1(0x0f)
};

// Class OnlineSubsystemUtils.TestBeaconClient
// Size: 0x430 (Inherited: 0x430)
struct ATestBeaconClient : AOnlineBeaconClient {

	void ServerPong(); // Function OnlineSubsystemUtils.TestBeaconClient.ServerPong // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x433e2f0
	void ClientPing(); // Function OnlineSubsystemUtils.TestBeaconClient.ClientPing // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x3631570
};

// Class OnlineSubsystemUtils.TestBeaconHost
// Size: 0x3c0 (Inherited: 0x3c0)
struct ATestBeaconHost : AOnlineBeaconHostObject {
};

// Class OnlineSubsystemUtils.TurnBasedBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UTurnBasedBlueprintLibrary : UBlueprintFunctionLibrary {

	void RegisterTurnBasedMatchInterfaceObject(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct UObject* Object); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.RegisterTurnBasedMatchInterfaceObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x43405e0
	void GetPlayerDisplayName(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, int32_t PlayerIndex, struct FString& PlayerDisplayName); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetPlayerDisplayName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x433c760
	void GetMyPlayerIndex(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, int32_t& PlayerIndex); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetMyPlayerIndex // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4347bd0
	void GetIsMyTurn(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString MatchId, bool& bIsMyTurn); // Function OnlineSubsystemUtils.TurnBasedBlueprintLibrary.GetIsMyTurn // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4350ba0
};

// Class OnlineSubsystemUtils.VoipListenerSynthComponent
// Size: 0xa80 (Inherited: 0xa20)
struct UVoipListenerSynthComponent : USynthComponent {
	char pad_a20[0x60]; // 0xa20(0x60)

	bool IsIdling(); // Function OnlineSubsystemUtils.VoipListenerSynthComponent.IsIdling // (Final|Native|Public|BlueprintCallable) // @ game+0x4356d10
};

