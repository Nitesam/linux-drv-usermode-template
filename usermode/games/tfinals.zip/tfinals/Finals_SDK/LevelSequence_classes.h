// Class LevelSequence.DefaultLevelSequenceInstanceData
// Size: 0x110 (Inherited: 0xa0)
struct UDefaultLevelSequenceInstanceData : UObject {
	struct AActor* TransformOriginActor; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
	struct FTransform TransformOrigin; // 0xb0(0x60)
};

// Class LevelSequence.AnimSequenceLevelSequenceLink
// Size: 0xd0 (Inherited: 0xa0)
struct UAnimSequenceLevelSequenceLink : UAssetUserData {
	struct FGuid SkelTrackGuid; // 0x98(0x10)
	struct FSoftObjectPath PathToLevelSequence; // 0xa8(0x20)
};

// Class LevelSequence.LevelSequence
// Size: 0x290 (Inherited: 0xe0)
struct ULevelSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0xe0(0x08)
	struct FLevelSequenceObjectReferenceMap ObjectReferences; // 0xe8(0x50)
	struct FLevelSequenceBindingReferences BindingReferences; // 0x138(0xf0)
	struct TMap<struct FString, struct FLevelSequenceObject> PossessedObjects; // 0x228(0x50)
	ClassPtrProperty DirectorClass; // 0x278(0x08)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x280(0x10)

	void RemoveMetaDataByClass(struct UObject* InClass); // Function LevelSequence.LevelSequence.RemoveMetaDataByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x257bb60
	struct UObject* FindOrAddMetaDataByClass(struct UObject* InClass); // Function LevelSequence.LevelSequence.FindOrAddMetaDataByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x2b7ec50
	struct UObject* FindMetaDataByClass(struct UObject* InClass); // Function LevelSequence.LevelSequence.FindMetaDataByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b7ec50
	struct UObject* CopyMetaData(struct UObject* InMetaData); // Function LevelSequence.LevelSequence.CopyMetaData // (Final|Native|Public|BlueprintCallable) // @ game+0x2b7ec50
};

// Class LevelSequence.LevelSequenceBurnInInitSettings
// Size: 0xa0 (Inherited: 0xa0)
struct ULevelSequenceBurnInInitSettings : UObject {
};

// Class LevelSequence.LevelSequenceBurnInOptions
// Size: 0xd0 (Inherited: 0xa0)
struct ULevelSequenceBurnInOptions : UObject {
	bool bUseBurnIn; // 0x98(0x01)
	struct FSoftClassPath BurnInClass; // 0xa0(0x20)
	struct ULevelSequenceBurnInInitSettings* Settings; // 0xc0(0x08)
	char pad_c9[0x7]; // 0xc9(0x07)

	void SetBurnIn(struct FSoftClassPath InBurnInClass); // Function LevelSequence.LevelSequenceBurnInOptions.SetBurnIn // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x2b7e820
};

// Class LevelSequence.LevelSequenceActor
// Size: 0x440 (Inherited: 0x3a0)
struct ALevelSequenceActor : AActor {
	char pad_3a0[0x10]; // 0x3a0(0x10)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x3b0(0x20)
	struct ULevelSequencePlayer* SequencePlayer; // 0x3d0(0x08)
	struct ULevelSequence* LevelSequenceAsset; // 0x3d8(0x08)
	struct FLevelSequenceCameraSettings CameraSettings; // 0x3e0(0x02)
	char pad_3e2[0x6]; // 0x3e2(0x06)
	struct ULevelSequenceBurnInOptions* BurnInOptions; // 0x3e8(0x08)
	struct UMovieSceneBindingOverrides* BindingOverrides; // 0x3f0(0x08)
	char bAutoPlay : 1; // 0x3f8(0x01)
	char bOverrideInstanceData : 1; // 0x3f8(0x01)
	char bReplicatePlayback : 1; // 0x3f8(0x01)
	char pad_3f8_3 : 5; // 0x3f8(0x01)
	char pad_3f9[0x7]; // 0x3f9(0x07)
	struct UObject* DefaultInstanceData; // 0x400(0x08)
	struct ULevelSequenceBurnIn* BurnInInstance; // 0x408(0x08)
	bool bShowBurnin; // 0x410(0x01)
	char pad_411[0x7]; // 0x411(0x07)
	struct FWorldPartitionResolveData WorldPartitionResolveData; // 0x418(0x20)
	char pad_438[0x8]; // 0x438(0x08)

	void ShowBurnin(); // Function LevelSequence.LevelSequenceActor.ShowBurnin // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b750e0
	void SetSequence(struct ULevelSequence* InSequence); // Function LevelSequence.LevelSequenceActor.SetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b812f0
	void SetReplicatePlayback(bool ReplicatePlayback); // Function LevelSequence.LevelSequenceActor.SetReplicatePlayback // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b7b720
	void SetBindingByTag(struct FName BindingTag, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.SetBindingByTag // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b8a350
	void SetBinding(struct FMovieSceneObjectBindingID Binding, struct TArray<struct AActor*>& Actors, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.SetBinding // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2b7c590
	void ResetBindings(); // Function LevelSequence.LevelSequenceActor.ResetBindings // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b89c40
	void ResetBinding(struct FMovieSceneObjectBindingID Binding); // Function LevelSequence.LevelSequenceActor.ResetBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b74cc0
	void RemoveBindingByTag(struct FName Tag, struct AActor* Actor); // Function LevelSequence.LevelSequenceActor.RemoveBindingByTag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b885e0
	void RemoveBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor); // Function LevelSequence.LevelSequenceActor.RemoveBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b77360
	void OnLevelSequenceLoaded__DelegateSignature(); // DelegateFunction LevelSequence.LevelSequenceActor.OnLevelSequenceLoaded__DelegateSignature // (Public|Delegate) // @ game+0x4abfe0
	void HideBurnin(); // Function LevelSequence.LevelSequenceActor.HideBurnin // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b82750
	struct ULevelSequencePlayer* GetSequencePlayer(); // Function LevelSequence.LevelSequenceActor.GetSequencePlayer // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b828f0
	struct ULevelSequence* GetSequence(); // Function LevelSequence.LevelSequenceActor.GetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b80010
	struct TArray<struct FMovieSceneObjectBindingID> FindNamedBindings(struct FName Tag); // Function LevelSequence.LevelSequenceActor.FindNamedBindings // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b8b040
	struct FMovieSceneObjectBindingID FindNamedBinding(struct FName Tag); // Function LevelSequence.LevelSequenceActor.FindNamedBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b8b3a0
	void AddBindingByTag(struct FName BindingTag, struct AActor* Actor, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.AddBindingByTag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b75cf0
	void AddBinding(struct FMovieSceneObjectBindingID Binding, struct AActor* Actor, bool bAllowBindingsFromAsset); // Function LevelSequence.LevelSequenceActor.AddBinding // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b822f0
};

// Class LevelSequence.ReplicatedLevelSequenceActor
// Size: 0x440 (Inherited: 0x440)
struct AReplicatedLevelSequenceActor : ALevelSequenceActor {
};

// Class LevelSequence.LevelSequenceAnimSequenceLink
// Size: 0xb0 (Inherited: 0xa0)
struct ULevelSequenceAnimSequenceLink : UAssetUserData {
	struct TArray<struct FLevelSequenceAnimSequenceLinkItem> AnimSequenceLinks; // 0x98(0x10)
};

// Class LevelSequence.LevelSequenceBurnIn
// Size: 0x420 (Inherited: 0x350)
struct ULevelSequenceBurnIn : UUserWidget {
	struct FLevelSequencePlayerSnapshot FrameInformation; // 0x348(0xc8)
	struct ALevelSequenceActor* LevelSequenceActor; // 0x410(0x08)

	void SetSettings(struct UObject* InSettings); // Function LevelSequence.LevelSequenceBurnIn.SetSettings // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct ULevelSequenceBurnInInitSettings* GetSettingsClass(); // Function LevelSequence.LevelSequenceBurnIn.GetSettingsClass // (RequiredAPI|Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b858e0
};

// Class LevelSequence.LevelSequenceDirector
// Size: 0xb0 (Inherited: 0xa0)
struct ULevelSequenceDirector : UObject {
	struct ULevelSequencePlayer* Player; // 0x98(0x08)
	int32_t SubSequenceID; // 0xa0(0x04)
	int32_t MovieScenePlayerIndex; // 0xa4(0x04)

	void OnCreated(); // Function LevelSequence.LevelSequenceDirector.OnCreated // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UMovieSceneSequence* GetSequence(); // Function LevelSequence.LevelSequenceDirector.GetSequence // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b8cec0
	struct FQualifiedFrameTime GetRootSequenceTime(); // Function LevelSequence.LevelSequenceDirector.GetRootSequenceTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b709f0
	struct FQualifiedFrameTime GetMasterSequenceTime(); // Function LevelSequence.LevelSequenceDirector.GetMasterSequenceTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b709f0
	struct FQualifiedFrameTime GetCurrentTime(); // Function LevelSequence.LevelSequenceDirector.GetCurrentTime // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b76ad0
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundObjects // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b761f0
	struct UObject* GetBoundObject(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundObject // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b72b80
	struct TArray<struct AActor*> GetBoundActors(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundActors // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b72cd0
	struct AActor* GetBoundActor(struct FMovieSceneObjectBindingID ObjectBinding); // Function LevelSequence.LevelSequenceDirector.GetBoundActor // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b86b60
};

// Class LevelSequence.LegacyLevelSequenceDirectorBlueprint
// Size: 0x120 (Inherited: 0x120)
struct ULegacyLevelSequenceDirectorBlueprint : UBlueprint {
};

// Class LevelSequence.LevelSequencePlayer
// Size: 0x680 (Inherited: 0x540)
struct ULevelSequencePlayer : UMovieSceneSequencePlayer {
	struct FMulticastInlineDelegate OnCameraCut; // 0x538(0x10)
	char pad_550[0x130]; // 0x550(0x130)

	struct UCameraComponent* GetActiveCameraComponent(); // Function LevelSequence.LevelSequencePlayer.GetActiveCameraComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b7afa0
	struct ULevelSequencePlayer* CreateLevelSequencePlayer(struct UObject* WorldContextObject, struct ULevelSequence* LevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor*& OutActor); // Function LevelSequence.LevelSequencePlayer.CreateLevelSequencePlayer // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x2b7d280
};

// Class LevelSequence.LevelSequenceProjectSettings
// Size: 0xe0 (Inherited: 0xb0)
struct ULevelSequenceProjectSettings : UDeveloperSettings {
	bool bDefaultLockEngineToDisplayRate; // 0xa8(0x01)
	struct FString DefaultDisplayRate; // 0xb0(0x10)
	struct FString DefaultTickResolution; // 0xc0(0x10)
	enum class EUpdateClockSource DefaultClockSource; // 0xd0(0x01)
	char pad_d2[0xe]; // 0xd2(0x0e)
};

// Class LevelSequence.LevelSequenceMediaController
// Size: 0x3c0 (Inherited: 0x3a0)
struct ALevelSequenceMediaController : AActor {
	struct ALevelSequenceActor* Sequence; // 0x3a0(0x08)
	struct UMediaComponent* MediaComponent; // 0x3a8(0x08)
	float ServerStartTimeSeconds; // 0x3b0(0x04)
	char pad_3b4[0xc]; // 0x3b4(0x0c)

	void SynchronizeToServer(float DesyncThresholdSeconds); // Function LevelSequence.LevelSequenceMediaController.SynchronizeToServer // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b7ab10
	void Play(); // Function LevelSequence.LevelSequenceMediaController.Play // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b7fff0
	void OnRep_ServerStartTimeSeconds(); // Function LevelSequence.LevelSequenceMediaController.OnRep_ServerStartTimeSeconds // (Final|RequiredAPI|Native|Private) // @ game+0x2b7ea90
	struct ALevelSequenceActor* GetSequence(); // Function LevelSequence.LevelSequenceMediaController.GetSequence // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b74dd0
	struct UMediaComponent* GetMediaComponent(); // Function LevelSequence.LevelSequenceMediaController.GetMediaComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a6c9b0
};

