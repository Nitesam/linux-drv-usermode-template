// Enum EmbarkUtils.EEmbarkHardwareBreakpointTypes
enum class EEmbarkHardwareBreakpointTypes : uint8_t {
	InstructionExecutionOnly = 0,
	WritesOnly = 1,
	ReadAndWrites = 2,
	EEmbarkHardwareBreakpointTypes_MAX = 3
};

// Enum EmbarkUtils.EEmbarkHardwareBreakpointConditions
enum class EEmbarkHardwareBreakpointConditions : uint8_t {
	None = 0,
	Equal = 1,
	NotEqual = 2,
	GreaterThan = 3,
	GreaterThanEqual = 4,
	LessThan = 5,
	LessThanEqual = 6,
	EEmbarkHardwareBreakpointConditions_MAX = 7
};

// Enum EmbarkUtils.EEmbarkLogVerbosity
enum class EEmbarkLogVerbosity : uint8_t {
	NoLogging = 0,
	Fatal = 1,
	Error = 2,
	Warning = 3,
	Display = 4,
	Log = 5,
	Verbose = 6,
	VeryVerbose = 7,
	EEmbarkLogVerbosity_MAX = 8
};

// Enum EmbarkUtils.EEmbarkBallisticPredictionResult
enum class EEmbarkBallisticPredictionResult : uint8_t {
	TooFar = 0,
	PathBlocked = 1,
	DirectHit = 2,
	EEmbarkBallisticPredictionResult_MAX = 3
};

// Enum EmbarkUtils.EEmbarkTeamId
enum class EEmbarkTeamId : uint8_t {
	Team1 = 0,
	Team2 = 1,
	Team3 = 2,
	NoTeam = 255,
	EEmbarkTeamId_MAX = 256
};

// Enum EmbarkUtils.EEmbarkPropertyTypes
enum class EEmbarkPropertyTypes : uint8_t {
	INVALID = 0,
	Int8Property = 1,
	Int16Property = 2,
	Int32Property = 3,
	Int64Property = 4,
	UnsignedInt16Property = 5,
	UnsignedInt32Property = 6,
	UnsignedInt64Property = 7,
	ByteProperty = 8,
	EnumProperty = 9,
	Float32Property = 10,
	Float64Property = 11,
	BoolProperty = 12,
	ObjectProperty = 13,
	ClassProperty = 14,
	InterfaceProperty = 15,
	StringProperty = 16,
	NameProperty = 17,
	SoftObjectProperty = 18,
	FieldPathProperty = 19,
	SoftClassProperty = 20,
	TextProperty = 21,
	VectorProperty = 22,
	RotatorProperty = 23,
	LinearColorProperty = 24,
	ColorProperty = 25,
	TransformProperty = 26,
	GameplayTagProperty = 27,
	ArrayProperty = 28,
	MapProperty = 29,
	UnhandledStructProperty = 30,
	EEmbarkPropertyTypes_MAX = 31
};

// ScriptStruct EmbarkUtils.EmbarkTickLimitResult
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkTickLimitResult {
	float Wait; // 0x00(0x04)
	bool bContinue; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	float ExplicitCost; // 0x08(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkOctreeElement
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkOctreeElement {
	struct FEmbarkOctreeDataHandle Handle; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FBoxSphereBounds Bounds; // 0x08(0x38)
};

// ScriptStruct EmbarkUtils.EmbarkOctreeDataHandle
// Size: 0x04 (Inherited: 0x00)
struct FEmbarkOctreeDataHandle {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkHardwareBreakpointInfo
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkHardwareBreakpointInfo {
	struct UObject* MonitoredObject; // 0x00(0x08)
	struct FString MonitoredProperty; // 0x08(0x10)
	int32_t TriggersLeft; // 0x18(0x04)
	int32_t BreakpointHandle; // 0x1c(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkGenericOctree
// Size: 0xb8 (Inherited: 0x00)
struct FEmbarkGenericOctree {
	char pad_0[0x18]; // 0x00(0x18)
	struct TMap<struct FEmbarkOctreeDataHandle, struct FEmbarkScriptStruct> DataCollection; // 0x18(0x50)
	char pad_68[0x50]; // 0x68(0x50)
};

// ScriptStruct EmbarkUtils.EmbarkGenericStruct
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkGenericStruct {
	struct FEmbarkScriptStruct ActualStruct; // 0x00(0x18)
};

// ScriptStruct EmbarkUtils.EmbarkDuplicationLog
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkDuplicationLog {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct EmbarkUtils.EmbarkDuplicationLogCallstack
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkDuplicationLogCallstack {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct EmbarkUtils.EmbarkIntercept
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkIntercept {
	struct FVector Location; // 0x00(0x18)
	float TimeToHitSecs; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkBallisticPredictionInput
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkBallisticPredictionInput {
	float ProjectileSpeedCmPerSec; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector ProjectileInitialLocation; // 0x08(0x18)
	struct FVector ProjectileConstantAcceleration; // 0x20(0x18)
	struct FVector TargetLocation; // 0x38(0x18)
	struct FVector TargetConstantVelocity; // 0x50(0x18)
	struct FVector TargetConstantAcceleration; // 0x68(0x18)
};

// ScriptStruct EmbarkUtils.EmbarkBallisticPredictionOutput
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkBallisticPredictionOutput {
	struct FVector NecessaryDirection; // 0x00(0x18)
	struct FEmbarkIntercept Intercept; // 0x18(0x20)
};

// ScriptStruct EmbarkUtils.EmbarkBallisticTraceInput
// Size: 0x70 (Inherited: 0x00)
struct FEmbarkBallisticTraceInput {
	enum class ECollisionChannel TraceChannel; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct AActor*> IgnoredActors; // 0x08(0x10)
	int32_t MaxNrSteps; // 0x18(0x04)
	float StepSizeSecs; // 0x1c(0x04)
	float ProjectileRadiusCm; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct FVector ProjectileInitialLocation; // 0x28(0x18)
	struct FVector ProjectileConstantVelocity; // 0x40(0x18)
	struct FVector ProjectileConstantAcceleration; // 0x58(0x18)
};

// ScriptStruct EmbarkUtils.FloatModifierOverrideList
// Size: 0x68 (Inherited: 0x00)
struct FFloatModifierOverrideList {
	char pad_0[0x68]; // 0x00(0x68)
};

// ScriptStruct EmbarkUtils.EmbarkAttachedStaticMeshDesc
// Size: 0xd0 (Inherited: 0x00)
struct FEmbarkAttachedStaticMeshDesc {
	struct UStaticMesh* StaticMesh; // 0x00(0x08)
	struct TMap<struct FName, struct FStaticMaterial> MaterialOverrides; // 0x08(0x50)
	struct FName SocketName; // 0x58(0x08)
	struct FTransform RelativeTransform; // 0x60(0x60)
	bool bCastShadow; // 0xc0(0x01)
	char pad_c1[0xf]; // 0xc1(0x0f)
};

// ScriptStruct EmbarkUtils.EmbarkMeshMergeDesc
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkMeshMergeDesc {
	struct USkeleton* Skeleton; // 0x00(0x08)
	struct USkeletalMesh* RootMesh; // 0x08(0x08)
	struct TArray<struct USkeletalMesh*> MeshesToMerge; // 0x10(0x10)
	struct TArray<struct FEmbarkAttachedStaticMeshDesc> AttachedStaticMeshes; // 0x20(0x10)
	struct TArray<struct FName> MorphTargetsToMerge; // 0x30(0x10)
	struct TArray<struct FName> MorphTargetsToWriteStencil; // 0x40(0x10)
	struct TArray<int32_t> DisableClothIndices; // 0x50(0x10)
	struct UPhysicsAsset* PhysicsAsset; // 0x60(0x08)
	struct UAnimInstance* PostProcessAnim; // 0x68(0x08)
	int32_t MaxNumLODsToMerge; // 0x70(0x04)
	int32_t MinLODIndexToMerge; // 0x74(0x04)
	float Scale; // 0x78(0x04)
	bool bPreMergeSkeleton; // 0x7c(0x01)
	bool bMergeDisabledSections; // 0x7d(0x01)
	char pad_7e[0x2]; // 0x7e(0x02)
};

// ScriptStruct EmbarkUtils.EmbarkMassProperties
// Size: 0x70 (Inherited: 0x00)
struct FEmbarkMassProperties {
	float Mass; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector CenterOfMass; // 0x08(0x18)
	struct FVector LocalCenterOfMass; // 0x20(0x18)
	struct FVector MassSpaceInertiaTensor; // 0x38(0x18)
	struct FQuat MassFrame; // 0x50(0x20)
};

// ScriptStruct EmbarkUtils.EmbarkProjectionData
// Size: 0x1c0 (Inherited: 0x00)
struct FEmbarkProjectionData {
	char pad_0[0x1c0]; // 0x00(0x1c0)
};

// ScriptStruct EmbarkUtils.EmbarkWidgetProjectionData
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkWidgetProjectionData {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct EmbarkUtils.WarpCurvesDefinition
// Size: 0x20 (Inherited: 0x00)
struct FWarpCurvesDefinition {
	struct FName WarpTranslationHorizontalCurveName; // 0x00(0x08)
	struct FName WarpTranslationVerticalCurveName; // 0x08(0x08)
	struct FName WarpRotationCurveName; // 0x10(0x08)
	struct FName WarpUprightCurveName; // 0x18(0x08)
};

// ScriptStruct EmbarkUtils.WarpCurvesValue
// Size: 0x10 (Inherited: 0x00)
struct FWarpCurvesValue {
	float WarpTranslationHorizontal; // 0x00(0x04)
	float WarpTranslationVertical; // 0x04(0x04)
	float WarpRotation; // 0x08(0x04)
	float WarpUpright; // 0x0c(0x04)
};

// ScriptStruct EmbarkUtils.RootMotionAnimMatching_PointAtTime
// Size: 0x10 (Inherited: 0x00)
struct FRootMotionAnimMatching_PointAtTime {
	struct FVector3f Point; // 0x00(0x0c)
	float Time; // 0x0c(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkTickLimiterData
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkTickLimiterData {
	char pad_0[0x10]; // 0x00(0x10)
	struct TWeakObjectPtr<struct UObject> Owner; // 0x10(0x08)
	float TriggerTime; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkTickLimiter
// Size: 0x78 (Inherited: 0x00)
struct FEmbarkTickLimiter {
	float MaxCost; // 0x00(0x04)
	bool bUseGameTime; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct TArray<struct FEmbarkTickLimiterData> Heap; // 0x08(0x10)
	struct TArray<struct FEmbarkTickLimiterData> ToAdd; // 0x18(0x10)
	struct TSet<struct TWeakObjectPtr<struct UObject>> ToRemove; // 0x28(0x50)
};

// ScriptStruct EmbarkUtils.PerfTimerData
// Size: 0x10 (Inherited: 0x00)
struct FPerfTimerData {
	char pad_0[0x8]; // 0x00(0x08)
	float ElapsedTime; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
};

// ScriptStruct EmbarkUtils.EmbarkWindowWrapper
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkWindowWrapper {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkUtils.FakeEmbarkUtilsStruct
// Size: 0x28 (Inherited: 0x00)
struct FFakeEmbarkUtilsStruct {
	float FloatProperty; // 0x00(0x04)
	int32_t IntProperty; // 0x04(0x04)
	struct FString StringProperty; // 0x08(0x10)
	struct TArray<struct FString> StringArrayProperty; // 0x18(0x10)
};

