// Class ModelingComponents.MeshTopologySelectionMechanic
// Size: 0xb60 (Inherited: 0xa0)
struct UMeshTopologySelectionMechanic : UInteractionMechanic {
	char pad_a0[0x48]; // 0xa0(0x48)
	struct UMeshTopologySelectionMechanicProperties* Properties; // 0xe8(0x08)
	char pad_f0[0x60]; // 0xf0(0x60)
	struct UMouseHoverBehavior* HoverBehavior; // 0x150(0x08)
	struct USingleClickOrDragInputBehavior* ClickOrDragBehavior; // 0x158(0x08)
	struct URectangleMarqueeMechanic* MarqueeMechanic; // 0x160(0x08)
	char pad_168[0x5c8]; // 0x168(0x5c8)
	struct APreviewGeometryActor* PreviewGeometryActor; // 0x730(0x08)
	struct UTriangleSetComponent* DrawnTriangleSetComponent; // 0x738(0x08)
	char pad_740[0x50]; // 0x740(0x50)
	struct UMaterialInterface* HighlightedFaceMaterial; // 0x790(0x08)
	char pad_798[0x3c8]; // 0x798(0x3c8)
};

// Class ModelingComponents.BoundarySelectionMechanic
// Size: 0xb60 (Inherited: 0xb60)
struct UBoundarySelectionMechanic : UMeshTopologySelectionMechanic {
};

// Class ModelingComponents.DynamicMeshCommitter
// Size: 0xa0 (Inherited: 0xa0)
struct UDynamicMeshCommitter : UInterface {
};

// Class ModelingComponents.DynamicMeshProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UDynamicMeshProvider : UInterface {
};

// Class ModelingComponents.PersistentDynamicMeshSource
// Size: 0xa0 (Inherited: 0xa0)
struct UPersistentDynamicMeshSource : UInterface {
};

// Class ModelingComponents.GeometrySelectionVisualizationProperties
// Size: 0x180 (Inherited: 0x120)
struct UGeometrySelectionVisualizationProperties : UInteractiveToolPropertySet {
	bool bEnableShowTriangleROIBorder; // 0x118(0x01)
	bool bEnableShowEdgeSelectionVertices; // 0x119(0x01)
	enum class EGeometrySelectionElementType SelectionElementType; // 0x11a(0x01)
	enum class EGeometrySelectionTopologyType SelectionTopologyType; // 0x11b(0x01)
	bool bShowSelection; // 0x11c(0x01)
	bool bShowTriangleROIBorder; // 0x11d(0x01)
	bool bShowHidden; // 0x11e(0x01)
	bool bShowEdgeSelectionVertices; // 0x11f(0x01)
	float LineThickness; // 0x120(0x04)
	float PointSize; // 0x124(0x04)
	float DepthBias; // 0x128(0x04)
	struct FColor FaceColor; // 0x12c(0x04)
	struct FColor LineColor; // 0x130(0x04)
	struct FColor PointColor; // 0x134(0x04)
	struct FColor TriangleROIBorderColor; // 0x138(0x04)
	struct UMaterialInterface* TriangleMaterial; // 0x140(0x08)
	struct UMaterialInterface* LineMaterial; // 0x148(0x08)
	struct UMaterialInterface* PointMaterial; // 0x150(0x08)
	struct UMaterialInterface* TriangleMaterialShowingHidden; // 0x158(0x08)
	struct UMaterialInterface* LineMaterialShowingHidden; // 0x160(0x08)
	struct UMaterialInterface* PointMaterialShowingHidden; // 0x168(0x08)
	char pad_174[0xc]; // 0x174(0x0c)
};

// Class ModelingComponents.InteractiveToolActivity
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolActivity : UInteractionMechanic {
};

// Class ModelingComponents.ToolActivityHost
// Size: 0xa0 (Inherited: 0xa0)
struct UToolActivityHost : UInterface {
};

// Class ModelingComponents.MeshTopologySelectionMechanicProperties
// Size: 0x130 (Inherited: 0x120)
struct UMeshTopologySelectionMechanicProperties : UInteractiveToolPropertySet {
	bool bSelectVertices; // 0x118(0x01)
	bool bSelectEdges; // 0x119(0x01)
	bool bSelectFaces; // 0x11a(0x01)
	bool bSelectEdgeLoops; // 0x11b(0x01)
	bool bSelectEdgeRings; // 0x11c(0x01)
	bool bHitBackFaces; // 0x11d(0x01)
	bool bEnableMarquee; // 0x11e(0x01)
	bool bMarqueeIgnoreOcclusion; // 0x11f(0x01)
	bool bPreferProjectedElement; // 0x120(0x01)
	bool bSelectDownRay; // 0x121(0x01)
	bool bIgnoreOcclusion; // 0x122(0x01)
	char pad_12b[0x5]; // 0x12b(0x05)

	void SelectAll(); // Function ModelingComponents.MeshTopologySelectionMechanicProperties.SelectAll // (Final|Native|Public) // @ game+0x944e820
	void InvertSelection(); // Function ModelingComponents.MeshTopologySelectionMechanicProperties.InvertSelection // (Final|Native|Public) // @ game+0x9432900
};

// Class ModelingComponents.GeometrySelectionEditCommandArguments
// Size: 0xc0 (Inherited: 0xa0)
struct UGeometrySelectionEditCommandArguments : UInteractiveCommandArguments {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class ModelingComponents.GeometrySelectionEditCommandResult
// Size: 0x110 (Inherited: 0xa0)
struct UGeometrySelectionEditCommandResult : UInteractiveCommandResult {
	char pad_a0[0x70]; // 0xa0(0x70)
};

// Class ModelingComponents.GeometrySelectionEditCommand
// Size: 0xa0 (Inherited: 0xa0)
struct UGeometrySelectionEditCommand : UInteractiveCommand {
};

// Class ModelingComponents.VoxelProperties
// Size: 0x130 (Inherited: 0x120)
struct UVoxelProperties : UInteractiveToolPropertySet {
	int32_t VoxelCount; // 0x118(0x04)
	bool bAutoSimplify; // 0x11c(0x01)
	bool bRemoveInternalSurfaces; // 0x11d(0x01)
	double SimplifyMaxErrorFactor; // 0x120(0x08)
	double CubeRootMinComponentVolume; // 0x128(0x08)
};

// Class ModelingComponents.MultiSelectionMeshEditingToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMultiSelectionMeshEditingToolBuilder : UInteractiveToolWithToolTargetsBuilder {
};

// Class ModelingComponents.BaseCreateFromSelectedToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBaseCreateFromSelectedToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class ModelingComponents.OnAcceptHandleSourcesPropertiesBase
// Size: 0x120 (Inherited: 0x120)
struct UOnAcceptHandleSourcesPropertiesBase : UInteractiveToolPropertySet {
};

// Class ModelingComponents.OnAcceptHandleSourcesProperties
// Size: 0x120 (Inherited: 0x120)
struct UOnAcceptHandleSourcesProperties : UOnAcceptHandleSourcesPropertiesBase {
	enum class EHandleSourcesMethod HandleInputs; // 0x118(0x01)
};

// Class ModelingComponents.BaseCreateFromSelectedHandleSourceProperties
// Size: 0x150 (Inherited: 0x120)
struct UBaseCreateFromSelectedHandleSourceProperties : UOnAcceptHandleSourcesProperties {
	enum class EBaseCreateFromSelectedTargetType OutputWriteTo; // 0x120(0x04)
	char pad_124[0x4]; // 0x124(0x04)
	struct FString OutputNewName; // 0x128(0x10)
	struct FString OutputExistingName; // 0x138(0x10)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class ModelingComponents.TransformInputsToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UTransformInputsToolProperties : UInteractiveToolPropertySet {
	bool bShowTransformGizmo; // 0x118(0x01)
};

// Class ModelingComponents.MultiSelectionMeshEditingTool
// Size: 0x130 (Inherited: 0x130)
struct UMultiSelectionMeshEditingTool : UMultiSelectionTool {
	struct TWeakObjectPtr<struct UWorld> TargetWorld; // 0x128(0x08)
};

// Class ModelingComponents.BaseCreateFromSelectedTool
// Size: 0x180 (Inherited: 0x130)
struct UBaseCreateFromSelectedTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UTransformInputsToolProperties* TransformProperties; // 0x138(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x140(0x08)
	struct UBaseCreateFromSelectedHandleSourceProperties* HandleSourcesProperties; // 0x148(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x150(0x08)
	struct TArray<struct UTransformProxy*> TransformProxies; // 0x158(0x10)
	struct TArray<struct UCombinedTransformGizmo*> TransformGizmos; // 0x168(0x10)
	char pad_178[0x8]; // 0x178(0x08)
};

// Class ModelingComponents.BaseMeshProcessingToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBaseMeshProcessingToolBuilder : UInteractiveToolWithToolTargetsBuilder {
};

// Class ModelingComponents.BaseMeshProcessingTool
// Size: 0x480 (Inherited: 0x120)
struct UBaseMeshProcessingTool : USingleSelectionTool {
	char pad_120[0x20]; // 0x120(0x20)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x140(0x08)
	char pad_148[0x338]; // 0x148(0x338)
};

// Class ModelingComponents.BaseVoxelTool
// Size: 0x190 (Inherited: 0x180)
struct UBaseVoxelTool : UBaseCreateFromSelectedTool {
	struct UVoxelProperties* VoxProperties; // 0x178(0x08)
	char pad_188[0x8]; // 0x188(0x08)
};

// Class ModelingComponents.MeshSurfacePointMeshEditingToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshSurfacePointMeshEditingToolBuilder : UMeshSurfacePointToolBuilder {
};

// Class ModelingComponents.SingleSelectionMeshEditingToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USingleSelectionMeshEditingToolBuilder : UInteractiveToolWithToolTargetsBuilder {
};

// Class ModelingComponents.SingleSelectionMeshEditingTool
// Size: 0x130 (Inherited: 0x120)
struct USingleSelectionMeshEditingTool : USingleSelectionTool {
	struct TWeakObjectPtr<struct UWorld> TargetWorld; // 0x120(0x08)
	struct UPersistentMeshSelection* InputSelection; // 0x128(0x08)
};

// Class ModelingComponents.SingleTargetWithSelectionToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USingleTargetWithSelectionToolBuilder : UInteractiveToolWithToolTargetsBuilder {
};

// Class ModelingComponents.SingleTargetWithSelectionTool
// Size: 0x1a0 (Inherited: 0x120)
struct USingleTargetWithSelectionTool : USingleSelectionTool {
	struct TWeakObjectPtr<struct UWorld> TargetWorld; // 0x120(0x08)
	char pad_128[0x60]; // 0x128(0x60)
	struct UGeometrySelectionVisualizationProperties* GeometrySelectionVizProperties; // 0x188(0x08)
	struct UPreviewGeometry* GeometrySelectionViz; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class ModelingComponents.DynamicMeshReplacementChangeTarget
// Size: 0xd0 (Inherited: 0xa0)
struct UDynamicMeshReplacementChangeTarget : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class ModelingComponents.OctreeDynamicMeshComponent
// Size: 0x870 (Inherited: 0x760)
struct UOctreeDynamicMeshComponent : UBaseDynamicMeshComponent {
	char pad_760[0x50]; // 0x760(0x50)
	struct UDynamicMesh* MeshObject; // 0x7b0(0x08)
	char pad_7b8[0xb8]; // 0x7b8(0xb8)

	void SetDynamicMesh(struct UDynamicMesh* NewMesh); // Function ModelingComponents.OctreeDynamicMeshComponent.SetDynamicMesh // (Final|Native|Public|BlueprintCallable) // @ game+0x9432320
};

// Class ModelingComponents.LineSetComponent
// Size: 0x770 (Inherited: 0x6f0)
struct ULineSetComponent : UMeshComponent {
	struct UMaterialInterface* LineMaterial; // 0x6f0(0x08)
	struct FBoxSphereBounds Bounds; // 0x6f8(0x38)
	bool bBoundsDirty; // 0x730(0x01)
	char pad_731[0x3f]; // 0x731(0x3f)
};

// Class ModelingComponents.MeshElementsVisualizerProperties
// Size: 0x150 (Inherited: 0x120)
struct UMeshElementsVisualizerProperties : UInteractiveToolPropertySet {
	bool bVisible; // 0x118(0x01)
	bool bShowWireframe; // 0x119(0x01)
	bool bShowBorders; // 0x11a(0x01)
	bool bShowUVSeams; // 0x11b(0x01)
	bool bShowNormalSeams; // 0x11c(0x01)
	bool bShowTangentSeams; // 0x11d(0x01)
	bool bShowColorSeams; // 0x11e(0x01)
	float ThicknessScale; // 0x120(0x04)
	struct FColor WireframeColor; // 0x124(0x04)
	struct FColor BoundaryEdgeColor; // 0x128(0x04)
	struct FColor UVSeamColor; // 0x12c(0x04)
	struct FColor NormalSeamColor; // 0x130(0x04)
	struct FColor TangentSeamColor; // 0x134(0x04)
	struct FColor ColorSeamColor; // 0x138(0x04)
	float DepthBias; // 0x13c(0x04)
	bool bAdjustDepthBiasUsingMeshSize; // 0x140(0x01)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class ModelingComponents.PreviewGeometry
// Size: 0x190 (Inherited: 0xa0)
struct UPreviewGeometry : UObject {
	struct APreviewGeometryActor* ParentActor; // 0x98(0x08)
	struct TMap<struct FString, struct UTriangleSetComponent*> TriangleSets; // 0xa0(0x50)
	struct TMap<struct FString, struct ULineSetComponent*> LineSets; // 0xf0(0x50)
	struct TMap<struct FString, struct UPointSetComponent*> PointSets; // 0x140(0x50)

	bool SetPointSetVisibility(struct FString PointSetIdentifier, bool bVisible); // Function ModelingComponents.PreviewGeometry.SetPointSetVisibility // (Final|Native|Public) // @ game+0x947db10
	bool SetPointSetMaterial(struct FString PointSetIdentifier, struct UMaterialInterface* NewMaterial); // Function ModelingComponents.PreviewGeometry.SetPointSetMaterial // (Final|Native|Public) // @ game+0x9481a50
	bool SetLineSetVisibility(struct FString LineSetIdentifier, bool bVisible); // Function ModelingComponents.PreviewGeometry.SetLineSetVisibility // (Final|Native|Public) // @ game+0x949a4d0
	bool SetLineSetMaterial(struct FString LineSetIdentifier, struct UMaterialInterface* NewMaterial); // Function ModelingComponents.PreviewGeometry.SetLineSetMaterial // (Final|Native|Public) // @ game+0x94aafe0
	void SetAllPointSetsMaterial(struct UMaterialInterface* Material); // Function ModelingComponents.PreviewGeometry.SetAllPointSetsMaterial // (Final|Native|Public) // @ game+0x9499f40
	void SetAllLineSetsMaterial(struct UMaterialInterface* Material); // Function ModelingComponents.PreviewGeometry.SetAllLineSetsMaterial // (Final|Native|Public) // @ game+0x9464d60
	bool RemovePointSet(struct FString PointSetIdentifier, bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemovePointSet // (Final|Native|Public) // @ game+0x9452410
	bool RemoveLineSet(struct FString LineSetIdentifier, bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemoveLineSet // (Final|Native|Public) // @ game+0x94aca70
	void RemoveAllPointSets(bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemoveAllPointSets // (Final|Native|Public) // @ game+0x949eeb0
	void RemoveAllLineSets(bool bDestroy); // Function ModelingComponents.PreviewGeometry.RemoveAllLineSets // (Final|Native|Public) // @ game+0x94b2890
	struct APreviewGeometryActor* GetActor(); // Function ModelingComponents.PreviewGeometry.GetActor // (Final|Native|Public|Const) // @ game+0x3ade0b0
	struct UTriangleSetComponent* FindTriangleSet(struct FString TriangleSetIdentifier); // Function ModelingComponents.PreviewGeometry.FindTriangleSet // (Final|Native|Public) // @ game+0x948dd10
	struct UPointSetComponent* FindPointSet(struct FString PointSetIdentifier); // Function ModelingComponents.PreviewGeometry.FindPointSet // (Final|Native|Public) // @ game+0x94aa150
	struct ULineSetComponent* FindLineSet(struct FString LineSetIdentifier); // Function ModelingComponents.PreviewGeometry.FindLineSet // (Final|Native|Public) // @ game+0x9495c40
	void Disconnect(); // Function ModelingComponents.PreviewGeometry.Disconnect // (Final|Native|Public) // @ game+0x946ea40
	void CreateInWorld(struct UWorld* World, struct FTransform& WithTransform); // Function ModelingComponents.PreviewGeometry.CreateInWorld // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x94568a0
	struct UTriangleSetComponent* AddTriangleSet(struct FString TriangleSetIdentifier); // Function ModelingComponents.PreviewGeometry.AddTriangleSet // (Final|Native|Public) // @ game+0x94abd50
	struct UPointSetComponent* AddPointSet(struct FString PointSetIdentifier); // Function ModelingComponents.PreviewGeometry.AddPointSet // (Final|Native|Public) // @ game+0x94afbc0
	struct ULineSetComponent* AddLineSet(struct FString LineSetIdentifier); // Function ModelingComponents.PreviewGeometry.AddLineSet // (Final|Native|Public) // @ game+0x947c9d0
};

// Class ModelingComponents.MeshElementsVisualizer
// Size: 0x1c0 (Inherited: 0x190)
struct UMeshElementsVisualizer : UPreviewGeometry {
	struct UMeshElementsVisualizerProperties* Settings; // 0x190(0x08)
	struct UMeshWireframeComponent* WireframeComponent; // 0x198(0x08)
	char pad_1a0[0x20]; // 0x1a0(0x20)
};

// Class ModelingComponents.MeshWireframeComponent
// Size: 0x7a0 (Inherited: 0x6f0)
struct UMeshWireframeComponent : UMeshComponent {
	float LineDepthBias; // 0x6f0(0x04)
	float LineDepthBiasSizeScale; // 0x6f4(0x04)
	float ThicknessScale; // 0x6f8(0x04)
	bool bEnableWireframe; // 0x6fc(0x01)
	char pad_6fd[0x3]; // 0x6fd(0x03)
	struct FColor WireframeColor; // 0x700(0x04)
	float WireframeThickness; // 0x704(0x04)
	bool bEnableBoundaryEdges; // 0x708(0x01)
	char pad_709[0x3]; // 0x709(0x03)
	struct FColor BoundaryEdgeColor; // 0x70c(0x04)
	float BoundaryEdgeThickness; // 0x710(0x04)
	bool bEnableUVSeams; // 0x714(0x01)
	char pad_715[0x3]; // 0x715(0x03)
	struct FColor UVSeamColor; // 0x718(0x04)
	float UVSeamThickness; // 0x71c(0x04)
	bool bEnableNormalSeams; // 0x720(0x01)
	char pad_721[0x3]; // 0x721(0x03)
	struct FColor NormalSeamColor; // 0x724(0x04)
	float NormalSeamThickness; // 0x728(0x04)
	bool bEnableTangentSeams; // 0x72c(0x01)
	char pad_72d[0x3]; // 0x72d(0x03)
	struct FColor TangentSeamColor; // 0x730(0x04)
	float TangentSeamThickness; // 0x734(0x04)
	bool bEnableColorSeams; // 0x738(0x01)
	char pad_739[0x3]; // 0x739(0x03)
	struct FColor ColorSeamColor; // 0x73c(0x04)
	float ColorSeamThickness; // 0x740(0x04)
	char pad_744[0x4]; // 0x744(0x04)
	struct UMaterialInterface* LineMaterial; // 0x748(0x08)
	struct FBoxSphereBounds LocalBounds; // 0x750(0x38)
	char pad_788[0x18]; // 0x788(0x18)
};

// Class ModelingComponents.PointSetComponent
// Size: 0x770 (Inherited: 0x6f0)
struct UPointSetComponent : UMeshComponent {
	struct UMaterialInterface* PointMaterial; // 0x6f0(0x08)
	struct FBoxSphereBounds Bounds; // 0x6f8(0x38)
	bool bBoundsDirty; // 0x730(0x01)
	char pad_731[0x3f]; // 0x731(0x3f)
};

// Class ModelingComponents.PreviewMesh
// Size: 0x1b0 (Inherited: 0xa0)
struct UPreviewMesh : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
	bool bBuildSpatialDataStructure; // 0xb0(0x01)
	char pad_b1[0xf]; // 0xb1(0x0f)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0xc0(0x08)
	char pad_c8[0xe8]; // 0xc8(0xe8)
};

// Class ModelingComponents.PolyEditPreviewMesh
// Size: 0x5c0 (Inherited: 0x1b0)
struct UPolyEditPreviewMesh : UPreviewMesh {
	char pad_1b0[0x410]; // 0x1b0(0x410)
};

// Class ModelingComponents.PreviewGeometryActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct APreviewGeometryActor : AInternalToolFrameworkActor {
};

// Class ModelingComponents.TriangleSetComponent
// Size: 0x7f0 (Inherited: 0x6f0)
struct UTriangleSetComponent : UMeshComponent {
	struct FBoxSphereBounds Bounds; // 0x6f0(0x38)
	bool bBoundsDirty; // 0x728(0x01)
	char pad_729[0xc7]; // 0x729(0xc7)
};

// Class ModelingComponents.UVLayoutPreviewProperties
// Size: 0x140 (Inherited: 0x120)
struct UUVLayoutPreviewProperties : UInteractiveToolPropertySet {
	bool bEnabled; // 0x118(0x01)
	enum class EUVLayoutPreviewSide Side; // 0x11c(0x04)
	float Scale; // 0x120(0x04)
	struct FVector2D Offset; // 0x128(0x10)
	bool bShowWireframe; // 0x138(0x01)
	char pad_13a[0x6]; // 0x13a(0x06)
};

// Class ModelingComponents.UVLayoutPreview
// Size: 0x1e0 (Inherited: 0xa0)
struct UUVLayoutPreview : UObject {
	struct UUVLayoutPreviewProperties* Settings; // 0x98(0x08)
	struct UPreviewMesh* PreviewMesh; // 0xa0(0x08)
	struct UMeshElementsVisualizer* MeshElementsVisualizer; // 0xa8(0x08)
	struct UTriangleSetComponent* TriangleComponent; // 0xb0(0x08)
	bool bShowBackingRectangle; // 0xb8(0x01)
	struct UMaterialInterface* BackingRectangleMaterial; // 0xc0(0x08)
	char pad_c9[0x117]; // 0xc9(0x117)
};

// Class ModelingComponents.CollectSurfacePathMechanic
// Size: 0x630 (Inherited: 0xa0)
struct UCollectSurfacePathMechanic : UInteractionMechanic {
	char pad_a0[0x590]; // 0xa0(0x590)
};

// Class ModelingComponents.CollisionPrimitivesMechanic
// Size: 0x5d0 (Inherited: 0xa0)
struct UCollisionPrimitivesMechanic : UInteractionMechanic {
	char pad_a0[0x210]; // 0xa0(0x210)
	struct UPreviewGeometry* PreviewGeometry; // 0x2b0(0x08)
	struct ULineSetComponent* DrawnPrimitiveEdges; // 0x2b8(0x08)
	char pad_2c0[0x150]; // 0x2c0(0x150)
	struct UTransformProxy* TranslateTransformProxy; // 0x410(0x08)
	struct UTransformProxy* SphereTransformProxy; // 0x418(0x08)
	struct UTransformProxy* BoxTransformProxy; // 0x420(0x08)
	struct UTransformProxy* CapsuleTransformProxy; // 0x428(0x08)
	struct UTransformProxy* FullTransformProxy; // 0x430(0x08)
	struct UTransformProxy* CurrentActiveProxy; // 0x438(0x08)
	struct UCombinedTransformGizmo* TranslateTransformGizmo; // 0x440(0x08)
	struct UCombinedTransformGizmo* SphereTransformGizmo; // 0x448(0x08)
	struct UCombinedTransformGizmo* BoxTransformGizmo; // 0x450(0x08)
	struct UCombinedTransformGizmo* CapsuleTransformGizmo; // 0x458(0x08)
	struct UCombinedTransformGizmo* FullTransformGizmo; // 0x460(0x08)
	char pad_468[0x50]; // 0x468(0x50)
	struct URectangleMarqueeMechanic* MarqueeMechanic; // 0x4b8(0x08)
	char pad_4c0[0x110]; // 0x4c0(0x110)
};

// Class ModelingComponents.ConstructionPlaneMechanic
// Size: 0x160 (Inherited: 0xa0)
struct UConstructionPlaneMechanic : UInteractionMechanic {
	char pad_a0[0x98]; // 0xa0(0x98)
	struct UCombinedTransformGizmo* PlaneTransformGizmo; // 0x138(0x08)
	struct UTransformProxy* PlaneTransformProxy; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
	struct USingleClickInputBehavior* ClickToSetPlaneBehavior; // 0x150(0x08)
	struct ULocalSingleClickInputBehavior* MiddleClickToSetGizmoBehavior; // 0x158(0x08)
};

// Class ModelingComponents.CurveControlPointsMechanic
// Size: 0x6f0 (Inherited: 0xa0)
struct UCurveControlPointsMechanic : UInteractionMechanic {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct USingleClickInputBehavior* ClickBehavior; // 0xb0(0x08)
	struct UMouseHoverBehavior* HoverBehavior; // 0xb8(0x08)
	char pad_c0[0x498]; // 0xc0(0x498)
	struct APreviewGeometryActor* PreviewGeometryActor; // 0x558(0x08)
	struct UPointSetComponent* DrawnControlPoints; // 0x560(0x08)
	struct ULineSetComponent* DrawnControlSegments; // 0x568(0x08)
	struct UPointSetComponent* PreviewPoint; // 0x570(0x08)
	struct ULineSetComponent* PreviewSegment; // 0x578(0x08)
	char pad_580[0x78]; // 0x580(0x78)
	struct UTransformProxy* PointTransformProxy; // 0x5f8(0x08)
	struct UCombinedTransformGizmo* PointTransformGizmo; // 0x600(0x08)
	char pad_608[0xe8]; // 0x608(0xe8)
};

// Class ModelingComponents.DragAlignmentMechanic
// Size: 0x2e0 (Inherited: 0xa0)
struct UDragAlignmentMechanic : UInteractionMechanic {
	char pad_a0[0x240]; // 0xa0(0x240)
};

// Class ModelingComponents.DragAlignmentInteraction
// Size: 0x340 (Inherited: 0xa0)
struct UDragAlignmentInteraction : UObject {
	char pad_a0[0x2a0]; // 0xa0(0x2a0)
};

// Class ModelingComponents.LatticeControlPointsMechanic
// Size: 0x570 (Inherited: 0xa0)
struct ULatticeControlPointsMechanic : UInteractionMechanic {
	char pad_a0[0x1f0]; // 0xa0(0x1f0)
	struct APreviewGeometryActor* PreviewGeometryActor; // 0x290(0x08)
	struct UPointSetComponent* DrawnControlPoints; // 0x298(0x08)
	struct ULineSetComponent* DrawnLatticeEdges; // 0x2a0(0x08)
	char pad_2a8[0xa8]; // 0x2a8(0xa8)
	struct UTransformProxy* PointTransformProxy; // 0x350(0x08)
	struct UCombinedTransformGizmo* PointTransformGizmo; // 0x358(0x08)
	char pad_360[0x58]; // 0x360(0x58)
	struct URectangleMarqueeMechanic* MarqueeMechanic; // 0x3b8(0x08)
	char pad_3c0[0x1b0]; // 0x3c0(0x1b0)
};

// Class ModelingComponents.PlaneDistanceFromHitMechanic
// Size: 0x580 (Inherited: 0xa0)
struct UPlaneDistanceFromHitMechanic : UInteractionMechanic {
	char pad_a0[0x4e0]; // 0xa0(0x4e0)
};

// Class ModelingComponents.PolyLassoMarqueeMechanic
// Size: 0x240 (Inherited: 0xa0)
struct UPolyLassoMarqueeMechanic : UInteractionMechanic {
	char pad_a0[0x58]; // 0xa0(0x58)
	float SpacingTolerance; // 0xf8(0x04)
	float LineThickness; // 0xfc(0x04)
	struct FLinearColor LineColor; // 0x100(0x10)
	struct FLinearColor ClosedColor; // 0x110(0x10)
	bool bEnableFreehandPolygons; // 0x120(0x01)
	bool bEnableMultiClickPolygons; // 0x121(0x01)
	char pad_122[0x6]; // 0x122(0x06)
	struct UClickDragInputBehavior* ClickDragBehavior; // 0x128(0x08)
	struct UMouseHoverBehavior* HoverBehavior; // 0x130(0x08)
	char pad_138[0x108]; // 0x138(0x108)
};

// Class ModelingComponents.RectangleMarqueeMechanic
// Size: 0x290 (Inherited: 0xa0)
struct URectangleMarqueeMechanic : UInteractionMechanic {
	char pad_a0[0x8]; // 0xa0(0x08)
	bool bUseExternalClickDragBehavior; // 0xa8(0x01)
	bool bUseExternalUpdateCameraState; // 0xa9(0x01)
	char pad_aa[0x46]; // 0xaa(0x46)
	double OnDragRectangleChangedDeferredThreshold; // 0xf0(0x08)
	char pad_f8[0x48]; // 0xf8(0x48)
	struct UClickDragInputBehavior* ClickDragBehavior; // 0x140(0x08)
	char pad_148[0x148]; // 0x148(0x148)
};

// Class ModelingComponents.RectangleMarqueeInteraction
// Size: 0x280 (Inherited: 0xa0)
struct URectangleMarqueeInteraction : UObject {
	char pad_a0[0x1e0]; // 0xa0(0x1e0)
};

// Class ModelingComponents.SpaceCurveDeformationMechanicPropertySet
// Size: 0x130 (Inherited: 0x120)
struct USpaceCurveDeformationMechanicPropertySet : UInteractiveToolPropertySet {
	enum class ESpaceCurveControlPointTransformMode TransformMode; // 0x118(0x04)
	enum class ESpaceCurveControlPointOriginMode TransformOrigin; // 0x11c(0x04)
	float Softness; // 0x120(0x04)
	enum class ESpaceCurveControlPointFalloffType SoftFalloff; // 0x124(0x04)
};

// Class ModelingComponents.SpaceCurveDeformationMechanic
// Size: 0x340 (Inherited: 0xa0)
struct USpaceCurveDeformationMechanic : UInteractionMechanic {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct USingleClickInputBehavior* ClickBehavior; // 0xb0(0x08)
	struct UMouseHoverBehavior* HoverBehavior; // 0xb8(0x08)
	char pad_c0[0x18]; // 0xc0(0x18)
	struct USpaceCurveDeformationMechanicPropertySet* TransformProperties; // 0xd8(0x08)
	char pad_e0[0xf8]; // 0xe0(0xf8)
	struct APreviewGeometryActor* PreviewGeometryActor; // 0x1d8(0x08)
	struct UPointSetComponent* RenderPoints; // 0x1e0(0x08)
	struct ULineSetComponent* RenderSegments; // 0x1e8(0x08)
	char pad_1f0[0x38]; // 0x1f0(0x38)
	struct UTransformProxy* PointTransformProxy; // 0x228(0x08)
	struct UCombinedTransformGizmo* PointTransformGizmo; // 0x230(0x08)
	char pad_238[0x108]; // 0x238(0x108)
};

// Class ModelingComponents.SpatialCurveDistanceMechanic
// Size: 0x480 (Inherited: 0xa0)
struct USpatialCurveDistanceMechanic : UInteractionMechanic {
	char pad_a0[0x3e0]; // 0xa0(0x3e0)
};

// Class ModelingComponents.MeshOpPreviewWithBackgroundCompute
// Size: 0x130 (Inherited: 0xa0)
struct UMeshOpPreviewWithBackgroundCompute : UObject {
	char pad_a0[0x28]; // 0xa0(0x28)
	struct UPreviewMesh* PreviewMesh; // 0xc8(0x08)
	struct TArray<struct UMaterialInterface*> StandardMaterials; // 0xd0(0x10)
	struct UMaterialInterface* OverrideMaterial; // 0xe0(0x08)
	struct UMaterialInterface* WorkingMaterial; // 0xe8(0x08)
	struct UMaterialInterface* SecondaryMaterial; // 0xf0(0x08)
	struct TWeakObjectPtr<struct UWorld> PreviewWorld; // 0xf8(0x08)
	char pad_100[0x30]; // 0x100(0x30)
};

// Class ModelingComponents.ModelingComponentsSettings
// Size: 0xb0 (Inherited: 0xb0)
struct UModelingComponentsSettings : UDeveloperSettings {
	bool bEnableRayTracingWhileEditing; // 0xa8(0x01)
	bool bEnableRayTracing; // 0xa9(0x01)
	bool bGenerateLightmapUVs; // 0xaa(0x01)
	bool bEnableCollision; // 0xab(0x01)
	enum class ECollisionTraceFlag CollisionMode; // 0xac(0x01)
};

// Class ModelingComponents.ModelingComponentsEditorSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UModelingComponentsEditorSettings : UDeveloperSettings {
	enum class EModelingComponentsPlaneVisualizationMode GridMode; // 0xa8(0x01)
	int32_t NumGridLines; // 0xac(0x04)
	float GridSpacing; // 0xb0(0x04)
	float GridScale; // 0xb4(0x04)
	float GridSize; // 0xb8(0x04)
};

// Class ModelingComponents.ModelingObjectsCreationAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UModelingObjectsCreationAPI : UObject {

	struct FCreateTextureObjectResult CreateTextureObject(struct FCreateTextureObjectParams& CreateTexParams); // Function ModelingComponents.ModelingObjectsCreationAPI.CreateTextureObject // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x946deb0
	struct FCreateActorResult CreateNewActor(struct FCreateActorParams& CreateActorParams); // Function ModelingComponents.ModelingObjectsCreationAPI.CreateNewActor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x94994b0
	struct FCreateMeshObjectResult CreateMeshObject(struct FCreateMeshObjectParams& CreateMeshParams); // Function ModelingComponents.ModelingObjectsCreationAPI.CreateMeshObject // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x945ed90
	struct FCreateMaterialObjectResult CreateMaterialObject(struct FCreateMaterialObjectParams& CreateMaterialParams); // Function ModelingComponents.ModelingObjectsCreationAPI.CreateMaterialObject // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x945cea0
};

// Class ModelingComponents.PreviewMeshActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct APreviewMeshActor : AInternalToolFrameworkActor {
};

// Class ModelingComponents.CreateMeshObjectTypeProperties
// Size: 0x150 (Inherited: 0x120)
struct UCreateMeshObjectTypeProperties : UInteractiveToolPropertySet {
	struct FString OutputType; // 0x118(0x10)
	struct AVolume* VolumeType; // 0x128(0x08)
	struct TArray<struct FString> OutputTypeNamesList; // 0x130(0x10)
	bool bShowVolumeList; // 0x140(0x01)
	char pad_149[0x7]; // 0x149(0x07)

	bool ShouldShowPropertySet(); // Function ModelingComponents.CreateMeshObjectTypeProperties.ShouldShowPropertySet // (Final|Native|Public|Const) // @ game+0x94ab100
	struct TArray<struct FString> GetOutputTypeNamesFunc(); // Function ModelingComponents.CreateMeshObjectTypeProperties.GetOutputTypeNamesFunc // (Final|Native|Public) // @ game+0x94520e0
	enum class ECreateObjectTypeHint GetCurrentCreateMeshType(); // Function ModelingComponents.CreateMeshObjectTypeProperties.GetCurrentCreateMeshType // (Final|Native|Public|Const) // @ game+0x948efa0
};

// Class ModelingComponents.OnAcceptHandleSourcesPropertiesSingle
// Size: 0x120 (Inherited: 0x120)
struct UOnAcceptHandleSourcesPropertiesSingle : UOnAcceptHandleSourcesPropertiesBase {
	enum class EHandleSourcesMethod HandleInputs; // 0x118(0x01)
};

// Class ModelingComponents.PolygroupLayersProperties
// Size: 0x130 (Inherited: 0x120)
struct UPolygroupLayersProperties : UInteractiveToolPropertySet {
	struct FName ActiveGroupLayer; // 0x118(0x08)
	struct TArray<struct FString> GroupLayersList; // 0x120(0x10)

	struct TArray<struct FString> GetGroupLayersFunc(); // Function ModelingComponents.PolygroupLayersProperties.GetGroupLayersFunc // (Final|Native|Public) // @ game+0x94c0500
};

// Class ModelingComponents.WeightMapSetProperties
// Size: 0x140 (Inherited: 0x120)
struct UWeightMapSetProperties : UInteractiveToolPropertySet {
	struct FName WeightMap; // 0x118(0x08)
	struct TArray<struct FString> WeightMapsList; // 0x120(0x10)
	bool bInvertWeightMap; // 0x130(0x01)
	char pad_139[0x7]; // 0x139(0x07)

	struct TArray<struct FString> GetWeightMapsFunc(); // Function ModelingComponents.WeightMapSetProperties.GetWeightMapsFunc // (Final|Native|Public) // @ game+0x94c0500
};

// Class ModelingComponents.GeometrySelectionManager
// Size: 0x300 (Inherited: 0xa0)
struct UGeometrySelectionManager : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct UGeometrySelectionEditCommandArguments* SelectionArguments; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)
	struct UInteractiveToolsContext* ToolsContext; // 0xd0(0x08)
	char pad_d8[0x228]; // 0xd8(0x228)
};

// Class ModelingComponents.PersistentMeshSelection
// Size: 0x100 (Inherited: 0xa0)
struct UPersistentMeshSelection : UObject {
	char pad_a0[0x60]; // 0xa0(0x60)
};

// Class ModelingComponents.PersistentMeshSelectionManager
// Size: 0xb0 (Inherited: 0xa0)
struct UPersistentMeshSelectionManager : UObject {
	struct UInteractiveToolsContext* ParentContext; // 0x98(0x08)
	struct UPersistentMeshSelection* ActiveSelection; // 0xa0(0x08)
	struct UPreviewGeometry* SelectionDisplay; // 0xa8(0x08)
};

// Class ModelingComponents.PolygonSelectionMechanicProperties
// Size: 0x130 (Inherited: 0x130)
struct UPolygonSelectionMechanicProperties : UMeshTopologySelectionMechanicProperties {
};

// Class ModelingComponents.PolygonSelectionMechanic
// Size: 0xb70 (Inherited: 0xb60)
struct UPolygonSelectionMechanic : UMeshTopologySelectionMechanic {
	struct UPolygonSelectionMechanicProperties* Properties; // 0xb60(0x08)
	char pad_b68[0x8]; // 0xb68(0x08)
};

// Class ModelingComponents.ModelingSceneSnappingManager
// Size: 0x1c0 (Inherited: 0xa0)
struct UModelingSceneSnappingManager : USceneSnappingManager {
	struct UInteractiveToolsContext* ParentContext; // 0x98(0x08)
	char pad_a8[0x118]; // 0xa8(0x118)
};

// Class ModelingComponents.MultiTransformer
// Size: 0x220 (Inherited: 0xa0)
struct UMultiTransformer : UObject {
	char pad_a0[0x58]; // 0xa0(0x58)
	struct UInteractiveGizmoManager* GizmoManager; // 0xf8(0x08)
	char pad_100[0x70]; // 0x100(0x70)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x170(0x08)
	struct UTransformProxy* TransformProxy; // 0x178(0x08)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x180(0x08)
	char pad_188[0x98]; // 0x188(0x98)
};

