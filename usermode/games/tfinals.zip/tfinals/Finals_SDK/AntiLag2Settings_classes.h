// Class AntiLag2Settings.AntiLag2Settings
// Size: 0xb0 (Inherited: 0xb0)
struct UAntiLag2Settings : UDeveloperSettings {
	bool bEnabled; // 0xa8(0x01)
};

