// Enum EmbarkDiscord.EDiscordConnectionErrorEventType
enum class EDiscordConnectionErrorEventType : uint8_t {
	None = 0,
	UnlinkFailedWithCooldownLimitation = 1,
	UnlinkFailed = 2,
	LinkingFailed = 3,
	LinkingTimedout = 4,
	AuthorizeFailed = 5,
	CanceledPreviousAttempt = 6,
	EDiscordConnectionErrorEventType_MAX = 7
};

