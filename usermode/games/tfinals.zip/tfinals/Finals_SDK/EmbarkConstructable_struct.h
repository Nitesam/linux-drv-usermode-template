// Enum EmbarkConstructable.EConstructableHealthChangeReason
enum class EConstructableHealthChangeReason : uint8_t {
	WasHealed = 0,
	WasDamaged = 1,
	BrokeFromAttack = 2,
	BrokeDueToParentGettingDestroyed = 3,
	BrokeDueToInstantDestruction = 4,
	TookNoDamage = 5,
	SelfRemoval = 6,
	DisabledFromAttack = 7,
	BrokeDueToGroupGettingDestroyed = 8,
	NUMBER_OF_ENTRIES = 9,
	EConstructableHealthChangeReason_MAX = 10
};

// Enum EmbarkConstructable.EConstructableFeatureQualityLevel
enum class EConstructableFeatureQualityLevel : uint8_t {
	Low = 0,
	Medium = 1,
	High = 2,
	Full = 3,
	NUMBER_OF_ENTRIES = 4,
	EConstructableFeatureQualityLevel_MAX = 5
};

// Enum EmbarkConstructable.EConstructablePartTargetType
enum class EConstructablePartTargetType : uint8_t {
	NoTarget = 0,
	TargetOrientation_World = 1,
	TargetLocation_World = 2,
	TargetActor = 3,
	TargetComponent = 4,
	TargetConstructablePart = 5,
	TargetChase = 6,
	TargetRelativeRotation = 7,
	TerminalValue = 8,
	NUMBER_OF_ENTRIES = 9,
	EConstructablePartTargetType_MAX = 10
};

// Enum EmbarkConstructable.EConstructableCapabilityEventType
enum class EConstructableCapabilityEventType : uint8_t {
	Start = 0,
	Cancel = 1,
	Stop = 2,
	NUMBER_OF_ENTRIES = 3,
	EConstructableCapabilityEventType_MAX = 4
};

// Enum EmbarkConstructable.EPartHierarchyType
enum class EPartHierarchyType : uint8_t {
	Frame = 0,
	ChildOfFrame = 1,
	Other = 2,
	EPartHierarchyType_MAX = 3
};

// Enum EmbarkConstructable.EConstructableReplicationType
enum class EConstructableReplicationType : uint8_t {
	Disabled = 0,
	Constraint = 1,
	Child = 2,
	Full = 3,
	EConstructableReplicationType_MAX = 4
};

// Enum EmbarkConstructable.EConstructablePartTransformSelectionType
enum class EConstructablePartTransformSelectionType : uint8_t {
	PartPivot = 0,
	Socket = 1,
	Proxy = 2,
	EConstructablePartTransformSelectionType_MAX = 3
};

// Enum EmbarkConstructable.ESkeletalMeshStyleSpace
enum class ESkeletalMeshStyleSpace : uint8_t {
	LocalSpace = 0,
	WorldSpace = 1,
	ESkeletalMeshStyleSpace_MAX = 2
};

// Enum EmbarkConstructable.ESkeletalMeshStylePhysicsType
enum class ESkeletalMeshStylePhysicsType : uint8_t {
	None = 0,
	Simulated = 1,
	Welded = 2,
	Kinematic = 3,
	ESkeletalMeshStylePhysicsType_MAX = 4
};

// Enum EmbarkConstructable.EConstructablePartRelativeTransformSpace
enum class EConstructablePartRelativeTransformSpace : uint8_t {
	PartPivot = 0,
	Actor = 1,
	ParentSocket = 2,
	EConstructablePartRelativeTransformSpace_MAX = 3
};

// Enum EmbarkConstructable.EOrientationFilterType
enum class EOrientationFilterType : uint8_t {
	Lerp = 0,
	MinJerk = 1,
	Instant = 2,
	EOrientationFilterType_MAX = 3
};

// Enum EmbarkConstructable.EConstructablePartPivotType
enum class EConstructablePartPivotType : uint8_t {
	Socket = 0,
	FirstOfSocketGroup = 1,
	NormalizedSocketGroup = 2,
	EConstructablePartPivotType_MAX = 3
};

// Enum EmbarkConstructable.EConstructableTrainingShape
enum class EConstructableTrainingShape : uint8_t {
	Sphere = 0,
	Box = 1,
	Capsule = 2,
	EConstructableTrainingShape_MAX = 3
};

// Enum EmbarkConstructable.EPartResistanceGroup
enum class EPartResistanceGroup : uint8_t {
	Undefined = 0,
	Normal = 1,
	Armor = 2,
	Sturdy = 3,
	WeakPoint = 4,
	Critical = 5,
	Fragile = 6,
	EPartResistanceGroup_MAX = 7
};

// Enum EmbarkConstructable.EConstructableNumPartsCategory
enum class EConstructableNumPartsCategory : uint8_t {
	Small = 0,
	Medium = 1,
	Large = 2,
	EConstructableNumPartsCategory_MAX = 3
};

// ScriptStruct EmbarkConstructable.ConstructableDamageData
// Size: 0x48 (Inherited: 0x00)
struct FConstructableDamageData {
	struct TWeakObjectPtr<struct APawn> DamageInstigatorPawn; // 0x00(0x08)
	int32_t AffectedPartID; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FVector_NetQuantize ImpactLocation; // 0x10(0x18)
	enum class EConstructableHealthChangeReason HealthChangeReason; // 0x28(0x01)
	char DamageType; // 0x29(0x01)
	char pad_2a[0x2]; // 0x2a(0x02)
	float CurrentHealthUNorm_RoughEstimate; // 0x2c(0x04)
	float HealthChangeSNorm_RoughEstimate; // 0x30(0x04)
	float HealthChange; // 0x34(0x04)
	int32_t EventID; // 0x38(0x04)
	char Severity; // 0x3c(0x01)
	bool bFromOriginalSource; // 0x3d(0x01)
	char pad_3e[0x2]; // 0x3e(0x02)
	float ServerEventTime; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructablePartTargetingData
// Size: 0xa8 (Inherited: 0x00)
struct FConstructablePartTargetingData {
	char AffectedPartID; // 0x00(0x01)
	char TargetPartID; // 0x01(0x01)
	enum class EConstructablePartTargetType TargetType; // 0x02(0x01)
	enum class EConstructableFeatureQualityLevel QualityLevel; // 0x03(0x01)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector TargetLocation; // 0x08(0x18)
	struct FRotator TargetOrientation; // 0x20(0x18)
	struct TWeakObjectPtr<struct UObject> TargetObject; // 0x38(0x08)
	int32_t EventID; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FVector ChaseStartLocation; // 0x48(0x18)
	struct FVector ChaseTargetLocation; // 0x60(0x18)
	float TrackingOffsetZ; // 0x78(0x04)
	float MaxChaseSpeed; // 0x7c(0x04)
	bool bChaseWorldLocation; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FABBLowCompressedVectorMaxLen200 AimOffset; // 0x88(0x18)
	char pad_a0[0x8]; // 0xa0(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructablePartTargetingEventData
// Size: 0xf8 (Inherited: 0xa8)
struct FConstructablePartTargetingEventData : FConstructablePartTargetingData {
	struct FRotator ActualPartOrientationWorld; // 0xa8(0x18)
	struct FRotator CurrentTargetingOrientationWorld; // 0xc0(0x18)
	bool bHasReachedTarget; // 0xd8(0x01)
	char pad_d9[0x7]; // 0xd9(0x07)
	struct FVector LastKnownTargetLocation; // 0xe0(0x18)
};

// ScriptStruct EmbarkConstructable.ConstructablePartTagData
// Size: 0x28 (Inherited: 0x00)
struct FConstructablePartTagData {
	int32_t PartID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FGameplayTagContainer AggregatedTags; // 0x08(0x20)
};

// ScriptStruct EmbarkConstructable.ComponentOrStyle
// Size: 0x18 (Inherited: 0x00)
struct FComponentOrStyle {
	struct USceneComponent* Component; // 0x00(0x08)
	struct AActor* Owner; // 0x08(0x08)
	int32_t PartID; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkConstructable.ComponentOrStyleTargetData
// Size: 0x20 (Inherited: 0x08)
struct FComponentOrStyleTargetData : FGameplayAbilityTargetData {
	struct FComponentOrStyle Target; // 0x08(0x18)
};

// ScriptStruct EmbarkConstructable.ConstructablePartAbilityData
// Size: 0x60 (Inherited: 0x00)
struct FConstructablePartAbilityData {
	int32_t MainPartID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSet<int32_t> PartIDsAssociatedWithAbility; // 0x08(0x50)
	struct TWeakObjectPtr<struct UGameplayEffect> CostGameplayEffect; // 0x58(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructablePartAttributeMapping
// Size: 0x1f0 (Inherited: 0x00)
struct FConstructablePartAttributeMapping {
	struct UEmbarkAttributeSet* PartAttributeSet; // 0x00(0x08)
	int32_t PartAttributeSetId; // 0x08(0x04)
	char pad_c[0x1e4]; // 0x0c(0x1e4)
};

// ScriptStruct EmbarkConstructable.ConstructablePartAttributeBaseData
// Size: 0x18 (Inherited: 0x00)
struct FConstructablePartAttributeBaseData {
	struct UAttributeSet* BaseAttributeSet; // 0x00(0x08)
	struct FName BaseAttributeName; // 0x08(0x08)
	int32_t PartID; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructablePartAttributeChangedData
// Size: 0x20 (Inherited: 0x00)
struct FConstructablePartAttributeChangedData {
	struct FConstructablePartAttributeBaseData PartAttributeBaseData; // 0x00(0x18)
	float OldValue; // 0x18(0x04)
	float NewValue; // 0x1c(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructableCustomEffectState
// Size: 0x70 (Inherited: 0x00)
struct FConstructableCustomEffectState {
	char pad_0[0x70]; // 0x00(0x70)
};

// ScriptStruct EmbarkConstructable.ConstructableTargetHitData
// Size: 0xf0 (Inherited: 0x00)
struct FConstructableTargetHitData {
	struct FHitResult Hit; // 0x00(0xe8)
	float AffectedDegreeUNorm; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructablePartDamageModelData
// Size: 0x18 (Inherited: 0x00)
struct FConstructablePartDamageModelData {
	int32_t AffectedPartID; // 0x00(0x04)
	float AffectedDegreeUNorm; // 0x04(0x04)
	float TakenDamage; // 0x08(0x04)
	float RawTakenDamage; // 0x0c(0x04)
	struct AActor* Instigator; // 0x10(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructablePartAttackerData
// Size: 0x60 (Inherited: 0x00)
struct FConstructablePartAttackerData {
	int32_t AttackingPartID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UPrimaryDataAsset* EnemyType; // 0x08(0x08)
	struct TMap<char, float> SnapshottedDamage; // 0x10(0x50)
};

// ScriptStruct EmbarkConstructable.ReplicatedSubobjectTargetData
// Size: 0x10 (Inherited: 0x08)
struct FReplicatedSubobjectTargetData : FGameplayAbilityTargetData {
	struct UReplicatedSubobject* TargetObject; // 0x08(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableGameplayEffectContext
// Size: 0x188 (Inherited: 0xe8)
struct FConstructableGameplayEffectContext : FEmbarkGameplayEffectContext {
	bool bAffectActor; // 0xe8(0x01)
	char pad_e9[0x7]; // 0xe9(0x07)
	struct TArray<struct FConstructablePartDamageModelData> AffectedParts; // 0xf0(0x10)
	int32_t PrimaryTargetPartId; // 0x100(0x04)
	char pad_104[0x4]; // 0x104(0x04)
	struct FConstructablePartAttackerData AttackingPartInfo; // 0x108(0x60)
	float ActorRawTakenDamage; // 0x168(0x04)
	float ArmorDamage; // 0x16c(0x04)
	float DamageMitigatedByArmor; // 0x170(0x04)
	float ActorAffectedDegreeUNorm; // 0x174(0x04)
	char pad_178[0x1]; // 0x178(0x01)
	char DamageType; // 0x179(0x01)
	char pad_17a[0x2]; // 0x17a(0x02)
	int32_t EventID; // 0x17c(0x04)
	struct TWeakObjectPtr<struct UObject> OriginatorObject; // 0x180(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableTargetData
// Size: 0x28 (Inherited: 0x08)
struct FConstructableTargetData : FGameplayAbilityTargetData {
	struct TWeakObjectPtr<struct AActor> TargetActor; // 0x08(0x08)
	struct TArray<struct FConstructablePartDamageModelData> TargetParts; // 0x10(0x10)
	int32_t PrimaryTargetPartId; // 0x20(0x04)
	float TargetActorAffectedDegreeUNorm; // 0x24(0x04)
};

// ScriptStruct EmbarkConstructable.ServiceUpdateTimeInfo
// Size: 0x08 (Inherited: 0x00)
struct FServiceUpdateTimeInfo {
	float TimeUntilNextUpdate; // 0x00(0x04)
	float TimeBetweenUpdates; // 0x04(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructableCapabilityID
// Size: 0x01 (Inherited: 0x00)
struct FConstructableCapabilityID {
	char ID; // 0x00(0x01)
};

// ScriptStruct EmbarkConstructable.ConstructableCapabilityEvent
// Size: 0x30 (Inherited: 0x00)
struct FConstructableCapabilityEvent {
	struct FConstructableCapabilityID ID; // 0x00(0x01)
	enum class EConstructableCapabilityEventType EventType; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct UObject* TargetObject; // 0x08(0x08)
	struct FVector InitialTargetLocation; // 0x10(0x18)
	char ReplicationID; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkConstructable.ConstructableSMNetworkData
// Size: 0x20 (Inherited: 0x00)
struct FConstructableSMNetworkData {
	struct FConstructableCapabilityID CapabilityID; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FEmbarkSMActiveStateData SMActiveState; // 0x08(0x10)
	char ReplicationID; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct EmbarkConstructable.ConstructableDamageDataBB
// Size: 0x70 (Inherited: 0x00)
struct FConstructableDamageDataBB {
	struct FVector_NetQuantize ImpactLocation; // 0x00(0x18)
	struct TWeakObjectPtr<struct APawn> DamageInstigatorPawn; // 0x18(0x08)
	char AffectedPartID; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
	int32_t EventID; // 0x24(0x04)
	struct FABFloat CurrentHealthUNorm_RoughEstimate; // 0x28(0x10)
	struct FABFloat HealthChangeSNorm_RoughEstimate; // 0x38(0x10)
	struct FABFloat HealthChange; // 0x48(0x10)
	bool bFromOriginalSource; // 0x58(0x01)
	char Severity; // 0x59(0x01)
	enum class EConstructableHealthChangeReason HealthChangeReason; // 0x5a(0x01)
	char DamageType; // 0x5b(0x01)
	char ReplicationCounter; // 0x5c(0x01)
	char pad_5d[0x3]; // 0x5d(0x03)
	struct FABFloat ServerEventTime; // 0x60(0x10)
};

// ScriptStruct EmbarkConstructable.ThrusterDefinition
// Size: 0x90 (Inherited: 0x00)
struct FThrusterDefinition {
	struct FTransform Transform; // 0x00(0x60)
	float Scalar; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct FVector Force; // 0x68(0x18)
	int32_t PartID; // 0x80(0x04)
	bool bIsStunned; // 0x84(0x01)
	char pad_85[0x3]; // 0x85(0x03)
	float ForceMultiplier; // 0x88(0x04)
	char pad_8c[0x4]; // 0x8c(0x04)
};

// ScriptStruct EmbarkConstructable.ThrusterSimParams
// Size: 0xc0 (Inherited: 0x00)
struct FThrusterSimParams {
	struct FTransform BodyTransform; // 0x00(0x60)
	struct FRotator DesiredRotation; // 0x60(0x18)
	struct FVector TargetMoveVector; // 0x78(0x18)
	float BodyMass; // 0x90(0x04)
	float AdditionalSpeed; // 0x94(0x04)
	float AdditionalSpeedFactorZ; // 0x98(0x04)
	float RotationSpeed; // 0x9c(0x04)
	float HeightPidResult; // 0xa0(0x04)
	float RotationPidResult; // 0xa4(0x04)
	float DownforceFactorAllow; // 0xa8(0x04)
	float ThrustCalculationBasisVerticalOffset; // 0xac(0x04)
	float RotationTargetDamping; // 0xb0(0x04)
	char pad_b4[0xc]; // 0xb4(0x0c)
};

// ScriptStruct EmbarkConstructable.ConstructablePartDamagePropagation
// Size: 0x10 (Inherited: 0x00)
struct FConstructablePartDamagePropagation {
	float ParentMultiplier; // 0x00(0x04)
	float FrameMultiplier; // 0x04(0x04)
	enum class EPartHierarchyType PartHierarchyType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t PropagationParentPartId; // 0x0c(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructablePart
// Size: 0x38 (Inherited: 0x00)
struct FConstructablePart {
	struct UPrimitiveComponent* StyleComponent; // 0x00(0x08)
	struct TScriptInterface<IConstructableStyleComponent> Style; // 0x08(0x10)
	int32_t ID; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct AConstructableBase* ConstructableOwner; // 0x20(0x08)
	struct FConstructablePartDamagePropagation DamagePropagation; // 0x28(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructablePartList
// Size: 0xc0 (Inherited: 0x00)
struct FConstructablePartList {
	struct FGameplayTagQuery PartQuery; // 0x00(0x48)
	struct FConstructableStylePropertyOuter PropertyOuterContainer; // 0x48(0x28)
	struct TMap<int32_t, struct FName> PartList; // 0x70(0x50)
};

// ScriptStruct EmbarkConstructable.ConstructableStylePropertyOuter
// Size: 0x28 (Inherited: 0x00)
struct FConstructableStylePropertyOuter {
	struct AActor* PropertyActorClass; // 0x00(0x08)
	struct AActor* AlternatePropertyActorClass; // 0x08(0x08)
	struct UObject* PropertyOuterCDO; // 0x10(0x08)
	struct UObject* AlternatePropertyOuterCDO; // 0x18(0x08)
	bool bIsPropertyOuterConstructable; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EmbarkConstructable.ConstructablePartReplicationData
// Size: 0x48 (Inherited: 0x0c)
struct FConstructablePartReplicationData : FFastArraySerializerItem {
	char pad_c[0x4]; // 0x0c(0x04)
	struct FVector_NetQuantize10 PartLocation; // 0x10(0x18)
	struct FRotator PartOrientation; // 0x28(0x18)
	int32_t PartID; // 0x40(0x04)
	enum class EConstructableReplicationType Replication; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
};

// ScriptStruct EmbarkConstructable.ActorBBReplicatedPart
// Size: 0x70 (Inherited: 0x00)
struct FActorBBReplicatedPart {
	struct FABBLowCompressedWorldTransform Transform; // 0x00(0x60)
	int32_t PartID; // 0x60(0x04)
	enum class EConstructableReplicationType Replication; // 0x64(0x01)
	char pad_65[0xb]; // 0x65(0x0b)
};

// ScriptStruct EmbarkConstructable.ConstructablePartReplicationDataArray
// Size: 0x128 (Inherited: 0x110)
struct FConstructablePartReplicationDataArray : FFastArraySerializer {
	struct TArray<struct FConstructablePartReplicationData> Items; // 0x110(0x10)
	char pad_120[0x8]; // 0x120(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableSkeletalReplicationConfig
// Size: 0x48 (Inherited: 0x00)
struct FConstructableSkeletalReplicationConfig {
	struct FGameplayTagQuery InitialReplicatedJointTags; // 0x00(0x48)
};

// ScriptStruct EmbarkConstructable.ConstructablePartReplicationConfig
// Size: 0x50 (Inherited: 0x00)
struct FConstructablePartReplicationConfig {
	struct FGameplayTagQuery InitialReplicatedPartTags; // 0x00(0x48)
	enum class EConstructableReplicationType InitialReplicationType; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct EmbarkConstructable.ConstructablePartSelection
// Size: 0x0c (Inherited: 0x00)
struct FConstructablePartSelection {
	int32_t PartID; // 0x00(0x04)
	struct FName PartDisplayName; // 0x04(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructablePartTransform
// Size: 0x100 (Inherited: 0x00)
struct FConstructablePartTransform {
	struct FConstructableStyleProxy StyleProxy; // 0x00(0xd0)
	struct TWeakObjectPtr<struct UPrimitiveComponent> Component; // 0xd0(0x08)
	struct TScriptInterface<IConstructableStyleComponent> Style; // 0xd8(0x10)
	struct FName SocketName; // 0xe8(0x08)
	int32_t PartID; // 0xf0(0x04)
	enum class EConstructablePartTransformSelectionType TransformType; // 0xf4(0x01)
	char pad_f5[0xb]; // 0xf5(0x0b)
};

// ScriptStruct EmbarkConstructable.ConstructableStyleProxy
// Size: 0xd0 (Inherited: 0x00)
struct FConstructableStyleProxy {
	struct FEmbarkProxyTransform Proxy; // 0x00(0xa0)
	struct TWeakObjectPtr<struct UPrimitiveComponent> StyleAsComponent; // 0xa0(0x08)
	struct TScriptInterface<IConstructableStyleComponent> Style; // 0xa8(0x10)
	int32_t PartID; // 0xb8(0x04)
	struct FName AttachName; // 0xbc(0x08)
	char pad_c4[0xc]; // 0xc4(0x0c)
};

// ScriptStruct EmbarkConstructable.ConstructablePartTransformSelection
// Size: 0x140 (Inherited: 0x00)
struct FConstructablePartTransformSelection {
	struct FConstructablePartSelection PartSelection; // 0x00(0x0c)
	enum class EConstructablePartTransformSelectionType TransformType; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	struct FEmbarkSocketSelection SocketSelection; // 0x10(0x08)
	char pad_18[0x8]; // 0x18(0x08)
	struct FConstructableStyleProxy StyleProxy; // 0x20(0xd0)
	struct FConstructablePart Part; // 0xf0(0x38)
	struct TWeakObjectPtr<struct UPrimitiveComponent> StyleAsComponent; // 0x128(0x08)
	struct TScriptInterface<IConstructableStyleComponent> Style; // 0x130(0x10)
};

// ScriptStruct EmbarkConstructable.SLERPDriveParams
// Size: 0x14 (Inherited: 0x00)
struct FSLERPDriveParams {
	int32_t PhysicsConstraintIndex; // 0x00(0x04)
	bool bOrientationDrive; // 0x04(0x01)
	bool bAngularVelocityDrive; // 0x05(0x01)
	bool bDisableCollision; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
	float Spring; // 0x08(0x04)
	float Damper; // 0x0c(0x04)
	float MaxForce; // 0x10(0x04)
};

// ScriptStruct EmbarkConstructable.TSSDriveParams
// Size: 0x18 (Inherited: 0x00)
struct FTSSDriveParams {
	int32_t PhysicsConstraintIndex; // 0x00(0x04)
	bool bOrientationDriveTwist; // 0x04(0x01)
	bool bOrientationDriveSwing; // 0x05(0x01)
	bool bAngularVelocityDriveTwist; // 0x06(0x01)
	bool bAngularVelocityDriveSwing; // 0x07(0x01)
	bool bDisableCollision; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float Spring; // 0x0c(0x04)
	float Damper; // 0x10(0x04)
	float MaxForce; // 0x14(0x04)
};

// ScriptStruct EmbarkConstructable.LinearDriveParams
// Size: 0x14 (Inherited: 0x00)
struct FLinearDriveParams {
	int32_t PhysicsConstraintIndex; // 0x00(0x04)
	bool bXAxisEnabled; // 0x04(0x01)
	bool bYAxisEnabled; // 0x05(0x01)
	bool bZAxisEnabled; // 0x06(0x01)
	bool bDisableCollision; // 0x07(0x01)
	float Spring; // 0x08(0x04)
	float Damper; // 0x0c(0x04)
	float MaxForce; // 0x10(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructableSkeletalMeshStylePartSocketID
// Size: 0x0c (Inherited: 0x00)
struct FConstructableSkeletalMeshStylePartSocketID {
	int32_t SocketID; // 0x00(0x04)
	struct FName PartName; // 0x04(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableSkeletalMeshStylePartSocketIDContainer
// Size: 0x50 (Inherited: 0x00)
struct FConstructableSkeletalMeshStylePartSocketIDContainer {
	struct TMap<struct FName, struct FConstructableSkeletalMeshStylePartSocketID> Items; // 0x00(0x50)
};

// ScriptStruct EmbarkConstructable.ConstructableSkeletalMeshStylePartSurfacePointsContainer
// Size: 0x10 (Inherited: 0x00)
struct FConstructableSkeletalMeshStylePartSurfacePointsContainer {
	struct TArray<struct FVector> Points; // 0x00(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructableSkeletalMeshStylePartIDContainer
// Size: 0x10 (Inherited: 0x00)
struct FConstructableSkeletalMeshStylePartIDContainer {
	struct TArray<int32_t> PartIDs; // 0x00(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructableSkeletalMeshStyleProxyPartChildren
// Size: 0x10 (Inherited: 0x00)
struct FConstructableSkeletalMeshStyleProxyPartChildren {
	struct TArray<int32_t> ChildrenPartIDs; // 0x00(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructableMeshStyleSlotTransform
// Size: 0x90 (Inherited: 0x00)
struct FConstructableMeshStyleSlotTransform {
	struct FGameplayTagContainer SlotTags; // 0x00(0x20)
	struct FName Socket; // 0x20(0x08)
	char pad_28[0x8]; // 0x28(0x08)
	struct FTransform SlotTransform; // 0x30(0x60)
};

// ScriptStruct EmbarkConstructable.ConstructableStylePartListEntry
// Size: 0x140 (Inherited: 0x00)
struct FConstructableStylePartListEntry {
	struct FEmbarkSocketSelection SocketSelection; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
	struct FConstructableStyleProxy StyleProxy; // 0x10(0xd0)
	struct FName PartName; // 0xe0(0x08)
	int32_t PartID; // 0xe8(0x04)
	enum class EConstructablePartTransformSelectionType TransformType; // 0xec(0x01)
	char pad_ed[0x3]; // 0xed(0x03)
	struct FConstructablePart Part; // 0xf0(0x38)
	struct TWeakObjectPtr<struct UPrimitiveComponent> StyleAsComponent; // 0x128(0x08)
	struct TScriptInterface<IConstructableStyleComponent> Style; // 0x130(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructableStylePartList
// Size: 0x70 (Inherited: 0x00)
struct FConstructableStylePartList {
	struct FGameplayTagQuery PartQuery; // 0x00(0x48)
	struct FEmbarkPropertyOuter PropertyOuterContainer; // 0x48(0x10)
	struct TArray<struct FConstructableStylePartListEntry> PartList; // 0x58(0x10)
	struct AActor* Owner; // 0x68(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructablePartConfigOverride
// Size: 0x18 (Inherited: 0x00)
struct FConstructablePartConfigOverride {
	int16_t AffectedPartID; // 0x00(0x02)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t EventID; // 0x04(0x04)
	struct FABFloat MaxRotationSpeedDegPerSec; // 0x08(0x10)
};

// ScriptStruct EmbarkConstructable.OrientationSpeedFilter
// Size: 0x38 (Inherited: 0x00)
struct FOrientationSpeedFilter {
	enum class EOrientationFilterType OrientationFilterType; // 0x00(0x01)
	char pad_1[0x37]; // 0x01(0x37)
};

// ScriptStruct EmbarkConstructable.ConstructablePartTargetingConfig
// Size: 0x120 (Inherited: 0x00)
struct FConstructablePartTargetingConfig {
	struct FOrientationSpeedFilter OrientationInterpolationFilter; // 0x00(0x38)
	float OrientationInterpolationSpeed; // 0x38(0x04)
	float MaxRotationSpeedDegPerSec; // 0x3c(0x04)
	float HasReachedTargetAcceptanceThreshold; // 0x40(0x04)
	float PredictionResponsivenessUNorm; // 0x44(0x04)
	float ProjectileSpeedCmPerSec; // 0x48(0x04)
	bool bDirectlyUpdatePartOrientations; // 0x4c(0x01)
	bool bPreferLobbingProjectiles; // 0x4d(0x01)
	bool bUsePartRotationSpeedDamping; // 0x4e(0x01)
	char pad_4f[0x1]; // 0x4f(0x01)
	struct FGameplayTagQuery RotationSpeedDampingPartQuery; // 0x50(0x48)
	struct FRuntimeFloatCurve PartDestroyedCountToRotationSpeedMultiplierCurve; // 0x98(0x88)
};

// ScriptStruct EmbarkConstructable.ConstructablePartGroupTargetingConfig
// Size: 0x168 (Inherited: 0x00)
struct FConstructablePartGroupTargetingConfig {
	struct FGameplayTagQuery RequiredPartTags; // 0x00(0x48)
	struct FConstructablePartTargetingConfig Config; // 0x48(0x120)
};

// ScriptStruct EmbarkConstructable.ConstructablePartPivotConfig
// Size: 0x58 (Inherited: 0x00)
struct FConstructablePartPivotConfig {
	struct FGameplayTagQuery RequiredPartTags; // 0x00(0x48)
	struct FName SocketName; // 0x48(0x08)
	enum class EConstructablePartPivotType PivotType; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// ScriptStruct EmbarkConstructable.TargetingServiceParams
// Size: 0x08 (Inherited: 0x00)
struct FTargetingServiceParams {
	float SpeedModifier; // 0x00(0x04)
	enum class EConstructableFeatureQualityLevel ReplicationResolution; // 0x04(0x01)
	bool bSendTerminalValue; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
};

// ScriptStruct EmbarkConstructable.ConstructableTrainingShapeInfo
// Size: 0x68 (Inherited: 0x00)
struct FConstructableTrainingShapeInfo {
	struct FConstructablePartSelection SelectedPart; // 0x00(0x0c)
	enum class EConstructableTrainingShape Shape; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	struct FVector RelativeLocation; // 0x10(0x18)
	struct FRotator RelativeRotation; // 0x28(0x18)
	struct FVector HalfExtent; // 0x40(0x18)
	float Radius; // 0x58(0x04)
	float HalfHeight; // 0x5c(0x04)
	struct FName DefaultTag; // 0x60(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableStyleSocket
// Size: 0x70 (Inherited: 0x00)
struct FConstructableStyleSocket {
	struct FTransform SocketTransform; // 0x00(0x60)
	struct FName SocketName; // 0x60(0x08)
	char pad_68[0x8]; // 0x68(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableStyleSocketGroupDataArray
// Size: 0x10 (Inherited: 0x00)
struct FConstructableStyleSocketGroupDataArray {
	struct TArray<struct FName> SocketList; // 0x00(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructableStyleSKSocketGroupContainer
// Size: 0x50 (Inherited: 0x00)
struct FConstructableStyleSKSocketGroupContainer {
	struct TMap<struct FName, struct FConstructableStyleSocketGroupDataArray> SocketGroupList; // 0x00(0x50)
};

// ScriptStruct EmbarkConstructable.ConstructableSocketRepIndexData
// Size: 0x0c (Inherited: 0x00)
struct FConstructableSocketRepIndexData {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct EmbarkConstructable.ConstructablePartAttributeSetMetaData
// Size: 0x48 (Inherited: 0x00)
struct FConstructablePartAttributeSetMetaData {
	struct FSoftClassPath CoreAttributeSetClass; // 0x00(0x20)
	int32_t NrAttributesPerSet; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<struct UObject*> PartAttributeSetClasses; // 0x28(0x10)
	struct TArray<struct FName> BaseAttributeNames; // 0x38(0x10)
};

// ScriptStruct EmbarkConstructable.ConstructablePartIDRange
// Size: 0x08 (Inherited: 0x00)
struct FConstructablePartIDRange {
	int32_t BasePartID; // 0x00(0x04)
	int32_t NrIDs; // 0x04(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructablePartParentInfo
// Size: 0x28 (Inherited: 0x00)
struct FConstructablePartParentInfo {
	struct UPrimitiveComponent* ParentStyleComponent; // 0x00(0x08)
	struct TScriptInterface<IConstructableStyleComponent> Style; // 0x08(0x10)
	int32_t ParentPartID; // 0x18(0x04)
	struct FName AttachSocketName; // 0x1c(0x08)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct EmbarkConstructable.ConstructableProxyPart
// Size: 0xe0 (Inherited: 0x00)
struct FConstructableProxyPart {
	struct FTransform RelativeToParentTransform; // 0x00(0x60)
	struct FGameplayTagContainer PartTags; // 0x60(0x20)
	struct FRotator InitialRelativeRotation; // 0x80(0x18)
	struct FConstructablePartIDRange PartIDRange; // 0x98(0x08)
	struct FConstructablePartParentInfo ParentPart; // 0xa0(0x28)
	struct FName PartName; // 0xc8(0x08)
	bool bIsDestroyed; // 0xd0(0x01)
	char pad_d1[0xf]; // 0xd1(0x0f)
};

// ScriptStruct EmbarkConstructable.LinearConstraintData
// Size: 0x08 (Inherited: 0x00)
struct FLinearConstraintData {
	float Limit; // 0x00(0x04)
	enum class ELinearConstraintMotion XMotion; // 0x04(0x01)
	enum class ELinearConstraintMotion YMotion; // 0x05(0x01)
	enum class ELinearConstraintMotion ZMotion; // 0x06(0x01)
	bool bIsEnabled; // 0x07(0x01)
};

// ScriptStruct EmbarkConstructable.AngularConstraintData
// Size: 0x40 (Inherited: 0x00)
struct FAngularConstraintData {
	float PitchLimitDegrees; // 0x00(0x04)
	float YawLimitDegrees; // 0x04(0x04)
	float RollLimitDegrees; // 0x08(0x04)
	float PitchLimitMiddleDegrees; // 0x0c(0x04)
	float YawLimitMiddleDegrees; // 0x10(0x04)
	float RollLimitMiddleDegrees; // 0x14(0x04)
	enum class EAngularConstraintMotion PitchMotion; // 0x18(0x01)
	enum class EAngularConstraintMotion YawMotion; // 0x19(0x01)
	enum class EAngularConstraintMotion RollMotion; // 0x1a(0x01)
	bool bIsEnabled; // 0x1b(0x01)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct FVector TwistAxis; // 0x20(0x18)
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct EmbarkConstructable.ConstructableBoundsId
// Size: 0x08 (Inherited: 0x00)
struct FConstructableBoundsId {
	char pad_0[0x8]; // 0x00(0x08)
};

