// Class DLSS.DLSSOverrideSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UDLSSOverrideSettings : UObject {
	enum class EDLSSSettingOverride EnableDLSSInEditorViewportsOverride; // 0x98(0x01)
	enum class EDLSSSettingOverride EnableDLSSInPlayInEditorViewportsOverride; // 0x99(0x01)
	bool bShowDLSSIncompatiblePluginsToolsWarnings; // 0x9a(0x01)
	enum class EDLSSSettingOverride ShowDLSSSDebugOnScreenMessages; // 0x9b(0x01)
};

// Class DLSS.DLSSSettings
// Size: 0xe0 (Inherited: 0xa0)
struct UDLSSSettings : UObject {
	bool bEnableDLSSD3D12; // 0x98(0x01)
	bool bEnableDLSSD3D11; // 0x99(0x01)
	bool bEnableDLSSVulkan; // 0x9a(0x01)
	bool bEnableDLSSInEditorViewports; // 0x9b(0x01)
	bool bEnableDLSSInPlayInEditorViewports; // 0x9c(0x01)
	bool bShowDLSSSDebugOnScreenMessages; // 0x9d(0x01)
	struct FString GenericDLSSBinaryPath; // 0xa0(0x10)
	bool bGenericDLSSBinaryExists; // 0xb0(0x01)
	uint32_t NVIDIANGXApplicationId; // 0xb4(0x04)
	struct FString CustomDLSSBinaryPath; // 0xb8(0x10)
	bool bCustomDLSSBinaryExists; // 0xc8(0x01)
	bool bAllowOTAUpdate; // 0xc9(0x01)
	bool bShowDLSSIncompatiblePluginsToolsWarnings; // 0xca(0x01)
	enum class EDLSSPreset DLAAPreset; // 0xcb(0x01)
	enum class EDLSSPreset DLSSQualityPreset; // 0xcd(0x01)
	enum class EDLSSPreset DLSSBalancedPreset; // 0xce(0x01)
	enum class EDLSSPreset DLSSPerformancePreset; // 0xcf(0x01)
	enum class EDLSSPreset DLSSUltraPerformancePreset; // 0xd0(0x01)
	enum class EDLSSRRPreset DLAARRPreset; // 0xd1(0x01)
	enum class EDLSSRRPreset DLSSRRQualityPreset; // 0xd3(0x01)
	enum class EDLSSRRPreset DLSSRRBalancedPreset; // 0xd4(0x01)
	enum class EDLSSRRPreset DLSSRRPerformancePreset; // 0xd5(0x01)
	enum class EDLSSRRPreset DLSSRRUltraPerformancePreset; // 0xd6(0x01)
	char pad_d8[0x8]; // 0xd8(0x08)
};

