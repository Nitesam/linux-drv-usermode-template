// Class EmbarkGameplay.EmbarkFovHelpers
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkFovHelpers : UObject {

	bool IsInFrustum(struct FVector& LocationToCheck); // Function EmbarkGameplay.EmbarkFovHelpers.IsInFrustum // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5da5a00
	struct FMatrix GetViewProjectionMatrix(struct UObject* WorldContextObject); // Function EmbarkGameplay.EmbarkFovHelpers.GetViewProjectionMatrix // (Final|Native|Static|Private|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5dabfd0
	struct FMatrix GetModelViewProjectionMatrix(struct UObject* WorldContextObject, struct FTransform& Transform); // Function EmbarkGameplay.EmbarkFovHelpers.GetModelViewProjectionMatrix // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5dac860
	struct FMatrix GetMatrixFromTransform(struct FTransform& Transform); // Function EmbarkGameplay.EmbarkFovHelpers.GetMatrixFromTransform // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5da45c0
	struct FMatrix GetInverseMatrix(struct FMatrix& Matrix); // Function EmbarkGameplay.EmbarkFovHelpers.GetInverseMatrix // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5dac690
	struct FTransform GetCustomFovWorldTransform(struct UObject* WorldContextObject, struct FTransform& Transform, float HorizontalFOV); // Function EmbarkGameplay.EmbarkFovHelpers.GetCustomFovWorldTransform // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5daca00
	struct FMatrix GetCustomFovModelViewProjectionMatrix(struct UObject* WorldContextObject, struct FMatrix& TransformMatrix, float HorizontalFOV); // Function EmbarkGameplay.EmbarkFovHelpers.GetCustomFovModelViewProjectionMatrix // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5dae3b0
};

// Class EmbarkGameplay.EmbarkActor
// Size: 0x470 (Inherited: 0x3a0)
struct AEmbarkActor : AActor {
	char pad_3a0[0x78]; // 0x3a0(0x78)
	struct FMulticastInlineDelegate OnOwnerReplicated; // 0x418(0x10)
	bool bDefaultAbilitySystemReplicates; // 0x428(0x01)
	enum class EGameplayEffectReplicationMode DefaultAbilitySystemReplicationMode; // 0x411(0x01)
	struct UEmbarkAbilitySystemComponent* AbilitySystem; // 0x408(0x08)
	float StillInWorldCheckVelocityLookAheadTime; // 0x400(0x04)
	char pad_436[0x2]; // 0x436(0x02)
	bool bDisableWhenOutOfBounds; // 0x438(0x01)
	bool bAllowTickInViewport; // 0x410(0x01)
	struct AActor* LastPlayerDamageInstigator; // 0x430(0x08)
	char pad_442[0x2e]; // 0x442(0x2e)

	void UnregisterOnPrePhysicsEvent(); // Function EmbarkGameplay.EmbarkActor.UnregisterOnPrePhysicsEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x5da5aa0
	void UnregisterOnPostPhysicsEvent(); // Function EmbarkGameplay.EmbarkActor.UnregisterOnPostPhysicsEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x5dae9b0
	void SetDefaultNetDormancy(enum class ENetDormancy DefaultNetDormancy); // Function EmbarkGameplay.EmbarkActor.SetDefaultNetDormancy // (Final|Native|Protected) // @ game+0x5da4710
	void RegisterOnPrePhysicsEvent(); // Function EmbarkGameplay.EmbarkActor.RegisterOnPrePhysicsEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x5dafc00
	void RegisterOnPostPhysicsEvent(); // Function EmbarkGameplay.EmbarkActor.RegisterOnPostPhysicsEvent // (Final|Native|Protected|BlueprintCallable) // @ game+0x5da6c70
	float ReceiveTakeDamage(float DamageAmount, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* DamageCauser); // Function EmbarkGameplay.EmbarkActor.ReceiveTakeDamage // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveRewindForReplay(); // Function EmbarkGameplay.EmbarkActor.ReceiveRewindForReplay // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePreInitializeComponents(); // Function EmbarkGameplay.EmbarkActor.ReceivePreInitializeComponents // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostInitializeComponents(); // Function EmbarkGameplay.EmbarkActor.ReceivePostInitializeComponents // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnRepOwner(); // Function EmbarkGameplay.EmbarkActor.ReceiveOnRepOwner // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnRepInstigator(); // Function EmbarkGameplay.EmbarkActor.ReceiveOnRepInstigator // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnPrePhysics(); // Function EmbarkGameplay.EmbarkActor.ReceiveOnPrePhysics // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnPostPhysics(); // Function EmbarkGameplay.EmbarkActor.ReceiveOnPostPhysics // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnGameplayTagUpdated(struct FGameplayTag& Tag, bool TagExists); // Function EmbarkGameplay.EmbarkActor.ReceiveOnGameplayTagUpdated // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnAbilitySystemDestroyed(struct UEmbarkAbilitySystemComponent* EmbarkASC); // Function EmbarkGameplay.EmbarkActor.ReceiveOnAbilitySystemDestroyed // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnAbilitySystemCreated(struct UEmbarkAbilitySystemComponent* EmbarkASC); // Function EmbarkGameplay.EmbarkActor.ReceiveOnAbilitySystemCreated // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnGameplayTagUpdated(struct FGameplayTag& Tag, bool TagExists); // Function EmbarkGameplay.EmbarkActor.OnGameplayTagUpdated // (Final|Native|Protected|HasOutParms) // @ game+0x5daeab0
	void IntializeEmbarkActor(); // Function EmbarkGameplay.EmbarkActor.IntializeEmbarkActor // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool HasASC(); // Function EmbarkGameplay.EmbarkActor.HasASC // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dacd10
	struct UEmbarkAbilitySystemComponent* GetOrCreateASC_Server(); // Function EmbarkGameplay.EmbarkActor.GetOrCreateASC_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5da7370
	struct UEmbarkAbilitySystemComponent* GetASC(); // Function EmbarkGameplay.EmbarkActor.GetASC // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dab7c0
	void BP_SetTeam(enum class EEmbarkTeamId NewTeam); // Function EmbarkGameplay.EmbarkActor.BP_SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x5da7030
	void BP_OutsideWorldBoundsEvent(); // Function EmbarkGameplay.EmbarkActor.BP_OutsideWorldBoundsEvent // (Native|Event|Protected|BlueprintEvent) // @ game+0x2c82670
	enum class EEmbarkTeamId BP_GetTeam(); // Function EmbarkGameplay.EmbarkActor.BP_GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5daf5d0
	void BP_FellOutOfWorldEvent(struct UDamageType* dmgType); // Function EmbarkGameplay.EmbarkActor.BP_FellOutOfWorldEvent // (Native|Event|Protected|BlueprintEvent) // @ game+0x5dacc60
};

// Class EmbarkGameplay.EmbarkActorComponent
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkActorComponent : UActorComponent {

	void ReceiveInitializeComponent(); // Function EmbarkGameplay.EmbarkActorComponent.ReceiveInitializeComponent // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.EmbarkActorStateInterpolatorComponent
// Size: 0x200 (Inherited: 0x200)
struct UEmbarkActorStateInterpolatorComponent : UStateInterpolatorComponent {
};

// Class EmbarkGameplay.EmbarkActorTransformInterpolatorComponent
// Size: 0x4d0 (Inherited: 0x200)
struct UEmbarkActorTransformInterpolatorComponent : UStateInterpolatorComponent {
	struct FReplicatedTransform ReplicatedRootTransform; // 0x200(0x68)
	bool bUseBodyInstanceTransform; // 0x268(0x01)
	char pad_269[0x3]; // 0x269(0x03)
	int32_t EmbarkID; // 0x26c(0x04)
	bool bHighFidelityBlackboardNetworking; // 0x270(0x01)
	char pad_271[0x87]; // 0x271(0x87)
	struct UTransformInterpolator* TransformInterpolator; // 0x2f8(0x08)
	struct AEmbarkFastReplicatorTransformInterpolator* TransformFastReplicator; // 0x300(0x08)
	struct AEmbarkActorBlackBoardFastReplicatorTransformInterpolator* BBTransformFastReplicator; // 0x308(0x08)
	char pad_310[0x1c0]; // 0x310(0x1c0)

	bool TryGetLatestReceivedTransformServerTimestamp(float& OutTimestamp); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.TryGetLatestReceivedTransformServerTimestamp // (Final|Native|Public|HasOutParms|Const) // @ game+0x5daa110
	bool TryGetInterpolatedTransform(struct FTransform& OutTransform); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.TryGetInterpolatedTransform // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5da3f50
	bool TryGetInterpolatedLinearVelocity(struct FVector& OutLinearVelocity); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.TryGetInterpolatedLinearVelocity // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5da8d20
	bool TryGetInterpolatedAngularVelocity(struct FVector& OutAngularVelocity); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.TryGetInterpolatedAngularVelocity // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5da3210
	void StopUsingPredictedTransform(); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.StopUsingPredictedTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x5dafae0
	void SetShouldUpdateActorTransform(bool bEnabled); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.SetShouldUpdateActorTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x5da36a0
	void SetInterpolatorEnabled(bool bEnabled, bool bSkipSetTransformRightAway); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.SetInterpolatorEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5daee60
	void SetForceUpdateEveryFrame(bool bForceUpdate); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.SetForceUpdateEveryFrame // (Final|Native|Public) // @ game+0x5db1460
	void SetEnableFastReplicationDefault(bool bInCanSimulatePhysics, bool bInStartsInSleeping); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.SetEnableFastReplicationDefault // (Final|Native|Public) // @ game+0x5daa370
	void SetAngularVelocity_Server(struct FVector& InAngularVelocity); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.SetAngularVelocity_Server // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5da8750
	void ResetInterpolationState(); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.ResetInterpolationState // (Final|Native|Public|BlueprintCallable) // @ game+0x5da9680
	void OnWake_Server(struct UPrimitiveComponent* Component, struct FName bone); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.OnWake_Server // (Final|Native|Private) // @ game+0x5da7220
	void OnSleep_Server(struct UPrimitiveComponent* Component, struct FName bone); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.OnSleep_Server // (Final|Native|Private) // @ game+0x5db08b0
	void OnRep_RootTransform(); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.OnRep_RootTransform // (Final|Native|Private) // @ game+0x5db27c0
	bool IsInterpolatorEnabled(); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.IsInterpolatorEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5daa6f0
	void InterpolateFromNewTransformWithTransitionPeriod(struct FTransform& NewTransform, float InPredictedTransformTransitionPeriod, struct FDelegate& InPredictedTransformDelegate, struct FVector& PredictedVelocity, struct FVector& LinearVelocity, struct FVector& AngularVelocity, bool bEnableInterpolatorIfDisabled); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.InterpolateFromNewTransformWithTransitionPeriod // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5da2a50
	void InterpolateFromNewTransform(struct FTransform& NewTransform, struct FVector& LinearVelocity, struct FVector& AngularVelocity, bool bEnableInterpolatorIfDisabled, bool bDisablePredictionIfEnabled); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.InterpolateFromNewTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5da9a10
	bool GetShouldUpdateActorTransform(); // Function EmbarkGameplay.EmbarkActorTransformInterpolatorComponent.GetShouldUpdateActorTransform // (Final|Native|Public|BlueprintCallable) // @ game+0x5da4f00
};

// Class EmbarkGameplay.WidgetMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UWidgetMixinLibrary : UObject {

	void SetRenderAngle(struct UWidget* Widget, float Angle); // Function EmbarkGameplay.WidgetMixinLibrary.SetRenderAngle // (Final|Native|Static|Public) // @ game+0x5da80e0
};

// Class EmbarkGameplay.ActorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UActorMixinLibrary : UObject {

	void TakeDamage(struct AActor* Actor, float DamageAmount, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* DamageCauser); // Function EmbarkGameplay.ActorMixinLibrary.TakeDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5dab290
	struct AController* GetInstigatorController(struct AActor* Actor); // Function EmbarkGameplay.ActorMixinLibrary.GetInstigatorController // (Final|Native|Static|Public) // @ game+0x5dadc70
	struct APawn* GetInstigator(struct AActor* Actor); // Function EmbarkGameplay.ActorMixinLibrary.GetInstigator // (Final|Native|Static|Public) // @ game+0x5da95d0
};

// Class EmbarkGameplay.PlayerStateMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerStateMixinLibrary : UObject {

	void SetScore(struct APlayerState* PlayerState, float NewScore); // Function EmbarkGameplay.PlayerStateMixinLibrary.SetScore // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5da5800
};

// Class EmbarkGameplay.ActorComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UActorComponentMixinLibrary : UObject {

	void SetCanEverAffectNavigation(struct UActorComponent* ActorComponent, bool bValue); // Function EmbarkGameplay.ActorComponentMixinLibrary.SetCanEverAffectNavigation // (Final|Native|Static|Public) // @ game+0x5dacd40
	void RegisterComponent(struct UActorComponent* ComponentToRegister); // Function EmbarkGameplay.ActorComponentMixinLibrary.RegisterComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5dac490
};

// Class EmbarkGameplay.InputComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UInputComponentMixinLibrary : UObject {

	bool HasBindings(struct UInputComponent* InputComponent); // Function EmbarkGameplay.InputComponentMixinLibrary.HasBindings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5dadf20
	void ClearBindingValues(struct UInputComponent* InputComponent); // Function EmbarkGameplay.InputComponentMixinLibrary.ClearBindingValues // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5daf7c0
};

// Class EmbarkGameplay.DataTableMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDataTableMixinLibrary : UObject {

	bool FindTableCellAsString(struct UDataTable* DataTable, struct FName RowName, struct FName ColumnName, struct FString& OutResultString); // Function EmbarkGameplay.DataTableMixinLibrary.FindTableCellAsString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5db0b70
	bool FindTableCellAsFloat(struct UDataTable* DataTable, struct FName RowName, struct FName ColumnName, float& OutResultFloat); // Function EmbarkGameplay.DataTableMixinLibrary.FindTableCellAsFloat // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5db1f70
};

// Class EmbarkGameplay.StringMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UStringMixinLibrary : UObject {

	void RemoveAt(struct FString& StringToChange, int32_t StartIdx, int32_t Count); // Function EmbarkGameplay.StringMixinLibrary.RemoveAt // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5dabd60
};

// Class EmbarkGameplay.SoundWaveMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USoundWaveMixinLibrary : UObject {

	void SetSubtitlesText(struct USoundWave* SoundWave, int32_t Index, struct FText& Text); // Function EmbarkGameplay.SoundWaveMixinLibrary.SetSubtitlesText // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da8430
	void SetIsMature(struct USoundWave* SoundWave, bool bMature); // Function EmbarkGameplay.SoundWaveMixinLibrary.SetIsMature // (Final|Native|Static|Public) // @ game+0x5daafc0
	bool GetIsMature(struct USoundWave* SoundWave); // Function EmbarkGameplay.SoundWaveMixinLibrary.GetIsMature // (Final|Native|Static|Public) // @ game+0x5db1ec0
};

// Class EmbarkGameplay.SubtitleCueMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USubtitleCueMixinLibrary : UObject {

	void SetText(struct FSubtitleCue& SubtitleCue, struct FText& Text); // Function EmbarkGameplay.SubtitleCueMixinLibrary.SetText // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da9840
};

// Class EmbarkGameplay.WorldMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UWorldMixinLibrary : UObject {

	struct UWorldPartition* GetWorldPartition(struct UWorld* World); // Function EmbarkGameplay.WorldMixinLibrary.GetWorldPartition // (Final|Native|Static|Public) // @ game+0x5da2f80
	struct UWorldComposition* GetWorldComposition(struct UWorld* World); // Function EmbarkGameplay.WorldMixinLibrary.GetWorldComposition // (Final|Native|Static|Public) // @ game+0x5daf9a0
	struct UEnvQueryManager* GetEnvQueryManager(struct UWorld* World); // Function EmbarkGameplay.WorldMixinLibrary.GetEnvQueryManager // (Final|Native|Static|Public) // @ game+0x5da96e0
	struct UDataLayerManager* GetDataLayerManager(struct UWorld* World); // Function EmbarkGameplay.WorldMixinLibrary.GetDataLayerManager // (Final|Native|Static|Public) // @ game+0x5da8c70
};

// Class EmbarkGameplay.PawnMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPawnMixinLibrary : UObject {

	void SetPlayerState(struct APawn* Pawn, struct APlayerState* PlayerState); // Function EmbarkGameplay.PawnMixinLibrary.SetPlayerState // (Final|Native|Static|Public) // @ game+0x5db1540
	enum class EAutoPossessAI GetAutoPossessAI(struct APawn* Pawn); // Function EmbarkGameplay.PawnMixinLibrary.GetAutoPossessAI // (Final|Native|Static|Public) // @ game+0x5da81e0
};

// Class EmbarkGameplay.MaterialParameterCollectionMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMaterialParameterCollectionMixinLibrary : UObject {

	void SetVectorDefaultValue(struct UMaterialParameterCollection* MaterialParameterCollection, int32_t Index, struct FLinearColor DefaultValue); // Function EmbarkGameplay.MaterialParameterCollectionMixinLibrary.SetVectorDefaultValue // (Final|Native|Static|Public|HasDefaults) // @ game+0x5da9de0
};

// Class EmbarkGameplay.AIControllerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIControllerMixinLibrary : UObject {

	struct UAIPerceptionComponent* GetPerceptionComponent(struct AAIController* AIController); // Function EmbarkGameplay.AIControllerMixinLibrary.GetPerceptionComponent // (Final|Native|Static|Public) // @ game+0x5daf510
};

// Class EmbarkGameplay.ControllerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UControllerMixinLibrary : UObject {

	void SetStartSpot(struct AController* Controller, struct AActor* StartSpot); // Function EmbarkGameplay.ControllerMixinLibrary.SetStartSpot // (Final|Native|Static|Public) // @ game+0x5daa740
	struct AActor* GetStartSpot(struct AController* Controller); // Function EmbarkGameplay.ControllerMixinLibrary.GetStartSpot // (Final|Native|Static|Public) // @ game+0x5db1a00
};

// Class EmbarkGameplay.ConeConstraintMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConeConstraintMixinLibrary : UObject {

	void SetIsSoftConstraint(struct FConeConstraint& Constraint, bool bValue); // Function EmbarkGameplay.ConeConstraintMixinLibrary.SetIsSoftConstraint // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dab4f0
};

// Class EmbarkGameplay.TwistConstraintMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UTwistConstraintMixinLibrary : UObject {

	void SetIsSoftConstraint(struct FTwistConstraint& Constraint, bool bValue); // Function EmbarkGameplay.TwistConstraintMixinLibrary.SetIsSoftConstraint // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da4990
};

// Class EmbarkGameplay.LinearConstraintMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULinearConstraintMixinLibrary : UObject {

	void SetIsSoftConstraint(struct FLinearConstraint& Constraint, bool bValue); // Function EmbarkGameplay.LinearConstraintMixinLibrary.SetIsSoftConstraint // (Final|Native|Static|Public|HasOutParms) // @ game+0x5daba10
};

// Class EmbarkGameplay.ConstraintInstanceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstraintInstanceMixinLibrary : UObject {

	void SetScaleLinearLimits(struct FConstraintInstance& ConstraintInstance, bool bValue); // Function EmbarkGameplay.ConstraintInstanceMixinLibrary.SetScaleLinearLimits // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da93f0
};

// Class EmbarkGameplay.ConstraintProfilePropertiesMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstraintProfilePropertiesMixinLibrary : UObject {

	void SetParentDominates(struct FConstraintProfileProperties& ConstraintProfileProperties, bool bValue); // Function EmbarkGameplay.ConstraintProfilePropertiesMixinLibrary.SetParentDominates // (Final|Native|Static|Public|HasOutParms) // @ game+0x5db1b50
};

// Class EmbarkGameplay.BTServiceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UBTServiceMixinLibrary : UObject {

	void SetIntervalAndRandomDeviation(struct UBTService* BTService, float Interval, float RandomDeviation); // Function EmbarkGameplay.BTServiceMixinLibrary.SetIntervalAndRandomDeviation // (Final|Native|Static|Public) // @ game+0x5da3c80
};

// Class EmbarkGameplay.AIStimulusMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIStimulusMixinLibrary : UObject {

	bool IsSensedBy(struct FAIStimulus& AIStimulus, struct UAISense* SenseClass); // Function EmbarkGameplay.AIStimulusMixinLibrary.IsSensedBy // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da9070
};

// Class EmbarkGameplay.AIPerceptionComponentLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAIPerceptionComponentLibrary : UObject {

	struct FVector GetActorLocation(struct UAIPerceptionComponent* AIPerceptionComponent, struct AActor* Actor); // Function EmbarkGameplay.AIPerceptionComponentLibrary.GetActorLocation // (Final|Native|Static|Public|HasDefaults) // @ game+0x5da2620
};

// Class EmbarkGameplay.AnimInstanceScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAnimInstanceScriptMixinLibrary : UObject {

	bool GetCurveValueDefault(struct UAnimInstance* AnimInstance, struct FName CurveName, float& OutValue); // Function EmbarkGameplay.AnimInstanceScriptMixinLibrary.GetCurveValueDefault // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da7620
};

// Class EmbarkGameplay.CharacterMovementComponentScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UCharacterMovementComponentScriptMixinLibrary : UObject {

	void ResetToDefaultMovementMode(struct UCharacterMovementComponent* MovementComponent); // Function EmbarkGameplay.CharacterMovementComponentScriptMixinLibrary.ResetToDefaultMovementMode // (Final|Native|Static|Public) // @ game+0x5da3b20
};

// Class EmbarkGameplay.PrimitiveComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPrimitiveComponentMixinLibrary : UObject {

	bool SetBodyInstanceGenerateWakeEvents(struct UPrimitiveComponent* InPrimitiveComponent, bool bNewValue, struct FName InBoneName); // Function EmbarkGameplay.PrimitiveComponentMixinLibrary.SetBodyInstanceGenerateWakeEvents // (Final|Native|Static|Private) // @ game+0x5da9290
	struct FBodyInstance GetPrimitiveBodyInstance(struct UPrimitiveComponent* InPrimitiveComponent, bool& bOutSucess, struct FName InBoneName, bool bGetWelded); // Function EmbarkGameplay.PrimitiveComponentMixinLibrary.GetPrimitiveBodyInstance // (Final|Native|Static|Private|HasOutParms) // @ game+0x5db1640
	float GetLastRenderTimeOnScreen(struct UPrimitiveComponent* InPrimitiveComponent); // Function EmbarkGameplay.PrimitiveComponentMixinLibrary.GetLastRenderTimeOnScreen // (Final|Native|Static|Private) // @ game+0x5da4f20
	float GetLastRenderTime(struct UPrimitiveComponent* InPrimitiveComponent); // Function EmbarkGameplay.PrimitiveComponentMixinLibrary.GetLastRenderTime // (Final|Native|Static|Private) // @ game+0x5dae880
	void CheckForOverlaps(struct UPrimitiveComponent* InPrimitiveComponent); // Function EmbarkGameplay.PrimitiveComponentMixinLibrary.CheckForOverlaps // (Final|Native|Static|Private) // @ game+0x5dad910
};

// Class EmbarkGameplay.BodyInstanceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UBodyInstanceMixinLibrary : UObject {

	void SetInstanceNotifyRBCollision(struct FBodyInstance& InBodyInstance, bool bNewNotifyCollision); // Function EmbarkGameplay.BodyInstanceMixinLibrary.SetInstanceNotifyRBCollision // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da6b60
	void SetEnableGravity(struct FBodyInstance& InBodyInstance, bool bGravityEnabled); // Function EmbarkGameplay.BodyInstanceMixinLibrary.SetEnableGravity // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dae560
	bool IsWelded(struct FBodyInstance& InBodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.IsWelded // (Final|Native|Static|Public|HasOutParms) // @ game+0x5da6640
	struct FBodyInstance GetWeldedParent(struct FBodyInstance& InBodyInstance, bool& bOutSucess); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetWeldedParent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5db21c0
	struct FVector GetPhysicsBodyLinearVelocity(struct FBodyInstance& BodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetPhysicsBodyLinearVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5db1da0
	struct FBox GetPhysicsBodyBounds(struct FBodyInstance& BodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetPhysicsBodyBounds // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5db11b0
	struct FVector GetPhysicsBodyAngularVelocityRad(struct FBodyInstance& BodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetPhysicsBodyAngularVelocityRad // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5da7dc0
	struct UPrimitiveComponent* GetOwnerComponent(struct FBodyInstance& InBodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetOwnerComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dab5f0
	int32_t GetInstanceBodyIndex(struct FBodyInstance& InBodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetInstanceBodyIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5daf100
	struct FName GetBoneName(struct FBodyInstance& InBodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetBoneName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dace80
	float GetBodyMass(struct FBodyInstance& InBodyInstance); // Function EmbarkGameplay.BodyInstanceMixinLibrary.GetBodyMass // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dafb40
};

// Class EmbarkGameplay.SimpleConstructionScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USimpleConstructionScriptMixinLibrary : UObject {

	void GetAllNodes(struct USimpleConstructionScript* Script, struct TArray<struct USCS_Node*>& Nodes); // Function EmbarkGameplay.SimpleConstructionScriptMixinLibrary.GetAllNodes // (Final|Native|Static|Private|HasOutParms) // @ game+0x5da4830
};

// Class EmbarkGameplay.ClassScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UClassScriptMixinLibrary : UObject {

	struct UStruct* GetSuperStruct(struct UObject* Class); // Function EmbarkGameplay.ClassScriptMixinLibrary.GetSuperStruct // (Final|Native|Static|Private) // @ game+0x5da3020
	struct USimpleConstructionScript* GetSimpleConstructionScript(struct UObject* Class); // Function EmbarkGameplay.ClassScriptMixinLibrary.GetSimpleConstructionScript // (Final|Native|Static|Private) // @ game+0x5da6490
};

// Class EmbarkGameplay.SCSNodeScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USCSNodeScriptMixinLibrary : UObject {

	struct UActorComponent* GetActualComponentTemplate(struct USCS_Node* Node, struct UObject* Class); // Function EmbarkGameplay.SCSNodeScriptMixinLibrary.GetActualComponentTemplate // (Final|Native|Static|Private) // @ game+0x5da9f40
};

// Class EmbarkGameplay.FBoxScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFBoxScriptMixinLibrary : UObject {

	struct TArray<struct FVector> GetBoxPoints(struct FBox& Box); // Function EmbarkGameplay.FBoxScriptMixinLibrary.GetBoxPoints // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5dae9d0
};

// Class EmbarkGameplay.QuatScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UQuatScriptMixinLibrary : UObject {

	struct FQuat ShortestDelta(struct FQuat& Source, struct FQuat& Target); // Function EmbarkGameplay.QuatScriptMixinLibrary.ShortestDelta // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5da42c0
	float DotProduct(struct FQuat& A, struct FQuat& B); // Function EmbarkGameplay.QuatScriptMixinLibrary.DotProduct // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5daa9c0
};

// Class EmbarkGameplay.CameraComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UCameraComponentMixinLibrary : UObject {

	void RemoveBlendable(struct UCameraComponent* CameraComponent, struct UMaterialInterface* MaterialInterface); // Function EmbarkGameplay.CameraComponentMixinLibrary.RemoveBlendable // (Final|Native|Static|Public) // @ game+0x5daad30
	void AddOrUpdateBlendable(struct UCameraComponent* CameraComponent, struct UMaterialInterface* MaterialInterface, float Weight); // Function EmbarkGameplay.CameraComponentMixinLibrary.AddOrUpdateBlendable // (Final|Native|Static|Public) // @ game+0x5da8900
};

// Class EmbarkGameplay.EmbarkAvoidanceComponent
// Size: 0x1d0 (Inherited: 0x160)
struct UEmbarkAvoidanceComponent : UActorComponent {
	struct FEmbarkAvoidanceAgentSettings Settings; // 0x160(0x24)
	char pad_184[0x4]; // 0x184(0x04)
	struct FVector IdealVelocityAvoidance; // 0x188(0x18)
	struct FVector LockedAvoidanceVelocity; // 0x1a0(0x18)
	float AvoidanceLockTimer; // 0x1b8(0x04)
	int32_t AvoidanceUID; // 0x1bc(0x04)
	char bUseRVOAvoidance : 1; // 0x1c0(0x01)
	char pad_1c0_1 : 7; // 0x1c0(0x01)
	char pad_1c1[0xf]; // 0x1c1(0x0f)

	void SetAvoidanceEnabled(bool bEnable); // Function EmbarkGameplay.EmbarkAvoidanceComponent.SetAvoidanceEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5dba180
	void Initialize(struct FEmbarkAvoidanceAgentSettings& InSettings); // Function EmbarkGameplay.EmbarkAvoidanceComponent.Initialize // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dba080
	struct FVector CalculateAvoidanceVelocity(struct FVector& InDesiredVelocity); // Function EmbarkGameplay.EmbarkAvoidanceComponent.CalculateAvoidanceVelocity // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5db4e30
};

// Class EmbarkGameplay.EmbarkCheatManager
// Size: 0x180 (Inherited: 0x100)
struct UEmbarkCheatManager : UCheatManager {
	struct FMulticastInlineDelegate OnServerHardwareBreakpointChanged; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnReceivedAngelscriptServerCodeExecutionResult; // 0x108(0x10)
	struct FTransform CachedDebugCameraTransform; // 0x120(0x60)

	void StopRepeatConsoleCommand(struct FString ConsoleCommand); // Function EmbarkGameplay.EmbarkCheatManager.StopRepeatConsoleCommand // (Final|Exec|Native|Public) // @ game+0x51aacd0
	void StopAllRepeatingConsoleCommands(); // Function EmbarkGameplay.EmbarkCheatManager.StopAllRepeatingConsoleCommands // (Final|Exec|Native|Public) // @ game+0x33aadf0
	void ServerSetTriggerVSBreakpoint(bool bEnable); // Function EmbarkGameplay.EmbarkCheatManager.ServerSetTriggerVSBreakpoint // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x5db7e40
	void ServerRunAngelscriptCodeString(struct FString CodeString, struct UObject* OptionalObject); // Function EmbarkGameplay.EmbarkCheatManager.ServerRunAngelscriptCodeString // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x5db8d10
	void ServerClearHardwareBreakpoint(int32_t DebugRegisterToClear); // Function EmbarkGameplay.EmbarkCheatManager.ServerClearHardwareBreakpoint // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x5db6770
	void ServerAddHardwareBreakpoint(struct UObject* Obj, struct FString PropertyName, int32_t TriggersUntilDisable, enum class EEmbarkHardwareBreakpointTypes BreakpointType, enum class EEmbarkHardwareBreakpointConditions TriggerCondition, int64_t TriggerConditionValue); // Function EmbarkGameplay.EmbarkCheatManager.ServerAddHardwareBreakpoint // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x5dba6c0
	void ResetTweakableToDefault(struct FString ObjectPath, struct FString PropertyPath); // Function EmbarkGameplay.EmbarkCheatManager.ResetTweakableToDefault // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x5db8ab0
	void RepeatConsoleCommand(struct FString InConsoleCommand, float InInterval); // Function EmbarkGameplay.EmbarkCheatManager.RepeatConsoleCommand // (Final|Exec|Native|Public) // @ game+0x5db7880
	void PrintDebug_AbilitySystem(); // Function EmbarkGameplay.EmbarkCheatManager.PrintDebug_AbilitySystem // (Final|Exec|Native|Public|BlueprintCallable) // @ game+0x33aadf0
	void OnHardwareBreakpointChanged(struct FEmbarkHardwareBreakpointInfo& BreakpointInfo); // Function EmbarkGameplay.EmbarkCheatManager.OnHardwareBreakpointChanged // (Final|Native|Private|HasOutParms) // @ game+0x5db95f0
	void ForceCrash(struct TArray<struct FString>& Args); // Function EmbarkGameplay.EmbarkCheatManager.ForceCrash // (Final|Exec|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5db5b40
	void ExecuteCheat_Server(struct TArray<struct FString>& Args); // Function EmbarkGameplay.EmbarkCheatManager.ExecuteCheat_Server // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x4abfe0
	void DeleteLocalSaveGames(); // Function EmbarkGameplay.EmbarkCheatManager.DeleteLocalSaveGames // (Final|Exec|Native|Public) // @ game+0x33aadf0
	void DebugCameraEnded(); // Function EmbarkGameplay.EmbarkCheatManager.DebugCameraEnded // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ClientSendCodeExecutionResult(struct FString Result); // Function EmbarkGameplay.EmbarkCheatManager.ClientSendCodeExecutionResult // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x53bbf00
	void ClientNotifyOfServerHardwareBreakpoint(struct FEmbarkHardwareBreakpointInfo BreakpointInfo); // Function EmbarkGameplay.EmbarkCheatManager.ClientNotifyOfServerHardwareBreakpoint // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5db4970
	void BP_FeatureFlagsChanged(); // Function EmbarkGameplay.EmbarkCheatManager.BP_FeatureFlagsChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ApplyRuntimeTweakable(struct FString ObjectPath, struct FString PropertyPath, struct FString PropertyValue, bool bApplyToInstances); // Function EmbarkGameplay.EmbarkCheatManager.ApplyRuntimeTweakable // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x5db79e0
	void AddInfImpulse(); // Function EmbarkGameplay.EmbarkCheatManager.AddInfImpulse // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x33aadf0
};

// Class EmbarkGameplay.EmbarkComponentSelectionMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkComponentSelectionMixinLibrary : UObject {

	void SetComponent(struct FEmbarkComponentSelection& ComponentSelection, struct UActorComponent* Component); // Function EmbarkGameplay.EmbarkComponentSelectionMixinLibrary.SetComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5db4680
	struct UActorComponent* GetComponent(struct FEmbarkComponentSelection& ComponentSelection, struct UObject* WorldContextObject, struct AActor* Owner); // Function EmbarkGameplay.EmbarkComponentSelectionMixinLibrary.GetComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5db6860
};

// Class EmbarkGameplay.EmbarkConvexVolumeMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConvexVolumeMixinLibrary : UObject {

	void UpdateConvexVolume(struct FEmbarkConvexVolume& ConvexVolume, struct FTransform& NewTransform); // Function EmbarkGameplay.EmbarkConvexVolumeMixinLibrary.UpdateConvexVolume // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5db5cf0
	bool IntersectSphere(struct FEmbarkConvexVolume& ConvexVolume, struct FVector& Origin, float& Radius); // Function EmbarkGameplay.EmbarkConvexVolumeMixinLibrary.IntersectSphere // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5db5310
	bool IntersectLineSegment(struct FEmbarkConvexVolume& ConvexVolume, struct FVector& Start, struct FVector& End); // Function EmbarkGameplay.EmbarkConvexVolumeMixinLibrary.IntersectLineSegment // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5db57a0
	bool IntersectBox(struct FEmbarkConvexVolume& ConvexVolume, struct FVector& Origin, struct FVector& Translation, struct FVector& Extent); // Function EmbarkGameplay.EmbarkConvexVolumeMixinLibrary.IntersectBox // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5db4b90
	struct TArray<struct FPlane> GetConvexVolumePlanes(struct FEmbarkConvexVolume& ConvexVolume); // Function EmbarkGameplay.EmbarkConvexVolumeMixinLibrary.GetConvexVolumePlanes // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5dba530
	struct FEmbarkConvexVolume CreateConvexVolume(struct FTransform& Transform, float HalfFOVX, float HalfFOVY, float MinZ, float MaxZ); // Function EmbarkGameplay.EmbarkConvexVolumeMixinLibrary.CreateConvexVolume // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5db4f10
};

// Class EmbarkGameplay.EmbarkEngineSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkEngineSubsystem : UEngineSubsystem {

	void OnInitialized(); // Function EmbarkGameplay.EmbarkEngineSubsystem.OnInitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitialized(); // Function EmbarkGameplay.EmbarkEngineSubsystem.OnDeinitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.EmbarkWorldSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWorldSubsystem : UWorldSubsystem {

	void OnInitialized(); // Function EmbarkGameplay.EmbarkWorldSubsystem.OnInitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitialized(); // Function EmbarkGameplay.EmbarkWorldSubsystem.OnDeinitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem
// Size: 0x1e0 (Inherited: 0xa0)
struct UEmbarkEnvironmentInstigatorSubsystem : UEmbarkWorldSubsystem {
	char pad_a0[0x140]; // 0xa0(0x140)

	void SetObjectRelevancyTimeout(float Timeout); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.SetObjectRelevancyTimeout // (Final|Native|Public|BlueprintCallable) // @ game+0x5db8170
	void SetDestructibleRelevancyTimeoutModifier(float Modifier); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.SetDestructibleRelevancyTimeoutModifier // (Final|Native|Public|BlueprintCallable) // @ game+0x5db7da0
	void SetDestructibleRelevancyTimeout(float Timeout); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.SetDestructibleRelevancyTimeout // (Final|Native|Public|BlueprintCallable) // @ game+0x5db5960
	void SetDestructibleBoneSearchDepth(int32_t Depth); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.SetDestructibleBoneSearchDepth // (Final|Native|Public|BlueprintCallable) // @ game+0x5db34e0
	bool ResetComponentEvent(struct USceneComponent* Component, float GracePeriod); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.ResetComponentEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5db7020
	bool ResetAlwaysReleantSingularBoneEvent(struct UEmbarkFracturedDestructibleMeshComponent* MeshComponent, int32_t BoneIndex); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.ResetAlwaysReleantSingularBoneEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5db6f10
	bool ResetActorEvent(struct AActor* Actor, float GracePeriod); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.ResetActorEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5db5ef0
	void OnTick(float DeltaTime); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.OnTick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnComponentDestroyed(struct UActorComponent* DestroyedComponent); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.OnComponentDestroyed // (Final|Native|Private) // @ game+0x5db7130
	void OnActorDestroyed(struct AActor* DestroyedActor); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.OnActorDestroyed // (Final|Native|Private) // @ game+0x5db7130
	bool GetMostRelevantObjectInstigatorData(struct UObject* Object, struct FInstigator& OutInstigatorData, bool bMustPassCriteriaCheck); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.GetMostRelevantObjectInstigatorData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dbaae0
	struct APlayerState* GetMostRelevantObjectInstigator(struct UObject* Object, bool bMustPassCriteriaCheck); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.GetMostRelevantObjectInstigator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5db8920
	struct APlayerState* GetMostRelevantBoneInstigator(struct UEmbarkFracturedDestructibleMeshComponent* MeshComponent, int32_t BoneIndex, bool bMustPassCriteriaCheck); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.GetMostRelevantBoneInstigator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5db3600
	void AddPropagatingBoneEvent(struct APlayerState* InstigatingPlayer, struct UEmbarkFracturedDestructibleMeshComponent* MeshComponent, int32_t BoneIndex); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.AddPropagatingBoneEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5db3340
	void AddComponentEvent(struct FInstigator& InstigatorData, struct USceneComponent* Component, char Relevancy); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.AddComponentEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5db4450
	void AddAlwaysReleantSingularBoneEvent(struct APlayerState* InstigatingPlayer, struct UEmbarkFracturedDestructibleMeshComponent* MeshComponent, int32_t BoneIndex); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.AddAlwaysReleantSingularBoneEvent // (Final|Native|Public|BlueprintCallable) // @ game+0x5db9830
	void AddActorEvent(struct FInstigator& InstigatorData, struct AActor* Actor, char Relevancy); // Function EmbarkGameplay.EmbarkEnvironmentInstigatorSubsystem.AddActorEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dbacd0
};

// Class EmbarkGameplay.EmbarkEnvironmentInsigatorSubsystemFake
// Size: 0x1e0 (Inherited: 0x1e0)
struct UEmbarkEnvironmentInsigatorSubsystemFake : UEmbarkEnvironmentInstigatorSubsystem {
};

// Class EmbarkGameplay.EmbarkFastReplicatorBucketTransformInterpolator
// Size: 0x540 (Inherited: 0x410)
struct AEmbarkFastReplicatorBucketTransformInterpolator : AEmbarkFastReplicatorBucketFastArray {
	struct FEmbarkFastArrayTransform Transforms; // 0x408(0x130)
};

// Class EmbarkGameplay.EmbarkFastReplicatorTransformInterpolator
// Size: 0x550 (Inherited: 0x550)
struct AEmbarkFastReplicatorTransformInterpolator : AEmbarkFastReplicator {
};

// Class EmbarkGameplay.EmbarkBlackBoardFastReplicatorBucketTransformInterpolator
// Size: 0x430 (Inherited: 0x3b0)
struct AEmbarkBlackBoardFastReplicatorBucketTransformInterpolator : AEmbarkFastReplicatorBucket {
	struct FBlackBoardDeltaCompressionPtr ActorTransformCollectionPtr; // 0x3a8(0x78)
	char pad_428[0x8]; // 0x428(0x08)

	void OnRep_ActorTransformCollection(); // Function EmbarkGameplay.EmbarkBlackBoardFastReplicatorBucketTransformInterpolator.OnRep_ActorTransformCollection // (Final|Native|Public) // @ game+0x5db3020
};

// Class EmbarkGameplay.EmbarkActorBlackBoardFastReplicatorTransformInterpolator
// Size: 0x550 (Inherited: 0x550)
struct AEmbarkActorBlackBoardFastReplicatorTransformInterpolator : AEmbarkFastReplicator {
};

// Class EmbarkGameplay.EmbarkGameInstance
// Size: 0x360 (Inherited: 0x2b0)
struct UEmbarkGameInstance : UGameInstance {
	char pad_2b0[0x8]; // 0x2b0(0x08)
	struct FMulticastInlineDelegate OnActiveGameplayChanged; // 0x2b8(0x10)
	struct TMap<struct FUniqueNetIdRepl, struct UNetConnection*> PlayerConnections; // 0x2c8(0x50)
	char pad_318[0x48]; // 0x318(0x48)

	void SetQuilkinRoutingToken(struct FString Base64Bytes); // Function EmbarkGameplay.EmbarkGameInstance.SetQuilkinRoutingToken // (Final|Native|Public) // @ game+0x5dbce60
	void SetActiveGameplay(bool bActiveGameplay); // Function EmbarkGameplay.EmbarkGameInstance.SetActiveGameplay // (Final|Native|Public) // @ game+0x5dc0480
	struct AGameModeBase* ReceiveOverrideGameModeClass(struct AGameModeBase* GameModeClass, struct FString MapName, struct FString Options, struct FString Portal); // Function EmbarkGameplay.EmbarkGameInstance.ReceiveOverrideGameModeClass // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveOnLoginFailure(struct FUniqueNetIdRepl& NetId); // Function EmbarkGameplay.EmbarkGameInstance.ReceiveOnLoginFailure // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveOnInitialLogin(struct FUniqueNetIdRepl& NetId); // Function EmbarkGameplay.EmbarkGameInstance.ReceiveOnInitialLogin // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	bool IsMainMenu(); // Function EmbarkGameplay.EmbarkGameInstance.IsMainMenu // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	bool IsInActiveGameplay(); // Function EmbarkGameplay.EmbarkGameInstance.IsInActiveGameplay // (Final|Native|Public|Const) // @ game+0x5dc0f80
	bool IsGameplayMap(); // Function EmbarkGameplay.EmbarkGameInstance.IsGameplayMap // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	bool BP_WorldSupportsInstantReplays(); // Function EmbarkGameplay.EmbarkGameInstance.BP_WorldSupportsInstantReplays // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void BP_ReturnToMainMenu(); // Function EmbarkGameplay.EmbarkGameInstance.BP_ReturnToMainMenu // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc1a70
	void BP_HandleGameSpecificControlMessage(struct FEmbarkGameControlMessage& ControlMessage); // Function EmbarkGameplay.EmbarkGameInstance.BP_HandleGameSpecificControlMessage // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void BP_HandleAntiCheatNotification(struct FString Message); // Function EmbarkGameplay.EmbarkGameInstance.BP_HandleAntiCheatNotification // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.EmbarkGameMode
// Size: 0x490 (Inherited: 0x480)
struct AEmbarkGameMode : AGameMode {
	char bKeepOriginalPlayerStateOnReconnect : 1; // 0x480(0x01)
	char pad_480_1 : 7; // 0x480(0x01)
	char pad_481[0xf]; // 0x481(0x0f)

	void ReceiveStartPlay(); // Function EmbarkGameplay.EmbarkGameMode.ReceiveStartPlay // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePreRestartPlayer(struct AController* NewController); // Function EmbarkGameplay.EmbarkGameMode.ReceivePreRestartPlayer // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePreLogin(struct FString Options, struct FString Address, struct FUniqueNetIdRepl& UniqueID, struct FString& ErrorMessage); // Function EmbarkGameplay.EmbarkGameMode.ReceivePreLogin // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostInitializeComponents(); // Function EmbarkGameplay.EmbarkGameMode.ReceivePostInitializeComponents // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveNotifyPendingConnectionLost(struct FUniqueNetIdRepl& ConnectionUniqueId, bool bIsReplayConnectionLost); // Function EmbarkGameplay.EmbarkGameMode.ReceiveNotifyPendingConnectionLost // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveInitSeamlessTravelPlayer(struct AController* NewController); // Function EmbarkGameplay.EmbarkGameMode.ReceiveInitSeamlessTravelPlayer // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveInitPlayer(struct AController* NewController); // Function EmbarkGameplay.EmbarkGameMode.ReceiveInitPlayer // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveHandleMatchIsWaitingToStart(); // Function EmbarkGameplay.EmbarkGameMode.ReceiveHandleMatchIsWaitingToStart // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveHandleMatchHasStarted(); // Function EmbarkGameplay.EmbarkGameMode.ReceiveHandleMatchHasStarted // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveHandleMatchHasEnded(); // Function EmbarkGameplay.EmbarkGameMode.ReceiveHandleMatchHasEnded // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveHandleMatchAborted(); // Function EmbarkGameplay.EmbarkGameMode.ReceiveHandleMatchAborted // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveHandleLeavingMap(); // Function EmbarkGameplay.EmbarkGameMode.ReceiveHandleLeavingMap // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveGetSeamlessTravelActorList(bool bToTransition, struct TArray<struct AActor*>& ActorList); // Function EmbarkGameplay.EmbarkGameMode.ReceiveGetSeamlessTravelActorList // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveDDOSEscalation(struct FString InSeverityCategory); // Function EmbarkGameplay.EmbarkGameMode.ReceiveDDOSEscalation // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveConstructGameSpecificControlMessage(struct FString& OutGameSpecificMessage); // Function EmbarkGameplay.EmbarkGameMode.ReceiveConstructGameSpecificControlMessage // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void PreLogout(struct AController* Exiting); // Function EmbarkGameplay.EmbarkGameMode.PreLogout // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnNetworkDDOSEscalation(struct UWorld* InWorld, struct UNetDriver* InNetDriver, struct FString SeverityCategory); // Function EmbarkGameplay.EmbarkGameMode.OnNetworkDDOSEscalation // (Final|Native|Protected) // @ game+0x5dbc8c0
	bool KickPlayer(struct APlayerController* KickedPlayer, char KickType, struct FText& KickReason); // Function EmbarkGameplay.EmbarkGameMode.KickPlayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dbe2e0
	void GetInactivePlayers(struct TArray<struct APlayerState*>& OutPlayerStates); // Function EmbarkGameplay.EmbarkGameMode.GetInactivePlayers // (Final|Native|Protected|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc02a0
	struct AActor* FindPlayerStart_NativeVersion(struct AController* Player, struct FString IncomingName); // Function EmbarkGameplay.EmbarkGameMode.FindPlayerStart_NativeVersion // (Final|Native|Protected) // @ game+0x5dbb920
};

// Class EmbarkGameplay.EmbarkGameSession
// Size: 0x3c0 (Inherited: 0x3b0)
struct AEmbarkGameSession : AGameSession {
	char bDestroyPawnOnKick : 1; // 0x3b0(0x01)
	char pad_3b0_1 : 7; // 0x3b0(0x01)
	char pad_3b1[0xf]; // 0x3b1(0x0f)
};

// Class EmbarkGameplay.EmbarkGameStateBase
// Size: 0x760 (Inherited: 0x4e0)
struct AEmbarkGameStateBase : AGameState {
	char pad_4e0[0x8]; // 0x4e0(0x08)
	struct TArray<struct AEmbarkSquad*> Squads; // 0x4e8(0x10)
	struct FMulticastInlineDelegate OnSquadsChanged; // 0x4f8(0x10)
	struct FOnlineTweakablesContainer OnlineTweakablesContainer; // 0x508(0x10)
	struct FBlackBoardVariableDeltaCompressionPtr BlackBoardReplicationPtr; // 0x518(0x78)
	float ReplicatedRealtimeWorldTimeSeconds; // 0x590(0x04)
	float ServerRealtimeWorldTimeSecondsDelta; // 0x594(0x04)
	char pad_598[0x10]; // 0x598(0x10)
	struct FMulticastInlineDelegate OnMatchIdChanged; // 0x5a8(0x10)
	char pad_5b8[0x30]; // 0x5b8(0x30)
	struct TArray<struct FMatchIdDesc> MatchesId; // 0x5e8(0x10)
	char pad_5f8[0x48]; // 0x5f8(0x48)
	struct TArray<struct AEmbarkSquad*> AllSquads; // 0x640(0x10)
	char pad_650[0x78]; // 0x650(0x78)
	struct TArray<struct UObject*> LoadedAssetsKeepAlive; // 0x6c8(0x10)
	char pad_6d8[0x30]; // 0x6d8(0x30)
	struct TArray<struct TSoftClassPtr<UObject>> QueuedObjectsToKeepAlive; // 0x708(0x10)
	char pad_718[0x48]; // 0x718(0x48)

	void SortAssetsByName(struct TArray<struct UObject*>& Classes); // Function EmbarkGameplay.EmbarkGameStateBase.SortAssetsByName // (Final|Native|Protected|HasOutParms) // @ game+0x5dbba90
	void OnSquadsChanged__DelegateSignature(); // DelegateFunction EmbarkGameplay.EmbarkGameStateBase.OnSquadsChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnRep_ReplicatedRealtimeWorldTimeSeconds(); // Function EmbarkGameplay.EmbarkGameStateBase.OnRep_ReplicatedRealtimeWorldTimeSeconds // (Final|Native|Private) // @ game+0x5dbbc40
	void OnRep_OnlineTweakablesContainer(); // Function EmbarkGameplay.EmbarkGameStateBase.OnRep_OnlineTweakablesContainer // (Final|Native|Private) // @ game+0x5dbbd90
	void OnRep_MatchesId(); // Function EmbarkGameplay.EmbarkGameStateBase.OnRep_MatchesId // (Final|Native|Private|Const) // @ game+0x5dbf620
	void OnRep_AllSquads(); // Function EmbarkGameplay.EmbarkGameStateBase.OnRep_AllSquads // (Final|Native|Private) // @ game+0x5dbb0b0
	void OnOnlineTweakablesRegistered(struct FOnlineTweakablesContainer& InOnlineTweakablesContainer); // Function EmbarkGameplay.EmbarkGameStateBase.OnOnlineTweakablesRegistered // (Final|Native|Private|HasOutParms) // @ game+0x5dc17a0
	void OnMod_Squads(); // Function EmbarkGameplay.EmbarkGameStateBase.OnMod_Squads // (Final|Native|Private) // @ game+0x5dc2d50
	void OnMatchIdChanged__DelegateSignature(); // DelegateFunction EmbarkGameplay.EmbarkGameStateBase.OnMatchIdChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void LoadAssetsFromObjects(struct TArray<struct TSoftClassPtr<UObject>>& Objects); // Function EmbarkGameplay.EmbarkGameStateBase.LoadAssetsFromObjects // (Final|Native|Protected|HasOutParms) // @ game+0x5dbeed0
	struct TArray<struct AEmbarkSquad*> GetSpectatingSquads(); // Function EmbarkGameplay.EmbarkGameStateBase.GetSpectatingSquads // (Final|Native|Public|Const) // @ game+0x5dbe9e0
	float GetRealtimeServerWorldTimeSeconds(); // Function EmbarkGameplay.EmbarkGameStateBase.GetRealtimeServerWorldTimeSeconds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dbba20
	struct TArray<struct AEmbarkSquad*> GetPlayingSquads(); // Function EmbarkGameplay.EmbarkGameStateBase.GetPlayingSquads // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc19f0
	struct TArray<struct AEmbarkSquad*> GetAllSquads(); // Function EmbarkGameplay.EmbarkGameStateBase.GetAllSquads // (Final|Native|Public|Const) // @ game+0x5dbee50
	void EmptySquads(); // Function EmbarkGameplay.EmbarkGameStateBase.EmptySquads // (Final|Native|Public) // @ game+0x5dbb260
	void AddSquads(struct TArray<struct AEmbarkSquad*> NewSquads); // Function EmbarkGameplay.EmbarkGameStateBase.AddSquads // (Final|Native|Public) // @ game+0x5dbc110
	void AddSquad(struct AEmbarkSquad* NewSquad); // Function EmbarkGameplay.EmbarkGameStateBase.AddSquad // (Final|Native|Public) // @ game+0x5dbfe60
};

// Class EmbarkGameplay.EmbarkGameViewportClient
// Size: 0x750 (Inherited: 0x700)
struct UEmbarkGameViewportClient : UGameViewportClient {
	char pad_700[0x50]; // 0x700(0x50)
};

// Class EmbarkGameplay.EmbarkItemSubsystem
// Size: 0xd0 (Inherited: 0xa0)
struct UEmbarkItemSubsystem : UEmbarkGlobalSubsystem {
	bool bUpdateAssetOnChangedBulk; // 0xa0(0x01)
	char pad_a1[0x2f]; // 0xa1(0x2f)

	void ReceiveFeatureFlagChanged(); // Function EmbarkGameplay.EmbarkItemSubsystem.ReceiveFeatureFlagChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnAssetsReady(); // Function EmbarkGameplay.EmbarkItemSubsystem.OnAssetsReady // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnAssetsChangedBulk(struct TArray<struct FAssetData>& AssetData); // Function EmbarkGameplay.EmbarkItemSubsystem.OnAssetsChangedBulk // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnAssetsChanged(struct FAssetData& AssetData); // Function EmbarkGameplay.EmbarkItemSubsystem.OnAssetsChanged // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.EmbarkLocalPlayer
// Size: 0x450 (Inherited: 0x440)
struct UEmbarkLocalPlayer : ULocalPlayer {
	char pad_440[0x10]; // 0x440(0x10)
};

// Class EmbarkGameplay.EmbarkLocalPlayerSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkLocalPlayerSubsystem : ULocalPlayerSubsystem {

	void ReceivePlayerControllerChanged(struct APlayerController* NewPlayerController); // Function EmbarkGameplay.EmbarkLocalPlayerSubsystem.ReceivePlayerControllerChanged // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool OnShouldCreateSubsystem(struct UObject* Outer); // Function EmbarkGameplay.EmbarkLocalPlayerSubsystem.OnShouldCreateSubsystem // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5dc0da0
	void OnInitialized(); // Function EmbarkGameplay.EmbarkLocalPlayerSubsystem.OnInitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitialized(); // Function EmbarkGameplay.EmbarkLocalPlayerSubsystem.OnDeinitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void GetDependencies(struct TArray<struct USubsystem*>& Dependencies); // Function EmbarkGameplay.EmbarkLocalPlayerSubsystem.GetDependencies // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5dbd400
};

// Class EmbarkGameplay.EmbarkNiagaraComponent
// Size: 0x960 (Inherited: 0x960)
struct UEmbarkNiagaraComponent : UNiagaraComponent {
};

// Class EmbarkGameplay.EmbarkNiagaraDebugComponent
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkNiagaraDebugComponent : UActorComponent {

	void DisplayDebugDataFor(struct UNiagaraComponent* Comp); // Function EmbarkGameplay.EmbarkNiagaraDebugComponent.DisplayDebugDataFor // (Native|Event|Public|BlueprintEvent) // @ game+0x3633ca0
};

// Class EmbarkGameplay.EmbarkOptimizedTickMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkOptimizedTickMixinLibrary : UObject {

	void UpdateTickIntervalAndCooldown(struct FEmbarkOptimizedTick& OptimizedTick, float Interval); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.UpdateTickIntervalAndCooldown // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dc0360
	void TeardownOptimizedTick(struct FEmbarkOptimizedTick& OptimizedTick); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.TeardownOptimizedTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbbe90
	void SetupOptimizedTickBySignature(struct FEmbarkOptimizedTick& OptimizedTick, struct FDelegate TickFunction); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.SetupOptimizedTickBySignature // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dc3250
	void SetupOptimizedTick(struct FEmbarkOptimizedTick& OptimizedTick, struct UObject* TickObject, struct FName FunctionName); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.SetupOptimizedTick // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbcbe0
	void SetTickEnabled(struct FEmbarkOptimizedTick& OptimizedTick, bool bValue); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.SetTickEnabled // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbb100
	bool HasTickOptimizedObject(struct FEmbarkOptimizedTick& OptimizedTick); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.HasTickOptimizedObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbfc50
	void AddTickPrerequisiteComponent(struct FEmbarkOptimizedTick& OptimizedTick, struct UActorComponent* PrerequisiteComponent); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.AddTickPrerequisiteComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dc3720
	void AddTickPrerequisiteActor(struct FEmbarkOptimizedTick& OptimizedTick, struct AActor* PrerequisiteActor); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.AddTickPrerequisiteActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbd2e0
	void AddAsTickPrerequisiteForComponent(struct FEmbarkOptimizedTick& OptimizedTick, struct UActorComponent* Component); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.AddAsTickPrerequisiteForComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbb6f0
	void AddAsTickPrerequisiteForActor(struct FEmbarkOptimizedTick& OptimizedTick, struct AActor* Actor); // Function EmbarkGameplay.EmbarkOptimizedTickMixinLibrary.AddAsTickPrerequisiteForActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dbcfc0
};

// Class EmbarkGameplay.EmbarkOptimizedTickObject
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkOptimizedTickObject : UObject {
	char pad_a0[0x48]; // 0xa0(0x48)
	struct UObject* TickObject; // 0xe8(0x08)
	struct UASFunction* TickFunction; // 0xf0(0x08)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class EmbarkGameplay.EmbarkOptimizedTickObjectPoolSubSystem
// Size: 0x140 (Inherited: 0x140)
struct UEmbarkOptimizedTickObjectPoolSubSystem : UEmbarkObjectPoolSubsystem {
};

// Class EmbarkGameplay.EmbarkOptimizedTickObjectSubsystem
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkOptimizedTickObjectSubsystem : UWorldSubsystem {
	struct TArray<struct UEmbarkOptimizedTickObject*> OptimizedTickLifetime; // 0xa0(0x10)
	struct UEmbarkOptimizedTickObjectPoolSubSystem* Pool; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class EmbarkGameplay.ParallelUpdateBaseClass
// Size: 0xd0 (Inherited: 0xa0)
struct UParallelUpdateBaseClass : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)

	void InitComponent(struct UActorComponent* ActorComp, enum class ETickingGroup TickGroup, bool InNeedsSyncPre, bool InNeedsPreTickGameThread, bool InNeedsTickAnyThread, bool InNeedsPostTickGameThread, bool InNeedsSyncPost); // Function EmbarkGameplay.ParallelUpdateBaseClass.InitComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5dccbf0
	void InitActor(struct AActor* Actor, enum class ETickingGroup TickGroup, bool InNeedsSyncPre, bool InNeedsPreTickGameThread, bool InNeedsTickAnyThread, bool InNeedsPostTickGameThread, bool InNeedsSyncPost); // Function EmbarkGameplay.ParallelUpdateBaseClass.InitActor // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcb940
	void Deinit(); // Function EmbarkGameplay.ParallelUpdateBaseClass.Deinit // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc4650
};

// Class EmbarkGameplay.EmbarkParallelActorUpdaterSubsystemActor
// Size: 0x3c0 (Inherited: 0x3a0)
struct AEmbarkParallelActorUpdaterSubsystemActor : AActor {
	char pad_3a0[0x20]; // 0x3a0(0x20)
};

// Class EmbarkGameplay.EmbarkParallelActorUpdaterSubsystem
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkParallelActorUpdaterSubsystem : UWorldSubsystem {
	char pad_a0[0x50]; // 0xa0(0x50)
};

// Class EmbarkGameplay.EmbarkPawn
// Size: 0x4d0 (Inherited: 0x420)
struct AEmbarkPawn : APawn {
	char pad_420[0x20]; // 0x420(0x20)
	struct UEmbarkAbilitySystemComponent* AbilitySystem; // 0x440(0x08)
	struct FBlackBoardDeltaCompressionPtr BlackBoardReplicationPtr; // 0x448(0x78)
	char pad_4c0[0x8]; // 0x4c0(0x08)
	bool bReplicateTeamId; // 0x4c8(0x01)
	enum class EEmbarkTeamId TeamId; // 0x4c9(0x01)
	char pad_4ca[0x6]; // 0x4ca(0x06)

	void TriggerInputAction(struct FName InputAction, enum class EInputEvent InputEvent); // Function EmbarkGameplay.EmbarkPawn.TriggerInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcc8f0
	struct UObject* RegisterClassToBlackBoard(struct UObject* Clazz); // Function EmbarkGameplay.EmbarkPawn.RegisterClassToBlackBoard // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcd7a0
	void ReceiveSetupPlayerInputComponent(struct UInputComponent* PlayerInputComponent); // Function EmbarkGameplay.EmbarkPawn.ReceiveSetupPlayerInputComponent // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveRestart(); // Function EmbarkGameplay.EmbarkPawn.ReceiveRestart // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostInitializeComponents(); // Function EmbarkGameplay.EmbarkPawn.ReceivePostInitializeComponents // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	struct UObject* GetFirstStateOfTypeFromBlackBoard(struct UObject* Clazz); // Function EmbarkGameplay.EmbarkPawn.GetFirstStateOfTypeFromBlackBoard // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dcc1c0
	struct UObject* EditFirstStateOfTypeFromBlackBoard(struct UObject* Clazz, bool bSetDirty); // Function EmbarkGameplay.EmbarkPawn.EditFirstStateOfTypeFromBlackBoard // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc5680
	void BP_SetTeam(enum class EEmbarkTeamId NewTeam); // Function EmbarkGameplay.EmbarkPawn.BP_SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcb0b0
	enum class EEmbarkTeamId BP_GetTeam(); // Function EmbarkGameplay.EmbarkPawn.BP_GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc4670
};

// Class EmbarkGameplay.EmbarkPerformanceCheatManagerExtension
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkPerformanceCheatManagerExtension : UCheatManagerExtension {
	char pad_a0[0x10]; // 0xa0(0x10)

	void ForceConsecutiveBadFramesOnServer(int32_t TargetFrameTimeMilliseconds, int32_t NumFrames); // Function EmbarkGameplay.EmbarkPerformanceCheatManagerExtension.ForceConsecutiveBadFramesOnServer // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x5dc82d0
	void ForceBadFrameOnServerToTarget(int32_t TargetFrameTimeMilliseconds); // Function EmbarkGameplay.EmbarkPerformanceCheatManagerExtension.ForceBadFrameOnServerToTarget // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x5dc77c0
	void CancelForcedBadFrames(); // Function EmbarkGameplay.EmbarkPerformanceCheatManagerExtension.CancelForcedBadFrames // (Final|BlueprintAuthorityOnly|Exec|Native|Public) // @ game+0x5dcc820
};

// Class EmbarkGameplay.EmbarkPlatformIdComponent
// Size: 0x190 (Inherited: 0x160)
struct UEmbarkPlatformIdComponent : UActorComponent {
	struct FUniqueNetIdRepl PlatformId; // 0x158(0x30)

	bool TryGetPlatformId(struct FUniqueNetIdRepl& OutPlatformId); // Function EmbarkGameplay.EmbarkPlatformIdComponent.TryGetPlatformId // (Final|Native|Private|HasOutParms|Const) // @ game+0x5dc4b30
	void Server_SetPlatformId(struct FUniqueNetIdRepl InPlatformId); // Function EmbarkGameplay.EmbarkPlatformIdComponent.Server_SetPlatformId // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x5dc8a60
};

// Class EmbarkGameplay.EmbarkPlayerController
// Size: 0x1070 (Inherited: 0xf10)
struct AEmbarkPlayerController : APlayerController {
	char pad_f10[0x10]; // 0xf10(0x10)
	struct UEmbarkServersideInputReplicationComponent* ServersideInputReplicationComponent; // 0xf20(0x08)
	struct UDirectReplicationWrapperComponent* DirectReplicationWrapperComponent; // 0xf28(0x08)
	struct FMulticastInlineDelegate OnSquadPlayersProfilesReceived; // 0xf30(0x10)
	struct FMulticastInlineDelegate OnEmbarkInputDeviceChanged; // 0xf40(0x10)
	struct FMulticastInlineDelegate OnPostInputTick; // 0xf50(0x10)
	struct FMulticastInlineDelegate OnPreProcessInput; // 0xf60(0x10)
	struct FMulticastInlineDelegate OnPostProcessInput; // 0xf70(0x10)
	bool bDestroyPawnWhenLeavingGame; // 0xf80(0x01)
	bool bUseCustomShortConnectTimeout; // 0xf81(0x01)
	bool bCustomShortConnectTimeout; // 0xf82(0x01)
	char pad_f83[0x5]; // 0xf83(0x05)
	struct UUserWidget* WatermarkWidget; // 0xf88(0x08)
	struct FMulticastInlineDelegate OnApplicationActivationStateChangedEvent; // 0xf90(0x10)
	struct FMulticastInlineDelegate OnPlayerStateReplicated; // 0xfa0(0x10)
	bool bHasReplicatedPlayerState; // 0xfb0(0x01)
	bool bLogClientConsoleCommandsOnServer; // 0xfb1(0x01)
	char pad_fb2[0x6]; // 0xfb2(0x06)
	struct TArray<struct UCheatManagerExtension*> CheatManagerExtensions; // 0xfb8(0x10)
	char ReplicatedServerReceivingJitter; // 0xfc8(0x01)
	char pad_fc9[0x3f]; // 0xfc9(0x3f)
	struct APawn* LastPossessedPawn; // 0x1008(0x08)
	struct TArray<struct UEmbarkPawnComponent*> CachedPawnComponents; // 0x1010(0x10)
	struct TSet<struct FTenancyUserId> RequestingProfiles; // 0x1020(0x50)

	bool WasUsingMouse(); // Function EmbarkGameplay.EmbarkPlayerController.WasUsingMouse // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc3c40
	bool WasUsingKeyboard(); // Function EmbarkGameplay.EmbarkPlayerController.WasUsingKeyboard // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc3c40
	bool WasUsingGamepad(); // Function EmbarkGameplay.EmbarkPlayerController.WasUsingGamepad // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dcd8b0
	void SetUnresponsiveConnectionTelemetryEnabled(bool bEnabled); // Function EmbarkGameplay.EmbarkPlayerController.SetUnresponsiveConnectionTelemetryEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc6970
	void ServerSetMatchId(struct FName InPlatformKey, struct FString InMatchId); // Function EmbarkGameplay.EmbarkPlayerController.ServerSetMatchId // (Final|Net|NetReliableNative|Event|Private|NetServer|NetValidate) // @ game+0x5dc9520
	void ServerRequestSquadPlayersProfiles(struct TArray<struct FTenancyUserId> TenancyUserIds, struct FString AuthType); // Function EmbarkGameplay.EmbarkPlayerController.ServerRequestSquadPlayersProfiles // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x5dc8fe0
	void ServerNotifyHasReplicatedPlayerState(); // Function EmbarkGameplay.EmbarkPlayerController.ServerNotifyHasReplicatedPlayerState // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x5dc6f40
	void ServerLogConsoleCommandFromClient(struct FString Cmd); // Function EmbarkGameplay.EmbarkPlayerController.ServerLogConsoleCommandFromClient // (Final|Net|Native|Event|Private|NetServer|NetValidate) // @ game+0x5dc67e0
	void ServerForceClientRotation(struct FRotator Rot, bool bResetCam); // Function EmbarkGameplay.EmbarkPlayerController.ServerForceClientRotation // (Final|BlueprintAuthorityOnly|Native|Public|HasDefaults) // @ game+0x5dc40a0
	void SendTelemetryRoundIdToClient(); // Function EmbarkGameplay.EmbarkPlayerController.SendTelemetryRoundIdToClient // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc82b0
	void SendInputDeviceChanged(enum class EEmbarkInputDevice InputDevice); // Function EmbarkGameplay.EmbarkPlayerController.SendInputDeviceChanged // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x5dcd5e0
	void ReceiveSetupInputComponent(struct UInputComponent* PlayerInputComponent); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveSetupInputComponent // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveSeamlessTravelTo(struct APlayerController* NewPC); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveSeamlessTravelTo // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveSeamlessTravelFrom(struct APlayerController* OldPC); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveSeamlessTravelFrom // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePreClientTravel(struct FString PendingURL, enum class ETravelType TravelType, bool bIsSeamlessTravel); // Function EmbarkGameplay.EmbarkPlayerController.ReceivePreClientTravel // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostSeamlessTravel(); // Function EmbarkGameplay.EmbarkPlayerController.ReceivePostSeamlessTravel // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnVoiceChannelInfoReceived(enum class EVoiceChannel Channel, struct FVoiceChannelInfo& VoiceChannelInfo); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveOnVoiceChannelInfoReceived // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnRep_ControlledPawn(); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveOnRep_ControlledPawn // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnActiveGameplayChanged(bool bIsInActiveGameplay); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveOnActiveGameplayChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveNotifyLoadedWorld(struct FName WorldPackageName, bool bFinalDest); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveNotifyLoadedWorld // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveInitPlayerState(struct APlayerState* InPlayerState); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveInitPlayerState // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveGetSeamlessTravelActorList(bool bToEntry, struct TArray<struct AActor*>& ActorList); // Function EmbarkGameplay.EmbarkPlayerController.ReceiveGetSeamlessTravelActorList // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnServerKick(char Type, struct FText& Reason); // Function EmbarkGameplay.EmbarkPlayerController.OnServerKick // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnPostInputTick__DelegateSignature(float InDeltaTime); // DelegateFunction EmbarkGameplay.EmbarkPlayerController.OnPostInputTick__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnEmbarkInputDeviceChanged__DelegateSignature(enum class EEmbarkInputDevice NewInputDevice); // DelegateFunction EmbarkGameplay.EmbarkPlayerController.OnEmbarkInputDeviceChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void OnActiveGameplayChanged(bool bIsInActiveGameplay); // Function EmbarkGameplay.EmbarkPlayerController.OnActiveGameplayChanged // (Native|Protected) // @ game+0x5dc73c0
	void LocalPawnChanged(struct APawn* NewPawn); // Function EmbarkGameplay.EmbarkPlayerController.LocalPawnChanged // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool IsAnyForceFeedbackActive(); // Function EmbarkGameplay.EmbarkPlayerController.IsAnyForceFeedbackActive // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc8a30
	bool HasLocalPlayerSubsystem(struct ULocalPlayerSubsystem*& Subsystem); // Function EmbarkGameplay.EmbarkPlayerController.HasLocalPlayerSubsystem // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dcbf50
	struct FUniqueNetIdRepl GetUniqueNetId(); // Function EmbarkGameplay.EmbarkPlayerController.GetUniqueNetId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc3b20
	float GetTotalForceFeedbackValue(); // Function EmbarkGameplay.EmbarkPlayerController.GetTotalForceFeedbackValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc7690
	struct FRotator GetRotationInput(); // Function EmbarkGameplay.EmbarkPlayerController.GetRotationInput // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dcaf80
	float GetReplicatedServerReceivingJitterInMS_Client(); // Function EmbarkGameplay.EmbarkPlayerController.GetReplicatedServerReceivingJitterInMS_Client // (Native|Public|Const) // @ game+0x5dcb4c0
	struct TArray<struct FInputActionRecordedState> GetCurrentFrameInputActions(); // Function EmbarkGameplay.EmbarkPlayerController.GetCurrentFrameInputActions // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcac20
	void EnableTabNavigation(); // Function EmbarkGameplay.EmbarkPlayerController.EnableTabNavigation // (Final|Native|Public|BlueprintCallable) // @ game+0x5dc6bf0
	void DumpInputToGameplayDebuggerObject(struct UEmbarkGameplayDebuggerBaseObject* InDebuggerObject); // Function EmbarkGameplay.EmbarkPlayerController.DumpInputToGameplayDebuggerObject // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcc700
	void DumpInputStack(bool bIncludeKeybinds); // Function EmbarkGameplay.EmbarkPlayerController.DumpInputStack // (Final|Native|Public|BlueprintCallable) // @ game+0x5193460
	void DisableTabNavigation(); // Function EmbarkGameplay.EmbarkPlayerController.DisableTabNavigation // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcb150
	void ClientSetTelemetryRoundId(struct FString TelemetryRoundId); // Function EmbarkGameplay.EmbarkPlayerController.ClientSetTelemetryRoundId // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5dcd160
	void ClientReceiveVoiceChannelInfo(enum class EVoiceChannel Channel, struct FVoiceChannelInfo VoiceChannelInfo); // Function EmbarkGameplay.EmbarkPlayerController.ClientReceiveVoiceChannelInfo // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x5dcdaf0
	void ClientReceiveSquadPlayersProfiles(struct TArray<struct FCompactPlayerProfile> Profiles); // Function EmbarkGameplay.EmbarkPlayerController.ClientReceiveSquadPlayersProfiles // (Final|Net|NetReliableNative|Event|Private|NetClient) // @ game+0x5dc68c0
	void ClientNotifyNetworkUnresponsive(struct FGuid InUnresponsiveId); // Function EmbarkGameplay.EmbarkPlayerController.ClientNotifyNetworkUnresponsive // (Net|NetReliableNative|Event|Protected|HasDefaults|NetClient) // @ game+0x5dcc3a0
	void ClientEmbarkWasKicked(char KickType, struct FText KickReason); // Function EmbarkGameplay.EmbarkPlayerController.ClientEmbarkWasKicked // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0x5dc9290
	void BP_SetTeam(enum class EEmbarkTeamId NewTeam); // Function EmbarkGameplay.EmbarkPlayerController.BP_SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x5dca4c0
	enum class EEmbarkTeamId BP_GetTeam(); // Function EmbarkGameplay.EmbarkPlayerController.BP_GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dc6630
};

// Class EmbarkGameplay.EmbarkPlayerStateBase
// Size: 0x4c0 (Inherited: 0x450)
struct AEmbarkPlayerStateBase : APlayerState {
	char pad_450[0x10]; // 0x450(0x10)
	struct AEmbarkSquad* Squad; // 0x460(0x08)
	struct FPartyInfo PartyInfo; // 0x468(0x18)
	struct UEmbarkAbilitySystemComponent* AbilitySystem; // 0x480(0x08)
	struct UEmbarkPlatformIdComponent* PlatformIdComponent; // 0x488(0x08)
	char bDestroyOriginalOnDeactivate : 1; // 0x490(0x01)
	char pad_490_1 : 7; // 0x490(0x01)
	char pad_491[0x7]; // 0x491(0x07)
	struct FMulticastInlineDelegate OnSquadActorReplicated; // 0x498(0x10)
	char pad_4a8[0x10]; // 0x4a8(0x10)
	char bIsAReplayActor : 1; // 0x4b8(0x01)
	char pad_4b8_1 : 7; // 0x4b8(0x01)
	char pad_4b9[0x7]; // 0x4b9(0x07)

	void SetUniqueId(struct FUniqueNetIdRepl& NetId); // Function EmbarkGameplay.EmbarkPlayerStateBase.SetUniqueId // (Final|Native|Public|HasOutParms) // @ game+0x5dd36c0
	void OnRep_Squad(); // Function EmbarkGameplay.EmbarkPlayerStateBase.OnRep_Squad // (Final|Native|Private|Const) // @ game+0x5dd21b0
	void OnRep_PartyInfo(); // Function EmbarkGameplay.EmbarkPlayerStateBase.OnRep_PartyInfo // (Final|Native|Private|Const) // @ game+0x33aadf0
	bool IsReplayActor(); // Function EmbarkGameplay.EmbarkPlayerStateBase.IsReplayActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dce6c0
	void HandleOnSetUniqueId(); // Function EmbarkGameplay.EmbarkPlayerStateBase.HandleOnSetUniqueId // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void HandleOnReactivate(); // Function EmbarkGameplay.EmbarkPlayerStateBase.HandleOnReactivate // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void HandleOnDeactivate(); // Function EmbarkGameplay.EmbarkPlayerStateBase.HandleOnDeactivate // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	float GetReplicatedPing(); // Function EmbarkGameplay.EmbarkPlayerStateBase.GetReplicatedPing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dd2140
	float GetExactPing_Server(); // Function EmbarkGameplay.EmbarkPlayerStateBase.GetExactPing_Server // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dd21d0
	struct FString GetDebugPlayerName(); // Function EmbarkGameplay.EmbarkPlayerStateBase.GetDebugPlayerName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dcfee0
};

// Class EmbarkGameplay.EmbarkProjectileMovementComponent
// Size: 0x310 (Inherited: 0x310)
struct UEmbarkProjectileMovementComponent : UProjectileMovementComponent {
	float TickDeltaMultiplier; // 0x308(0x04)

	bool HasProjectileMovementStoppedSimulation(); // Function EmbarkGameplay.EmbarkProjectileMovementComponent.HasProjectileMovementStoppedSimulation // (Final|Native|Public) // @ game+0x5dd4680
	void AddForceToProjectileMovement(struct FVector InForce); // Function EmbarkGameplay.EmbarkProjectileMovementComponent.AddForceToProjectileMovement // (Final|Native|Public|HasDefaults) // @ game+0x5dd4210
};

// Class EmbarkGameplay.EmbarkProxyComponent
// Size: 0x3c0 (Inherited: 0x3c0)
struct UEmbarkProxyComponent : USceneComponent {
};

// Class EmbarkGameplay.EmbarkProxyTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkProxyTransformMixinLibrary : UObject {

	struct FTransform GetRelativeTransform(struct FEmbarkProxyTransform& ProxyTransform); // Function EmbarkGameplay.EmbarkProxyTransformMixinLibrary.GetRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5dce450
	struct FQuat GetRelativeRotationQuat(struct FEmbarkProxyTransform& ProxyTransform); // Function EmbarkGameplay.EmbarkProxyTransformMixinLibrary.GetRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5dd4ab0
	struct FRotator GetRelativeRotation(struct FEmbarkProxyTransform& ProxyTransform); // Function EmbarkGameplay.EmbarkProxyTransformMixinLibrary.GetRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5dd1130
	struct FVector GetRelativeLocation(struct FEmbarkProxyTransform& ProxyTransform); // Function EmbarkGameplay.EmbarkProxyTransformMixinLibrary.GetRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5dd32c0
	struct FName GetComponentName(struct FEmbarkProxyTransform& ProxyTransform); // Function EmbarkGameplay.EmbarkProxyTransformMixinLibrary.GetComponentName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dd47f0
	struct FName GetComponentDisplayName(struct FEmbarkProxyTransform& ProxyTransform); // Function EmbarkGameplay.EmbarkProxyTransformMixinLibrary.GetComponentDisplayName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dce880
};

// Class EmbarkGameplay.EmbarkReplayController
// Size: 0x1070 (Inherited: 0x1070)
struct AEmbarkReplayController : AEmbarkPlayerController {

	void ReceiveOnReplayPlaybackStopped(); // Function EmbarkGameplay.EmbarkReplayController.ReceiveOnReplayPlaybackStopped // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnReplayPlaybackStarted(struct FGameplayAbilityTargetDataHandle& InReplayPayload); // Function EmbarkGameplay.EmbarkReplayController.ReceiveOnReplayPlaybackStarted // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.EmbarkScreenFadeProxy
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkScreenFadeProxy : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnFinished; // 0xa0(0x10)
	char pad_b0[0x40]; // 0xb0(0x40)

	struct UEmbarkScreenFadeProxy* FadeScreenToColor(struct UObject* WorldContextObject, struct FLinearColor Color, float Duration); // Function EmbarkGameplay.EmbarkScreenFadeProxy.FadeScreenToColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5dd3410
	struct UEmbarkScreenFadeProxy* FadeScreenFromAndToColor(struct UObject* WorldContextObject, struct FLinearColor FromColor, struct FLinearColor ToColor, float Duration); // Function EmbarkGameplay.EmbarkScreenFadeProxy.FadeScreenFromAndToColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5dcfd10
	void ClearScreenFade(struct UObject* WorldContextObject); // Function EmbarkGameplay.EmbarkScreenFadeProxy.ClearScreenFade // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5dce6e0
};

// Class EmbarkGameplay.EmbarkNetScriptStruct_Test
// Size: 0x3f0 (Inherited: 0x3a0)
struct AEmbarkNetScriptStruct_Test : AActor {
	struct USceneComponent* RootComp; // 0x398(0x08)
	struct TMap<struct UScriptStruct*, struct UASFunction*> ScriptStructFunctions; // 0x3a0(0x50)

	void Multicast_TestRPCWithScriptStruct(struct FEmbarkScriptStruct ScriptStruct); // Function EmbarkGameplay.EmbarkNetScriptStruct_Test.Multicast_TestRPCWithScriptStruct // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x5dd0b50
	void Multicast_ScriptStruct(struct FEmbarkScriptStruct ScriptStruct); // Function EmbarkGameplay.EmbarkNetScriptStruct_Test.Multicast_ScriptStruct // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x5dce2c0
};

// Class EmbarkGameplay.EmbarkStructObject_Test
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkStructObject_Test : UObject {
	struct FEmbarkScriptStruct ThisStruct; // 0x98(0x18)
	char pad_b8[0x8]; // 0xb8(0x08)

	void StructOut(int32_t& __ANY_STRUCT_REF); // Function EmbarkGameplay.EmbarkStructObject_Test.StructOut // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void StructInit(int32_t& __ANY_STRUCT_REF); // Function EmbarkGameplay.EmbarkStructObject_Test.StructInit // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ProcessStructOut(); // Function EmbarkGameplay.EmbarkStructObject_Test.ProcessStructOut // (Final|Native|Public) // @ game+0x5dcebe0
	void Init(); // Function EmbarkGameplay.EmbarkStructObject_Test.Init // (Final|Native|Public) // @ game+0x5dceaa0
};

// Class EmbarkGameplay.EmbarkSkeletalMeshComponent
// Size: 0x1410 (Inherited: 0x10e0)
struct UEmbarkSkeletalMeshComponent : USkeletalMeshComponentBudgeted {
	char pad_10e0[0x10]; // 0x10e0(0x10)
	struct FAnimUpdateRateInfo AnimUpdateRateInfo; // 0x10f0(0x0c)
	char pad_10fc[0x4]; // 0x10fc(0x04)
	struct FOptimizedChildPoseCopyInfo OptimizedChildPoseCopyInfo; // 0x1100(0x88)
	bool bDisablePhysicsStateOnDedicatedServer; // 0x1188(0x01)
	bool bDisableLoadOnServer; // 0x1189(0x01)
	bool bCanTickAnimationOnServer; // 0x118a(0x01)
	bool bUseAnimationJobGraph; // 0x118b(0x01)
	bool bDeferKinematicBonesUpdateSameFrame; // 0x118c(0x01)
	char pad_118d[0x3]; // 0x118d(0x03)
	struct FGameplayTagContainer AdditionalClothCollisionTags; // 0x1190(0x20)
	float ClothParticleSystemWeight; // 0x11b0(0x04)
	char pad_11b4[0x4]; // 0x11b4(0x04)
	struct FVector ClothGravity; // 0x11b8(0x18)
	bool bUseCustomClothSpaceTransform; // 0x11d0(0x01)
	bool bScheduleClothInParallelAnimTask; // 0x11d1(0x01)
	char pad_11d2[0xe]; // 0x11d2(0x0e)
	struct FTransform CustomClothSpaceTransform; // 0x11e0(0x60)
	struct FName CustomClothBoneTransformName; // 0x1240(0x08)
	float ClothComponentMovementVelocity; // 0x1248(0x04)
	char pad_124c[0x5]; // 0x124c(0x05)
	bool bOnlyAllowScopedTickToggling; // 0x1251(0x01)
	char pad_1252[0xe]; // 0x1252(0x0e)
	struct TArray<struct UEmbarkSkeletalMeshComponent*> ChildComponentsToUpdate; // 0x1260(0x10)
	struct TArray<struct FSimpleAttachInfo> SimpleAttachers; // 0x1270(0x10)
	bool bUpdateInProgress; // 0x1280(0x01)
	char pad_1281[0x7]; // 0x1281(0x07)
	struct UEmbarkSkeletalMeshComponent* ParentComponent; // 0x1288(0x08)
	struct FSkeletalMeshPendingChanges PendingChanges; // 0x1290(0x40)
	char pad_12d0[0xd8]; // 0x12d0(0xd8)
	struct USkinnedAsset* CachedCurrentSkinnedAsset; // 0x13a8(0x08)
	char pad_13b0[0x38]; // 0x13b0(0x38)
	struct TArray<struct UObject*> TrackedNotifyStateClassToBitIndex; // 0x13e8(0x10)
	char pad_13f8[0x18]; // 0x13f8(0x18)

	bool TrackedNotifyStateIsActive(int32_t TrackedBitIndex); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.TrackedNotifyStateIsActive // (Final|Native|Public) // @ game+0x5dd3e90
	int32_t TrackedNotifyStateGetBitIndex(struct UAnimNotifyState* AnimNotifyStateType); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.TrackedNotifyStateGetBitIndex // (Final|Native|Public) // @ game+0x5dd4de0
	void SyncDeferredKinematicBonesUpdate(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SyncDeferredKinematicBonesUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd4950
	void SuspendNewStyleUpdate(bool bSuspend); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SuspendNewStyleUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd1c00
	void SetUseClothUnholyRefToLocals(bool bInUseClothUnholyRefToLocals); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetUseClothUnholyRefToLocals // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd2230
	void SetOverrideEndTickGroup(bool NewValue, enum class ETickingGroup InEndTickGroup); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetOverrideEndTickGroup // (Final|Native|Public) // @ game+0x5dd1290
	void SetGroundPlane(struct FVector3f& PlanePosition, struct FVector3f& PlaneNormal); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetGroundPlane // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5dcdec0
	void SetEnableGameThreadPreUpdateForPhysicsAccessDependencies(bool bInEnableGameThreadPreUpdateForPhysicsAccessDependencies); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetEnableGameThreadPreUpdateForPhysicsAccessDependencies // (Final|Native|Public) // @ game+0x5dcde20
	void SetClothUnholyScale(float InClothUnholyScale); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetClothUnholyScale // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd05d0
	void SetClothEndTickGroup(enum class ETickingGroup InEndTickGroup); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetClothEndTickGroup // (Final|Native|Public) // @ game+0x5dd16d0
	void SetClearMorphTargetsWhenChangingSkeletalMesh(bool bNewValue); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetClearMorphTargetsWhenChangingSkeletalMesh // (Final|Native|Public) // @ game+0x5dd04f0
	void SetAnimStateUpdaterComponent(struct UEmbarkAnimStateUpdaterComponent* InAnimStateUpdaterComponent); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.SetAnimStateUpdaterComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5dcdd10
	void ResetAllAnimInstanceNotifies(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.ResetAllAnimInstanceNotifies // (Final|Native|Public) // @ game+0x5dd2210
	void RemoveSimpleAttacher(struct USkeletalMeshComponent* AttacherToRemove); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.RemoveSimpleAttacher // (Final|Native|Public) // @ game+0x5dd3980
	void RegisterParentUpdate(struct UEmbarkSkeletalMeshComponent* Comp); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.RegisterParentUpdate // (Final|Native|Public|BlueprintCallable) // @ game+0x5dce380
	void RefreshClothingRelationships(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.RefreshClothingRelationships // (Final|Native|Public) // @ game+0x5dd1ca0
	bool IsUpdatingAnimation(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.IsUpdatingAnimation // (Final|Native|Public|Const) // @ game+0x5dceaf0
	bool IsUpdatedFromParentComponent(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.IsUpdatedFromParentComponent // (Final|Native|Public|Const) // @ game+0x5dd1670
	bool HasActiveClothingAssets(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.HasActiveClothingAssets // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dd1380
	bool GetUpdatesEnabledNewMode(); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.GetUpdatesEnabledNewMode // (Final|Native|Public|Const) // @ game+0x5dcf8f0
	struct UEmbarkSkeletalMeshComponent* CreateNewComponent(struct AActor* Owner, struct FName UniqueMeshName, bool ShouldAutoRegisterWithBudgetAllocator); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.CreateNewComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5dd4340
	void AddWindToClothSimulation(struct FVector3f& Wind); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.AddWindToClothSimulation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5dd1960
	void AddSimpleAttacher(struct USkeletalMeshComponent* Attacher, struct FName InAttachSocketName, bool bPushAttachTransformNow); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.AddSimpleAttacher // (Final|Native|Public) // @ game+0x5dd3820
	void AddForceToClothSimulation(struct FVector3f& Force); // Function EmbarkGameplay.EmbarkSkeletalMeshComponent.AddForceToClothSimulation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5dd3ce0
};

// Class EmbarkGameplay.EmbarkSMInstance
// Size: 0x7b0 (Inherited: 0x770)
struct UEmbarkSMInstance : USMInstance {
	bool bAllowTransitions; // 0x768(0x01)
	char pad_771[0x3f]; // 0x771(0x3f)

	void UpdateStateFromStateData(struct FEmbarkSMActiveStateData& NewActiveStateData); // Function EmbarkGameplay.EmbarkSMInstance.UpdateStateFromStateData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dd5100
	bool GetActiveStateData(struct FEmbarkSMActiveStateData& ActiveStateData, bool bForceUpdate); // Function EmbarkGameplay.EmbarkSMInstance.GetActiveStateData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dddb50
};

// Class EmbarkGameplay.EmbarkSMStateMachineComponent
// Size: 0x1f0 (Inherited: 0x160)
struct UEmbarkSMStateMachineComponent : UActorComponent {
	struct FMulticastInlineDelegate OnStateMachineInitializedEvent; // 0x158(0x10)
	struct FMulticastInlineDelegate OnStateMachineStartedEvent; // 0x168(0x10)
	struct FMulticastInlineDelegate OnStateMachineUpdatedEvent; // 0x178(0x10)
	struct FMulticastInlineDelegate OnStateMachineStoppedEvent; // 0x188(0x10)
	struct FMulticastInlineDelegate OnStateMachineTransitionTakenEvent; // 0x198(0x10)
	struct FMulticastInlineDelegate OnStateMachineStateChangedEvent; // 0x1a8(0x10)
	struct UEmbarkSMInstance* StateMachineClass; // 0x1b8(0x08)
	bool bInitializeOnBeginPlay; // 0x1c0(0x01)
	bool bStartOnBeginPlay; // 0x1c1(0x01)
	bool bAllowForLocalTransitions; // 0x1c2(0x01)
	float ServerTickInterval; // 0x1c4(0x04)
	float ClientTickInterval; // 0x1c8(0x04)
	struct FEmbarkSMActiveStateData ActiveStateData; // 0x1d0(0x10)
	struct USMStateMachineComponent* SMComponent; // 0x1e0(0x08)
	char pad_1eb[0x5]; // 0x1eb(0x05)

	void Update(float DeltaSeconds); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Update // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd58d0
	void Stop(); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Stop // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd79e0
	void Start(); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Start // (Final|Native|Public|BlueprintCallable) // @ game+0x5ddddc0
	void Shutdown(); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Shutdown // (Final|Native|Public|BlueprintCallable) // @ game+0x5dd73c0
	void OnRep_ActiveStateData(); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.OnRep_ActiveStateData // (Final|Native|Protected) // @ game+0x5dd73f0
	void Internal_OnStateMachineUpdated(struct USMInstance* SMInstance, float DeltaSeconds); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Internal_OnStateMachineUpdated // (Final|Native|Protected) // @ game+0x5dd78e0
	void Internal_OnStateMachineTransitionTaken(struct USMInstance* SMInstance, struct FSMTransitionInfo Transition); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Internal_OnStateMachineTransitionTaken // (Final|Native|Protected) // @ game+0x5dd69b0
	void Internal_OnStateMachineStopped(struct USMInstance* SMInstance); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Internal_OnStateMachineStopped // (Final|Native|Protected) // @ game+0x5dd7020
	void Internal_OnStateMachineStateChanged(struct USMInstance* SMInstance, struct FSMStateInfo ToState, struct FSMStateInfo FromState); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Internal_OnStateMachineStateChanged // (Final|Native|Protected) // @ game+0x5dde310
	void Internal_OnStateMachineStarted(struct USMInstance* SMInstance); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Internal_OnStateMachineStarted // (Final|Native|Protected) // @ game+0x5dd5d20
	void Internal_OnStateMachineInitializedEvent(struct USMInstance* Instance); // Function EmbarkGameplay.EmbarkSMStateMachineComponent.Internal_OnStateMachineInitializedEvent // (Final|Native|Protected) // @ game+0x5dddce0
};

// Class EmbarkGameplay.EmbarkSpectator
// Size: 0x450 (Inherited: 0x450)
struct AEmbarkSpectator : ASpectatorPawn {

	void ReceivePlayerSetupInputComponent(struct UInputComponent* PlayerInputComponent); // Function EmbarkGameplay.EmbarkSpectator.ReceivePlayerSetupInputComponent // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnRep_Controller(); // Function EmbarkGameplay.EmbarkSpectator.ReceiveOnRep_Controller // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	struct APawn* GetSpectatedPawn(); // Function EmbarkGameplay.EmbarkSpectator.GetSpectatedPawn // (Native|Event|Public|BlueprintEvent) // @ game+0x5dd8590
};

// Class EmbarkGameplay.EmbarkSpringArmComponent
// Size: 0x4d0 (Inherited: 0x4c0)
struct UEmbarkSpringArmComponent : USpringArmComponent {
	struct TArray<struct AActor*> IgnoreCollisionActors; // 0x4c0(0x10)

	void SetIgnoreCollisionActors(struct TArray<struct AActor*>& InActors); // Function EmbarkGameplay.EmbarkSpringArmComponent.SetIgnoreCollisionActors // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dd5f70
	void RemoveActorFromIgnoreCollisionActors(struct AActor* InActor); // Function EmbarkGameplay.EmbarkSpringArmComponent.RemoveActorFromIgnoreCollisionActors // (Final|Native|Public|BlueprintCallable) // @ game+0x5dde9c0
	void GetIgnoreCollisionActors(struct TArray<struct AActor*>& OutActors); // Function EmbarkGameplay.EmbarkSpringArmComponent.GetIgnoreCollisionActors // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5dd61d0
};

// Class EmbarkGameplay.EmbarkSquadMember
// Size: 0x120 (Inherited: 0xd0)
struct UEmbarkSquadMember : UReplicatedSubobject {
	struct FUniqueNetIdRepl UniqueID; // 0xc8(0x30)
	struct APlayerState* PlayerState; // 0xf8(0x08)
	struct FString SquadMemberMetaData; // 0x100(0x10)
	char pad_118[0x8]; // 0x118(0x08)

	void OnRep_UniqueId(); // Function EmbarkGameplay.EmbarkSquadMember.OnRep_UniqueId // (Final|Native|Private) // @ game+0x5dd7420
	void OnRep_SquadMemberMetaData(); // Function EmbarkGameplay.EmbarkSquadMember.OnRep_SquadMemberMetaData // (Final|Native|Private) // @ game+0x5dd7420
	void OnRep_PlayerState(); // Function EmbarkGameplay.EmbarkSquadMember.OnRep_PlayerState // (Final|Native|Private) // @ game+0x5dd7420
	struct APawn* GetMemberPawn(); // Function EmbarkGameplay.EmbarkSquadMember.GetMemberPawn // (Final|Native|Public|Const) // @ game+0x5dd5720
};

// Class EmbarkGameplay.EmbarkSquad
// Size: 0x430 (Inherited: 0x3a0)
struct AEmbarkSquad : AActor {
	struct FString Title; // 0x398(0x10)
	struct TArray<struct UEmbarkSquadMember*> Members; // 0x3a8(0x10)
	struct FString SquadId; // 0x3b8(0x10)
	int32_t Seed; // 0x3c8(0x04)
	enum class ESquadParticipationType ParticipationType; // 0x3cc(0x01)
	struct FMulticastInlineDelegate OnSquadChanged; // 0x3d0(0x10)
	char pad_3e5[0x4b]; // 0x3e5(0x4b)

	void SetSquadId(struct FString InSquadId); // Function EmbarkGameplay.EmbarkSquad.SetSquadId // (Final|Native|Public) // @ game+0x5dd6780
	void OnRep_Title(); // Function EmbarkGameplay.EmbarkSquad.OnRep_Title // (Final|Native|Private) // @ game+0x5dd7a00
	void OnRep_SquadId(); // Function EmbarkGameplay.EmbarkSquad.OnRep_SquadId // (Final|Native|Private) // @ game+0x5dda000
	void OnRep_Seed(); // Function EmbarkGameplay.EmbarkSquad.OnRep_Seed // (Final|Native|Private) // @ game+0x5dd7a00
	void OnRep_ParticipationType(); // Function EmbarkGameplay.EmbarkSquad.OnRep_ParticipationType // (Final|Native|Private) // @ game+0x5dd7a00
	void OnRep_Members(); // Function EmbarkGameplay.EmbarkSquad.OnRep_Members // (Final|Native|Private) // @ game+0x5ddd8f0
	void OnMod_Members(); // Function EmbarkGameplay.EmbarkSquad.OnMod_Members // (Final|Native|Private) // @ game+0x5dd7a00
	struct FString GetSquadId(); // Function EmbarkGameplay.EmbarkSquad.GetSquadId // (Final|Native|Public|Const) // @ game+0x5dd8be0
	struct FPartyInfo GetInfoFromPartyId(struct FString PartyId); // Function EmbarkGameplay.EmbarkSquad.GetInfoFromPartyId // (Final|Native|Public|Const) // @ game+0x5dda820
	void AddPartyMember(struct FString PartyId, struct FUniqueNetIdRepl& PartyMemberUniqueNetId); // Function EmbarkGameplay.EmbarkSquad.AddPartyMember // (Final|Native|Public|HasOutParms) // @ game+0x5dd5b20
};

// Class EmbarkGameplay.SquadStatics
// Size: 0xa0 (Inherited: 0xa0)
struct USquadStatics : UBlueprintFunctionLibrary {

	bool TryParseSquadJson(struct UObject* WorldContextObject, struct FString Json, struct TArray<struct AEmbarkSquad*>& OutSquads); // Function EmbarkGameplay.SquadStatics.TryParseSquadJson // (Final|Native|Static|Public|HasOutParms) // @ game+0x5dd9d40
	struct TArray<struct AEmbarkSquad*> ParseSquadJson(struct UObject* WorldContextObject, struct FString Json); // Function EmbarkGameplay.SquadStatics.ParseSquadJson // (Final|Native|Static|Public) // @ game+0x5ddbc90
	struct TArray<struct UEmbarkSquadMember*> FlattenSquads(struct TArray<struct AEmbarkSquad*>& Squads, enum class ESquadParticipationType ParticipationTypeFilter); // Function EmbarkGameplay.SquadStatics.FlattenSquads // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ddad90
};

// Class EmbarkGameplay.EmbarkStateMachineTransition
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStateMachineTransition : UObject {

	void BP_OnTransition(); // Function EmbarkGameplay.EmbarkStateMachineTransition.BP_OnTransition // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnStartBeingEvaluated(); // Function EmbarkGameplay.EmbarkStateMachineTransition.BP_OnStartBeingEvaluated // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool BP_CanEnter(); // Function EmbarkGameplay.EmbarkStateMachineTransition.BP_CanEnter // (Native|Event|Protected|BlueprintEvent|Const) // @ game+0x3247a90
};

// Class EmbarkGameplay.EmbarkStateMachineState
// Size: 0xa60 (Inherited: 0xa0)
struct UEmbarkStateMachineState : UObject {
	struct FMulticastInlineDelegate OnEnter; // 0x98(0x10)
	struct FMulticastInlineDelegate OnPostEnter; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnExit; // 0xb8(0x10)
	struct FEmbarkStateMachine LocalStateMachine; // 0xc8(0x990)

	void Start(struct UEmbarkStateMachineState* State); // Function EmbarkGameplay.EmbarkStateMachineState.Start // (Final|Native|Public) // @ game+0x5dd9800
	void SetCanOnlyExitWhenLocalStateMachineIsFinished(bool bCanOnlyExitWhenLocalStateMachineIsFinished); // Function EmbarkGameplay.EmbarkStateMachineState.SetCanOnlyExitWhenLocalStateMachineIsFinished // (Final|Native|Public) // @ game+0x5dd5c80
	float GetTimeInState(); // Function EmbarkGameplay.EmbarkStateMachineState.GetTimeInState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5dd6030
	struct FEmbarkStateMachineStateInstance From(struct UEmbarkStateMachineState* State); // Function EmbarkGameplay.EmbarkStateMachineState.From // (Final|Native|Public) // @ game+0x5dd5a00
	void ForceTickStateManually(float DeltaSeconds, int32_t ForciblyRecurseCount); // Function EmbarkGameplay.EmbarkStateMachineState.ForceTickStateManually // (Final|Native|Public) // @ game+0x5ddd6f0
	void BP_Tick(float DeltaSeconds); // Function EmbarkGameplay.EmbarkStateMachineState.BP_Tick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_Exit(); // Function EmbarkGameplay.EmbarkStateMachineState.BP_Exit // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_Enter(); // Function EmbarkGameplay.EmbarkStateMachineState.BP_Enter // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool BP_CanExit(); // Function EmbarkGameplay.EmbarkStateMachineState.BP_CanExit // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3247a90
};

// Class EmbarkGameplay.EmbarkStateMachineMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStateMachineMixinLibrary : UObject {

	void Tick(struct FEmbarkStateMachine& StateMachine, float DeltaSeconds, int32_t ForciblyRecurseTransitionCount); // Function EmbarkGameplay.EmbarkStateMachineMixinLibrary.Tick // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5ddb570
	void Start(struct FEmbarkStateMachine& StateMachine, struct UEmbarkStateMachineState* State); // Function EmbarkGameplay.EmbarkStateMachineMixinLibrary.Start // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5ddc990
	bool HasReachedEndState(struct FEmbarkStateMachine& StateMachine); // Function EmbarkGameplay.EmbarkStateMachineMixinLibrary.HasReachedEndState // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5dd7650
	struct TArray<struct UEmbarkStateMachineTransition*> GetActiveTransitions(struct FEmbarkStateMachine& StateMachine); // Function EmbarkGameplay.EmbarkStateMachineMixinLibrary.GetActiveTransitions // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5ddec80
	struct UEmbarkStateMachineState* GetActiveState(struct FEmbarkStateMachine& StateMachine); // Function EmbarkGameplay.EmbarkStateMachineMixinLibrary.GetActiveState // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5dddde0
	struct FEmbarkStateMachineStateInstance From(struct FEmbarkStateMachine& StateMachine, struct UEmbarkStateMachineState* State); // Function EmbarkGameplay.EmbarkStateMachineMixinLibrary.From // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5ddb910
};

// Class EmbarkGameplay.EmbarkStateMachineStateInstanceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStateMachineStateInstanceMixinLibrary : UObject {

	struct FEmbarkStateMachineStateInstance Via(struct FEmbarkStateMachineStateInstance& StateInstance, struct UEmbarkStateMachineTransition* Transition, int32_t Priority, float TimeToWaitInEnterableStateUntilEnterable); // Function EmbarkGameplay.EmbarkStateMachineStateInstanceMixinLibrary.Via // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5ddd220
	struct FEmbarkStateMachineStateInstance ToAlways(struct FEmbarkStateMachineStateInstance& StateInstance, struct UEmbarkStateMachineState* State); // Function EmbarkGameplay.EmbarkStateMachineStateInstanceMixinLibrary.ToAlways // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5dd51c0
	struct FEmbarkStateMachineStateInstance To(struct FEmbarkStateMachineStateInstance& StateInstance, struct UEmbarkStateMachineState* State); // Function EmbarkGameplay.EmbarkStateMachineStateInstanceMixinLibrary.To // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5ddc100
};

// Class EmbarkGameplay.EmbarkStateMachineTestTransition
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStateMachineTestTransition : UEmbarkStateMachineTransition {
};

// Class EmbarkGameplay.EmbarkStateMachineTestState
// Size: 0xa70 (Inherited: 0xa60)
struct UEmbarkStateMachineTestState : UEmbarkStateMachineState {
	char pad_a60[0x10]; // 0xa60(0x10)
};

// Class EmbarkGameplay.EmbarkStaticMeshComponent
// Size: 0x790 (Inherited: 0x790)
struct UEmbarkStaticMeshComponent : UStaticMeshComponent {

	struct UEmbarkStaticMeshComponent* CreateNewComponent(struct AActor* Owner, struct FName UniqueMeshName); // Function EmbarkGameplay.EmbarkStaticMeshComponent.CreateNewComponent // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5df5760
};

// Class EmbarkGameplay.EmbarkWatermarkSubsystem
// Size: 0xc0 (Inherited: 0xb0)
struct UEmbarkWatermarkSubsystem : UScriptGameInstanceSubsystem {
	struct UUserWidget* WatermarkWidgetClass; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class EmbarkGameplay.EmbarkWorldAssociatedObject
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWorldAssociatedObject : UObject {
};

// Class EmbarkGameplay.EmbarkTickableWorldSubsystem
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkTickableWorldSubsystem : UTickableWorldSubsystem {

	void OnTick(float DeltaTime); // Function EmbarkGameplay.EmbarkTickableWorldSubsystem.OnTick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnInitialized(); // Function EmbarkGameplay.EmbarkTickableWorldSubsystem.OnInitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnDeinitialized(); // Function EmbarkGameplay.EmbarkTickableWorldSubsystem.OnDeinitialized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkGameplay.GameStateBaseMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameStateBaseMixinLibrary : UObject {

	void RemovePlayerState(struct AGameStateBase* GameStateBase, struct APlayerState* PlayerState); // Function EmbarkGameplay.GameStateBaseMixinLibrary.RemovePlayerState // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5de8500
	void AddPlayerState(struct AGameStateBase* GameStateBase, struct APlayerState* PlayerState); // Function EmbarkGameplay.GameStateBaseMixinLibrary.AddPlayerState // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5df1bb0
};

// Class EmbarkGameplay.LevelSequenceLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULevelSequenceLibrary : UBlueprintFunctionLibrary {

	struct ULevelSequencePlayer* CreateLevelSequencePlayerWithClass(struct UObject* WorldContextObject, struct ULevelSequence* InLevelSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ALevelSequenceActor* LevelSequenceActorType, struct ALevelSequenceActor*& OutActor); // Function EmbarkGameplay.LevelSequenceLibrary.CreateLevelSequencePlayerWithClass // (Final|Native|Static|Private|HasOutParms) // @ game+0x5de3500
};

// Class EmbarkGameplay.PreloadableEmbarkActor
// Size: 0x480 (Inherited: 0x470)
struct APreloadableEmbarkActor : AEmbarkActor {
	int32_t IndexInWorldItemList; // 0x470(0x04)
	char pad_474[0xc]; // 0x474(0x0c)

	int32_t GetAndCacheIndexInWorldItemArray(); // Function EmbarkGameplay.PreloadableEmbarkActor.GetAndCacheIndexInWorldItemArray // (Final|Native|Public) // @ game+0x5de0c30
};

// Class EmbarkGameplay.PreloadableEmbarkActorListAsset
// Size: 0xb0 (Inherited: 0xa0)
struct UPreloadableEmbarkActorListAsset : UPrimaryDataAsset {
	struct TArray<struct TSoftClassPtr<UObject>> WorldItemClasses; // 0xa0(0x10)
};

// Class EmbarkGameplay.TransformArrayComponent
// Size: 0x160 (Inherited: 0x160)
struct UTransformArrayComponent : UActorComponent {

	bool GetTransformAtIndex(int32_t Index, struct FTransform& OutTransform, bool bWorldSpace); // Function EmbarkGameplay.TransformArrayComponent.GetTransformAtIndex // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5df5dd0
	bool GetAllTransforms(struct TArray<struct FTransform>& OutTransforms, bool bWorldSpace); // Function EmbarkGameplay.TransformArrayComponent.GetAllTransforms // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x5de0c80
};

