// Enum EmbarkMovement.EEmbarkLocalBaseType
enum class EEmbarkLocalBaseType : uint8_t {
	None = 0,
	StandingOnBase = 1,
	AboveBase = 2,
	MovingTowardsBase = 4,
	All = 7,
	EEmbarkLocalBaseType_MAX = 8
};

// Enum EmbarkMovement.EEmbarkCustomMovementMode
enum class EEmbarkCustomMovementMode : uint8_t {
	CUSTOM_Default = 0,
	CUSTOM_AnimSequenceRootWarp = 1,
	CUSTOM_Max = 2
};

// Enum EmbarkMovement.EGroundSuspensionMode
enum class EGroundSuspensionMode : uint8_t {
	Deactivated = 0,
	PushFromGround = 1,
	PullToGround = 2,
	PushAndPull = 3,
	EGroundSuspensionMode_MAX = 4
};

// ScriptStruct EmbarkMovement.EmbarkServersideReplicatedInput
// Size: 0x1f0 (Inherited: 0x00)
struct FEmbarkServersideReplicatedInput {
	float ClientGeneratedInputTimestamp; // 0x00(0x04)
	char pad_4[0xc]; // 0x04(0x0c)
	struct FPendulumClaims PendulumClaims; // 0x10(0x160)
	struct FVector InputVector; // 0x170(0x18)
	struct FVector RawInputVector; // 0x188(0x18)
	struct FRotator ControlRotation; // 0x1a0(0x18)
	char pad_1b8[0x20]; // 0x1b8(0x20)
	int32_t InputFrame; // 0x1d8(0x04)
	char pad_1dc[0x4]; // 0x1dc(0x04)
	bool bIsUsingGamepad; // 0x1e0(0x01)
	bool bIsAimAssistEnabled; // 0x1e1(0x01)
	char pad_1e2[0xe]; // 0x1e2(0x0e)
};

// ScriptStruct EmbarkMovement.PendulumClaims
// Size: 0x160 (Inherited: 0x00)
struct FPendulumClaims {
	struct FPendulumRootMotionClaim VaultClaim; // 0x00(0x150)
	bool bWantsToWallJump; // 0x150(0x01)
	char pad_151[0xf]; // 0x151(0x0f)
};

// ScriptStruct EmbarkMovement.PendulumRootMotionClaim
// Size: 0x150 (Inherited: 0x00)
struct FPendulumRootMotionClaim {
	struct FEmbarkRootWarpSpace RootWarpSpace; // 0x00(0x140)
	struct FPendulumRootMotionHandle RootMotionHandle; // 0x140(0x02)
	bool bWantsToPlay; // 0x142(0x01)
	char pad_143[0xd]; // 0x143(0x0d)
};

// ScriptStruct EmbarkMovement.PendulumRootMotionHandle
// Size: 0x02 (Inherited: 0x00)
struct FPendulumRootMotionHandle {
	char CategoryIndex; // 0x00(0x01)
	char SequenceIndex; // 0x01(0x01)
};

// ScriptStruct EmbarkMovement.EmbarkRootWarpSpace
// Size: 0x140 (Inherited: 0x00)
struct FEmbarkRootWarpSpace {
	bool bIsValid; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FEmbarkRootWarpSpaceTransformData TransformData; // 0x08(0x68)
	struct FName AttachedToBone; // 0x70(0x08)
	struct USceneComponent* AttachedToComponent; // 0x78(0x08)
	char pad_80[0xc0]; // 0x80(0xc0)
};

// ScriptStruct EmbarkMovement.EmbarkRootWarpSpaceTransformData
// Size: 0x68 (Inherited: 0x00)
struct FEmbarkRootWarpSpaceTransformData {
	char bIsWorldSpace : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector WarpStartLocation; // 0x08(0x18)
	struct FVector WarpStartRotation; // 0x20(0x18)
	struct FVector WarpEndLocation; // 0x38(0x18)
	struct FVector WarpEndRotation; // 0x50(0x18)
};

// ScriptStruct EmbarkMovement.RootMotionInputScale
// Size: 0x0c (Inherited: 0x00)
struct FRootMotionInputScale {
	float InputScale; // 0x00(0x04)
	float InputScaleSides; // 0x04(0x04)
	float InputScaleFwdBwd; // 0x08(0x04)
};

// ScriptStruct EmbarkMovement.RootMotionVisualMeshCorrectionData
// Size: 0x04 (Inherited: 0x00)
struct FRootMotionVisualMeshCorrectionData {
	float CharacterScale; // 0x00(0x04)
};

// ScriptStruct EmbarkMovement.RootMotionAnimData
// Size: 0xe0 (Inherited: 0x00)
struct FRootMotionAnimData {
	struct FGameplayTag GameplayTags; // 0x00(0x08)
	struct FGameplayTagContainer AbilityGameplayTags; // 0x08(0x20)
	struct TArray<struct UAnimSequence*> Sequences; // 0x28(0x10)
	float StartTimeStamp; // 0x38(0x04)
	float SpeedScale; // 0x3c(0x04)
	float StartTimeOffset; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FRuntimeFloatCurve WarpCurve; // 0x48(0x88)
	float WarpedDuration; // 0xd0(0x04)
	struct FRootMotionVisualMeshCorrectionData VisualMeshCorrectionData; // 0xd4(0x04)
	char RepIndex; // 0xd8(0x01)
	char pad_d9[0x7]; // 0xd9(0x07)
};

// ScriptStruct EmbarkMovement.LocalBaseReplicatedInfo
// Size: 0x80 (Inherited: 0x00)
struct FLocalBaseReplicatedInfo {
	struct UPrimitiveComponent* MovementBase; // 0x00(0x08)
	struct FName BoneName; // 0x08(0x08)
	struct FReplicatedTransform Transform; // 0x10(0x68)
	bool bServerHasBaseComponent; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
};

// ScriptStruct EmbarkMovement.CharacterMovementRootWarpContext
// Size: 0xb0 (Inherited: 0x00)
struct FCharacterMovementRootWarpContext {
	struct FTransform WarpEndTransform; // 0x00(0x60)
	struct FVector WarpDeltaMove; // 0x60(0x18)
	struct FVector InputVector; // 0x78(0x18)
	bool bSweepMove; // 0x90(0x01)
	char pad_91[0x3]; // 0x91(0x03)
	float DeltaSeconds; // 0x94(0x04)
	float InputScaleSides; // 0x98(0x04)
	float InputScaleFwdBwd; // 0x9c(0x04)
	bool bIsFirstSimFrame; // 0xa0(0x01)
	char pad_a1[0xf]; // 0xa1(0x0f)
};

// ScriptStruct EmbarkMovement.EmbarkGroundNormal
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkGroundNormal {
	struct FVector Vec; // 0x00(0x18)
	float GroundNormalPitch; // 0x18(0x04)
	float GroundNormalYaw; // 0x1c(0x04)
};

// ScriptStruct EmbarkMovement.EmbarkCharacterMovementBaseState
// Size: 0x3b0 (Inherited: 0x00)
struct FEmbarkCharacterMovementBaseState {
	struct FVector Location; // 0x00(0x18)
	struct FVector Velocity; // 0x18(0x18)
	struct FEmbarkGroundNormal GroundNormal; // 0x30(0x20)
	enum class EMovementMode MovementMode; // 0x50(0x01)
	bool bIsInJump; // 0x51(0x01)
	bool bIsInDoubleJump; // 0x52(0x01)
	char pad_53[0x1]; // 0x53(0x01)
	float JumpStamina; // 0x54(0x04)
	float TimeSinceGrounded; // 0x58(0x04)
	float TimeSinceJump; // 0x5c(0x04)
	bool bIsInCrouch; // 0x60(0x01)
	bool bIsInSlide; // 0x61(0x01)
	bool bIsInWater; // 0x62(0x01)
	char pad_63[0x1]; // 0x63(0x01)
	float FootToGroundHeight; // 0x64(0x04)
	struct FLocalBaseReplicatedInfo LocalBaseInfo; // 0x68(0x80)
	char pad_e8[0x8]; // 0xe8(0x08)
	struct FPendulumSimState PendulumSimState; // 0xf0(0x2b0)
	float CurrentTime; // 0x3a0(0x04)
	int32_t CurrentTick; // 0x3a4(0x04)
	char pad_3a8[0x8]; // 0x3a8(0x08)
};

// ScriptStruct EmbarkMovement.PendulumSimState
// Size: 0x2b0 (Inherited: 0x00)
struct FPendulumSimState {
	struct FPendulumRootMotionState RootMotionState; // 0x00(0x1a0)
	struct FPendulumVaultSimState VaultSimState; // 0x1a0(0xf0)
	bool bHasWalkableFloor; // 0x290(0x01)
	char pad_291[0x7]; // 0x291(0x07)
	struct UPrimitiveComponent* FloorComponent; // 0x298(0x08)
	struct FName FloorBoneName; // 0x2a0(0x08)
	char pad_2a8[0x8]; // 0x2a8(0x08)
};

// ScriptStruct EmbarkMovement.PendulumVaultSimState
// Size: 0xf0 (Inherited: 0x00)
struct FPendulumVaultSimState {
	struct FPendulumBlockedVaultables BlockedVaultables; // 0x00(0xe8)
	float VaultCooldownEndsTimeStamp; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// ScriptStruct EmbarkMovement.PendulumBlockedVaultables
// Size: 0xe8 (Inherited: 0x00)
struct FPendulumBlockedVaultables {
	char pad_0[0xe8]; // 0x00(0xe8)
};

// ScriptStruct EmbarkMovement.PendulumRootMotionState
// Size: 0x1a0 (Inherited: 0x00)
struct FPendulumRootMotionState {
	struct FEmbarkRootWarpSpace RootWarpSpace; // 0x00(0x140)
	struct FPendulumRootMotionHandle RootMotionHandle; // 0x140(0x02)
	char pad_142[0x6]; // 0x142(0x06)
	struct FVector RootMotionGoblinVelocity; // 0x148(0x18)
	struct FVector RootMotionStartLocation; // 0x160(0x18)
	struct FVector RootMotionStartRotation; // 0x178(0x18)
	float AnimStartTimeStamp; // 0x190(0x04)
	float AnimStartTimeOffset; // 0x194(0x04)
	bool bClipActive; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
};

// ScriptStruct EmbarkMovement.FrictionInfo
// Size: 0x10 (Inherited: 0x00)
struct FFrictionInfo {
	float Friction; // 0x00(0x04)
	float BrakingFriction; // 0x04(0x04)
	bool bUseSeparateBrakingFriction; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float BrakingFrictionFactor; // 0x0c(0x04)
};

// ScriptStruct EmbarkMovement.OnGroundAccelerationParams
// Size: 0x28 (Inherited: 0x00)
struct FOnGroundAccelerationParams {
	float MaxAcceleration; // 0x00(0x04)
	float MaxAccelerationForward; // 0x04(0x04)
	float MaxAccelerationSideways; // 0x08(0x04)
	float MaxAccelerationBackwards; // 0x0c(0x04)
	bool bEnableDirectionalAccelerationModel; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float BrakingDeceleration; // 0x14(0x04)
	struct FFrictionInfo FrictionInfo; // 0x18(0x10)
};

// ScriptStruct EmbarkMovement.InAirAccelerationParams
// Size: 0x24 (Inherited: 0x00)
struct FInAirAccelerationParams {
	float MaxAcceleration; // 0x00(0x04)
	float BrakingDeceleration; // 0x04(0x04)
	float PhysicsVolumeTerminalVelocity; // 0x08(0x04)
	float PhysicsVolumeFluidFriction; // 0x0c(0x04)
	bool bHasAnimRootMotion; // 0x10(0x01)
	bool bRootMotionHasOverrideVelocity; // 0x11(0x01)
	bool bCheatFlying; // 0x12(0x01)
	char pad_13[0x1]; // 0x13(0x01)
	struct FFrictionInfo FrictionInfo; // 0x14(0x10)
};

// ScriptStruct EmbarkMovement.EmbarkCustomMovementFlags
// Size: 0x01 (Inherited: 0x00)
struct FEmbarkCustomMovementFlags {
	char bCustomFlag0 : 1; // 0x00(0x01)
	char bCustomFlag1 : 1; // 0x00(0x01)
	char bCustomFlag2 : 1; // 0x00(0x01)
	char bCustomFlag3 : 1; // 0x00(0x01)
	char pad_0_4 : 4; // 0x00(0x01)
};

// ScriptStruct EmbarkMovement.EmbarkMovementDirectionSpeed
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkMovementDirectionSpeed {
	float Forward; // 0x00(0x04)
	float Strafing; // 0x04(0x04)
	float BackPedaling; // 0x08(0x04)
};

// ScriptStruct EmbarkMovement.EmbarkMovementParamsStatic
// Size: 0x390 (Inherited: 0x00)
struct FEmbarkMovementParamsStatic {
	bool bIsServer; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector InputVector; // 0x08(0x18)
	bool bWantsToJump; // 0x20(0x01)
	bool bWantsToCrouch; // 0x21(0x01)
	bool bWantsToSlide; // 0x22(0x01)
	char pad_23[0x1]; // 0x23(0x01)
	float SimulateTime; // 0x24(0x04)
	float CharacterScale; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
	struct FRotator ControlRotation; // 0x30(0x18)
	float WorldTimeSeconds; // 0x48(0x04)
	float CapsuleHalfHeightCrouching; // 0x4c(0x04)
	float CapsuleHalfHeightStanding; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct UEmbarkCharacterMovementStaticCallerBase* StaticCaller; // 0x58(0x08)
	struct TArray<struct AActor*> CapsuleIgnoreActors; // 0x60(0x10)
	float CapsuleRadius; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FVector CachedSlideJumpVelocity; // 0x78(0x18)
	float MaxAcceleration; // 0x90(0x04)
	float FallingLateralFriction; // 0x94(0x04)
	float GroundFriction; // 0x98(0x04)
	float BrakingDecelerationWalking; // 0x9c(0x04)
	float BrakingDecelerationFalling; // 0xa0(0x04)
	float BrakingDecelerationFlying; // 0xa4(0x04)
	float BrakingFrictionFactor; // 0xa8(0x04)
	float BrakingFriction; // 0xac(0x04)
	float MinAnalogSpeed; // 0xb0(0x04)
	bool bUseSeparateBrakingFriction; // 0xb4(0x01)
	bool bMaintainHorizontalGroundVelocity; // 0xb5(0x01)
	bool bHasAnimRootMotion; // 0xb6(0x01)
	bool bRootMotionHasOverrideVelocity; // 0xb7(0x01)
	float PhysicsVolumeTerminalVelocity; // 0xb8(0x04)
	float PhysicsVolumeFluidFriction; // 0xbc(0x04)
	float GravityZ; // 0xc0(0x04)
	bool bCheatFlying; // 0xc4(0x01)
	char pad_c5[0x3]; // 0xc5(0x03)
	float JumpMaxHoldTime; // 0xc8(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)
	struct FVector FloorVelocity; // 0xd0(0x18)
	bool bFloorIsSimulatingServer; // 0xe8(0x01)
	bool bIsCrouched; // 0xe9(0x01)
	bool bIsSprinting; // 0xea(0x01)
	bool bIsWalking; // 0xeb(0x01)
	enum class EMovementMode MovementModeAtPostPhysics; // 0xec(0x01)
	char pad_ed[0x3]; // 0xed(0x03)
	struct FEmbarkMovementDirectionSpeed RunSpeed; // 0xf0(0x0c)
	struct FEmbarkMovementDirectionSpeed SprintSpeed; // 0xfc(0x0c)
	struct FEmbarkMovementDirectionSpeed CrouchSpeed; // 0x108(0x0c)
	float AimWalkSpeed; // 0x114(0x04)
	float FlyingSpeed; // 0x118(0x04)
	float SpeedModifier; // 0x11c(0x04)
	struct FVirtualTerrainWalkableThresholds BaseVirtualTerrainThresholds; // 0x120(0x0c)
	struct FVirtualTerrainGroundTracerConfig BaseVirtualTerrainGroundTracerCfg; // 0x12c(0x10)
	float MaxWalkingAcceleration; // 0x13c(0x04)
	float MaxWalkingAccelerationForward; // 0x140(0x04)
	float MaxWalkingAccelerationSideways; // 0x144(0x04)
	float MaxWalkingAccelerationBackwards; // 0x148(0x04)
	bool bEnableDirectionalWalkingAccelerationModel; // 0x14c(0x01)
	char pad_14d[0x3]; // 0x14d(0x03)
	float MaxFallingAcceleration; // 0x150(0x04)
	float MaxFlyingAcceleration; // 0x154(0x04)
	float MaxFallingSpeedHorizontal; // 0x158(0x04)
	float JumpZVelocity; // 0x15c(0x04)
	float JumpStaminaConsumptionPerJump; // 0x160(0x04)
	float JumpStaminaGainSpeed; // 0x164(0x04)
	float JumpStaminaHorizontalVelMinScale; // 0x168(0x04)
	float MinJumpStaminaZVelocity; // 0x16c(0x04)
	float JumpCoyoteTimeThreshold; // 0x170(0x04)
	struct FGameplayTag VaultAbilityTag; // 0x174(0x08)
	struct FGameplayTag VaultAbilityBlockedTag; // 0x17c(0x08)
	float VaultObjectCooldown; // 0x184(0x04)
	float VaultCooldown; // 0x188(0x04)
	float WallJumpCooldown; // 0x18c(0x04)
	float MaxZVelocityToInheritWhenEndingVault; // 0x190(0x04)
	float FallingHorizontalDragCoefficient; // 0x194(0x04)
	float FallingHorizontalDragThresholdSpeed; // 0x198(0x04)
	float FallingVerticalDragCoefficient; // 0x19c(0x04)
	struct FEmbarkMovementBlockedFloorsContainer BlockedFloorsContainer; // 0x1a0(0x28)
	char pad_1c8[0x8]; // 0x1c8(0x08)
	struct FPendulumClaims PendulumClaims; // 0x1d0(0x160)
	struct FGameplayTagContainer ActiveGASTags; // 0x330(0x20)
	struct FGameplayTagContainer CancelAbilitiesGASTags; // 0x350(0x20)
	struct UEmbarkDataAsset* RootMotionDefinitions; // 0x370(0x08)
	float WaterSpeedMultiplier; // 0x378(0x04)
	float WaterJumpVelocityMultiplier; // 0x37c(0x04)
	bool bEnableDoubleJump; // 0x380(0x01)
	bool bDoubleJumpRequiresNormalJumpFirst; // 0x381(0x01)
	char pad_382[0x2]; // 0x382(0x02)
	float DoubleJumpWithinNormalJumpTime; // 0x384(0x04)
	float DoubleJumpMinTimeAfterJump; // 0x388(0x04)
	float DoubleJumpZVelocity; // 0x38c(0x04)
};

// ScriptStruct EmbarkMovement.EmbarkMovementBlockedFloorsContainer
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkMovementBlockedFloorsContainer {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkMovement.VirtualTerrainGroundTracerConfig
// Size: 0x10 (Inherited: 0x00)
struct FVirtualTerrainGroundTracerConfig {
	float LookAheadGridStretchScalar; // 0x00(0x04)
	float LookAheadForwardStretchScalar; // 0x04(0x04)
	float LookAheadVelocityInfluence; // 0x08(0x04)
	float LookAheadInputInfluence; // 0x0c(0x04)
};

// ScriptStruct EmbarkMovement.VirtualTerrainWalkableThresholds
// Size: 0x0c (Inherited: 0x00)
struct FVirtualTerrainWalkableThresholds {
	float MaxStepUpHeight; // 0x00(0x04)
	float MaxStepDownHeight; // 0x04(0x04)
	float MaxWalkableAngle; // 0x08(0x04)
};

// ScriptStruct EmbarkMovement.EmbarkMovementParamsTransientResultColliderData
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkMovementParamsTransientResultColliderData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FVector PushedDirection; // 0x08(0x18)
};

// ScriptStruct EmbarkMovement.EmbarkMovementParamsTransientResult
// Size: 0x118 (Inherited: 0x00)
struct FEmbarkMovementParamsTransientResult {
	bool bConstrainedMove; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float CompressedKneesPercentage; // 0x04(0x04)
	char pad_8[0x110]; // 0x08(0x110)
};

// ScriptStruct EmbarkMovement.EmbarkMovementParamsDynamic
// Size: 0x540 (Inherited: 0x00)
struct FEmbarkMovementParamsDynamic {
	struct FVector Location; // 0x00(0x18)
	struct FVector Velocity; // 0x18(0x18)
	struct FVector GroundNormal; // 0x30(0x18)
	enum class EMovementMode MovementMode; // 0x48(0x01)
	bool bIsInJump; // 0x49(0x01)
	bool bIsInDoubleJump; // 0x4a(0x01)
	char pad_4b[0x1]; // 0x4b(0x01)
	float JumpStamina; // 0x4c(0x04)
	bool bIsInCrouch; // 0x50(0x01)
	bool bIsInSlide; // 0x51(0x01)
	bool bSimpleTracesWhenNotMoving; // 0x52(0x01)
	bool bSimpleTracesWhenMoving; // 0x53(0x01)
	bool bIsInWater; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
	float FootToGroundHeight; // 0x58(0x04)
	char pad_5c[0x4]; // 0x5c(0x04)
	struct FFindFloorResult FloorResult; // 0x60(0xf8)
	bool bIsFloorWalkable; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	float TimeSinceGrounded; // 0x15c(0x04)
	float TimeSinceJump; // 0x160(0x04)
	float MaxSpeed; // 0x164(0x04)
	float CurrentTime; // 0x168(0x04)
	int32_t CurrentTick; // 0x16c(0x04)
	struct FPendulumSimState PendulumSimState; // 0x170(0x2b0)
	struct FEmbarkMovementParamsTransientResult TransientResult; // 0x420(0x118)
	char pad_538[0x8]; // 0x538(0x08)
};

// ScriptStruct EmbarkMovement.KneeHeightPill
// Size: 0x80 (Inherited: 0x00)
struct FKneeHeightPill {
	float KneeHeightAboveGround; // 0x00(0x04)
	float OwnerCapsulePillHalfHeight; // 0x04(0x04)
	float HalfHeight; // 0x08(0x04)
	float Radius; // 0x0c(0x04)
	float HeightOffsetFromCharacterCapsule; // 0x10(0x04)
	float DistanceFromGround; // 0x14(0x04)
	struct FName CollisionProfileName; // 0x18(0x08)
	struct FVector Location; // 0x20(0x18)
	struct TArray<struct AActor*> ActorsToIgnore; // 0x38(0x10)
	struct FVector FootLocation; // 0x48(0x18)
	struct FVector OwnerLocation; // 0x60(0x18)
	char pad_78[0x8]; // 0x78(0x08)
};

// ScriptStruct EmbarkMovement.DiscreteMove
// Size: 0x50 (Inherited: 0x00)
struct FDiscreteMove {
	struct FVector OriginalVelocity; // 0x00(0x18)
	struct FVector MoveVec; // 0x18(0x18)
	struct FVector MoveDir; // 0x30(0x18)
	float MoveDistance; // 0x48(0x04)
	float DeltaSeconds; // 0x4c(0x04)
};

// ScriptStruct EmbarkMovement.KneeHeightMoveSimulationContext
// Size: 0x358 (Inherited: 0x00)
struct FKneeHeightMoveSimulationContext {
	struct FKneeHeightPill KneeHeightPill; // 0x00(0x80)
	struct FDiscreteMove InitialMove; // 0x80(0x50)
	struct FVirtualTerrainWalkableThresholds WalkableThresholds; // 0xd0(0x0c)
	bool bDisallowUpwardsBounces; // 0xdc(0x01)
	bool bReflectMoveAgainstBadFloorAngles; // 0xdd(0x01)
	char pad_de[0x2]; // 0xde(0x02)
	struct FVirtualTerrainGroundPlane GroundPlane; // 0xe0(0x238)
	float SimulateTime; // 0x318(0x04)
	char pad_31c[0x4]; // 0x31c(0x04)
	struct FVector Location; // 0x320(0x18)
	enum class EGroundSuspensionMode GroundSuspensionMode; // 0x338(0x01)
	bool bVelocityCompensateSuspension; // 0x339(0x01)
	char pad_33a[0x6]; // 0x33a(0x06)
	struct TArray<struct UObject*> IgnoreStartingPenetrationOfTypes; // 0x340(0x10)
	char pad_350[0x8]; // 0x350(0x08)
};

// ScriptStruct EmbarkMovement.VirtualTerrainGroundPlane
// Size: 0x238 (Inherited: 0x00)
struct FVirtualTerrainGroundPlane {
	struct FHitResult MostRelevantHitResult; // 0x00(0xe8)
	struct FHitResult MostRelevantValidHitResult; // 0xe8(0xe8)
	struct FVector GroundPlaneCenter; // 0x1d0(0x18)
	struct FVector AllHitsGroundPlaneCenter; // 0x1e8(0x18)
	struct FVector AllHitsGroundNormal; // 0x200(0x18)
	struct FVector GroundNormal; // 0x218(0x18)
	bool bHasHits; // 0x230(0x01)
	bool bHasValidGround; // 0x231(0x01)
	bool bGroundAngleIsWalkable; // 0x232(0x01)
	char pad_233[0x5]; // 0x233(0x05)
};

// ScriptStruct EmbarkMovement.KneeHeightMoveSimulationResult
// Size: 0x3d8 (Inherited: 0x00)
struct FKneeHeightMoveSimulationResult {
	struct FKneeHeightPill KneeHeightPill; // 0x00(0x80)
	struct FHitResult CollisionResult; // 0x80(0xe8)
	struct FVirtualTerrainGroundPlane GroundPlane; // 0x168(0x238)
	float FootToGroundHeight; // 0x3a0(0x04)
	char pad_3a4[0x4]; // 0x3a4(0x04)
	struct FVector Location; // 0x3a8(0x18)
	struct FVector Velocity; // 0x3c0(0x18)
};

// ScriptStruct EmbarkMovement.MoveCollisionDebugData
// Size: 0x68 (Inherited: 0x00)
struct FMoveCollisionDebugData {
	bool bCollided; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector CollisionFreeMove; // 0x08(0x18)
	struct FVector BouncedMove; // 0x20(0x18)
	struct FVector WallNormal; // 0x38(0x18)
	struct FVector SlideMove; // 0x50(0x18)
};

// ScriptStruct EmbarkMovement.KneeHeightMoveDebugData
// Size: 0x1060 (Inherited: 0x00)
struct FKneeHeightMoveDebugData {
	struct FEmbarkMovementParamsDynamic Dynamics; // 0x00(0x540)
	struct FEmbarkMovementParamsStatic Statics; // 0x540(0x390)
	struct FVector StartGroundNormal; // 0x8d0(0x18)
	struct FVector StartVelocity; // 0x8e8(0x18)
	struct FVector CalcVelocity; // 0x900(0x18)
	struct FKneeHeightMoveSimulationContext InitialMoveContext; // 0x918(0x358)
	struct FKneeHeightMoveSimulationResult MoveResult; // 0xc70(0x3d8)
	struct TArray<struct FMoveCollisionDebugData> MoveCollisions; // 0x1048(0x10)
	bool bShouldNotUpdate; // 0x1058(0x01)
	enum class EMovementMode FinalMovementMode; // 0x1059(0x01)
	bool bSimulateRootMotion; // 0x105a(0x01)
	char pad_105b[0x5]; // 0x105b(0x05)
};

// ScriptStruct EmbarkMovement.EmbarkRootMotionInputScale
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkRootMotionInputScale {
	float InputScale; // 0x00(0x04)
	float InputScaleSides; // 0x04(0x04)
	float InputScaleFwdBwd; // 0x08(0x04)
};

// ScriptStruct EmbarkMovement.EmbarkMoveModifiers
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkMoveModifiers {
	float Forward; // 0x00(0x04)
	float Right; // 0x04(0x04)
};

// ScriptStruct EmbarkMovement.EmbarkMoveOverrides
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkMoveOverrides {
	float Forward; // 0x00(0x04)
	float Right; // 0x04(0x04)
};

// ScriptStruct EmbarkMovement.VirtualTerrainTraceDynamics
// Size: 0xb0 (Inherited: 0x00)
struct FVirtualTerrainTraceDynamics {
	struct FVector FootLocation; // 0x00(0x18)
	struct FVector GroundNormal; // 0x18(0x18)
	struct FVector InputVector; // 0x30(0x18)
	struct FVector TraceOrigin; // 0x48(0x18)
	struct FVector GravityDir; // 0x60(0x18)
	struct FVector CharacterVelocity; // 0x78(0x18)
	struct TArray<struct AActor*> GroundTraceIgnoredActors; // 0x90(0x10)
	float GroundTraceDistance; // 0xa0(0x04)
	struct FName CollisionProfile; // 0xa4(0x08)
	bool bSimpleTracesWhenNotMoving; // 0xac(0x01)
	bool bSimpleTracesWhenMoving; // 0xad(0x01)
	char pad_ae[0x2]; // 0xae(0x02)
};

// ScriptStruct EmbarkMovement.VirtualTerrainParams
// Size: 0xd0 (Inherited: 0x00)
struct FVirtualTerrainParams {
	struct FVirtualTerrainWalkableThresholds WalkableThresholds; // 0x00(0x0c)
	struct FVirtualTerrainGroundTracerConfig GroundTracerCfg; // 0x0c(0x10)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct FVirtualTerrainTraceDynamics TraceDynamics; // 0x20(0xb0)
};

// ScriptStruct EmbarkMovement.PendulumSequencePair
// Size: 0x10 (Inherited: 0x00)
struct FPendulumSequencePair {
	struct UAnimSequence* AnimSeq_3P; // 0x00(0x08)
	struct UAnimSequence* AnimSeq_1P; // 0x08(0x08)
};

// ScriptStruct EmbarkMovement.PendulumRootMotionSampleResult
// Size: 0x40 (Inherited: 0x00)
struct FPendulumRootMotionSampleResult {
	struct FVector DeltaMove; // 0x00(0x18)
	struct FVector DesiredWarpLocation; // 0x18(0x18)
	float InputScaleSides; // 0x30(0x04)
	float InputScaleFwdBwd; // 0x34(0x04)
	float GoblinMovementGhostMode; // 0x38(0x04)
	bool bIsLastFrame; // 0x3c(0x01)
	char pad_3d[0x3]; // 0x3d(0x03)
};

// ScriptStruct EmbarkMovement.PendulumRootMotionDisplayState
// Size: 0x170 (Inherited: 0x00)
struct FPendulumRootMotionDisplayState {
	struct FEmbarkRootWarpSpace RootWarpSpace; // 0x00(0x140)
	struct FPendulumRootMotionHandle RootMotionHandle; // 0x140(0x02)
	char pad_142[0x6]; // 0x142(0x06)
	struct FPendulumSequencePair AnimSequencePair; // 0x148(0x10)
	float CurrentSamplingTime; // 0x158(0x04)
	float SamplingStartTimeOffset; // 0x15c(0x04)
	bool bClipActive; // 0x160(0x01)
	char pad_161[0xf]; // 0x161(0x0f)
};

