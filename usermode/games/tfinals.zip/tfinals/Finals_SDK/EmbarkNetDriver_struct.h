// Enum EmbarkNetDriver.EEmbarkNetResult
enum class EEmbarkNetResult : uint8_t {
	Unknown = 0,
	Success = 1,
	EEmbarkNetResult_MAX = 2
};

// Enum EmbarkNetDriver.EUnresponsiveConnectionType
enum class EUnresponsiveConnectionType : uint8_t {
	PropertyReplication = 0,
	RPCReplication = 1,
	Both = 2,
	NetworkUnresponsiveFromClient = 3,
	NetworkUnresponsiveFromServer = 4,
	EUnresponsiveConnectionType_MAX = 5
};

// ScriptStruct EmbarkNetDriver.NetworkConnectionInfo
// Size: 0x98 (Inherited: 0x00)
struct FNetworkConnectionInfo {
	char pad_0[0x98]; // 0x00(0x98)
};

