// Class KantanChartsDatasource.KantanCartesianDatasourceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UKantanCartesianDatasourceInterface : UInterface {

	struct FText GetSeriesName(int32_t SeriesIdx); // Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetSeriesName // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6a0d240
	struct FName GetSeriesId(int32_t CatIdx); // Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetSeriesId // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6a0db90
	struct TArray<struct FKantanCartesianDatapoint> GetSeriesDatapoints(int32_t SeriesIdx); // Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetSeriesDatapoints // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6a0bab0
	int32_t GetNumSeries(); // Function KantanChartsDatasource.KantanCartesianDatasourceInterface.GetNumSeries // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2c1da90
};

// Class KantanChartsDatasource.KantanCategoryDatasourceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UKantanCategoryDatasourceInterface : UInterface {

	int32_t GetNumCategories(); // Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetNumCategories // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2c1da90
	float GetCategoryValue(int32_t CatIdx); // Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetCategoryValue // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6a0e450
	struct FText GetCategoryName(int32_t CatIdx); // Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetCategoryName // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6a0d240
	struct FName GetCategoryId(int32_t CatIdx); // Function KantanChartsDatasource.KantanCategoryDatasourceInterface.GetCategoryId // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x6a0db90
};

// Class KantanChartsDatasource.KantanSimpleCartesianDatasource
// Size: 0xc0 (Inherited: 0xa0)
struct UKantanSimpleCartesianDatasource : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)

	struct UKantanSimpleCartesianDatasource* NewSimpleCartesianDatasource(int32_t MaxDatapoints); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.NewSimpleCartesianDatasource // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a0c6b0
	void BP_SetDatapointLimit(int32_t Limit); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_SetDatapointLimit // (Final|Native|Public|BlueprintCallable) // @ game+0x6a11e80
	void BP_RemoveSeries(struct FName ID, bool& bSuccess); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_RemoveSeries // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a0c2f0
	void BP_RemoveAllSeries(); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_RemoveAllSeries // (Final|Native|Public|BlueprintCallable) // @ game+0x6a0ac20
	void BP_AddSeriesWithId(struct FName ID, struct FText Name, bool& bSuccess); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_AddSeriesWithId // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a0aa50
	void BP_AddSeries(struct FText Name, struct FName& SeriesId); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_AddSeries // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a0f180
	void BP_AddDatapoint(struct FName SeriesId, struct FVector2D& Point, bool& bSuccess); // Function KantanChartsDatasource.KantanSimpleCartesianDatasource.BP_AddDatapoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6a0b780
};

// Class KantanChartsDatasource.KantanSimpleCategoryDatasource
// Size: 0xb0 (Inherited: 0xa0)
struct UKantanSimpleCategoryDatasource : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)

	struct UKantanSimpleCategoryDatasource* NewSimpleCategoryDatasource(); // Function KantanChartsDatasource.KantanSimpleCategoryDatasource.NewSimpleCategoryDatasource // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x6a11c20
	void BP_UpdateCategoryValue(struct FName ID, float Value, bool& bSuccess); // Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_UpdateCategoryValue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a0d660
	void BP_RemoveCategory(struct FName ID, bool& bSuccess); // Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_RemoveCategory // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a11450
	void BP_RemoveAllCategories(); // Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_RemoveAllCategories // (Final|Native|Public|BlueprintCallable) // @ game+0x6a0c030
	void BP_AddCategoryWithId(struct FName ID, struct FText Name, bool& bSuccess); // Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_AddCategoryWithId // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a0b8e0
	void BP_AddCategory(struct FText Name, struct FName& CatId); // Function KantanChartsDatasource.KantanSimpleCategoryDatasource.BP_AddCategory // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a11630
};

