// Class Renderer.SparseVolumeTextureViewerComponent
// Size: 0x700 (Inherited: 0x6c0)
struct USparseVolumeTextureViewerComponent : UPrimitiveComponent {
	struct USparseVolumeTexture* SparseVolumeTexturePreview; // 0x6b8(0x08)
	char bAnimate : 1; // 0x6c0(0x01)
	char bReversePlayback : 1; // 0x6c0(0x01)
	char bBlockingStreamingRequests : 1; // 0x6c0(0x01)
	float AnimationFrame; // 0x6c4(0x04)
	float FrameRate; // 0x6c8(0x04)
	float AnimationTime; // 0x6cc(0x04)
	enum class ESparseVolumeTexturePreviewAttribute PreviewAttribute; // 0x6d0(0x01)
	int32_t MipLevel; // 0x6d4(0x04)
	float Extinction; // 0x6d8(0x04)
	char pad_6dd_3 : 5; // 0x6dd(0x01)
	char pad_6de[0x22]; // 0x6de(0x22)
};

// Class Renderer.SparseVolumeTextureViewer
// Size: 0x3a0 (Inherited: 0x3a0)
struct ASparseVolumeTextureViewer : AInfo {
	struct USparseVolumeTextureViewerComponent* SparseVolumeTextureViewerComponent; // 0x398(0x08)
};

