// Class SMExtendedRuntime.SMExtendedGraphPropertyHelpers
// Size: 0xa0 (Inherited: 0xa0)
struct USMExtendedGraphPropertyHelpers : UBlueprintFunctionLibrary {

	struct FText ObjectToText(struct UObject* InObject, struct FName InFunctionName); // Function SMExtendedRuntime.SMExtendedGraphPropertyHelpers.ObjectToText // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8ecf880
	void BreakTextGraphProperty(struct FSMTextGraphProperty& GraphProperty, struct FText& Result); // Function SMExtendedRuntime.SMExtendedGraphPropertyHelpers.BreakTextGraphProperty // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x8ecef40
};

