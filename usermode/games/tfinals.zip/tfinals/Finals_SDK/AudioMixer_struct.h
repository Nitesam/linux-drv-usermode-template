// Enum AudioMixer.EAudioDeviceChangedRole
enum class EAudioDeviceChangedRole : uint8_t {
	Invalid = 0,
	Console = 1,
	Multimedia = 2,
	Communications = 3,
	Count = 4,
	EAudioDeviceChangedRole_MAX = 5
};

// Enum AudioMixer.EAudioDeviceChangedState
enum class EAudioDeviceChangedState : uint8_t {
	Invalid = 0,
	Active = 1,
	Disabled = 2,
	NotPresent = 3,
	Unplugged = 4,
	Count = 5,
	EAudioDeviceChangedState_MAX = 6
};

// Enum AudioMixer.EAudioMixerChannelType
enum class EAudioMixerChannelType : uint8_t {
	FrontLeft = 0,
	FrontRight = 1,
	FrontCenter = 2,
	LowFrequency = 3,
	BackLeft = 4,
	BackRight = 5,
	FrontLeftOfCenter = 6,
	FrontRightOfCenter = 7,
	BackCenter = 8,
	SideLeft = 9,
	SideRight = 10,
	TopCenter = 11,
	TopFrontLeft = 12,
	TopFrontCenter = 13,
	TopFrontRight = 14,
	TopBackLeft = 15,
	TopBackCenter = 16,
	TopBackRight = 17,
	Unknown = 18,
	ChannelTypeCount = 19,
	DefaultChannel = 0,
	EAudioMixerChannelType_MAX = 20
};

// Enum AudioMixer.EAudioMixerStreamDataFormatType
enum class EAudioMixerStreamDataFormatType : uint8_t {
	Unknown = 0,
	Float = 1,
	Int16 = 2,
	Unsupported = 3,
	EAudioMixerStreamDataFormatType_MAX = 4
};

// Enum AudioMixer.ESwapAudioOutputDeviceResultState
enum class ESwapAudioOutputDeviceResultState : uint8_t {
	Failure = 0,
	Success = 1,
	None = 2,
	ESwapAudioOutputDeviceResultState_MAX = 3
};

// Enum AudioMixer.ESourceManagerRenderThreadPhase
enum class ESourceManagerRenderThreadPhase : uint8_t {
	Begin = 0,
	PumpMpscCmds = 1,
	PumpCmds = 2,
	ProcessModulators = 3,
	UpdatePendingReleaseData = 4,
	GenerateSrcAudio_WithBusses = 5,
	ComputeBusses = 6,
	GenerateSrcAudio_WithoutBusses = 7,
	UpdateBusses = 8,
	SpatialInterface_OnAllSourcesProcessed = 9,
	SourceDataOverride_OnAllSourcesProcessed = 10,
	UpdateGameThreadCopies = 11,
	Finished = 12,
	ESourceManagerRenderThreadPhase_MAX = 13
};

// Enum AudioMixer.EMusicalNoteName
enum class EMusicalNoteName : uint8_t {
	C = 0,
	Db = 1,
	D = 2,
	Eb = 3,
	E = 4,
	F = 5,
	Gb = 6,
	G = 7,
	Ab = 8,
	A = 9,
	Bb = 10,
	B = 11,
	EMusicalNoteName_MAX = 12
};

// Enum AudioMixer.ESubmixEffectDynamicsProcessorType
enum class ESubmixEffectDynamicsProcessorType : uint8_t {
	Compressor = 0,
	Limiter = 1,
	Expander = 2,
	Gate = 3,
	UpwardsCompressor = 4,
	Count = 5,
	ESubmixEffectDynamicsProcessorType_MAX = 6
};

// Enum AudioMixer.ESubmixEffectDynamicsPeakMode
enum class ESubmixEffectDynamicsPeakMode : uint8_t {
	MeanSquared = 0,
	RootMeanSquared = 1,
	Peak = 2,
	Count = 3,
	ESubmixEffectDynamicsPeakMode_MAX = 4
};

// Enum AudioMixer.ESubmixEffectDynamicsChannelLinkMode
enum class ESubmixEffectDynamicsChannelLinkMode : uint8_t {
	Disabled = 0,
	Average = 1,
	Peak = 2,
	Count = 3,
	ESubmixEffectDynamicsChannelLinkMode_MAX = 4
};

// Enum AudioMixer.ESubmixEffectDynamicsKeySource
enum class ESubmixEffectDynamicsKeySource : uint8_t {
	Default = 0,
	AudioBus = 1,
	Submix = 2,
	Count = 3,
	ESubmixEffectDynamicsKeySource_MAX = 4
};

// ScriptStruct AudioMixer.AudioOutputDeviceInfo
// Size: 0x48 (Inherited: 0x00)
struct FAudioOutputDeviceInfo {
	struct FString Name; // 0x00(0x10)
	struct FString DeviceID; // 0x10(0x10)
	int32_t NumChannels; // 0x20(0x04)
	int32_t SampleRate; // 0x24(0x04)
	enum class EAudioMixerStreamDataFormatType Format; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct TArray<enum class EAudioMixerChannelType> OutputChannelArray; // 0x30(0x10)
	char bIsSystemDefault : 1; // 0x40(0x01)
	char bIsCurrentDevice : 1; // 0x40(0x01)
	char pad_40_2 : 6; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct AudioMixer.SwapAudioOutputResult
// Size: 0x28 (Inherited: 0x00)
struct FSwapAudioOutputResult {
	struct FString CurrentDeviceId; // 0x00(0x10)
	struct FString RequestedDeviceId; // 0x10(0x10)
	enum class ESwapAudioOutputDeviceResultState Result; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct AudioMixer.SubmixEffectDynamicProcessorFilterSettings
// Size: 0x0c (Inherited: 0x00)
struct FSubmixEffectDynamicProcessorFilterSettings {
	char bEnabled : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Cutoff; // 0x04(0x04)
	float GainDb; // 0x08(0x04)
};

// ScriptStruct AudioMixer.SubmixEffectDynamicsProcessorSettings
// Size: 0x60 (Inherited: 0x00)
struct FSubmixEffectDynamicsProcessorSettings {
	enum class ESubmixEffectDynamicsProcessorType DynamicsProcessorType; // 0x00(0x01)
	enum class ESubmixEffectDynamicsPeakMode PeakMode; // 0x01(0x01)
	enum class ESubmixEffectDynamicsChannelLinkMode LinkMode; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	float InputGainDb; // 0x04(0x04)
	float ThresholdDb; // 0x08(0x04)
	float Ratio; // 0x0c(0x04)
	float KneeBandwidthDb; // 0x10(0x04)
	float LookAheadMsec; // 0x14(0x04)
	float AttackTimeMsec; // 0x18(0x04)
	float ReleaseTimeMsec; // 0x1c(0x04)
	enum class ESubmixEffectDynamicsKeySource KeySource; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct UAudioBus* ExternalAudioBus; // 0x28(0x08)
	struct USoundSubmix* ExternalSubmix; // 0x30(0x08)
	char bChannelLinked : 1; // 0x38(0x01)
	char bAnalogMode : 1; // 0x38(0x01)
	char bBypass : 1; // 0x38(0x01)
	char bKeyAudition : 1; // 0x38(0x01)
	char pad_38_4 : 4; // 0x38(0x01)
	char pad_39[0x3]; // 0x39(0x03)
	float KeyGainDb; // 0x3c(0x04)
	float OutputGainDb; // 0x40(0x04)
	struct FSubmixEffectDynamicProcessorFilterSettings KeyHighshelf; // 0x44(0x0c)
	struct FSubmixEffectDynamicProcessorFilterSettings KeyLowshelf; // 0x50(0x0c)
	char pad_5c[0x4]; // 0x5c(0x04)
};

// ScriptStruct AudioMixer.SubmixEffectEQBand
// Size: 0x10 (Inherited: 0x00)
struct FSubmixEffectEQBand {
	float Frequency; // 0x00(0x04)
	float Bandwidth; // 0x04(0x04)
	float GainDb; // 0x08(0x04)
	char bEnabled : 1; // 0x0c(0x01)
	char pad_c_1 : 7; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
};

// ScriptStruct AudioMixer.SubmixEffectSubmixEQSettings
// Size: 0x10 (Inherited: 0x00)
struct FSubmixEffectSubmixEQSettings {
	struct TArray<struct FSubmixEffectEQBand> EQBands; // 0x00(0x10)
};

// ScriptStruct AudioMixer.SubmixEffectReverbSettings
// Size: 0x40 (Inherited: 0x00)
struct FSubmixEffectReverbSettings {
	bool bBypassEarlyReflections; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ReflectionsDelay; // 0x04(0x04)
	float GainHF; // 0x08(0x04)
	float ReflectionsGain; // 0x0c(0x04)
	bool bBypassLateReflections; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float LateDelay; // 0x14(0x04)
	float DecayTime; // 0x18(0x04)
	float Density; // 0x1c(0x04)
	float Diffusion; // 0x20(0x04)
	float AirAbsorptionGainHF; // 0x24(0x04)
	float DecayHFRatio; // 0x28(0x04)
	float LateGain; // 0x2c(0x04)
	float Gain; // 0x30(0x04)
	float WetLevel; // 0x34(0x04)
	float DryLevel; // 0x38(0x04)
	bool bBypass; // 0x3c(0x01)
	char pad_3d[0x3]; // 0x3d(0x03)
};

