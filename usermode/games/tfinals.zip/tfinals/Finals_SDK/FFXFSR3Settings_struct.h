// Enum FFXFSR3Settings.EFFXFSR3QualityMode
enum class EFFXFSR3QualityMode : uint8_t {
	NativeAA = 0,
	Quality = 1,
	Balanced = 2,
	Performance = 3,
	UltraPerformance = 4,
	EFFXFSR3QualityMode_MAX = 5
};

// Enum FFXFSR3Settings.EFFXFSR3HistoryFormat
enum class EFFXFSR3HistoryFormat : uint8_t {
	FloatRGBA = 0,
	FloatR11G11B10 = 1,
	EFFXFSR3HistoryFormat_MAX = 2
};

// Enum FFXFSR3Settings.EFFXFSR3DeDitherMode
enum class EFFXFSR3DeDitherMode : uint8_t {
	Off = 0,
	Full = 1,
	HairOnly = 2,
	EFFXFSR3DeDitherMode_MAX = 3
};

// Enum FFXFSR3Settings.EFFXFSR3LandscapeHISMMode
enum class EFFXFSR3LandscapeHISMMode : uint8_t {
	Off = 0,
	AllStatic = 1,
	StaticWPO = 2,
	EFFXFSR3LandscapeHISMMode_MAX = 3
};

// Enum FFXFSR3Settings.EFFXFSR3FrameGenUIMode
enum class EFFXFSR3FrameGenUIMode : uint8_t {
	SlateRedraw = 0,
	UIExtraction = 1,
	EFFXFSR3FrameGenUIMode_MAX = 2
};

// Enum FFXFSR3Settings.EFFXFSR3PaceRHIFrameMode
enum class EFFXFSR3PaceRHIFrameMode : uint8_t {
	None = 0,
	CustomPresentVSync = 1,
	EFFXFSR3PaceRHIFrameMode_MAX = 2
};

