// Enum EmbarkFire.EEmbarkFireObjectType
enum class EEmbarkFireObjectType : uint8_t {
	Disabled = 0,
	Burnable = 1,
	HeatModifier = 2,
	Count = 3,
	EEmbarkFireObjectType_MAX = 4
};

// Enum EmbarkFire.EEmbarkFireBurnableGroupType
enum class EEmbarkFireBurnableGroupType : uint8_t {
	Player = 0,
	GameplayObjects = 1,
	Environment = 2,
	EEmbarkFireBurnableGroupType_MAX = 3
};

// Enum EmbarkFire.EEmbarkFireHeatModifierBehavior
enum class EEmbarkFireHeatModifierBehavior : uint8_t {
	ConstantHeat = 0,
	Extinguish = 1,
	Ignite = 2,
	MaxHeat = 3,
	EEmbarkFireHeatModifierBehavior_MAX = 4
};

// Enum EmbarkFire.EEmbarkFireObjectRepresentation
enum class EEmbarkFireObjectRepresentation : uint8_t {
	None = 0,
	SceneComponent = 1,
	Sphere = 2,
	EEmbarkFireObjectRepresentation_MAX = 3
};

// ScriptStruct EmbarkFire.EmbarkFireOnStateChangedData
// Size: 0x58 (Inherited: 0x00)
struct FEmbarkFireOnStateChangedData {
	struct FEmbarkFireObjectHandle Handle; // 0x00(0x04)
	bool bIsBurning; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FInstigator Instigator; // 0x08(0x50)
};

// ScriptStruct EmbarkFire.EmbarkFireObjectHandle
// Size: 0x04 (Inherited: 0x00)
struct FEmbarkFireObjectHandle {
	int32_t Index; // 0x00(0x04)
};

// ScriptStruct EmbarkFire.EmbarkFireStateChangedDataClient
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkFireStateChangedDataClient {
	struct USceneComponent* Component; // 0x00(0x08)
	struct FName BoneName; // 0x08(0x08)
	bool bIsBurning; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkFire.ReplicatedEmbarkFireStateItem
// Size: 0x24 (Inherited: 0x0c)
struct FReplicatedEmbarkFireStateItem : FFastArraySerializerItem {
	struct TWeakObjectPtr<struct USceneComponent> Component; // 0x0c(0x08)
	struct FName BoneName; // 0x14(0x08)
	struct FEmbarkFireObjectHandle Handle; // 0x1c(0x04)
	enum class EPhysicalSurface PhysicalSurface; // 0x20(0x01)
	bool bIsBurning; // 0x21(0x01)
	char pad_22[0x2]; // 0x22(0x02)
};

// ScriptStruct EmbarkFire.ReplicatedEmbarkFireStateFastArray
// Size: 0x178 (Inherited: 0x110)
struct FReplicatedEmbarkFireStateFastArray : FFastArraySerializer {
	struct TArray<struct FReplicatedEmbarkFireStateItem> Items; // 0x110(0x10)
	struct AEmbarkFireReplicationActor* FireReplicationActor; // 0x120(0x08)
	char pad_128[0x50]; // 0x128(0x50)
};

// ScriptStruct EmbarkFire.EmbarkFireSurfaceEffectSettings
// Size: 0xc8 (Inherited: 0x00)
struct FEmbarkFireSurfaceEffectSettings {
	struct FEmbarkFXParticleParams ParticleSettings; // 0x00(0x18)
	struct FEmbarkFXAudioParams SoundSettings; // 0x18(0x58)
	struct FEmbarkFXDecalParams DecalSettings; // 0x70(0x58)
};

// ScriptStruct EmbarkFire.EmbarkFireBurnableHeatLimitSetting
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkFireBurnableHeatLimitSetting {
	struct FGameplayTag SourceTagToLimitHeatFrom; // 0x00(0x08)
	float MaxHeatAddedPerSecondBySourceTag; // 0x08(0x04)
};

// ScriptStruct EmbarkFire.EmbarkFireHeatTransferAreaSettings
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkFireHeatTransferAreaSettings {
	float Radius; // 0x00(0x04)
	float Lifetime; // 0x04(0x04)
};

// ScriptStruct EmbarkFire.EmbarkFireBurnableSettings
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkFireBurnableSettings {
	float HeatRecipientBoundsModifier; // 0x00(0x04)
	enum class EEmbarkFireBurnableGroupType GroupType; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	float StartingHeat; // 0x08(0x04)
	float IgnitionPoint; // 0x0c(0x04)
	float MaxHeat; // 0x10(0x04)
	float HeatToAddWhileIgnitedPerSecond; // 0x14(0x04)
	float HeatDecayPerSecond; // 0x18(0x04)
	bool bLimitAmountOfHeatToAddPerSecondBySourceTag; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
	struct FEmbarkFireBurnableHeatLimitSetting HeatLimitSettings; // 0x20(0x0c)
	float StartingFuel; // 0x2c(0x04)
	float FuelDepletionPerSecond; // 0x30(0x04)
	bool bUseDefaultFireFXWhenIgnited; // 0x34(0x01)
	enum class EPhysicalSurface PhysicalSurface; // 0x35(0x01)
	bool bRequiresHeatTransferAreaToSpreadHeat; // 0x36(0x01)
	char pad_37[0x1]; // 0x37(0x01)
};

// ScriptStruct EmbarkFire.EmbarkFireHeatModifierSettings
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkFireHeatModifierSettings {
	enum class EEmbarkFireHeatModifierBehavior HeatModifierBehavior; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Heat; // 0x04(0x04)
	float Lifetime; // 0x08(0x04)
};

// ScriptStruct EmbarkFire.EmbarkFireObjectSettings
// Size: 0x68 (Inherited: 0x00)
struct FEmbarkFireObjectSettings {
	enum class EEmbarkFireObjectType ObjectType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FGameplayTag SourceTag; // 0x04(0x08)
	float HeatTransferBoundsModifier; // 0x0c(0x04)
	bool bScaleHeatTransferBoundsModifier; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	struct FEmbarkFireBurnableSettings BurnableSettings; // 0x14(0x38)
	struct FEmbarkFireHeatModifierSettings HeatModifierSettings; // 0x4c(0x0c)
	float DamagePerSecondWhileOnFire; // 0x58(0x04)
	bool bSpawnHeatTransferArea; // 0x5c(0x01)
	char pad_5d[0x3]; // 0x5d(0x03)
	struct FEmbarkFireHeatTransferAreaSettings HeatTransferAreaSettings; // 0x60(0x08)
};

// ScriptStruct EmbarkFire.EmbarkFireLocationUpdate
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkFireLocationUpdate {
	struct FEmbarkFireObjectHandle Handle; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector NewLocation; // 0x08(0x18)
};

// ScriptStruct EmbarkFire.EmbarkFireObjectSphereData
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkFireObjectSphereData {
	struct FVector Location; // 0x00(0x18)
	float Scale; // 0x18(0x04)
	float Radius; // 0x1c(0x04)
	struct TWeakObjectPtr<struct USceneComponent> AssociatedComponent; // 0x20(0x08)
	struct FName BoneName; // 0x28(0x08)
};

// ScriptStruct EmbarkFire.EmbarkFireObjectStateInitData
// Size: 0x108 (Inherited: 0x00)
struct FEmbarkFireObjectStateInitData {
	enum class EEmbarkFireObjectRepresentation ObjectRepresentation; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct USceneComponent* Component; // 0x08(0x08)
	struct FEmbarkFireObjectSphereData SphereData; // 0x10(0x30)
	struct FEmbarkFireObjectSettings Settings; // 0x40(0x68)
	struct FDelegate OnStateChangedCallback; // 0xa8(0x10)
	struct FInstigator SpawnInstigator; // 0xb8(0x50)
};

// ScriptStruct EmbarkFire.EmbarkFireObjectState
// Size: 0x138 (Inherited: 0x00)
struct FEmbarkFireObjectState {
	char pad_0[0x138]; // 0x00(0x138)
};

// ScriptStruct EmbarkFire.EmbarkFireHeatTransferAreaState
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkFireHeatTransferAreaState {
	char pad_0[0x28]; // 0x00(0x28)
};

