// Class EmbarkUtils.EmbarkClassUtilsFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkClassUtilsFunctionLibrary : UBlueprintFunctionLibrary {

	struct TArray<struct UObject*> GetSubclassesOf(struct UObject* ParentClass); // Function EmbarkUtils.EmbarkClassUtilsFunctionLibrary.GetSubclassesOf // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5193b50
};

// Class EmbarkUtils.EmbarkConsoleCommandMacroFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkConsoleCommandMacroFunctionLibrary : UBlueprintFunctionLibrary {

	struct TArray<struct FString> StopRecordingMacro(struct UObject* WorldContextObject); // Function EmbarkUtils.EmbarkConsoleCommandMacroFunctionLibrary.StopRecordingMacro // (Final|Native|Static|Public) // @ game+0x51992c0
	void StartRecordingMacro(struct UObject* WorldContextObject); // Function EmbarkUtils.EmbarkConsoleCommandMacroFunctionLibrary.StartRecordingMacro // (Final|Native|Static|Public) // @ game+0x519dd70
	void PlayMacro(struct UObject* WorldContextObject, struct TArray<struct FString>& Commands, struct APlayerController* SpecificPlayer); // Function EmbarkUtils.EmbarkConsoleCommandMacroFunctionLibrary.PlayMacro // (Final|Native|Static|Public|HasOutParms) // @ game+0x5196000
};

// Class EmbarkUtils.EmbarkDebugUtilsFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDebugUtilsFunctionLibrary : UBlueprintFunctionLibrary {

	void DrawDebugSphere(struct UObject* WorldContextObject, struct FVector Center, float Radius, int32_t Segments, struct FLinearColor SphereColor, float Duration, float Thickness); // Function EmbarkUtils.EmbarkDebugUtilsFunctionLibrary.DrawDebugSphere // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5194940
	void DrawDebugLine(struct UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, float DrawTime, float Thickness, struct FLinearColor Color); // Function EmbarkUtils.EmbarkDebugUtilsFunctionLibrary.DrawDebugLine // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5193120
	void DrawDebugBox(struct UObject* WorldContextObject, struct FVector Center, struct FVector Extent, struct FQuat& Rotation, float DrawTime, float Thickness, struct FLinearColor Color); // Function EmbarkUtils.EmbarkDebugUtilsFunctionLibrary.DrawDebugBox // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x519c310
	void DrawDebugArrow(struct UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, float DrawTime, float Thickness, struct FLinearColor Color); // Function EmbarkUtils.EmbarkDebugUtilsFunctionLibrary.DrawDebugArrow // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5193120
};

// Class EmbarkUtils.EmbarkEnumUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkEnumUtils : UBlueprintFunctionLibrary {

	int32_t StringToEnumIdx(struct FString EnumName, struct FString Value); // Function EmbarkUtils.EmbarkEnumUtils.StringToEnumIdx // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5196410
	int32_t GetEnumValueByIndex(struct FString EnumName, int32_t Index); // Function EmbarkUtils.EmbarkEnumUtils.GetEnumValueByIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5191040
	int32_t GetEnumCount(struct FString EnumName); // Function EmbarkUtils.EmbarkEnumUtils.GetEnumCount // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5195090
	struct TArray<struct FString> GetAllEnumValueNames(struct FString EnumName); // Function EmbarkUtils.EmbarkEnumUtils.GetAllEnumValueNames // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5196fd0
	struct FString EnumValueToString(struct FString EnumName, int64_t Value); // Function EmbarkUtils.EmbarkEnumUtils.EnumValueToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5190db0
	struct FString EnumToString(struct FString EnumName, int32_t Value); // Function EmbarkUtils.EmbarkEnumUtils.EnumToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5199900
	struct FString EnumIndexToString(struct FString EnumName, int32_t Index); // Function EmbarkUtils.EmbarkEnumUtils.EnumIndexToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x519b690
};

// Class EmbarkUtils.EmbarkOctreeDataHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkOctreeDataHandleMixinLibrary : UObject {

	bool IsValid(struct FEmbarkOctreeDataHandle& Handle); // Function EmbarkUtils.EmbarkOctreeDataHandleMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x519cd00
};

// Class EmbarkUtils.EmbarkGenericOctreeMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkGenericOctreeMixinLibrary : UObject {

	void UpdateNode(struct FEmbarkGenericOctree& Octree, struct FEmbarkOctreeDataHandle& ID, struct FBoxSphereBounds NewBounds); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.UpdateNode // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51996a0
	void RemoveNode(struct FEmbarkGenericOctree& Octree, struct FEmbarkOctreeDataHandle& ID); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.RemoveNode // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5191250
	bool IsInitialized(struct FEmbarkGenericOctree& Octree); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.IsInitialized // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5199a90
	void Initialize(struct FEmbarkGenericOctree& Octree, struct FBox& Bounds); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.Initialize // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51908c0
	void FindNearbyElements(struct FEmbarkGenericOctree& Octree, struct FVector& Position, struct FDelegate IterateBoundsFunc); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.FindNearbyElements // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5195e20
	void FindFirstElementWithBoundsTest(struct FEmbarkGenericOctree& Octree, struct FBox& BoxBounds, struct FDelegate IterateBoundsFunc); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.FindFirstElementWithBoundsTest // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5196ac0
	void FindElementsWithBoundsTest(struct FEmbarkGenericOctree& Octree, struct FBox& BoxBounds, struct FDelegate IterateBoundsFunc); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.FindElementsWithBoundsTest // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5198480
	struct TArray<struct FEmbarkOctreeDataHandle> FindElements(struct FEmbarkGenericOctree& Octree, struct FBox& BoxBounds); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.FindElements // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x519b290
	void DebugDrawOctree(struct FEmbarkGenericOctree& Octree, struct UWorld* World); // Function EmbarkUtils.EmbarkGenericOctreeMixinLibrary.DebugDrawOctree // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x519bed0
};

// Class EmbarkUtils.EmbarkHardwareBreakpointSubsystem
// Size: 0x110 (Inherited: 0xb0)
struct UEmbarkHardwareBreakpointSubsystem : UTickableWorldSubsystem {
	struct FMulticastInlineDelegate OnHardwareBreakpointChanged; // 0xb0(0x10)
	char pad_c0[0x50]; // 0xc0(0x50)

	void SetTriggerVSBreakpoint(bool bEnable); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.SetTriggerVSBreakpoint // (Final|Native|Public) // @ game+0x5193460
	bool GetTriggerVSBreakpoint(); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.GetTriggerVSBreakpoint // (Final|Native|Public|Const) // @ game+0x5198790
	bool FindHardwareBreakpointForProperty(struct UObject* Obj, struct FString PropertyName, struct FEmbarkHardwareBreakpointInfo& OutBreakpointInfo); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.FindHardwareBreakpointForProperty // (Final|Native|Public|HasOutParms) // @ game+0x519d8c0
	bool DoesPropertySupportTriggerCondition(struct UObject* Obj, struct FString PropertyName); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.DoesPropertySupportTriggerCondition // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x51922d0
	bool DoesPropertySupportHardwareBreakpoint(struct UObject* Obj, struct FString PropertyName); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.DoesPropertySupportHardwareBreakpoint // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x519cb90
	bool ClearHardwareBreakpoint(int32_t DebugRegisterToClear); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.ClearHardwareBreakpoint // (Final|Native|Public) // @ game+0x51971f0
	void ClearAllHardwareBreakpoints(); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.ClearAllHardwareBreakpoints // (Final|Native|Public) // @ game+0x33aadf0
	int32_t AddHardwareBreakpointForProperty(struct UObject* Obj, struct FString PropertyName, int32_t TriggersUntilDisable, enum class EEmbarkHardwareBreakpointTypes BreakpointType, enum class EEmbarkHardwareBreakpointConditions TriggerCondition, int64_t TriggerConditionValue); // Function EmbarkUtils.EmbarkHardwareBreakpointSubsystem.AddHardwareBreakpointForProperty // (Final|Native|Public) // @ game+0x51952b0
};

// Class EmbarkUtils.EditorOutputLogRedirectSubsystem
// Size: 0xe0 (Inherited: 0xa0)
struct UEditorOutputLogRedirectSubsystem : UEngineSubsystem {
	char pad_a0[0x40]; // 0xa0(0x40)

	void UnregisterLogDelegate(struct UObject* Object); // Function EmbarkUtils.EditorOutputLogRedirectSubsystem.UnregisterLogDelegate // (Final|Native|Public) // @ game+0x5199220
	void RegisterLogDelegate(struct UObject* Object, struct FName& FunctionName); // Function EmbarkUtils.EditorOutputLogRedirectSubsystem.RegisterLogDelegate // (Final|Native|Public|HasOutParms) // @ game+0x519c110
	void BP_Flush(); // Function EmbarkUtils.EditorOutputLogRedirectSubsystem.BP_Flush // (Final|Native|Public) // @ game+0x519c2b0
};

// Class EmbarkUtils.EmbarkLogSpamSubsystem
// Size: 0x100 (Inherited: 0xb0)
struct UEmbarkLogSpamSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x50]; // 0xb0(0x50)

	void Log(struct UObject* CallingOwner, struct FName& CategoryName, enum class EEmbarkLogVerbosity Verbosity, struct FString Text); // Function EmbarkUtils.EmbarkLogSpamSubsystem.Log // (Final|Native|Static|Public|HasOutParms) // @ game+0x5199410
};

// Class EmbarkUtils.FMathUtilsFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFMathUtilsFunctionLibrary : UBlueprintFunctionLibrary {

	bool TraceBallisticPath(struct UObject* WorldContextObject, struct FEmbarkBallisticTraceInput& InputData, struct TArray<struct FVector>& OutTracedPath, struct FHitResult& OutHitResult); // Function EmbarkUtils.FMathUtilsFunctionLibrary.TraceBallisticPath // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5193f00
	struct FVector SlerpVector(struct FVector& Start, struct FVector& End, float Alpha); // Function EmbarkUtils.FMathUtilsFunctionLibrary.SlerpVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5191550
	float SampleProbabilityDensityFunction(struct UCurveFloat* ProbabilityDensityFunction, int32_t NumberOfSamples); // Function EmbarkUtils.FMathUtilsFunctionLibrary.SampleProbabilityDensityFunction // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5191150
	struct FVector RotationsToAngularVelocity(struct FQuat& PrevRotation, struct FQuat& NewRotation, double DeltaSeconds); // Function EmbarkUtils.FMathUtilsFunctionLibrary.RotationsToAngularVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x519de50
	struct FVector RotationalDeltaToAngularVelocity(struct FQuat& DeltaRotation, double DeltaSeconds); // Function EmbarkUtils.FMathUtilsFunctionLibrary.RotationalDeltaToAngularVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5190a80
	struct FVector ProjectVectorOnPlane(struct FVector& Vec, struct FVector& GroundNormal, struct FVector& UpVector); // Function EmbarkUtils.FMathUtilsFunctionLibrary.ProjectVectorOnPlane // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x519b940
	void ProjectOrientedBox(struct FOrientedBox& Box, struct FVector ProjectionAxis, float& Min, float& Max); // Function EmbarkUtils.FMathUtilsFunctionLibrary.ProjectOrientedBox // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5194330
	void PredictBallistics_SpeedToDirection_Simple(struct FEmbarkBallisticPredictionInput& InputData, struct FEmbarkBallisticPredictionOutput& OutputData); // Function EmbarkUtils.FMathUtilsFunctionLibrary.PredictBallistics_SpeedToDirection_Simple // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x519ab00
	bool PredictBallistics_SpeedToDirection_Complex(struct FEmbarkBallisticPredictionInput& InputData, struct TArray<struct FEmbarkBallisticPredictionOutput>& Results); // Function EmbarkUtils.FMathUtilsFunctionLibrary.PredictBallistics_SpeedToDirection_Complex // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5193c30
	bool PredictBallistics_SpeedToDirection_Basic(struct FEmbarkBallisticPredictionInput& InputData, struct TArray<struct FEmbarkBallisticPredictionOutput>& Results); // Function EmbarkUtils.FMathUtilsFunctionLibrary.PredictBallistics_SpeedToDirection_Basic // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5197500
	double MinimumJerkTrajectory(double& CurrentValue, double& CurrentSpeed, double& CurrentAcc, double TargetValue, double TargetSpeed, double TargetAcc, double TimeLeft, double DeltaTime); // Function EmbarkUtils.FMathUtilsFunctionLibrary.MinimumJerkTrajectory // (Final|Native|Static|Public|HasOutParms) // @ game+0x5197af0
	bool LineLineIntersect(struct FVector2D& L1Start, struct FVector2D& L1End, struct FVector2D& L2Start, struct FVector2D& L2End, struct FVector2D& OutIntersect, double Tolerance); // Function EmbarkUtils.FMathUtilsFunctionLibrary.LineLineIntersect // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x519bc70
	uint32_t HashCombine(uint32_t A, uint32_t B); // Function EmbarkUtils.FMathUtilsFunctionLibrary.HashCombine // (Final|Native|Static|Public) // @ game+0x5199cf0
	struct FVector GetLinearVelocityAtPoint(struct FVector& SpaceLoc, struct FVector& SpaceLinVel, struct FVector& SpaceAngVel, struct FVector& Point); // Function EmbarkUtils.FMathUtilsFunctionLibrary.GetLinearVelocityAtPoint // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x519d160
	void GetClosestPointsBetweenSegmentedLines(struct FVector& Start1, struct FVector& End1, struct FVector& Start2, struct FVector& End2, struct FVector& OutPoint1, struct FVector& OutPoint2); // Function EmbarkUtils.FMathUtilsFunctionLibrary.GetClosestPointsBetweenSegmentedLines // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5197870
	struct FVector GetClosestPointInList(struct TArray<struct FVector>& PointList, struct FVector& Point); // Function EmbarkUtils.FMathUtilsFunctionLibrary.GetClosestPointInList // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x519ef60
	float FastSin3(float X); // Function EmbarkUtils.FMathUtilsFunctionLibrary.FastSin3 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5196db0
	float FastSin2(float X); // Function EmbarkUtils.FMathUtilsFunctionLibrary.FastSin2 // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x519a120
	float FastSin(float X); // Function EmbarkUtils.FMathUtilsFunctionLibrary.FastSin // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x519e550
	int32_t CalculateWindingNumber2D(struct TArray<struct FVector>& Polygon, struct FVector& Point); // Function EmbarkUtils.FMathUtilsFunctionLibrary.CalculateWindingNumber2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5192a30
	float AlphaToBlendOption(float InAlpha, enum class EAlphaBlendOption InBlendOption, struct UCurveFloat* InCustomCurve); // Function EmbarkUtils.FMathUtilsFunctionLibrary.AlphaToBlendOption // (Final|Native|Static|Public) // @ game+0x51947a0
};

// Class EmbarkUtils.FloatModifierOverrideListMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFloatModifierOverrideListMixinLibrary : UObject {

	bool RemoveOverride(struct FFloatModifierOverrideList& OverrideList, int32_t& Handle); // Function EmbarkUtils.FloatModifierOverrideListMixinLibrary.RemoveOverride // (Final|Native|Static|Public|HasOutParms) // @ game+0x51972a0
	float GetValueClosestTo(struct FFloatModifierOverrideList& OverrideList, float TargetValue); // Function EmbarkUtils.FloatModifierOverrideListMixinLibrary.GetValueClosestTo // (Final|Native|Static|Public|HasOutParms) // @ game+0x5196180
	float GetLowestValue(struct FFloatModifierOverrideList& OverrideList); // Function EmbarkUtils.FloatModifierOverrideListMixinLibrary.GetLowestValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5190460
	float GetHighestValue(struct FFloatModifierOverrideList& OverrideList); // Function EmbarkUtils.FloatModifierOverrideListMixinLibrary.GetHighestValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5196820
	bool ChangeOverride(struct FFloatModifierOverrideList& OverrideList, int32_t Handle, float NewValue); // Function EmbarkUtils.FloatModifierOverrideListMixinLibrary.ChangeOverride // (Final|Native|Static|Public|HasOutParms) // @ game+0x519db10
	int32_t AddOverride(struct FFloatModifierOverrideList& OverrideList, float Value); // Function EmbarkUtils.FloatModifierOverrideListMixinLibrary.AddOverride // (Final|Native|Static|Public|HasOutParms) // @ game+0x519ceb0
};

// Class EmbarkUtils.EmbarkMeshMergeFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkMeshMergeFunctionLibrary : UBlueprintFunctionLibrary {

	struct USkeletalMesh* MergeMeshes(struct FEmbarkMeshMergeDesc& MergeDesc, bool bWaitUntilComplete, struct UObject* CallbackObject, struct FName CallbackFunction, int32_t CallbackUserData); // Function EmbarkUtils.EmbarkMeshMergeFunctionLibrary.MergeMeshes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51a50a0
	struct USkeletalMesh* MergeAttachedStaticMeshes(struct FEmbarkMeshMergeDesc& MergeDesc, bool bWaitUntilComplete, struct UObject* CallbackObject, struct FName CallbackFunction, int32_t CallbackUserData); // Function EmbarkUtils.EmbarkMeshMergeFunctionLibrary.MergeAttachedStaticMeshes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51a2770
};

// Class EmbarkUtils.EmbarkPawnComponent
// Size: 0x180 (Inherited: 0x160)
struct UEmbarkPawnComponent : UActorComponent {
	struct FMulticastInlineDelegate OnPawnPossessed; // 0x158(0x10)
	struct FMulticastInlineDelegate OnPawnUnPossessed; // 0x168(0x10)
	bool bShouldDelegatePossessToBeginPlay; // 0x178(0x01)

	void ReceiveOnUnpossessedBy(struct AController* UnpossessedBy); // Function EmbarkUtils.EmbarkPawnComponent.ReceiveOnUnpossessedBy // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnPossessedBy(struct AController* PossessedBy); // Function EmbarkUtils.EmbarkPawnComponent.ReceiveOnPossessedBy // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkUtils.EmbarkPhysicsDeferredTermBodySubsystem
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkPhysicsDeferredTermBodySubsystem : UWorldSubsystem {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class EmbarkUtils.EmbarkPhysicsUtil
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkPhysicsUtil : UObject {

	bool TempSphereOverlapComponent(struct UPrimitiveComponent* Component, struct FVector SphereLocation, float SphereRadius, bool bComplex); // Function EmbarkUtils.EmbarkPhysicsUtil.TempSphereOverlapComponent // (Final|Native|Static|Public|HasDefaults) // @ game+0x51a65e0
	bool TempBoxOverlapComponent(struct UPrimitiveComponent* Component, struct FBox Box, bool bComplex); // Function EmbarkUtils.EmbarkPhysicsUtil.TempBoxOverlapComponent // (Final|Native|Static|Public|HasDefaults) // @ game+0x51a4910
	bool TeleportToDirect(struct AActor* Actor, struct FVector& DestLocation, struct FRotator& DestRotation, bool bTeleportPhysics, bool bSweep, bool bIsATest, bool bNoCheck); // Function EmbarkUtils.EmbarkPhysicsUtil.TeleportToDirect // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51a6160
	void SyncPhysicsMaterialFrictionProperties(struct UPhysicalMaterial* PhysMat); // Function EmbarkUtils.EmbarkPhysicsUtil.SyncPhysicsMaterialFrictionProperties // (Final|Native|Static|Public) // @ game+0x51a5000
	void SetPhysicsPaused(struct UWorld* World, bool bIsPaused); // Function EmbarkUtils.EmbarkPhysicsUtil.SetPhysicsPaused // (Final|Native|Static|Public) // @ game+0x51a11b0
	void SetMaxDepenetrationVelocity(struct FBodyInstance& InBodyInstance, float InMaxDepenetrationVelocity); // Function EmbarkUtils.EmbarkPhysicsUtil.SetMaxDepenetrationVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a2ce0
	void SetMaxContactImpulse(struct FBodyInstance& InBodyInstance, float InMaxContactImpulse); // Function EmbarkUtils.EmbarkPhysicsUtil.SetMaxContactImpulse // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a3ae0
	void SetEnableKinematicHitCallbacks(struct FBodyInstance& InBodyInstance, bool bSetEnabled, bool bOnlySimulationShapes); // Function EmbarkUtils.EmbarkPhysicsUtil.SetEnableKinematicHitCallbacks // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a54e0
	void SetBodyTransform(struct FBodyInstance& Instance, struct FTransform& NewTransform, enum class ETeleportType Teleport, bool bAutoWake); // Function EmbarkUtils.EmbarkPhysicsUtil.SetBodyTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a59a0
	bool IsSamePhysicsBody(struct UPrimitiveComponent* ComponentA, struct FName& BoneNameA, struct UPrimitiveComponent* ComponentB, struct FName& BoneNameB); // Function EmbarkUtils.EmbarkPhysicsUtil.IsSamePhysicsBody // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a5680
	bool IsInstanceSimulating(struct UPrimitiveComponent* Component, struct FName BoneName); // Function EmbarkUtils.EmbarkPhysicsUtil.IsInstanceSimulating // (Final|Native|Static|Public) // @ game+0x51a40c0
	bool IsInScene(struct FBodyInstance& Body); // Function EmbarkUtils.EmbarkPhysicsUtil.IsInScene // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a5f80
	struct UPrimitiveComponent* GetSimulatingParent(struct USceneComponent* SceneComponent, struct FName BoneName); // Function EmbarkUtils.EmbarkPhysicsUtil.GetSimulatingParent // (Final|Native|Static|Public) // @ game+0x51a22f0
	struct USkeletalMesh* GetPreviewMeshFromPhysicsAsset(struct UPhysicsAsset* PhysicsAsset); // Function EmbarkUtils.EmbarkPhysicsUtil.GetPreviewMeshFromPhysicsAsset // (Final|Native|Static|Public) // @ game+0x51a6b30
	float GetMaxDepenetrationVelocity(struct FBodyInstance& InBodyInstance); // Function EmbarkUtils.EmbarkPhysicsUtil.GetMaxDepenetrationVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a67f0
	float GetMaxContactImpulse(struct FBodyInstance& InActorHandle); // Function EmbarkUtils.EmbarkPhysicsUtil.GetMaxContactImpulse // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a12e0
	struct FTransform GetKinematicTarget(struct FBodyInstance& Body); // Function EmbarkUtils.EmbarkPhysicsUtil.GetKinematicTarget // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a07a0
	float GetBodyInstanceMass(struct UPrimitiveComponent* PrimitiveComponent, struct FName BoneName); // Function EmbarkUtils.EmbarkPhysicsUtil.GetBodyInstanceMass // (Final|Native|Static|Public) // @ game+0x519ffc0
	bool FastDisableCollisionOnBodyShapes(struct FBodyInstance& Instance); // Function EmbarkUtils.EmbarkPhysicsUtil.FastDisableCollisionOnBodyShapes // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a3d10
	struct TArray<struct FOverlapResult> EnhancedSphereOverlapByTrace(struct UObject* WorldContextObject, struct FVector& SpherePos, float SphereRadius, enum class ETraceTypeQuery TraceChannel, struct UObject* ComponentClassFilter, struct TArray<struct AActor*>& ActorsToIgnore); // Function EmbarkUtils.EmbarkPhysicsUtil.EnhancedSphereOverlapByTrace // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a0160
	struct TArray<struct FOverlapResult> EnhancedSphereOverlap(struct UObject* WorldContextObject, struct FVector SpherePos, float SphereRadius, struct TArray<enum class EObjectTypeQuery>& ObjectTypes, struct UObject* ComponentClassFilter, struct TArray<struct AActor*>& ActorsToIgnore); // Function EmbarkUtils.EmbarkPhysicsUtil.EnhancedSphereOverlap // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a0c50
	struct TArray<struct FOverlapResult> EnhancedComponentOverlap(struct UObject* WorldContextObject, struct UPrimitiveComponent* Component, struct FTransform& ComponentTransform, struct TArray<enum class EObjectTypeQuery>& ObjectTypes, struct UObject* ComponentClassFilter, struct TArray<struct AActor*>& ActorsToIgnore); // Function EmbarkUtils.EmbarkPhysicsUtil.EnhancedComponentOverlap // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x519f090
	struct TArray<struct FOverlapResult> EnhancedBoxOverlapByTrace(struct UObject* WorldContextObject, struct FVector& BoxPos, struct FRotator& BoxRotation, struct FVector& BoxExtent, enum class ETraceTypeQuery TraceChannel, struct UObject* ComponentClassFilter, struct TArray<struct AActor*>& ActorsToIgnore); // Function EmbarkUtils.EmbarkPhysicsUtil.EnhancedBoxOverlapByTrace // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a5c40
	struct TArray<struct FOverlapResult> EnhancedBoxOverlap(struct UObject* WorldContextObject, struct FVector BoxPos, struct FRotator BoxRotation, struct FVector BoxExtent, struct TArray<enum class EObjectTypeQuery>& ObjectTypes, struct UObject* ComponentClassFilter, struct TArray<struct AActor*>& ActorsToIgnore); // Function EmbarkUtils.EmbarkPhysicsUtil.EnhancedBoxOverlap // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a3540
	enum class ECollisionChannel ConvertTraceTypeToCollisionChannel(enum class ETraceTypeQuery TraceType); // Function EmbarkUtils.EmbarkPhysicsUtil.ConvertTraceTypeToCollisionChannel // (Final|Native|Static|Public) // @ game+0x51a4290
	enum class ETraceTypeQuery ConvertToTraceType(enum class ECollisionChannel CollisionChannel); // Function EmbarkUtils.EmbarkPhysicsUtil.ConvertToTraceType // (Final|Native|Static|Public) // @ game+0x51a2160
	enum class EObjectTypeQuery ConvertToObjectType(enum class ECollisionChannel CollisionChannel); // Function EmbarkUtils.EmbarkPhysicsUtil.ConvertToObjectType // (Final|Native|Static|Public) // @ game+0x51a00c0
	enum class ECollisionChannel ConvertObjectTypeToCollisionChannel(enum class EObjectTypeQuery ObjectType); // Function EmbarkUtils.EmbarkPhysicsUtil.ConvertObjectTypeToCollisionChannel // (Final|Native|Static|Public) // @ game+0x51a3c60
	struct FEmbarkMassProperties CalcBodyMassProperties(struct FBodyInstance& InBodyInstance, struct FTransform MassModifierTransform, bool bIncludedWeldedShapes); // Function EmbarkUtils.EmbarkPhysicsUtil.CalcBodyMassProperties // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a2470
	void BuildFKBoxSphereBoundsFromAggGeom(struct FKAggregateGeom& AggGeom, struct FBoxSphereBounds& OutBoxSphereBound); // Function EmbarkUtils.EmbarkPhysicsUtil.BuildFKBoxSphereBoundsFromAggGeom // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a30a0
};

// Class EmbarkUtils.EmbarkPlayerStateDebugNameInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkPlayerStateDebugNameInterface : UInterface {
};

// Class EmbarkUtils.EmbarkProjectionDataCache
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkProjectionDataCache : UBlueprintFunctionLibrary {

	void ScreenToWidgetLocal(struct FEmbarkWidgetProjectionData& Projection, struct FGeometry& Geometry, struct FVector2D ScreenPosition, struct FVector2D& LocalCoordinate, bool bIncludeWindowPosition); // Function EmbarkUtils.EmbarkProjectionDataCache.ScreenToWidgetLocal // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a4d80
	void ScreenToWidgetAbsolute(struct FEmbarkWidgetProjectionData& Projection, struct FVector2D ScreenPosition, struct FVector2D& AbsoluteCoordinate, bool bIncludeWindowPosition); // Function EmbarkUtils.EmbarkProjectionDataCache.ScreenToWidgetAbsolute // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a68f0
	void ScreenToViewport(struct FEmbarkWidgetProjectionData& Projection, struct FVector2D ScreenPosition, struct FVector2D& ViewportPosition); // Function EmbarkUtils.EmbarkProjectionDataCache.ScreenToViewport // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a15c0
	bool ProjectWorldToWidgetPositionWithDistance(struct FEmbarkProjectionData& Projection, struct FEmbarkWidgetProjectionData& WidgetProjection, struct FVector& WorldLocation, struct FVector& ViewportPosition, bool bPlayerViewportRelative); // Function EmbarkUtils.EmbarkProjectionDataCache.ProjectWorldToWidgetPositionWithDistance // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a0470
	bool ProjectWorldToWidgetPosition(struct FEmbarkProjectionData& Projection, struct FEmbarkWidgetProjectionData& WidgetProjection, struct FVector& WorldLocation, struct FVector2D& ViewportPosition, bool bPlayerViewportRelative); // Function EmbarkUtils.EmbarkProjectionDataCache.ProjectWorldToWidgetPosition // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a4440
	bool ProjectWorldToScreenWithDistance(struct FEmbarkProjectionData& Projection, struct FVector WorldLocation, struct FVector& ScreenLocation, bool bPlayerViewportRelative); // Function EmbarkUtils.EmbarkProjectionDataCache.ProjectWorldToScreenWithDistance // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a6410
	bool ProjectWorldToScreen(struct FEmbarkProjectionData& Projection, struct FVector& WorldPosition, struct FVector2D& ScreenPosition, bool bPlayerViewportRelative); // Function EmbarkUtils.EmbarkProjectionDataCache.ProjectWorldToScreen // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a08a0
	bool ProjectWorldToPlayerViewport(struct FEmbarkProjectionData& Projection, struct FVector& WorldPosition, struct FVector2D& ScreenPosition); // Function EmbarkUtils.EmbarkProjectionDataCache.ProjectWorldToPlayerViewport // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a1770
	bool GetWidgetProjectionData(struct ULocalPlayer* LocalPlayer, struct FEmbarkWidgetProjectionData& Result); // Function EmbarkUtils.EmbarkProjectionDataCache.GetWidgetProjectionData // (Final|Native|Static|Public|HasOutParms) // @ game+0x519fdd0
	bool GetProjectionData(struct ULocalPlayer* LocalPlayer, struct FEmbarkProjectionData& Result); // Function EmbarkUtils.EmbarkProjectionDataCache.GetProjectionData // (Final|Native|Static|Public|HasOutParms) // @ game+0x519fc40
	void DeprojectScreenToWorld(struct FEmbarkProjectionData& Projection, struct FVector2D& ScreenPosition, struct FVector& WorldPosition, struct FVector& WorldDirection); // Function EmbarkUtils.EmbarkProjectionDataCache.DeprojectScreenToWorld // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a1ab0
	void AbsoluteToViewport(struct FEmbarkWidgetProjectionData& Projection, struct FVector2D AbsoluteDesktopCoordinate, struct FVector2D& PixelPosition, struct FVector2D& ViewportPosition); // Function EmbarkUtils.EmbarkProjectionDataCache.AbsoluteToViewport // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a3380
};

// Class EmbarkUtils.EmbarkRepeatConsoleCommandSubsystem
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkRepeatConsoleCommandSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x50]; // 0xa0(0x50)

	void StopExecutingRepeatingConsoleCommand(struct FString ConsoleCommand); // Function EmbarkUtils.EmbarkRepeatConsoleCommandSubsystem.StopExecutingRepeatingConsoleCommand // (Final|Native|Public|BlueprintCallable) // @ game+0x51aacd0
	void StopAllExecutingRepeatingConsoleCommand(); // Function EmbarkUtils.EmbarkRepeatConsoleCommandSubsystem.StopAllExecutingRepeatingConsoleCommand // (Final|Native|Public|BlueprintCallable) // @ game+0x33aadf0
	bool StartExecutingRepeatingConsoleCommand(struct FString InConsoleCommand, float Interval); // Function EmbarkUtils.EmbarkRepeatConsoleCommandSubsystem.StartExecutingRepeatingConsoleCommand // (Final|Native|Public|BlueprintCallable) // @ game+0x51ac5b0
	void OnTimerReachedExecuteCommand(struct FString InConsoleCommand); // Function EmbarkUtils.EmbarkRepeatConsoleCommandSubsystem.OnTimerReachedExecuteCommand // (Final|Native|Protected) // @ game+0x51aacd0
	struct UEmbarkRepeatConsoleCommandSubsystem* GetRepeatingConsoleCommandSubsystem(struct UObject* InObjectContext); // Function EmbarkUtils.EmbarkRepeatConsoleCommandSubsystem.GetRepeatingConsoleCommandSubsystem // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b68a0
};

// Class EmbarkUtils.RootMotionAnimMatchingUtils
// Size: 0xa0 (Inherited: 0xa0)
struct URootMotionAnimMatchingUtils : UBlueprintFunctionLibrary {

	float GetTimeAtClosestPoint(struct TArray<struct FRootMotionAnimMatching_PointAtTime>& PointAtTimes, struct FVector3f& Point, float MaxTimeToQuery); // Function EmbarkUtils.RootMotionAnimMatchingUtils.GetTimeAtClosestPoint // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51b64b0
};

// Class EmbarkUtils.EmbarkRootMotionUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRootMotionUtils : UBlueprintFunctionLibrary {

	struct FWarpCurvesValue GetWarpCurvesFromSeqAtTime(struct UAnimSequence* Sequence, float Time, struct FWarpCurvesDefinition& WarpCurveDefinitions, struct FWarpCurvesValue& ValuesIfCurvesDoNotExists); // Function EmbarkUtils.EmbarkRootMotionUtils.GetWarpCurvesFromSeqAtTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x51baf50
	struct FTransform GetInterpolatedWarpWorldTransform(struct FTransform& AuxRootTransform, struct FWarpCurvesValue& WarpCurves, struct FTransform& WarpTargetWorldTransform, struct FTransform& WarpStartTransform, float CapsuleHeight); // Function EmbarkUtils.EmbarkRootMotionUtils.GetInterpolatedWarpWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51be570
	float GetCurveAlphaForPhasedEntry(float CurrentClipTime, float StartTimeOffset, float RateScale); // Function EmbarkUtils.EmbarkRootMotionUtils.GetCurveAlphaForPhasedEntry // (Final|Native|Static|Public) // @ game+0x51af980
	void AdjustWarpCurvesForPhasedEntry(float CurrentClipTime, float StartTimeOffset, float RateScale, struct FWarpCurvesValue& OutWarpCurves); // Function EmbarkUtils.EmbarkRootMotionUtils.AdjustWarpCurvesForPhasedEntry // (Final|Native|Static|Public|HasOutParms) // @ game+0x51aed10
};

// Class EmbarkUtils.EmbarkTeamAgentInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkTeamAgentInterface : UInterface {
};

// Class EmbarkUtils.EmbarkTeamFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkTeamFunctionLibrary : UBlueprintFunctionLibrary {

	void SetActorTeam(struct AActor* ActorToUpdate, enum class EEmbarkTeamId NewTeam); // Function EmbarkUtils.EmbarkTeamFunctionLibrary.SetActorTeam // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b1110
	enum class ETeamAttitude GetAttitudeBetweenTeams(enum class EEmbarkTeamId AskingTeam, enum class EEmbarkTeamId TargetTeam); // Function EmbarkUtils.EmbarkTeamFunctionLibrary.GetAttitudeBetweenTeams // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bb160
	enum class ETeamAttitude GetAttitudeBetweenActors(struct AActor* AskingActor, struct AActor* TargetActor); // Function EmbarkUtils.EmbarkTeamFunctionLibrary.GetAttitudeBetweenActors // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b7a80
	enum class EEmbarkTeamId GetActorTeam(struct AActor* TeamMember); // Function EmbarkUtils.EmbarkTeamFunctionLibrary.GetActorTeam // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bbc00
};

// Class EmbarkUtils.FEmbarkTickLimiterMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFEmbarkTickLimiterMixinLibrary : UObject {

	void Unregister(struct FEmbarkTickLimiter& TickLimiter, struct UObject* Obj); // Function EmbarkUtils.FEmbarkTickLimiterMixinLibrary.Unregister // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51a7f90
	void Tick(struct FEmbarkTickLimiter& TickLimiter, struct UWorld* World); // Function EmbarkUtils.FEmbarkTickLimiterMixinLibrary.Tick // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51abc00
	void Register(struct FEmbarkTickLimiter& TickLimiter, struct FDelegate DynDelegate, float FirstDelay); // Function EmbarkUtils.FEmbarkTickLimiterMixinLibrary.Register // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b1d70
	float GetTime(struct FEmbarkTickLimiter& TickLimiter, struct UWorld* World); // Function EmbarkUtils.FEmbarkTickLimiterMixinLibrary.GetTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51aa4e0
};

// Class EmbarkUtils.EmbarkTickLimiterResultLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkTickLimiterResultLibrary : UBlueprintFunctionLibrary {

	struct FEmbarkTickLimitResult Stop(float Cost); // Function EmbarkUtils.EmbarkTickLimiterResultLibrary.Stop // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x51b94a0
	struct FEmbarkTickLimitResult Continue(float Wait, float Cost); // Function EmbarkUtils.EmbarkTickLimiterResultLibrary.Continue // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x51a8e80
};

// Class EmbarkUtils.EmbarkWindowWrapperMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWindowWrapperMixinLibrary : UObject {

	void SetVisibility(struct FEmbarkWindowWrapper& Window, bool bVisibility); // Function EmbarkUtils.EmbarkWindowWrapperMixinLibrary.SetVisibility // (Final|Native|Static|Private|HasOutParms) // @ game+0x51af300
	void MakeFocused(struct FEmbarkWindowWrapper& Window); // Function EmbarkUtils.EmbarkWindowWrapperMixinLibrary.MakeFocused // (Final|Native|Static|Private|HasOutParms) // @ game+0x51b7b80
	bool IsWindowVisible(struct FEmbarkWindowWrapper& Window); // Function EmbarkUtils.EmbarkWindowWrapperMixinLibrary.IsWindowVisible // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x51aa080
	bool IsWindowDestroyed(struct FEmbarkWindowWrapper& Window); // Function EmbarkUtils.EmbarkWindowWrapperMixinLibrary.IsWindowDestroyed // (Final|Native|Static|Private|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x51bc030
	void DestroyWindow(struct FEmbarkWindowWrapper& Window); // Function EmbarkUtils.EmbarkWindowWrapperMixinLibrary.DestroyWindow // (Final|Native|Static|Private|HasOutParms) // @ game+0x51b78a0
	void CreateAndOpenWindow(struct FEmbarkWindowWrapper& Window, struct UUserWidget* WidgetContent, struct FString WindowTitle, struct FVector2D& WindowSize, bool bResizable); // Function EmbarkUtils.EmbarkWindowWrapperMixinLibrary.CreateAndOpenWindow // (Final|Native|Static|Private|HasOutParms|HasDefaults) // @ game+0x51b9800
};

// Class EmbarkUtils.EmbarkUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUtils : UBlueprintFunctionLibrary {

	void UnbindOnReceiveEmbarkPlayerController(struct UObject* Object, struct FName FunctionName); // Function EmbarkUtils.EmbarkUtils.UnbindOnReceiveEmbarkPlayerController // (Final|Native|Static|Public) // @ game+0x51baba0
	bool TeleportActor(struct AActor* Actor, struct FVector& DestLocation, struct FRotator& DestRotation, bool bIsATest, bool bNoCheck); // Function EmbarkUtils.EmbarkUtils.TeleportActor // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51b5450
	float StopPerfTimer(struct FPerfTimerData& Data); // Function EmbarkUtils.EmbarkUtils.StopPerfTimer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51ba4d0
	void StartPerfTimer(struct FPerfTimerData& Data); // Function EmbarkUtils.EmbarkUtils.StartPerfTimer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51ad9a0
	bool SphereOverlapByChannel(struct UObject* WorldContextObject, struct FVector SpherePos, float SphereRadius, enum class ECollisionChannel CollisionChannel, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct FOverlapResult>& OutOverlaps); // Function EmbarkUtils.EmbarkUtils.SphereOverlapByChannel // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51af020
	void SortLocationsByDistance2D(struct FVector Origin, struct TArray<struct FVector>& Locations, struct TArray<int32_t>& OutIndices); // Function EmbarkUtils.EmbarkUtils.SortLocationsByDistance2D // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51aaff0
	void SortLocationsByDistance(struct FVector Origin, struct TArray<struct FVector>& Locations, struct TArray<int32_t>& OutIndices); // Function EmbarkUtils.EmbarkUtils.SortLocationsByDistance // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51bb730
	void SortActorsByDistance(struct FVector Location, struct TArray<struct AActor*>& Actors); // Function EmbarkUtils.EmbarkUtils.SortActorsByDistance // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51bbf20
	void SkeletalMeshComponentQueueReinitializeAnimationOnNextUpdate(struct USkeletalMeshComponent* SkeletalMeshComponent); // Function EmbarkUtils.EmbarkUtils.SkeletalMeshComponentQueueReinitializeAnimationOnNextUpdate // (Final|Native|Static|Public) // @ game+0x51b6bd0
	void SimulateTicksOnActorComponent(struct UActorComponent* ActorComponent, float TotalTime, float TimeStepTarget); // Function EmbarkUtils.EmbarkUtils.SimulateTicksOnActorComponent // (Final|Native|Static|Public) // @ game+0x51afd00
	void SimulateTicksOnActor(struct AActor* Actor, float TotalTime, float TimeStepTarget); // Function EmbarkUtils.EmbarkUtils.SimulateTicksOnActor // (Final|Native|Static|Public) // @ game+0x51ace00
	void SimulateMouseRMBUp(); // Function EmbarkUtils.EmbarkUtils.SimulateMouseRMBUp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33aadf0
	void SimulateMouseRMBDown(); // Function EmbarkUtils.EmbarkUtils.SimulateMouseRMBDown // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33aadf0
	void SimulateMouseMoved(int32_t X, int32_t Y, bool bActuallyMoveCursor); // Function EmbarkUtils.EmbarkUtils.SimulateMouseMoved // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51bc3b0
	void SimulateMouseLMBUp(); // Function EmbarkUtils.EmbarkUtils.SimulateMouseLMBUp // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33aadf0
	void SimulateMouseLMBDown(); // Function EmbarkUtils.EmbarkUtils.SimulateMouseLMBDown // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33aadf0
	void SimulateMouseClick(struct FKey& MouseButton, enum class EInputEvent InputEvent); // Function EmbarkUtils.EmbarkUtils.SimulateMouseClick // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b0010
	void SimulateKeyInput(struct FKey& Key, enum class EInputEvent InputEvent); // Function EmbarkUtils.EmbarkUtils.SimulateKeyInput // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b0010
	void SetVectorPropertyByName(struct UObject* Object, struct FString PropertyName, struct FVector& Value); // Function EmbarkUtils.EmbarkUtils.SetVectorPropertyByName // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51ad390
	void SetTransformPropertyByName(struct UObject* Object, struct FString PropertyName, struct FTransform& Value); // Function EmbarkUtils.EmbarkUtils.SetTransformPropertyByName // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a85c0
	struct FTimerHandle SetTimerDelegateForNextTickByFunctionNameConst(struct UObject* Object, struct FName FunctionName); // Function EmbarkUtils.EmbarkUtils.SetTimerDelegateForNextTickByFunctionNameConst // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b21c0
	struct FTimerHandle SetTimerDelegateForNextTickByFunctionName(struct UObject* Object, struct FName FunctionName); // Function EmbarkUtils.EmbarkUtils.SetTimerDelegateForNextTickByFunctionName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b8fc0
	struct FTimerHandle SetTimerDelegateForNextTick(struct FDelegate& Delegate); // Function EmbarkUtils.EmbarkUtils.SetTimerDelegateForNextTick // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51adb10
	struct FTimerHandle SetTimer(struct UObject* Object, struct FName FunctionName, float Time, bool bLooping, float InitialStartDelay, float InitialStartDelayVariance); // Function EmbarkUtils.EmbarkUtils.SetTimer // (Final|Native|Static|Public) // @ game+0x51b0530
	void SetTickOrderForComponent(struct UActorComponent* ActorComponent, uint64_t TickOrder); // Function EmbarkUtils.EmbarkUtils.SetTickOrderForComponent // (Final|Native|Static|Public) // @ game+0x51bc510
	void SetTextPropertyByName(struct UObject* Object, struct FString PropertyName, struct FText& Value); // Function EmbarkUtils.EmbarkUtils.SetTextPropertyByName // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b3520
	void SetStringPropertyByName(struct UObject* Object, struct FString PropertyName, struct FString Value); // Function EmbarkUtils.EmbarkUtils.SetStringPropertyByName // (Final|Native|Static|Public) // @ game+0x51a79f0
	void SetSoftObjectPropertyByName(struct UObject* Object, struct FString PropertyName, struct TSoftObjectPtr<UObject>& Value); // Function EmbarkUtils.EmbarkUtils.SetSoftObjectPropertyByName // (Final|Native|Static|Public|HasOutParms) // @ game+0x51aa360
	void SetSoftClassPropertyByName(struct UObject* Object, struct FString PropertyName, struct TSoftClassPtr<UObject>& Value); // Function EmbarkUtils.EmbarkUtils.SetSoftClassPropertyByName // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b5a90
	void SetRotatorPropertyByName(struct UObject* Object, struct FString PropertyName, struct FRotator& Value); // Function EmbarkUtils.EmbarkUtils.SetRotatorPropertyByName // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51b1b30
	bool SetPropertyByNameFromString(struct UObject* Object, struct FString PropertyName, struct FString Value); // Function EmbarkUtils.EmbarkUtils.SetPropertyByNameFromString // (Final|Native|Static|Public) // @ game+0x51b8cd0
	void SetObjectPropertyByName(struct UObject* Object, struct FString PropertyName, struct UObject* Value); // Function EmbarkUtils.EmbarkUtils.SetObjectPropertyByName // (Final|Native|Static|Public) // @ game+0x51a8460
	void SetNamePropertyByName(struct UObject* Object, struct FString PropertyName, struct FName& Value); // Function EmbarkUtils.EmbarkUtils.SetNamePropertyByName // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b16c0
	void SetLinearColorPropertyByName(struct UObject* Object, struct FString PropertyName, struct FLinearColor& Value); // Function EmbarkUtils.EmbarkUtils.SetLinearColorPropertyByName // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a7d80
	void SetIntPropertyByName(struct UObject* Object, struct FString PropertyName, int32_t Value); // Function EmbarkUtils.EmbarkUtils.SetIntPropertyByName // (Final|Native|Static|Public) // @ game+0x51a8f80
	void SetInt64PropertyByName(struct UObject* Object, struct FString PropertyName, int64_t Value); // Function EmbarkUtils.EmbarkUtils.SetInt64PropertyByName // (Final|Native|Static|Public) // @ game+0x51b6940
	void SetHighTickPrioForComponent(struct UActorComponent* ActorComponent); // Function EmbarkUtils.EmbarkUtils.SetHighTickPrioForComponent // (Final|Native|Static|Public) // @ game+0x51b53b0
	void SetHighTickPrioForActor(struct AActor* Actor); // Function EmbarkUtils.EmbarkUtils.SetHighTickPrioForActor // (Final|Native|Static|Public) // @ game+0x51b47b0
	void SetGameplayTagPropertyByName(struct UObject* Object, struct FString PropertyName, struct FGameplayTag& Value); // Function EmbarkUtils.EmbarkUtils.SetGameplayTagPropertyByName // (Final|Native|Static|Public|HasOutParms) // @ game+0x51be340
	void SetFloatPropertyByName(struct UObject* Object, struct FString PropertyName, double Value); // Function EmbarkUtils.EmbarkUtils.SetFloatPropertyByName // (Final|Native|Static|Public) // @ game+0x51bbd90
	void SetColorPropertyByName(struct UObject* Object, struct FString PropertyName, struct FColor& Value); // Function EmbarkUtils.EmbarkUtils.SetColorPropertyByName // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51bd630
	void SetClassPropertyByName(struct UObject* Object, struct FString PropertyName, struct UObject* Value); // Function EmbarkUtils.EmbarkUtils.SetClassPropertyByName // (Final|Native|Static|Public) // @ game+0x51a73a0
	void SetBytePropertyByName(struct UObject* Object, struct FString PropertyName, char Value); // Function EmbarkUtils.EmbarkUtils.SetBytePropertyByName // (Final|Native|Static|Public) // @ game+0x51b0fc0
	void SetBoolPropertyByName(struct UObject* Object, struct FString PropertyName, bool Value); // Function EmbarkUtils.EmbarkUtils.SetBoolPropertyByName // (Final|Native|Static|Public) // @ game+0x51ac0c0
	bool SegmentCapsuleOverlapActorsAndComponents(struct UObject* WorldContextObject, struct FVector CapsuleStart, struct FVector CapsuleEnd, float Radius, enum class ECollisionChannel CollisionChannel, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct AActor*>& OutActors, struct TArray<struct UPrimitiveComponent*>& OutComponents, bool bDebugDraw, struct FLinearColor& DebugDrawColor, float DebugDrawDuration); // Function EmbarkUtils.EmbarkUtils.SegmentCapsuleOverlapActorsAndComponents // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51b2310
	bool SegmentCapsuleOverlapActors(struct UObject* WorldContextObject, struct FVector CapsuleStart, struct FVector CapsuleEnd, float Radius, enum class ECollisionChannel CollisionChannel, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct AActor*>& OutActors, bool bDebugDraw, struct FLinearColor& DebugDrawColor, float DebugDrawDuration); // Function EmbarkUtils.EmbarkUtils.SegmentCapsuleOverlapActors // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51b9e00
	struct UTexture2D* ScreenShotToTexture(struct FIntPoint& OutSize); // Function EmbarkUtils.EmbarkUtils.ScreenShotToTexture // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51b36e0
	void SaveDeveloperStringSetting(struct FString SectionName, struct FString SettingsKey, struct FString Setting); // Function EmbarkUtils.EmbarkUtils.SaveDeveloperStringSetting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51bcc90
	void SaveDeveloperIntSetting(struct FString SectionName, struct FString SettingsKey, int32_t Setting); // Function EmbarkUtils.EmbarkUtils.SaveDeveloperIntSetting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51bba00
	void SaveDeveloperFloatSetting(struct FString SectionName, struct FString SettingsKey, float Setting); // Function EmbarkUtils.EmbarkUtils.SaveDeveloperFloatSetting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b5640
	bool SaveAutoExec(struct FString NewAutoExec); // Function EmbarkUtils.EmbarkUtils.SaveAutoExec // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51a8230
	struct FString RunAngelscriptCodeString(struct FString CodeString, struct UObject* OptionalObject); // Function EmbarkUtils.EmbarkUtils.RunAngelscriptCodeString // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b3c30
	struct UObject* ResolveClassFromString(struct FString ClassPath); // Function EmbarkUtils.EmbarkUtils.ResolveClassFromString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51ba860
	bool ResetObjectPropertyToCDO(struct UObject* Object, struct FString PropertyName); // Function EmbarkUtils.EmbarkUtils.ResetObjectPropertyToCDO // (Final|Native|Static|Public) // @ game+0x51b2c10
	bool ResetObjectPropertiesToCDO(struct UObject* Object); // Function EmbarkUtils.EmbarkUtils.ResetObjectPropertiesToCDO // (Final|Native|Static|Public) // @ game+0x51a9820
	struct FString RemoveWorldPIEPrefix(struct FString WorldPackagePath); // Function EmbarkUtils.EmbarkUtils.RemoveWorldPIEPrefix // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51aadd0
	void RemoveSCSNodeFromBlueprint(struct UObject* Class, struct UActorComponent* RemoveNodeMatchingThisComponentTemplate); // Function EmbarkUtils.EmbarkUtils.RemoveSCSNodeFromBlueprint // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51aa840
	struct UObject* RemoveConst(struct UObject* Object); // Function EmbarkUtils.EmbarkUtils.RemoveConst // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51afc20
	void ReinitializeProperties(struct UObject* Source, struct UObject* Target); // Function EmbarkUtils.EmbarkUtils.ReinitializeProperties // (Final|Native|Static|Public) // @ game+0x51aaec0
	void RegisterComponent(struct UActorComponent* ComponentToRegister); // Function EmbarkUtils.EmbarkUtils.RegisterComponent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b49b0
	void OverrideClientRate(struct UWorld* World, int32_t MaxClientRate, int32_t MaxInternetClientRate); // Function EmbarkUtils.EmbarkUtils.OverrideClientRate // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51ab1f0
	struct FName MakeUniqueObjectName(struct UObject* Parent, struct UObject* Class, struct FName InBaseName); // Function EmbarkUtils.EmbarkUtils.MakeUniqueObjectName // (Final|Native|Static|Public) // @ game+0x51b3f60
	float LoadFloatConsoleVariable(struct FString ConsoleVariableName); // Function EmbarkUtils.EmbarkUtils.LoadFloatConsoleVariable // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bb630
	bool LoadEngineStringSetting(struct FString SectionName, struct FString SettingsKey, struct FString& OutSetting); // Function EmbarkUtils.EmbarkUtils.LoadEngineStringSetting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b4d70
	bool LoadDeveloperStringSetting(struct FString SectionName, struct FString SettingsKey, struct FString& OutSetting); // Function EmbarkUtils.EmbarkUtils.LoadDeveloperStringSetting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b39e0
	bool LoadDeveloperSection(struct FString SectionName, struct TArray<struct FString>& OutSectionContents); // Function EmbarkUtils.EmbarkUtils.LoadDeveloperSection // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b41b0
	bool LoadDeveloperIntSetting(struct FString SectionName, struct FString SettingsKey, int32_t& OutSetting); // Function EmbarkUtils.EmbarkUtils.LoadDeveloperIntSetting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51ac880
	bool LoadDeveloperFloatSetting(struct FString SectionName, struct FString SettingsKey, float& OutSetting); // Function EmbarkUtils.EmbarkUtils.LoadDeveloperFloatSetting // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b9180
	struct UObject* LoadClassFromString(struct FString ClassPath); // Function EmbarkUtils.EmbarkUtils.LoadClassFromString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b4f80
	bool LoadAutoExec(struct TArray<struct FString>& Commands); // Function EmbarkUtils.EmbarkUtils.LoadAutoExec // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b1200
	void LoadAssetsAsync(struct TArray<struct FSoftObjectPath> ObjectPaths, struct UObject* CallbackObject, struct FName CallbackMethodName); // Function EmbarkUtils.EmbarkUtils.LoadAssetsAsync // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51ad140
	void LoadAssetAsync(struct FSoftObjectPath ObjectPath, struct UObject* CallbackObject, struct FName CallbackMethodName); // Function EmbarkUtils.EmbarkUtils.LoadAssetAsync // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x51b2e50
	bool LineTraceSingleBatched(struct UObject* WorldContextObject, struct TArray<struct FVector> Start, struct TArray<struct FVector> End, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult>& OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function EmbarkUtils.EmbarkUtils.LineTraceSingleBatched // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51bdc50
	bool IsWorldDistanceDependentSubLevel(struct UWorld* PersistentWorld, struct FName SubLevelPackageName); // Function EmbarkUtils.EmbarkUtils.IsWorldDistanceDependentSubLevel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51a9720
	bool IsUnattended(); // Function EmbarkUtils.EmbarkUtils.IsUnattended // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b4c40
	bool IsTimerActiveHandleWithContext(struct UObject* WorldContextObject, struct FTimerHandle Handle); // Function EmbarkUtils.EmbarkUtils.IsTimerActiveHandleWithContext // (Final|Native|Static|Public) // @ game+0x51ac780
	bool IsStreamingLevelPending(struct ULevelStreaming* LevelStreaming); // Function EmbarkUtils.EmbarkUtils.IsStreamingLevelPending // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51ae2b0
	bool IsStaticJITTranspiledCodeLoaded(); // Function EmbarkUtils.EmbarkUtils.IsStaticJITTranspiledCodeLoaded // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b5d10
	bool IsRunningTests(); // Function EmbarkUtils.EmbarkUtils.IsRunningTests // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5198790
	bool IsRepGraphNetRelevant(struct APawn* Pawn, struct AActor* ActorToCheck, bool bIncludeDormant); // Function EmbarkUtils.EmbarkUtils.IsRepGraphNetRelevant // (Final|Native|Static|Public) // @ game+0x51b4850
	bool IsPropertyIdentical(struct UObject* ObjA, struct FString PropertyNameA, struct UObject* ObjB, struct FString PropertyNameB); // Function EmbarkUtils.EmbarkUtils.IsPropertyIdentical // (Final|Native|Static|Public) // @ game+0x51ae350
	bool IsLevelInstanceLoaded(struct ALevelInstance* LevelInstance); // Function EmbarkUtils.EmbarkUtils.IsLevelInstanceLoaded // (Final|Native|Static|Public) // @ game+0x51b2a30
	bool IsInGameThread(); // Function EmbarkUtils.EmbarkUtils.IsInGameThread // (Final|Native|Static|Public) // @ game+0x51b1c80
	bool IsComponentNameStableForNetworking(struct UActorComponent* Component); // Function EmbarkUtils.EmbarkUtils.IsComponentNameStableForNetworking // (Final|Native|Static|Public) // @ game+0x51a71c0
	bool IsAutoplay(); // Function EmbarkUtils.EmbarkUtils.IsAutoplay // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5198790
	bool IsAnonymousUser(); // Function EmbarkUtils.EmbarkUtils.IsAnonymousUser // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5198790
	bool IsActorNameStableForNetworking(struct AActor* Actor); // Function EmbarkUtils.EmbarkUtils.IsActorNameStableForNetworking // (Final|Native|Static|Public) // @ game+0x51a71c0
	struct TMap<struct FVector3f, struct FColor> GetVertexColorData(struct USkeletalMesh* SkeletalMesh, uint32_t PaintingMeshLODIndex); // Function EmbarkUtils.EmbarkUtils.GetVertexColorData // (Final|Native|Static|Public) // @ game+0x51b6fd0
	int32_t GetUniqueId(struct UObject* QueryObject); // Function EmbarkUtils.EmbarkUtils.GetUniqueId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bab00
	struct FText GetTextPropertyByName(struct UObject* Object, struct FString PropertyName); // Function EmbarkUtils.EmbarkUtils.GetTextPropertyByName // (Final|Native|Static|Public) // @ game+0x51b96a0
	bool GetSocketRelativeTransform(struct UStaticMeshComponent* StaticMeshComponent, struct FName InSocketName, struct FTransform& OutRelativeTransform); // Function EmbarkUtils.EmbarkUtils.GetSocketRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x51ad7b0
	struct FTransform GetSkeletalMeshRefPoseTransform(struct USkeletalMesh* SkeletalMesh, struct FName BoneName); // Function EmbarkUtils.EmbarkUtils.GetSkeletalMeshRefPoseTransform // (Final|Native|Static|Public|HasDefaults) // @ game+0x51b0350
	float GetServerTimestampAccurate(struct UObject* WorldContextObject); // Function EmbarkUtils.EmbarkUtils.GetServerTimestampAccurate // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b46d0
	bool GetServerTimestamp(float& OutServerTime); // Function EmbarkUtils.EmbarkUtils.GetServerTimestamp // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x51a7ee0
	struct USCS_Node* GetSCSNodeFromCDOComponent(struct UObject* BPClass, struct USceneComponent* CDOComponent); // Function EmbarkUtils.EmbarkUtils.GetSCSNodeFromCDOComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b93a0
	struct FString GetSanitizedComponentTemplateNameByObject(struct UObject* ComponentTemplateObject); // Function EmbarkUtils.EmbarkUtils.GetSanitizedComponentTemplateNameByObject // (Final|Native|Static|Public) // @ game+0x51a92a0
	struct FString GetSanitizedComponentTemplateName(struct FString ComponentTemplateName); // Function EmbarkUtils.EmbarkUtils.GetSanitizedComponentTemplateName // (Final|Native|Static|Public) // @ game+0x51b7950
	struct FString GetRunAngelscriptCodeStringEntryFuncDecl(struct UObject* OptionalObject); // Function EmbarkUtils.EmbarkUtils.GetRunAngelscriptCodeStringEntryFuncDecl // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bd9d0
	bool GetPropertyValueAsString(struct UObject* Obj, struct FString PropertyName, struct FString& OutPropertyValue); // Function EmbarkUtils.EmbarkUtils.GetPropertyValueAsString // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b8e60
	bool GetPropertyTypeNameAsString(struct UObject* Obj, struct FString PropertyName, struct FString& OutPropertyTypeName); // Function EmbarkUtils.EmbarkUtils.GetPropertyTypeNameAsString // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a6e10
	enum class EEmbarkPropertyTypes GetPropertyType(struct UObject* Obj, struct FString PropertyName); // Function EmbarkUtils.EmbarkUtils.GetPropertyType // (Final|Native|Static|Public) // @ game+0x51acc40
	struct APlayerController* GetPlayerControllerInWorld(struct UObject* WorldContextObject, uint64_t PlayerIndex); // Function EmbarkUtils.EmbarkUtils.GetPlayerControllerInWorld // (Final|Native|Static|Public) // @ game+0x51ba610
	struct FString GetPlatformUserName(bool bOnlyAlphaNumeric); // Function EmbarkUtils.EmbarkUtils.GetPlatformUserName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b40d0
	int64_t GetPlatformTimeMSTwoDecimals(); // Function EmbarkUtils.EmbarkUtils.GetPlatformTimeMSTwoDecimals // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51afb20
	enum class EPhysicalSurface GetPhysicalSurfaceFromName(struct FName SurfaceName); // Function EmbarkUtils.EmbarkUtils.GetPhysicalSurfaceFromName // (Final|Native|Static|Public) // @ game+0x51be4d0
	struct USceneComponent* GetParentForCDOComponent(struct UObject* BPClass, struct USceneComponent* CDOComponent); // Function EmbarkUtils.EmbarkUtils.GetParentForCDOComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51a7870
	float GetOutgoingPacketLossAverage(struct APawn* Pawn); // Function EmbarkUtils.EmbarkUtils.GetOutgoingPacketLossAverage // (Final|Native|Static|Public) // @ game+0x51b2990
	float GetOutgoingConnectionJitter(struct APawn* Pawn); // Function EmbarkUtils.EmbarkUtils.GetOutgoingConnectionJitter // (Final|Native|Static|Public) // @ game+0x51a6ff0
	struct UObject* GetObjectFromNetGUID(struct UObject* WorldContextObject, uint64_t NetGUID); // Function EmbarkUtils.EmbarkUtils.GetObjectFromNetGUID // (Final|Native|Static|Public) // @ game+0x51b89e0
	struct TArray<struct FVector2D> GetNotifyStateStartAndEndTimes(struct UAnimSequence* Seq, struct UAnimNotifyState*& Type); // Function EmbarkUtils.EmbarkUtils.GetNotifyStateStartAndEndTimes // (Final|Native|Static|Public|HasOutParms) // @ game+0x51a6ce0
	struct TArray<struct FVector2D> GetNotifyStartAndEndTimeFromName(struct UAnimSequence* Seq, struct FName Name); // Function EmbarkUtils.EmbarkUtils.GetNotifyStartAndEndTimeFromName // (Final|Native|Static|Public) // @ game+0x51bb250
	struct TArray<struct FString> GetNiagaraParameterCollectionParameterNames(struct UNiagaraParameterCollection* ParameterCollection); // Function EmbarkUtils.EmbarkUtils.GetNiagaraParameterCollectionParameterNames // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b9550
	uint64_t GetNetGUIDForObject(struct UObject* WorldContextObject, struct UObject* Object); // Function EmbarkUtils.EmbarkUtils.GetNetGUIDForObject // (Final|Native|Static|Public) // @ game+0x51b87c0
	struct FName GetNameOfPhysicalSurface(enum class EPhysicalSurface SurfaceType); // Function EmbarkUtils.EmbarkUtils.GetNameOfPhysicalSurface // (Final|Native|Static|Public) // @ game+0x51b7fa0
	bool GetLookAtInfo(struct APlayerController* PlayerController, float MaxDistance, struct FHitResult& OutLookAtInfo); // Function EmbarkUtils.EmbarkUtils.GetLookAtInfo // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51bd780
	bool GetLookAt(struct APlayerController* PlayerController, struct FVector& OutLocation, struct FVector& OutDirection); // Function EmbarkUtils.EmbarkUtils.GetLookAt // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51b0810
	struct FString GetLogTimestampFormat(); // Function EmbarkUtils.EmbarkUtils.GetLogTimestampFormat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bb970
	int32_t GetInvalidId(); // Function EmbarkUtils.EmbarkUtils.GetInvalidId // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b6620
	void GetInheritenceList(struct UObject* StartingType, struct UObject* TerminationType, struct TArray<struct UObject*>& ClassInheritenceList); // Function EmbarkUtils.EmbarkUtils.GetInheritenceList // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51ba960
	float GetIncomingPacketLossAverage(struct APawn* Pawn); // Function EmbarkUtils.EmbarkUtils.GetIncomingPacketLossAverage // (Final|Native|Static|Public) // @ game+0x51b0170
	float GetIncomingConnectionJitter(struct APawn* Pawn); // Function EmbarkUtils.EmbarkUtils.GetIncomingConnectionJitter // (Final|Native|Static|Public) // @ game+0x51aa2c0
	uint32_t GetHashForObject(struct UObject* Object); // Function EmbarkUtils.EmbarkUtils.GetHashForObject // (Final|Native|Static|Public) // @ game+0x51b1520
	struct TMap<struct FString, struct FString> GetConnectionURLOptions(struct AController* Controller); // Function EmbarkUtils.EmbarkUtils.GetConnectionURLOptions // (Final|Native|Static|Public) // @ game+0x51adc40
	bool GetConfidentialSetting(int32_t Type); // Function EmbarkUtils.EmbarkUtils.GetConfidentialSetting // (Final|Native|Static|Public) // @ game+0x51aa760
	struct TArray<struct UActorComponent*> GetComponentsByClassFromCDO(struct AActor* ActorClass, struct UActorComponent* ComponentClass); // Function EmbarkUtils.EmbarkUtils.GetComponentsByClassFromCDO // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b6a90
	struct FBox GetComponentsBoundingBox(struct TArray<struct UPrimitiveComponent*> Components); // Function EmbarkUtils.EmbarkUtils.GetComponentsBoundingBox // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x51af810
	void GetClosestBoxActorsToWorldLocation(int32_t ResultCount, float MaxDistanceToCenter, struct FVector WorldLocation, struct TArray<struct AActor*>& InBoxes, struct TArray<struct AActor*>& OutBoxes); // Function EmbarkUtils.EmbarkUtils.GetClosestBoxActorsToWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51b0d60
	void GetClientRate(struct UWorld* World, int32_t& MaxClientRate, int32_t& MaxInternetClientRate); // Function EmbarkUtils.EmbarkUtils.GetClientRate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51b7e10
	struct FString GetClassPath(struct UObject* ClassToGetPathFrom); // Function EmbarkUtils.EmbarkUtils.GetClassPath // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bc8c0
	void GetCDOComponentsForClass(struct AActor* ActorClass, struct TArray<struct UActorComponent*>& OutCDOComponents); // Function EmbarkUtils.EmbarkUtils.GetCDOComponentsForClass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x51ab450
	struct UActorComponent* GetCDOComponentFromClass(struct AActor* ActorClass, struct UActorComponent* ComponentCDOClass); // Function EmbarkUtils.EmbarkUtils.GetCDOComponentFromClass // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51abe50
	struct FVector GetCatmullRomDirectionalPlaneNormal(struct USplineComponent* Spline, struct FVector& Location); // Function EmbarkUtils.EmbarkUtils.GetCatmullRomDirectionalPlaneNormal // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x51b5850
	int32_t GetBuildCL(); // Function EmbarkUtils.EmbarkUtils.GetBuildCL // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51a8430
	void GetBlueprintInheritanceList(struct UObject* StartingType, struct TArray<struct UObject*>& ClassInheritanceList); // Function EmbarkUtils.EmbarkUtils.GetBlueprintInheritanceList // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51bc740
	struct UObject* GetBlueprintGeneratedClass(struct UBlueprint* Blueprint); // Function EmbarkUtils.EmbarkUtils.GetBlueprintGeneratedClass // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b5960
	float GetAverageFrameTime(struct APawn* Pawn); // Function EmbarkUtils.EmbarkUtils.GetAverageFrameTime // (Final|Native|Static|Public) // @ game+0x51bd550
	bool GetAnimSequenceModelSpaceBoneTransformFromNameAtTime(struct UAnimSequence* Seq, struct FName BoneName, float Time, struct FTransform& Out, bool bApplyAdditiveAnimation); // Function EmbarkUtils.EmbarkUtils.GetAnimSequenceModelSpaceBoneTransformFromNameAtTime // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51ae500
	bool GetAnimSequenceModelSpaceBoneTransformFromIndexAtTime(struct UAnimSequence* Seq, int32_t BoneIndex, float Time, struct FTransform& Out, bool bApplyAdditiveAnimation); // Function EmbarkUtils.EmbarkUtils.GetAnimSequenceModelSpaceBoneTransformFromIndexAtTime // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51ad520
	bool GetAnimSequenceBoneTransformFromNameAtTime(struct UAnimSequence* Seq, struct FName BoneName, float Time, struct FTransform& Out, bool bApplyAdditiveAnimation); // Function EmbarkUtils.EmbarkUtils.GetAnimSequenceBoneTransformFromNameAtTime // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51b5f40
	bool GetAnimSequenceBoneTransformFromIndexAtTime(struct UAnimSequence* Seq, int32_t BoneIndex, float Time, struct FTransform& Out, bool bApplyAdditiveAnimation); // Function EmbarkUtils.EmbarkUtils.GetAnimSequenceBoneTransformFromIndexAtTime // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51b0a80
	void GetAnimSequenceBoneTransform(struct UAnimSequence* Seq, int32_t TrackIndex, float Time, struct FTransform& Out); // Function EmbarkUtils.EmbarkUtils.GetAnimSequenceBoneTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a94c0
	bool GetAnimationSequenceCurveValueFromNameAtTime(struct UAnimSequence* Seq, struct FName CurveName, float Time, float& Out); // Function EmbarkUtils.EmbarkUtils.GetAnimationSequenceCurveValueFromNameAtTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b1970
	struct TArray<struct ULevelStreaming*> GetAllSublevelsToLoadOnClient(struct UWorld* PersistentWorld); // Function EmbarkUtils.EmbarkUtils.GetAllSublevelsToLoadOnClient // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51ae190
	struct TArray<struct FName> GetAllStreamingLevelsAssetPackageNames(struct UWorld* PersistentWorld); // Function EmbarkUtils.EmbarkUtils.GetAllStreamingLevelsAssetPackageNames // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b6cb0
	struct TArray<struct ULevelStreaming*> GetAllStreamingLevels(struct UWorld* PersistentWorld); // Function EmbarkUtils.EmbarkUtils.GetAllStreamingLevels // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b5da0
	void GetAllSoftObjectPaths(struct UObject* Object, struct TArray<struct FSoftObjectPath>& OutPaths, bool bRecursivelySearchSubObjects, struct TArray<struct UObject*>& IgnoreSubObjectsOfClass); // Function EmbarkUtils.EmbarkUtils.GetAllSoftObjectPaths // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51ab8d0
	void GetAllReferencedGameplayTagsThroughReflection(struct UObject* Object, struct TSet<struct FGameplayTag>& OutUsedTags); // Function EmbarkUtils.EmbarkUtils.GetAllReferencedGameplayTagsThroughReflection // (Final|Native|Static|Public|HasOutParms) // @ game+0x51ba2b0
	void GetAllPropertyNames(struct UObject* Obj, struct TArray<struct FString>& OutNames, bool bRecursivelyFindProperties, bool bOnlyBlueprintVisible, bool bDotSyntaxForNestedProperties, bool bIncludeEditorProperties, bool bIncludeASOnlyProperties); // Function EmbarkUtils.EmbarkUtils.GetAllPropertyNames // (Final|Native|Static|Public|HasOutParms) // @ game+0x51ac250
	struct TArray<struct FAnimNotifyEvent> GetAllNotifyStatesInSequence(struct UAnimSequence* Seq); // Function EmbarkUtils.EmbarkUtils.GetAllNotifyStatesInSequence // (Final|Native|Static|Public) // @ game+0x51acf60
	struct TArray<struct ALevelInstance*> GetAllLevelInstancesToLoadOnClient(struct UWorld* PersistentWorld); // Function EmbarkUtils.EmbarkUtils.GetAllLevelInstancesToLoadOnClient // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bcf30
	void GetAllAttachedActors(struct AActor* Actor, struct TArray<struct AActor*>& OutAttachedActors); // Function EmbarkUtils.EmbarkUtils.GetAllAttachedActors // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51bad30
	bool GetActorRelativeTransform(struct USceneComponent* SceneComponent, struct FTransform& OutTransform); // Function EmbarkUtils.EmbarkUtils.GetActorRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x51a8b00
	void ForceUpdateOverlaps(struct AActor* Actor, bool bNotify); // Function EmbarkUtils.EmbarkUtils.ForceUpdateOverlaps // (Final|Native|Static|Public) // @ game+0x51b12f0
	void FlushLevelStreaming(struct UObject* WorldContextObject); // Function EmbarkUtils.EmbarkUtils.FlushLevelStreaming // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b3840
	void ExecuteSystemCommand(struct FString CommandString); // Function EmbarkUtils.EmbarkUtils.ExecuteSystemCommand // (Final|Native|Static|Public) // @ game+0x51afea0
	struct FString ErrorCodePadWithZeros(int32_t ErrorCode); // Function EmbarkUtils.EmbarkUtils.ErrorCodePadWithZeros // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b6740
	void DumpCallstackToLogSlow(); // Function EmbarkUtils.EmbarkUtils.DumpCallstackToLogSlow // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33aadf0
	void DrawDebugSphere(struct UObject* WorldContextObject, struct FVector Center, float Radius, int32_t Segments, struct FLinearColor SphereColor, float Duration, float Thickness); // Function EmbarkUtils.EmbarkUtils.DrawDebugSphere // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5194940
	void DrawDebugLine(struct UObject* WorldContextObject, struct FVector LineStart, struct FVector LineEnd, float DrawTime, float Thickness, struct FLinearColor Color); // Function EmbarkUtils.EmbarkUtils.DrawDebugLine // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5193120
	bool DoesPropertyExist(struct UObject* Obj, struct FString PropertyName); // Function EmbarkUtils.EmbarkUtils.DoesPropertyExist // (Final|Native|Static|Public) // @ game+0x51b0250
	bool DoesFunctionExist(struct UObject* Obj, struct FName FunctionName); // Function EmbarkUtils.EmbarkUtils.DoesFunctionExist // (Final|Native|Static|Public) // @ game+0x51bd230
	void DirtyNavMesh(struct UWorld* PersistentWorld); // Function EmbarkUtils.EmbarkUtils.DirtyNavMesh // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b3ec0
	bool DestroyController(struct AController* Controller); // Function EmbarkUtils.EmbarkUtils.DestroyController // (Final|Native|Static|Public) // @ game+0x51bd4b0
	void DeleteDeveloperSetting(struct FString SectionName, struct FString SettingsKey); // Function EmbarkUtils.EmbarkUtils.DeleteDeveloperSetting // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51aaa00
	struct TArray<struct UObject*> DebugGetAllObjectsOfClass(struct UObject* Class, bool bIncludeDerivedClasses); // Function EmbarkUtils.EmbarkUtils.DebugGetAllObjectsOfClass // (Final|Native|Static|Public) // @ game+0x51aab90
	struct UActorComponent* CreateComponentOfType(struct AActor* Owner, struct UActorComponent* ComponentType, bool bForceDisableReplication, enum class EComponentMobility Opt_SceneComponentMobility, struct USceneComponent* Opt_SceneComponentParent, struct FName Opt_SceneComponentAttachSocket, bool bCallRegisterComponent, bool bSetNetAddressable, struct FName ComponentName, bool bTransient, bool bMarkAsEditorOnlySubobject); // Function EmbarkUtils.EmbarkUtils.CreateComponentOfType // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b3020
	int32_t CountReplicatedProperties(struct UObject* Class); // Function EmbarkUtils.EmbarkUtils.CountReplicatedProperties // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51bae70
	void CopySkeletalMeshComponentBones(struct USkeletalMeshComponent* FromSkeletalMeshComponent, struct USkeletalMeshComponent* ToSkeletalMeshComponent); // Function EmbarkUtils.EmbarkUtils.CopySkeletalMeshComponentBones // (Final|Native|Static|Public) // @ game+0x51b15c0
	bool CopyProperty(struct UObject* FromObj, struct FString FromPropertyName, struct UObject* ToObj, struct FString ToPropertyName); // Function EmbarkUtils.EmbarkUtils.CopyProperty // (Final|Native|Static|Public) // @ game+0x51b4350
	void CopyPropertiesBetweenObjects(struct UObject* FromObj, struct UObject* ToObj); // Function EmbarkUtils.EmbarkUtils.CopyPropertiesBetweenObjects // (Final|Native|Static|Public) // @ game+0x51af480
	void CopyCollisionResponses(struct UPrimitiveComponent* From, struct UPrimitiveComponent* To); // Function EmbarkUtils.EmbarkUtils.CopyCollisionResponses // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b2d10
	struct FVector Conv_StringToVector(struct FString InString); // Function EmbarkUtils.EmbarkUtils.Conv_StringToVector // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x51aeec0
	void ClearAllTimersForObject(struct UObject* WorldContextObject, struct UObject* Object); // Function EmbarkUtils.EmbarkUtils.ClearAllTimersForObject // (Final|Native|Static|Public) // @ game+0x51a7bc0
	bool ClassHasRPCFunctions(struct UObject* Class); // Function EmbarkUtils.EmbarkUtils.ClassHasRPCFunctions // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51b1f30
	bool CapsuleTraceByChannel(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, float CapsuleRadius, float CapsuleHalfHeight, enum class ECollisionChannel CollisionChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult& OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function EmbarkUtils.EmbarkUtils.CapsuleTraceByChannel // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51b8050
	bool CapsuleOverlapByChannel(struct UObject* WorldContextObject, struct FVector CapsulePos, float Radius, float HalfHeight, struct FQuat Rotation, enum class ECollisionChannel CollisionChannel, struct TArray<struct AActor*>& ActorsToIgnore, struct TArray<struct FOverlapResult>& OutOverlaps); // Function EmbarkUtils.EmbarkUtils.CapsuleOverlapByChannel // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x51a9c40
	void CalculateFullCDOExtent(struct AActor* ActorClass, struct FBox& OutExtent, struct AActor* Opt_DebugActor); // Function EmbarkUtils.EmbarkUtils.CalculateFullCDOExtent // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x51a89c0
	void BindOnReceiveEmbarkPlayerController(struct UObject* Object, struct FName FunctionName); // Function EmbarkUtils.EmbarkUtils.BindOnReceiveEmbarkPlayerController // (Final|Native|Static|Public) // @ game+0x51addc0
	bool BeginPlayOnAllForActorTest(struct AActor* InActor); // Function EmbarkUtils.EmbarkUtils.BeginPlayOnAllForActorTest // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51ae920
	struct FString AutoplayGameMode(); // Function EmbarkUtils.EmbarkUtils.AutoplayGameMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x332a240
	bool AreObjectPropertiesIdenticalWithProperties(struct UObject* ObjectA, struct UObject* ObjectB, struct TArray<struct FName>& OutDifferingProperties); // Function EmbarkUtils.EmbarkUtils.AreObjectPropertiesIdenticalWithProperties // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x51af670
	bool AreObjectPropertiesIdentical(struct UObject* ObjectA, struct UObject* ObjectB); // Function EmbarkUtils.EmbarkUtils.AreObjectPropertiesIdentical // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x51b9ad0
	bool AnimSequenceGetTrackIndex(struct UAnimSequence* Seq, int32_t BoneIndex, int32_t& TrackIndex); // Function EmbarkUtils.EmbarkUtils.AnimSequenceGetTrackIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b7360
	bool AnimSequenceGetBoneIndex(struct UAnimSequence* Seq, struct FName BoneName, int32_t& BoneIndex); // Function EmbarkUtils.EmbarkUtils.AnimSequenceGetBoneIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x51b1810
};

// Class EmbarkUtils.FakeEmbarkUtilsReflectionTester
// Size: 0x120 (Inherited: 0xa0)
struct UFakeEmbarkUtilsReflectionTester : UObject {
	float FloatProperty; // 0x98(0x04)
	int32_t IntProperty; // 0x9c(0x04)
	struct FString StringProperty; // 0xa0(0x10)
	struct FName NameProperty; // 0xb0(0x08)
	bool bBoolProperty; // 0xb8(0x01)
	struct FVector VectorProperty; // 0xc0(0x18)
	struct FGameplayTag GameplayTagProperty; // 0xd8(0x08)
	struct UObject* ClassProperty; // 0xe0(0x08)
	struct FFakeEmbarkUtilsStruct StructProperty; // 0xe8(0x28)
	struct TArray<struct FFakeEmbarkUtilsStruct> StructArrayProperty; // 0x110(0x10)
};

// Class EmbarkUtils.FakeEmbarkUtilsReflectionOneOfEachPropertyTester
// Size: 0x200 (Inherited: 0xa0)
struct UFakeEmbarkUtilsReflectionOneOfEachPropertyTester : UObject {
	float FloatProperty; // 0x98(0x04)
	int32_t IntProperty; // 0x9c(0x04)
	int64_t Int64Property; // 0xa0(0x08)
	char ByteProperty; // 0xa8(0x01)
	struct FName NameProperty; // 0xac(0x08)
	struct UObject* ObjectProperty; // 0xb8(0x08)
	struct UObject* ClassProperty; // 0xc0(0x08)
	struct TSoftClassPtr<UObject> SoftClassProperty; // 0xc8(0x28)
	struct TSoftObjectPtr<UObject> SoftObjectProperty; // 0xf0(0x28)
	struct FString StringProperty; // 0x118(0x10)
	struct FText TextProperty; // 0x128(0x18)
	struct FVector VectorProperty; // 0x140(0x18)
	struct FRotator RotatorProperty; // 0x158(0x18)
	struct FLinearColor LinearColorProperty; // 0x170(0x10)
	struct FColor ColorProperty; // 0x180(0x04)
	char pad_185[0xb]; // 0x185(0x0b)
	struct FTransform TransformProperty; // 0x190(0x60)
	struct FGameplayTag GameplayTagProperty; // 0x1f0(0x08)
	char pad_1f8[0x8]; // 0x1f8(0x08)
};

// Class EmbarkUtils.FakeEmbarkUtilsReflectionContainerTester
// Size: 0x1a0 (Inherited: 0xa0)
struct UFakeEmbarkUtilsReflectionContainerTester : UObject {
	struct TArray<int32_t> IntArray; // 0x98(0x10)
	struct TMap<struct FString, int32_t> StringToIntMap; // 0xa8(0x50)
	struct TMap<int32_t, struct FFakeEmbarkUtilsStruct> IntToStructMap; // 0xf8(0x50)
	struct TMap<enum class EEmbarkPropertyTypes, int32_t> EnumToIntMap; // 0x148(0x50)
};

// Class EmbarkUtils.TestTickingActorComponent
// Size: 0x180 (Inherited: 0x160)
struct UTestTickingActorComponent : UActorComponent {
	char pad_160[0x20]; // 0x160(0x20)
};

// Class EmbarkUtils.TestTickingActor
// Size: 0x3c0 (Inherited: 0x3a0)
struct ATestTickingActor : AActor {
	char pad_3a0[0x20]; // 0x3a0(0x20)
};

// Class EmbarkUtils.EmbarkFakeNetDriver
// Size: 0x840 (Inherited: 0x840)
struct UEmbarkFakeNetDriver : UNetDriver {
};

