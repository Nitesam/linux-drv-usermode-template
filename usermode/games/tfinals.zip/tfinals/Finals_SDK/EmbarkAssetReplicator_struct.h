// ScriptStruct EmbarkAssetReplicator.AssetReplicatorIdBase
// Size: 0x10 (Inherited: 0x00)
struct FAssetReplicatorIdBase {
	struct UObject* PtrCache; // 0x00(0x08)
	uint16_t DataIdx; // 0x08(0x02)
	char pad_a[0x6]; // 0x0a(0x06)
};

// ScriptStruct EmbarkAssetReplicator.EmbarkAssetReplicatorAssetsList
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkAssetReplicatorAssetsList {
	struct TArray<struct FString> Assets; // 0x00(0x10)
	struct FName TypeName; // 0x10(0x08)
	int32_t QuantizationBits; // 0x18(0x04)
	char pad_1c[0x14]; // 0x1c(0x14)
};

