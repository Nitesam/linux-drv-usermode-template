// Class OnlineSubsystemEmbark.EmbarkOnlineDeveloperSettings
// Size: 0xf0 (Inherited: 0xb0)
struct UEmbarkOnlineDeveloperSettings : UDeveloperSettings {
	bool bManifestOverwritten; // 0xa8(0x01)
	bool bTenancyOverwritten; // 0xa9(0x01)
	int64_t ManifestId; // 0xb0(0x08)
	struct FString BuildIdentifier; // 0xb8(0x10)
	int32_t NumAutoPlayClient; // 0xc8(0x04)
	char pad_ce[0x2]; // 0xce(0x02)
	struct FString AutoPlayIdentity; // 0xd0(0x10)
	struct FString TenancyOverride; // 0xe0(0x10)
};

// Class OnlineSubsystemEmbark.RegionSetting
// Size: 0xf0 (Inherited: 0xd0)
struct URegionSetting : UIEmbarkOptionEnum {
	struct FText InvalidDisplayText; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)

	struct FGameplayTag GetCurrentRegionIdentifier(); // Function OnlineSubsystemEmbark.RegionSetting.GetCurrentRegionIdentifier // (Final|Native|Public|Const) // @ game+0x2b1a2e0
};

// Class OnlineSubsystemEmbark.EmbarkRegionSubsystem
// Size: 0xe0 (Inherited: 0xa0)
struct UEmbarkRegionSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x28]; // 0xa0(0x28)
	struct FMulticastInlineDelegate OnRegionChanged; // 0xc8(0x10)
	char pad_d8[0x8]; // 0xd8(0x08)

	struct FString GetCurrentRegionOnlineName(); // Function OnlineSubsystemEmbark.EmbarkRegionSubsystem.GetCurrentRegionOnlineName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x529f230
	struct FGameplayTag GetCurrentRegionIdentifier(); // Function OnlineSubsystemEmbark.EmbarkRegionSubsystem.GetCurrentRegionIdentifier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x52d1c20
	struct FText GetCurrentRegionDisplayName(); // Function OnlineSubsystemEmbark.EmbarkRegionSubsystem.GetCurrentRegionDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x529b9c0
	struct TMap<struct FGameplayTag, struct FEmbarkRegionInfo> GetAllRegionsInfo(); // Function OnlineSubsystemEmbark.EmbarkRegionSubsystem.GetAllRegionsInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x529ef50
};

// Class OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UOnlineSubsystemFeatureFlagNativeFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsVoipSmoothTransitionEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsVoipSmoothTransitionEnabled // (Final|Native|Static|Public) // @ game+0x5279100
	bool IsVoiceModerationEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsVoiceModerationEnabled // (Final|Native|Static|Public) // @ game+0x527ab90
	bool IsVoiceConversionEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsVoiceConversionEnabled // (Final|Native|Static|Public) // @ game+0x5293fe0
	bool IsProximityVoipEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsProximityVoipEnabled // (Final|Native|Static|Public) // @ game+0x5298ed0
	bool IsProximityVoipApigwEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsProximityVoipApigwEnabled // (Final|Native|Static|Public) // @ game+0x52d0db0
	bool IsPartyInvitePermissionEveryoneDefault(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsPartyInvitePermissionEveryoneDefault // (Final|Native|Static|Public) // @ game+0x52bf550
	bool IsMicrophoneTestEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsMicrophoneTestEnabled // (Final|Native|Static|Public) // @ game+0x528a250
	bool IsDiscoveryFriendsUpdateHackEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsDiscoveryFriendsUpdateHackEnabled // (Final|Native|Static|Public) // @ game+0x52a11f0
	bool IsAlwaysArrangePartyEnabled(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.IsAlwaysArrangePartyEnabled // (Final|Native|Static|Public) // @ game+0x52be0a0
	bool EnableToggleVoipEORHack(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.EnableToggleVoipEORHack // (Final|Native|Static|Public) // @ game+0x527ffe0
	bool EnableMatchmakingSquadLayout(); // Function OnlineSubsystemEmbark.OnlineSubsystemFeatureFlagNativeFunctionLibrary.EnableMatchmakingSquadLayout // (Final|Native|Static|Public) // @ game+0x52c45d0
};

