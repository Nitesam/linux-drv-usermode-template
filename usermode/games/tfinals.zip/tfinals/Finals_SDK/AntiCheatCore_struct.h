// Enum AntiCheatCore.EAntiCheatVendor
enum class EAntiCheatVendor : uint8_t {
	Invalid = 0,
	Sidecar = 1,
	Theia = 2,
	EasyAntiCheat = 3,
	Sard = 4,
	BattlEye = 5,
	Debug = 7,
	AntiCheatCore = 8,
	Engine = 9,
	Lighthouse = 10,
	Tencent = 11,
	Denuvo = 12,
	Elytra = 13,
	EAntiCheatVendor_MAX = 14
};

// Enum AntiCheatCore.EAntiCheatClientViolationType
enum class EAntiCheatClientViolationType : uint8_t {
	Invalid = 0,
	IntegrityCatalogNotFound = 1,
	IntegrityCatalogError = 2,
	IntegrityCatalogCertificateRevoked = 3,
	IntegrityCatalogMissingMainExecutable = 4,
	GameFileMismatch = 5,
	RequiredGameFileNotFound = 6,
	UnknownGameFileForbidden = 7,
	SystemFileUntrusted = 8,
	ForbiddenModuleLoaded = 9,
	CorruptedMemory = 10,
	ForbiddenToolDetected = 11,
	InternalAntiCheatViolation = 12,
	CorruptedNetworkMessageFlow = 13,
	VirtualMachineNotAllowed = 14,
	ForbiddenSystemConfiguration = 15,
	NoSecureBoot = 16,
	HardwareRestricted = 17,
	NvidiaProfileInspector = 18,
	CheatEngine = 19,
	AutoHotkey = 20,
	AutoClicker = 21,
	Crosshair = 22,
	LighthouseNotInstalled = 23,
	NoHVCI = 24,
	Aimbot = 25,
	Scripting = 26,
	GpuProfile = 27,
	Count = 28,
	EAntiCheatClientViolationType_MAX = 29
};

// Enum AntiCheatCore.EAntiCheatClientAction
enum class EAntiCheatClientAction : uint8_t {
	Invalid = 0,
	RemovePlayer = 1,
	EAntiCheatClientAction_MAX = 2
};

// Enum AntiCheatCore.EAntiCheatClientActionReason
enum class EAntiCheatClientActionReason : uint8_t {
	Invalid = 0,
	InternalError = 1,
	InvalidMessage = 2,
	AuthenticationFailed = 3,
	NullClient = 4,
	HeartbeatTimeout = 5,
	ClientViolation = 6,
	BackendViolation = 7,
	TemporaryCooldown = 8,
	TemporaryBanned = 9,
	PermanentBanned = 10,
	Count = 11,
	EAntiCheatClientActionReason_MAX = 12
};

// Enum AntiCheatCore.EAntiCheatClientAuthStatus
enum class EAntiCheatClientAuthStatus : uint8_t {
	Invalid = 0,
	LocalAuthComplete = 1,
	RemoteAuthComplete = 2,
	EAntiCheatClientAuthStatus_MAX = 3
};

// Enum AntiCheatCore.EAntiCheatClientType
enum class EAntiCheatClientType : uint8_t {
	ProtectedClient = 0,
	UnprotectedClient = 1,
	AIBot = 2,
	EAntiCheatClientType_MAX = 3
};

// Enum AntiCheatCore.EAntiCheatSeverity
enum class EAntiCheatSeverity : uint8_t {
	Allow = 0,
	Warning = 1,
	Error = 2,
	EAntiCheatSeverity_MAX = 3
};

