// Class EmbarkRBD.EmbarkRBDFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRBDFunctionLibrary : UBlueprintFunctionLibrary {

	struct FPhysicsBody SetVelocity(struct FPhysicsBody Body, struct FVector LinearVelocity, struct FVector AngularVelocity); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.SetVelocity // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a76ac0
	struct FPhysicsBody SetLinearVelocity(struct FPhysicsBody Body, struct FVector Velocity); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.SetLinearVelocity // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a77450
	struct FPhysicsBody SetAngularVelocity(struct FPhysicsBody Body, struct FVector AngularVelocity); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.SetAngularVelocity // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a772b0
	struct FVector GetVelocityAtLocation(struct FPhysicsBody Body, struct FVector Location); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.GetVelocityAtLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a757c0
	struct FVector GetLinearVelocity(struct FPhysicsBody Body); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.GetLinearVelocity // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a77cb0
	float GetEffectiveMass(struct FPhysicsBody RigidBody, struct FVector Location, struct FVector Direction); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.GetEffectiveMass // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a75ea0
	struct FVector GetCentreOfMass(struct FPhysicsBody Body); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.GetCentreOfMass // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a76960
	struct FVector GetAngularVelocity(struct FPhysicsBody Body); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.GetAngularVelocity // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a77db0
	void DepenetrateCollisions(struct TArray<struct FVector>& DepenetrationVelocity, struct TArray<struct FVector>& DepenetrationAngularVelocity, struct TArray<struct FPhysicsBody>& Bodies, struct TArray<struct FContact> CollisionPoints, int32_t MaxIterations, float CollisionMargin, bool IgnoreRotation, bool UseFriction); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.DepenetrateCollisions // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5a777c0
	struct FPhysicsBody CreateRigidBodyFromBodyInstance(struct FBodyInstance& BodyInstance); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.CreateRigidBodyFromBodyInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5a76fe0
	struct FPhysicsBody CreateRigidBody(struct FTransform MassSpaceTransform, struct FVector MassSpaceInertia, float Mass, int32_t ID); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.CreateRigidBody // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a76d90
	struct FPhysicsBody CreateGroundBody(struct FVector Centre, int32_t ID); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.CreateGroundBody // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a76270
	struct FPhysicsBody ApplyImpulseAtLocation(struct FPhysicsBody RigidBody, struct FVector Impulse, struct FVector Location); // Function EmbarkRBD.EmbarkRBDFunctionLibrary.ApplyImpulseAtLocation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a77560
};

// Class EmbarkRBD.EmbarkRBDSimulationSubsystem
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkRBDSimulationSubsystem : UTickableWorldSubsystem {
};

