// Class Foliage.FoliageInstancedStaticMeshComponent
// Size: 0xab0 (Inherited: 0xa70)
struct UFoliageInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent {
	struct FMulticastInlineDelegate OnInstanceTakePointDamage; // 0xa70(0x10)
	struct FMulticastInlineDelegate OnInstanceTakeRadialDamage; // 0xa80(0x10)
	bool bEnableDiscardOnLoad; // 0xa90(0x01)
	char pad_a91[0x3]; // 0xa91(0x03)
	struct FGuid GenerationGuid; // 0xa94(0x10)
	char pad_aa4[0xc]; // 0xaa4(0x0c)
};

// Class Foliage.FoliageType
// Size: 0x530 (Inherited: 0xa0)
struct UFoliageType : UObject {
	struct FGuid UpdateGuid; // 0x98(0x10)
	float Density; // 0xa8(0x04)
	float DensityAdjustmentFactor; // 0xac(0x04)
	float Radius; // 0xb0(0x04)
	bool bSingleInstanceModeOverrideRadius; // 0xb4(0x01)
	float SingleInstanceModeRadius; // 0xb8(0x04)
	enum class EFoliageScaling Scaling; // 0xbc(0x01)
	struct FFloatInterval ScaleX; // 0xc0(0x08)
	struct FFloatInterval ScaleY; // 0xc8(0x08)
	struct FFloatInterval ScaleZ; // 0xd0(0x08)
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[0x4]; // 0xd8(0x30)
	enum class FoliageVertexColorMask VertexColorMask; // 0x108(0x01)
	char pad_10b[0x1]; // 0x10b(0x01)
	float VertexColorMaskThreshold; // 0x10c(0x04)
	char VertexColorMaskInvert : 1; // 0x110(0x01)
	char pad_110_1 : 7; // 0x110(0x01)
	char pad_111[0x3]; // 0x111(0x03)
	struct FFloatInterval ZOffset; // 0x114(0x08)
	char AlignToNormal : 1; // 0x11c(0x01)
	char AverageNormal : 1; // 0x11c(0x01)
	char AverageNormalSingleComponent : 1; // 0x11c(0x01)
	char pad_11c_3 : 5; // 0x11c(0x01)
	char pad_11d[0x3]; // 0x11d(0x03)
	float AlignMaxAngle; // 0x120(0x04)
	char RandomYaw : 1; // 0x124(0x01)
	char pad_124_1 : 7; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	float RandomPitchAngle; // 0x128(0x04)
	struct FFloatInterval GroundSlopeAngle; // 0x12c(0x08)
	struct FFloatInterval Height; // 0x134(0x08)
	char pad_13c[0x4]; // 0x13c(0x04)
	struct TArray<struct FName> LandscapeLayers; // 0x140(0x10)
	float MinimumLayerWeight; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct TArray<struct FName> ExclusionLandscapeLayers; // 0x158(0x10)
	float MinimumExclusionLayerWeight; // 0x168(0x04)
	struct FName LandscapeLayer; // 0x16c(0x08)
	char CollisionWithWorld : 1; // 0x174(0x01)
	char pad_174_1 : 7; // 0x174(0x01)
	char pad_175[0x3]; // 0x175(0x03)
	struct FVector CollisionScale; // 0x178(0x18)
	int32_t AverageNormalSampleCount; // 0x190(0x04)
	char pad_194[0x4]; // 0x194(0x04)
	struct FBoxSphereBounds MeshBounds; // 0x198(0x38)
	struct FVector LowBoundOriginRadius; // 0x1d0(0x18)
	enum class EComponentMobility Mobility; // 0x1e8(0x01)
	char pad_1e9[0x3]; // 0x1e9(0x03)
	struct FInt32Interval CullDistance; // 0x1ec(0x08)
	char bEnableStaticLighting : 1; // 0x1f4(0x01)
	char CastShadow : 1; // 0x1f4(0x01)
	char bAffectDynamicIndirectLighting : 1; // 0x1f4(0x01)
	char bAffectDistanceFieldLighting : 1; // 0x1f4(0x01)
	char bCastDynamicShadow : 1; // 0x1f4(0x01)
	char bCastStaticShadow : 1; // 0x1f4(0x01)
	char pad_1f4_6 : 2; // 0x1f4(0x01)
	char pad_1f5[0x3]; // 0x1f5(0x03)
	char bCastContactShadow : 1; // 0x1f8(0x01)
	char pad_1f8_1 : 7; // 0x1f8(0x01)
	char pad_1f9[0x3]; // 0x1f9(0x03)
	char bCastShadowAsTwoSided : 1; // 0x1fc(0x01)
	char bReceivesDecals : 1; // 0x1fc(0x01)
	char bOverrideLightMapRes : 1; // 0x1fc(0x01)
	char pad_1fc_3 : 5; // 0x1fc(0x01)
	char pad_1fd[0x3]; // 0x1fd(0x03)
	enum class EShadowCacheInvalidationBehavior ShadowCacheInvalidationBehavior; // 0x200(0x01)
	char pad_201[0x3]; // 0x201(0x03)
	int32_t OverriddenLightMapRes; // 0x204(0x04)
	enum class ELightmapType LightmapType; // 0x208(0x01)
	char pad_209[0x3]; // 0x209(0x03)
	char bUseAsOccluder : 1; // 0x20c(0x01)
	char pad_20c_1 : 7; // 0x20c(0x01)
	char pad_20d[0x3]; // 0x20d(0x03)
	char bVisibleInRayTracing : 1; // 0x210(0x01)
	char bEvaluateWorldPositionOffset : 1; // 0x210(0x01)
	char pad_210_2 : 6; // 0x210(0x01)
	char pad_211[0x3]; // 0x211(0x03)
	int32_t WorldPositionOffsetDisableDistance; // 0x214(0x04)
	struct FBodyInstance BodyInstance; // 0x218(0x190)
	enum class EHasCustomNavigableGeometry CustomNavigableGeometry; // 0x3a8(0x01)
	struct FLightingChannels LightingChannels; // 0x3a9(0x01)
	char pad_3aa[0x2]; // 0x3aa(0x02)
	char bRenderCustomDepth : 1; // 0x3ac(0x01)
	char pad_3ac_1 : 7; // 0x3ac(0x01)
	char pad_3ad[0x3]; // 0x3ad(0x03)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x3b0(0x01)
	char pad_3b1[0x3]; // 0x3b1(0x03)
	int32_t CustomDepthStencilValue; // 0x3b4(0x04)
	int32_t TranslucencySortPriority; // 0x3b8(0x04)
	float CollisionRadius; // 0x3bc(0x04)
	float ShadeRadius; // 0x3c0(0x04)
	int32_t NumSteps; // 0x3c4(0x04)
	float InitialSeedDensity; // 0x3c8(0x04)
	float AverageSpreadDistance; // 0x3cc(0x04)
	float SpreadVariance; // 0x3d0(0x04)
	int32_t SeedsPerStep; // 0x3d4(0x04)
	int32_t DistributionSeed; // 0x3d8(0x04)
	float MaxInitialSeedOffset; // 0x3dc(0x04)
	bool bCanGrowInShade; // 0x3e0(0x01)
	bool bSpawnsInShade; // 0x3e1(0x01)
	char pad_3e2[0x2]; // 0x3e2(0x02)
	float MaxInitialAge; // 0x3e4(0x04)
	float MaxAge; // 0x3e8(0x04)
	float OverlapPriority; // 0x3ec(0x04)
	struct FFloatInterval ProceduralScale; // 0x3f0(0x08)
	struct FRuntimeFloatCurve ScaleCurve; // 0x3f8(0x88)
	struct FFoliageDensityFalloff DensityFalloff; // 0x480(0x90)
	int32_t ChangeCount; // 0x510(0x04)
	char ReapplyDensity : 1; // 0x514(0x01)
	char ReapplyRadius : 1; // 0x514(0x01)
	char ReapplyAlignToNormal : 1; // 0x514(0x01)
	char ReapplyRandomYaw : 1; // 0x514(0x01)
	char ReapplyScaling : 1; // 0x514(0x01)
	char ReapplyScaleX : 1; // 0x514(0x01)
	char ReapplyScaleY : 1; // 0x514(0x01)
	char ReapplyScaleZ : 1; // 0x514(0x01)
	char ReapplyRandomPitchAngle : 1; // 0x515(0x01)
	char ReapplyGroundSlope : 1; // 0x515(0x01)
	char ReapplyHeight : 1; // 0x515(0x01)
	char ReapplyLandscapeLayers : 1; // 0x515(0x01)
	char ReapplyZOffset : 1; // 0x515(0x01)
	char ReapplyCollisionWithWorld : 1; // 0x515(0x01)
	char ReapplyVertexColorMask : 1; // 0x515(0x01)
	char bEnableDensityScaling : 1; // 0x515(0x01)
	char bEnableDiscardOnLoad : 1; // 0x516(0x01)
	char bEnableCullDistanceScaling : 1; // 0x516(0x01)
	char pad_516_2 : 6; // 0x516(0x01)
	char pad_517[0x1]; // 0x517(0x01)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x518(0x10)
	int32_t VirtualTextureCullMips; // 0x528(0x04)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x52c(0x01)
	char pad_52d[0x3]; // 0x52d(0x03)
};

// Class Foliage.FoliageType_Actor
// Size: 0x550 (Inherited: 0x530)
struct UFoliageType_Actor : UFoliageType {
	struct AActor* ActorClass; // 0x530(0x08)
	bool bShouldAttachToBaseComponent; // 0x538(0x01)
	bool bStaticMeshOnly; // 0x539(0x01)
	char pad_53a[0x6]; // 0x53a(0x06)
	struct UFoliageInstancedStaticMeshComponent* StaticMeshOnlyComponentClass; // 0x540(0x08)
	char pad_548[0x8]; // 0x548(0x08)
};

// Class Foliage.FoliageType_InstancedStaticMesh
// Size: 0x560 (Inherited: 0x530)
struct UFoliageType_InstancedStaticMesh : UFoliageType {
	struct UStaticMesh* Mesh; // 0x530(0x08)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x538(0x10)
	struct TArray<struct UMaterialInterface*> NaniteOverrideMaterials; // 0x548(0x10)
	struct UFoliageInstancedStaticMeshComponent* ComponentClass; // 0x558(0x08)
};

// Class Foliage.InstancedFoliageActor
// Size: 0x400 (Inherited: 0x3b0)
struct AInstancedFoliageActor : AISMPartitionActor {
	char pad_3b0[0x50]; // 0x3b0(0x50)
};

// Class Foliage.InteractiveFoliageComponent
// Size: 0x790 (Inherited: 0x790)
struct UInteractiveFoliageComponent : UStaticMeshComponent {
};

// Class Foliage.FoliageStatistics
// Size: 0xa0 (Inherited: 0xa0)
struct UFoliageStatistics : UBlueprintFunctionLibrary {

	int32_t FoliageOverlappingSphereCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x23ce2a0
	void FoliageOverlappingBoxTransforms(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box, struct TArray<struct FTransform>& OutTransforms); // Function Foliage.FoliageStatistics.FoliageOverlappingBoxTransforms // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x23c9900
	int32_t FoliageOverlappingBoxCount(struct UObject* WorldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box); // Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x23cb950
};

// Class Foliage.GrassInstancedStaticMeshComponent
// Size: 0xa70 (Inherited: 0xa70)
struct UGrassInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent {
};

// Class Foliage.InteractiveFoliageActor
// Size: 0x440 (Inherited: 0x3b0)
struct AInteractiveFoliageActor : AStaticMeshActor {
	struct UCapsuleComponent* CapsuleComponent; // 0x3a8(0x08)
	struct FVector TouchingActorEntryPosition; // 0x3b0(0x18)
	struct FVector FoliageVelocity; // 0x3c8(0x18)
	struct FVector FoliageForce; // 0x3e0(0x18)
	struct FVector FoliagePosition; // 0x3f8(0x18)
	float FoliageDamageImpulseScale; // 0x410(0x04)
	float FoliageTouchImpulseScale; // 0x414(0x04)
	float FoliageStiffness; // 0x418(0x04)
	float FoliageStiffnessQuadratic; // 0x41c(0x04)
	float FoliageDamping; // 0x420(0x04)
	float MaxDamageImpulse; // 0x424(0x04)
	float MaxTouchImpulse; // 0x428(0x04)
	float MaxForce; // 0x42c(0x04)
	float Mass; // 0x430(0x04)
	char pad_43c[0x4]; // 0x43c(0x04)

	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo); // Function Foliage.InteractiveFoliageActor.CapsuleTouched // (Final|Native|Protected|HasOutParms) // @ game+0x23ce740
};

// Class Foliage.ProceduralFoliageBlockingVolume
// Size: 0x470 (Inherited: 0x3d0)
struct AProceduralFoliageBlockingVolume : AVolume {
	struct AProceduralFoliageVolume* ProceduralFoliageVolume; // 0x3d0(0x08)
	struct FFoliageDensityFalloff DensityFalloff; // 0x3d8(0x90)
	char pad_468[0x8]; // 0x468(0x08)
};

// Class Foliage.ProceduralFoliageComponent
// Size: 0x180 (Inherited: 0x160)
struct UProceduralFoliageComponent : UActorComponent {
	struct UProceduralFoliageSpawner* FoliageSpawner; // 0x158(0x08)
	float TileOverlap; // 0x160(0x04)
	struct AVolume* SpawningVolume; // 0x168(0x08)
	struct FGuid ProceduralGuid; // 0x170(0x10)
};

// Class Foliage.ProceduralFoliageSpawner
// Size: 0xf0 (Inherited: 0xa0)
struct UProceduralFoliageSpawner : UObject {
	int32_t RandomSeed; // 0x98(0x04)
	float TileSize; // 0x9c(0x04)
	int32_t NumUniqueTiles; // 0xa0(0x04)
	float MinimumQuadTreeSize; // 0xa4(0x04)
	struct TArray<struct FFoliageTypeObject> FoliageTypes; // 0xb0(0x10)
	bool bUseOverrideFoliageTerrainMaterials; // 0xc0(0x01)
	char pad_c1[0x7]; // 0xc1(0x07)
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> OverrideFoliageTerrainMaterials; // 0xc8(0x10)
	char pad_d8[0x18]; // 0xd8(0x18)

	void Simulate(int32_t NumSteps); // Function Foliage.ProceduralFoliageSpawner.Simulate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x23c0530
};

// Class Foliage.ProceduralFoliageTile
// Size: 0x1e0 (Inherited: 0xa0)
struct UProceduralFoliageTile : UObject {
	struct UProceduralFoliageSpawner* FoliageSpawner; // 0x98(0x08)
	char pad_a8[0x98]; // 0xa8(0x98)
	struct TArray<struct FProceduralFoliageInstance> InstancesArray; // 0x140(0x10)
	char pad_150[0x90]; // 0x150(0x90)
};

// Class Foliage.ProceduralFoliageVolume
// Size: 0x3e0 (Inherited: 0x3d0)
struct AProceduralFoliageVolume : AVolume {
	char pad_3d0[0x8]; // 0x3d0(0x08)
	struct UProceduralFoliageComponent* ProceduralComponent; // 0x3d8(0x08)
};

