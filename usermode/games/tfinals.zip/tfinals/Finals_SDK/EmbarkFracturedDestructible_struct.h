// Enum EmbarkFracturedDestructible.EDestructionDamageState
enum class EDestructionDamageState : uint8_t {
	Healthy = 0,
	AboutToBeDestroyed = 1,
	Destroyed = 2,
	COUNT = 3,
	EDestructionDamageState_MAX = 4
};

// Enum EmbarkFracturedDestructible.EDSMDamageType
enum class EDSMDamageType : uint8_t {
	PointDamage = 0,
	RadialDamage = 1,
	FireDamage = 2,
	IntegrityFailure = 3,
	Delayed = 4,
	MAX_NUM = 5,
	EDSMDamageType_MAX = 6
};

// Enum EmbarkFracturedDestructible.EDestructionEventType
enum class EDestructionEventType : uint8_t {
	None = 0,
	FracturedBoneDestroyed = 1,
	BreakEvent = 2,
	PropDestroyed = 4,
	Fire = 8,
	EDestructionEventType_MAX = 9
};

// Enum EmbarkFracturedDestructible.EEmbarkBoneSearchModes
enum class EEmbarkBoneSearchModes : uint8_t {
	DepthFirst = 0,
	BreadthFirst = 1,
	EEmbarkBoneSearchModes_MAX = 2
};

// Enum EmbarkFracturedDestructible.EEmbarkBoneSearchStopCondition
enum class EEmbarkBoneSearchStopCondition : uint8_t {
	None = 0,
	Depth = 1,
	Distance = 2,
	DepthAndDistance = 3,
	EEmbarkBoneSearchStopCondition_MAX = 4
};

// Enum EmbarkFracturedDestructible.EDestructibleBoneOverrideType
enum class EDestructibleBoneOverrideType : uint8_t {
	BoneOverride = 0,
	ComponentOverride = 1,
	VolumeOverride = 2,
	EDestructibleBoneOverrideType_MAX = 3
};

// Enum EmbarkFracturedDestructible.EDestructionLevelNameCompareMethod
enum class EDestructionLevelNameCompareMethod : uint8_t {
	StartsWith = 0,
	Contains = 1,
	Equals = 2,
	EDestructionLevelNameCompareMethod_MAX = 3
};

// Enum EmbarkFracturedDestructible.ECrushingCombineMode
enum class ECrushingCombineMode : uint8_t {
	MAX = 0,
	MULTIPLY = 1,
	GEOMETRIC = 2
};

// Enum EmbarkFracturedDestructible.EFracturedDestructibleStrainMode
enum class EFracturedDestructibleStrainMode : uint8_t {
	TryUseStrainBoneGroups = 0,
	TryUseStrainPointVolume = 1,
	OneStrainBonePerComponent = 2,
	OneStrainBonePerActor = 3,
	OneStrainBonePerBone = 4,
	MergeWithNeighbour = 5,
	DisableStrain = 6,
	EFracturedDestructibleStrainMode_MAX = 7
};

// Enum EmbarkFracturedDestructible.EMergeWithNeighbourMode
enum class EMergeWithNeighbourMode : uint8_t {
	PerBoneBestFit = 0,
	PerComponentBestFit = 1,
	PerActorBestFit = 2,
	EMergeWithNeighbourMode_MAX = 3
};

// Enum EmbarkFracturedDestructible.EFracturedStrainSolverType
enum class EFracturedStrainSolverType : uint8_t {
	NoStrainSolver = 0,
	DebugGlobalStrainSolver = 1,
	BlockGlobalStrainSolver = 2,
	SequentialStrainSolver = 3,
	ReducedDofBlockGlobalStrainSolver = 4,
	EFracturedStrainSolverType_MAX = 5
};

// Enum EmbarkFracturedDestructible.EEdgeMeshSize
enum class EEdgeMeshSize : uint8_t {
	INVALID = 0,
	E50 = 1,
	E100 = 2,
	E200 = 3,
	E300 = 4,
	E400 = 5,
	SCATTER = 6,
	MAX = 7
};

// Enum EmbarkFracturedDestructible.EEmbarkPhysicsConstraintAttachToComponent
enum class EEmbarkPhysicsConstraintAttachToComponent : uint8_t {
	FirstComponent = 0,
	SecondComponent = 1,
	EEmbarkPhysicsConstraintAttachToComponent_MAX = 2
};

// ScriptStruct EmbarkFracturedDestructible.BoneDamageEventType
// Size: 0x1a8 (Inherited: 0x00)
struct FBoneDamageEventType {
	struct UEmbarkFracturedDestructibleMeshComponent* DestructibleMeshComponent; // 0x00(0x08)
	struct FBoneDamage Damage; // 0x08(0x158)
	enum class EDestructionDamageState DamageState; // 0x160(0x01)
	bool bIsSimulating; // 0x161(0x01)
	char pad_162[0x6]; // 0x162(0x06)
	struct FBox BoneBounds; // 0x168(0x38)
	float NormalizedBoneHealth; // 0x1a0(0x04)
	char pad_1a4[0x4]; // 0x1a4(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.BoneDamage
// Size: 0x158 (Inherited: 0x00)
struct FBoneDamage {
	struct FName BoneName; // 0x00(0x08)
	float Damage; // 0x08(0x04)
	bool bEnableDelayedDamage; // 0x0c(0x01)
	bool bForceApplyDamage; // 0x0d(0x01)
	bool bUseImpactBreakAtPercent; // 0x0e(0x01)
	enum class EDSMDamageType DamageType; // 0x0f(0x01)
	struct FVector Origin; // 0x10(0x18)
	struct FVector ImpactPoint; // 0x28(0x18)
	struct FVector Direction; // 0x40(0x18)
	struct FGameplayEffectCustomExecutionParameters ExecutionContext; // 0x58(0xf8)
	struct FGameplayTag InstigatorSourceTag; // 0x150(0x08)
};

// ScriptStruct EmbarkFracturedDestructible.DestructibleBoneHandle
// Size: 0x04 (Inherited: 0x00)
struct FDestructibleBoneHandle {
	int32_t _Data; // 0x00(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkClusterMeshComponentKey
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkClusterMeshComponentKey {
	struct UStaticMesh* StaticMesh; // 0x00(0x08)
	struct TArray<struct UMaterialInterface*> OverrideMaterials; // 0x08(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructionCluster
// Size: 0x160 (Inherited: 0x00)
struct FEmbarkDestructionCluster {
	struct AEmbarkDestructionGraphActor* OwningDestructionGraphActor; // 0x00(0x08)
	struct UEmbarkFracturedDestructibleMeshComponent* RootFracturedDestructibleMeshComponent; // 0x08(0x08)
	char pad_10[0x150]; // 0x10(0x150)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructionClusterSystemTickFunction
// Size: 0x40 (Inherited: 0x38)
struct FEmbarkDestructionClusterSystemTickFunction : FTickFunction {
	char pad_38[0x8]; // 0x38(0x08)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionConstraintHandle
// Size: 0x20 (Inherited: 0x00)
struct FDestructionConstraintHandle {
	struct UEmbarkFracturedDestructibleMeshComponent* MeshComponentA; // 0x00(0x08)
	struct FDestructibleBoneHandle BoneHandleA; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct UEmbarkFracturedDestructibleMeshComponent* MeshComponentB; // 0x10(0x08)
	struct FDestructibleBoneHandle BoneHandleB; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionConstraint
// Size: 0x2d0 (Inherited: 0x00)
struct FDestructionConstraint {
	struct FDestructionConstraintHandle ConstraintHandle; // 0x00(0x20)
	struct FConstraintInstance ConstraintInstance; // 0x20(0x278)
	float LinearBreakThreshold; // 0x298(0x04)
	float AngularBreakThreshold; // 0x29c(0x04)
	bool bInitialized; // 0x2a0(0x01)
	char pad_2a1[0x3]; // 0x2a1(0x03)
	float ConstraintCreationTimestamp; // 0x2a4(0x04)
	float ConstraintCreationNormalizedHealthA; // 0x2a8(0x04)
	float ConstraintCreationNormalizedHealthB; // 0x2ac(0x04)
	float ConstraintWakingTimestamp; // 0x2b0(0x04)
	float SolverPositionIterationA; // 0x2b4(0x04)
	float SolverVelocityIterationA; // 0x2b8(0x04)
	float SolverPositionIterationB; // 0x2bc(0x04)
	float SolverVelocityIterationB; // 0x2c0(0x04)
	float LifeTimeScaler; // 0x2c4(0x04)
	float ScheduledForBreakTimestamp; // 0x2c8(0x04)
	float AboutToBreakWeakeningMul; // 0x2cc(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructibleRuntimeData
// Size: 0xb8 (Inherited: 0x00)
struct FFracturedDestructibleRuntimeData {
	struct TArray<struct FFracturedDestructibleOverlappingProp> RuntimeRegisteredProps; // 0x00(0x10)
	struct TSet<struct UEmbarkSimpleDestructibleMeshComponent*> OverlappingSimpleDestructibles; // 0x10(0x50)
	char pad_60[0x58]; // 0x60(0x58)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructibleOverlappingProp
// Size: 0x78 (Inherited: 0x00)
struct FFracturedDestructibleOverlappingProp {
	struct FFracturedDestructionListenerComponentPtr DestructionListenerComponent; // 0x00(0x38)
	struct FDestructionGraphPrimitiveComponentPtr OverlappingComponent; // 0x38(0x38)
	int32_t ItemIndex; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionGraphObjectPtr
// Size: 0x38 (Inherited: 0x00)
struct FDestructionGraphObjectPtr {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionGraphPrimitiveComponentPtr
// Size: 0x38 (Inherited: 0x38)
struct FDestructionGraphPrimitiveComponentPtr : FDestructionGraphObjectPtr {
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructionListenerComponentPtr
// Size: 0x38 (Inherited: 0x38)
struct FFracturedDestructionListenerComponentPtr : FDestructionGraphObjectPtr {
};

// ScriptStruct EmbarkFracturedDestructible.SimpleDestructibleRuntimeData
// Size: 0x170 (Inherited: 0x00)
struct FSimpleDestructibleRuntimeData {
	struct TSet<struct UEmbarkSimpleDestructibleMeshComponent*> OverlappingSimpleDestructibles; // 0x00(0x50)
	char pad_50[0x120]; // 0x50(0x120)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkBoneSearchResultMetaData
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkBoneSearchResultMetaData {
	struct UEmbarkFracturedDestructibleMeshComponent* MeshComponent; // 0x00(0x08)
	int32_t SearchDepth; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkBoneSearchResult
// Size: 0xa0 (Inherited: 0x00)
struct FEmbarkBoneSearchResult {
	struct TSet<struct FDestructibleBoneHandle> BoneHandles; // 0x00(0x50)
	struct TMap<struct FDestructibleBoneHandle, struct FEmbarkBoneSearchResultMetaData> SearchMetaData; // 0x50(0x50)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkBoneSearchParams
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkBoneSearchParams {
	bool bIncludeBrokenConnections; // 0x00(0x01)
	bool bIncludeDestroyedBones; // 0x01(0x01)
	bool bIncludeConnectionsCutDueToGraphBuild; // 0x02(0x01)
	bool bIgnoreDestructionStateForInputBone; // 0x03(0x01)
	bool bWithMetaData; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	int32_t SearchDepth; // 0x08(0x04)
	float SearchDistanceSqrd; // 0x0c(0x04)
	enum class EEmbarkBoneSearchModes SearchMode; // 0x10(0x01)
	enum class EEmbarkBoneSearchStopCondition SearchStopCondition; // 0x11(0x01)
	char pad_12[0x2]; // 0x12(0x02)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedListenerData
// Size: 0x48 (Inherited: 0x00)
struct FFracturedListenerData {
	struct UEmbarkFracturedDestructionListenerComponent* Listener; // 0x00(0x08)
	struct TArray<struct UPrimitiveComponent*> OverlappedComponents; // 0x08(0x10)
	struct TArray<struct UEmbarkFracturedDestructibleMeshComponent*> ConnectedComponents; // 0x18(0x10)
	struct TArray<struct FName> ConnectedBones; // 0x28(0x10)
	struct TArray<struct FTransform> BoneTransforms; // 0x38(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructibleMeshComponentPtr
// Size: 0x38 (Inherited: 0x38)
struct FFracturedDestructibleMeshComponentPtr : FDestructionGraphObjectPtr {
};

// ScriptStruct EmbarkFracturedDestructible.SimpleDestructibleMeshComponentPtr
// Size: 0x38 (Inherited: 0x38)
struct FSimpleDestructibleMeshComponentPtr : FDestructionGraphObjectPtr {
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructionClusterLevelData
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkDestructionClusterLevelData {
	bool bClusterStartAsSimulating; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FDestructibleBoneHandle> BoneHandles; // 0x08(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.DestructibleBonePropertyOverrideSource
// Size: 0x01 (Inherited: 0x00)
struct FDestructibleBonePropertyOverrideSource {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructibleBoneLevelData
// Size: 0x1e8 (Inherited: 0x00)
struct FFracturedDestructibleBoneLevelData {
	char bIsSupportive : 1; // 0x00(0x01)
	char bIsStrainSupportive : 1; // 0x00(0x01)
	char bIsDestructible : 1; // 0x00(0x01)
	char bEnableImpactDamage : 1; // 0x00(0x01)
	char bEnableSmoothImpactDestruction : 1; // 0x00(0x01)
	char bEnableSmoothImpactDestructionAdvanced : 1; // 0x00(0x01)
	char pad_0_6 : 2; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FFracturedDestructibleMeshComponentPtr DestructibleMeshComponentPtr; // 0x08(0x38)
	struct FDestructibleBoneHandle BoneHandle; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct TArray<struct FDestructibleBoneHandle> BoneConnections; // 0x48(0x10)
	struct TArray<struct FDestructibleBoneHandle> ConnectionsCutDueToGraphBuild; // 0x58(0x10)
	struct TArray<struct FFracturedDestructibleOverlappingProp> RegisteredProps; // 0x68(0x10)
	struct TArray<struct FSimpleDestructibleHandle> AttachedSimpleDestructibles; // 0x78(0x10)
	float Health; // 0x88(0x04)
	char pad_8c[0x4]; // 0x8c(0x04)
	struct FVector_NetQuantize10 InitialLocation; // 0x90(0x18)
	struct FFracturedMaterialGameplayData GameplayMaterialData; // 0xa8(0x130)
	struct TArray<int32_t> DestructionVolumeRuntimeOverridesHashes; // 0x1d8(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedMaterialGameplayData
// Size: 0x130 (Inherited: 0x00)
struct FFracturedMaterialGameplayData {
	float Health; // 0x00(0x04)
	struct FGameplayTag MaterialTag; // 0x04(0x08)
	char pad_c[0x4]; // 0x0c(0x04)
	double BendStrainWeighting; // 0x10(0x08)
	int32_t BendMagnitudeRescale; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	double TensionStrainWeighting; // 0x20(0x08)
	double CompressionStrainWeighting; // 0x28(0x08)
	double ShearStrainWeighting; // 0x30(0x08)
	double StrainBreakOffsetIncreaseByAverageScale; // 0x38(0x08)
	double StrainBreakOffsetTotal; // 0x40(0x08)
	double StrainBreakMultipleTotal; // 0x48(0x08)
	enum class EEmbarkFireObjectType ObjectType; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	struct FGameplayTag SourceTag; // 0x54(0x08)
	float HeatTransferBoundsModifier; // 0x5c(0x04)
	bool bScaleHeatTransferBoundsModifier; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	struct FEmbarkFireBurnableSettings BurnableSettings; // 0x64(0x38)
	struct FEmbarkFireHeatModifierSettings HeatModifierSettings; // 0x9c(0x0c)
	float DamagePerSecondWhileOnFire; // 0xa8(0x04)
	bool bSpawnHeatTransferArea; // 0xac(0x01)
	char pad_ad[0x3]; // 0xad(0x03)
	struct FEmbarkFireHeatTransferAreaSettings HeatTransferAreaSettings; // 0xb0(0x08)
	float BreakAtPercent; // 0xb8(0x04)
	float StrainBreakDamagePercent; // 0xbc(0x04)
	float StrainBreakMaxHealthReductionPercent; // 0xc0(0x04)
	float StrainPostBreakImpulseScale; // 0xc4(0x04)
	float ImpactImpulseLimit; // 0xc8(0x04)
	float StrainImpactImpulseScale; // 0xcc(0x04)
	float ImpactDamageMultiplier; // 0xd0(0x04)
	float ImpactBreakAtPercent; // 0xd4(0x04)
	float ImpactSizeDamageThreshold; // 0xd8(0x04)
	float CrushingCoefficient; // 0xdc(0x04)
	enum class ECrushingCombineMode CrushingCoefficientCombineMode; // 0xe0(0x01)
	bool bDelayDestruction; // 0xe1(0x01)
	char pad_e2[0x6]; // 0xe2(0x06)
	double DestructionDelayDuration; // 0xe8(0x08)
	bool EnableDestructionDislodgeEffect; // 0xf0(0x01)
	char pad_f1[0x3]; // 0xf1(0x03)
	float DislodgeEffectDuration; // 0xf4(0x04)
	float DislodgeEffectDynamicFriction; // 0xf8(0x04)
	float DislodgeEffectStaticFriction; // 0xfc(0x04)
	float DislodgeEffectSeparationOffset; // 0x100(0x04)
	float DislodgeEffectCooldown; // 0x104(0x04)
	float SmoothDestructionImpulseLimitScale; // 0x108(0x04)
	float SmoothDestructionLimitMulOnStaticCollision; // 0x10c(0x04)
	float SmoothDestructionVelocityDampingScale; // 0x110(0x04)
	float SmoothDestructionVelocityLimit; // 0x114(0x04)
	float SmoothDestructionImpactDamageMultiplier; // 0x118(0x04)
	float MaxDepenetrationVelocity; // 0x11c(0x04)
	struct FName ConstraintsPreset; // 0x120(0x08)
	float ConstraintsProbability; // 0x128(0x04)
	float ConstraintsDamageToBreak; // 0x12c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.SimpleDestructibleHandle
// Size: 0x04 (Inherited: 0x00)
struct FSimpleDestructibleHandle {
	int32_t Index; // 0x00(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.SimpleDestructibleLevelData
// Size: 0x78 (Inherited: 0x00)
struct FSimpleDestructibleLevelData {
	struct FSimpleDestructibleMeshComponentPtr SimpleDestructibleMeshComponent; // 0x00(0x38)
	struct FSimpleDestructibleHandle SimpleDestructibleHandle; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
	struct TArray<struct FSimpleDestructibleHandle> AttachedSimpleDestructibles; // 0x40(0x10)
	struct TArray<struct FSimpleDestructibleHandle> ParentSimpleDestructibles; // 0x50(0x10)
	struct TArray<struct FDestructibleBoneHandle> AttachedToBones; // 0x60(0x10)
	bool bIsAnchoredToStaticGeometry; // 0x70(0x01)
	bool bAllowAttaching; // 0x71(0x01)
	char pad_72[0x6]; // 0x72(0x06)
};

// ScriptStruct EmbarkFracturedDestructible.DestructibleBoneHandlePairArray
// Size: 0x10 (Inherited: 0x00)
struct FDestructibleBoneHandlePairArray {
	struct TArray<struct FDestructibleBoneHandlePair> BoneHandlePairArray; // 0x00(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.DestructibleBoneHandlePair
// Size: 0x08 (Inherited: 0x00)
struct FDestructibleBoneHandlePair {
	struct FDestructibleBoneHandle BoneHandle1; // 0x00(0x04)
	struct FDestructibleBoneHandle BoneHandle2; // 0x04(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructibleStrainBone
// Size: 0x40 (Inherited: 0x00)
struct FFracturedDestructibleStrainBone {
	struct FStrainBoneHandle StrainBoneHandle; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FDestructibleBoneHandle> BoneHandles; // 0x08(0x10)
	struct TArray<struct FStrainBoneHandle> StrainBoneConnections; // 0x18(0x10)
	struct TArray<struct FDestructibleBoneHandlePairArray> StrainBoneConnectionToDestructionBoneConnections; // 0x28(0x10)
	bool bIsSupportiveBone; // 0x38(0x01)
	bool bUseConnectedBonesForStrainAnchors; // 0x39(0x01)
	char pad_3a[0x2]; // 0x3a(0x02)
	int32_t StrainGraphIndex; // 0x3c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.StrainBoneHandle
// Size: 0x04 (Inherited: 0x00)
struct FStrainBoneHandle {
	int32_t Index; // 0x00(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructionGraphActorLevelData
// Size: 0x60 (Inherited: 0x00)
struct FEmbarkDestructionGraphActorLevelData {
	struct FDestructibleBoneHandle FirstBoneHandle; // 0x00(0x04)
	struct FDestructibleBoneHandle LastBoneHandle; // 0x04(0x04)
	char bIsValidForClient : 1; // 0x08(0x01)
	char pad_8_1 : 7; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t NumBoneConnections; // 0x0c(0x04)
	struct TMap<int32_t, int32_t> LocalConnectionIndexToPairIndex; // 0x10(0x50)
};

// ScriptStruct EmbarkFracturedDestructible.ConnectionPoint
// Size: 0x20 (Inherited: 0x00)
struct FConnectionPoint {
	struct FVector Point; // 0x00(0x18)
	struct FDestructibleBoneHandle RelativeToBone; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructionGraphData
// Size: 0x248 (Inherited: 0x00)
struct FEmbarkDestructionGraphData {
	struct TArray<struct FFracturedDestructibleBoneLevelData> DestructibleBonesLevelData; // 0x00(0x10)
	struct TMap<struct FDestructibleBoneHandlePair, int32_t> DestructibleBonePairsLookup; // 0x10(0x50)
	struct TArray<struct FDestructibleBoneHandlePair> DestructibleBonePairs; // 0x60(0x10)
	struct TMap<struct FFracturedDestructibleMeshComponentPtr, int32_t> DestructibleToBoneGraphIndexLookup; // 0x70(0x50)
	struct TArray<struct FSimpleDestructibleLevelData> SimpleDestructibleLevelData; // 0xc0(0x10)
	struct TMap<struct FSimpleDestructibleMeshComponentPtr, struct FSimpleDestructibleHandle> SimpleDestructibleMeshComponentToHandleLookup; // 0xd0(0x50)
	struct TArray<struct FFracturedDestructibleStrainBone> StrainGraphLevelData; // 0x120(0x10)
	struct TMap<struct FDestructibleBoneHandle, struct FStrainBoneHandle> DestructibleBoneToStrainHandleLookup; // 0x130(0x50)
	struct TArray<struct FEmbarkDestructionClusterLevelData> ClusterLevelData; // 0x180(0x10)
	struct TMap<struct FDestructibleBoneHandle, int32_t> DestructibleBoneToClusterLevelDataLookup; // 0x190(0x50)
	struct TArray<struct FEmbarkDestructionGraphActorLevelData> GraphActorLevelData; // 0x1e0(0x10)
	struct TMap<struct FDestructibleBoneHandlePair, struct FConnectionPoint> DestructibleBonePairConnectionPoints; // 0x1f0(0x50)
	int32_t VersionNumber; // 0x240(0x04)
	int32_t Hash; // 0x244(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionCollectorSettings
// Size: 0x10 (Inherited: 0x00)
struct FDestructionCollectorSettings {
	float GridEffectRate; // 0x00(0x04)
	float GridEffectSize; // 0x04(0x04)
	bool bMergeEvents; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float MergeEventLimit; // 0x0c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.SmoothImpactDestruction
// Size: 0x10 (Inherited: 0x00)
struct FSmoothImpactDestruction {
	float SmoothDestructionImpulseLimit; // 0x00(0x04)
	float SmoothDestructionMinMass; // 0x04(0x04)
	float SmoothDestructionVelocityDampingForce; // 0x08(0x04)
	float SmoothDestructionStaticVelocityDampingForce; // 0x0c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.DamageCracksSettings
// Size: 0x18 (Inherited: 0x00)
struct FDamageCracksSettings {
	struct UEmbarkSDFVolumeTexture* BoneEdgeSDFTexture; // 0x00(0x08)
	bool bEnableDamageEdgeCracks; // 0x08(0x01)
	bool bEnableCracksSoftEdgeBlending; // 0x09(0x01)
	char pad_a[0x2]; // 0x0a(0x02)
	float DamageVisualizationHealthThreshold; // 0x0c(0x04)
	struct UCurveFloat* DamageVisualizationHealthRemapCurve; // 0x10(0x08)
};

// ScriptStruct EmbarkFracturedDestructible.EdgeMeshMaterialOverride
// Size: 0x10 (Inherited: 0x00)
struct FEdgeMeshMaterialOverride {
	struct TArray<struct UMaterialInterface*> Materials; // 0x00(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionConstraintPreset
// Size: 0x30 (Inherited: 0x00)
struct FDestructionConstraintPreset {
	float LinearStiffness; // 0x00(0x04)
	float LinearDamping; // 0x04(0x04)
	float SwingStiffness; // 0x08(0x04)
	float SwingDamping; // 0x0c(0x04)
	float TwistStiffness; // 0x10(0x04)
	float TwistDamping; // 0x14(0x04)
	float LinearBreakThreshold; // 0x18(0x04)
	float AngularBreakThreshold; // 0x1c(0x04)
	float NoticeTimeWeakeningMul; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct UDestructionConstraintEffects* ConstraintEffects; // 0x28(0x08)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionPhysicsConstraintsSettings
// Size: 0x70 (Inherited: 0x00)
struct FDestructionPhysicsConstraintsSettings {
	bool bEnableConstraints; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ConstraintMinLifeTime; // 0x04(0x04)
	float ConstraintBreakingTime; // 0x08(0x04)
	float ConstraintBreakingLimitDecreaseMassThreshold; // 0x0c(0x04)
	int32_t ConstraintSoftBudget; // 0x10(0x04)
	float ConstraintNoticeBeforeBreakTime; // 0x14(0x04)
	struct TMap<struct FName, struct FDestructionConstraintPreset> PhysicsConstraintsPresets; // 0x18(0x50)
	float DebugVisualizationUpdateDeltaTime; // 0x68(0x04)
	char pad_6c[0x4]; // 0x6c(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionLevelNameCompareSetting
// Size: 0x40 (Inherited: 0x00)
struct FDestructionLevelNameCompareSetting {
	struct FString LevelName; // 0x00(0x10)
	enum class EDestructionLevelNameCompareMethod CompareMethod; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TSoftObjectPtr<UWorld> ExactLevel; // 0x18(0x28)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionLevelSettings
// Size: 0x68 (Inherited: 0x00)
struct FDestructionLevelSettings {
	struct FDestructionLevelNameCompareSetting LevelNameCompare; // 0x00(0x40)
	struct TSoftObjectPtr<UEmbarkDestructionLevelSettings> DestructionLevelSettings; // 0x40(0x28)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedMaterialGameplayOverrides
// Size: 0x138 (Inherited: 0x00)
struct FFracturedMaterialGameplayOverrides {
	char bOverride_Health : 1; // 0x00(0x01)
	char bOverride_MaterialTag : 1; // 0x00(0x01)
	char bOverride_BendStrainWeighting : 1; // 0x00(0x01)
	char bOverride_BendMagnitudeRescale : 1; // 0x00(0x01)
	char bOverride_TensionStrainWeighting : 1; // 0x00(0x01)
	char bOverride_CompressionStrainWeighting : 1; // 0x00(0x01)
	char bOverride_ShearStrainWeighting : 1; // 0x00(0x01)
	char bOverride_StrainBreakOffsetIncreaseByAverageScale : 1; // 0x00(0x01)
	char bOverride_StrainBreakOffsetTotal : 1; // 0x01(0x01)
	char bOverride_StrainBreakMultipleTotal : 1; // 0x01(0x01)
	char bOverride_ObjectType : 1; // 0x01(0x01)
	char bOverride_SourceTag : 1; // 0x01(0x01)
	char bOverride_HeatTransferBoundsModifier : 1; // 0x01(0x01)
	char bOverride_bScaleHeatTransferBoundsModifier : 1; // 0x01(0x01)
	char bOverride_BurnableSettings : 1; // 0x01(0x01)
	char bOverride_HeatModifierSettings : 1; // 0x01(0x01)
	char bOverride_DamagePerSecondWhileOnFire : 1; // 0x02(0x01)
	char bOverride_bSpawnHeatTransferArea : 1; // 0x02(0x01)
	char bOverride_HeatTransferAreaSettings : 1; // 0x02(0x01)
	char bOverride_BreakAtPercent : 1; // 0x02(0x01)
	char bOverride_StrainBreakDamagePercent : 1; // 0x02(0x01)
	char bOverride_StrainBreakMaxHealthReductionPercent : 1; // 0x02(0x01)
	char bOverride_StrainPostBreakImpulseScale : 1; // 0x02(0x01)
	char bOverride_ImpactImpulseLimit : 1; // 0x02(0x01)
	char bOverride_StrainImpactImpulseScale : 1; // 0x03(0x01)
	char bOverride_ImpactDamageMultiplier : 1; // 0x03(0x01)
	char bOverride_ImpactBreakAtPercent : 1; // 0x03(0x01)
	char bOverride_ImpactSizeDamageThreshold : 1; // 0x03(0x01)
	char bOverride_CrushingCoefficient : 1; // 0x03(0x01)
	char bOverride_CrushingCoefficientCombineMode : 1; // 0x03(0x01)
	char bOverride_bDelayDestruction : 1; // 0x03(0x01)
	char bOverride_DestructionDelayDuration : 1; // 0x03(0x01)
	char bOverride_EnableDestructionDislodgeEffect : 1; // 0x04(0x01)
	char bOverride_DislodgeEffectDuration : 1; // 0x04(0x01)
	char bOverride_DislodgeEffectDynamicFriction : 1; // 0x04(0x01)
	char bOverride_DislodgeEffectStaticFriction : 1; // 0x04(0x01)
	char bOverride_DislodgeEffectSeparationOffset : 1; // 0x04(0x01)
	char bOverride_DislodgeEffectCooldown : 1; // 0x04(0x01)
	char bOverride_SmoothDestructionImpulseLimitScale : 1; // 0x04(0x01)
	char bOverride_SmoothDestructionLimitMulOnStaticCollision : 1; // 0x04(0x01)
	char bOverride_SmoothDestructionVelocityDampingScale : 1; // 0x05(0x01)
	char bOverride_SmoothDestructionVelocityLimit : 1; // 0x05(0x01)
	char bOverride_SmoothDestructionImpactDamageMultiplier : 1; // 0x05(0x01)
	char bOverride_MaxDepenetrationVelocity : 1; // 0x05(0x01)
	char bOverride_ConstraintsPreset : 1; // 0x05(0x01)
	char bOverride_ConstraintsProbability : 1; // 0x05(0x01)
	char bOverride_ConstraintsDamageToBreak : 1; // 0x05(0x01)
	char pad_5_7 : 1; // 0x05(0x01)
	char pad_6[0x2]; // 0x06(0x02)
	float Health; // 0x08(0x04)
	struct FGameplayTag MaterialTag; // 0x0c(0x08)
	char pad_14[0x4]; // 0x14(0x04)
	double BendStrainWeighting; // 0x18(0x08)
	int32_t BendMagnitudeRescale; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	double TensionStrainWeighting; // 0x28(0x08)
	double CompressionStrainWeighting; // 0x30(0x08)
	double ShearStrainWeighting; // 0x38(0x08)
	double StrainBreakOffsetIncreaseByAverageScale; // 0x40(0x08)
	double StrainBreakOffsetTotal; // 0x48(0x08)
	double StrainBreakMultipleTotal; // 0x50(0x08)
	enum class EEmbarkFireObjectType ObjectType; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	struct FGameplayTag SourceTag; // 0x5c(0x08)
	float HeatTransferBoundsModifier; // 0x64(0x04)
	bool bScaleHeatTransferBoundsModifier; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	struct FEmbarkFireBurnableSettings BurnableSettings; // 0x6c(0x38)
	struct FEmbarkFireHeatModifierSettings HeatModifierSettings; // 0xa4(0x0c)
	float DamagePerSecondWhileOnFire; // 0xb0(0x04)
	bool bSpawnHeatTransferArea; // 0xb4(0x01)
	char pad_b5[0x3]; // 0xb5(0x03)
	struct FEmbarkFireHeatTransferAreaSettings HeatTransferAreaSettings; // 0xb8(0x08)
	float BreakAtPercent; // 0xc0(0x04)
	float StrainBreakDamagePercent; // 0xc4(0x04)
	float StrainBreakMaxHealthReductionPercent; // 0xc8(0x04)
	float StrainPostBreakImpulseScale; // 0xcc(0x04)
	float ImpactImpulseLimit; // 0xd0(0x04)
	float StrainImpactImpulseScale; // 0xd4(0x04)
	float ImpactDamageMultiplier; // 0xd8(0x04)
	float ImpactBreakAtPercent; // 0xdc(0x04)
	float ImpactSizeDamageThreshold; // 0xe0(0x04)
	float CrushingCoefficient; // 0xe4(0x04)
	enum class ECrushingCombineMode CrushingCoefficientCombineMode; // 0xe8(0x01)
	bool bDelayDestruction; // 0xe9(0x01)
	char pad_ea[0x6]; // 0xea(0x06)
	double DestructionDelayDuration; // 0xf0(0x08)
	bool EnableDestructionDislodgeEffect; // 0xf8(0x01)
	char pad_f9[0x3]; // 0xf9(0x03)
	float DislodgeEffectDuration; // 0xfc(0x04)
	float DislodgeEffectDynamicFriction; // 0x100(0x04)
	float DislodgeEffectStaticFriction; // 0x104(0x04)
	float DislodgeEffectSeparationOffset; // 0x108(0x04)
	float DislodgeEffectCooldown; // 0x10c(0x04)
	float SmoothDestructionImpulseLimitScale; // 0x110(0x04)
	float SmoothDestructionLimitMulOnStaticCollision; // 0x114(0x04)
	float SmoothDestructionVelocityDampingScale; // 0x118(0x04)
	float SmoothDestructionVelocityLimit; // 0x11c(0x04)
	float SmoothDestructionImpactDamageMultiplier; // 0x120(0x04)
	float MaxDepenetrationVelocity; // 0x124(0x04)
	struct FName ConstraintsPreset; // 0x128(0x08)
	float ConstraintsProbability; // 0x130(0x04)
	float ConstraintsDamageToBreak; // 0x134(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.MeshArray
// Size: 0x10 (Inherited: 0x00)
struct FMeshArray {
	struct TArray<struct UStaticMesh*> Meshes; // 0x00(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkOrientedBox
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkOrientedBox {
	struct FVector Center; // 0x00(0x18)
	struct FVector Extent; // 0x18(0x18)
	struct FRotator Rotation; // 0x30(0x18)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkBoneMassProperties
// Size: 0x60 (Inherited: 0x00)
struct FEmbarkBoneMassProperties {
	float Mass; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector LocalCenterOfMass; // 0x08(0x18)
	struct FVector MassSpaceInertiaTensor; // 0x20(0x18)
	char pad_38[0x8]; // 0x38(0x08)
	struct FQuat MassFrame; // 0x40(0x20)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkEdgeMeshEntry
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkEdgeMeshEntry {
	struct FName EdgeMeshKey; // 0x00(0x08)
	float Length; // 0x08(0x04)
	struct FName MeshType; // 0x0c(0x08)
	char pad_14[0xc]; // 0x14(0x0c)
	struct FTransform EdgeTransform; // 0x20(0x60)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkBoneEdgeMeshes
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkBoneEdgeMeshes {
	struct TArray<struct FEmbarkEdgeMeshEntry> Meshes; // 0x00(0x10)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructibleBoneAssetData
// Size: 0x150 (Inherited: 0x00)
struct FEmbarkDestructibleBoneAssetData {
	struct FName BoneName; // 0x00(0x08)
	struct FVector BoneRefLocation; // 0x08(0x18)
	struct TArray<struct FName> LinkedBones; // 0x20(0x10)
	bool bIsDestructible; // 0x30(0x01)
	bool bIsSupportive; // 0x31(0x01)
	bool bIsStrainSupportive; // 0x32(0x01)
	char pad_33[0x1]; // 0x33(0x01)
	struct FName PhysicalMaterial; // 0x34(0x08)
	struct FName StrainBoneGroup; // 0x3c(0x08)
	int32_t MeshIndex; // 0x44(0x04)
	struct UBodySetup* BoneBodySetup; // 0x48(0x08)
	struct FEmbarkBoneMassProperties MassProperties; // 0x50(0x60)
	struct TMap<struct FName, struct FEmbarkBoneEdgeMeshes> EdgeMeshes; // 0xb0(0x50)
	struct TSet<struct FEmbarkOrientedBox> BoundingBoxes; // 0x100(0x50)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkDestructibleBoneData
// Size: 0x370 (Inherited: 0x00)
struct FEmbarkDestructibleBoneData {
	char pad_0[0x210]; // 0x00(0x210)
	struct UPhysicalMaterial* PhysicalMaterial; // 0x210(0x08)
	struct TSet<struct USceneComponent*> AttachedChildren; // 0x218(0x50)
	char pad_268[0x108]; // 0x268(0x108)
};

// ScriptStruct EmbarkFracturedDestructible.StrainBoneHandlePair
// Size: 0x08 (Inherited: 0x00)
struct FStrainBoneHandlePair {
	struct FStrainBoneHandle StrainBoneHandle1; // 0x00(0x04)
	struct FStrainBoneHandle StrainBoneHandle2; // 0x04(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.EmbarkFracturedDestructibleBoneRef
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkFracturedDestructibleBoneRef {
	struct FComponentReference FracturedDestructibleMeshComponent; // 0x00(0x28)
	struct FName BoneName; // 0x28(0x08)
};

// ScriptStruct EmbarkFracturedDestructible.BoneDestructionSettings
// Size: 0x78 (Inherited: 0x00)
struct FBoneDestructionSettings {
	char bOverride_bAutoGenerateConnections : 1; // 0x00(0x01)
	char bOverride_bIsSupportive : 1; // 0x00(0x01)
	char bOverride_bIsStrainSupportive : 1; // 0x00(0x01)
	char bOverride_bIsDestructible : 1; // 0x00(0x01)
	char bOverride_bSupportiveIfOnStableGround : 1; // 0x00(0x01)
	char bOverride_bPruneDiagonalConnections : 1; // 0x00(0x01)
	char bOverride_DiagonalPruneRotationOffset : 1; // 0x00(0x01)
	char bOverride_StrainGraphIndex : 1; // 0x00(0x01)
	char bOverride_StrainMode : 1; // 0x01(0x01)
	char bOverride_StrainPointVolumeIdentifier : 1; // 0x01(0x01)
	char bOverride_bCutConnectionsToExternalStrainGraphs : 1; // 0x01(0x01)
	char bOverride_MergeWithNeighbourMode : 1; // 0x01(0x01)
	char bOverride_MergeWithNeighbourOverride : 1; // 0x01(0x01)
	char bOverride_bEnableImpactDamage : 1; // 0x01(0x01)
	char bOverride_bEnableSmoothImpactDestruction : 1; // 0x01(0x01)
	char bOverride_bEnableSmoothImpactDestructionAdvanced : 1; // 0x01(0x01)
	char bOverride_bUseConnectedBonesForStrainAnchors : 1; // 0x02(0x01)
	char bOverride_bClusterStartAsSimulating : 1; // 0x02(0x01)
	char pad_2_2 : 6; // 0x02(0x01)
	bool bAutoGenerateConnections; // 0x03(0x01)
	bool bIsSupportive; // 0x04(0x01)
	bool bIsStrainSupportive; // 0x05(0x01)
	bool bIsDestructible; // 0x06(0x01)
	bool bSupportiveIfOnStableGround; // 0x07(0x01)
	bool bPruneDiagonalConnections; // 0x08(0x01)
	bool bEnableImpactDamage; // 0x09(0x01)
	bool bEnableSmoothImpactDestruction; // 0x0a(0x01)
	bool bEnableSmoothImpactDestructionAdvanced; // 0x0b(0x01)
	bool bUseConnectedBonesForStrainAnchors; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	struct FRotator DiagonalPruneRotationOffset; // 0x10(0x18)
	int32_t StrainGraphIndex; // 0x28(0x04)
	enum class EFracturedDestructibleStrainMode StrainMode; // 0x2c(0x01)
	char pad_2d[0x3]; // 0x2d(0x03)
	struct FName StrainPointVolumeIdentifier; // 0x30(0x08)
	bool bCutConnectionsToExternalStrainGraphs; // 0x38(0x01)
	enum class EMergeWithNeighbourMode MergeWithNeighbourMode; // 0x39(0x01)
	char pad_3a[0x6]; // 0x3a(0x06)
	struct FEmbarkFracturedDestructibleBoneRef MergeWithNeighbourOverride; // 0x40(0x30)
	bool bClusterStartAsSimulating; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
};

// ScriptStruct EmbarkFracturedDestructible.DestructionOverlapWiggleSettings
// Size: 0x0c (Inherited: 0x00)
struct FDestructionOverlapWiggleSettings {
	float WiggleAmount; // 0x00(0x04)
	bool bX; // 0x04(0x01)
	bool bY; // 0x05(0x01)
	bool bZ; // 0x06(0x01)
	bool bXY; // 0x07(0x01)
	bool bXZ; // 0x08(0x01)
	bool bZY; // 0x09(0x01)
	char pad_a[0x2]; // 0x0a(0x02)
};

// ScriptStruct EmbarkFracturedDestructible.SimpleDestructibleDestructionSettings
// Size: 0x48 (Inherited: 0x00)
struct FSimpleDestructibleDestructionSettings {
	char bOverride_bRegisterSimpleDestructibleWithDestructionGraph : 1; // 0x00(0x01)
	char bOverride_bUseBoundsOverlap : 1; // 0x00(0x01)
	char bOverride_bAttachToSimpleDestructibleParent : 1; // 0x00(0x01)
	char bOverride_bForceIsOnSupportiveGround : 1; // 0x00(0x01)
	char bOverride_bOnlyAttachToSimpleDestructibleParent : 1; // 0x00(0x01)
	char bOverride_BoundsInflateAmount : 1; // 0x00(0x01)
	char bOverride_BoundsOffset : 1; // 0x00(0x01)
	char bOverride_OverlapWiggleSettings : 1; // 0x00(0x01)
	char pad_1[0x1]; // 0x01(0x01)
	bool bRegisterSimpleDestructibleWithDestructionGraph; // 0x02(0x01)
	bool bUseBoundsOverlap; // 0x03(0x01)
	bool bAttachToSimpleDestructibleParent; // 0x04(0x01)
	bool bForceIsOnSupportiveGround; // 0x05(0x01)
	bool bOnlyAttachToSimpleDestructibleParent; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
	struct FVector BoundsInflateAmount; // 0x08(0x18)
	struct FVector BoundsOffset; // 0x20(0x18)
	struct FDestructionOverlapWiggleSettings OverlapWiggleSettings; // 0x38(0x0c)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkFracturedDestructible.StrainMaterialSettings
// Size: 0x40 (Inherited: 0x00)
struct FStrainMaterialSettings {
	double BendStrainWeighting; // 0x00(0x08)
	int32_t BendMagnitudeRescale; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	double TensionStrainWeighting; // 0x10(0x08)
	double CompressionStrainWeighting; // 0x18(0x08)
	double ShearStrainWeighting; // 0x20(0x08)
	double StrainBreakOffsetIncreaseByAverageScale; // 0x28(0x08)
	double StrainBreakOffsetTotal; // 0x30(0x08)
	double StrainBreakMultipleTotal; // 0x38(0x08)
};

// ScriptStruct EmbarkFracturedDestructible.StrainSettings
// Size: 0x60 (Inherited: 0x00)
struct FStrainSettings {
	enum class EFracturedStrainSolverType StrainSolverType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t MaxNrOfStrainBreaksPerSolve; // 0x04(0x04)
	int32_t SequentialSolverIterationCount; // 0x08(0x04)
	bool UseMedianForAverage; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	double NumericalSoftening; // 0x10(0x08)
	double NumericalNanGuard; // 0x18(0x08)
	struct FStrainMaterialSettings DefaultSettings; // 0x20(0x40)
};

// ScriptStruct EmbarkFracturedDestructible.FracturedDestructionReplicationSettings
// Size: 0x50 (Inherited: 0x00)
struct FFracturedDestructionReplicationSettings {
	struct FVector MaxBoneLocationBounds; // 0x00(0x18)
	struct FVector MinBoneLocationBounds; // 0x18(0x18)
	struct FIntVector FullChangeBitCountXYZ; // 0x30(0x0c)
	struct FIntVector SmallChangeBitCountXYZ; // 0x3c(0x0c)
	int32_t BitCountForSmallChangeRotation; // 0x48(0x04)
	int32_t BitCountForFullChangeRotation; // 0x4c(0x04)
};

