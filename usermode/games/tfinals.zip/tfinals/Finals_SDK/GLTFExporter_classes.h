// Class GLTFExporter.GLTFExportOptions
// Size: 0x110 (Inherited: 0xa0)
struct UGLTFExportOptions : UObject {
	float ExportUniformScale; // 0x98(0x04)
	bool bExportPreviewMesh; // 0x9c(0x01)
	bool bSkipNearDefaultValues; // 0x9d(0x01)
	bool bIncludeCopyrightNotice; // 0x9e(0x01)
	bool bExportProxyMaterials; // 0x9f(0x01)
	bool bExportUnlitMaterials; // 0xa0(0x01)
	bool bExportClearCoatMaterials; // 0xa1(0x01)
	bool bExportEmissiveStrength; // 0xa2(0x01)
	enum class EGLTFMaterialBakeMode BakeMaterialInputs; // 0xa3(0x01)
	enum class EGLTFMaterialBakeSizePOT DefaultMaterialBakeSize; // 0xa4(0x01)
	enum class TextureFilter DefaultMaterialBakeFilter; // 0xa5(0x01)
	enum class TextureAddress DefaultMaterialBakeTiling; // 0xa6(0x01)
	struct TMap<enum class EGLTFMaterialPropertyGroup, struct FGLTFOverrideMaterialBakeSettings> DefaultInputBakeSettings; // 0xa8(0x50)
	int32_t DefaultLevelOfDetail; // 0xf8(0x04)
	bool bExportVertexColors; // 0xfc(0x01)
	bool bExportVertexSkinWeights; // 0xfd(0x01)
	bool bUseMeshQuantization; // 0xfe(0x01)
	bool bExportLevelSequences; // 0xff(0x01)
	bool bExportAnimationSequences; // 0x100(0x01)
	enum class EGLTFTextureImageFormat TextureImageFormat; // 0x101(0x01)
	int32_t TextureImageQuality; // 0x104(0x04)
	bool bExportTextureTransforms; // 0x108(0x01)
	bool bAdjustNormalmaps; // 0x109(0x01)
	bool bExportHiddenInGame; // 0x10a(0x01)
	bool bExportLights; // 0x10b(0x01)
	bool bExportCameras; // 0x10c(0x01)
	enum class EGLTFMaterialVariantMode ExportMaterialVariants; // 0x10d(0x01)

	void ResetToDefault(); // Function GLTFExporter.GLTFExportOptions.ResetToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x9805020
};

// Class GLTFExporter.GLTFExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFExporter : UExporter {

	bool ExportToGLTF(struct UObject* Object, struct FString FilePath, struct UGLTFExportOptions* Options, struct TSet<struct AActor*>& SelectedActors, struct FGLTFExportMessages& OutMessages); // Function GLTFExporter.GLTFExporter.ExportToGLTF // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x980d050
};

// Class GLTFExporter.GLTFAnimSequenceExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFAnimSequenceExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFLevelExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFLevelExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFLevelSequenceExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFLevelSequenceExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFLevelVariantSetsExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFLevelVariantSetsExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFMaterialExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFMaterialExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFSkeletalMeshExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFSkeletalMeshExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFStaticMeshExporter
// Size: 0xf0 (Inherited: 0xf0)
struct UGLTFStaticMeshExporter : UGLTFExporter {
};

// Class GLTFExporter.GLTFProxyOptions
// Size: 0xf0 (Inherited: 0xa0)
struct UGLTFProxyOptions : UObject {
	bool bBakeMaterialInputs; // 0x98(0x01)
	enum class EGLTFMaterialBakeSizePOT DefaultMaterialBakeSize; // 0x99(0x01)
	enum class TextureFilter DefaultMaterialBakeFilter; // 0x9a(0x01)
	enum class TextureAddress DefaultMaterialBakeTiling; // 0x9b(0x01)
	struct TMap<enum class EGLTFMaterialPropertyGroup, struct FGLTFOverrideMaterialBakeSettings> DefaultInputBakeSettings; // 0xa0(0x50)

	void ResetToDefault(); // Function GLTFExporter.GLTFProxyOptions.ResetToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x9807380
};

// Class GLTFExporter.GLTFMaterialExportOptions
// Size: 0x100 (Inherited: 0xa0)
struct UGLTFMaterialExportOptions : UAssetUserData {
	struct UMaterialInterface* Proxy; // 0x98(0x08)
	struct FGLTFOverrideMaterialBakeSettings Default; // 0xa0(0x06)
	struct TMap<enum class EGLTFMaterialPropertyGroup, struct FGLTFOverrideMaterialBakeSettings> Inputs; // 0xa8(0x50)
	char pad_fe[0x2]; // 0xfe(0x02)
};

