// Class DataflowEngine.DataflowBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDataflowBlueprintLibrary : UBlueprintFunctionLibrary {

	void EvaluateTerminalNodeByName(struct UDataflow* Dataflow, struct FName TerminalNodeName, struct UObject* ResultAsset); // Function DataflowEngine.DataflowBlueprintLibrary.EvaluateTerminalNodeByName // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2568d40
};

// Class DataflowEngine.DataflowEdNode
// Size: 0x130 (Inherited: 0x110)
struct UDataflowEdNode : UEdGraphNode {
	char pad_110[0x18]; // 0x110(0x18)
	bool bRenderInAssetEditor; // 0x128(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class DataflowEngine.Dataflow
// Size: 0x120 (Inherited: 0xd0)
struct UDataflow : UEdGraph {
	char pad_d0[0x28]; // 0xd0(0x28)
	bool bActive; // 0xf8(0x01)
	char pad_f9[0x7]; // 0xf9(0x07)
	struct TArray<struct UObject*> Targets; // 0x100(0x10)
	struct UMaterial* Material; // 0x110(0x08)
	char pad_118[0x8]; // 0x118(0x08)
};

