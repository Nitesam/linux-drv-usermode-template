// Enum EmbarkHTTP.EEmbarkHttpCode
enum class EEmbarkHttpCode : int32_t {
	Unknown = 0,
	Continue = 100,
	SwitchProtocol = 101,
	Ok = 200,
	Created = 201,
	Accepted = 202,
	Partial = 203,
	NoContent = 204,
	ResetContent = 205,
	PartialContent = 206,
	Ambiguous = 300,
	Moved = 301,
	Redirect = 302,
	RedirectMethod = 303,
	NotModified = 304,
	UseProxy = 305,
	RedirectKeepVerb = 307,
	BadRequest = 400,
	Denied = 401,
	PaymentReq = 402,
	Forbidden = 403,
	NotFound = 404,
	BadMethod = 405,
	NoneAcceptable = 406,
	ProxyAuthReq = 407,
	RequestTimeout = 408,
	Conflict = 409,
	Gone = 410,
	LengthRequired = 411,
	PrecondFailed = 412,
	RequestTooLarge = 413,
	UriTooLong = 414,
	UnsupportedMedia = 415,
	StatusUpgradeRequired = 426,
	PreconditionRequired = 428,
	TooManyRequests = 429,
	RetryWith = 449,
	ClientClosedRequest = 499,
	ServerError = 500,
	NotSupported = 501,
	BadGateway = 502,
	ServiceUnavail = 503,
	GatewayTimeout = 504,
	VersionNotSup = 505,
	EEmbarkHttpCode_MAX = 506
};

// ScriptStruct EmbarkHTTP.EmbarkHttpError
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkHttpError {
	enum class EEmbarkHttpCode Code; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Message; // 0x08(0x10)
};

