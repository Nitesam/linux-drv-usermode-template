// Class Agones.AgonesComponent
// Size: 0x1d0 (Inherited: 0x160)
struct UAgonesComponent : UActorComponent {
	struct FString HttpPort; // 0x158(0x10)
	float HealthRateSeconds; // 0x168(0x04)
	bool bDisableAutoConnect; // 0x16c(0x01)
	struct FMulticastInlineDelegate ConnectedDelegate; // 0x170(0x10)
	char pad_185[0x4b]; // 0x185(0x4b)

	void WatchGameServer(struct FDelegate WatchDelegate); // Function Agones.AgonesComponent.WatchGameServer // (Final|Native|Public|BlueprintCallable) // @ game+0x536a6e0
	void Shutdown(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.Shutdown // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void SetPlayerCapacity(int64_t Count, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.SetPlayerCapacity // (Final|Native|Public|BlueprintCallable) // @ game+0x536a5c0
	void SetLabel(struct FString Key, struct FString Value, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.SetLabel // (Final|Native|Public|BlueprintCallable) // @ game+0x53688e0
	void SetAnnotation(struct FString Key, struct FString Value, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.SetAnnotation // (Final|Native|Public|BlueprintCallable) // @ game+0x53688e0
	void Reserve(int64_t Seconds, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.Reserve // (Final|Native|Public|BlueprintCallable) // @ game+0x536a5c0
	void Ready(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.Ready // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void PlayerDisconnect(struct FString PlayerId, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.PlayerDisconnect // (Final|Native|Public|BlueprintCallable) // @ game+0x5367f50
	void PlayerConnect(struct FString PlayerId, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.PlayerConnect // (Final|Native|Public|BlueprintCallable) // @ game+0x5367f50
	void IsPlayerConnected(struct FString PlayerId, struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.IsPlayerConnected // (Final|Native|Public|BlueprintCallable) // @ game+0x5367f50
	void HealthPing(float RateSeconds); // Function Agones.AgonesComponent.HealthPing // (Final|Native|Public|BlueprintCallable) // @ game+0x2e7fe30
	void Health(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.Health // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void GetPlayerCount(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.GetPlayerCount // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void GetPlayerCapacity(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.GetPlayerCapacity // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void GetConnectedPlayers(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.GetConnectedPlayers // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void GameServer(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.GameServer // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
	void ConnectSuccess(struct FGameServerResponse GameServerResponse); // Function Agones.AgonesComponent.ConnectSuccess // (Final|Native|Private) // @ game+0x5368b20
	void Connect(); // Function Agones.AgonesComponent.Connect // (Final|Native|Public|BlueprintCallable) // @ game+0x29fb8f0
	void Allocate(struct FDelegate SuccessDelegate, struct FDelegate ErrorDelegate); // Function Agones.AgonesComponent.Allocate // (Final|Native|Public|BlueprintCallable) // @ game+0x53681b0
};

// Class Agones.AgonesSubsystem
// Size: 0xd0 (Inherited: 0xa0)
struct UAgonesSubsystem : UEngineSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
	float TestShutdownTimeoutSeconds; // 0xb0(0x04)
	char pad_b4[0x4]; // 0xb4(0x04)
	struct FString HttpPort; // 0xb8(0x10)
	char pad_c8[0x8]; // 0xc8(0x08)
};

