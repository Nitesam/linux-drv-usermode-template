// ScriptStruct DataflowNodes.FloatOverrideDataflowNode
// Size: 0x100 (Inherited: 0xe8)
struct FFloatOverrideDataflowNode : FDataflowNode {
	struct FName PropertyName; // 0xe8(0x08)
	struct FName KeyName; // 0xf0(0x08)
	float ValueOut; // 0xf8(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)
};

// ScriptStruct DataflowNodes.SelectionSetDataflowNode
// Size: 0x108 (Inherited: 0xe8)
struct FSelectionSetDataflowNode : FDataflowNode {
	struct FString Indices; // 0xe8(0x10)
	struct TArray<int32_t> IndicesOut; // 0xf8(0x10)
};

// ScriptStruct DataflowNodes.GetSkeletalMeshDataflowNode
// Size: 0xf8 (Inherited: 0xe8)
struct FGetSkeletalMeshDataflowNode : FDataflowNode {
	struct USkeletalMesh* SkeletalMesh; // 0xe8(0x08)
	struct FName PropertyName; // 0xf0(0x08)
};

// ScriptStruct DataflowNodes.GetSkeletonDataflowNode
// Size: 0xf8 (Inherited: 0xe8)
struct FGetSkeletonDataflowNode : FDataflowNode {
	struct USkeleton* Skeleton; // 0xe8(0x08)
	struct FName PropertyName; // 0xf0(0x08)
};

// ScriptStruct DataflowNodes.SkeletalMeshBoneDataflowNode
// Size: 0x108 (Inherited: 0xe8)
struct FSkeletalMeshBoneDataflowNode : FDataflowNode {
	struct FName BoneName; // 0xe8(0x08)
	struct USkeletalMesh* SkeletalMesh; // 0xf0(0x08)
	int32_t BoneIndexOut; // 0xf8(0x04)
	struct FName PropertyName; // 0xfc(0x08)
	char pad_104[0x4]; // 0x104(0x04)
};

// ScriptStruct DataflowNodes.SkeletalMeshReferenceTransformDataflowNode
// Size: 0x160 (Inherited: 0xe8)
struct FSkeletalMeshReferenceTransformDataflowNode : FDataflowNode {
	struct USkeletalMesh* SkeletalMeshIn; // 0xe8(0x08)
	int32_t BoneIndexIn; // 0xf0(0x04)
	char pad_f4[0xc]; // 0xf4(0x0c)
	struct FTransform TransformOut; // 0x100(0x60)
};

// ScriptStruct DataflowNodes.GetStaticMeshDataflowNode
// Size: 0xf8 (Inherited: 0xe8)
struct FGetStaticMeshDataflowNode : FDataflowNode {
	struct UStaticMesh* StaticMesh; // 0xe8(0x08)
	struct FName PropertyName; // 0xf0(0x08)
};

