// Class Constraints.ConstraintsActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AConstraintsActor : AActor {
	struct UConstraintsManager* ConstraintsManager; // 0x398(0x08)
};

// Class Constraints.TickableConstraint
// Size: 0xf0 (Inherited: 0xa0)
struct UTickableConstraint : UObject {
	struct FConstraintTickFunction ConstraintTick; // 0x98(0x50)
	bool Active; // 0xe8(0x01)
};

// Class Constraints.ConstraintsManager
// Size: 0xc0 (Inherited: 0xa0)
struct UConstraintsManager : UObject {
	struct FMulticastSparseDelegate OnConstraintAdded_BP; // 0x98(0x01)
	struct FMulticastSparseDelegate OnConstraintRemoved_BP; // 0x99(0x01)
	char pad_a2[0x6]; // 0xa2(0x06)
	struct TArray<struct UTickableConstraint*> Constraints; // 0xa8(0x10)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class Constraints.ConstraintsScriptingLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstraintsScriptingLibrary : UBlueprintFunctionLibrary {

	bool RemoveThisConstraint(struct UWorld* InWorld, struct UTickableConstraint* InTickableConstraint); // Function Constraints.ConstraintsScriptingLibrary.RemoveThisConstraint // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x26cf640
	bool RemoveConstraint(struct UWorld* InWorld, int32_t InIndex); // Function Constraints.ConstraintsScriptingLibrary.RemoveConstraint // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x26ce940
	struct UConstraintsManager* GetManager(struct UWorld* InWorld); // Function Constraints.ConstraintsScriptingLibrary.GetManager // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x26bf930
	struct TArray<struct UTickableConstraint*> GetConstraintsArray(struct UWorld* InWorld); // Function Constraints.ConstraintsScriptingLibrary.GetConstraintsArray // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x26d1e20
	struct UTransformableHandle* CreateTransformableHandle(struct UWorld* InWorld, struct UObject* InObject, struct FName& InAttachmentName); // Function Constraints.ConstraintsScriptingLibrary.CreateTransformableHandle // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x26cd0c0
	struct UTransformableComponentHandle* CreateTransformableComponentHandle(struct UWorld* InWorld, struct USceneComponent* InSceneComponent, struct FName& InSocketName); // Function Constraints.ConstraintsScriptingLibrary.CreateTransformableComponentHandle // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x26c23f0
	struct UTickableTransformConstraint* CreateFromType(struct UWorld* InWorld, enum class ETransformConstraintType InType); // Function Constraints.ConstraintsScriptingLibrary.CreateFromType // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x26c3fa0
	bool AddConstraint(struct UWorld* InWorld, struct UTransformableHandle* InParentHandle, struct UTransformableHandle* InChildHandle, struct UTickableTransformConstraint* InConstraint, bool bMaintainOffset); // Function Constraints.ConstraintsScriptingLibrary.AddConstraint // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x26c2fb0
};

// Class Constraints.TransformableHandle
// Size: 0xd0 (Inherited: 0xa0)
struct UTransformableHandle : UObject {
	struct FMovieSceneObjectBindingID ConstraintBindingID; // 0x98(0x18)
	char pad_b8[0x18]; // 0xb8(0x18)
};

// Class Constraints.TransformableComponentHandle
// Size: 0xe0 (Inherited: 0xd0)
struct UTransformableComponentHandle : UTransformableHandle {
	struct TWeakObjectPtr<struct USceneComponent> Component; // 0xc8(0x08)
	struct FName SocketName; // 0xd0(0x08)
};

// Class Constraints.TickableTransformConstraint
// Size: 0x110 (Inherited: 0xf0)
struct UTickableTransformConstraint : UTickableConstraint {
	struct UTransformableHandle* ParentTRSHandle; // 0xf0(0x08)
	struct UTransformableHandle* ChildTRSHandle; // 0xf8(0x08)
	bool bMaintainOffset; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	float Weight; // 0x104(0x04)
	bool bDynamicOffset; // 0x108(0x01)
	enum class ETransformConstraintType Type; // 0x109(0x01)
	char pad_10a[0x6]; // 0x10a(0x06)
};

// Class Constraints.TickableTranslationConstraint
// Size: 0x140 (Inherited: 0x110)
struct UTickableTranslationConstraint : UTickableTransformConstraint {
	char pad_110[0x8]; // 0x110(0x08)
	struct FVector OffsetTranslation; // 0x118(0x18)
	struct FFilterOptionPerAxis AxisFilter; // 0x130(0x03)
	char pad_133[0xd]; // 0x133(0x0d)
};

// Class Constraints.TickableRotationConstraint
// Size: 0x150 (Inherited: 0x110)
struct UTickableRotationConstraint : UTickableTransformConstraint {
	char pad_110[0x10]; // 0x110(0x10)
	struct FQuat OffsetRotation; // 0x120(0x20)
	struct FFilterOptionPerAxis AxisFilter; // 0x140(0x03)
	char pad_143[0xd]; // 0x143(0x0d)
};

// Class Constraints.TickableScaleConstraint
// Size: 0x140 (Inherited: 0x110)
struct UTickableScaleConstraint : UTickableTransformConstraint {
	char pad_110[0x8]; // 0x110(0x08)
	struct FVector OffsetScale; // 0x118(0x18)
	struct FFilterOptionPerAxis AxisFilter; // 0x130(0x03)
	char pad_133[0xd]; // 0x133(0x0d)
};

// Class Constraints.TickableParentConstraint
// Size: 0x190 (Inherited: 0x110)
struct UTickableParentConstraint : UTickableTransformConstraint {
	char pad_110[0x10]; // 0x110(0x10)
	struct FTransform OffsetTransform; // 0x120(0x60)
	bool bScaling; // 0x180(0x01)
	struct FTransformFilter TransformFilter; // 0x181(0x09)
	char pad_18a[0x6]; // 0x18a(0x06)
};

// Class Constraints.TickableLookAtConstraint
// Size: 0x130 (Inherited: 0x110)
struct UTickableLookAtConstraint : UTickableTransformConstraint {
	struct FVector Axis; // 0x110(0x18)
	char pad_128[0x8]; // 0x128(0x08)
};

