// Enum StreamlineLatewarpBlueprint.EStreamlineLatewarpMode
enum class EStreamlineLatewarpMode : uint8_t {
	Off = 0,
	On = 1,
	EStreamlineLatewarpMode_MAX = 2
};

