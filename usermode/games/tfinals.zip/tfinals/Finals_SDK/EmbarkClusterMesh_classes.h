// Class EmbarkClusterMesh.EmbarkClusterMeshActor
// Size: 0x3f0 (Inherited: 0x3a0)
struct AEmbarkClusterMeshActor : AActor {
	struct TArray<struct FTransform> ClusterLocalTransforms; // 0x398(0x10)
	bool bPerformanceTestEnable; // 0x3a8(0x01)
	uint32_t PerformanceTestClusterCount; // 0x3ac(0x04)
	uint32_t PerformanceTestInstancesPerCluster; // 0x3b0(0x04)
	float PerformanceTestInstancesPerClusterRandomPercentage; // 0x3b4(0x04)
	float PerformanceTestTransformUpdatePercentage; // 0x3b8(0x04)
	float PerformanceTestClustersCreatedPerFrame; // 0x3bc(0x04)
	struct UEmbarkClusterMeshComponent* ClusterMeshComponent; // 0x3c0(0x08)
	char pad_3cd[0x23]; // 0x3cd(0x23)
};

// Class EmbarkClusterMesh.EmbarkClusterMeshComponent
// Size: 0x720 (Inherited: 0x6f0)
struct UEmbarkClusterMeshComponent : UMeshComponent {
	struct UStaticMesh* StaticMesh; // 0x6f0(0x08)
	char pad_6f8[0x28]; // 0x6f8(0x28)
};

// Class EmbarkClusterMesh.EmbarkClusterMeshSubsystem
// Size: 0x140 (Inherited: 0xa0)
struct UEmbarkClusterMeshSubsystem : UEngineSubsystem {
	char pad_a0[0xa0]; // 0xa0(0xa0)
};

// Class EmbarkClusterMesh.MaterialExpressionEmbarkClusterMeshPerInstanceCustomData
// Size: 0x150 (Inherited: 0x120)
struct UMaterialExpressionEmbarkClusterMeshPerInstanceCustomData : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0x120(0x28)
	float ConstDefaultValue; // 0x148(0x04)
	uint32_t DataIndex; // 0x14c(0x04)
};

// Class EmbarkClusterMesh.MaterialExpressionEmbarkClusterMeshPerInstanceCustomData4Vector
// Size: 0x170 (Inherited: 0x120)
struct UMaterialExpressionEmbarkClusterMeshPerInstanceCustomData4Vector : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0x120(0x28)
	char pad_148[0x8]; // 0x148(0x08)
	struct FVector4 ConstDefaultValue; // 0x150(0x20)
};

// Class EmbarkClusterMesh.MaterialExpressionEmbarkClusterMeshPerClusterCustomData
// Size: 0x150 (Inherited: 0x120)
struct UMaterialExpressionEmbarkClusterMeshPerClusterCustomData : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0x120(0x28)
	float ConstDefaultValue; // 0x148(0x04)
	uint32_t DataIndex; // 0x14c(0x04)
};

// Class EmbarkClusterMesh.MaterialExpressionEmbarkClusterMeshPerClusterCustomData4Vector
// Size: 0x180 (Inherited: 0x120)
struct UMaterialExpressionEmbarkClusterMeshPerClusterCustomData4Vector : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0x120(0x28)
	char pad_148[0x8]; // 0x148(0x08)
	struct FVector4 ConstDefaultValue; // 0x150(0x20)
	uint32_t DataIndex; // 0x170(0x04)
	char pad_174[0xc]; // 0x174(0x0c)
};

