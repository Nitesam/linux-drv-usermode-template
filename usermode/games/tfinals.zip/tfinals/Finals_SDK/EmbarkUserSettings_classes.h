// Class EmbarkUserSettings.EmbarkGameUserSettings
// Size: 0x290 (Inherited: 0x1c0)
struct UEmbarkGameUserSettings : UGameUserSettings {
	struct FMulticastInlineDelegate GameViewportResized; // 0x1c0(0x10)
	char pad_1d0[0x8]; // 0x1d0(0x08)
	uint32_t EmbarkVersion; // 0x1d8(0x04)
	enum class EStreamlineReflexMode NvReflexMode; // 0x1dc(0x01)
	enum class EStreamlineLatewarpMode ReflexLatewarpMode; // 0x1dd(0x01)
	bool bAntiLag2Enabled; // 0x1de(0x01)
	enum class EStreamlineDLSSGMode DLSSFrameGenerationMode; // 0x1df(0x01)
	enum class ESwapchainHookFeature LastUsedSwapchainHookFeature; // 0x1e0(0x01)
	enum class EResolutionScalingMethod ResolutionScalingMethod; // 0x1e1(0x01)
	bool bResolutionScalingMethodSelectedByUser; // 0x1e2(0x01)
	enum class EResolutionScaleMode ResolutionScaleMode; // 0x1e3(0x01)
	enum class UDLSSMode DLSSMode; // 0x1e4(0x01)
	enum class EDLSSModel DLSSModel; // 0x1e5(0x01)
	enum class EFSR3Mode FSR3Mode; // 0x1e6(0x01)
	enum class EFSR3FrameGenerationMode FSR3FrameGenerationMode; // 0x1e7(0x01)
	enum class EXeSSQualityMode XeSSMode; // 0x1e8(0x01)
	char pad_1e9[0x3]; // 0x1e9(0x03)
	float SecondaryResolutionScalePercentage; // 0x1ec(0x04)
	bool bConsole120HzModeEnabled; // 0x1f0(0x01)
	char pad_1f1[0x3]; // 0x1f1(0x03)
	float MotionBlurScale; // 0x1f4(0x04)
	enum class EMotionBlurMode MotionBlurMode; // 0x1f8(0x01)
	bool bMotionBlurModeSelectedByUser; // 0x1f9(0x01)
	bool LensDistortionEnabled; // 0x1fa(0x01)
	enum class ERTXGIQuality RTXGIQuality; // 0x1fb(0x01)
	int32_t RTXGIResolutionQuality; // 0x1fc(0x04)
	bool bIdleEnergySavingEnabled; // 0x200(0x01)
	bool bInactiveWindowEnergySavingEnabled; // 0x201(0x01)
	enum class EPerformanceOverlayMode PerformanceOverlayMode; // 0x202(0x01)
	char pad_203[0x6d]; // 0x203(0x6d)
	struct UEmbarkGameUserSettings* DefaultGameUserSettings; // 0x270(0x08)
	char pad_278[0x18]; // 0x278(0x18)

	void SetXeSSMode(enum class EXeSSQualityMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetXeSSMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b14690
	void SetSecondaryResolutionScalePercentage(float ScalePercentage); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetSecondaryResolutionScalePercentage // (Final|Native|Public|BlueprintCallable) // @ game+0x5b15e70
	void SetScalabilityOverrideLayer(struct FString LayerName); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetScalabilityOverrideLayer // (Final|Native|Public|BlueprintCallable) // @ game+0x5b13ec0
	void SetRTXGIResolutionQuality(int32_t Value); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetRTXGIResolutionQuality // (Final|Native|Public|BlueprintCallable) // @ game+0x5b14900
	void SetRTXGIQuality(enum class ERTXGIQuality Quality); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetRTXGIQuality // (Final|Native|Public|BlueprintCallable) // @ game+0x5b19950
	void SetResolutionScalingMethod(enum class EResolutionScalingMethod Method, bool bSetByUser); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetResolutionScalingMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x5b19ad0
	void SetResolutionScaleMode(enum class EResolutionScaleMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetResolutionScaleMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b158f0
	void SetReflexLatewarpMode(enum class EStreamlineLatewarpMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetReflexLatewarpMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b137f0
	void SetPerformanceOverlayMode(enum class EPerformanceOverlayMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetPerformanceOverlayMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b1a4c0
	void SetNvReflexMode(enum class EStreamlineReflexMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetNvReflexMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b19490
	void SetMotionBlurScale(float Scale); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetMotionBlurScale // (Final|Native|Public|BlueprintCallable) // @ game+0x5b12f40
	void SetMotionBlurMode(enum class EMotionBlurMode Mode, bool bSetByUser); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetMotionBlurMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b139b0
	void SetLensDistortionEnabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetLensDistortionEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b13130
	void SetInGameFullscreenMenuEnabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetInGameFullscreenMenuEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b1a3b0
	void SetInGameEnabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetInGameEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b13410
	void SetInactiveWindowEnergySavingEnabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetInactiveWindowEnergySavingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b19020
	void SetInActiveGameplay(bool bIsInActiveGameplay); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetInActiveGameplay // (Final|Native|Public|BlueprintCallable) // @ game+0x5b19d70
	void SetIdleEnergySavingEnabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetIdleEnergySavingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b16680
	void SetFSR3Mode(enum class EFSR3Mode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetFSR3Mode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b13210
	void SetFSR3FrameGenerationMode(enum class EFSR3FrameGenerationMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetFSR3FrameGenerationMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b15fc0
	void SetDLSSModel(enum class EDLSSModel Model); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetDLSSModel // (Final|Native|Public|BlueprintCallable) // @ game+0x5b14580
	void SetDLSSMode(enum class UDLSSMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetDLSSMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b12d40
	void SetDLSSFrameGenerationMode(enum class EStreamlineDLSSGMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetDLSSFrameGenerationMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5b18d70
	void SetD3D12Enabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetD3D12Enabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b132b0
	void SetConsole120HzModeEnabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetConsole120HzModeEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b13630
	void SetAntiLag2Enabled(bool bEnabled); // Function EmbarkUserSettings.EmbarkGameUserSettings.SetAntiLag2Enabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5b159f0
	void PrintSettings(); // Function EmbarkUserSettings.EmbarkGameUserSettings.PrintSettings // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x33aadf0
	bool IsXeSSSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsXeSSSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13750
	bool IsXeSSModeDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsXeSSModeDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b159c0
	bool IsXeSSLoaded(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsXeSSLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b168e0
	bool IsRTXGISoftwareRayTracingSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsRTXGISoftwareRayTracingSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13de0
	bool IsRTXGIResolutionQualityDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsRTXGIResolutionQualityDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14d20
	bool IsRTXGIQualityDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsRTXGIQualityDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b126c0
	bool IsResolutionScalingMethodDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsResolutionScalingMethodDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12d10
	bool IsReflexLatewarpSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsReflexLatewarpSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b18e60
	bool IsReflexLatewarpPendingRestart(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsReflexLatewarpPendingRestart // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14400
	bool IsRayTracingSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsRayTracingSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b18f10
	bool IsPerformanceOverlayDeveloperModeAvailable(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsPerformanceOverlayDeveloperModeAvailable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14f60
	bool IsPCSettingsAvailable(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsPCSettingsAvailable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x339d9b0
	bool IsNvReflexSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsNvReflexSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b18f40
	bool IsNvReflexModeDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsNvReflexModeDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19100
	bool IsMotionBlurSupportedBySelectedScalability(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsMotionBlurSupportedBySelectedScalability // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19d40
	bool IsMotionBlurSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsMotionBlurSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x339d9b0
	bool IsLensDistortionSupportedBySelectedScalability(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsLensDistortionSupportedBySelectedScalability // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14bf0
	bool IsLensDistortionSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsLensDistortionSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x339d9b0
	bool IsInGameEnabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsInGameEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b15050
	bool IsFSR3Supported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsFSR3Supported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b1a380
	bool IsFSR3ModeDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsFSR3ModeDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19fd0
	bool IsFSR3Loaded(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsFSR3Loaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b1a310
	bool IsFSR3FrameGenerationSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsFSR3FrameGenerationSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14510
	bool IsFSR3FrameGenerationPendingRestart(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsFSR3FrameGenerationPendingRestart // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19920
	bool IsFSR3FrameGenerationDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsFSR3FrameGenerationDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b16910
	bool IsDLSSSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12bf0
	bool IsDLSSModeDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSModeDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14cf0
	bool IsDLSSLoaded(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSLoaded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b143d0
	bool IsDLSSFrameGenerationSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSFrameGenerationSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13600
	bool IsDLSSFrameGenerationPendingRestart(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSFrameGenerationPendingRestart // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b126f0
	bool IsDLSSFrameGenerationLikelySupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSFrameGenerationLikelySupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14e40
	bool IsDLSSFrameGenerationDirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsDLSSFrameGenerationDirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12e90
	bool IsD3D12Supported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsD3D12Supported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12690
	bool IsD3D12Dirty(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsD3D12Dirty // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b18ff0
	bool IsConsole120HzModeSupported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsConsole120HzModeSupported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5198790
	bool IsAntiLag2Supported(); // Function EmbarkUserSettings.EmbarkGameUserSettings.IsAntiLag2Supported // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12ce0
	enum class EXeSSQualityMode GetXeSSMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetXeSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b15f10
	struct TArray<enum class EXeSSQualityMode> GetSupportedXeSSModes(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetSupportedXeSSModes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14a50
	struct TArray<enum class UDLSSMode> GetSupportedDLSSModes(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetSupportedDLSSModes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b193c0
	struct TArray<enum class EStreamlineDLSSGMode> GetSupportedDLSSFrameGenerationModes(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetSupportedDLSSFrameGenerationModes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14fc0
	float GetSecondaryResolutionScalePercentage(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetSecondaryResolutionScalePercentage // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b134b0
	float GetScreenPercentageForDLSSMode(enum class UDLSSMode Mode); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetScreenPercentageForDLSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14460
	int32_t GetRTXGIResolutionQuality(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetRTXGIResolutionQuality // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19e50
	enum class ERTXGIQuality GetRTXGIQuality(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetRTXGIQuality // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b158c0
	enum class EResolutionScalingMethod GetResolutionScalingMethod(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetResolutionScalingMethod // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14850
	enum class EResolutionScaleMode GetResolutionScaleMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetResolutionScaleMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b1a450
	enum class EStreamlineLatewarpMode GetReflexLatewarpMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetReflexLatewarpMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12e20
	enum class EPerformanceOverlayMode GetPerformanceOverlayMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetPerformanceOverlayMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14eb0
	enum class EStreamlineReflexMode GetNvReflexMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetNvReflexMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14430
	float GetMotionBlurScale(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetMotionBlurScale // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19c90
	enum class EMotionBlurMode GetMotionBlurMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetMotionBlurMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14a20
	bool GetLensDistortionEnabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetLensDistortionEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b15770
	bool GetInactiveWindowEnergySavingEnabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetInactiveWindowEnergySavingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cf6380
	bool GetIdleEnergySavingEnabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetIdleEnergySavingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19530
	enum class EFSR3Mode GetFSR3Mode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetFSR3Mode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14dd0
	enum class EFSR3FrameGenerationMode GetFSR3FrameGenerationMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetFSR3FrameGenerationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b18d10
	struct UEmbarkGameUserSettings* GetEmbarkGameUserSettingsWithDefaultSettings(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEmbarkGameUserSettingsWithDefaultSettings // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b19310
	enum class EXeSSQualityMode GetEffectiveXeSSMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveXeSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14ee0
	enum class ERTXGIQuality GetEffectiveRTXGIQuality(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveRTXGIQuality // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14620
	enum class EStreamlineLatewarpMode GetEffectiveReflexLatewarpMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveReflexLatewarpMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b199f0
	enum class EFSR3Mode GetEffectiveFSR3Mode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveFSR3Mode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13980
	enum class EFSR3FrameGenerationMode GetEffectiveFSR3FrameGenerationMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveFSR3FrameGenerationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19130
	enum class UDLSSMode GetEffectiveDLSSMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveDLSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19160
	enum class EStreamlineDLSSGMode GetEffectiveDLSSFrameGenerationMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetEffectiveDLSSFrameGenerationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b15ad0
	enum class EDLSSModel GetDLSSModel(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetDLSSModel // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b15990
	enum class UDLSSMode GetDLSSMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetDLSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b19e80
	enum class EStreamlineDLSSGMode GetDLSSFrameGenerationMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetDLSSFrameGenerationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13560
	enum class EResolutionScalingMethod GetDefaultResolutionScalingMethod(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetDefaultResolutionScalingMethod // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b14030
	enum class EMotionBlurMode GetDefaultMotionBlurMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetDefaultMotionBlurMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b15080
	bool GetD3D12Enabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetD3D12Enabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13950
	bool GetConsole120HzModeEnabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetConsole120HzModeEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12760
	enum class EXeSSQualityMode GetAppliedXeSSMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetAppliedXeSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13f80
	enum class ERTXGIQuality GetAppliedRTXGIQuality(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetAppliedRTXGIQuality // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b135d0
	enum class EFSR3Mode GetAppliedFSR3Mode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetAppliedFSR3Mode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b13e90
	enum class EFSR3FrameGenerationMode GetAppliedFSR3FrameGenerationMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetAppliedFSR3FrameGenerationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b12fe0
	enum class UDLSSMode GetAppliedDLSSMode(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetAppliedDLSSMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b1a5a0
	bool GetAntiLag2Enabled(); // Function EmbarkUserSettings.EmbarkGameUserSettings.GetAntiLag2Enabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5b16730
	struct UEmbarkGameUserSettings* Get(); // Function EmbarkUserSettings.EmbarkGameUserSettings.Get // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b14f90
	void AutoDetectScalabilitySettings(); // Function EmbarkUserSettings.EmbarkGameUserSettings.AutoDetectScalabilitySettings // (Final|Native|Public|BlueprintCallable) // @ game+0x5b19f70
	void ApplyAutoDetectedSettings(); // Function EmbarkUserSettings.EmbarkGameUserSettings.ApplyAutoDetectedSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x5b15820
};

// Class EmbarkUserSettings.EmbarkVideoSetting
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkVideoSetting : UIEmbarkUserSetting {
};

// Class EmbarkUserSettings.EmbarkFloatVideoSetting
// Size: 0xd0 (Inherited: 0xd0)
struct UEmbarkFloatVideoSetting : UIEmbarkOptionFloat {
};

// Class EmbarkUserSettings.ScalabilitySetting
// Size: 0x130 (Inherited: 0xb0)
struct UScalabilitySetting : UEmbarkVideoSetting {
	struct FScalabilityText Texts; // 0xb0(0x78)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class EmbarkUserSettings.WindowModeSetting
// Size: 0x100 (Inherited: 0xb0)
struct UWindowModeSetting : UEmbarkVideoSetting {
	struct FText FullScreenModeText; // 0xb0(0x18)
	struct FText WindowedModeText; // 0xc8(0x18)
	struct FText WindowedFullScreenModeText; // 0xe0(0x18)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class EmbarkUserSettings.ResolutionSetting
// Size: 0xc0 (Inherited: 0xb0)
struct UResolutionSetting : UEmbarkVideoSetting {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class EmbarkUserSettings.WindowResolutionSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UWindowResolutionSetting : UEmbarkVideoSetting {
	char pad_b0[0x10]; // 0xb0(0x10)
	struct FText CustomText; // 0xc0(0x18)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class EmbarkUserSettings.NvidiaDLSSFrameGenerationSetting
// Size: 0x140 (Inherited: 0xb0)
struct UNvidiaDLSSFrameGenerationSetting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText AutoText; // 0xc8(0x18)
	struct FText On2XText; // 0xe0(0x18)
	struct FText On3XText; // 0xf8(0x18)
	struct FText On4XText; // 0x110(0x18)
	char pad_128[0x18]; // 0x128(0x18)
};

// Class EmbarkUserSettings.FSR3FrameGenerationSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UFSR3FrameGenerationSetting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText EnabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.VSyncSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UVSyncSetting : UEmbarkVideoSetting {
	struct FText EnabledText; // 0xb0(0x18)
	struct FText DisabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.NvidiaReflexSetting
// Size: 0x100 (Inherited: 0xb0)
struct UNvidiaReflexSetting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText EnabledText; // 0xc8(0x18)
	struct FText EnabledBoostText; // 0xe0(0x18)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class EmbarkUserSettings.NvidiaReflexLatewarpSetting
// Size: 0xf0 (Inherited: 0xb0)
struct UNvidiaReflexLatewarpSetting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText EnabledText; // 0xc8(0x18)
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class EmbarkUserSettings.AntiLag2Setting
// Size: 0xe0 (Inherited: 0xb0)
struct UAntiLag2Setting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText EnabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.FrameRateLimitSetting
// Size: 0xf0 (Inherited: 0xd0)
struct UFrameRateLimitSetting : UEmbarkFloatVideoSetting {
	float MinLimit; // 0xd0(0x04)
	float MaxLimit; // 0xd4(0x04)
	struct FText UnlimitedText; // 0xd8(0x18)
};

// Class EmbarkUserSettings.Console120HzModeSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UConsole120HzModeSetting : UEmbarkVideoSetting {
	struct FText EnabledText; // 0xb0(0x18)
	struct FText DisabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.SecondaryResolutionScaleSetting
// Size: 0xd0 (Inherited: 0xd0)
struct USecondaryResolutionScaleSetting : UEmbarkFloatVideoSetting {
};

// Class EmbarkUserSettings.ResolutionScalingMethodSetting
// Size: 0x160 (Inherited: 0xb0)
struct UResolutionScalingMethodSetting : UEmbarkVideoSetting {
	struct FText NoAAText; // 0xb0(0x18)
	struct FText TAAUText; // 0xc8(0x18)
	struct FText TSRText; // 0xe0(0x18)
	struct FText DLSSText; // 0xf8(0x18)
	struct FText FSR3Text; // 0x110(0x18)
	struct FText XeSSText; // 0x128(0x18)
	char pad_140[0x20]; // 0x140(0x20)
};

// Class EmbarkUserSettings.NvidiaDLSSSetting
// Size: 0x190 (Inherited: 0xb0)
struct UNvidiaDLSSSetting : UEmbarkVideoSetting {
	struct FText OffText; // 0xb0(0x18)
	struct FText AutoText; // 0xc8(0x18)
	struct FText DLAAText; // 0xe0(0x18)
	struct FText UltraQualityText; // 0xf8(0x18)
	struct FText QualityText; // 0x110(0x18)
	struct FText BalancedText; // 0x128(0x18)
	struct FText PerformanceText; // 0x140(0x18)
	struct FText UltraPerformanceText; // 0x158(0x18)
	char pad_170[0x20]; // 0x170(0x20)
};

// Class EmbarkUserSettings.NvidiaDLSSModelSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UNvidiaDLSSModelSetting : UEmbarkVideoSetting {
	struct FText CNNText; // 0xb0(0x18)
	struct FText TransformerText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.FSR3TemporalUpscalingSetting
// Size: 0x150 (Inherited: 0xb0)
struct UFSR3TemporalUpscalingSetting : UEmbarkVideoSetting {
	struct FText NativeAAText; // 0xb0(0x18)
	struct FText QualityText; // 0xc8(0x18)
	struct FText BalancedText; // 0xe0(0x18)
	struct FText PerformanceText; // 0xf8(0x18)
	struct FText UltraPerformanceText; // 0x110(0x18)
	struct FText OffText; // 0x128(0x18)
	char pad_140[0x10]; // 0x140(0x10)
};

// Class EmbarkUserSettings.XeSSTemporalUpscalingSetting
// Size: 0x190 (Inherited: 0xb0)
struct UXeSSTemporalUpscalingSetting : UEmbarkVideoSetting {
	struct FText UltraPerformanceText; // 0xb0(0x18)
	struct FText PerformanceText; // 0xc8(0x18)
	struct FText BalancedText; // 0xe0(0x18)
	struct FText QualityText; // 0xf8(0x18)
	struct FText UltraQualityText; // 0x110(0x18)
	struct FText UltraQualityPlusText; // 0x128(0x18)
	struct FText AntiAliasingText; // 0x140(0x18)
	struct FText OffText; // 0x158(0x18)
	char pad_170[0x20]; // 0x170(0x20)
};

// Class EmbarkUserSettings.ResolutionScaleModeSetting
// Size: 0xf0 (Inherited: 0xb0)
struct UResolutionScaleModeSetting : UEmbarkVideoSetting {
	struct FText AutoText; // 0xb0(0x18)
	struct FText ManualText; // 0xc8(0x18)
	char pad_e0[0x10]; // 0xe0(0x10)
};

// Class EmbarkUserSettings.ResolutionScaleSetting
// Size: 0xf0 (Inherited: 0xd0)
struct UResolutionScaleSetting : UEmbarkFloatVideoSetting {
	struct FText AutoText; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class EmbarkUserSettings.MotionBlurModeSetting
// Size: 0x130 (Inherited: 0xb0)
struct UMotionBlurModeSetting : UEmbarkVideoSetting {
	struct FText OffText; // 0xb0(0x18)
	struct FText OnText; // 0xc8(0x18)
	struct FText ForegroundOnlyText; // 0xe0(0x18)
	struct FText FullText; // 0xf8(0x18)
	char pad_110[0x20]; // 0x110(0x20)
};

// Class EmbarkUserSettings.MotionBlurScaleSetting
// Size: 0xd0 (Inherited: 0xd0)
struct UMotionBlurScaleSetting : UEmbarkFloatVideoSetting {
};

// Class EmbarkUserSettings.LensDistortionSetting
// Size: 0xe0 (Inherited: 0xb0)
struct ULensDistortionSetting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText EnabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.NvidiaRTXGIScalabilitySetting
// Size: 0x170 (Inherited: 0xb0)
struct UNvidiaRTXGIScalabilitySetting : UEmbarkVideoSetting {
	struct FText StaticText; // 0xb0(0x18)
	struct FScalabilityText DynamicTexts; // 0xc8(0x78)
	struct FText DynamicSoftwareText; // 0x140(0x18)
	char pad_158[0x18]; // 0x158(0x18)
};

// Class EmbarkUserSettings.OverallScalabilitySetting
// Size: 0x140 (Inherited: 0x130)
struct UOverallScalabilitySetting : UScalabilitySetting {
	struct FText CustomQualityText; // 0x128(0x18)
};

// Class EmbarkUserSettings.ViewDistanceScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UViewDistanceScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.AntiAliasingScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UAntiAliasingScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.ShadowScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UShadowScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.PostProcessingScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UPostProcessingScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.TextureScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UTextureScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.EffectsScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UEffectsScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.ReflectionsScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UReflectionsScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.FoliageScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UFoliageScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.NvidiaRTXGIResolutionScalabilitySetting
// Size: 0x130 (Inherited: 0x130)
struct UNvidiaRTXGIResolutionScalabilitySetting : UScalabilitySetting {
};

// Class EmbarkUserSettings.RenderingModeSetting
// Size: 0xe0 (Inherited: 0xb0)
struct URenderingModeSetting : UEmbarkVideoSetting {
	struct FText EnabledText; // 0xb0(0x18)
	struct FText DisabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.PerformanceOverlaySetting
// Size: 0x100 (Inherited: 0xb0)
struct UPerformanceOverlaySetting : UEmbarkVideoSetting {
	struct FText DisabledText; // 0xb0(0x18)
	struct FText SimpleText; // 0xc8(0x18)
	struct FText DetailedText; // 0xe0(0x18)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class EmbarkUserSettings.IdleEnergySavingSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UIdleEnergySavingSetting : UEmbarkVideoSetting {
	struct FText EnabledText; // 0xb0(0x18)
	struct FText DisabledText; // 0xc8(0x18)
};

// Class EmbarkUserSettings.InactiveWindowEnergySavingSetting
// Size: 0xe0 (Inherited: 0xb0)
struct UInactiveWindowEnergySavingSetting : UEmbarkVideoSetting {
	struct FText EnabledText; // 0xb0(0x18)
	struct FText DisabledText; // 0xc8(0x18)
};

