// Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAutomationUtilsBlueprintLibrary : UBlueprintFunctionLibrary {

	void TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride); // Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x98193b0
};

