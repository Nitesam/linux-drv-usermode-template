// Class ActorSequence.ActorSequence
// Size: 0x100 (Inherited: 0xe0)
struct UActorSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0xd8(0x08)
	struct FActorSequenceObjectReferenceMap ObjectReferences; // 0xe0(0x20)
};

// Class ActorSequence.ActorSequenceComponent
// Size: 0x190 (Inherited: 0x160)
struct UActorSequenceComponent : UActorComponent {
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x158(0x20)
	struct UActorSequence* Sequence; // 0x178(0x08)
	struct UActorSequencePlayer* SequencePlayer; // 0x180(0x08)

	void StopSequence(); // Function ActorSequence.ActorSequenceComponent.StopSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x9b30ef0
	void PlaySequence(); // Function ActorSequence.ActorSequenceComponent.PlaySequence // (Final|Native|Public|BlueprintCallable) // @ game+0x9b2fdc0
	void PauseSequence(); // Function ActorSequence.ActorSequenceComponent.PauseSequence // (Final|Native|Public|BlueprintCallable) // @ game+0x9b2f980
};

// Class ActorSequence.ActorSequencePlayer
// Size: 0x540 (Inherited: 0x540)
struct UActorSequencePlayer : UMovieSceneSequencePlayer {
};

