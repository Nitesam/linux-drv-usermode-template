// Class EmbarkPropertyBag.PropertyBagLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPropertyBagLibrary : UBlueprintFunctionLibrary {

	void SetVector(struct UObject* WorldContextObject, struct FPropertyBagItem Item, struct FVector Value, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.SetVector // (Final|Native|Static|Public|HasDefaults) // @ game+0x8cdbdf0
	void SetQuat(struct UObject* WorldContextObject, struct FPropertyBagItem Item, struct FQuat Value, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.SetQuat // (Final|Native|Static|Public|HasDefaults) // @ game+0x8ce1990
	void SetInt(struct UObject* WorldContextObject, struct FPropertyBagItem Item, int32_t Value, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.SetInt // (Final|Native|Static|Public) // @ game+0x8cda7e0
	void SetFloat(struct UObject* WorldContextObject, struct FPropertyBagItem Item, float Value, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.SetFloat // (Final|Native|Static|Public) // @ game+0x8ce17b0
	void SetBool(struct UObject* WorldContextObject, struct FPropertyBagItem Item, bool bValue, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.SetBool // (Final|Native|Static|Public) // @ game+0x8cdbff0
	struct FPropertyBagItem New(struct UObject* WorldContextObject, enum class EPropertyBagItemType Type, int32_t Num); // Function EmbarkPropertyBag.PropertyBagLibrary.New // (Final|Native|Static|Public) // @ game+0x8ce1030
	struct FVector GetVector(struct UObject* WorldContextObject, struct FPropertyBagItem Item, struct FVector Default, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.GetVector // (Final|Native|Static|Public|HasDefaults) // @ game+0x8cdb830
	struct FQuat GetQuat(struct UObject* WorldContextObject, struct FPropertyBagItem Item, struct FQuat Default, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.GetQuat // (Final|Native|Static|Public|HasDefaults) // @ game+0x8cdb320
	int32_t GetInt(struct UObject* WorldContextObject, struct FPropertyBagItem Item, int32_t Default, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.GetInt // (Final|Native|Static|Public) // @ game+0x8ce1280
	float GetFloat(struct UObject* WorldContextObject, struct FPropertyBagItem Item, float Default, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.GetFloat // (Final|Native|Static|Public) // @ game+0x8ce0dd0
	bool GetBool(struct UObject* WorldContextObject, struct FPropertyBagItem Item, bool bDefault, int32_t Index); // Function EmbarkPropertyBag.PropertyBagLibrary.GetBool // (Final|Native|Static|Public) // @ game+0x8cdeb60
	void Delete(struct UObject* WorldContextObject, struct FPropertyBagItem& Item); // Function EmbarkPropertyBag.PropertyBagLibrary.Delete // (Final|Native|Static|Public|HasOutParms) // @ game+0x8cd9f20
};

// Class EmbarkPropertyBag.PropertyBagSubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UPropertyBagSubsystem : UWorldSubsystem {
	char pad_a0[0x60]; // 0xa0(0x60)
};

