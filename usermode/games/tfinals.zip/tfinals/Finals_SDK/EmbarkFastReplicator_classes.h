// Class EmbarkFastReplicator.EmbarkFastReplicatorRegisterTokenScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkFastReplicatorRegisterTokenScriptMixinLibrary : UObject {

	bool IsValid(struct FEmbarkFastReplicatorRegisterToken& Token); // Function EmbarkFastReplicator.EmbarkFastReplicatorRegisterTokenScriptMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a469d0
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorActorOrComponentScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkFastReplicatorActorOrComponentScriptMixinLibrary : UObject {

	bool IsValid(struct FEmbarkFastReplicatorActorOrComponent& Ref); // Function EmbarkFastReplicator.EmbarkFastReplicatorActorOrComponentScriptMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5d26ae0
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorInterface
// Size: 0x3a0 (Inherited: 0x3a0)
struct AEmbarkFastReplicatorInterface : AEmbarkGlobalActor {
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorBucket
// Size: 0x3b0 (Inherited: 0x3a0)
struct AEmbarkFastReplicatorBucket : AActor {
	char pad_3a0[0x10]; // 0x3a0(0x10)
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorBucketFastArray
// Size: 0x410 (Inherited: 0x3b0)
struct AEmbarkFastReplicatorBucketFastArray : AEmbarkFastReplicatorBucket {
	char pad_3b0[0x60]; // 0x3b0(0x60)
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorProxy
// Size: 0x3c0 (Inherited: 0x3a0)
struct AEmbarkFastReplicatorProxy : AActor {
	struct AEmbarkFastReplicator* OwnerReplicator; // 0x398(0x08)
	struct TArray<struct AEmbarkFastReplicatorBucket*> Buckets; // 0x3a0(0x10)
	char pad_3b8[0x8]; // 0x3b8(0x08)

	void OnRep_OwnerReplicator(); // Function EmbarkFastReplicator.EmbarkFastReplicatorProxy.OnRep_OwnerReplicator // (Final|Native|Private) // @ game+0x5d2abb0
	void OnRep_Buckets(); // Function EmbarkFastReplicator.EmbarkFastReplicatorProxy.OnRep_Buckets // (Final|Native|Private) // @ game+0x5d294f0
};

// Class EmbarkFastReplicator.EmbarkFastReplicator
// Size: 0x550 (Inherited: 0x3a0)
struct AEmbarkFastReplicator : AEmbarkFastReplicatorInterface {
	char pad_3a0[0x168]; // 0x3a0(0x168)
	struct TArray<struct FEmbarkFastReplicatorActorOrComponent> LeakDetection; // 0x508(0x10)
	char pad_518[0x38]; // 0x518(0x38)

	bool UnregisterInstance(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FEmbarkFastReplicatorRegisterToken& Token); // Function EmbarkFastReplicator.EmbarkFastReplicator.UnregisterInstance // (Final|Native|Public|HasOutParms) // @ game+0x5d22640
	bool RegisterInstanceComponent(struct UActorComponent* Component, struct FEmbarkFastReplicatorRegisterToken& Token); // Function EmbarkFastReplicator.EmbarkFastReplicator.RegisterInstanceComponent // (Final|Native|Public|HasOutParms) // @ game+0x5d26ba0
	bool RegisterInstanceActor(struct AActor* Actor, struct FEmbarkFastReplicatorRegisterToken& Token); // Function EmbarkFastReplicator.EmbarkFastReplicator.RegisterInstanceActor // (Final|Native|Public|HasOutParms) // @ game+0x5d2f310
	bool RegisterInstance(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FEmbarkFastReplicatorRegisterToken& Token); // Function EmbarkFastReplicator.EmbarkFastReplicator.RegisterInstance // (Final|Native|Public|HasOutParms) // @ game+0x5d27640
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorCallback
// Size: 0x5f0 (Inherited: 0x550)
struct AEmbarkFastReplicatorCallback : AEmbarkFastReplicator {
	char pad_550[0xa0]; // 0x550(0xa0)

	void UnregisterCallback_Client(struct FEmbarkFastReplicatorActorOrComponent& Ref); // Function EmbarkFastReplicator.EmbarkFastReplicatorCallback.UnregisterCallback_Client // (Final|Native|Public|HasOutParms) // @ game+0x5d2dc90
};

// Class EmbarkFastReplicator.TestEmbarkFastReplicatorBucketMockup
// Size: 0x3c0 (Inherited: 0x3b0)
struct ATestEmbarkFastReplicatorBucketMockup : AEmbarkFastReplicatorBucket {
	char pad_3b0[0x10]; // 0x3b0(0x10)
};

// Class EmbarkFastReplicator.TestEmbarkFastReplicatorMockup
// Size: 0x600 (Inherited: 0x5f0)
struct ATestEmbarkFastReplicatorMockup : AEmbarkFastReplicatorCallback {
	char pad_5f0[0x10]; // 0x5f0(0x10)

	void OnCallback(struct FEmbarkFastReplicatorActorOrComponent& Ref); // Function EmbarkFastReplicator.TestEmbarkFastReplicatorMockup.OnCallback // (Final|Native|Public|HasOutParms) // @ game+0x5d28540
};

// Class EmbarkFastReplicator.TestEmbarkFastReplicatorBucketFastArrayMockup
// Size: 0x540 (Inherited: 0x410)
struct ATestEmbarkFastReplicatorBucketFastArrayMockup : AEmbarkFastReplicatorBucketFastArray {
	struct FTestEmbarkFastArrayMockup Data; // 0x408(0x130)
};

// Class EmbarkFastReplicator.TestEmbarkFastReplicatorFastArrayMockup
// Size: 0x550 (Inherited: 0x550)
struct ATestEmbarkFastReplicatorFastArrayMockup : AEmbarkFastReplicator {
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorBucketTransform
// Size: 0x540 (Inherited: 0x410)
struct AEmbarkFastReplicatorBucketTransform : AEmbarkFastReplicatorBucketFastArray {
	struct FEmbarkFastArrayTransform Transforms; // 0x408(0x130)
};

// Class EmbarkFastReplicator.EmbarkFastReplicatorTransform
// Size: 0x5f0 (Inherited: 0x5f0)
struct AEmbarkFastReplicatorTransform : AEmbarkFastReplicatorCallback {

	void UpdateData_Server(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FReplicatedTransform& NewTransform); // Function EmbarkFastReplicator.EmbarkFastReplicatorTransform.UpdateData_Server // (Final|Native|Public|HasOutParms) // @ game+0x5d2c540
	void RegisterCallback_Client(struct FEmbarkFastReplicatorActorOrComponent& Ref, struct FDelegate Callback); // Function EmbarkFastReplicator.EmbarkFastReplicatorTransform.RegisterCallback_Client // (Final|Native|Public|HasOutParms) // @ game+0x5d260b0
};

