// Class Gridly.GridlyBPFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGridlyBPFunctionLibrary : UBlueprintFunctionLibrary {

	void UpdateLocalizationPreview(struct TArray<struct FPolyglotTextData>& PolyglotTextDatas); // Function Gridly.GridlyBPFunctionLibrary.UpdateLocalizationPreview // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x96eea50
	struct FString GetLocalizationPreviewCulture(); // Function Gridly.GridlyBPFunctionLibrary.GetLocalizationPreviewCulture // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x331fec0
	void EnableLocalizationPreview(struct FString Culture); // Function Gridly.GridlyBPFunctionLibrary.EnableLocalizationPreview // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x33d3c00
};

// Class Gridly.GridlyDataTable
// Size: 0x130 (Inherited: 0x120)
struct UGridlyDataTable : UDataTable {
	struct FString ViewId; // 0x120(0x10)
};

// Class Gridly.GridlyGameSettings
// Size: 0x1e0 (Inherited: 0xa0)
struct UGridlyGameSettings : UObject {
	struct FString ImportApiKey; // 0x98(0x10)
	struct TArray<struct FString> ImportFromViewIds; // 0xa8(0x10)
	int32_t ImportMaxRecordsPerRequest; // 0xb8(0x04)
	struct FString ExportApiKey; // 0xc0(0x10)
	struct FString ExportViewId; // 0xd0(0x10)
	int32_t ExportMaxRecordsPerRequest; // 0xe0(0x04)
	bool bUseCombinedNamespaceId; // 0xe4(0x01)
	bool bAlsoExportNamespaceColumn; // 0xe5(0x01)
	struct FString NamespaceColumnId; // 0xe8(0x10)
	struct FString SourceLanguageColumnIdPrefix; // 0xf8(0x10)
	struct FString TargetLanguageColumnIdPrefix; // 0x108(0x10)
	bool bUseCustomCultureMapping; // 0x118(0x01)
	char pad_11b[0x5]; // 0x11b(0x05)
	struct TMap<struct FString, struct FString> CustomCultureMapping; // 0x120(0x50)
	bool bExportContext; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct FString ContextColumnId; // 0x178(0x10)
	bool bExportMetadata; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	struct TMap<struct FString, struct FGridlyColumnInfo> MetadataMapping; // 0x190(0x50)
};

// Class Gridly.GridlyTask_DownloadLocalizedTexts
// Size: 0x150 (Inherited: 0xa0)
struct UGridlyTask_DownloadLocalizedTexts : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnProgress; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnFail; // 0xc0(0x10)
	char pad_d0[0x80]; // 0xd0(0x80)

	struct UGridlyTask_DownloadLocalizedTexts* DownloadLocalizedTexts(struct UObject* WorldContextObject); // Function Gridly.GridlyTask_DownloadLocalizedTexts.DownloadLocalizedTexts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x96f1ec0
};

// Class Gridly.GridlyTask_ImportDataTableFromGridly
// Size: 0x150 (Inherited: 0xa0)
struct UGridlyTask_ImportDataTableFromGridly : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate OnSuccess; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnProgress; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnFail; // 0xc0(0x10)
	char pad_d0[0x78]; // 0xd0(0x78)
	struct UGridlyDataTable* GridlyDataTable; // 0x148(0x08)

	struct UGridlyTask_ImportDataTableFromGridly* ImportDataTableFromGridly(struct UObject* WorldContextObject, struct UGridlyDataTable* GridlyDataTable); // Function Gridly.GridlyTask_ImportDataTableFromGridly.ImportDataTableFromGridly // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x96ff330
};

