// Enum AnimGraphRuntime.EBoneWeightAssetWeightMode
enum class EBoneWeightAssetWeightMode : uint8_t {
	Combined_TranslateRotateScale = 0,
	Split_Rotation = 1,
	EBoneWeightAssetWeightMode_MAX = 2
};

// Enum AnimGraphRuntime.EAnimLayerCurveBlendMode
enum class EAnimLayerCurveBlendMode : uint8_t {
	Blend = 0,
	Additive = 1,
	Override = 2,
	Ignored = 3,
	EAnimLayerCurveBlendMode_MAX = 4
};

// Enum AnimGraphRuntime.EAnimLayerAdditivePoseBlendMode
enum class EAnimLayerAdditivePoseBlendMode : uint8_t {
	LocalSpace = 0,
	MeshSpace = 1,
	EAnimLayerAdditivePoseBlendMode_MAX = 2
};

// Enum AnimGraphRuntime.EAnimLayerPoseBlendMode
enum class EAnimLayerPoseBlendMode : uint8_t {
	LocalSpace = 0,
	MeshSpace = 1,
	EAnimLayerPoseBlendMode_MAX = 2
};

// Enum AnimGraphRuntime.EBoneModificationMode
enum class EBoneModificationMode : uint8_t {
	BMM_Ignore = 0,
	BMM_Replace = 1,
	BMM_Additive = 2,
	BMM_MAX = 3
};

// Enum AnimGraphRuntime.ERefPoseType
enum class ERefPoseType : uint8_t {
	EIT_LocalSpace = 0,
	EIT_Additive = 1,
	EIT_MAX = 2
};

// Enum AnimGraphRuntime.EEasingFuncType
enum class EEasingFuncType : uint8_t {
	Linear = 0,
	Sinusoidal = 1,
	Cubic = 2,
	QuadraticInOut = 3,
	CubicInOut = 4,
	HermiteCubic = 5,
	QuarticInOut = 6,
	QuinticInOut = 7,
	CircularIn = 8,
	CircularOut = 9,
	CircularInOut = 10,
	ExpIn = 11,
	ExpOut = 12,
	ExpInOut = 13,
	CustomCurve = 14,
	EEasingFuncType_MAX = 15
};

// Enum AnimGraphRuntime.ERotationComponent
enum class ERotationComponent : uint8_t {
	EulerX = 0,
	EulerY = 1,
	EulerZ = 2,
	QuaternionAngle = 3,
	SwingAngle = 4,
	TwistAngle = 5,
	ERotationComponent_MAX = 6
};

// Enum AnimGraphRuntime.EBlendListTransitionType
enum class EBlendListTransitionType : uint8_t {
	StandardBlend = 0,
	Inertialization = 1,
	EBlendListTransitionType_MAX = 2
};

// Enum AnimGraphRuntime.EAnimFunctionCallSite
enum class EAnimFunctionCallSite : uint8_t {
	OnInitialize = 0,
	OnUpdate = 1,
	OnBecomeRelevant = 2,
	OnEvaluate = 3,
	OnInitializePostRecursion = 4,
	OnUpdatePostRecursion = 5,
	OnBecomeRelevantPostRecursion = 6,
	OnEvaluatePostRecursion = 7,
	OnStartedBlendingOut = 8,
	OnStartedBlendingIn = 9,
	OnFinishedBlendingOut = 10,
	OnFinishedBlendingIn = 11,
	EAnimFunctionCallSite_MAX = 12
};

// Enum AnimGraphRuntime.ELayeredBoneBlendMode
enum class ELayeredBoneBlendMode : uint8_t {
	BranchFilter = 0,
	BlendMask = 1,
	ELayeredBoneBlendMode_MAX = 2
};

// Enum AnimGraphRuntime.EModifyCurveApplyMode
enum class EModifyCurveApplyMode : uint8_t {
	Add = 0,
	Scale = 1,
	Blend = 2,
	WeightedMovingAverage = 3,
	RemapCurve = 4,
	EModifyCurveApplyMode_MAX = 5
};

// Enum AnimGraphRuntime.EPoseDriverType
enum class EPoseDriverType : uint8_t {
	SwingAndTwist = 0,
	SwingOnly = 1,
	Translation = 2,
	EPoseDriverType_MAX = 3
};

// Enum AnimGraphRuntime.EPoseDriverSource
enum class EPoseDriverSource : uint8_t {
	Rotation = 0,
	Translation = 1,
	EPoseDriverSource_MAX = 2
};

// Enum AnimGraphRuntime.EPoseDriverOutput
enum class EPoseDriverOutput : uint8_t {
	DrivePoses = 0,
	DriveCurves = 1,
	EPoseDriverOutput_MAX = 2
};

// Enum AnimGraphRuntime.ESnapshotSourceMode
enum class ESnapshotSourceMode : uint8_t {
	NamedSnapshot = 0,
	SnapshotPin = 1,
	ESnapshotSourceMode_MAX = 2
};

// Enum AnimGraphRuntime.ESequenceEvalReinit
enum class ESequenceEvalReinit : uint8_t {
	NoReset = 0,
	StartPosition = 1,
	ExplicitTime = 2,
	ESequenceEvalReinit_MAX = 3
};

// Enum AnimGraphRuntime.ESwapRootBone
enum class ESwapRootBone : uint8_t {
	SwapRootBone_Component = 0,
	SwapRootBone_Actor = 1,
	SwapRootBone_None = 2,
	SwapRootBone_MAX = 3
};

// Enum AnimGraphRuntime.AnimPhysAngularConstraintType
enum class AnimPhysAngularConstraintType : uint8_t {
	Angular = 0,
	Cone = 1,
	AnimPhysAngularConstraintType_MAX = 2
};

// Enum AnimGraphRuntime.AnimPhysLinearConstraintType
enum class AnimPhysLinearConstraintType : uint8_t {
	Free = 0,
	Limited = 1,
	AnimPhysLinearConstraintType_MAX = 2
};

// Enum AnimGraphRuntime.AnimPhysSimSpaceType
enum class AnimPhysSimSpaceType : uint8_t {
	Component = 0,
	Actor = 1,
	World = 2,
	RootRelative = 3,
	BoneRelative = 4,
	AnimPhysSimSpaceType_MAX = 5
};

// Enum AnimGraphRuntime.ESphericalLimitType
enum class ESphericalLimitType : uint8_t {
	Inner = 0,
	Outer = 1,
	ESphericalLimitType_MAX = 2
};

// Enum AnimGraphRuntime.EDrivenBoneModificationMode
enum class EDrivenBoneModificationMode : uint8_t {
	AddToInput = 0,
	ReplaceComponent = 1,
	AddToRefPose = 2,
	EDrivenBoneModificationMode_MAX = 3
};

// Enum AnimGraphRuntime.EDrivenDestinationMode
enum class EDrivenDestinationMode : uint8_t {
	Bone = 0,
	MorphTarget = 1,
	MaterialParameter = 2,
	EDrivenDestinationMode_MAX = 3
};

// Enum AnimGraphRuntime.EConstraintOffsetOption
enum class EConstraintOffsetOption : uint8_t {
	None = 0,
	Offset_RefPose = 1,
	EConstraintOffsetOption_MAX = 2
};

// Enum AnimGraphRuntime.CopyBoneDeltaMode
enum class CopyBoneDeltaMode : uint8_t {
	Accumulate = 0,
	Copy = 1,
	CopyBoneDeltaMode_MAX = 2
};

// Enum AnimGraphRuntime.EInterpolationBlend
enum class EInterpolationBlend : uint8_t {
	Linear = 0,
	Cubic = 1,
	Sinusoidal = 2,
	EaseInOutExponent2 = 3,
	EaseInOutExponent3 = 4,
	EaseInOutExponent4 = 5,
	EaseInOutExponent5 = 6,
	MAX = 7
};

// Enum AnimGraphRuntime.ESimulationSpace
enum class ESimulationSpace : uint8_t {
	ComponentSpace = 0,
	WorldSpace = 1,
	BaseBoneSpace = 2,
	ESimulationSpace_MAX = 3
};

// Enum AnimGraphRuntime.ESimulationTiming
enum class ESimulationTiming : uint8_t {
	Default = 0,
	Synchronous = 1,
	Deferred = 2,
	ESimulationTiming_MAX = 3
};

// Enum AnimGraphRuntime.EScaleChainInitialLength
enum class EScaleChainInitialLength : uint8_t {
	FixedDefaultLengthValue = 0,
	Distance = 1,
	ChainLength = 2,
	EScaleChainInitialLength_MAX = 3
};

// Enum AnimGraphRuntime.ESplineBoneAxis
enum class ESplineBoneAxis : uint8_t {
	None = 0,
	X = 1,
	Y = 2,
	Z = 3,
	ESplineBoneAxis_MAX = 4
};

// Enum AnimGraphRuntime.EWarpingEvaluationMode
enum class EWarpingEvaluationMode : uint8_t {
	Manual = 0,
	Graph = 1,
	EWarpingEvaluationMode_MAX = 2
};

// Enum AnimGraphRuntime.EWarpingVectorMode
enum class EWarpingVectorMode : uint8_t {
	ComponentSpaceVector = 0,
	ActorSpaceVector = 1,
	WorldSpaceVector = 2,
	IKFootRootLocalSpaceVector = 3,
	EWarpingVectorMode_MAX = 4
};

// Enum AnimGraphRuntime.ERBFSolverType
enum class ERBFSolverType : uint8_t {
	Additive = 0,
	Interpolative = 1,
	ERBFSolverType_MAX = 2
};

// Enum AnimGraphRuntime.ERBFFunctionType
enum class ERBFFunctionType : uint8_t {
	Gaussian = 0,
	Exponential = 1,
	Linear = 2,
	Cubic = 3,
	Quintic = 4,
	DefaultFunction = 5,
	ERBFFunctionType_MAX = 6
};

// Enum AnimGraphRuntime.ERBFDistanceMethod
enum class ERBFDistanceMethod : uint8_t {
	Euclidean = 0,
	Quaternion = 1,
	SwingAngle = 2,
	TwistAngle = 3,
	DefaultMethod = 4,
	ERBFDistanceMethod_MAX = 5
};

// Enum AnimGraphRuntime.ERBFNormalizeMethod
enum class ERBFNormalizeMethod : uint8_t {
	OnlyNormalizeAboveOne = 0,
	AlwaysNormalize = 1,
	NormalizeWithinMedian = 2,
	NoNormalization = 3,
	ERBFNormalizeMethod_MAX = 4
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceGraphBase
// Size: 0xa0 (Inherited: 0x48)
struct FAnimNode_BlendSpaceGraphBase : FAnimNode_Base {
	float X; // 0x48(0x04)
	float Y; // 0x4c(0x04)
	struct FName GroupName; // 0x50(0x08)
	enum class EAnimGroupRole GroupRole; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct UBlendSpace* BlendSpace; // 0x60(0x08)
	struct TArray<struct FPoseLink> SamplePoseLinks; // 0x68(0x10)
	char pad_78[0x28]; // 0x78(0x28)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceGraph
// Size: 0xa0 (Inherited: 0xa0)
struct FAnimNode_BlendSpaceGraph : FAnimNode_BlendSpaceGraphBase {
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceSampleResult
// Size: 0x58 (Inherited: 0x58)
struct FAnimNode_BlendSpaceSampleResult : FAnimNode_Root {
};

// ScriptStruct AnimGraphRuntime.CompactPoseBoneWeightsMapping
// Size: 0x10 (Inherited: 0x00)
struct FCompactPoseBoneWeightsMapping {
	struct TArray<struct FBoneWeightInfo> BoneWeights; // 0x00(0x10)
};

// ScriptStruct AnimGraphRuntime.BWABlendSettings
// Size: 0x10 (Inherited: 0x00)
struct FBWABlendSettings {
	float BlendTime; // 0x00(0x04)
	enum class EAlphaBlendOption BlendOption; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct UCurveFloat* CustomCurve; // 0x08(0x08)
};

// ScriptStruct AnimGraphRuntime.LayerDistanceLODBlender
// Size: 0x14 (Inherited: 0x00)
struct FLayerDistanceLODBlender {
	char pad_0[0x8]; // 0x00(0x08)
	float DistanceLODThreshold; // 0x08(0x04)
	float DistanceLODBlendTime; // 0x0c(0x04)
	bool bDriveDistanceLODThresholdAsPin; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimLayerSetup
// Size: 0xd8 (Inherited: 0x00)
struct FAnimLayerSetup {
	struct FName LayerName; // 0x00(0x08)
	struct FLayerDistanceLODBlender LayerDistanceLODBlender; // 0x08(0x14)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct TArray<struct UBoneWeightsAsset*> BoneWeightAssets; // 0x20(0x10)
	float BlendDuration; // 0x30(0x04)
	float HideLayerBlendDurationTrue; // 0x34(0x04)
	float HideLayerBlendDurationFalse; // 0x38(0x04)
	char pad_3c[0x8]; // 0x3c(0x08)
	bool bUseBWABlendSettings; // 0x44(0x01)
	bool bUseDynamicBoneWeights; // 0x45(0x01)
	char pad_46[0xa]; // 0x46(0x0a)
	struct UBoneWeightsAsset* CachedDynamicBoneWeight; // 0x50(0x08)
	char pad_58[0x78]; // 0x58(0x78)
	bool bAdditive; // 0xd0(0x01)
	enum class EAnimLayerPoseBlendMode PoseBlendMode; // 0xd1(0x01)
	enum class EAnimLayerAdditivePoseBlendMode AdditiveBlendMode; // 0xd2(0x01)
	bool bAlwaysUpdateCurve; // 0xd3(0x01)
	enum class EAnimLayerCurveBlendMode CurveBlendMode; // 0xd4(0x01)
	char pad_d5[0x3]; // 0xd5(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Layers
// Size: 0x140 (Inherited: 0x48)
struct FAnimNode_Layers : FAnimNode_Base {
	struct FName DebugNodeName; // 0x48(0x08)
	struct FName DebugHyperlinkPath; // 0x50(0x08)
	struct FPoseLink BasePose; // 0x58(0x10)
	float CurrentDistanceForLOD; // 0x68(0x04)
	char pad_6c[0x4]; // 0x6c(0x04)
	struct TArray<struct FPoseLink> BlendPoses; // 0x70(0x10)
	struct TArray<struct FAnimLayerSetup> Layers; // 0x80(0x10)
	struct TArray<float> Weight; // 0x90(0x10)
	struct TArray<bool> Hide; // 0xa0(0x10)
	struct TArray<int32_t> SelectedBoneWeightAsset; // 0xb0(0x10)
	struct TArray<struct FBWABlendSettings> BWABlendSettings; // 0xc0(0x10)
	struct TArray<float> DistanceLODThresholdPerLayer; // 0xd0(0x10)
	struct TArray<struct UBoneWeightsAsset*> DynamicBoneWeights; // 0xe0(0x10)
	struct TArray<struct UBoneWeightsAsset*> DynamicBWAToCachedIndex; // 0xf0(0x10)
	char pad_100[0x20]; // 0x100(0x20)
	int32_t LODThreshold; // 0x120(0x04)
	char pad_124[0x1c]; // 0x124(0x1c)
};

// ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// Size: 0x100 (Inherited: 0x48)
struct FAnimNode_SkeletalControlBase : FAnimNode_Base {
	struct FComponentSpacePoseLink ComponentPose; // 0x48(0x10)
	int32_t LODThreshold; // 0x58(0x04)
	float ActualAlpha; // 0x5c(0x04)
	enum class EAnimAlphaInputType AlphaInputType; // 0x60(0x01)
	bool bAlphaBoolEnabled; // 0x61(0x01)
	char pad_62[0x2]; // 0x62(0x02)
	float Alpha; // 0x64(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0x68(0x08)
	struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x70(0x48)
	struct FName AlphaCurveName; // 0xb8(0x08)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0xc0(0x30)
	char pad_f0[0x10]; // 0xf0(0x10)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// Size: 0x160 (Inherited: 0x100)
struct FAnimNode_ModifyBone : FAnimNode_SkeletalControlBase {
	struct FBoneReference BoneToModify; // 0x100(0x10)
	struct FVector Translation; // 0x110(0x18)
	struct FRotator Rotation; // 0x128(0x18)
	struct FVector Scale; // 0x140(0x18)
	enum class EBoneModificationMode TranslationMode; // 0x158(0x01)
	enum class EBoneModificationMode RotationMode; // 0x159(0x01)
	enum class EBoneModificationMode ScaleMode; // 0x15a(0x01)
	enum class EBoneControlSpace TranslationSpace; // 0x15b(0x01)
	enum class EBoneControlSpace RotationSpace; // 0x15c(0x01)
	enum class EBoneControlSpace ScaleSpace; // 0x15d(0x01)
	char pad_15e[0x2]; // 0x15e(0x02)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// Size: 0x48 (Inherited: 0x48)
struct FAnimNode_RefPose : FAnimNode_Base {
};

// ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// Size: 0x48 (Inherited: 0x48)
struct FAnimNode_MeshSpaceRefPose : FAnimNode_Base {
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// Size: 0x128 (Inherited: 0x100)
struct FAnimNode_RotationMultiplier : FAnimNode_SkeletalControlBase {
	struct FBoneReference TargetBone; // 0x100(0x10)
	struct FBoneReference SourceBone; // 0x110(0x10)
	float Multiplier; // 0x120(0x04)
	enum class EBoneAxis RotationAxisToRefer; // 0x124(0x01)
	bool bIsAdditive; // 0x125(0x01)
	char pad_126[0x2]; // 0x126(0x02)
};

// ScriptStruct AnimGraphRuntime.BlendSpaceReference
// Size: 0x10 (Inherited: 0x10)
struct FBlendSpaceReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.RotationRetargetingInfo
// Size: 0x1a0 (Inherited: 0x00)
struct FRotationRetargetingInfo {
	bool bEnabled; // 0x00(0x01)
	char pad_1[0xf]; // 0x01(0x0f)
	struct FTransform Source; // 0x10(0x60)
	struct FTransform Target; // 0x70(0x60)
	enum class ERotationComponent RotationComponent; // 0xd0(0x01)
	char pad_d1[0x7]; // 0xd1(0x07)
	struct FVector TwistAxis; // 0xd8(0x18)
	bool bUseAbsoluteAngle; // 0xf0(0x01)
	char pad_f1[0x3]; // 0xf1(0x03)
	float SourceMinimum; // 0xf4(0x04)
	float SourceMaximum; // 0xf8(0x04)
	float TargetMinimum; // 0xfc(0x04)
	float TargetMaximum; // 0x100(0x04)
	enum class EEasingFuncType EasingType; // 0x104(0x01)
	char pad_105[0x3]; // 0x105(0x03)
	struct FRuntimeFloatCurve CustomCurve; // 0x108(0x88)
	bool bFlipEasing; // 0x190(0x01)
	char pad_191[0x3]; // 0x191(0x03)
	float EasingWeight; // 0x194(0x04)
	bool bClamp; // 0x198(0x01)
	char pad_199[0x7]; // 0x199(0x07)
};

// ScriptStruct AnimGraphRuntime.PositionHistory
// Size: 0x30 (Inherited: 0x00)
struct FPositionHistory {
	struct TArray<struct FVector> Positions; // 0x00(0x10)
	float Range; // 0x10(0x04)
	char pad_14[0x1c]; // 0x14(0x1c)
};

// ScriptStruct AnimGraphRuntime.AnimationStateResultReference
// Size: 0x10 (Inherited: 0x10)
struct FAnimationStateResultReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.AnimationStateMachineReference
// Size: 0x10 (Inherited: 0x10)
struct FAnimationStateMachineReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayerBase
// Size: 0xa0 (Inherited: 0x70)
struct FAnimNode_BlendSpacePlayerBase : FAnimNode_AssetPlayerBase {
	char pad_70[0x28]; // 0x70(0x28)
	struct UBlendSpace* PreviousBlendSpace; // 0x98(0x08)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// Size: 0xa8 (Inherited: 0xa0)
struct FAnimNode_BlendSpacePlayer : FAnimNode_BlendSpacePlayerBase {
	struct UBlendSpace* BlendSpace; // 0xa0(0x08)
};

// ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// Size: 0x210 (Inherited: 0xa8)
struct FAnimNode_AimOffsetLookAt : FAnimNode_BlendSpacePlayer {
	char pad_a8[0xc8]; // 0xa8(0xc8)
	struct FPoseLink BasePose; // 0x170(0x10)
	int32_t LODThreshold; // 0x180(0x04)
	struct FName SourceSocketName; // 0x184(0x08)
	struct FName PivotSocketName; // 0x18c(0x08)
	char pad_194[0x4]; // 0x194(0x04)
	struct FVector LookAtLocation; // 0x198(0x18)
	struct FVector SocketAxis; // 0x1b0(0x18)
	float Alpha; // 0x1c8(0x04)
	char pad_1cc[0x44]; // 0x1cc(0x44)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// Size: 0x100 (Inherited: 0x48)
struct FAnimNode_ApplyAdditive : FAnimNode_Base {
	struct FPoseLink base; // 0x48(0x10)
	struct FPoseLink Additive; // 0x58(0x10)
	float Alpha; // 0x68(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0x6c(0x08)
	int32_t LODThreshold; // 0x74(0x04)
	struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x78(0x48)
	struct FName AlphaCurveName; // 0xc0(0x08)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0xc8(0x30)
	char pad_f8[0x4]; // 0xf8(0x04)
	enum class EAnimAlphaInputType AlphaInputType; // 0xfc(0x01)
	bool bAlphaBoolEnabled; // 0xfd(0x01)
	char pad_fe[0x2]; // 0xfe(0x02)
};

// ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// Size: 0x24 (Inherited: 0x00)
struct FBlendBoneByChannelEntry {
	struct FBoneReference SourceBone; // 0x00(0x10)
	struct FBoneReference TargetBone; // 0x10(0x10)
	bool bBlendTranslation; // 0x20(0x01)
	bool bBlendRotation; // 0x21(0x01)
	bool bBlendScale; // 0x22(0x01)
	char pad_23[0x1]; // 0x23(0x01)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// Size: 0xa0 (Inherited: 0x48)
struct FAnimNode_BlendBoneByChannel : FAnimNode_Base {
	struct FPoseLink A; // 0x48(0x10)
	struct FPoseLink B; // 0x58(0x10)
	struct TArray<struct FBlendBoneByChannelEntry> BoneDefinitions; // 0x68(0x10)
	char pad_78[0x10]; // 0x78(0x10)
	float Alpha; // 0x88(0x04)
	char pad_8c[0x4]; // 0x8c(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0x90(0x08)
	enum class EBoneControlSpace TransformsSpace; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// Size: 0x80 (Inherited: 0x48)
struct FAnimNode_BlendListBase : FAnimNode_Base {
	struct TArray<struct FPoseLink> BlendPose; // 0x48(0x10)
	char pad_58[0x28]; // 0x58(0x28)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// Size: 0x80 (Inherited: 0x80)
struct FAnimNode_BlendListByBool : FAnimNode_BlendListBase {
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// Size: 0x80 (Inherited: 0x80)
struct FAnimNode_BlendListByEnum : FAnimNode_BlendListBase {
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// Size: 0x80 (Inherited: 0x80)
struct FAnimNode_BlendListByInt : FAnimNode_BlendListBase {
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// Size: 0xb0 (Inherited: 0xa8)
struct FAnimNode_BlendSpaceEvaluator : FAnimNode_BlendSpacePlayer {
	float NormalizedTime; // 0xa8(0x04)
	bool bTeleportToNormalizedTime; // 0xac(0x01)
	char pad_ad[0x3]; // 0xad(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer_Standalone
// Size: 0xc8 (Inherited: 0xa0)
struct FAnimNode_BlendSpacePlayer_Standalone : FAnimNode_BlendSpacePlayerBase {
	struct FName GroupName; // 0xa0(0x08)
	enum class EAnimGroupRole GroupRole; // 0xa8(0x01)
	enum class EAnimSyncMethod Method; // 0xa9(0x01)
	bool bIgnoreForRelevancyTest; // 0xaa(0x01)
	char pad_ab[0x1]; // 0xab(0x01)
	float X; // 0xac(0x04)
	float Y; // 0xb0(0x04)
	float PlayRate; // 0xb4(0x04)
	bool bLoop; // 0xb8(0x01)
	bool bResetPlayTimeWhenBlendSpaceChanges; // 0xb9(0x01)
	char pad_ba[0x2]; // 0xba(0x02)
	float StartPosition; // 0xbc(0x04)
	struct UBlendSpace* BlendSpace; // 0xc0(0x08)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CallFunction
// Size: 0x70 (Inherited: 0x48)
struct FAnimNode_CallFunction : FAnimNode_Base {
	struct FPoseLink Source; // 0x48(0x10)
	char pad_58[0x14]; // 0x58(0x14)
	enum class EAnimFunctionCallSite CallSite; // 0x6c(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// Size: 0x190 (Inherited: 0x48)
struct FAnimNode_CopyPoseFromMesh : FAnimNode_Base {
	struct TWeakObjectPtr<struct USkeletalMeshComponent> SourceMeshComponent; // 0x48(0x08)
	char bUseAttachedParent : 1; // 0x50(0x01)
	char bCopyCurves : 1; // 0x50(0x01)
	char pad_50_2 : 6; // 0x50(0x01)
	bool bCopyCustomAttributes; // 0x51(0x01)
	char bUseMeshPose : 1; // 0x52(0x01)
	char pad_52_1 : 7; // 0x52(0x01)
	char pad_53[0x1]; // 0x53(0x01)
	struct FName RootBoneToCopy; // 0x54(0x08)
	char pad_5c[0x134]; // 0x5c(0x134)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// Size: 0x78 (Inherited: 0x48)
struct FAnimNode_CurveSource : FAnimNode_Base {
	struct FPoseLink SourcePose; // 0x48(0x10)
	struct FName SourceBinding; // 0x58(0x08)
	float Alpha; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
	struct TScriptInterface<ICurveSourceInterface> CurveSource; // 0x68(0x10)
};

// ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// Size: 0x128 (Inherited: 0x48)
struct FAnimNode_LayeredBoneBlend : FAnimNode_Base {
	struct FPoseLink BasePose; // 0x48(0x10)
	struct TArray<struct FPoseLink> BlendPoses; // 0x58(0x10)
	enum class ELayeredBoneBlendMode BlendMode; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct TArray<struct UBlendProfile*> BlendMasks; // 0x70(0x10)
	struct TArray<struct FInputBlendPose> LayerSetup; // 0x80(0x10)
	struct TArray<float> BlendWeights; // 0x90(0x10)
	bool bMeshSpaceRotationBlend; // 0xa0(0x01)
	bool bMeshSpaceScaleBlend; // 0xa1(0x01)
	enum class ECurveBlendOption CurveBlendOption; // 0xa2(0x01)
	bool bBlendRootMotionBasedOnRootBone; // 0xa3(0x01)
	char pad_a4[0x4]; // 0xa4(0x04)
	int32_t LODThreshold; // 0xa8(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights; // 0xb0(0x10)
	struct FGuid SkeletonGuid; // 0xc0(0x10)
	struct FGuid VirtualBoneGuid; // 0xd0(0x10)
	char pad_e0[0x48]; // 0xe0(0x48)
};

// ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// Size: 0x70 (Inherited: 0x48)
struct FAnimNode_MakeDynamicAdditive : FAnimNode_Base {
	struct FPoseLink base; // 0x48(0x10)
	struct FPoseLink Additive; // 0x58(0x10)
	bool bMeshSpaceAdditive; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// ScriptStruct AnimGraphRuntime.AnimNode_MirrorBase
// Size: 0x80 (Inherited: 0x48)
struct FAnimNode_MirrorBase : FAnimNode_Base {
	struct FPoseLink Source; // 0x48(0x10)
	char pad_58[0x28]; // 0x58(0x28)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Mirror
// Size: 0x80 (Inherited: 0x80)
struct FAnimNode_Mirror : FAnimNode_MirrorBase {
};

// ScriptStruct AnimGraphRuntime.AnimNode_Mirror_Standalone
// Size: 0x98 (Inherited: 0x80)
struct FAnimNode_Mirror_Standalone : FAnimNode_MirrorBase {
	bool bMirror; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct UMirrorDataTable* MirrorDataTable; // 0x88(0x08)
	float BlendTime; // 0x90(0x04)
	bool bResetChild; // 0x94(0x01)
	bool bBoneMirroring; // 0x95(0x01)
	bool bCurveMirroring; // 0x96(0x01)
	bool bAttributeMirroring; // 0x97(0x01)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// Size: 0x158 (Inherited: 0x48)
struct FAnimNode_ModifyCurve : FAnimNode_Base {
	struct FPoseLink SourcePose; // 0x48(0x10)
	struct TMap<struct FName, float> CurveMap; // 0x58(0x50)
	struct TArray<float> CurveValues; // 0xa8(0x10)
	struct TArray<struct FName> CurveNames; // 0xb8(0x10)
	char pad_c8[0x88]; // 0xc8(0x88)
	float Alpha; // 0x150(0x04)
	enum class EModifyCurveApplyMode ApplyMode; // 0x154(0x01)
	char pad_155[0x3]; // 0x155(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// Size: 0x88 (Inherited: 0x48)
struct FAnimNode_MultiWayBlend : FAnimNode_Base {
	struct TArray<struct FPoseLink> Poses; // 0x48(0x10)
	struct TArray<float> DesiredAlphas; // 0x58(0x10)
	char pad_68[0x10]; // 0x68(0x10)
	struct FInputScaleBias AlphaScaleBias; // 0x78(0x08)
	bool bAdditiveNode; // 0x80(0x01)
	bool bNormalizeAlpha; // 0x81(0x01)
	char pad_82[0x6]; // 0x82(0x06)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// Size: 0xd0 (Inherited: 0x70)
struct FAnimNode_PoseHandler : FAnimNode_AssetPlayerBase {
	struct UPoseAsset* PoseAsset; // 0x70(0x08)
	char pad_78[0x58]; // 0x78(0x58)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// Size: 0x108 (Inherited: 0xd0)
struct FAnimNode_PoseBlendNode : FAnimNode_PoseHandler {
	struct FPoseLink SourcePose; // 0xd0(0x10)
	enum class EAlphaBlendOption BlendOption; // 0xe0(0x01)
	char pad_e1[0x7]; // 0xe1(0x07)
	struct UCurveFloat* CustomCurve; // 0xe8(0x08)
	char pad_f0[0x18]; // 0xf0(0x18)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// Size: 0xe8 (Inherited: 0xd0)
struct FAnimNode_PoseByName : FAnimNode_PoseHandler {
	struct FName PoseName; // 0xd0(0x08)
	float PoseWeight; // 0xd8(0x04)
	char pad_dc[0xc]; // 0xdc(0x0c)
};

// ScriptStruct AnimGraphRuntime.PoseDriverTransform
// Size: 0x30 (Inherited: 0x00)
struct FPoseDriverTransform {
	struct FVector TargetTranslation; // 0x00(0x18)
	struct FRotator TargetRotation; // 0x18(0x18)
};

// ScriptStruct AnimGraphRuntime.PoseDriverTarget
// Size: 0xc8 (Inherited: 0x00)
struct FPoseDriverTarget {
	struct TArray<struct FPoseDriverTransform> BoneTransforms; // 0x00(0x10)
	struct FRotator TargetRotation; // 0x10(0x18)
	float TargetScale; // 0x28(0x04)
	enum class ERBFDistanceMethod DistanceMethod; // 0x2c(0x01)
	enum class ERBFFunctionType FunctionType; // 0x2d(0x01)
	bool bApplyCustomCurve; // 0x2e(0x01)
	char pad_2f[0x1]; // 0x2f(0x01)
	struct FRichCurve CustomCurve; // 0x30(0x80)
	struct FName DrivenName; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
	bool bIsHidden; // 0xc0(0x01)
	char pad_c1[0x7]; // 0xc1(0x07)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// Size: 0x1d8 (Inherited: 0xd0)
struct FAnimNode_PoseDriver : FAnimNode_PoseHandler {
	struct FPoseLink SourcePose; // 0xd0(0x10)
	struct TArray<struct FBoneReference> SourceBones; // 0xe0(0x10)
	struct FBoneReference EvalSpaceBone; // 0xf0(0x10)
	bool bEvalFromRefPose; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct TArray<struct FBoneReference> OnlyDriveBones; // 0x108(0x10)
	struct TArray<struct FPoseDriverTarget> PoseTargets; // 0x118(0x10)
	struct FRBFParams RBFParams; // 0x128(0x38)
	enum class EPoseDriverSource DriveSource; // 0x160(0x01)
	enum class EPoseDriverOutput DriveOutput; // 0x161(0x01)
	char pad_162[0x42]; // 0x162(0x42)
	int32_t LODThreshold; // 0x1a4(0x04)
	char pad_1a8[0x30]; // 0x1a8(0x30)
};

// ScriptStruct AnimGraphRuntime.RBFParams
// Size: 0x38 (Inherited: 0x00)
struct FRBFParams {
	int32_t TargetDimensions; // 0x00(0x04)
	enum class ERBFSolverType SolverType; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	float Radius; // 0x08(0x04)
	bool bAutomaticRadius; // 0x0c(0x01)
	enum class ERBFFunctionType Function; // 0x0d(0x01)
	enum class ERBFDistanceMethod DistanceMethod; // 0x0e(0x01)
	enum class EBoneAxis TwistAxis; // 0x0f(0x01)
	float WeightThreshold; // 0x10(0x04)
	enum class ERBFNormalizeMethod NormalizeMethod; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FVector MedianReference; // 0x18(0x18)
	float MedianMin; // 0x30(0x04)
	float MedianMax; // 0x34(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// Size: 0xc8 (Inherited: 0x48)
struct FAnimNode_PoseSnapshot : FAnimNode_Base {
	struct FName SnapshotName; // 0x48(0x08)
	struct FPoseSnapshot Snapshot; // 0x50(0x38)
	enum class ESnapshotSourceMode Mode; // 0x88(0x01)
	char pad_89[0x3f]; // 0x89(0x3f)
};

// ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// Size: 0x50 (Inherited: 0x00)
struct FRandomPlayerSequenceEntry {
	struct UAnimSequenceBase* Sequence; // 0x00(0x08)
	float ChanceToPlay; // 0x08(0x04)
	int32_t MinLoopCount; // 0x0c(0x04)
	int32_t MaxLoopCount; // 0x10(0x04)
	float MinPlayRate; // 0x14(0x04)
	float MaxPlayRate; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	struct FAlphaBlend BlendIn; // 0x20(0x30)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// Size: 0xb0 (Inherited: 0x48)
struct FAnimNode_RandomPlayer : FAnimNode_AssetPlayerRelevancyBase {
	struct TArray<struct FRandomPlayerSequenceEntry> Entries; // 0x48(0x10)
	char pad_58[0x50]; // 0x58(0x50)
	float BlendWeight; // 0xa8(0x04)
	bool bShuffleMode; // 0xac(0x01)
	char pad_ad[0x3]; // 0xad(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// Size: 0xe8 (Inherited: 0x48)
struct FAnimNode_RotateRootBone : FAnimNode_Base {
	struct FPoseLink BasePose; // 0x48(0x10)
	float Pitch; // 0x58(0x04)
	float Yaw; // 0x5c(0x04)
	struct FInputScaleBiasClamp PitchScaleBiasClamp; // 0x60(0x30)
	struct FInputScaleBiasClamp YawScaleBiasClamp; // 0x90(0x30)
	struct FRotator MeshToComponent; // 0xc0(0x18)
	bool bRotateRootMotionAttribute; // 0xd8(0x01)
	char pad_d9[0xf]; // 0xd9(0x0f)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// Size: 0x150 (Inherited: 0xa8)
struct FAnimNode_RotationOffsetBlendSpace : FAnimNode_BlendSpacePlayer {
	struct FPoseLink BasePose; // 0xa8(0x10)
	int32_t LODThreshold; // 0xb8(0x04)
	float Alpha; // 0xbc(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0xc0(0x08)
	struct FInputAlphaBoolBlend AlphaBoolBlend; // 0xc8(0x48)
	struct FName AlphaCurveName; // 0x110(0x08)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x118(0x30)
	char pad_148[0x4]; // 0x148(0x04)
	enum class EAnimAlphaInputType AlphaInputType; // 0x14c(0x01)
	bool bAlphaBoolEnabled; // 0x14d(0x01)
	char pad_14e[0x2]; // 0x14e(0x02)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpaceGraph
// Size: 0x148 (Inherited: 0xa0)
struct FAnimNode_RotationOffsetBlendSpaceGraph : FAnimNode_BlendSpaceGraphBase {
	struct FPoseLink BasePose; // 0xa0(0x10)
	int32_t LODThreshold; // 0xb0(0x04)
	float Alpha; // 0xb4(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0xb8(0x08)
	struct FInputAlphaBoolBlend AlphaBoolBlend; // 0xc0(0x48)
	struct FName AlphaCurveName; // 0x108(0x08)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0x110(0x30)
	char pad_140[0x4]; // 0x140(0x04)
	enum class EAnimAlphaInputType AlphaInputType; // 0x144(0x01)
	bool bAlphaBoolEnabled; // 0x145(0x01)
	char pad_146[0x2]; // 0x146(0x02)
};

// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluatorBase
// Size: 0x78 (Inherited: 0x70)
struct FAnimNode_SequenceEvaluatorBase : FAnimNode_AssetPlayerBase {
	char pad_70[0x8]; // 0x70(0x08)
};

// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// Size: 0x78 (Inherited: 0x78)
struct FAnimNode_SequenceEvaluator : FAnimNode_SequenceEvaluatorBase {
};

// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator_Standalone
// Size: 0xa0 (Inherited: 0x78)
struct FAnimNode_SequenceEvaluator_Standalone : FAnimNode_SequenceEvaluatorBase {
	struct FName GroupName; // 0x78(0x08)
	enum class EAnimGroupRole GroupRole; // 0x80(0x01)
	enum class EAnimSyncMethod Method; // 0x81(0x01)
	bool bIgnoreForRelevancyTest; // 0x82(0x01)
	char pad_83[0x5]; // 0x83(0x05)
	struct UAnimSequenceBase* Sequence; // 0x88(0x08)
	float ExplicitTime; // 0x90(0x04)
	bool bShouldLoop; // 0x94(0x01)
	bool bTeleportToExplicitTime; // 0x95(0x01)
	enum class ESequenceEvalReinit ReinitializationBehavior; // 0x96(0x01)
	char pad_97[0x1]; // 0x97(0x01)
	float StartPosition; // 0x98(0x04)
	char pad_9c[0x4]; // 0x9c(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Slot
// Size: 0x80 (Inherited: 0x48)
struct FAnimNode_Slot : FAnimNode_Base {
	struct FPoseLink Source; // 0x48(0x10)
	struct FName SlotName; // 0x58(0x08)
	bool bAlwaysUpdateSourcePose; // 0x60(0x01)
	char pad_61[0x1f]; // 0x61(0x1f)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Sync
// Size: 0x68 (Inherited: 0x48)
struct FAnimNode_Sync : FAnimNode_Base {
	struct FPoseLink Source; // 0x48(0x10)
	struct FName GroupName; // 0x58(0x08)
	enum class EAnimGroupRole GroupRole; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// Size: 0x100 (Inherited: 0x48)
struct FAnimNode_TwoWayBlend : FAnimNode_Base {
	struct FPoseLink A; // 0x48(0x10)
	struct FPoseLink B; // 0x58(0x10)
	enum class EAnimAlphaInputType AlphaInputType; // 0x68(0x01)
	char bAlphaBoolEnabled : 1; // 0x69(0x01)
	char pad_69_1 : 2; // 0x69(0x01)
	char bResetChildOnActivation : 1; // 0x69(0x01)
	char pad_69_4 : 4; // 0x69(0x01)
	char pad_6a[0x2]; // 0x6a(0x02)
	float Alpha; // 0x6c(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0x70(0x08)
	struct FInputAlphaBoolBlend AlphaBoolBlend; // 0x78(0x48)
	struct FName AlphaCurveName; // 0xc0(0x08)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp; // 0xc8(0x30)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// Size: 0xc40 (Inherited: 0x700)
struct FAnimSequencerInstanceProxy : FAnimInstanceProxy {
	char pad_700[0x540]; // 0x700(0x540)
};

// ScriptStruct AnimGraphRuntime.BlendListBaseReference
// Size: 0x10 (Inherited: 0x10)
struct FBlendListBaseReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.BlendSpacePlayerReference
// Size: 0x10 (Inherited: 0x10)
struct FBlendSpacePlayerReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// Size: 0x88 (Inherited: 0x00)
struct FAnimPhysConstraintSetup {
	enum class AnimPhysLinearConstraintType LinearXLimitType; // 0x00(0x01)
	enum class AnimPhysLinearConstraintType LinearYLimitType; // 0x01(0x01)
	enum class AnimPhysLinearConstraintType LinearZLimitType; // 0x02(0x01)
	char pad_3[0x5]; // 0x03(0x05)
	struct FVector LinearAxesMin; // 0x08(0x18)
	struct FVector LinearAxesMax; // 0x20(0x18)
	enum class AnimPhysAngularConstraintType AngularConstraintType; // 0x38(0x01)
	enum class AnimPhysTwistAxis TwistAxis; // 0x39(0x01)
	enum class AnimPhysTwistAxis AngularTargetAxis; // 0x3a(0x01)
	char pad_3b[0x1]; // 0x3b(0x01)
	float ConeAngle; // 0x3c(0x04)
	struct FVector AngularLimitsMin; // 0x40(0x18)
	struct FVector AngularLimitsMax; // 0x58(0x18)
	struct FVector AngularTarget; // 0x70(0x18)
};

// ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// Size: 0x70 (Inherited: 0x00)
struct FAnimPhysPlanarLimit {
	struct FBoneReference DrivingBone; // 0x00(0x10)
	struct FTransform PlaneTransform; // 0x10(0x60)
};

// ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// Size: 0x30 (Inherited: 0x00)
struct FAnimPhysSphericalLimit {
	struct FBoneReference DrivingBone; // 0x00(0x10)
	struct FVector SphereLocalOffset; // 0x10(0x18)
	float LimitRadius; // 0x28(0x04)
	enum class ESphericalLimitType LimitType; // 0x2c(0x01)
	char pad_2d[0x3]; // 0x2d(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimPhysBodyDefinition
// Size: 0xd0 (Inherited: 0x00)
struct FAnimPhysBodyDefinition {
	struct FBoneReference BoundBone; // 0x00(0x10)
	struct FVector BoxExtents; // 0x10(0x18)
	struct FVector LocalJointOffset; // 0x28(0x18)
	struct FAnimPhysConstraintSetup ConstraintSetup; // 0x40(0x88)
	enum class AnimPhysCollisionType CollisionType; // 0xc8(0x01)
	char pad_c9[0x3]; // 0xc9(0x03)
	float SphereCollisionRadius; // 0xcc(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// Size: 0x560 (Inherited: 0x100)
struct FAnimNode_AnimDynamics : FAnimNode_SkeletalControlBase {
	float LinearDampingOverride; // 0x100(0x04)
	float AngularDampingOverride; // 0x104(0x04)
	char pad_108[0xc8]; // 0x108(0xc8)
	struct FBoneReference RelativeSpaceBone; // 0x1d0(0x10)
	struct FBoneReference BoundBone; // 0x1e0(0x10)
	struct FBoneReference ChainEnd; // 0x1f0(0x10)
	struct TArray<struct FAnimPhysBodyDefinition> PhysicsBodyDefinitions; // 0x200(0x10)
	float GravityScale; // 0x210(0x04)
	char pad_214[0x4]; // 0x214(0x04)
	struct FVector GravityOverride; // 0x218(0x18)
	float LinearSpringConstant; // 0x230(0x04)
	float AngularSpringConstant; // 0x234(0x04)
	float WindScale; // 0x238(0x04)
	char pad_23c[0x4]; // 0x23c(0x04)
	struct FVector ComponentLinearAccScale; // 0x240(0x18)
	struct FVector ComponentLinearVelScale; // 0x258(0x18)
	struct FVector ComponentAppliedLinearAccClamp; // 0x270(0x18)
	float AngularBiasOverride; // 0x288(0x04)
	int32_t NumSolverIterationsPreUpdate; // 0x28c(0x04)
	int32_t NumSolverIterationsPostUpdate; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits; // 0x298(0x10)
	struct FVector ExternalForce; // 0x2a8(0x18)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // 0x2c0(0x10)
	enum class AnimPhysSimSpaceType SimulationSpace; // 0x2d0(0x01)
	char pad_2d1[0x2]; // 0x2d1(0x02)
	char bUseSphericalLimits : 1; // 0x2d3(0x01)
	char bUsePlanarLimit : 1; // 0x2d3(0x01)
	char bDoUpdate : 1; // 0x2d3(0x01)
	char bDoEval : 1; // 0x2d3(0x01)
	char bOverrideLinearDamping : 1; // 0x2d3(0x01)
	char bOverrideAngularBias : 1; // 0x2d3(0x01)
	char bOverrideAngularDamping : 1; // 0x2d3(0x01)
	char bEnableWind : 1; // 0x2d3(0x01)
	char pad_2d4_0 : 1; // 0x2d4(0x01)
	char bUseGravityOverride : 1; // 0x2d4(0x01)
	char bGravityOverrideInSimSpace : 1; // 0x2d4(0x01)
	char bLinearSpring : 1; // 0x2d4(0x01)
	char bAngularSpring : 1; // 0x2d4(0x01)
	char bChain : 1; // 0x2d4(0x01)
	char pad_2d4_6 : 2; // 0x2d4(0x01)
	char pad_2d5[0xb]; // 0x2d5(0x0b)
	struct FRotationRetargetingInfo RetargetingSettings; // 0x2e0(0x1a0)
	char pad_480[0xe0]; // 0x480(0xe0)
};

// ScriptStruct AnimGraphRuntime.AngularRangeLimit
// Size: 0x40 (Inherited: 0x00)
struct FAngularRangeLimit {
	struct FVector LimitMin; // 0x00(0x18)
	struct FVector LimitMax; // 0x18(0x18)
	struct FBoneReference bone; // 0x30(0x10)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ApplyLimits
// Size: 0x120 (Inherited: 0x100)
struct FAnimNode_ApplyLimits : FAnimNode_SkeletalControlBase {
	struct TArray<struct FAngularRangeLimit> AngularRangeLimits; // 0x100(0x10)
	struct TArray<struct FVector> AngularOffsets; // 0x110(0x10)
};

// ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// Size: 0x160 (Inherited: 0x100)
struct FAnimNode_BoneDrivenController : FAnimNode_SkeletalControlBase {
	struct FBoneReference SourceBone; // 0x100(0x10)
	struct UCurveFloat* DrivingCurve; // 0x110(0x08)
	float Multiplier; // 0x118(0x04)
	char pad_11c[0x4]; // 0x11c(0x04)
	double RangeMin; // 0x120(0x08)
	double RangeMax; // 0x128(0x08)
	double RemappedMin; // 0x130(0x08)
	double RemappedMax; // 0x138(0x08)
	struct FName ParameterName; // 0x140(0x08)
	struct FBoneReference TargetBone; // 0x148(0x10)
	enum class EDrivenDestinationMode DestinationMode; // 0x158(0x01)
	enum class EDrivenBoneModificationMode ModificationMode; // 0x159(0x01)
	enum class EComponentType SourceComponent; // 0x15a(0x01)
	char bUseRange : 1; // 0x15b(0x01)
	char bAffectTargetTranslationX : 1; // 0x15b(0x01)
	char bAffectTargetTranslationY : 1; // 0x15b(0x01)
	char bAffectTargetTranslationZ : 1; // 0x15b(0x01)
	char bAffectTargetRotationX : 1; // 0x15b(0x01)
	char bAffectTargetRotationY : 1; // 0x15b(0x01)
	char bAffectTargetRotationZ : 1; // 0x15b(0x01)
	char bAffectTargetScaleX : 1; // 0x15b(0x01)
	char bAffectTargetScaleY : 1; // 0x15c(0x01)
	char bAffectTargetScaleZ : 1; // 0x15c(0x01)
	char pad_15c_2 : 6; // 0x15c(0x01)
	char pad_15d[0x3]; // 0x15d(0x03)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CCDIK
// Size: 0x1f0 (Inherited: 0x100)
struct FAnimNode_CCDIK : FAnimNode_SkeletalControlBase {
	struct FVector EffectorLocation; // 0x100(0x18)
	enum class EBoneControlSpace EffectorLocationSpace; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
	struct FBoneSocketTarget EffectorTarget; // 0x120(0x90)
	struct FBoneReference TipBone; // 0x1b0(0x10)
	struct FBoneReference RootBone; // 0x1c0(0x10)
	float Precision; // 0x1d0(0x04)
	int32_t MaxIterations; // 0x1d4(0x04)
	bool bStartFromTail; // 0x1d8(0x01)
	bool bEnableRotationLimit; // 0x1d9(0x01)
	char pad_1da[0x6]; // 0x1da(0x06)
	struct TArray<float> RotationLimitPerJoints; // 0x1e0(0x10)
};

// ScriptStruct AnimGraphRuntime.Constraint
// Size: 0x1c (Inherited: 0x00)
struct FConstraint {
	struct FBoneReference TargetBone; // 0x00(0x10)
	enum class EConstraintOffsetOption OffsetOption; // 0x10(0x01)
	enum class ETransformConstraintType TransformType; // 0x11(0x01)
	struct FFilterOptionPerAxis PerAxis; // 0x12(0x03)
	char pad_15[0x7]; // 0x15(0x07)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// Size: 0x140 (Inherited: 0x100)
struct FAnimNode_Constraint : FAnimNode_SkeletalControlBase {
	struct FBoneReference BoneToModify; // 0x100(0x10)
	struct TArray<struct FConstraint> ConstraintSetup; // 0x110(0x10)
	struct TArray<float> ConstraintWeights; // 0x120(0x10)
	char pad_130[0x10]; // 0x130(0x10)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// Size: 0x128 (Inherited: 0x100)
struct FAnimNode_CopyBone : FAnimNode_SkeletalControlBase {
	struct FBoneReference SourceBone; // 0x100(0x10)
	struct FBoneReference TargetBone; // 0x110(0x10)
	bool bCopyTranslation; // 0x120(0x01)
	bool bCopyRotation; // 0x121(0x01)
	bool bCopyScale; // 0x122(0x01)
	enum class EBoneControlSpace ControlSpace; // 0x123(0x01)
	char pad_124[0x4]; // 0x124(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// Size: 0x130 (Inherited: 0x100)
struct FAnimNode_CopyBoneDelta : FAnimNode_SkeletalControlBase {
	struct FBoneReference SourceBone; // 0x100(0x10)
	struct FBoneReference TargetBone; // 0x110(0x10)
	bool bCopyTranslation; // 0x120(0x01)
	bool bCopyRotation; // 0x121(0x01)
	bool bCopyScale; // 0x122(0x01)
	enum class CopyBoneDeltaMode CopyMode; // 0x123(0x01)
	float TranslationMultiplier; // 0x124(0x04)
	float RotationMultiplier; // 0x128(0x04)
	float ScaleMultiplier; // 0x12c(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// Size: 0x220 (Inherited: 0x100)
struct FAnimNode_Fabrik : FAnimNode_SkeletalControlBase {
	struct FTransform EffectorTransform; // 0x100(0x60)
	struct FBoneSocketTarget EffectorTarget; // 0x160(0x90)
	struct FBoneReference TipBone; // 0x1f0(0x10)
	struct FBoneReference RootBone; // 0x200(0x10)
	float Precision; // 0x210(0x04)
	int32_t MaxIterations; // 0x214(0x04)
	enum class EBoneControlSpace EffectorTransformSpace; // 0x218(0x01)
	enum class EBoneRotationSource EffectorRotationSource; // 0x219(0x01)
	char pad_21a[0x6]; // 0x21a(0x06)
};

// ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// Size: 0x158 (Inherited: 0x100)
struct FAnimNode_HandIKRetargeting : FAnimNode_SkeletalControlBase {
	struct FBoneReference RightHandFK; // 0x100(0x10)
	struct FBoneReference LeftHandFK; // 0x110(0x10)
	struct FBoneReference RightHandIK; // 0x120(0x10)
	struct FBoneReference LeftHandIK; // 0x130(0x10)
	struct TArray<struct FBoneReference> IKBonesToMove; // 0x140(0x10)
	float HandFKWeight; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
};

// ScriptStruct AnimGraphRuntime.IKChainLink
// Size: 0x70 (Inherited: 0x00)
struct FIKChainLink {
	char pad_0[0x70]; // 0x00(0x70)
};

// ScriptStruct AnimGraphRuntime.IKChain
// Size: 0x50 (Inherited: 0x00)
struct FIKChain {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// Size: 0x34 (Inherited: 0x00)
struct FAnimLegIKDefinition {
	struct FBoneReference IKFootBone; // 0x00(0x10)
	struct FBoneReference FKFootBone; // 0x10(0x10)
	int32_t NumBonesInLimb; // 0x20(0x04)
	float MinRotationAngle; // 0x24(0x04)
	enum class EAxis FootBoneForwardAxis; // 0x28(0x01)
	enum class EAxis HingeRotationAxis; // 0x29(0x01)
	bool bEnableRotationLimit; // 0x2a(0x01)
	bool bEnableKneeTwistCorrection; // 0x2b(0x01)
	struct FName TwistOffsetCurveName; // 0x2c(0x08)
};

// ScriptStruct AnimGraphRuntime.AnimLegIKData
// Size: 0xf0 (Inherited: 0x00)
struct FAnimLegIKData {
	char pad_0[0xf0]; // 0x00(0xf0)
};

// ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// Size: 0x130 (Inherited: 0x100)
struct FAnimNode_LegIK : FAnimNode_SkeletalControlBase {
	float ReachPrecision; // 0x100(0x04)
	int32_t MaxIterations; // 0x104(0x04)
	struct TArray<struct FAnimLegIKDefinition> LegsDefinition; // 0x108(0x10)
	char pad_118[0x18]; // 0x118(0x18)
};

// ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// Size: 0x280 (Inherited: 0x100)
struct FAnimNode_LookAt : FAnimNode_SkeletalControlBase {
	struct FBoneReference BoneToModify; // 0x100(0x10)
	struct FBoneSocketTarget LookAtTarget; // 0x110(0x90)
	struct FVector LookAtLocation; // 0x1a0(0x18)
	struct FAxis LookAt_Axis; // 0x1b8(0x20)
	bool bUseLookUpAxis; // 0x1d8(0x01)
	enum class EInterpolationBlend InterpolationType; // 0x1d9(0x01)
	char pad_1da[0x6]; // 0x1da(0x06)
	struct FAxis LookUp_Axis; // 0x1e0(0x20)
	float LookAtClamp; // 0x200(0x04)
	float InterpolationTime; // 0x204(0x04)
	float InterpolationTriggerThreashold; // 0x208(0x04)
	char pad_20c[0x74]; // 0x20c(0x74)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// Size: 0x160 (Inherited: 0x100)
struct FAnimNode_ObserveBone : FAnimNode_SkeletalControlBase {
	struct FBoneReference BoneToObserve; // 0x100(0x10)
	enum class EBoneControlSpace DisplaySpace; // 0x110(0x01)
	bool bRelativeToRefPose; // 0x111(0x01)
	char pad_112[0x6]; // 0x112(0x06)
	struct FVector Translation; // 0x118(0x18)
	struct FRotator Rotation; // 0x130(0x18)
	struct FVector Scale; // 0x148(0x18)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ResetRoot
// Size: 0x110 (Inherited: 0x100)
struct FAnimNode_ResetRoot : FAnimNode_SkeletalControlBase {
	char pad_100[0x10]; // 0x100(0x10)
};

// ScriptStruct AnimGraphRuntime.SimSpaceSettings
// Size: 0x60 (Inherited: 0x00)
struct FSimSpaceSettings {
	float WorldAlpha; // 0x00(0x04)
	float VelocityScaleZ; // 0x04(0x04)
	float MaxLinearVelocity; // 0x08(0x04)
	float MaxAngularVelocity; // 0x0c(0x04)
	float MaxLinearAcceleration; // 0x10(0x04)
	float MaxAngularAcceleration; // 0x14(0x04)
	struct FVector ExternalLinearDragV; // 0x18(0x18)
	struct FVector ExternalLinearVelocity; // 0x30(0x18)
	struct FVector ExternalAngularVelocity; // 0x48(0x18)
};

// ScriptStruct AnimGraphRuntime.AnimNode_RigidBody
// Size: 0x9a0 (Inherited: 0x100)
struct FAnimNode_RigidBody : FAnimNode_SkeletalControlBase {
	struct UPhysicsAsset* OverridePhysicsAsset; // 0x100(0x08)
	char pad_108[0x130]; // 0x108(0x130)
	struct FVector OverrideWorldGravity; // 0x238(0x18)
	struct FVector ExternalForce; // 0x250(0x18)
	struct FVector ComponentLinearAccScale; // 0x268(0x18)
	struct FVector ComponentLinearVelScale; // 0x280(0x18)
	struct FVector ComponentAppliedLinearAccClamp; // 0x298(0x18)
	struct FSimSpaceSettings SimSpaceSettings; // 0x2b0(0x60)
	float CachedBoundsScale; // 0x310(0x04)
	struct FBoneReference BaseBoneRef; // 0x314(0x10)
	enum class ECollisionChannel OverlapChannel; // 0x324(0x01)
	enum class ESimulationSpace SimulationSpace; // 0x325(0x01)
	bool bForceDisableCollisionBetweenConstraintBodies; // 0x326(0x01)
	bool bUseExternalClothCollision; // 0x327(0x01)
	char pad_328[0x1]; // 0x328(0x01)
	char bEnableWorldGeometry : 1; // 0x329(0x01)
	char bOverrideWorldGravity : 1; // 0x329(0x01)
	char bTransferBoneVelocities : 1; // 0x329(0x01)
	char bFreezeIncomingPoseOnStart : 1; // 0x329(0x01)
	char bClampLinearTranslationLimitToRefPose : 1; // 0x329(0x01)
	char pad_329_5 : 3; // 0x329(0x01)
	char pad_32a[0x2]; // 0x32a(0x02)
	float WorldSpaceMinimumScale; // 0x32c(0x04)
	float EvaluationResetTime; // 0x330(0x04)
	char pad_334[0x1]; // 0x334(0x01)
	enum class ESimulationTiming SimulationTiming; // 0x335(0x01)
	char pad_336[0x66a]; // 0x336(0x66a)
};

// ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// Size: 0xc0 (Inherited: 0x48)
struct FAnimNode_ScaleChainLength : FAnimNode_Base {
	struct FPoseLink InputPose; // 0x48(0x10)
	float DefaultChainLength; // 0x58(0x04)
	struct FBoneReference ChainStartBone; // 0x5c(0x10)
	struct FBoneReference ChainEndBone; // 0x6c(0x10)
	char pad_7c[0x4]; // 0x7c(0x04)
	struct FVector TargetLocation; // 0x80(0x18)
	float Alpha; // 0x98(0x04)
	char pad_9c[0x4]; // 0x9c(0x04)
	struct FInputScaleBias AlphaScaleBias; // 0xa0(0x08)
	enum class EScaleChainInitialLength ChainInitialLength; // 0xa8(0x01)
	char pad_a9[0x17]; // 0xa9(0x17)
};

// ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// Size: 0x14 (Inherited: 0x00)
struct FSplineIKCachedBoneData {
	struct FBoneReference bone; // 0x00(0x10)
	int32_t RefSkeletonIndex; // 0x10(0x04)
};

// ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// Size: 0x2a8 (Inherited: 0x100)
struct FAnimNode_SplineIK : FAnimNode_SkeletalControlBase {
	struct FBoneReference StartBone; // 0x100(0x10)
	struct FBoneReference EndBone; // 0x110(0x10)
	enum class ESplineBoneAxis BoneAxis; // 0x120(0x01)
	bool bAutoCalculateSpline; // 0x121(0x01)
	char pad_122[0x2]; // 0x122(0x02)
	int32_t PointCount; // 0x124(0x04)
	struct TArray<struct FTransform> ControlPoints; // 0x128(0x10)
	float Roll; // 0x138(0x04)
	float TwistStart; // 0x13c(0x04)
	float TwistEnd; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct FAlphaBlend TwistBlend; // 0x148(0x30)
	float Stretch; // 0x178(0x04)
	float Offset; // 0x17c(0x04)
	char pad_180[0x128]; // 0x180(0x128)
};

// ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// Size: 0x1a0 (Inherited: 0x100)
struct FAnimNode_SpringBone : FAnimNode_SkeletalControlBase {
	struct FBoneReference SpringBone; // 0x100(0x10)
	double MaxDisplacement; // 0x110(0x08)
	double SpringStiffness; // 0x118(0x08)
	double SpringDamping; // 0x120(0x08)
	double ErrorResetThresh; // 0x128(0x08)
	char pad_130[0x6c]; // 0x130(0x6c)
	char bLimitDisplacement : 1; // 0x19c(0x01)
	char bTranslateX : 1; // 0x19c(0x01)
	char bTranslateY : 1; // 0x19c(0x01)
	char bTranslateZ : 1; // 0x19c(0x01)
	char bRotateX : 1; // 0x19c(0x01)
	char bRotateY : 1; // 0x19c(0x01)
	char bRotateZ : 1; // 0x19c(0x01)
	char pad_19c_7 : 1; // 0x19c(0x01)
	char pad_19d[0x3]; // 0x19d(0x03)
};

// ScriptStruct AnimGraphRuntime.RotationLimit
// Size: 0x30 (Inherited: 0x00)
struct FRotationLimit {
	struct FVector LimitMin; // 0x00(0x18)
	struct FVector LimitMax; // 0x18(0x18)
};

// ScriptStruct AnimGraphRuntime.AnimNode_Trail
// Size: 0x2d0 (Inherited: 0x100)
struct FAnimNode_Trail : FAnimNode_SkeletalControlBase {
	char pad_100[0x60]; // 0x100(0x60)
	struct FBoneReference TrailBone; // 0x160(0x10)
	int32_t ChainLength; // 0x170(0x04)
	enum class EAxis ChainBoneAxis; // 0x174(0x01)
	char bInvertChainBoneAxis : 1; // 0x175(0x01)
	char bLimitStretch : 1; // 0x175(0x01)
	char bLimitRotation : 1; // 0x175(0x01)
	char bUsePlanarLimit : 1; // 0x175(0x01)
	char bActorSpaceFakeVel : 1; // 0x175(0x01)
	char bReorientParentToChild : 1; // 0x175(0x01)
	char pad_175_6 : 2; // 0x175(0x01)
	char pad_176[0x2]; // 0x176(0x02)
	float MaxDeltaTime; // 0x178(0x04)
	float RelaxationSpeedScale; // 0x17c(0x04)
	struct FRuntimeFloatCurve TrailRelaxationSpeed; // 0x180(0x88)
	struct FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor; // 0x208(0x30)
	struct TArray<struct FRotationLimit> RotationLimits; // 0x238(0x10)
	struct TArray<struct FVector> RotationOffsets; // 0x248(0x10)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits; // 0x258(0x10)
	float StretchLimit; // 0x268(0x04)
	char pad_26c[0x4]; // 0x26c(0x04)
	struct FVector FakeVelocity; // 0x270(0x18)
	struct FBoneReference BaseJoint; // 0x288(0x10)
	float LastBoneRotationAnimAlphaBlend; // 0x298(0x04)
	char pad_29c[0x34]; // 0x29c(0x34)
};

// ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// Size: 0x30 (Inherited: 0x00)
struct FReferenceBoneFrame {
	struct FBoneReference bone; // 0x00(0x10)
	struct FAxis Axis; // 0x10(0x20)
};

// ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// Size: 0x1a0 (Inherited: 0x100)
struct FAnimNode_TwistCorrectiveNode : FAnimNode_SkeletalControlBase {
	struct FReferenceBoneFrame BaseFrame; // 0x100(0x30)
	struct FReferenceBoneFrame TwistFrame; // 0x130(0x30)
	struct FAxis TwistPlaneNormalAxis; // 0x160(0x20)
	float RangeMax; // 0x180(0x04)
	float RemappedMin; // 0x184(0x04)
	float RemappedMax; // 0x188(0x04)
	struct FName CurveName; // 0x18c(0x08)
	char pad_194[0xc]; // 0x194(0x0c)
};

// ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// Size: 0x2b0 (Inherited: 0x100)
struct FAnimNode_TwoBoneIK : FAnimNode_SkeletalControlBase {
	struct FBoneReference IKBone; // 0x100(0x10)
	double StartStretchRatio; // 0x110(0x08)
	double MaxStretchScale; // 0x118(0x08)
	struct FVector EffectorLocation; // 0x120(0x18)
	char pad_138[0x8]; // 0x138(0x08)
	struct FBoneSocketTarget EffectorTarget; // 0x140(0x90)
	struct FVector JointTargetLocation; // 0x1d0(0x18)
	char pad_1e8[0x8]; // 0x1e8(0x08)
	struct FBoneSocketTarget JointTarget; // 0x1f0(0x90)
	struct FAxis TwistAxis; // 0x280(0x20)
	enum class EBoneControlSpace EffectorLocationSpace; // 0x2a0(0x01)
	enum class EBoneControlSpace JointTargetLocationSpace; // 0x2a1(0x01)
	char bAllowStretching : 1; // 0x2a2(0x01)
	char bTakeRotationFromEffectorSpace : 1; // 0x2a2(0x01)
	char bMaintainEffectorRelRot : 1; // 0x2a2(0x01)
	char bAllowTwist : 1; // 0x2a2(0x01)
	char pad_2a2_4 : 4; // 0x2a2(0x01)
	char pad_2a3[0xd]; // 0x2a3(0x0d)
};

// ScriptStruct AnimGraphRuntime.IKFootPelvisPullDownSolver
// Size: 0x80 (Inherited: 0x00)
struct FIKFootPelvisPullDownSolver {
	struct FVectorRK4SpringInterpolator PelvisAdjustmentInterp; // 0x00(0x08)
	char pad_8[0x58]; // 0x08(0x58)
	double PelvisAdjustmentInterpAlpha; // 0x60(0x08)
	double PelvisAdjustmentMaxDistance; // 0x68(0x08)
	double PelvisAdjustmentErrorTolerance; // 0x70(0x08)
	int32_t PelvisAdjustmentMaxIter; // 0x78(0x04)
	char pad_7c[0x4]; // 0x7c(0x04)
};

// ScriptStruct AnimGraphRuntime.WarpingVectorValue
// Size: 0x20 (Inherited: 0x00)
struct FWarpingVectorValue {
	enum class EWarpingVectorMode Mode; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector Value; // 0x08(0x18)
};

// ScriptStruct AnimGraphRuntime.LayeredBoneBlendReference
// Size: 0x10 (Inherited: 0x10)
struct FLayeredBoneBlendReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.LinkedAnimGraphReference
// Size: 0x10 (Inherited: 0x10)
struct FLinkedAnimGraphReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.RBFEntry
// Size: 0x10 (Inherited: 0x00)
struct FRBFEntry {
	struct TArray<float> Values; // 0x00(0x10)
};

// ScriptStruct AnimGraphRuntime.RBFTarget
// Size: 0xa0 (Inherited: 0x10)
struct FRBFTarget : FRBFEntry {
	float ScaleFactor; // 0x10(0x04)
	bool bApplyCustomCurve; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FRichCurve CustomCurve; // 0x18(0x80)
	enum class ERBFDistanceMethod DistanceMethod; // 0x98(0x01)
	enum class ERBFFunctionType FunctionType; // 0x99(0x01)
	char pad_9a[0x6]; // 0x9a(0x06)
};

// ScriptStruct AnimGraphRuntime.SequenceEvaluatorReference
// Size: 0x10 (Inherited: 0x10)
struct FSequenceEvaluatorReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.SequencePlayerReference
// Size: 0x10 (Inherited: 0x10)
struct FSequencePlayerReference : FAnimNodeReference {
};

// ScriptStruct AnimGraphRuntime.SkeletalControlReference
// Size: 0x10 (Inherited: 0x10)
struct FSkeletalControlReference : FAnimNodeReference {
};

