// Enum EmbarkAbilitySystem.EEmbarkGameplayTagEventType
enum class EEmbarkGameplayTagEventType : uint8_t {
	NewOrRemoved = 0,
	AnyCountChange = 1,
	EEmbarkGameplayTagEventType_MAX = 2
};

// ScriptStruct EmbarkAbilitySystem.AdditionalEffectsWithSetByCallerData
// Size: 0x0c (Inherited: 0x00)
struct FAdditionalEffectsWithSetByCallerData {
	struct FGameplayTag Tag; // 0x00(0x08)
	float Magnitude; // 0x08(0x04)
};

// ScriptStruct EmbarkAbilitySystem.AdditionalEffectsWithSetByCallerEffects
// Size: 0x18 (Inherited: 0x00)
struct FAdditionalEffectsWithSetByCallerEffects {
	struct UGameplayEffect* GameplayEffect; // 0x00(0x08)
	struct TArray<struct FAdditionalEffectsWithSetByCallerData> Config; // 0x08(0x10)
};

// ScriptStruct EmbarkAbilitySystem.DelegateHandleHolder
// Size: 0x08 (Inherited: 0x00)
struct FDelegateHandleHolder {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct EmbarkAbilitySystem.EmbarkAttributeInitializerEntry
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkAttributeInitializerEntry {
	struct FGameplayAttribute Attribute; // 0x00(0x38)
	float DefaultValue; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
};

// ScriptStruct EmbarkAbilitySystem.EmbarkAttributeInitializerDefinition
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkAttributeInitializerDefinition {
	struct FGameplayAttribute Attribute; // 0x00(0x38)
	struct UAngelscriptAttributeSet* AttributeSetClass; // 0x38(0x08)
};

// ScriptStruct EmbarkAbilitySystem.EmbarkAttributeInitializer
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkAttributeInitializer {
	struct TArray<struct FEmbarkAttributeInitializerEntry> Internal_DefaultAttributeValues; // 0x00(0x10)
	struct TArray<struct FEmbarkAttributeInitializerDefinition> Attributes; // 0x10(0x10)
};

// ScriptStruct EmbarkAbilitySystem.EmbarkGameplayEffectContextGrantedCueParameters
// Size: 0xf8 (Inherited: 0x00)
struct FEmbarkGameplayEffectContextGrantedCueParameters {
	struct FGameplayCueParameters Parameters; // 0x00(0xf0)
	char pad_f0[0x8]; // 0xf0(0x08)
};

// ScriptStruct EmbarkAbilitySystem.EmbarkGameplayEffectContext
// Size: 0xe8 (Inherited: 0x80)
struct FEmbarkGameplayEffectContext : FGameplayEffectContext {
	struct TMap<struct FName, struct FEmbarkScriptStruct> ScriptStructMap; // 0x80(0x50)
	struct TArray<struct FEmbarkGameplayEffectContextGrantedCueParameters> GrantedCues; // 0xd0(0x10)
	struct TWeakObjectPtr<struct APlayerState> MinimalReplicationInstigatorPlayerState; // 0xe0(0x08)
};

// ScriptStruct EmbarkAbilitySystem.EmbarkScriptStructTargetData
// Size: 0x58 (Inherited: 0x08)
struct FEmbarkScriptStructTargetData : FGameplayAbilityTargetData {
	struct TMap<struct FName, struct FEmbarkScriptStruct> ScriptStructMap; // 0x08(0x50)
};

