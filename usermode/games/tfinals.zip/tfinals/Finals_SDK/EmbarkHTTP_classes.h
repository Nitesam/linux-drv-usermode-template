// Class EmbarkHTTP.EmbarkHttpContext
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkHttpContext : UObject {

	void SetGlobalManifestId(int64_t InManifestId); // Function EmbarkHTTP.EmbarkHttpContext.SetGlobalManifestId // (Final|Native|Static|Public) // @ game+0x44b6fd0
	void SetGlobalDevInstanceKey(struct FString Key); // Function EmbarkHTTP.EmbarkHttpContext.SetGlobalDevInstanceKey // (Final|Native|Static|Public) // @ game+0x33d3c00
	int64_t GetManifestId(); // Function EmbarkHTTP.EmbarkHttpContext.GetManifestId // (Final|Native|Public|Const) // @ game+0x44b9300
	struct FString GetDevInstanceKey(); // Function EmbarkHTTP.EmbarkHttpContext.GetDevInstanceKey // (Final|Native|Public|Const) // @ game+0x44b86c0
};

// Class EmbarkHTTP.EmbarkHttpUtilsLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkHttpUtilsLibrary : UBlueprintFunctionLibrary {

	struct FString HttpCodeToString(int32_t HttpCode); // Function EmbarkHTTP.EmbarkHttpUtilsLibrary.HttpCodeToString // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x44b1f40
	int32_t GetHttpError(struct FEmbarkHttpError& InError); // Function EmbarkHTTP.EmbarkHttpUtilsLibrary.GetHttpError // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x44b31e0
	struct FEmbarkHttpError CreateError(int32_t HttpCode, struct FString Message); // Function EmbarkHTTP.EmbarkHttpUtilsLibrary.CreateError // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x44b2ab0
};

