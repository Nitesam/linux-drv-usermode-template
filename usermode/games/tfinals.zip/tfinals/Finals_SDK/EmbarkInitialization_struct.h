// Enum EmbarkInitialization.EEmbarkInitializationFlags
enum class EEmbarkInitializationFlags : uint8_t {
	None = 0,
	ReturnLocalPlayer = 2,
	ObjectContextOnly = 4,
	EEmbarkInitializationFlags_MAX = 5
};

// ScriptStruct EmbarkInitialization.EmbarkInitializationContext
// Size: 0x68 (Inherited: 0x00)
struct FEmbarkInitializationContext {
	struct FString RemainingInitialization; // 0x00(0x10)
	struct UObject* ObjectContext; // 0x10(0x08)
	struct AController* BaseController; // 0x18(0x08)
	struct APlayerController* Controller; // 0x20(0x08)
	struct APlayerState* PlayerState; // 0x28(0x08)
	struct AGameStateBase* GameStateBase; // 0x30(0x08)
	struct APawn* Pawn; // 0x38(0x08)
	struct ULocalPlayer* LocalPlayer; // 0x40(0x08)
	struct APlayerController* LocalPlayerController; // 0x48(0x08)
	int32_t AdditionalRequested; // 0x50(0x04)
	int32_t CurrentAdditionalInitializationDone; // 0x54(0x04)
	enum class ENetRole RelevantInitializationRole; // 0x58(0x01)
	bool bIsAdditionalInitializationDone; // 0x59(0x01)
	bool bIsBaseDone; // 0x5a(0x01)
	bool bIsCustomInitializationComplete; // 0x5b(0x01)
	enum class EEmbarkInitializationFlags InitializationFlags; // 0x5c(0x01)
	char pad_5d[0x3]; // 0x5d(0x03)
	float TimeoutSeconds; // 0x60(0x04)
	char pad_64[0x4]; // 0x64(0x04)
};

// ScriptStruct EmbarkInitialization.EmbarkInitializationRequestKey
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkInitializationRequestKey {
	struct UObject* ObjectContext; // 0x00(0x08)
	struct UEmbarkInitializationExtensionObject* AdditionalExtensionObject; // 0x08(0x08)
	struct FName ObjectContextName; // 0x10(0x08)
	int32_t RequestedInitialization; // 0x18(0x04)
	struct FName AdditionalExtensionName; // 0x1c(0x08)
	enum class EEmbarkInitializationFlags InitializationFlags; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	float TimeoutSeconds; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
};

// ScriptStruct EmbarkInitialization.EmbarkInitializationRequestEntry
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkInitializationRequestEntry {
	char pad_0[0x10]; // 0x00(0x10)
	struct FDelegate BlueprintScriptDelegate; // 0x10(0x10)
};

// ScriptStruct EmbarkInitialization.EmbarkInitializationRequestValueArrayWrapper
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkInitializationRequestValueArrayWrapper {
	struct FDateTime TimeRequested; // 0x00(0x08)
	struct FEmbarkInitializationContext LastEvaluationContext; // 0x08(0x68)
	struct TArray<struct FEmbarkInitializationRequestEntry> Value; // 0x70(0x10)
};

