// Enum RTXGI.EDDGIRaysPerProbe
enum class EDDGIRaysPerProbe : int32_t {
	n144 = 144,
	n288 = 288,
	n432 = 432,
	n576 = 576,
	n720 = 720,
	n864 = 864,
	n1008 = 1008,
	EDDGIRaysPerProbe_MAX = 1009
};

// Enum RTXGI.ERTXGIQualityPreset
enum class ERTXGIQualityPreset : uint8_t {
	LOW = 0,
	MEDIUM = 1,
	HIGH = 2,
	EPIC = 3,
	SOFTWARE = 4,
	CUSTOM = 5,
	OFF = 6,
	ERTXGIQualityPreset_MAX = 7
};

// Enum RTXGI.ERTXGISurfacesMode
enum class ERTXGISurfacesMode : uint8_t {
	DDGI = 0,
	PATH_TRACE = 1,
	ERTXGISurfacesMode_MAX = 2
};

// Enum RTXGI.ERTXGIVolumetricsMode
enum class ERTXGIVolumetricsMode : uint8_t {
	OFF = 0,
	DDGI = 1,
	ERTXGIVolumetricsMode_MAX = 2
};

// Enum RTXGI.ERTXGICompositeMode
enum class ERTXGICompositeMode : uint8_t {
	OFF = 0,
	ON = 1,
	ERTXGICompositeMode_MAX = 2
};

// Enum RTXGI.ERTXGIPathTraceCheckerboardMode
enum class ERTXGIPathTraceCheckerboardMode : uint8_t {
	OFF = 0,
	ONE_QUARTER = 1,
	TWO_QUARTER = 2,
	THREE_QUARTER = 3,
	ERTXGIPathTraceCheckerboardMode_MAX = 4
};

// Enum RTXGI.ERTXGIPathTraceDenoiseMode
enum class ERTXGIPathTraceDenoiseMode : uint8_t {
	OFF = 0,
	REFERENCE = 1,
	ERTXGIPathTraceDenoiseMode_MAX = 2
};

// Enum RTXGI.ERTXGIDDGIRayDataBitDepth
enum class ERTXGIDDGIRayDataBitDepth : uint8_t {
	R32D32 = 0,
	R48D16 = 1,
	R96D32 = 2,
	ERTXGIDDGIRayDataBitDepth_MAX = 3
};

// Enum RTXGI.ERTXGIDDGIIrradianceBitDepth
enum class ERTXGIDDGIIrradianceBitDepth : uint8_t {
	D10 = 0,
	D16 = 1,
	D32 = 2,
	ERTXGIDDGIIrradianceBitDepth_MAX = 3
};

// Enum RTXGI.ERTXGIDDGIDistanceBitDepth
enum class ERTXGIDDGIDistanceBitDepth : uint8_t {
	D16 = 0,
	D32 = 1,
	ERTXGIDDGIDistanceBitDepth_MAX = 2
};

// Enum RTXGI.EDDGISkyLightType
enum class EDDGISkyLightType : uint8_t {
	None = 0,
	Raster = 1,
	RayTracing = 2,
	EDDGISkyLightType_MAX = 3
};

// Enum RTXGI.ERTXGIVisDDGIProbeData
enum class ERTXGIVisDDGIProbeData : uint8_t {
	OFF = 0,
	IRRADIANCE = 1,
	DISTANCE = 2,
	DISTANCE_SQUARED = 3,
	ERTXGIVisDDGIProbeData_MAX = 4
};

// Enum RTXGI.ERTXGIVisDDGIProbeView
enum class ERTXGIVisDDGIProbeView : uint8_t {
	OFF = 0,
	RADIANCE = 1,
	HIT_KIND = 2,
	NANS = 3,
	ERTXGIVisDDGIProbeView_MAX = 4
};

// ScriptStruct RTXGI.DDGITextureCaptureData
// Size: 0x28 (Inherited: 0x00)
struct FDDGITextureCaptureData {
	uint32_t Width; // 0x00(0x04)
	uint32_t Height; // 0x04(0x04)
	uint32_t Stride; // 0x08(0x04)
	uint32_t PixelFormat; // 0x0c(0x04)
	char pad_10[0x18]; // 0x10(0x18)
};

// ScriptStruct RTXGI.DDGIVolumeCaptureData
// Size: 0xb0 (Inherited: 0x00)
struct FDDGIVolumeCaptureData {
	struct FDDGITextureCaptureData Irradiance; // 0x00(0x28)
	struct FDDGITextureCaptureData Distance; // 0x28(0x28)
	struct FDDGITextureCaptureData Offsets; // 0x50(0x28)
	struct FDDGITextureCaptureData States; // 0x78(0x28)
	struct FGuid VolumeId; // 0xa0(0x10)
};

// ScriptStruct RTXGI.DDGILevelCaptureData
// Size: 0x38 (Inherited: 0x00)
struct FDDGILevelCaptureData {
	struct FString LevelPackageName; // 0x00(0x10)
	struct TSoftObjectPtr<UDDGICaptureRegistry> CapturedLevelData; // 0x10(0x28)
};

// ScriptStruct RTXGI.ProbeRelocation
// Size: 0x0c (Inherited: 0x00)
struct FProbeRelocation {
	bool AutomaticProbeRelocation; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ProbeMinFrontfaceDistance; // 0x04(0x04)
	float ProbeBackfaceThreshold; // 0x08(0x04)
};

