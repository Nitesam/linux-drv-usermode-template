// Class EmbarkAudio.EmbarkAudioGrainComponent
// Size: 0x410 (Inherited: 0x3c0)
struct UEmbarkAudioGrainComponent : USceneComponent {
	struct FEmbarkAudioGrain GrainData; // 0x3c0(0x48)
	char pad_408[0x8]; // 0x408(0x08)
};

// Class EmbarkAudio.EmbarkAudioGrainSubsystem
// Size: 0x9f0 (Inherited: 0xb0)
struct UEmbarkAudioGrainSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x30]; // 0xb0(0x30)
	struct TArray<struct FEmbarkAudioGrainSoundInfo> SoundInfos; // 0xe0(0x10)
	char pad_f0[0x900]; // 0xf0(0x900)

	void SowGrains(struct TArray<struct FEmbarkAudioGrainSowingData>& InGrains, struct TArray<int32_t>& OutGrainIds); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.SowGrains // (Final|Native|Public|HasOutParms) // @ game+0x67f8f60
	int32_t SowGrain(struct FVector& InWorldPosition, struct FEmbarkAudioGrain& InData, struct USceneComponent* InAttachToComponent); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.SowGrain // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x67ef810
	void SetConfig(struct FEmbarkAudioGrainSystemConfig& InConfig); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.SetConfig // (Final|Native|Public|HasOutParms) // @ game+0x67f01e0
	void SetAudioParameters(struct TArray<struct FEmbarkAudioGrainParameterData>& InParameters); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.SetAudioParameters // (Final|Native|Public|HasOutParms) // @ game+0x67f2c70
	void SetAudioParameter(struct FName InParameter, float InValue); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.SetAudioParameter // (Final|Native|Public) // @ game+0x67eeb50
	void ReapGrains(struct TArray<int32_t>& InIds); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.ReapGrains // (Final|Native|Public|HasOutParms) // @ game+0x67f6df0
	void ReapGrain(int32_t InId); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.ReapGrain // (Final|Native|Public) // @ game+0x67f2540
	void PauseGrain(int32_t InId, bool bPause); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.PauseGrain // (Final|Native|Public) // @ game+0x67ee400
	void MoveGrain(int32_t InId, struct FVector& InNewWorldPosition); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.MoveGrain // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x67f7ca0
	struct UEmbarkAudioGrainSubsystem* Get(struct UObject* WorldContextObject); // Function EmbarkAudio.EmbarkAudioGrainSubsystem.Get // (Final|Native|Static|Public) // @ game+0x67f34c0
};

// Class EmbarkAudio.EmbarkAudioSpatializationSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkAudioSpatializationSettings : USpatializationPluginSourceSettingsBase {
	struct FEmbarkAudioSpatializationSourceSettings Settings; // 0x98(0x14)
};

// Class EmbarkAudio.EmbarkAudioFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAudioFunctionLibrary : UBlueprintFunctionLibrary {

	void StopListeningForAudioDeviceDestroyed(struct UObject* InObject); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.StopListeningForAudioDeviceDestroyed // (Final|Native|Static|Public) // @ game+0x67f21b0
	void StopListeningForAudioDeviceCreated(struct UObject* InObject); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.StopListeningForAudioDeviceCreated // (Final|Native|Static|Public) // @ game+0x67f1c20
	void SetUnfocusedVolumeMultiplier(float InVolumeMultiplier); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.SetUnfocusedVolumeMultiplier // (Final|Native|Static|Public) // @ game+0x67f70a0
	void SetSubmixOutputVolumeForAudioDevice(uint32_t ID, struct USoundSubmix* InSoundSubmix, float InOutputVolume); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.SetSubmixOutputVolumeForAudioDevice // (Final|Native|Static|Public) // @ game+0x67f0900
	void SetSoundMixClassOverrideForAudioDevice(uint32_t ID, struct USoundMix* InSoundMixModifier, struct USoundClass* InSoundClass, float Volume, float Pitch, float FadeInTime, bool bApplyToChildren); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.SetSoundMixClassOverrideForAudioDevice // (Final|Native|Static|Public) // @ game+0x67f8270
	void SetAudioSpatializationChannels(int32_t InChannelCount); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.SetAudioSpatializationChannels // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x67f4020
	void PushSoundMixModifierForAudioDevice(uint32_t ID, struct USoundMix* InSoundMixModifier); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.PushSoundMixModifierForAudioDevice // (Final|Native|Static|Public) // @ game+0x67f55b0
	void PopSoundMixModifierForAudioDevice(uint32_t ID, struct USoundMix* InSoundMixModifier); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.PopSoundMixModifierForAudioDevice // (Final|Native|Static|Public) // @ game+0x67eec90
	void ListenForAudioDeviceDestroyed(struct UObject* InObject, struct FName& InFunctionName); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.ListenForAudioDeviceDestroyed // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f1970
	void ListenForAudioDeviceCreated(struct UObject* InObject, struct FName& InFunctionName); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.ListenForAudioDeviceCreated // (Final|Native|Static|Public|HasOutParms) // @ game+0x67ee5b0
	bool IsWorldAudioMuted(struct UWorld* World); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.IsWorldAudioMuted // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x67f3300
	float GetMaxDistance(struct USoundBase* Sound); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetMaxDistance // (Final|Native|Static|Public) // @ game+0x67f7160
	int32_t GetMaxChannelsForAudioDvice(uint32_t ID); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetMaxChannelsForAudioDvice // (Final|Native|Static|Public) // @ game+0x67f76f0
	float GetMappedRangeClampedCurve(struct FVector2D InRange, struct FVector2D OutRange, float Value, enum class EMapRangeCurve Curve, bool bInvertCurve); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetMappedRangeClampedCurve // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x67f4430
	struct FTransform GetFirstListenerTransform(struct UWorld* World); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetFirstListenerTransform // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x67efab0
	struct FVector GetFirstListenerPosition(struct UWorld* World); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetFirstListenerPosition // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x67eff50
	float GetDistanceToNearestListener(struct UWorld* World, struct FVector Location); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetDistanceToNearestListener // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x67f61e0
	struct AAudioVolume* GetAudioVolume(struct UWorld* World, struct FVector& Location); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetAudioVolume // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x67f30b0
	void GetAudioDeviceIDs(struct TArray<uint32_t>& OutAudioDeviceIDs); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetAudioDeviceIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f2b60
	float GetActorDistanceToNearestListener(struct AActor* InActor); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.GetActorDistanceToNearestListener // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x67f39e0
	void DisableOcclusion(bool bSetDisabled); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.DisableOcclusion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x67f7da0
	struct USoundWave* CreateSoundWaveFromMemoryBuffer(struct TArray<char>& InRawAudioDataPCM16, uint32_t InNumChannels, uint32_t InSampleRate); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.CreateSoundWaveFromMemoryBuffer // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f0380
	void ClearSoundMix(struct UWorld* World, struct USoundMix* SoundMix); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.ClearSoundMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x67f50b0
	void BindToOnQueueSubtitles(struct UAudioComponent* AudioComponent, struct UObject* Object, struct FName FunctionName); // Function EmbarkAudio.EmbarkAudioFunctionLibrary.BindToOnQueueSubtitles // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x67f0540
};

// Class EmbarkAudio.FEmbarkAudioParametersMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFEmbarkAudioParametersMixinLibrary : UObject {

	void AddTrigger(struct FEmbarkAudioParameters& Parameters, struct FName InName); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddTrigger // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f46f0
	void AddStringArray(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct TArray<struct FString>& InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddStringArray // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f2310
	void AddString(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct FString InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddString // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f0f10
	void AddObjectArray(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct TArray<struct UObject*>& InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddObjectArray // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f9280
	void AddObject(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct UObject* InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f2680
	void AddIntArray(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct TArray<int32_t>& InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddIntArray // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f57f0
	void AddInt(struct FEmbarkAudioParameters& Parameters, struct FName InName, int32_t InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddInt // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f11b0
	void AddFloatArray(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct TArray<float>& InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddFloatArray // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f6500
	void AddFloat(struct FEmbarkAudioParameters& Parameters, struct FName InName, float InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddFloat // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f1d30
	void AddBoolArray(struct FEmbarkAudioParameters& Parameters, struct FName InName, struct TArray<bool>& InValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddBoolArray // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f0000
	void AddBool(struct FEmbarkAudioParameters& Parameters, struct FName InName, bool bInValue); // Function EmbarkAudio.FEmbarkAudioParametersMixinLibrary.AddBool // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f4860
};

// Class EmbarkAudio.EmbarkAudioComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAudioComponentMixinLibrary : UObject {

	void SetTriggerParameter(struct UAudioComponent* AudioComponent, struct FName InName); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetTriggerParameter // (Final|Native|Static|Public) // @ game+0x67f75f0
	void SetStringParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct FString InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetStringParameter // (Final|Native|Static|Public) // @ game+0x67efc30
	void SetStringArrayParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct TArray<struct FString>& InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetStringArrayParameter // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f37f0
	void SetParameters(struct UAudioComponent* AudioComponent, struct FEmbarkAudioParameters& InParameters); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetParameters // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f7e90
	void SetObjectParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct UObject* InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetObjectParameter // (Final|Native|Static|Public) // @ game+0x67f1ab0
	void SetObjectArrayParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct TArray<struct UObject*>& InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetObjectArrayParameter // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f0aa0
	void SetIntArrayParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct TArray<int32_t>& InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetIntArrayParameter // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f3560
	void SetFloatArrayParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct TArray<float>& InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetFloatArrayParameter // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f7a60
	void SetBoolArrayParameter(struct UAudioComponent* AudioComponent, struct FName InName, struct TArray<bool>& InValue); // Function EmbarkAudio.EmbarkAudioComponentMixinLibrary.SetBoolArrayParameter // (Final|Native|Static|Public|HasOutParms) // @ game+0x67f4ef0
};

// Class EmbarkAudio.EmbarkAudioGameplayVolumeBase
// Size: 0x400 (Inherited: 0x400)
struct AEmbarkAudioGameplayVolumeBase : AAudioGameplayVolume {

	void TriggerUpdateProxy(); // Function EmbarkAudio.EmbarkAudioGameplayVolumeBase.TriggerUpdateProxy // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x67f8c10
};

// Class EmbarkAudio.EmbarkAudioTickableObject
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkAudioTickableObject : UObject {
	bool bIsInitialized; // 0xa0(0x01)
	char pad_a1[0xf]; // 0xa1(0x0f)

	void OnTick(float DeltaSeconds); // Function EmbarkAudio.EmbarkAudioTickableObject.OnTick // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkAudio.EmbarkPathfinderAudioOcclusionSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkPathfinderAudioOcclusionSettings : UOcclusionPluginSourceSettingsBase {
	struct FEmbarkPathfinderAudioOcclusionSourceSettings Settings; // 0x98(0x18)
};

// Class EmbarkAudio.SoundWaveCollection
// Size: 0xd0 (Inherited: 0xa0)
struct USoundWaveCollection : UDataAsset {
	struct TArray<struct USoundWave*> SoundList; // 0xa0(0x10)
	char pad_b0[0x20]; // 0xb0(0x20)

	void RegisterCallback(struct UObject* Object, struct FName FuncName); // Function EmbarkAudio.SoundWaveCollection.RegisterCallback // (Final|Native|Public|BlueprintCallable) // @ game+0x680fb90
	struct USoundWave* GetSoundWave(int32_t RequestedIndex); // Function EmbarkAudio.SoundWaveCollection.GetSoundWave // (Final|Native|Public|BlueprintCallable) // @ game+0x6801db0
};

// Class EmbarkAudio.SoundWeaponSynthComponent
// Size: 0xa80 (Inherited: 0xa20)
struct USoundWeaponSynthComponent : USynthComponent {
	float MasterAmplitude; // 0xa20(0x04)
	float PreFireDelayTime; // 0xa24(0x04)
	float DeactivationTime; // 0xa28(0x04)
	bool bBypassVolumeScaleForPriority; // 0xa2c(0x01)
	char pad_a2d[0x3]; // 0xa2d(0x03)
	float Priority; // 0xa30(0x04)
	char pad_a34[0x4c]; // 0xa34(0x4c)

	void StopFiring_Internal(); // Function EmbarkAudio.SoundWeaponSynthComponent.StopFiring_Internal // (Final|Native|Public) // @ game+0x6801e80
	void StartFiring_Internal(int32_t MinBulletsPerRound, int32_t MaxBulletsPerRound, float RateOfFire); // Function EmbarkAudio.SoundWeaponSynthComponent.StartFiring_Internal // (Final|Native|Public) // @ game+0x6802600
	void SetStayActive(bool bSetStayActive); // Function EmbarkAudio.SoundWeaponSynthComponent.SetStayActive // (Final|Native|Public) // @ game+0x6815040
	void SetSoundLayerSounds(int32_t SoundLayerIndex, struct USoundWaveCollection* InSounds); // Function EmbarkAudio.SoundWeaponSynthComponent.SetSoundLayerSounds // (Final|Native|Public) // @ game+0x680b000
	void SetSoundLayerParameters(int32_t SoundLayerIndex, enum class EWeaponSynthSoundLayerType LayerType, float Amplitude, float Pitch, int32_t Offset, bool bAlignWithEndOfShot); // Function EmbarkAudio.SoundWeaponSynthComponent.SetSoundLayerParameters // (Final|Native|Public) // @ game+0x68169a0
	void SetSoundLayerBurstEnvelope(int32_t SoundLayerIndex, float AttackGain, float DecayTime); // Function EmbarkAudio.SoundWeaponSynthComponent.SetSoundLayerBurstEnvelope // (Final|Native|Public) // @ game+0x680b8a0
	void PrepareSoundLayers(int32_t NumSoundLayers, struct FName AssetDebugName); // Function EmbarkAudio.SoundWeaponSynthComponent.PrepareSoundLayers // (Final|Native|Public) // @ game+0x67fed10
	void ModifyRateOfFire(float NewRateOfFire); // Function EmbarkAudio.SoundWeaponSynthComponent.ModifyRateOfFire // (Final|Native|Public) // @ game+0x6811050
	bool IsSilent(); // Function EmbarkAudio.SoundWeaponSynthComponent.IsSilent // (Final|Native|Public) // @ game+0x68058b0
	void IncrementShotCounter(); // Function EmbarkAudio.SoundWeaponSynthComponent.IncrementShotCounter // (Final|Native|Public) // @ game+0x6809cb0
	float GetRateOfFire(); // Function EmbarkAudio.SoundWeaponSynthComponent.GetRateOfFire // (Final|Native|Public|Const) // @ game+0x67febe0
	float GetDistanceToListener(); // Function EmbarkAudio.SoundWeaponSynthComponent.GetDistanceToListener // (Final|Native|Public|Const) // @ game+0x680fab0
};

