// ScriptStruct EmbarkReplicatedTransform.ReplicatedTransform
// Size: 0x68 (Inherited: 0x00)
struct FReplicatedTransform {
	struct FVector Location; // 0x00(0x18)
	struct FRotator Rotation; // 0x18(0x18)
	struct FVector LinearVelocity; // 0x30(0x18)
	struct FVector AngularVelocity; // 0x48(0x18)
	enum class EVectorQuantization LocationQuantizationLevel; // 0x60(0x01)
	enum class ERotatorQuantization RotationQuantizationLevel; // 0x61(0x01)
	enum class EVectorQuantization LinearVelocityQuantizationLevel; // 0x62(0x01)
	enum class EVectorQuantization AngularVelocityQuantizationLevel; // 0x63(0x01)
	char bReplicateLocation : 1; // 0x64(0x01)
	char bReplicateRotation : 1; // 0x64(0x01)
	char bReplicateLinearVelocity : 1; // 0x64(0x01)
	char bReplicateAngularVelocity : 1; // 0x64(0x01)
	char pad_64_4 : 4; // 0x64(0x01)
	char TeleportedCycle; // 0x65(0x01)
	char pad_66[0x1]; // 0x66(0x01)
	char bDormantLinearVelocity : 1; // 0x67(0x01)
	char bDormantAngularVelocity : 1; // 0x67(0x01)
	char pad_67_2 : 6; // 0x67(0x01)
};

