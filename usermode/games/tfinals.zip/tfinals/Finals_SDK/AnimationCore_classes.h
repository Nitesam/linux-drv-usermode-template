// Class AnimationCore.AnimationDataSourceRegistry
// Size: 0xf0 (Inherited: 0xa0)
struct UAnimationDataSourceRegistry : UObject {
	struct TMap<struct FName, struct TWeakObjectPtr<struct UObject>> DataSources; // 0x98(0x50)
};

