// Enum ComponentAssembler.EAssemblyNetworkMode
enum class EAssemblyNetworkMode : uint8_t {
	OnlyCreateOnClient = 0,
	OnlyCreateOnServer = 1,
	CreateOnBothClientAndServer = 2,
	CreateOnServerAndReplicateToClient = 3,
	EAssemblyNetworkMode_MAX = 4
};

