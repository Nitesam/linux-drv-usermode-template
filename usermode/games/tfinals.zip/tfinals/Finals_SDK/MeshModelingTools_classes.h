// Class MeshModelingTools.PolyEditActivityContext
// Size: 0x190 (Inherited: 0xa0)
struct UPolyEditActivityContext : UObject {
	struct UPolyEditCommonProperties* CommonProperties; // 0x98(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0xb0(0x08)
	char pad_b8[0x28]; // 0xb8(0x28)
	struct UPolygonSelectionMechanic* SelectionMechanic; // 0xe0(0x08)
	char pad_e8[0xa8]; // 0xe8(0xa8)
};

// Class MeshModelingTools.AddPrimitiveToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UAddPrimitiveToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingTools.ProceduralShapeToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UProceduralShapeToolProperties : UInteractiveToolPropertySet {
	enum class EMakeMeshPolygroupMode PolygroupMode; // 0x118(0x01)
	enum class EMakeMeshPlacementType TargetSurface; // 0x119(0x01)
	enum class EMakeMeshPivotLocation PivotLocation; // 0x11a(0x01)
	float Rotation; // 0x11c(0x04)
	bool bAlignToNormal; // 0x120(0x01)
	bool bShowGizmo; // 0x121(0x01)
	bool bShowGizmoOptions; // 0x122(0x01)
	char pad_12a[0x6]; // 0x12a(0x06)
};

// Class MeshModelingTools.ProceduralBoxToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralBoxToolProperties : UProceduralShapeToolProperties {
	float Width; // 0x128(0x04)
	float Depth; // 0x12c(0x04)
	float Height; // 0x130(0x04)
	int32_t WidthSubdivisions; // 0x134(0x04)
	int32_t DepthSubdivisions; // 0x138(0x04)
	int32_t HeightSubdivisions; // 0x13c(0x04)
};

// Class MeshModelingTools.ProceduralRectangleToolProperties
// Size: 0x150 (Inherited: 0x130)
struct UProceduralRectangleToolProperties : UProceduralShapeToolProperties {
	enum class EProceduralRectType RectangleType; // 0x128(0x04)
	float Width; // 0x12c(0x04)
	float Depth; // 0x130(0x04)
	int32_t WidthSubdivisions; // 0x134(0x04)
	int32_t DepthSubdivisions; // 0x138(0x04)
	bool bMaintainDimension; // 0x13c(0x01)
	float CornerRadius; // 0x140(0x04)
	int32_t CornerSlices; // 0x144(0x04)
	char pad_14d[0x3]; // 0x14d(0x03)
};

// Class MeshModelingTools.ProceduralDiscToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralDiscToolProperties : UProceduralShapeToolProperties {
	enum class EProceduralDiscType DiscType; // 0x128(0x04)
	float Radius; // 0x12c(0x04)
	int32_t RadialSlices; // 0x130(0x04)
	int32_t RadialSubdivisions; // 0x134(0x04)
	float HoleRadius; // 0x138(0x04)
};

// Class MeshModelingTools.ProceduralTorusToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralTorusToolProperties : UProceduralShapeToolProperties {
	float MajorRadius; // 0x128(0x04)
	float MinorRadius; // 0x12c(0x04)
	int32_t MajorSlices; // 0x130(0x04)
	int32_t MinorSlices; // 0x134(0x04)
};

// Class MeshModelingTools.ProceduralCylinderToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralCylinderToolProperties : UProceduralShapeToolProperties {
	float Radius; // 0x128(0x04)
	float Height; // 0x12c(0x04)
	int32_t RadialSlices; // 0x130(0x04)
	int32_t HeightSubdivisions; // 0x134(0x04)
};

// Class MeshModelingTools.ProceduralConeToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralConeToolProperties : UProceduralShapeToolProperties {
	float Radius; // 0x128(0x04)
	float Height; // 0x12c(0x04)
	int32_t RadialSlices; // 0x130(0x04)
	int32_t HeightSubdivisions; // 0x134(0x04)
};

// Class MeshModelingTools.ProceduralArrowToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralArrowToolProperties : UProceduralShapeToolProperties {
	float ShaftRadius; // 0x128(0x04)
	float ShaftHeight; // 0x12c(0x04)
	float HeadRadius; // 0x130(0x04)
	float HeadHeight; // 0x134(0x04)
	int32_t RadialSlices; // 0x138(0x04)
	int32_t HeightSubdivisions; // 0x13c(0x04)
};

// Class MeshModelingTools.ProceduralSphereToolProperties
// Size: 0x140 (Inherited: 0x130)
struct UProceduralSphereToolProperties : UProceduralShapeToolProperties {
	float Radius; // 0x128(0x04)
	enum class EProceduralSphereType SubdivisionType; // 0x12c(0x04)
	int32_t Subdivisions; // 0x130(0x04)
	int32_t HorizontalSlices; // 0x134(0x04)
	int32_t VerticalSlices; // 0x138(0x04)
};

// Class MeshModelingTools.ProceduralStairsToolProperties
// Size: 0x150 (Inherited: 0x130)
struct UProceduralStairsToolProperties : UProceduralShapeToolProperties {
	enum class EProceduralStairsType StairsType; // 0x128(0x04)
	int32_t NumSteps; // 0x12c(0x04)
	float StepWidth; // 0x130(0x04)
	float StepHeight; // 0x134(0x04)
	float StepDepth; // 0x138(0x04)
	float CurveAngle; // 0x13c(0x04)
	float SpiralAngle; // 0x140(0x04)
	float InnerRadius; // 0x144(0x04)
};

// Class MeshModelingTools.AddPrimitiveTool
// Size: 0x1b0 (Inherited: 0x120)
struct UAddPrimitiveTool : USingleClickTool {
	char pad_120[0x10]; // 0x120(0x10)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x130(0x08)
	struct UProceduralShapeToolProperties* ShapeSettings; // 0x138(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x140(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x148(0x08)
	struct UCombinedTransformGizmo* Gizmo; // 0x150(0x08)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x158(0x08)
	struct FString AssetName; // 0x160(0x10)
	char pad_170[0x40]; // 0x170(0x40)
};

// Class MeshModelingTools.AddBoxPrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddBoxPrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddCylinderPrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddCylinderPrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddConePrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddConePrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddRectanglePrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddRectanglePrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddDiscPrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddDiscPrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddTorusPrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddTorusPrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddArrowPrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddArrowPrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddSpherePrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddSpherePrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.AddStairsPrimitiveTool
// Size: 0x1b0 (Inherited: 0x1b0)
struct UAddStairsPrimitiveTool : UAddPrimitiveTool {
};

// Class MeshModelingTools.CombineMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UCombineMeshesToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingTools.CombineMeshesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UCombineMeshesToolProperties : UInteractiveToolPropertySet {
	bool bIsDuplicateMode; // 0x118(0x01)
	enum class EBaseCreateFromSelectedTargetType OutputWriteTo; // 0x11c(0x04)
	struct FString OutputNewName; // 0x120(0x10)
	struct FString OutputExistingName; // 0x130(0x10)
};

// Class MeshModelingTools.CombineMeshesTool
// Size: 0x160 (Inherited: 0x130)
struct UCombineMeshesTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UCombineMeshesToolProperties* BasicProperties; // 0x138(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x140(0x08)
	struct UOnAcceptHandleSourcesPropertiesBase* HandleSourceProperties; // 0x148(0x08)
	char pad_150[0x10]; // 0x150(0x10)
};

// Class MeshModelingTools.DeleteGeometrySelectionCommand
// Size: 0xa0 (Inherited: 0xa0)
struct UDeleteGeometrySelectionCommand : UGeometrySelectionEditCommand {
};

// Class MeshModelingTools.DisconnectGeometrySelectionCommand
// Size: 0xa0 (Inherited: 0xa0)
struct UDisconnectGeometrySelectionCommand : UGeometrySelectionEditCommand {
};

// Class MeshModelingTools.ModifyGeometrySelectionCommand
// Size: 0xa0 (Inherited: 0xa0)
struct UModifyGeometrySelectionCommand : UGeometrySelectionEditCommand {
};

// Class MeshModelingTools.ModifyGeometrySelectionCommand_Invert
// Size: 0xa0 (Inherited: 0xa0)
struct UModifyGeometrySelectionCommand_Invert : UModifyGeometrySelectionCommand {
};

// Class MeshModelingTools.ModifyGeometrySelectionCommand_ExpandToConnected
// Size: 0xa0 (Inherited: 0xa0)
struct UModifyGeometrySelectionCommand_ExpandToConnected : UModifyGeometrySelectionCommand {
};

// Class MeshModelingTools.ModifyGeometrySelectionCommand_InvertConnected
// Size: 0xa0 (Inherited: 0xa0)
struct UModifyGeometrySelectionCommand_InvertConnected : UModifyGeometrySelectionCommand {
};

// Class MeshModelingTools.ModifyGeometrySelectionCommand_Expand
// Size: 0xa0 (Inherited: 0xa0)
struct UModifyGeometrySelectionCommand_Expand : UModifyGeometrySelectionCommand {
};

// Class MeshModelingTools.ModifyGeometrySelectionCommand_Contract
// Size: 0xa0 (Inherited: 0xa0)
struct UModifyGeometrySelectionCommand_Contract : UModifyGeometrySelectionCommand {
};

// Class MeshModelingTools.RetriangulateGeometrySelectionCommand
// Size: 0xa0 (Inherited: 0xa0)
struct URetriangulateGeometrySelectionCommand : UGeometrySelectionEditCommand {
};

// Class MeshModelingTools.CSGMeshesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UCSGMeshesToolProperties : UInteractiveToolPropertySet {
	enum class ECSGOperation Operation; // 0x118(0x01)
	bool bTryFixHoles; // 0x119(0x01)
	bool bTryCollapseEdges; // 0x11a(0x01)
	float WindingThreshold; // 0x11c(0x04)
	bool bShowNewBoundaries; // 0x120(0x01)
	bool bShowSubtractedMesh; // 0x121(0x01)
	float SubtractedMeshOpacity; // 0x124(0x04)
	struct FLinearColor SubtractedMeshColor; // 0x128(0x10)
	bool bUseFirstMeshMaterials; // 0x138(0x01)
	char pad_13e[0x2]; // 0x13e(0x02)
};

// Class MeshModelingTools.TrimMeshesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UTrimMeshesToolProperties : UInteractiveToolPropertySet {
	enum class ETrimOperation WhichMesh; // 0x118(0x01)
	enum class ETrimSide TrimSide; // 0x119(0x01)
	float WindingThreshold; // 0x11c(0x04)
	bool bShowTrimmingMesh; // 0x120(0x01)
	float OpacityOfTrimmingMesh; // 0x124(0x04)
	struct FLinearColor ColorOfTrimmingMesh; // 0x128(0x10)
	char pad_13b[0x5]; // 0x13b(0x05)
};

// Class MeshModelingTools.CSGMeshesTool
// Size: 0x1d0 (Inherited: 0x180)
struct UCSGMeshesTool : UBaseCreateFromSelectedTool {
	struct UCSGMeshesToolProperties* CSGProperties; // 0x178(0x08)
	struct UTrimMeshesToolProperties* TrimProperties; // 0x180(0x08)
	char pad_190[0x8]; // 0x190(0x08)
	struct TArray<struct UPreviewMesh*> OriginalMeshPreviews; // 0x198(0x10)
	struct UMaterialInstanceDynamic* PreviewsGhostMaterial; // 0x1a8(0x08)
	struct ULineSetComponent* DrawnLineSet; // 0x1b0(0x08)
	char pad_1b8[0x18]; // 0x1b8(0x18)
};

// Class MeshModelingTools.CSGMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UCSGMeshesToolBuilder : UBaseCreateFromSelectedToolBuilder {
};

// Class MeshModelingTools.CutMeshWithMeshToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UCutMeshWithMeshToolProperties : UInteractiveToolPropertySet {
	bool bTryFixHoles; // 0x118(0x01)
	bool bTryCollapseEdges; // 0x119(0x01)
	float WindingThreshold; // 0x11c(0x04)
	bool bShowNewBoundaries; // 0x120(0x01)
	bool bUseFirstMeshMaterials; // 0x121(0x01)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class MeshModelingTools.CutMeshWithMeshTool
// Size: 0x3f0 (Inherited: 0x180)
struct UCutMeshWithMeshTool : UBaseCreateFromSelectedTool {
	struct UCutMeshWithMeshToolProperties* CutProperties; // 0x178(0x08)
	struct UPreviewMesh* IntersectPreviewMesh; // 0x180(0x08)
	char pad_190[0x18]; // 0x190(0x18)
	struct ULineSetComponent* DrawnLineSet; // 0x1a8(0x08)
	char pad_1b0[0x240]; // 0x1b0(0x240)
};

// Class MeshModelingTools.CutMeshWithMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UCutMeshWithMeshToolBuilder : UBaseCreateFromSelectedToolBuilder {
};

// Class MeshModelingTools.DrawAndRevolveToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UDrawAndRevolveToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingTools.RevolveProperties
// Size: 0x190 (Inherited: 0x120)
struct URevolveProperties : UInteractiveToolPropertySet {
	double RevolveDegreesClamped; // 0x118(0x08)
	double RevolveDegrees; // 0x120(0x08)
	double RevolveDegreesOffset; // 0x128(0x08)
	double StepsMaxDegrees; // 0x130(0x08)
	bool bExplicitSteps; // 0x138(0x01)
	int32_t NumExplicitSteps; // 0x13c(0x04)
	double HeightOffsetPerDegree; // 0x140(0x08)
	bool bReverseRevolutionDirection; // 0x148(0x01)
	bool bFlipMesh; // 0x149(0x01)
	bool bSharpNormals; // 0x14a(0x01)
	double SharpNormalsDegreeThreshold; // 0x150(0x08)
	bool bPathAtMidpointOfStep; // 0x158(0x01)
	enum class ERevolvePropertiesPolygroupMode PolygroupMode; // 0x159(0x01)
	enum class ERevolvePropertiesQuadSplit QuadSplitMode; // 0x15a(0x01)
	char pad_15b[0x35]; // 0x15b(0x35)
};

// Class MeshModelingTools.RevolveToolProperties
// Size: 0x1d0 (Inherited: 0x190)
struct URevolveToolProperties : URevolveProperties {
	enum class ERevolvePropertiesCapFillMode CapFillMode; // 0x188(0x01)
	bool bClosePathToAxis; // 0x189(0x01)
	struct FVector DrawPlaneOrigin; // 0x190(0x18)
	struct FRotator DrawPlaneOrientation; // 0x1a8(0x18)
	bool bEnableSnapping; // 0x1c0(0x01)
	bool bAllowedToEditDrawPlane; // 0x1c1(0x01)
	char pad_1c4[0xc]; // 0x1c4(0x0c)
};

// Class MeshModelingTools.RevolveOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct URevolveOperatorFactory : UObject {
	struct UDrawAndRevolveTool* RevolveTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingTools.DrawAndRevolveTool
// Size: 0x1e0 (Inherited: 0x110)
struct UDrawAndRevolveTool : UInteractiveTool {
	char pad_110[0x98]; // 0x110(0x98)
	struct UCurveControlPointsMechanic* ControlPointsMechanic; // 0x1a8(0x08)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x1b0(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x1b8(0x08)
	struct URevolveToolProperties* Settings; // 0x1c0(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x1c8(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x1d0(0x08)
	char pad_1d8[0x8]; // 0x1d8(0x08)
};

// Class MeshModelingTools.DrawPolygonToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UDrawPolygonToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingTools.DrawPolygonToolStandardProperties
// Size: 0x130 (Inherited: 0x120)
struct UDrawPolygonToolStandardProperties : UInteractiveToolPropertySet {
	enum class EDrawPolygonDrawMode PolygonDrawMode; // 0x118(0x01)
	bool bAllowSelfIntersections; // 0x119(0x01)
	float FeatureSizeRatio; // 0x11c(0x04)
	int32_t RadialSlices; // 0x120(0x04)
	float Distance; // 0x124(0x04)
	bool bShowGridGizmo; // 0x128(0x01)
	enum class EDrawPolygonExtrudeMode ExtrudeMode; // 0x129(0x01)
	float ExtrudeHeight; // 0x12c(0x04)
};

// Class MeshModelingTools.DrawPolygonToolSnapProperties
// Size: 0x130 (Inherited: 0x120)
struct UDrawPolygonToolSnapProperties : UInteractiveToolPropertySet {
	bool bEnableSnapping; // 0x118(0x01)
	bool bSnapToWorldGrid; // 0x119(0x01)
	bool bSnapToVertices; // 0x11a(0x01)
	bool bSnapToEdges; // 0x11b(0x01)
	bool bSnapToAxes; // 0x11c(0x01)
	bool bSnapToLengths; // 0x11d(0x01)
	bool bSnapToSurfaces; // 0x11e(0x01)
	float SnapToSurfacesOffset; // 0x120(0x04)
	char pad_12b[0x5]; // 0x12b(0x05)
};

// Class MeshModelingTools.DrawPolygonTool
// Size: 0x5d0 (Inherited: 0x110)
struct UDrawPolygonTool : UInteractiveTool {
	char pad_110[0x8]; // 0x110(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x118(0x08)
	struct UDrawPolygonToolStandardProperties* PolygonProperties; // 0x120(0x08)
	struct UDrawPolygonToolSnapProperties* SnapProperties; // 0x128(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x130(0x08)
	char pad_138[0x98]; // 0x138(0x98)
	struct UPreviewMesh* PreviewMesh; // 0x1d0(0x08)
	char pad_1d8[0x3d0]; // 0x1d8(0x3d0)
	struct UPlaneDistanceFromHitMechanic* HeightMechanic; // 0x5a8(0x08)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x5b0(0x08)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x5b8(0x08)
	char pad_5c0[0x10]; // 0x5c0(0x10)
};

// Class MeshModelingTools.EditMeshPolygonsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UEditMeshPolygonsToolBuilder : USingleTargetWithSelectionToolBuilder {
};

// Class MeshModelingTools.PolyEditCommonProperties
// Size: 0x130 (Inherited: 0x120)
struct UPolyEditCommonProperties : UInteractiveToolPropertySet {
	bool bShowWireframe; // 0x118(0x01)
	bool bShowSelectableCorners; // 0x119(0x01)
	bool bGizmoVisible; // 0x11a(0x01)
	enum class ELocalFrameMode LocalFrameMode; // 0x11c(0x04)
	bool bLockRotation; // 0x120(0x01)
	bool bLocalCoordSystem; // 0x121(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingTools.EditMeshPolygonsActionModeToolBuilder
// Size: 0xb0 (Inherited: 0xa0)
struct UEditMeshPolygonsActionModeToolBuilder : UEditMeshPolygonsToolBuilder {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class MeshModelingTools.EditMeshPolygonsSelectionModeToolBuilder
// Size: 0xb0 (Inherited: 0xa0)
struct UEditMeshPolygonsSelectionModeToolBuilder : UEditMeshPolygonsToolBuilder {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class MeshModelingTools.EditMeshPolygonsToolActionPropertySet
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolActionPropertySet : UInteractiveToolPropertySet {
};

// Class MeshModelingTools.PolyEditTopologyProperties
// Size: 0x130 (Inherited: 0x120)
struct UPolyEditTopologyProperties : UEditMeshPolygonsToolActionPropertySet {
	bool bAddExtraCorners; // 0x120(0x01)
	char pad_121[0x7]; // 0x121(0x07)
	double ExtraCornerAngleThresholdDegrees; // 0x128(0x08)

	void RegenerateExtraCorners(); // Function MeshModelingTools.PolyEditTopologyProperties.RegenerateExtraCorners // (Final|Native|Public) // @ game+0x95537e0
};

// Class MeshModelingTools.EditMeshPolygonsToolActions
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolActions : UEditMeshPolygonsToolActionPropertySet {

	void SimplifyByGroups(); // Function MeshModelingTools.EditMeshPolygonsToolActions.SimplifyByGroups // (Final|Native|Public) // @ game+0x9514a50
	void Retriangulate(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Retriangulate // (Final|Native|Public) // @ game+0x9516ba0
	void RecalcNormals(); // Function MeshModelingTools.EditMeshPolygonsToolActions.RecalcNormals // (Final|Native|Public) // @ game+0x950d960
	void PushPull(); // Function MeshModelingTools.EditMeshPolygonsToolActions.PushPull // (Final|Native|Public) // @ game+0x952aa80
	void Outset(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Outset // (Final|Native|Public) // @ game+0x953d330
	void Offset(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Offset // (Final|Native|Public) // @ game+0x9526870
	void Merge(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Merge // (Final|Native|Public) // @ game+0x9549920
	void Inset(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Inset // (Final|Native|Public) // @ game+0x9560700
	void InsertEdgeLoop(); // Function MeshModelingTools.EditMeshPolygonsToolActions.InsertEdgeLoop // (Final|Native|Public) // @ game+0x956ae00
	void InsertEdge(); // Function MeshModelingTools.EditMeshPolygonsToolActions.InsertEdge // (Final|Native|Public) // @ game+0x957de80
	void Flip(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Flip // (Final|Native|Public) // @ game+0x9512e70
	void Extrude(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Extrude // (Final|Native|Public) // @ game+0x9512710
	void Duplicate(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Duplicate // (Final|Native|Public) // @ game+0x9510df0
	void Disconnect(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Disconnect // (Final|Native|Public) // @ game+0x9518550
	void Delete(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Delete // (Final|Native|Public) // @ game+0x9536a40
	void Decompose(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Decompose // (Final|Native|Public) // @ game+0x952aae0
	void CutFaces(); // Function MeshModelingTools.EditMeshPolygonsToolActions.CutFaces // (Final|Native|Public) // @ game+0x950ea40
	void Bevel(); // Function MeshModelingTools.EditMeshPolygonsToolActions.Bevel // (Final|Native|Public) // @ game+0x951deb0
};

// Class MeshModelingTools.EditMeshPolygonsToolActions_Triangles
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolActions_Triangles : UEditMeshPolygonsToolActionPropertySet {

	void RecalcNormals(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.RecalcNormals // (Final|Native|Public) // @ game+0x950d960
	void PushPull(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.PushPull // (Final|Native|Public) // @ game+0x952aa80
	void Poke(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Poke // (Final|Native|Public) // @ game+0x9575bf0
	void Outset(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Outset // (Final|Native|Public) // @ game+0x953d330
	void Offset(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Offset // (Final|Native|Public) // @ game+0x9526870
	void Inset(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Inset // (Final|Native|Public) // @ game+0x9560700
	void Flip(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Flip // (Final|Native|Public) // @ game+0x9512e70
	void Extrude(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Extrude // (Final|Native|Public) // @ game+0x9512710
	void Duplicate(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Duplicate // (Final|Native|Public) // @ game+0x9510df0
	void Disconnect(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Disconnect // (Final|Native|Public) // @ game+0x9518550
	void Delete(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.Delete // (Final|Native|Public) // @ game+0x9536a40
	void CutFaces(); // Function MeshModelingTools.EditMeshPolygonsToolActions_Triangles.CutFaces // (Final|Native|Public) // @ game+0x950ea40
};

// Class MeshModelingTools.EditMeshPolygonsToolUVActions
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolUVActions : UEditMeshPolygonsToolActionPropertySet {

	void PlanarProjection(); // Function MeshModelingTools.EditMeshPolygonsToolUVActions.PlanarProjection // (Final|Native|Public) // @ game+0x95498c0
};

// Class MeshModelingTools.EditMeshPolygonsToolEdgeActions
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolEdgeActions : UEditMeshPolygonsToolActionPropertySet {

	void Weld(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Weld // (Final|Native|Public) // @ game+0x9512bc0
	void Straighten(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Straighten // (Final|Native|Public) // @ game+0x954d660
	void Simplify(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Simplify // (Final|Native|Public) // @ game+0x9533360
	void FillHole(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.FillHole // (Final|Native|Public) // @ game+0x95118a0
	void Bridge(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Bridge // (Final|Native|Public) // @ game+0x9548140
	void Bevel(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions.Bevel // (Final|Native|Public) // @ game+0x955f6f0
};

// Class MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolEdgeActions_Triangles : UEditMeshPolygonsToolActionPropertySet {

	void Weld(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Weld // (Final|Native|Public) // @ game+0x9512bc0
	void Split(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Split // (Final|Native|Public) // @ game+0x954d240
	void Flip(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Flip // (Final|Native|Public) // @ game+0x9533fa0
	void FillHole(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.FillHole // (Final|Native|Public) // @ game+0x95118a0
	void Collapse(); // Function MeshModelingTools.EditMeshPolygonsToolEdgeActions_Triangles.Collapse // (Final|Native|Public) // @ game+0x9577850
};

// Class MeshModelingTools.EditMeshPolygonsToolCancelAction
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolCancelAction : UEditMeshPolygonsToolActionPropertySet {

	void Done(); // Function MeshModelingTools.EditMeshPolygonsToolCancelAction.Done // (Final|Native|Public) // @ game+0x9528510
};

// Class MeshModelingTools.EditMeshPolygonsToolAcceptCancelAction
// Size: 0x120 (Inherited: 0x120)
struct UEditMeshPolygonsToolAcceptCancelAction : UEditMeshPolygonsToolActionPropertySet {

	void Cancel(); // Function MeshModelingTools.EditMeshPolygonsToolAcceptCancelAction.Cancel // (Final|Native|Public) // @ game+0x9528510
	void Apply(); // Function MeshModelingTools.EditMeshPolygonsToolAcceptCancelAction.Apply // (Final|Native|Public) // @ game+0x9535250
};

// Class MeshModelingTools.EditMeshPolygonsTool
// Size: 0x8f0 (Inherited: 0x1a0)
struct UEditMeshPolygonsTool : USingleTargetWithSelectionTool {
	char pad_1a0[0x18]; // 0x1a0(0x18)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x1b8(0x08)
	struct UPolyEditCommonProperties* CommonProps; // 0x1c0(0x08)
	struct UEditMeshPolygonsToolActions* EditActions; // 0x1c8(0x08)
	struct UEditMeshPolygonsToolActions_Triangles* EditActions_Triangles; // 0x1d0(0x08)
	struct UEditMeshPolygonsToolEdgeActions* EditEdgeActions; // 0x1d8(0x08)
	struct UEditMeshPolygonsToolEdgeActions_Triangles* EditEdgeActions_Triangles; // 0x1e0(0x08)
	struct UEditMeshPolygonsToolUVActions* EditUVActions; // 0x1e8(0x08)
	struct UEditMeshPolygonsToolCancelAction* CancelAction; // 0x1f0(0x08)
	struct UEditMeshPolygonsToolAcceptCancelAction* AcceptCancelAction; // 0x1f8(0x08)
	struct UPolyEditTopologyProperties* TopologyProperties; // 0x200(0x08)
	struct UPolyEditExtrudeActivity* ExtrudeActivity; // 0x208(0x08)
	struct UPolyEditInsetOutsetActivity* InsetOutsetActivity; // 0x210(0x08)
	struct UPolyEditCutFacesActivity* CutFacesActivity; // 0x218(0x08)
	struct UPolyEditPlanarProjectionUVActivity* PlanarProjectionUVActivity; // 0x220(0x08)
	struct UPolyEditInsertEdgeActivity* InsertEdgeActivity; // 0x228(0x08)
	struct UPolyEditInsertEdgeLoopActivity* InsertEdgeLoopActivity; // 0x230(0x08)
	struct UPolyEditBevelEdgeActivity* BevelEdgeActivity; // 0x238(0x08)
	char pad_240[0x38]; // 0x240(0x38)
	struct UPolyEditActivityContext* ActivityContext; // 0x278(0x08)
	struct UPolygonSelectionMechanic* SelectionMechanic; // 0x280(0x08)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x288(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x290(0x08)
	struct UTransformProxy* TransformProxy; // 0x298(0x08)
	char pad_2a0[0x650]; // 0x2a0(0x650)
};

// Class MeshModelingTools.NewMeshMaterialProperties
// Size: 0x130 (Inherited: 0x120)
struct UNewMeshMaterialProperties : UInteractiveToolPropertySet {
	struct TWeakObjectPtr<struct UMaterialInterface> Material; // 0x118(0x08)
	float UVScale; // 0x120(0x04)
	bool bWorldSpaceUVScale; // 0x124(0x01)
	bool bShowWireframe; // 0x125(0x01)
	bool bShowExtendedOptions; // 0x126(0x01)
	char pad_12f[0x1]; // 0x12f(0x01)
};

// Class MeshModelingTools.ExistingMeshMaterialProperties
// Size: 0x150 (Inherited: 0x120)
struct UExistingMeshMaterialProperties : UInteractiveToolPropertySet {
	enum class ESetMeshMaterialMode MaterialMode; // 0x118(0x01)
	float CheckerDensity; // 0x11c(0x04)
	struct UMaterialInterface* OverrideMaterial; // 0x120(0x08)
	struct FString UVChannel; // 0x128(0x10)
	struct TArray<struct FString> UVChannelNamesList; // 0x138(0x10)
	struct UMaterialInstanceDynamic* CheckerMaterial; // 0x148(0x08)

	struct TArray<struct FString> GetUVChannelNamesFunc(); // Function MeshModelingTools.ExistingMeshMaterialProperties.GetUVChannelNamesFunc // (Final|Native|Public|Const) // @ game+0x9511c80
};

// Class MeshModelingTools.MeshEditingViewProperties
// Size: 0x170 (Inherited: 0x120)
struct UMeshEditingViewProperties : UInteractiveToolPropertySet {
	bool bShowWireframe; // 0x118(0x01)
	enum class EMeshEditingMaterialModes MaterialMode; // 0x11c(0x04)
	bool bFlatShading; // 0x120(0x01)
	struct FLinearColor Color; // 0x124(0x10)
	char pad_136[0x2]; // 0x136(0x02)
	struct UTexture2D* Image; // 0x138(0x08)
	double Opacity; // 0x140(0x08)
	struct FLinearColor TransparentMaterialColor; // 0x148(0x10)
	bool bTwoSided; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	struct TWeakObjectPtr<struct UMaterialInterface> CustomMaterial; // 0x15c(0x08)
	char pad_164[0xc]; // 0x164(0x0c)
};

// Class MeshModelingTools.MeshUVChannelProperties
// Size: 0x140 (Inherited: 0x120)
struct UMeshUVChannelProperties : UInteractiveToolPropertySet {
	struct FString UVChannel; // 0x118(0x10)
	struct TArray<struct FString> UVChannelNamesList; // 0x128(0x10)

	struct TArray<struct FString> GetUVChannelNamesFunc(); // Function MeshModelingTools.MeshUVChannelProperties.GetUVChannelNamesFunc // (Final|Native|Public|Const) // @ game+0x955a840
};

// Class MeshModelingTools.RecomputeUVsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct URecomputeUVsToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingTools.RecomputeUVsTool
// Size: 0x190 (Inherited: 0x130)
struct URecomputeUVsTool : USingleSelectionMeshEditingTool {
	struct UMeshUVChannelProperties* UVChannelProperties; // 0x130(0x08)
	struct URecomputeUVsToolProperties* Settings; // 0x138(0x08)
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0x140(0x08)
	struct UExistingMeshMaterialProperties* MaterialSettings; // 0x148(0x08)
	bool bCreateUVLayoutViewOnSetup; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct UUVLayoutPreview* UVLayoutView; // 0x158(0x08)
	struct URecomputeUVsOpFactory* RecomputeUVsOpFactory; // 0x160(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x168(0x08)
	char pad_170[0x20]; // 0x170(0x20)
};

// Class MeshModelingTools.PolyEditBevelEdgeProperties
// Size: 0x120 (Inherited: 0x120)
struct UPolyEditBevelEdgeProperties : UInteractiveToolPropertySet {
	double BevelDistance; // 0x118(0x08)
};

// Class MeshModelingTools.PolyEditBevelEdgeActivity
// Size: 0x1b0 (Inherited: 0xa0)
struct UPolyEditBevelEdgeActivity : UInteractiveToolActivity {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct UPolyEditBevelEdgeProperties* BevelProperties; // 0xa8(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xb0(0x08)
	char pad_b8[0xf8]; // 0xb8(0xf8)
};

// Class MeshModelingTools.PolyEditCutProperties
// Size: 0x120 (Inherited: 0x120)
struct UPolyEditCutProperties : UInteractiveToolPropertySet {
	enum class EPolyEditCutPlaneOrientation Orientation; // 0x118(0x04)
	bool bSnapToVertices; // 0x11c(0x01)
};

// Class MeshModelingTools.PolyEditCutFacesActivity
// Size: 0x130 (Inherited: 0xa0)
struct UPolyEditCutFacesActivity : UInteractiveToolActivity {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UPolyEditCutProperties* CutProperties; // 0xb0(0x08)
	struct UPolyEditPreviewMesh* EditPreview; // 0xb8(0x08)
	struct UCollectSurfacePathMechanic* SurfacePathMechanic; // 0xc0(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xc8(0x08)
	char pad_d0[0x60]; // 0xd0(0x60)
};

// Class MeshModelingTools.PolyEditExtrudeProperties
// Size: 0x150 (Inherited: 0x120)
struct UPolyEditExtrudeProperties : UInteractiveToolPropertySet {
	enum class EPolyEditExtrudeDistanceMode DistanceMode; // 0x118(0x04)
	double Distance; // 0x120(0x08)
	enum class EPolyEditExtrudeDirection Direction; // 0x128(0x04)
	enum class EPolyEditExtrudeDirection MeasureDirection; // 0x12c(0x04)
	bool bShellsToSolids; // 0x130(0x01)
	enum class EPolyEditExtrudeModeOptions DirectionMode; // 0x134(0x04)
	double MaxDistanceScaleFactor; // 0x138(0x08)
	bool bUseColinearityForSettingBorderGroups; // 0x140(0x01)
	char pad_142[0xe]; // 0x142(0x0e)
};

// Class MeshModelingTools.PolyEditOffsetProperties
// Size: 0x150 (Inherited: 0x120)
struct UPolyEditOffsetProperties : UInteractiveToolPropertySet {
	enum class EPolyEditExtrudeDistanceMode DistanceMode; // 0x118(0x04)
	double Distance; // 0x120(0x08)
	enum class EPolyEditOffsetModeOptions DirectionMode; // 0x128(0x04)
	double MaxDistanceScaleFactor; // 0x130(0x08)
	bool bShellsToSolids; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	enum class EPolyEditExtrudeDirection MeasureDirection; // 0x13c(0x04)
	bool bUseColinearityForSettingBorderGroups; // 0x140(0x01)
	char pad_141[0xf]; // 0x141(0x0f)
};

// Class MeshModelingTools.PolyEditPushPullProperties
// Size: 0x150 (Inherited: 0x120)
struct UPolyEditPushPullProperties : UInteractiveToolPropertySet {
	enum class EPolyEditExtrudeDistanceMode DistanceMode; // 0x118(0x04)
	double Distance; // 0x120(0x08)
	enum class EPolyEditPushPullModeOptions DirectionMode; // 0x128(0x04)
	double MaxDistanceScaleFactor; // 0x130(0x08)
	bool bShellsToSolids; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	enum class EPolyEditExtrudeDirection MeasureDirection; // 0x13c(0x04)
	bool bUseColinearityForSettingBorderGroups; // 0x140(0x01)
	char pad_141[0xf]; // 0x141(0x0f)
};

// Class MeshModelingTools.PolyEditExtrudeActivity
// Size: 0x240 (Inherited: 0xa0)
struct UPolyEditExtrudeActivity : UInteractiveToolActivity {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct UPolyEditExtrudeProperties* ExtrudeProperties; // 0xc0(0x08)
	struct UPolyEditOffsetProperties* OffsetProperties; // 0xc8(0x08)
	struct UPolyEditPushPullProperties* PushPullProperties; // 0xd0(0x08)
	struct UPlaneDistanceFromHitMechanic* ExtrudeHeightMechanic; // 0xd8(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xe0(0x08)
	char pad_e8[0x158]; // 0xe8(0x158)
};

// Class MeshModelingTools.GroupEdgeInsertionProperties
// Size: 0x130 (Inherited: 0x120)
struct UGroupEdgeInsertionProperties : UInteractiveToolPropertySet {
	enum class EGroupEdgeInsertionMode InsertionMode; // 0x118(0x04)
	bool bContinuousInsertion; // 0x11c(0x01)
	double VertexTolerance; // 0x120(0x08)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingTools.PolyEditInsertEdgeActivity
// Size: 0x4e0 (Inherited: 0xa0)
struct UPolyEditInsertEdgeActivity : UInteractiveToolActivity {
	char pad_a0[0x18]; // 0xa0(0x18)
	struct UGroupEdgeInsertionProperties* Settings; // 0xb8(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xc0(0x08)
	char pad_c8[0x418]; // 0xc8(0x418)
};

// Class MeshModelingTools.EdgeLoopInsertionProperties
// Size: 0x150 (Inherited: 0x120)
struct UEdgeLoopInsertionProperties : UInteractiveToolPropertySet {
	enum class EEdgeLoopPositioningMode PositionMode; // 0x118(0x04)
	enum class EEdgeLoopInsertionMode InsertionMode; // 0x11c(0x04)
	int32_t NumLoops; // 0x120(0x04)
	double ProportionOffset; // 0x128(0x08)
	double DistanceOffset; // 0x130(0x08)
	bool bInteractive; // 0x138(0x01)
	bool bFlipOffsetDirection; // 0x139(0x01)
	bool bHighlightProblemGroups; // 0x13a(0x01)
	char pad_13f[0x1]; // 0x13f(0x01)
	double VertexTolerance; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class MeshModelingTools.PolyEditInsertEdgeLoopActivity
// Size: 0x470 (Inherited: 0xa0)
struct UPolyEditInsertEdgeLoopActivity : UInteractiveToolActivity {
	char pad_a0[0x18]; // 0xa0(0x18)
	struct UEdgeLoopInsertionProperties* Settings; // 0xb8(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xc0(0x08)
	char pad_c8[0x3a8]; // 0xc8(0x3a8)
};

// Class MeshModelingTools.PolyEditInsetOutsetProperties
// Size: 0x130 (Inherited: 0x120)
struct UPolyEditInsetOutsetProperties : UInteractiveToolPropertySet {
	float Softness; // 0x118(0x04)
	bool bBoundaryOnly; // 0x11c(0x01)
	float AreaScale; // 0x120(0x04)
	bool bReproject; // 0x124(0x01)
	bool bOutset; // 0x125(0x01)
	char pad_12b[0x5]; // 0x12b(0x05)
};

// Class MeshModelingTools.PolyEditInsetOutsetActivity
// Size: 0xe0 (Inherited: 0xa0)
struct UPolyEditInsetOutsetActivity : UInteractiveToolActivity {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UPolyEditInsetOutsetProperties* Settings; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
	struct UPolyEditPreviewMesh* EditPreview; // 0xc0(0x08)
	struct USpatialCurveDistanceMechanic* CurveDistMechanic; // 0xc8(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class MeshModelingTools.PolyEditSetUVProperties
// Size: 0x120 (Inherited: 0x120)
struct UPolyEditSetUVProperties : UInteractiveToolPropertySet {
	bool bShowMaterial; // 0x118(0x01)
};

// Class MeshModelingTools.PolyEditPlanarProjectionUVActivity
// Size: 0x160 (Inherited: 0xa0)
struct UPolyEditPlanarProjectionUVActivity : UInteractiveToolActivity {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UPolyEditSetUVProperties* SetUVProperties; // 0xb0(0x08)
	struct UPolyEditPreviewMesh* EditPreview; // 0xb8(0x08)
	struct UCollectSurfacePathMechanic* SurfacePathMechanic; // 0xc0(0x08)
	struct UPolyEditActivityContext* ActivityContext; // 0xc8(0x08)
	char pad_d0[0x90]; // 0xd0(0x90)
};

// Class MeshModelingTools.UVLayoutToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UUVLayoutToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingTools.UVLayoutTool
// Size: 0x1e0 (Inherited: 0x130)
struct UUVLayoutTool : UMultiSelectionMeshEditingTool {
	struct UMeshUVChannelProperties* UVChannelProperties; // 0x130(0x08)
	struct UUVLayoutProperties* BasicProperties; // 0x138(0x08)
	struct UExistingMeshMaterialProperties* MaterialSettings; // 0x140(0x08)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews; // 0x148(0x10)
	struct TArray<struct UUVLayoutOperatorFactory*> Factories; // 0x158(0x10)
	char pad_168[0x68]; // 0x168(0x68)
	struct UUVLayoutPreview* UVLayoutView; // 0x1d0(0x08)
	char pad_1d8[0x8]; // 0x1d8(0x08)
};

// Class MeshModelingTools.UVProjectionToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UUVProjectionToolBuilder : USingleTargetWithSelectionToolBuilder {
};

// Class MeshModelingTools.UVProjectionToolEditActions
// Size: 0x120 (Inherited: 0x120)
struct UUVProjectionToolEditActions : UInteractiveToolPropertySet {

	void Reset(); // Function MeshModelingTools.UVProjectionToolEditActions.Reset // (Final|Native|Public) // @ game+0x9512710
	void AutoFitAlign(); // Function MeshModelingTools.UVProjectionToolEditActions.AutoFitAlign // (Final|Native|Public) // @ game+0x9528510
	void AutoFit(); // Function MeshModelingTools.UVProjectionToolEditActions.AutoFit // (Final|Native|Public) // @ game+0x9535250
};

// Class MeshModelingTools.UVProjectionToolProperties
// Size: 0x200 (Inherited: 0x120)
struct UUVProjectionToolProperties : UInteractiveToolPropertySet {
	enum class EUVProjectionMethod ProjectionType; // 0x118(0x01)
	struct FVector Dimensions; // 0x120(0x18)
	bool bProportionalDimensions; // 0x138(0x01)
	char pad_13a[0x2]; // 0x13a(0x02)
	enum class EUVProjectionToolInitializationMode Initialization; // 0x13c(0x04)
	float CylinderSplitAngle; // 0x140(0x04)
	float ExpMapNormalBlending; // 0x144(0x04)
	int32_t ExpMapSmoothingSteps; // 0x148(0x04)
	float ExpMapSmoothingAlpha; // 0x14c(0x04)
	float Rotation; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct FVector2D Scale; // 0x158(0x10)
	struct FVector2D Translation; // 0x168(0x10)
	struct FVector SavedDimensions; // 0x178(0x18)
	bool bSavedProportionalDimensions; // 0x190(0x01)
	char pad_191[0xf]; // 0x191(0x0f)
	struct FTransform SavedTransform; // 0x1a0(0x60)
};

// Class MeshModelingTools.UVProjectionOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UUVProjectionOperatorFactory : UObject {
	struct UUVProjectionTool* Tool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingTools.UVProjectionTool
// Size: 0x550 (Inherited: 0x1a0)
struct UUVProjectionTool : USingleTargetWithSelectionTool {
	struct UMeshUVChannelProperties* UVChannelProperties; // 0x198(0x08)
	struct UUVProjectionToolProperties* BasicProperties; // 0x1a0(0x08)
	struct UUVProjectionToolEditActions* EditActions; // 0x1a8(0x08)
	struct UExistingMeshMaterialProperties* MaterialSettings; // 0x1b0(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x1b8(0x08)
	struct UMaterialInstanceDynamic* CheckerMaterial; // 0x1c0(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x1c8(0x08)
	struct UTransformProxy* TransformProxy; // 0x1d0(0x08)
	struct UUVProjectionOperatorFactory* OperatorFactory; // 0x1d8(0x08)
	struct UPreviewGeometry* EdgeRenderer; // 0x1e0(0x08)
	char pad_1f0[0x348]; // 0x1f0(0x348)
	struct USingleClickInputBehavior* ClickToSetPlaneBehavior; // 0x538(0x08)
	char pad_540[0x10]; // 0x540(0x10)
};

