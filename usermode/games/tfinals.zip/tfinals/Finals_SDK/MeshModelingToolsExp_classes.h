// Class MeshModelingToolsExp.BakeInputMeshProperties
// Size: 0x1b0 (Inherited: 0x120)
struct UBakeInputMeshProperties : UInteractiveToolPropertySet {
	struct UStaticMesh* TargetStaticMesh; // 0x118(0x08)
	struct USkeletalMesh* TargetSkeletalMesh; // 0x120(0x08)
	struct AActor* TargetDynamicMesh; // 0x128(0x08)
	struct FString TargetUVLayer; // 0x130(0x10)
	bool bHasTargetUVLayer; // 0x140(0x01)
	struct UStaticMesh* SourceStaticMesh; // 0x148(0x08)
	struct USkeletalMesh* SourceSkeletalMesh; // 0x150(0x08)
	struct AActor* SourceDynamicMesh; // 0x158(0x08)
	bool bHideSourceMesh; // 0x160(0x01)
	char pad_162[0x6]; // 0x162(0x06)
	struct UTexture2D* SourceNormalMap; // 0x168(0x08)
	struct FString SourceNormalMapUVLayer; // 0x170(0x10)
	enum class EBakeNormalSpace SourceNormalSpace; // 0x180(0x04)
	bool bHasSourceNormalMap; // 0x184(0x01)
	char pad_185[0x3]; // 0x185(0x03)
	float ProjectionDistance; // 0x188(0x04)
	bool bProjectionInWorldSpace; // 0x18c(0x01)
	char pad_18d[0x3]; // 0x18d(0x03)
	struct TArray<struct FString> TargetUVLayerNamesList; // 0x190(0x10)
	struct TArray<struct FString> SourceUVLayerNamesList; // 0x1a0(0x10)

	struct TArray<struct FString> GetTargetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeInputMeshProperties.GetTargetUVLayerNamesFunc // (Final|Native|Public|Const) // @ game+0x957eca0
	struct TArray<struct FString> GetSourceUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeInputMeshProperties.GetSourceUVLayerNamesFunc // (Final|Native|Public|Const) // @ game+0x95832c0
};

// Class MeshModelingToolsExp.BakeNormalMapToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UBakeNormalMapToolProperties : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.BakeOcclusionMapToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UBakeOcclusionMapToolProperties : UInteractiveToolPropertySet {
	int32_t OcclusionRays; // 0x118(0x04)
	float MaxDistance; // 0x11c(0x04)
	float SpreadAngle; // 0x120(0x04)
	float BiasAngle; // 0x124(0x04)
};

// Class MeshModelingToolsExp.BakeCurvatureMapToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UBakeCurvatureMapToolProperties : UInteractiveToolPropertySet {
	enum class EBakeCurvatureTypeMode CurvatureType; // 0x118(0x04)
	enum class EBakeCurvatureColorMode ColorMapping; // 0x11c(0x04)
	float ColorRangeMultiplier; // 0x120(0x04)
	float MinRangeMultiplier; // 0x124(0x04)
	enum class EBakeCurvatureClampMode Clamping; // 0x128(0x04)
};

// Class MeshModelingToolsExp.BakeTexture2DProperties
// Size: 0x140 (Inherited: 0x120)
struct UBakeTexture2DProperties : UInteractiveToolPropertySet {
	struct UTexture2D* SourceTexture; // 0x118(0x08)
	struct FString UVLayer; // 0x120(0x10)
	struct TArray<struct FString> UVLayerNamesList; // 0x130(0x10)

	struct TArray<struct FString> GetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeTexture2DProperties.GetUVLayerNamesFunc // (Final|Native|Public|Const) // @ game+0x94520e0
};

// Class MeshModelingToolsExp.BakeMultiTexture2DProperties
// Size: 0x160 (Inherited: 0x120)
struct UBakeMultiTexture2DProperties : UInteractiveToolPropertySet {
	struct TArray<struct UTexture2D*> MaterialIDSourceTextures; // 0x118(0x10)
	struct FString UVLayer; // 0x128(0x10)
	struct TArray<struct FString> UVLayerNamesList; // 0x138(0x10)
	struct TArray<struct UTexture2D*> AllSourceTextures; // 0x148(0x10)

	struct TArray<struct FString> GetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeMultiTexture2DProperties.GetUVLayerNamesFunc // (Final|Native|Public|Const) // @ game+0x9511c80
};

// Class MeshModelingToolsExp.BakeVisualizationProperties
// Size: 0x130 (Inherited: 0x120)
struct UBakeVisualizationProperties : UInteractiveToolPropertySet {
	bool bPreviewAsMaterial; // 0x118(0x01)
	float Brightness; // 0x11c(0x04)
	float AOMultiplier; // 0x120(0x04)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.ExtrudeMeshSelectionToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UExtrudeMeshSelectionToolBuilder : USingleTargetWithSelectionToolBuilder {
};

// Class MeshModelingToolsExp.ExtrudeMeshSelectionToolProperties
// Size: 0x160 (Inherited: 0x120)
struct UExtrudeMeshSelectionToolProperties : UInteractiveToolPropertySet {
	enum class EExtrudeMeshSelectionInteractionMode InputMode; // 0x118(0x01)
	double ExtrudeDistance; // 0x120(0x08)
	enum class EExtrudeMeshSelectionRegionModifierMode RegionMode; // 0x128(0x01)
	char pad_12a[0x2]; // 0x12a(0x02)
	int32_t NumSubdivisions; // 0x12c(0x04)
	double CreaseAngle; // 0x130(0x08)
	double RaycastMaxDistance; // 0x138(0x08)
	bool bShellsToSolids; // 0x140(0x01)
	bool bInferGroupsFromNbrs; // 0x141(0x01)
	bool bGroupPerSubdivision; // 0x142(0x01)
	bool bReplaceSelectionGroups; // 0x143(0x01)
	char pad_144[0x4]; // 0x144(0x04)
	double UVScale; // 0x148(0x08)
	bool bUVIslandPerGroup; // 0x150(0x01)
	bool bInferMaterialID; // 0x151(0x01)
	char pad_152[0x2]; // 0x152(0x02)
	int32_t SetMaterialID; // 0x154(0x04)
	bool bShowInputMaterials; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
};

// Class MeshModelingToolsExp.ExtrudeMeshSelectionTool
// Size: 0x8e0 (Inherited: 0x1a0)
struct UExtrudeMeshSelectionTool : USingleTargetWithSelectionTool {
	struct UExtrudeMeshSelectionToolProperties* ExtrudeProperties; // 0x198(0x08)
	char pad_1a8[0x718]; // 0x1a8(0x718)
	struct UPreviewMesh* SourcePreview; // 0x8c0(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* EditCompute; // 0x8c8(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x8d0(0x08)
	struct UTransformProxy* TransformProxy; // 0x8d8(0x08)
};

// Class MeshModelingToolsExp.MeshSculptBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UMeshSculptBrushOpProps : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.BaseKelvinletBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UBaseKelvinletBrushOpProps : UMeshSculptBrushOpProps {
	float Stiffness; // 0x118(0x04)
	float Incompressiblity; // 0x11c(0x04)
	int32_t BrushSteps; // 0x120(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)
};

// Class MeshModelingToolsExp.ScaleKelvinletBrushOpProps
// Size: 0x130 (Inherited: 0x130)
struct UScaleKelvinletBrushOpProps : UBaseKelvinletBrushOpProps {
	float Strength; // 0x128(0x04)
	float Falloff; // 0x12c(0x04)
};

// Class MeshModelingToolsExp.PullKelvinletBrushOpProps
// Size: 0x130 (Inherited: 0x130)
struct UPullKelvinletBrushOpProps : UBaseKelvinletBrushOpProps {
	float Falloff; // 0x128(0x04)
	float Depth; // 0x12c(0x04)
};

// Class MeshModelingToolsExp.SharpPullKelvinletBrushOpProps
// Size: 0x130 (Inherited: 0x130)
struct USharpPullKelvinletBrushOpProps : UBaseKelvinletBrushOpProps {
	float Falloff; // 0x128(0x04)
	float Depth; // 0x12c(0x04)
};

// Class MeshModelingToolsExp.TwistKelvinletBrushOpProps
// Size: 0x130 (Inherited: 0x130)
struct UTwistKelvinletBrushOpProps : UBaseKelvinletBrushOpProps {
	float Strength; // 0x128(0x04)
	float Falloff; // 0x12c(0x04)
};

// Class MeshModelingToolsExp.GroupEraseBrushOpProps
// Size: 0x160 (Inherited: 0x120)
struct UGroupEraseBrushOpProps : UMeshSculptBrushOpProps {
	int32_t Group; // 0x118(0x04)
	bool bOnlyEraseCurrent; // 0x11c(0x01)
	char pad_125[0x3b]; // 0x125(0x3b)
};

// Class MeshModelingToolsExp.GroupPaintBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UGroupPaintBrushOpProps : UMeshSculptBrushOpProps {
	int32_t Group; // 0x118(0x04)
	bool bOnlyPaintUngrouped; // 0x11c(0x01)
};

// Class MeshModelingToolsExp.InflateBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UInflateBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
};

// Class MeshModelingToolsExp.MoveBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UMoveBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float Depth; // 0x120(0x04)
	struct FModelingToolsAxisFilter AxisFilters; // 0x124(0x03)
	char pad_12f[0x1]; // 0x12f(0x01)
};

// Class MeshModelingToolsExp.PinchBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UPinchBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float Depth; // 0x120(0x04)
	bool bPerpDamping; // 0x124(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.BasePlaneBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UBasePlaneBrushOpProps : UMeshSculptBrushOpProps {
};

// Class MeshModelingToolsExp.PlaneBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UPlaneBrushOpProps : UBasePlaneBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float Depth; // 0x120(0x04)
	enum class EPlaneBrushSideMode WhichSide; // 0x124(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.ViewAlignedPlaneBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UViewAlignedPlaneBrushOpProps : UBasePlaneBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float Depth; // 0x120(0x04)
	enum class EPlaneBrushSideMode WhichSide; // 0x124(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.FixedPlaneBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UFixedPlaneBrushOpProps : UBasePlaneBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float Depth; // 0x120(0x04)
	enum class EPlaneBrushSideMode WhichSide; // 0x124(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.StandardSculptBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UStandardSculptBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
};

// Class MeshModelingToolsExp.ViewAlignedSculptBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UViewAlignedSculptBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
};

// Class MeshModelingToolsExp.SculptMaxBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct USculptMaxBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float MaxHeight; // 0x120(0x04)
	bool bUseFixedHeight; // 0x124(0x01)
	float FixedHeight; // 0x128(0x04)
};

// Class MeshModelingToolsExp.BaseSmoothBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UBaseSmoothBrushOpProps : UMeshSculptBrushOpProps {
};

// Class MeshModelingToolsExp.SmoothBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct USmoothBrushOpProps : UBaseSmoothBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	bool bPreserveUVFlow; // 0x120(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.SecondarySmoothBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct USecondarySmoothBrushOpProps : UBaseSmoothBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	bool bPreserveUVFlow; // 0x120(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.SmoothFillBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct USmoothFillBrushOpProps : UBaseSmoothBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	bool bPreserveUVFlow; // 0x120(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.FlattenBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UFlattenBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	float Depth; // 0x120(0x04)
	enum class EPlaneBrushSideMode WhichSide; // 0x124(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.EraseBrushOpProps
// Size: 0x120 (Inherited: 0x120)
struct UEraseBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
};

// Class MeshModelingToolsExp.VertexColorBaseBrushOpProps
// Size: 0x130 (Inherited: 0x120)
struct UVertexColorBaseBrushOpProps : UMeshSculptBrushOpProps {
	float Strength; // 0x118(0x04)
	float Falloff; // 0x11c(0x04)
	enum class EVertexColorPaintBrushOpBlendMode BlendMode; // 0x120(0x04)
	bool bApplyFalloff; // 0x124(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.VertexColorPaintBrushOpProps
// Size: 0x140 (Inherited: 0x130)
struct UVertexColorPaintBrushOpProps : UVertexColorBaseBrushOpProps {
	struct FLinearColor Color; // 0x128(0x10)
};

// Class MeshModelingToolsExp.VertexColorSoftenBrushOpProps
// Size: 0x130 (Inherited: 0x130)
struct UVertexColorSoftenBrushOpProps : UVertexColorBaseBrushOpProps {
};

// Class MeshModelingToolsExp.VertexColorSmoothBrushOpProps
// Size: 0x130 (Inherited: 0x130)
struct UVertexColorSmoothBrushOpProps : UVertexColorBaseBrushOpProps {
};

// Class MeshModelingToolsExp.OffsetMeshSelectionToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UOffsetMeshSelectionToolBuilder : USingleTargetWithSelectionToolBuilder {
};

// Class MeshModelingToolsExp.OffsetMeshSelectionToolProperties
// Size: 0x150 (Inherited: 0x120)
struct UOffsetMeshSelectionToolProperties : UInteractiveToolPropertySet {
	double OffsetDistance; // 0x118(0x08)
	enum class EOffsetMeshSelectionDirectionMode Direction; // 0x120(0x01)
	int32_t NumSubdivisions; // 0x124(0x04)
	double CreaseAngle; // 0x128(0x08)
	bool bShellsToSolids; // 0x130(0x01)
	bool bInferGroupsFromNbrs; // 0x131(0x01)
	bool bGroupPerSubdivision; // 0x132(0x01)
	bool bReplaceSelectionGroups; // 0x133(0x01)
	double UVScale; // 0x138(0x08)
	bool bUVIslandPerGroup; // 0x140(0x01)
	bool bInferMaterialID; // 0x141(0x01)
	char pad_143[0x1]; // 0x143(0x01)
	int32_t SetMaterialID; // 0x144(0x04)
	bool bShowInputMaterials; // 0x148(0x01)
	char pad_149[0x7]; // 0x149(0x07)
};

// Class MeshModelingToolsExp.OffsetMeshSelectionTool
// Size: 0x8d0 (Inherited: 0x1a0)
struct UOffsetMeshSelectionTool : USingleTargetWithSelectionTool {
	struct UOffsetMeshSelectionToolProperties* OffsetProperties; // 0x198(0x08)
	char pad_1a8[0x718]; // 0x1a8(0x718)
	struct UPreviewMesh* SourcePreview; // 0x8c0(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* EditCompute; // 0x8c8(0x08)
};

// Class MeshModelingToolsExp.PatternToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UPatternToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.PatternToolSettings
// Size: 0x130 (Inherited: 0x120)
struct UPatternToolSettings : UInteractiveToolPropertySet {
	int32_t Seed; // 0x118(0x04)
	bool bProjectElementsDown; // 0x11c(0x01)
	float ProjectionOffset; // 0x120(0x04)
	bool bHideSources; // 0x124(0x01)
	bool bUseRelativeTransforms; // 0x125(0x01)
	bool bRandomlyPickElements; // 0x126(0x01)
	enum class EPatternToolShape Shape; // 0x127(0x01)
	enum class EPatternToolSingleAxis SingleAxis; // 0x128(0x01)
	enum class EPatternToolSinglePlane SinglePlane; // 0x129(0x01)
	char pad_12f[0x1]; // 0x12f(0x01)
};

// Class MeshModelingToolsExp.PatternTool_BoundingBoxSettings
// Size: 0x130 (Inherited: 0x120)
struct UPatternTool_BoundingBoxSettings : UInteractiveToolPropertySet {
	bool bIgnoreTransforms; // 0x118(0x01)
	float Adjustment; // 0x11c(0x04)
	bool bVisualize; // 0x120(0x01)
	char pad_126[0xa]; // 0x126(0x0a)
};

// Class MeshModelingToolsExp.PatternTool_LinearSettings
// Size: 0x140 (Inherited: 0x120)
struct UPatternTool_LinearSettings : UInteractiveToolPropertySet {
	enum class EPatternToolAxisSpacingMode SpacingMode; // 0x118(0x01)
	int32_t Count; // 0x11c(0x04)
	double StepSize; // 0x120(0x08)
	double Extent; // 0x128(0x08)
	bool bCentered; // 0x130(0x01)
	char pad_136[0xa]; // 0x136(0x0a)
};

// Class MeshModelingToolsExp.PatternTool_GridSettings
// Size: 0x150 (Inherited: 0x120)
struct UPatternTool_GridSettings : UInteractiveToolPropertySet {
	enum class EPatternToolAxisSpacingMode SpacingX; // 0x118(0x01)
	int32_t CountX; // 0x11c(0x04)
	double StepSizeX; // 0x120(0x08)
	double ExtentX; // 0x128(0x08)
	bool bCenteredX; // 0x130(0x01)
	enum class EPatternToolAxisSpacingMode SpacingY; // 0x131(0x01)
	int32_t CountY; // 0x134(0x04)
	double StepSizeY; // 0x138(0x08)
	double ExtentY; // 0x140(0x08)
	bool bCenteredY; // 0x148(0x01)
	char pad_14c[0x4]; // 0x14c(0x04)
};

// Class MeshModelingToolsExp.PatternTool_RadialSettings
// Size: 0x150 (Inherited: 0x120)
struct UPatternTool_RadialSettings : UInteractiveToolPropertySet {
	enum class EPatternToolAxisSpacingMode SpacingMode; // 0x118(0x01)
	int32_t Count; // 0x11c(0x04)
	double StepSize; // 0x120(0x08)
	double Radius; // 0x128(0x08)
	double StartAngle; // 0x130(0x08)
	double EndAngle; // 0x138(0x08)
	double AngleShift; // 0x140(0x08)
	bool bOriented; // 0x148(0x01)
	char pad_14e[0x2]; // 0x14e(0x02)
};

// Class MeshModelingToolsExp.PatternTool_RotationSettings
// Size: 0x170 (Inherited: 0x120)
struct UPatternTool_RotationSettings : UInteractiveToolPropertySet {
	bool bInterpolate; // 0x118(0x01)
	bool bJitter; // 0x119(0x01)
	struct FRotator StartRotation; // 0x120(0x18)
	struct FRotator EndRotation; // 0x138(0x18)
	struct FRotator Jitter; // 0x150(0x18)
	char pad_16a[0x6]; // 0x16a(0x06)
};

// Class MeshModelingToolsExp.PatternTool_TranslationSettings
// Size: 0x170 (Inherited: 0x120)
struct UPatternTool_TranslationSettings : UInteractiveToolPropertySet {
	bool bInterpolate; // 0x118(0x01)
	bool bJitter; // 0x119(0x01)
	struct FVector StartTranslation; // 0x120(0x18)
	struct FVector EndTranslation; // 0x138(0x18)
	struct FVector Jitter; // 0x150(0x18)
	char pad_16a[0x6]; // 0x16a(0x06)
};

// Class MeshModelingToolsExp.PatternTool_ScaleSettings
// Size: 0x170 (Inherited: 0x120)
struct UPatternTool_ScaleSettings : UInteractiveToolPropertySet {
	bool bProportional; // 0x118(0x01)
	bool bInterpolate; // 0x119(0x01)
	bool bJitter; // 0x11a(0x01)
	struct FVector StartScale; // 0x120(0x18)
	struct FVector EndScale; // 0x138(0x18)
	struct FVector Jitter; // 0x150(0x18)
	char pad_16b[0x5]; // 0x16b(0x05)
};

// Class MeshModelingToolsExp.PatternTool_OutputSettings
// Size: 0x120 (Inherited: 0x120)
struct UPatternTool_OutputSettings : UInteractiveToolPropertySet {
	bool bSeparateActors; // 0x118(0x01)
	bool bConvertToDynamic; // 0x119(0x01)
	bool bCreateISMCs; // 0x11a(0x01)
	bool bHaveStaticMeshes; // 0x11b(0x01)
	bool bEnableCreateISMCs; // 0x11c(0x01)
};

// Class MeshModelingToolsExp.PatternTool
// Size: 0x530 (Inherited: 0x130)
struct UPatternTool : UMultiSelectionMeshEditingTool {
	struct UPatternToolSettings* Settings; // 0x130(0x08)
	struct UPatternTool_BoundingBoxSettings* BoundingBoxSettings; // 0x138(0x08)
	struct UPatternTool_LinearSettings* LinearSettings; // 0x140(0x08)
	struct UPatternTool_GridSettings* GridSettings; // 0x148(0x08)
	struct UPatternTool_RadialSettings* RadialSettings; // 0x150(0x08)
	struct UPatternTool_RotationSettings* RotationSettings; // 0x158(0x08)
	struct UPatternTool_TranslationSettings* TranslationSettings; // 0x160(0x08)
	struct UPatternTool_ScaleSettings* ScaleSettings; // 0x168(0x08)
	char pad_170[0x58]; // 0x170(0x58)
	struct UPatternTool_OutputSettings* OutputSettings; // 0x1c8(0x08)
	char pad_1d0[0x48]; // 0x1d0(0x48)
	struct UTransformProxy* PatternGizmoProxy; // 0x218(0x08)
	struct UCombinedTransformGizmo* PatternGizmo; // 0x220(0x08)
	char pad_228[0x18]; // 0x228(0x18)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x240(0x08)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x248(0x08)
	char pad_250[0x1e8]; // 0x250(0x1e8)
	struct TSet<struct UPrimitiveComponent*> AllComponents; // 0x438(0x50)
	char pad_488[0xa0]; // 0x488(0xa0)
	struct UPreviewGeometry* PreviewGeometry; // 0x528(0x08)
};

// Class MeshModelingToolsExp.MeshConstraintProperties
// Size: 0x120 (Inherited: 0x120)
struct UMeshConstraintProperties : UInteractiveToolPropertySet {
	bool bPreserveSharpEdges; // 0x118(0x01)
	enum class EMeshBoundaryConstraint MeshBoundaryConstraint; // 0x119(0x01)
	enum class EGroupBoundaryConstraint GroupBoundaryConstraint; // 0x11a(0x01)
	enum class EMaterialBoundaryConstraint MaterialBoundaryConstraint; // 0x11b(0x01)
	bool bPreventNormalFlips; // 0x11c(0x01)
	bool bPreventTinyTriangles; // 0x11d(0x01)

	bool IsPreventTinyTrianglesEnabled(); // Function MeshModelingToolsExp.MeshConstraintProperties.IsPreventTinyTrianglesEnabled // (Native|Protected|Const) // @ game+0x2b960b0
	bool IsPreventNormalFlipsEnabled(); // Function MeshModelingToolsExp.MeshConstraintProperties.IsPreventNormalFlipsEnabled // (Native|Protected|Const) // @ game+0x29eeb30
};

// Class MeshModelingToolsExp.RemeshProperties
// Size: 0x130 (Inherited: 0x120)
struct URemeshProperties : UMeshConstraintProperties {
	float SmoothingStrength; // 0x120(0x04)
	bool bFlips; // 0x124(0x01)
	bool bSplits; // 0x125(0x01)
	bool bCollapses; // 0x126(0x01)
	char pad_127[0x9]; // 0x127(0x09)
};

// Class MeshModelingToolsExp.RevolveSplineToolProperties
// Size: 0x1e0 (Inherited: 0x190)
struct URevolveSplineToolProperties : URevolveProperties {
	enum class ERevolveSplineSampleMode SampleMode; // 0x188(0x01)
	double ErrorTolerance; // 0x190(0x08)
	double MaxSampleDistance; // 0x198(0x08)
	enum class ERevolvePropertiesCapFillMode CapFillMode; // 0x1a0(0x01)
	bool bClosePathToAxis; // 0x1a1(0x01)
	char pad_1a3[0x5]; // 0x1a3(0x05)
	struct FVector AxisOrigin; // 0x1a8(0x18)
	struct FVector2D AxisOrientation; // 0x1c0(0x10)
	bool bResetAxisOnStart; // 0x1d0(0x01)
	char pad_1d1[0xf]; // 0x1d1(0x0f)
};

// Class MeshModelingToolsExp.RevolveSplineToolActionPropertySet
// Size: 0x120 (Inherited: 0x120)
struct URevolveSplineToolActionPropertySet : UInteractiveToolPropertySet {

	void ResetAxis(); // Function MeshModelingToolsExp.RevolveSplineToolActionPropertySet.ResetAxis // (Final|Native|Public) // @ game+0x9585d30
};

// Class MeshModelingToolsExp.RevolveSplineTool
// Size: 0x1f0 (Inherited: 0x110)
struct URevolveSplineTool : UInteractiveTool {
	char pad_110[0x10]; // 0x110(0x10)
	struct URevolveSplineToolProperties* Settings; // 0x120(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x128(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x130(0x08)
	struct URevolveSplineToolActionPropertySet* ToolActions; // 0x138(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x140(0x08)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x148(0x08)
	char pad_150[0xa0]; // 0x150(0xa0)
};

// Class MeshModelingToolsExp.RevolveSplineToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct URevolveSplineToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingToolsExp.AddPatchToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UAddPatchToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingToolsExp.AddPatchToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UAddPatchToolProperties : UInteractiveToolPropertySet {
	float Width; // 0x118(0x04)
	float Rotation; // 0x11c(0x04)
	int32_t Subdivisions; // 0x120(0x04)
	float Shift; // 0x124(0x04)
};

// Class MeshModelingToolsExp.AddPatchTool
// Size: 0x1a0 (Inherited: 0x120)
struct UAddPatchTool : USingleClickTool {
	struct UAddPatchToolProperties* ShapeSettings; // 0x120(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x128(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x130(0x08)
	char pad_138[0x68]; // 0x138(0x68)
};

// Class MeshModelingToolsExp.AlignObjectsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UAlignObjectsToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.AlignObjectsToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UAlignObjectsToolProperties : UInteractiveToolPropertySet {
	enum class EAlignObjectsAlignTypes AlignType; // 0x118(0x04)
	enum class EAlignObjectsAlignToOptions AlignTo; // 0x11c(0x04)
	enum class EAlignObjectsBoxPoint BoxPosition; // 0x120(0x04)
	bool bAlignX; // 0x124(0x01)
	bool bAlignY; // 0x125(0x01)
	bool bAlignZ; // 0x126(0x01)
	char pad_12f[0x1]; // 0x12f(0x01)
};

// Class MeshModelingToolsExp.AlignObjectsTool
// Size: 0x1d0 (Inherited: 0x130)
struct UAlignObjectsTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UAlignObjectsToolProperties* AlignProps; // 0x138(0x08)
	char pad_140[0x90]; // 0x140(0x90)
};

// Class MeshModelingToolsExp.BakeMeshAttributeMapsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBakeMeshAttributeMapsToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.BakeMeshAttributeMapsToolProperties
// Size: 0x1b0 (Inherited: 0x120)
struct UBakeMeshAttributeMapsToolProperties : UInteractiveToolPropertySet {
	int32_t MapTypes; // 0x118(0x04)
	struct FString MapPreview; // 0x120(0x10)
	enum class EBakeTextureResolution Resolution; // 0x130(0x04)
	enum class EBakeTextureBitDepth BitDepth; // 0x134(0x04)
	enum class EBakeTextureSamplesPerPixel SamplesPerPixel; // 0x138(0x04)
	struct UTexture2D* SampleFilterMask; // 0x140(0x08)
	struct TArray<struct FString> MapPreviewNamesList; // 0x148(0x10)
	char pad_158[0x58]; // 0x158(0x58)

	struct TArray<struct FString> GetMapPreviewNamesFunc(); // Function MeshModelingToolsExp.BakeMeshAttributeMapsToolProperties.GetMapPreviewNamesFunc // (Final|Native|Public) // @ game+0x9592b50
};

// Class MeshModelingToolsExp.BakeMeshAttributeTool
// Size: 0x500 (Inherited: 0x130)
struct UBakeMeshAttributeTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UBakeOcclusionMapToolProperties* OcclusionSettings; // 0x138(0x08)
	struct UBakeCurvatureMapToolProperties* CurvatureSettings; // 0x140(0x08)
	struct UBakeTexture2DProperties* TextureSettings; // 0x148(0x08)
	struct UBakeMultiTexture2DProperties* MultiTextureSettings; // 0x150(0x08)
	struct UMaterialInstanceDynamic* WorkingPreviewMaterial; // 0x158(0x08)
	struct UMaterialInstanceDynamic* ErrorPreviewMaterial; // 0x160(0x08)
	char pad_168[0x398]; // 0x168(0x398)
};

// Class MeshModelingToolsExp.BakeMeshAttributeMapsToolBase
// Size: 0x670 (Inherited: 0x500)
struct UBakeMeshAttributeMapsToolBase : UBakeMeshAttributeTool {
	struct UBakeVisualizationProperties* VisualizationProps; // 0x500(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x508(0x08)
	struct UMaterialInstanceDynamic* PreviewMaterial; // 0x510(0x08)
	struct UMaterialInstanceDynamic* BentNormalPreviewMaterial; // 0x518(0x08)
	char pad_520[0x50]; // 0x520(0x50)
	struct TMap<enum class EBakeMapType, struct UTexture2D*> CachedMaps; // 0x570(0x50)
	char pad_5c0[0x98]; // 0x5c0(0x98)
	struct UTexture2D* EmptyNormalMap; // 0x658(0x08)
	struct UTexture2D* EmptyColorMapBlack; // 0x660(0x08)
	struct UTexture2D* EmptyColorMapWhite; // 0x668(0x08)
};

// Class MeshModelingToolsExp.BakeMeshAttributeMapsTool
// Size: 0x6e0 (Inherited: 0x670)
struct UBakeMeshAttributeMapsTool : UBakeMeshAttributeMapsToolBase {
	struct UBakeInputMeshProperties* InputMeshSettings; // 0x670(0x08)
	struct UBakeMeshAttributeMapsToolProperties* Settings; // 0x678(0x08)
	struct UBakeMeshAttributeMapsResultToolProperties* ResultSettings; // 0x680(0x08)
	char pad_688[0x58]; // 0x688(0x58)
};

// Class MeshModelingToolsExp.BakeMeshAttributeMapsResultToolProperties
// Size: 0x170 (Inherited: 0x120)
struct UBakeMeshAttributeMapsResultToolProperties : UInteractiveToolPropertySet {
	struct TMap<enum class EBakeMapType, struct UTexture2D*> Result; // 0x118(0x50)
};

// Class MeshModelingToolsExp.BakeMeshAttributeVertexToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBakeMeshAttributeVertexToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.BakeMeshAttributeVertexToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UBakeMeshAttributeVertexToolProperties : UInteractiveToolPropertySet {
	enum class EBakeVertexOutput OutputMode; // 0x118(0x04)
	int32_t OutputType; // 0x11c(0x04)
	int32_t OutputTypeR; // 0x120(0x04)
	int32_t OutputTypeG; // 0x124(0x04)
	int32_t OutputTypeB; // 0x128(0x04)
	int32_t OutputTypeA; // 0x12c(0x04)
	enum class EBakeVertexChannel PreviewMode; // 0x130(0x04)
	bool bSplitAtNormalSeams; // 0x134(0x01)
	bool bSplitAtUVSeams; // 0x135(0x01)
	char pad_13e[0x2]; // 0x13e(0x02)
};

// Class MeshModelingToolsExp.BakeMeshAttributeVertexTool
// Size: 0x600 (Inherited: 0x500)
struct UBakeMeshAttributeVertexTool : UBakeMeshAttributeTool {
	struct UBakeInputMeshProperties* InputMeshSettings; // 0x500(0x08)
	struct UBakeMeshAttributeVertexToolProperties* Settings; // 0x508(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x510(0x08)
	struct UMaterialInstanceDynamic* PreviewMaterial; // 0x518(0x08)
	struct UMaterialInstanceDynamic* PreviewAlphaMaterial; // 0x520(0x08)
	char pad_528[0xd8]; // 0x528(0xd8)
};

// Class MeshModelingToolsExp.BakeMultiMeshAttributeMapsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBakeMultiMeshAttributeMapsToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.BakeMultiMeshAttributeMapsToolProperties
// Size: 0x1b0 (Inherited: 0x120)
struct UBakeMultiMeshAttributeMapsToolProperties : UInteractiveToolPropertySet {
	int32_t MapTypes; // 0x118(0x04)
	struct FString MapPreview; // 0x120(0x10)
	enum class EBakeTextureResolution Resolution; // 0x130(0x04)
	enum class EBakeTextureBitDepth BitDepth; // 0x134(0x04)
	enum class EBakeTextureSamplesPerPixel SamplesPerPixel; // 0x138(0x04)
	struct UTexture2D* SampleFilterMask; // 0x140(0x08)
	struct TArray<struct FString> MapPreviewNamesList; // 0x148(0x10)
	char pad_158[0x58]; // 0x158(0x58)

	struct TArray<struct FString> GetMapPreviewNamesFunc(); // Function MeshModelingToolsExp.BakeMultiMeshAttributeMapsToolProperties.GetMapPreviewNamesFunc // (Final|Native|Public) // @ game+0x9592b50
};

// Class MeshModelingToolsExp.BakeMultiMeshInputToolProperties
// Size: 0x170 (Inherited: 0x120)
struct UBakeMultiMeshInputToolProperties : UInteractiveToolPropertySet {
	struct UStaticMesh* TargetStaticMesh; // 0x118(0x08)
	struct USkeletalMesh* TargetSkeletalMesh; // 0x120(0x08)
	struct AActor* TargetDynamicMesh; // 0x128(0x08)
	struct FString TargetUVLayer; // 0x130(0x10)
	struct TArray<struct FBakeMultiMeshDetailProperties> SourceMeshes; // 0x140(0x10)
	float ProjectionDistance; // 0x150(0x04)
	struct TArray<struct FString> TargetUVLayerNamesList; // 0x158(0x10)
	char pad_16c[0x4]; // 0x16c(0x04)

	struct TArray<struct FString> GetTargetUVLayerNamesFunc(); // Function MeshModelingToolsExp.BakeMultiMeshInputToolProperties.GetTargetUVLayerNamesFunc // (Final|Native|Public|Const) // @ game+0x95faeb0
};

// Class MeshModelingToolsExp.BakeMultiMeshAttributeMapsTool
// Size: 0x720 (Inherited: 0x670)
struct UBakeMultiMeshAttributeMapsTool : UBakeMeshAttributeMapsToolBase {
	struct UBakeMultiMeshAttributeMapsToolProperties* Settings; // 0x670(0x08)
	struct UBakeMultiMeshInputToolProperties* InputMeshSettings; // 0x678(0x08)
	struct UBakeMeshAttributeMapsResultToolProperties* ResultSettings; // 0x680(0x08)
	char pad_688[0x98]; // 0x688(0x98)
};

// Class MeshModelingToolsExp.BakeTransformToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBakeTransformToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.BakeTransformToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UBakeTransformToolProperties : UInteractiveToolPropertySet {
	bool bApplyToAllLODs; // 0x118(0x01)
	bool bBakeRotation; // 0x119(0x01)
	enum class EBakeScaleMethod BakeScale; // 0x11a(0x01)
	bool bRecenterPivot; // 0x11b(0x01)
	bool bAllowNoScale; // 0x11c(0x01)
};

// Class MeshModelingToolsExp.BakeTransformTool
// Size: 0x150 (Inherited: 0x130)
struct UBakeTransformTool : UMultiSelectionMeshEditingTool {
	struct UBakeTransformToolProperties* BasicProperties; // 0x130(0x08)
	char pad_138[0x18]; // 0x138(0x18)
};

// Class MeshModelingToolsExp.ConvertMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UConvertMeshesToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.ConvertMeshesToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UConvertMeshesToolProperties : UInteractiveToolPropertySet {
	bool bTransferMaterials; // 0x118(0x01)
	bool bShowTransferMaterials; // 0x119(0x01)
	bool bTransferCollision; // 0x11a(0x01)
};

// Class MeshModelingToolsExp.ConvertMeshesTool
// Size: 0x150 (Inherited: 0x130)
struct UConvertMeshesTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UConvertMeshesToolProperties* BasicProperties; // 0x138(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class MeshModelingToolsExp.ConvertToPolygonsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UConvertToPolygonsToolBuilder : USingleTargetWithSelectionToolBuilder {
};

// Class MeshModelingToolsExp.ConvertToPolygonsToolProperties
// Size: 0x150 (Inherited: 0x120)
struct UConvertToPolygonsToolProperties : UInteractiveToolPropertySet {
	enum class EConvertToPolygonsMode ConversionMode; // 0x118(0x04)
	float AngleTolerance; // 0x11c(0x04)
	int32_t NumPoints; // 0x120(0x04)
	bool bSplitExisting; // 0x124(0x01)
	bool bNormalWeighted; // 0x125(0x01)
	float NormalWeighting; // 0x128(0x04)
	float QuadAdjacencyWeight; // 0x12c(0x04)
	float QuadMetricClamp; // 0x130(0x04)
	int32_t QuadSearchRounds; // 0x134(0x04)
	bool bRespectUVSeams; // 0x138(0x01)
	bool bRespectHardNormals; // 0x139(0x01)
	int32_t MinGroupSize; // 0x13c(0x04)
	bool bCalculateNormals; // 0x140(0x01)
	bool bShowGroupColors; // 0x141(0x01)
	char pad_146[0xa]; // 0x146(0x0a)
};

// Class MeshModelingToolsExp.OutputPolygroupLayerProperties
// Size: 0x150 (Inherited: 0x120)
struct UOutputPolygroupLayerProperties : UInteractiveToolPropertySet {
	struct FName GroupLayer; // 0x118(0x08)
	struct TArray<struct FString> OptionsList; // 0x120(0x10)
	bool bShowNewLayerName; // 0x130(0x01)
	struct FString NewLayerName; // 0x138(0x10)
	char pad_149[0x7]; // 0x149(0x07)

	struct TArray<struct FString> GetGroupOptionsList(); // Function MeshModelingToolsExp.OutputPolygroupLayerProperties.GetGroupOptionsList // (Final|Native|Public) // @ game+0x94c0500
};

// Class MeshModelingToolsExp.ConvertToPolygonsOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UConvertToPolygonsOperatorFactory : UObject {
	struct UConvertToPolygonsTool* ConvertToPolygonsTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.ConvertToPolygonsTool
// Size: 0x230 (Inherited: 0x1a0)
struct UConvertToPolygonsTool : USingleTargetWithSelectionTool {
	struct UConvertToPolygonsToolProperties* Settings; // 0x198(0x08)
	struct UPolygroupLayersProperties* CopyFromLayerProperties; // 0x1a0(0x08)
	struct UOutputPolygroupLayerProperties* OutputProperties; // 0x1a8(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* PreviewCompute; // 0x1b0(0x08)
	struct UPreviewGeometry* PreviewGeometry; // 0x1b8(0x08)
	struct UPreviewMesh* UnmodifiedAreaPreviewMesh; // 0x1c0(0x08)
	char pad_1d0[0x60]; // 0x1d0(0x60)
};

// Class MeshModelingToolsExp.CubeGridToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UCubeGridToolBuilder : UInteractiveToolWithToolTargetsBuilder {
};

// Class MeshModelingToolsExp.CubeGridToolProperties
// Size: 0x220 (Inherited: 0x120)
struct UCubeGridToolProperties : UInteractiveToolPropertySet {
	struct FVector GridFrameOrigin; // 0x118(0x18)
	struct FRotator GridFrameOrientation; // 0x130(0x18)
	bool bShowGizmo; // 0x148(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	char GridPower; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
	double CurrentBlockSize; // 0x160(0x08)
	int32_t BlocksPerStep; // 0x168(0x04)
	bool bPowerOfTwoBlockSizes; // 0x16c(0x01)
	char pad_16d[0x3]; // 0x16d(0x03)
	double BlockBaseSize; // 0x170(0x08)
	bool bCrosswiseDiagonal; // 0x178(0x01)
	bool bKeepSideGroups; // 0x179(0x01)
	char pad_17a[0x6]; // 0x17a(0x06)
	double PlaneTolerance; // 0x180(0x08)
	bool bHitUnrelatedGeometry; // 0x188(0x01)
	bool bHitGridGroundPlaneIfCloser; // 0x189(0x01)
	char pad_18a[0x2]; // 0x18a(0x02)
	enum class ECubeGridToolFaceSelectionMode FaceSelectionMode; // 0x18c(0x04)
	struct FString ToggleCornerMode; // 0x190(0x10)
	struct FString PushPull; // 0x1a0(0x10)
	struct FString ResizeGrid; // 0x1b0(0x10)
	char pad_1c0[0x10]; // 0x1c0(0x10)
	struct FString FlipSelection; // 0x1d0(0x10)
	struct FString GridGizmo; // 0x1e0(0x10)
	struct FString QuickShiftGizmo; // 0x1f0(0x10)
	struct FString AlignGizmo; // 0x200(0x10)
	bool bInCornerMode; // 0x210(0x01)
	bool bAllowedToEditGrid; // 0x211(0x01)
	char pad_212[0xe]; // 0x212(0x0e)
};

// Class MeshModelingToolsExp.CubeGridToolActions
// Size: 0x130 (Inherited: 0x120)
struct UCubeGridToolActions : UInteractiveToolPropertySet {
	struct AActor* GridSourceActor; // 0x120(0x08)
	char pad_128[0x8]; // 0x128(0x08)

	void SlideForward(); // Function MeshModelingToolsExp.CubeGridToolActions.SlideForward // (Final|Native|Public) // @ game+0x95be1d0
	void SlideBack(); // Function MeshModelingToolsExp.CubeGridToolActions.SlideBack // (Final|Native|Public) // @ game+0x95f3d40
	void ResetGridFromActor(); // Function MeshModelingToolsExp.CubeGridToolActions.ResetGridFromActor // (Final|Native|Public) // @ game+0x95e8510
	void Push(); // Function MeshModelingToolsExp.CubeGridToolActions.Push // (Final|Native|Public) // @ game+0x95bb750
	void Pull(); // Function MeshModelingToolsExp.CubeGridToolActions.Pull // (Final|Native|Public) // @ game+0x95ee360
	void Flip(); // Function MeshModelingToolsExp.CubeGridToolActions.Flip // (Final|Native|Public) // @ game+0x95f2cb0
	void CornerMode(); // Function MeshModelingToolsExp.CubeGridToolActions.CornerMode // (Final|Native|Public) // @ game+0x95aa780
};

// Class MeshModelingToolsExp.CubeGridDuringActivityActions
// Size: 0x120 (Inherited: 0x120)
struct UCubeGridDuringActivityActions : UInteractiveToolPropertySet {

	void Done(); // Function MeshModelingToolsExp.CubeGridDuringActivityActions.Done // (Final|Native|Public) // @ game+0x95aeb50
	void Cancel(); // Function MeshModelingToolsExp.CubeGridDuringActivityActions.Cancel // (Final|Native|Public) // @ game+0x95bb820
};

// Class MeshModelingToolsExp.CubeGridTool
// Size: 0x6a0 (Inherited: 0x110)
struct UCubeGridTool : UInteractiveTool {
	char pad_110[0x28]; // 0x110(0x28)
	struct UCombinedTransformGizmo* GridGizmo; // 0x138(0x08)
	struct UDragAlignmentMechanic* GridGizmoAlignmentMechanic; // 0x140(0x08)
	struct UTransformProxy* GridGizmoTransformProxy; // 0x148(0x08)
	struct UPreviewGeometry* LineSets; // 0x150(0x08)
	struct UClickDragInputBehavior* ClickDragBehavior; // 0x158(0x08)
	struct UMouseHoverBehavior* HoverBehavior; // 0x160(0x08)
	struct ULocalSingleClickInputBehavior* CtrlMiddleClickBehavior; // 0x168(0x08)
	struct ULocalClickDragInputBehavior* MiddleClickDragBehavior; // 0x170(0x08)
	struct UCubeGridToolProperties* Settings; // 0x178(0x08)
	struct UCubeGridToolActions* ToolActions; // 0x180(0x08)
	struct UCubeGridDuringActivityActions* DuringActivityActions; // 0x188(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x190(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x198(0x08)
	struct UToolTarget* Target; // 0x1a0(0x08)
	char pad_1a8[0x180]; // 0x1a8(0x180)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x328(0x08)
	char pad_330[0x370]; // 0x330(0x370)
};

// Class MeshModelingToolsExp.DeformMeshPolygonsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UDeformMeshPolygonsToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.DeformMeshPolygonsTransformProperties
// Size: 0x140 (Inherited: 0x120)
struct UDeformMeshPolygonsTransformProperties : UInteractiveToolPropertySet {
	enum class EGroupTopologyDeformationStrategy DeformationStrategy; // 0x118(0x01)
	enum class EQuickTransformerMode TransformMode; // 0x119(0x01)
	bool bSelectFaces; // 0x11a(0x01)
	bool bSelectEdges; // 0x11b(0x01)
	bool bSelectVertices; // 0x11c(0x01)
	bool bShowWireframe; // 0x11d(0x01)
	enum class EWeightScheme SelectedWeightScheme; // 0x120(0x04)
	double HandleWeight; // 0x128(0x08)
	bool bPostFixHandles; // 0x130(0x01)
	char pad_133[0xd]; // 0x133(0x0d)
};

// Class MeshModelingToolsExp.DeformMeshPolygonsTool
// Size: 0x1880 (Inherited: 0x180)
struct UDeformMeshPolygonsTool : UMeshSurfacePointTool {
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0x180(0x08)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0x188(0x08)
	struct UDeformMeshPolygonsTransformProperties* TransformProps; // 0x190(0x08)
	char pad_198[0x16e8]; // 0x198(0x16e8)
};

// Class MeshModelingToolsExp.DisplaceMeshCommonProperties
// Size: 0x150 (Inherited: 0x120)
struct UDisplaceMeshCommonProperties : UInteractiveToolPropertySet {
	enum class EDisplaceMeshToolDisplaceType DisplacementType; // 0x118(0x01)
	float DisplaceIntensity; // 0x11c(0x04)
	int32_t RandomSeed; // 0x120(0x04)
	enum class EDisplaceMeshToolSubdivisionType SubdivisionType; // 0x124(0x01)
	int32_t Subdivisions; // 0x128(0x04)
	struct FName WeightMap; // 0x12c(0x08)
	char pad_136[0x2]; // 0x136(0x02)
	struct TArray<struct FString> WeightMapsList; // 0x138(0x10)
	bool bInvertWeightMap; // 0x148(0x01)
	bool bShowWireframe; // 0x149(0x01)
	bool bDisableSizeWarning; // 0x14a(0x01)
	char pad_14b[0x5]; // 0x14b(0x05)

	struct TArray<struct FString> GetWeightMapsFunc(); // Function MeshModelingToolsExp.DisplaceMeshCommonProperties.GetWeightMapsFunc // (Final|Native|Public) // @ game+0x9595d60
};

// Class MeshModelingToolsExp.SelectiveTessellationProperties
// Size: 0x140 (Inherited: 0x120)
struct USelectiveTessellationProperties : UInteractiveToolPropertySet {
	enum class EDisplaceMeshToolTriangleSelectionType SelectionType; // 0x118(0x01)
	struct FName ActiveMaterial; // 0x11c(0x08)
	struct TArray<struct FString> MaterialIDList; // 0x128(0x10)
	char pad_139[0x7]; // 0x139(0x07)

	struct TArray<struct FString> GetMaterialIDsFunc(); // Function MeshModelingToolsExp.SelectiveTessellationProperties.GetMaterialIDsFunc // (Final|Native|Public) // @ game+0x95ed160
};

// Class MeshModelingToolsExp.DisplaceMeshTextureMapProperties
// Size: 0x160 (Inherited: 0x120)
struct UDisplaceMeshTextureMapProperties : UInteractiveToolPropertySet {
	struct UTexture2D* DisplacementMap; // 0x118(0x08)
	enum class EDisplaceMeshToolChannelType Channel; // 0x120(0x01)
	float DisplacementMapBaseValue; // 0x124(0x04)
	struct FVector2D UVScale; // 0x128(0x10)
	struct FVector2D UVOffset; // 0x138(0x10)
	bool bApplyAdjustmentCurve; // 0x148(0x01)
	char pad_14e[0x2]; // 0x14e(0x02)
	struct UCurveFloat* AdjustmentCurve; // 0x150(0x08)
	bool bRecalcNormals; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
};

// Class MeshModelingToolsExp.DisplaceMeshDirectionalFilterProperties
// Size: 0x140 (Inherited: 0x120)
struct UDisplaceMeshDirectionalFilterProperties : UInteractiveToolPropertySet {
	bool bEnableFilter; // 0x118(0x01)
	struct FVector FilterDirection; // 0x120(0x18)
	float FilterWidth; // 0x138(0x04)
	char pad_13d[0x3]; // 0x13d(0x03)
};

// Class MeshModelingToolsExp.DisplaceMeshPerlinNoiseProperties
// Size: 0x130 (Inherited: 0x120)
struct UDisplaceMeshPerlinNoiseProperties : UInteractiveToolPropertySet {
	struct TArray<struct FPerlinLayerProperties> PerlinLayerProperties; // 0x118(0x10)
};

// Class MeshModelingToolsExp.DisplaceMeshSineWaveProperties
// Size: 0x140 (Inherited: 0x120)
struct UDisplaceMeshSineWaveProperties : UInteractiveToolPropertySet {
	float SineWaveFrequency; // 0x118(0x04)
	float SineWavePhaseShift; // 0x11c(0x04)
	struct FVector SineWaveDirection; // 0x120(0x18)
};

// Class MeshModelingToolsExp.DisplaceMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UDisplaceMeshToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.DisplaceMeshTool
// Size: 0x4e0 (Inherited: 0x130)
struct UDisplaceMeshTool : USingleSelectionMeshEditingTool {
	struct UDisplaceMeshCommonProperties* CommonProperties; // 0x130(0x08)
	struct UDisplaceMeshDirectionalFilterProperties* DirectionalFilterProperties; // 0x138(0x08)
	struct UDisplaceMeshTextureMapProperties* TextureMapProperties; // 0x140(0x08)
	struct UDisplaceMeshPerlinNoiseProperties* NoiseProperties; // 0x148(0x08)
	struct UDisplaceMeshSineWaveProperties* SineWaveProperties; // 0x150(0x08)
	struct USelectiveTessellationProperties* SelectiveTessellationProperties; // 0x158(0x08)
	struct UCurveFloat* ActiveContrastCurveTarget; // 0x160(0x08)
	struct UMeshStatisticsProperties* MeshStatistics; // 0x168(0x08)
	char pad_170[0x340]; // 0x170(0x340)
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0x4b0(0x08)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0x4b8(0x08)
	char pad_4c0[0x20]; // 0x4c0(0x20)
};

// Class MeshModelingToolsExp.DrawPolyPathToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UDrawPolyPathToolBuilder : UMeshSurfacePointToolBuilder {
};

// Class MeshModelingToolsExp.DrawPolyPathProperties
// Size: 0x140 (Inherited: 0x120)
struct UDrawPolyPathProperties : UInteractiveToolPropertySet {
	enum class EDrawPolyPathWidthMode WidthMode; // 0x118(0x04)
	float Width; // 0x11c(0x04)
	bool bRoundedCorners; // 0x120(0x01)
	enum class EDrawPolyPathRadiusMode RadiusMode; // 0x124(0x04)
	float CornerRadius; // 0x128(0x04)
	int32_t RadialSlices; // 0x12c(0x04)
	bool bSinglePolyGroup; // 0x130(0x01)
	enum class EDrawPolyPathExtrudeMode ExtrudeMode; // 0x134(0x04)
	float ExtrudeHeight; // 0x138(0x04)
	float RampStartRatio; // 0x13c(0x04)
};

// Class MeshModelingToolsExp.DrawPolyPathExtrudeProperties
// Size: 0x120 (Inherited: 0x120)
struct UDrawPolyPathExtrudeProperties : UInteractiveToolPropertySet {
	enum class EDrawPolyPathExtrudeDirection Direction; // 0x118(0x04)
};

// Class MeshModelingToolsExp.DrawPolyPathTool
// Size: 0x2f0 (Inherited: 0x110)
struct UDrawPolyPathTool : UInteractiveTool {
	char pad_110[0x18]; // 0x110(0x18)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x128(0x08)
	struct UDrawPolyPathProperties* TransformProps; // 0x130(0x08)
	struct UDrawPolyPathExtrudeProperties* ExtrudeProperties; // 0x138(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x140(0x08)
	char pad_148[0xb8]; // 0x148(0xb8)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x200(0x08)
	char pad_208[0xc0]; // 0x208(0xc0)
	struct UPolyEditPreviewMesh* EditPreview; // 0x2c8(0x08)
	struct UPlaneDistanceFromHitMechanic* ExtrudeHeightMechanic; // 0x2d0(0x08)
	struct USpatialCurveDistanceMechanic* CurveDistMechanic; // 0x2d8(0x08)
	struct UCollectSurfacePathMechanic* SurfacePathMechanic; // 0x2e0(0x08)
	char pad_2e8[0x8]; // 0x2e8(0x08)
};

// Class MeshModelingToolsExp.DynamicMeshBrushTool
// Size: 0x340 (Inherited: 0x300)
struct UDynamicMeshBrushTool : UBaseBrushTool {
	struct UPreviewMesh* PreviewMesh; // 0x300(0x08)
	char pad_308[0x38]; // 0x308(0x38)
};

// Class MeshModelingToolsExp.DynamicMeshSculptToolBuilder
// Size: 0xb0 (Inherited: 0xa0)
struct UDynamicMeshSculptToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class MeshModelingToolsExp.DynamicMeshBrushProperties
// Size: 0x140 (Inherited: 0x120)
struct UDynamicMeshBrushProperties : UInteractiveToolPropertySet {
	struct FBrushToolRadius BrushSize; // 0x118(0x14)
	float BrushFalloffAmount; // 0x12c(0x04)
	float Depth; // 0x130(0x04)
	bool bHitBackFaces; // 0x134(0x01)
	char pad_13d[0x3]; // 0x13d(0x03)
};

// Class MeshModelingToolsExp.DynamicMeshBrushSculptProperties
// Size: 0x130 (Inherited: 0x120)
struct UDynamicMeshBrushSculptProperties : UInteractiveToolPropertySet {
	bool bIsRemeshingEnabled; // 0x118(0x01)
	enum class EDynamicMeshSculptBrushType PrimaryBrushType; // 0x119(0x01)
	float PrimaryBrushSpeed; // 0x11c(0x04)
	bool bPreserveUVFlow; // 0x120(0x01)
	bool bFreezeTarget; // 0x121(0x01)
	float SmoothBrushSpeed; // 0x124(0x04)
	bool bDetailPreservingSmooth; // 0x128(0x01)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.DynamicSculptToolActions
// Size: 0x120 (Inherited: 0x120)
struct UDynamicSculptToolActions : UInteractiveToolPropertySet {

	void DiscardAttributes(); // Function MeshModelingToolsExp.DynamicSculptToolActions.DiscardAttributes // (Final|Native|Public) // @ game+0x95cb320
};

// Class MeshModelingToolsExp.BrushRemeshProperties
// Size: 0x140 (Inherited: 0x130)
struct UBrushRemeshProperties : URemeshProperties {
	bool bEnableRemeshing; // 0x128(0x01)
	int32_t TriangleSize; // 0x12c(0x04)
	int32_t PreserveDetail; // 0x130(0x04)
	int32_t Iterations; // 0x134(0x04)
	char pad_13d[0x3]; // 0x13d(0x03)
};

// Class MeshModelingToolsExp.FixedPlaneBrushProperties
// Size: 0x160 (Inherited: 0x120)
struct UFixedPlaneBrushProperties : UInteractiveToolPropertySet {
	bool bPropertySetEnabled; // 0x118(0x01)
	bool bShowGizmo; // 0x119(0x01)
	struct FVector Position; // 0x120(0x18)
	char pad_13a[0x6]; // 0x13a(0x06)
	struct FQuat Rotation; // 0x140(0x20)
};

// Class MeshModelingToolsExp.DynamicMeshSculptTool
// Size: 0x1090 (Inherited: 0x180)
struct UDynamicMeshSculptTool : UMeshSurfacePointTool {
	struct UDynamicMeshBrushProperties* BrushProperties; // 0x178(0x08)
	struct UDynamicMeshBrushSculptProperties* SculptProperties; // 0x180(0x08)
	struct USculptMaxBrushProperties* SculptMaxBrushProperties; // 0x188(0x08)
	struct UKelvinBrushProperties* KelvinBrushProperties; // 0x190(0x08)
	struct UBrushRemeshProperties* RemeshProperties; // 0x198(0x08)
	struct UFixedPlaneBrushProperties* GizmoProperties; // 0x1a0(0x08)
	struct UMeshEditingViewProperties* ViewProperties; // 0x1a8(0x08)
	struct UDynamicSculptToolActions* SculptToolActions; // 0x1b0(0x08)
	char pad_1c0[0x50]; // 0x1c0(0x50)
	struct UBrushStampIndicator* BrushIndicator; // 0x210(0x08)
	struct UMaterialInstanceDynamic* BrushIndicatorMaterial; // 0x218(0x08)
	struct UPreviewMesh* BrushIndicatorMesh; // 0x220(0x08)
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0x228(0x08)
	struct UOctreeDynamicMeshComponent* DynamicMeshComponent; // 0x230(0x08)
	struct UMaterialInstanceDynamic* ActiveOverrideMaterial; // 0x238(0x08)
	char pad_240[0xe30]; // 0x240(0xe30)
	struct UCombinedTransformGizmo* PlaneTransformGizmo; // 0x1070(0x08)
	struct UTransformProxy* PlaneTransformProxy; // 0x1078(0x08)
	char pad_1080[0x10]; // 0x1080(0x10)
};

// Class MeshModelingToolsExp.EditNormalsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UEditNormalsToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.EditNormalsToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UEditNormalsToolProperties : UInteractiveToolPropertySet {
	bool bRecomputeNormals; // 0x118(0x01)
	enum class ENormalCalculationMethod NormalCalculationMethod; // 0x119(0x01)
	bool bFixInconsistentNormals; // 0x11a(0x01)
	bool bInvertNormals; // 0x11b(0x01)
	enum class ESplitNormalMethod SplitNormalMethod; // 0x11c(0x01)
	float SharpEdgeAngleThreshold; // 0x120(0x04)
	bool bAllowSharpVertices; // 0x124(0x01)
	bool bToolHasSelection; // 0x125(0x01)
	char pad_12b[0x5]; // 0x12b(0x05)
};

// Class MeshModelingToolsExp.EditNormalsOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UEditNormalsOperatorFactory : UObject {
	struct UEditNormalsTool* Tool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.EditNormalsTool
// Size: 0x290 (Inherited: 0x130)
struct UEditNormalsTool : UMultiSelectionMeshEditingTool {
	struct UEditNormalsToolProperties* BasicProperties; // 0x130(0x08)
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0x138(0x08)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews; // 0x140(0x10)
	char pad_150[0x70]; // 0x150(0x70)
	struct UGeometrySelectionVisualizationProperties* GeometrySelectionVizProperties; // 0x1c0(0x08)
	struct UPreviewGeometry* GeometrySelectionViz; // 0x1c8(0x08)
	char pad_1d0[0xc0]; // 0x1d0(0xc0)
};

// Class MeshModelingToolsExp.EditPivotToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UEditPivotToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.EditPivotToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UEditPivotToolProperties : UInteractiveToolPropertySet {
	bool bApplyToAllLODs; // 0x118(0x01)
	bool bEnableSnapDragging; // 0x119(0x01)
	enum class EEditPivotSnapDragRotationMode RotationMode; // 0x11a(0x01)
};

// Class MeshModelingToolsExp.EditPivotToolActionPropertySet
// Size: 0x130 (Inherited: 0x120)
struct UEditPivotToolActionPropertySet : UInteractiveToolPropertySet {
	bool bUseWorldBox; // 0x120(0x01)
	char pad_121[0xf]; // 0x121(0x0f)

	void WorldOrigin(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.WorldOrigin // (Final|Native|Public) // @ game+0x9637fd0
	void Top(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Top // (Final|Native|Public) // @ game+0x964b850
	void Right(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Right // (Final|Native|Public) // @ game+0x966d3d0
	void Left(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Left // (Final|Native|Public) // @ game+0x96183f0
	void Front(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Front // (Final|Native|Public) // @ game+0x962b2c0
	void Center(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Center // (Final|Native|Public) // @ game+0x9648dc0
	void Bottom(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Bottom // (Final|Native|Public) // @ game+0x9636f50
	void Back(); // Function MeshModelingToolsExp.EditPivotToolActionPropertySet.Back // (Final|Native|Public) // @ game+0x964dc60
};

// Class MeshModelingToolsExp.EditPivotTool
// Size: 0x2b0 (Inherited: 0x130)
struct UEditPivotTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UEditPivotToolProperties* TransformProps; // 0x138(0x08)
	struct UEditPivotToolActionPropertySet* EditPivotActions; // 0x140(0x08)
	char pad_148[0xd8]; // 0x148(0xd8)
	struct TArray<struct FEditPivotTarget> ActiveGizmos; // 0x220(0x10)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x230(0x08)
	char pad_238[0x78]; // 0x238(0x78)
};

// Class MeshModelingToolsExp.EditUVIslandsToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UEditUVIslandsToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.EditUVIslandsTool
// Size: 0x550 (Inherited: 0x180)
struct UEditUVIslandsTool : UMeshSurfacePointTool {
	struct UExistingMeshMaterialProperties* MaterialSettings; // 0x178(0x08)
	struct UMaterialInstanceDynamic* CheckerMaterial; // 0x180(0x08)
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0x188(0x08)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0x190(0x08)
	struct UPolygonSelectionMechanic* SelectionMechanic; // 0x198(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x1a8(0x08)
	struct UTransformProxy* TransformProxy; // 0x1b0(0x08)
	char pad_1b8[0x398]; // 0x1b8(0x398)
};

// Class MeshModelingToolsExp.HoleFillToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UHoleFillToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.SmoothHoleFillProperties
// Size: 0x140 (Inherited: 0x120)
struct USmoothHoleFillProperties : UInteractiveToolPropertySet {
	bool bConstrainToHoleInterior; // 0x118(0x01)
	int32_t RemeshingExteriorRegionWidth; // 0x11c(0x04)
	int32_t SmoothingExteriorRegionWidth; // 0x120(0x04)
	int32_t SmoothingInteriorRegionWidth; // 0x124(0x04)
	float InteriorSmoothness; // 0x128(0x04)
	double FillDensityScalar; // 0x130(0x08)
	bool bProjectDuringRemesh; // 0x138(0x01)
	char pad_13a[0x6]; // 0x13a(0x06)
};

// Class MeshModelingToolsExp.HoleFillToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UHoleFillToolProperties : UInteractiveToolPropertySet {
	enum class EHoleFillOpFillType FillType; // 0x118(0x01)
	bool bRemoveIsolatedTriangles; // 0x119(0x01)
	bool bQuickFillSmallHoles; // 0x11a(0x01)
};

// Class MeshModelingToolsExp.HoleFillToolActions
// Size: 0x120 (Inherited: 0x120)
struct UHoleFillToolActions : UInteractiveToolPropertySet {

	void SelectAll(); // Function MeshModelingToolsExp.HoleFillToolActions.SelectAll // (Final|Native|Public) // @ game+0x96334b0
	void Clear(); // Function MeshModelingToolsExp.HoleFillToolActions.Clear // (Final|Native|Public) // @ game+0x9687010
};

// Class MeshModelingToolsExp.HoleFillStatisticsProperties
// Size: 0x170 (Inherited: 0x120)
struct UHoleFillStatisticsProperties : UInteractiveToolPropertySet {
	struct FString InitialHoles; // 0x118(0x10)
	struct FString SelectedHoles; // 0x128(0x10)
	struct FString SuccessfulFills; // 0x138(0x10)
	struct FString FailedFills; // 0x148(0x10)
	struct FString RemainingHoles; // 0x158(0x10)
};

// Class MeshModelingToolsExp.HoleFillOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UHoleFillOperatorFactory : UObject {
	struct UHoleFillTool* FillTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.HoleFillTool
// Size: 0x2c0 (Inherited: 0x130)
struct UHoleFillTool : USingleSelectionMeshEditingTool {
	struct USmoothHoleFillProperties* SmoothHoleFillProperties; // 0x130(0x08)
	struct UHoleFillToolProperties* Properties; // 0x138(0x08)
	struct UHoleFillToolActions* Actions; // 0x140(0x08)
	struct UHoleFillStatisticsProperties* Statistics; // 0x148(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x150(0x08)
	struct UBoundarySelectionMechanic* SelectionMechanic; // 0x158(0x08)
	char pad_160[0x160]; // 0x160(0x160)
};

// Class MeshModelingToolsExp.LatticeDeformerToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct ULatticeDeformerToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.LatticeDeformerToolProperties
// Size: 0x140 (Inherited: 0x120)
struct ULatticeDeformerToolProperties : UInteractiveToolPropertySet {
	int32_t XAxisResolution; // 0x120(0x04)
	int32_t YAxisResolution; // 0x124(0x04)
	int32_t ZAxisResolution; // 0x128(0x04)
	float Padding; // 0x12c(0x04)
	enum class ELatticeInterpolationType InterpolationType; // 0x130(0x01)
	bool bDeformNormals; // 0x131(0x01)
	bool bCanChangeResolution; // 0x132(0x01)
	char pad_133[0x1]; // 0x133(0x01)
	enum class EToolContextCoordinateSystem GizmoCoordinateSystem; // 0x134(0x04)
	bool bSetPivotMode; // 0x138(0x01)
	bool bSoftDeformation; // 0x139(0x01)
	char pad_13a[0x6]; // 0x13a(0x06)

	void Constrain(); // Function MeshModelingToolsExp.LatticeDeformerToolProperties.Constrain // (Final|Native|Public) // @ game+0x965f7c0
	void ClearConstraints(); // Function MeshModelingToolsExp.LatticeDeformerToolProperties.ClearConstraints // (Final|Native|Public) // @ game+0x9620510
};

// Class MeshModelingToolsExp.LatticeDeformerOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct ULatticeDeformerOperatorFactory : UObject {
	struct ULatticeDeformerTool* LatticeDeformerTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.LatticeDeformerTool
// Size: 0x1e0 (Inherited: 0x130)
struct ULatticeDeformerTool : USingleSelectionMeshEditingTool {
	char pad_130[0x20]; // 0x130(0x20)
	struct ULatticeControlPointsMechanic* ControlPointsMechanic; // 0x150(0x08)
	struct ULatticeDeformerToolProperties* Settings; // 0x158(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x160(0x08)
	bool bLatticeDeformed; // 0x168(0x01)
	char pad_169[0x77]; // 0x169(0x77)
};

// Class MeshModelingToolsExp.MeshAttributePaintToolBuilder
// Size: 0xe0 (Inherited: 0xa0)
struct UMeshAttributePaintToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
	char pad_a0[0x40]; // 0xa0(0x40)
};

// Class MeshModelingToolsExp.MeshAttributePaintBrushOperationProperties
// Size: 0x120 (Inherited: 0x120)
struct UMeshAttributePaintBrushOperationProperties : UInteractiveToolPropertySet {
	enum class EBrushActionMode BrushAction; // 0x118(0x04)
};

// Class MeshModelingToolsExp.MeshAttributePaintToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UMeshAttributePaintToolProperties : UInteractiveToolPropertySet {
	struct FString Attribute; // 0x118(0x10)
	char pad_130[0x10]; // 0x130(0x10)

	struct TArray<struct FString> GetAttributeNames(); // Function MeshModelingToolsExp.MeshAttributePaintToolProperties.GetAttributeNames // (Final|Native|Public) // @ game+0x955a840
};

// Class MeshModelingToolsExp.MeshAttributePaintEditActions
// Size: 0x120 (Inherited: 0x120)
struct UMeshAttributePaintEditActions : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.MeshAttributePaintTool
// Size: 0x830 (Inherited: 0x340)
struct UMeshAttributePaintTool : UDynamicMeshBrushTool {
	struct UMeshAttributePaintBrushOperationProperties* BrushActionProps; // 0x340(0x08)
	struct UMeshAttributePaintToolProperties* AttribProps; // 0x348(0x08)
	char pad_350[0x4e0]; // 0x350(0x4e0)
};

// Class MeshModelingToolsExp.MeshBoundaryToolBase
// Size: 0x220 (Inherited: 0x130)
struct UMeshBoundaryToolBase : USingleSelectionMeshEditingTool {
	char pad_130[0xe0]; // 0x130(0xe0)
	struct UPolygonSelectionMechanic* SelectionMechanic; // 0x210(0x08)
	char pad_218[0x8]; // 0x218(0x08)
};

// Class MeshModelingToolsExp.MeshGroupPaintToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshGroupPaintToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.GroupPaintBrushFilterProperties
// Size: 0x150 (Inherited: 0x120)
struct UGroupPaintBrushFilterProperties : UInteractiveToolPropertySet {
	enum class EMeshGroupPaintBrushType PrimaryBrushType; // 0x118(0x01)
	enum class EMeshGroupPaintInteractionType SubToolType; // 0x119(0x01)
	float BrushSize; // 0x11c(0x04)
	enum class EMeshGroupPaintBrushAreaType BrushAreaMode; // 0x120(0x01)
	bool bHitBackFaces; // 0x121(0x01)
	int32_t SetGroup; // 0x124(0x04)
	bool bOnlySetUngrouped; // 0x128(0x01)
	int32_t EraseGroup; // 0x12c(0x04)
	bool bOnlyEraseCurrent; // 0x130(0x01)
	char pad_132[0x2]; // 0x132(0x02)
	float AngleThreshold; // 0x134(0x04)
	bool bUVSeams; // 0x138(0x01)
	bool bNormalSeams; // 0x139(0x01)
	enum class EMeshGroupPaintVisibilityType VisibilityFilter; // 0x13a(0x01)
	char pad_13b[0x1]; // 0x13b(0x01)
	int32_t MinTriVertCount; // 0x13c(0x04)
	bool bShowHitGroup; // 0x140(0x01)
	bool bShowAllGroups; // 0x141(0x01)
	char pad_142[0xe]; // 0x142(0x0e)
};

// Class MeshModelingToolsExp.MeshGroupPaintToolActionPropertySet
// Size: 0x120 (Inherited: 0x120)
struct UMeshGroupPaintToolActionPropertySet : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.MeshGroupPaintToolFreezeActions
// Size: 0x120 (Inherited: 0x120)
struct UMeshGroupPaintToolFreezeActions : UMeshGroupPaintToolActionPropertySet {

	void UnfreezeAll(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.UnfreezeAll // (Final|Native|Public) // @ game+0x963f6d0
	void ShrinkCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.ShrinkCurrent // (Final|Native|Public) // @ game+0x9611280
	void GrowCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.GrowCurrent // (Final|Native|Public) // @ game+0x9615b90
	void FreezeOthers(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.FreezeOthers // (Final|Native|Public) // @ game+0x9629ce0
	void FreezeCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.FreezeCurrent // (Final|Native|Public) // @ game+0x964dcc0
	void FloodFillCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.FloodFillCurrent // (Final|Native|Public) // @ game+0x962ffb0
	void ClearCurrent(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.ClearCurrent // (Final|Native|Public) // @ game+0x9679e00
	void ClearAll(); // Function MeshModelingToolsExp.MeshGroupPaintToolFreezeActions.ClearAll // (Final|Native|Public) // @ game+0x965e370
};

// Class MeshModelingToolsExp.MeshSculptToolBase
// Size: 0xc10 (Inherited: 0x180)
struct UMeshSculptToolBase : UMeshSurfacePointTool {
	struct USculptBrushProperties* BrushProperties; // 0x178(0x08)
	struct UWorkPlaneProperties* GizmoProperties; // 0x180(0x08)
	char pad_190[0x110]; // 0x190(0x110)
	struct TMap<int32_t, struct UMeshSculptBrushOpProps*> BrushOpPropSets; // 0x2a0(0x50)
	char pad_2f0[0x50]; // 0x2f0(0x50)
	struct TMap<int32_t, struct UMeshSculptBrushOpProps*> SecondaryBrushOpPropSets; // 0x340(0x50)
	char pad_390[0x6f0]; // 0x390(0x6f0)
	struct UMeshEditingViewProperties* ViewProperties; // 0xa80(0x08)
	struct UMaterialInstanceDynamic* ActiveOverrideMaterial; // 0xa88(0x08)
	struct UBrushStampIndicator* BrushIndicator; // 0xa90(0x08)
	bool bIsVolumetricIndicator; // 0xa98(0x01)
	char pad_a99[0x7]; // 0xa99(0x07)
	struct UMaterialInstanceDynamic* BrushIndicatorMaterial; // 0xaa0(0x08)
	struct UPreviewMesh* BrushIndicatorMesh; // 0xaa8(0x08)
	struct UCombinedTransformGizmo* PlaneTransformGizmo; // 0xab0(0x08)
	struct UTransformProxy* PlaneTransformProxy; // 0xab8(0x08)
	char pad_ac0[0x150]; // 0xac0(0x150)
};

// Class MeshModelingToolsExp.MeshGroupPaintTool
// Size: 0x1040 (Inherited: 0xc10)
struct UMeshGroupPaintTool : UMeshSculptToolBase {
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0xc08(0x08)
	struct UGroupPaintBrushFilterProperties* FilterProperties; // 0xc10(0x08)
	struct UGroupPaintBrushOpProps* PaintBrushOpProperties; // 0xc18(0x08)
	struct UGroupEraseBrushOpProps* EraseBrushOpProperties; // 0xc20(0x08)
	struct UMeshGroupPaintToolFreezeActions* FreezeActions; // 0xc28(0x08)
	struct UPolyLassoMarqueeMechanic* PolyLassoMechanic; // 0xc38(0x08)
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0xc40(0x08)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0xc48(0x08)
	struct UMeshElementsVisualizer* MeshElementsDisplay; // 0xc50(0x08)
	char pad_c58[0x3e8]; // 0xc58(0x3e8)
};

// Class MeshModelingToolsExp.MeshInspectorToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshInspectorToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.MeshInspectorProperties
// Size: 0x130 (Inherited: 0x120)
struct UMeshInspectorProperties : UInteractiveToolPropertySet {
	bool bWireframe; // 0x118(0x01)
	bool bBoundaryEdges; // 0x119(0x01)
	bool bBowtieVertices; // 0x11a(0x01)
	bool bPolygonBorders; // 0x11b(0x01)
	bool bUVSeams; // 0x11c(0x01)
	bool bUVBowties; // 0x11d(0x01)
	bool bMissingUVs; // 0x11e(0x01)
	bool bNormalSeams; // 0x11f(0x01)
	bool bTangentSeams; // 0x120(0x01)
	bool bNormalVectors; // 0x121(0x01)
	bool bTangentVectors; // 0x122(0x01)
	float NormalLength; // 0x124(0x04)
	float TangentLength; // 0x128(0x04)
	enum class EMeshInspectorToolDrawIndexMode ShowIndices; // 0x12c(0x01)
};

// Class MeshModelingToolsExp.MeshInspectorMaterialProperties
// Size: 0x190 (Inherited: 0x120)
struct UMeshInspectorMaterialProperties : UInteractiveToolPropertySet {
	enum class EMeshInspectorMaterialMode MaterialMode; // 0x118(0x01)
	float CheckerDensity; // 0x11c(0x04)
	struct UMaterialInterface* OverrideMaterial; // 0x120(0x08)
	struct FString UVChannel; // 0x128(0x10)
	struct TArray<struct FString> UVChannelNamesList; // 0x138(0x10)
	bool bFlatShading; // 0x148(0x01)
	struct FLinearColor Color; // 0x14c(0x10)
	char pad_15e[0x2]; // 0x15e(0x02)
	double Opacity; // 0x160(0x08)
	struct FLinearColor TransparentMaterialColor; // 0x168(0x10)
	bool bTwoSided; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
	struct UMaterialInstanceDynamic* CheckerMaterial; // 0x180(0x08)
	struct UMaterialInstanceDynamic* ActiveCustomMaterial; // 0x188(0x08)

	struct TArray<struct FString> GetUVChannelNamesFunc(); // Function MeshModelingToolsExp.MeshInspectorMaterialProperties.GetUVChannelNamesFunc // (Final|Native|Public|Const) // @ game+0x9511c80
};

// Class MeshModelingToolsExp.MeshInspectorTool
// Size: 0x2d0 (Inherited: 0x130)
struct UMeshInspectorTool : USingleSelectionMeshEditingTool {
	struct UMeshInspectorProperties* Settings; // 0x130(0x08)
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0x138(0x08)
	struct UMeshInspectorMaterialProperties* MaterialSettings; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x150(0x08)
	struct ULineSetComponent* DrawnLineSet; // 0x158(0x08)
	struct UMaterialInterface* DefaultMaterial; // 0x160(0x08)
	char pad_168[0x168]; // 0x168(0x168)
};

// Class MeshModelingToolsExp.MeshSelectionToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshSelectionToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.MeshSelectionToolActionPropertySet
// Size: 0x120 (Inherited: 0x120)
struct UMeshSelectionToolActionPropertySet : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.MeshSelectionEditActions
// Size: 0x120 (Inherited: 0x120)
struct UMeshSelectionEditActions : UMeshSelectionToolActionPropertySet {

	void Shrink(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Shrink // (Final|Native|Public) // @ game+0x9629200
	void SelectAll(); // Function MeshModelingToolsExp.MeshSelectionEditActions.SelectAll // (Final|Native|Public) // @ game+0x9677290
	void OptimizeBorder(); // Function MeshModelingToolsExp.MeshSelectionEditActions.OptimizeBorder // (Final|Native|Public) // @ game+0x9653500
	void LargestTriCountPart(); // Function MeshModelingToolsExp.MeshSelectionEditActions.LargestTriCountPart // (Final|Native|Public) // @ game+0x9617d50
	void LargestAreaPart(); // Function MeshModelingToolsExp.MeshSelectionEditActions.LargestAreaPart // (Final|Native|Public) // @ game+0x9652b40
	void Invert(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Invert // (Final|Native|Public) // @ game+0x9618d40
	void Grow(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Grow // (Final|Native|Public) // @ game+0x96615d0
	void FloodFill(); // Function MeshModelingToolsExp.MeshSelectionEditActions.FloodFill // (Final|Native|Public) // @ game+0x964d130
	void ExpandToMaterials(); // Function MeshModelingToolsExp.MeshSelectionEditActions.ExpandToMaterials // (Final|Native|Public) // @ game+0x967a130
	void Clear(); // Function MeshModelingToolsExp.MeshSelectionEditActions.Clear // (Final|Native|Public) // @ game+0x96759d0
};

// Class MeshModelingToolsExp.MeshSelectionMeshEditActions
// Size: 0x120 (Inherited: 0x120)
struct UMeshSelectionMeshEditActions : UMeshSelectionToolActionPropertySet {

	void SmoothBorder(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.SmoothBorder // (Final|Native|Public) // @ game+0x9629ab0
	void Separate(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Separate // (Final|Native|Public) // @ game+0x9684100
	void FlipNormals(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.FlipNormals // (Final|Native|Public) // @ game+0x965f5c0
	void Duplicate(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Duplicate // (Final|Native|Public) // @ game+0x9676740
	void Disconnect(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Disconnect // (Final|Native|Public) // @ game+0x964b8b0
	void Delete(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.Delete // (Final|Native|Public) // @ game+0x9621810
	void CreatePolygroup(); // Function MeshModelingToolsExp.MeshSelectionMeshEditActions.CreatePolygroup // (Final|Native|Public) // @ game+0x9631760
};

// Class MeshModelingToolsExp.MeshSelectionToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UMeshSelectionToolProperties : UInteractiveToolPropertySet {
	enum class EMeshSelectionToolPrimaryMode SelectionMode; // 0x118(0x04)
	float AngleTolerance; // 0x11c(0x04)
	bool bHitBackFaces; // 0x120(0x01)
	bool bShowPoints; // 0x121(0x01)
	enum class EMeshFacesColorMode FaceColorMode; // 0x124(0x04)
	char pad_12e[0x2]; // 0x12e(0x02)
};

// Class MeshModelingToolsExp.MeshSelectionTool
// Size: 0x770 (Inherited: 0x340)
struct UMeshSelectionTool : UDynamicMeshBrushTool {
	char pad_340[0x8]; // 0x340(0x08)
	struct UMeshSelectionToolProperties* SelectionProps; // 0x348(0x08)
	struct UMeshSelectionEditActions* SelectionActions; // 0x350(0x08)
	struct UMeshSelectionToolActionPropertySet* EditActions; // 0x358(0x08)
	struct UMeshStatisticsProperties* MeshStatisticsProperties; // 0x360(0x08)
	struct UMeshElementsVisualizer* MeshElementsDisplay; // 0x368(0x08)
	struct UMeshUVChannelProperties* UVChannelProperties; // 0x370(0x08)
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0x378(0x08)
	char pad_380[0x58]; // 0x380(0x58)
	struct UMeshSelectionSet* Selection; // 0x3d8(0x08)
	struct TArray<struct AActor*> SpawnedActors; // 0x3e0(0x10)
	char pad_3f0[0x380]; // 0x3f0(0x380)
};

// Class MeshModelingToolsExp.MeshSpaceDeformerToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshSpaceDeformerToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.MeshSpaceDeformerToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UMeshSpaceDeformerToolProperties : UInteractiveToolPropertySet {
	enum class ENonlinearOperationType SelectedOperationType; // 0x118(0x01)
	float UpperBoundsInterval; // 0x11c(0x04)
	float LowerBoundsInterval; // 0x120(0x04)
	float BendDegrees; // 0x124(0x04)
	float TwistDegrees; // 0x128(0x04)
	enum class EFlareProfileType FlareProfileType; // 0x12c(0x01)
	float FlarePercentY; // 0x130(0x04)
	bool bLockXAndYFlaring; // 0x134(0x01)
	char pad_137[0x1]; // 0x137(0x01)
	float FlarePercentX; // 0x138(0x04)
	bool bLockBottom; // 0x13c(0x01)
	bool bShowOriginalMesh; // 0x13d(0x01)
	bool bDrawVisualization; // 0x13e(0x01)
	bool bAlignToNormalOnCtrlClick; // 0x13f(0x01)
};

// Class MeshModelingToolsExp.MeshSpaceDeformerToolActionPropertySet
// Size: 0x120 (Inherited: 0x120)
struct UMeshSpaceDeformerToolActionPropertySet : UInteractiveToolPropertySet {

	void ShiftToCenter(); // Function MeshModelingToolsExp.MeshSpaceDeformerToolActionPropertySet.ShiftToCenter // (Final|Native|Public) // @ game+0x9611a80
};

// Class MeshModelingToolsExp.SpaceDeformerOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct USpaceDeformerOperatorFactory : UObject {
	struct UMeshSpaceDeformerTool* SpaceDeformerTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.MeshSpaceDeformerTool
// Size: 0x340 (Inherited: 0x130)
struct UMeshSpaceDeformerTool : USingleSelectionMeshEditingTool {
	struct UMeshSpaceDeformerToolProperties* Settings; // 0x130(0x08)
	struct UMeshSpaceDeformerToolActionPropertySet* ToolActions; // 0x138(0x08)
	struct UGizmoTransformChangeStateTarget* StateTarget; // 0x140(0x08)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x148(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x150(0x08)
	char pad_158[0x10]; // 0x158(0x10)
	struct UPreviewMesh* OriginalMeshPreview; // 0x168(0x08)
	struct UIntervalGizmo* IntervalGizmo; // 0x170(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x178(0x08)
	struct UTransformProxy* TransformProxy; // 0x180(0x08)
	struct UGizmoLocalFloatParameterSource* UpIntervalSource; // 0x188(0x08)
	struct UGizmoLocalFloatParameterSource* DownIntervalSource; // 0x190(0x08)
	struct UGizmoLocalFloatParameterSource* ForwardIntervalSource; // 0x198(0x08)
	char pad_1a0[0x1a0]; // 0x1a0(0x1a0)
};

// Class MeshModelingToolsExp.MeshVertexPaintToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshVertexPaintToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.VertexPaintBasicProperties
// Size: 0x150 (Inherited: 0x120)
struct UVertexPaintBasicProperties : UInteractiveToolPropertySet {
	enum class EMeshVertexPaintBrushType PrimaryBrushType; // 0x118(0x01)
	enum class EMeshVertexPaintInteractionType SubToolType; // 0x119(0x01)
	struct FLinearColor PaintColor; // 0x11c(0x10)
	enum class EMeshVertexPaintColorBlendMode BlendMode; // 0x12c(0x01)
	enum class EMeshVertexPaintSecondaryActionType SecondaryActionType; // 0x12d(0x01)
	struct FLinearColor EraseColor; // 0x130(0x10)
	float SmoothStrength; // 0x140(0x04)
	struct FModelingToolsColorChannelFilter ChannelFilter; // 0x144(0x04)
	bool bHardEdges; // 0x148(0x01)
	char pad_14d[0x3]; // 0x14d(0x03)
};

// Class MeshModelingToolsExp.VertexPaintBrushFilterProperties
// Size: 0x130 (Inherited: 0x120)
struct UVertexPaintBrushFilterProperties : UInteractiveToolPropertySet {
	enum class EMeshVertexPaintBrushAreaType BrushAreaMode; // 0x118(0x01)
	float AngleThreshold; // 0x11c(0x04)
	bool bUVSeams; // 0x120(0x01)
	bool bNormalSeams; // 0x121(0x01)
	enum class EMeshVertexPaintVisibilityType VisibilityFilter; // 0x122(0x01)
	int32_t MinTriVertCount; // 0x124(0x04)
	enum class EMeshVertexPaintMaterialMode MaterialMode; // 0x128(0x01)
	bool bShowHitColor; // 0x129(0x01)
	enum class EMeshVertexPaintInteractionType CurrentSubToolType; // 0x12a(0x01)
	char pad_12f[0x1]; // 0x12f(0x01)
};

// Class MeshModelingToolsExp.MeshVertexPaintToolActionPropertySet
// Size: 0x120 (Inherited: 0x120)
struct UMeshVertexPaintToolActionPropertySet : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.MeshVertexPaintToolQuickActions
// Size: 0x120 (Inherited: 0x120)
struct UMeshVertexPaintToolQuickActions : UMeshVertexPaintToolActionPropertySet {

	void PaintAll(); // Function MeshModelingToolsExp.MeshVertexPaintToolQuickActions.PaintAll // (Final|Native|Public) // @ game+0x963f6d0
	void FillWhite(); // Function MeshModelingToolsExp.MeshVertexPaintToolQuickActions.FillWhite // (Final|Native|Public) // @ game+0x9615b90
	void FillBlack(); // Function MeshModelingToolsExp.MeshVertexPaintToolQuickActions.FillBlack // (Final|Native|Public) // @ game+0x9629ce0
	void EraseAll(); // Function MeshModelingToolsExp.MeshVertexPaintToolQuickActions.EraseAll // (Final|Native|Public) // @ game+0x964dcc0
};

// Class MeshModelingToolsExp.MeshVertexPaintToolUtilityActions
// Size: 0x170 (Inherited: 0x120)
struct UMeshVertexPaintToolUtilityActions : UMeshVertexPaintToolActionPropertySet {
	enum class EMeshVertexPaintToolUtilityOperations Operation; // 0x120(0x04)
	enum class EMeshVertexPaintColorChannel SourceChannel; // 0x124(0x01)
	char pad_125[0x3]; // 0x125(0x03)
	float SourceValue; // 0x128(0x04)
	struct FName WeightMap; // 0x12c(0x08)
	char pad_134[0x4]; // 0x134(0x04)
	struct TArray<struct FString> WeightMapsList; // 0x138(0x10)
	struct FModelingToolsColorChannelFilter TargetChannels; // 0x148(0x04)
	enum class EMeshVertexPaintColorChannel TargetChannel; // 0x14c(0x01)
	bool bCopyToHiRes; // 0x14d(0x01)
	char pad_14e[0x2]; // 0x14e(0x02)
	struct FString CopyToLODName; // 0x150(0x10)
	struct TArray<struct FString> LODNamesList; // 0x160(0x10)

	struct TArray<struct FString> GetWeightMapsFunc(); // Function MeshModelingToolsExp.MeshVertexPaintToolUtilityActions.GetWeightMapsFunc // (Final|Native|Public) // @ game+0x9595d60
	struct TArray<struct FString> GetLODNamesFunc(); // Function MeshModelingToolsExp.MeshVertexPaintToolUtilityActions.GetLODNamesFunc // (Final|Native|Public|Const) // @ game+0x9649a30
	void ApplySelectedOperation(); // Function MeshModelingToolsExp.MeshVertexPaintToolUtilityActions.ApplySelectedOperation // (Final|Native|Public) // @ game+0x9611280
};

// Class MeshModelingToolsExp.MeshVertexPaintTool
// Size: 0x11a0 (Inherited: 0xc10)
struct UMeshVertexPaintTool : UMeshSculptToolBase {
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0xc08(0x08)
	struct UVertexPaintBasicProperties* BasicProperties; // 0xc10(0x08)
	struct UVertexPaintBrushFilterProperties* FilterProperties; // 0xc18(0x08)
	struct UVertexColorPaintBrushOpProps* PaintBrushOpProperties; // 0xc20(0x08)
	struct UVertexColorPaintBrushOpProps* EraseBrushOpProperties; // 0xc28(0x08)
	struct UMeshVertexPaintToolQuickActions* QuickActions; // 0xc30(0x08)
	struct UMeshVertexPaintToolUtilityActions* UtilityActions; // 0xc38(0x08)
	struct UPolyLassoMarqueeMechanic* PolyLassoMechanic; // 0xc48(0x08)
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0xc50(0x08)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0xc58(0x08)
	struct UMeshElementsVisualizer* MeshElementsDisplay; // 0xc60(0x08)
	char pad_c68[0x538]; // 0xc68(0x538)
};

// Class MeshModelingToolsExp.MeshVertexSculptToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshVertexSculptToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.VertexBrushSculptProperties
// Size: 0x130 (Inherited: 0x120)
struct UVertexBrushSculptProperties : UInteractiveToolPropertySet {
	enum class EMeshVertexSculptBrushType PrimaryBrushType; // 0x118(0x01)
	enum class EMeshSculptFalloffType PrimaryFalloffType; // 0x119(0x01)
	enum class EMeshVertexSculptBrushFilterType BrushFilter; // 0x11a(0x01)
	bool bFreezeTarget; // 0x11b(0x01)
	struct TWeakObjectPtr<struct UMeshVertexSculptTool> Tool; // 0x11c(0x08)
	char pad_12c[0x4]; // 0x12c(0x04)
};

// Class MeshModelingToolsExp.VertexBrushAlphaProperties
// Size: 0x140 (Inherited: 0x120)
struct UVertexBrushAlphaProperties : UInteractiveToolPropertySet {
	struct UTexture2D* Alpha; // 0x118(0x08)
	float RotationAngle; // 0x120(0x04)
	bool bRandomize; // 0x124(0x01)
	float RandomRange; // 0x128(0x04)
	struct TWeakObjectPtr<struct UMeshVertexSculptTool> Tool; // 0x12c(0x08)
	char pad_139[0x7]; // 0x139(0x07)
};

// Class MeshModelingToolsExp.MeshSymmetryProperties
// Size: 0x120 (Inherited: 0x120)
struct UMeshSymmetryProperties : UInteractiveToolPropertySet {
	bool bEnableSymmetry; // 0x118(0x01)
	bool bSymmetryCanBeEnabled; // 0x119(0x01)
};

// Class MeshModelingToolsExp.MeshVertexSculptTool
// Size: 0x1560 (Inherited: 0xc10)
struct UMeshVertexSculptTool : UMeshSculptToolBase {
	struct UVertexBrushSculptProperties* SculptProperties; // 0xc08(0x08)
	struct UVertexBrushAlphaProperties* AlphaProperties; // 0xc10(0x08)
	struct UTexture2D* BrushAlpha; // 0xc18(0x08)
	struct UMeshSymmetryProperties* SymmetryProperties; // 0xc20(0x08)
	char pad_c30[0x10]; // 0xc30(0x10)
	struct AInternalToolFrameworkActor* PreviewMeshActor; // 0xc40(0x08)
	struct UDynamicMeshComponent* DynamicMeshComponent; // 0xc48(0x08)
	char pad_c50[0x910]; // 0xc50(0x910)
};

// Class MeshModelingToolsExp.MirrorToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMirrorToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.MirrorToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UMirrorToolProperties : UInteractiveToolPropertySet {
	enum class EMirrorOperationMode OperationMode; // 0x118(0x01)
	bool bCropAlongMirrorPlaneFirst; // 0x119(0x01)
	bool bSimplifyAlongCrop; // 0x11a(0x01)
	bool bWeldVerticesOnMirrorPlane; // 0x11b(0x01)
	double PlaneTolerance; // 0x120(0x08)
	bool bAllowBowtieVertexCreation; // 0x128(0x01)
	bool bShowPreview; // 0x129(0x01)
	enum class EMirrorSaveMode WriteTo; // 0x12a(0x01)
	char pad_12f[0x1]; // 0x12f(0x01)
};

// Class MeshModelingToolsExp.MirrorOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UMirrorOperatorFactory : UObject {
	struct UMirrorTool* MirrorTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.MirrorToolActionPropertySet
// Size: 0x130 (Inherited: 0x120)
struct UMirrorToolActionPropertySet : UInteractiveToolPropertySet {
	bool bButtonsOnlyChangeOrientation; // 0x120(0x01)
	char pad_121[0xf]; // 0x121(0x0f)

	void Up(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Up // (Final|Native|Public) // @ game+0x9635a50
	void ShiftToCenter(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.ShiftToCenter // (Final|Native|Public) // @ game+0x966bec0
	void Right(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Right // (Final|Native|Public) // @ game+0x962dd60
	void Left(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Left // (Final|Native|Public) // @ game+0x9608790
	void Forward(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Forward // (Final|Native|Public) // @ game+0x9674eb0
	void Down(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Down // (Final|Native|Public) // @ game+0x9643d00
	void Backward(); // Function MeshModelingToolsExp.MirrorToolActionPropertySet.Backward // (Final|Native|Public) // @ game+0x964a130
};

// Class MeshModelingToolsExp.MirrorTool
// Size: 0x1f0 (Inherited: 0x130)
struct UMirrorTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UMirrorToolProperties* Settings; // 0x138(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x140(0x08)
	struct UOnAcceptHandleSourcesProperties* HandleSourcesProperties; // 0x148(0x08)
	struct UMirrorToolActionPropertySet* ToolActions; // 0x150(0x08)
	struct TArray<struct UDynamicMeshReplacementChangeTarget*> MeshesToMirror; // 0x158(0x10)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews; // 0x168(0x10)
	char pad_178[0x30]; // 0x178(0x30)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x1a8(0x08)
	char pad_1b0[0x40]; // 0x1b0(0x40)
};

// Class MeshModelingToolsExp.OffsetMeshToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UOffsetMeshToolProperties : UInteractiveToolPropertySet {
	enum class EOffsetMeshToolOffsetType OffsetType; // 0x118(0x01)
	float Distance; // 0x11c(0x04)
	bool bCreateShell; // 0x120(0x01)
	char pad_126[0xa]; // 0x126(0x0a)
};

// Class MeshModelingToolsExp.OffsetWeightMapSetProperties
// Size: 0x140 (Inherited: 0x140)
struct UOffsetWeightMapSetProperties : UWeightMapSetProperties {
	float MinDistance; // 0x138(0x04)
};

// Class MeshModelingToolsExp.IterativeOffsetProperties
// Size: 0x130 (Inherited: 0x120)
struct UIterativeOffsetProperties : UInteractiveToolPropertySet {
	int32_t Steps; // 0x118(0x04)
	bool bOffsetBoundaries; // 0x11c(0x01)
	float SmoothingPerStep; // 0x120(0x04)
	bool bReprojectSmooth; // 0x124(0x01)
	char pad_12a[0x6]; // 0x12a(0x06)
};

// Class MeshModelingToolsExp.ImplicitOffsetProperties
// Size: 0x120 (Inherited: 0x120)
struct UImplicitOffsetProperties : UInteractiveToolPropertySet {
	float Smoothness; // 0x118(0x04)
	bool bPreserveUVs; // 0x11c(0x01)
};

// Class MeshModelingToolsExp.OffsetMeshTool
// Size: 0x4a0 (Inherited: 0x480)
struct UOffsetMeshTool : UBaseMeshProcessingTool {
	struct UOffsetMeshToolProperties* OffsetProperties; // 0x480(0x08)
	struct UIterativeOffsetProperties* IterativeProperties; // 0x488(0x08)
	struct UImplicitOffsetProperties* ImplicitProperties; // 0x490(0x08)
	struct UOffsetWeightMapSetProperties* WeightMapProperties; // 0x498(0x08)
};

// Class MeshModelingToolsExp.OffsetMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UOffsetMeshToolBuilder : UBaseMeshProcessingToolBuilder {
};

// Class MeshModelingToolsExp.PhysicsObjectToolPropertySet
// Size: 0x180 (Inherited: 0x120)
struct UPhysicsObjectToolPropertySet : UInteractiveToolPropertySet {
	struct FString ObjectName; // 0x118(0x10)
	enum class ECollisionGeometryMode CollisionType; // 0x128(0x04)
	struct TArray<struct FPhysicsSphereData> Spheres; // 0x130(0x10)
	struct TArray<struct FPhysicsBoxData> Boxes; // 0x140(0x10)
	struct TArray<struct FPhysicsCapsuleData> Capsules; // 0x150(0x10)
	struct TArray<struct FPhysicsConvexData> Convexes; // 0x160(0x10)
	struct TArray<struct FPhysicsLevelSetData> LevelSets; // 0x170(0x10)
};

// Class MeshModelingToolsExp.CollisionGeometryVisualizationProperties
// Size: 0x140 (Inherited: 0x120)
struct UCollisionGeometryVisualizationProperties : UInteractiveToolPropertySet {
	bool bShowCollision; // 0x118(0x01)
	float LineThickness; // 0x11c(0x04)
	bool bShowHidden; // 0x120(0x01)
	bool bRandomColors; // 0x121(0x01)
	struct FColor Color; // 0x124(0x04)
	struct UMaterialInterface* LineMaterial; // 0x128(0x08)
	struct UMaterialInterface* LineMaterialShowingHidden; // 0x130(0x08)
	bool bEnableShowCollision; // 0x138(0x01)
	char pad_13c[0x4]; // 0x13c(0x04)
};

// Class MeshModelingToolsExp.ExtractCollisionGeometryToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UExtractCollisionGeometryToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.ExtractCollisionToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UExtractCollisionToolProperties : UInteractiveToolPropertySet {
	enum class EExtractCollisionOutputType CollisionType; // 0x118(0x01)
	bool bWeldEdges; // 0x119(0x01)
	bool bOutputSeparateMeshes; // 0x11a(0x01)
	bool bShowPreview; // 0x11b(0x01)
	bool bShowInputMesh; // 0x11c(0x01)
};

// Class MeshModelingToolsExp.ExtractCollisionGeometryTool
// Size: 0x3b0 (Inherited: 0x130)
struct UExtractCollisionGeometryTool : USingleSelectionMeshEditingTool {
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x130(0x08)
	struct UExtractCollisionToolProperties* Settings; // 0x138(0x08)
	struct UCollisionGeometryVisualizationProperties* VizSettings; // 0x140(0x08)
	struct UPhysicsObjectToolPropertySet* ObjectProps; // 0x148(0x08)
	struct UPreviewGeometry* PreviewElements; // 0x150(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x158(0x08)
	char pad_160[0x250]; // 0x160(0x250)
};

// Class MeshModelingToolsExp.PhysicsInspectorToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UPhysicsInspectorToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.PhysicsInspectorTool
// Size: 0x170 (Inherited: 0x130)
struct UPhysicsInspectorTool : UMultiSelectionMeshEditingTool {
	struct UCollisionGeometryVisualizationProperties* VizSettings; // 0x130(0x08)
	struct TArray<struct UPhysicsObjectToolPropertySet*> ObjectData; // 0x138(0x10)
	struct TArray<struct UPreviewGeometry*> PreviewElements; // 0x148(0x10)
	char pad_158[0x18]; // 0x158(0x18)
};

// Class MeshModelingToolsExp.SetCollisionGeometryToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USetCollisionGeometryToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.SetCollisionGeometryToolProperties
// Size: 0x160 (Inherited: 0x120)
struct USetCollisionGeometryToolProperties : UInteractiveToolPropertySet {
	enum class ECollisionGeometryType GeometryType; // 0x118(0x04)
	bool bAppendToExisting; // 0x11c(0x01)
	bool bUseWorldSpace; // 0x11d(0x01)
	enum class ESetCollisionGeometryInputMode InputMode; // 0x120(0x04)
	bool bRemoveContained; // 0x124(0x01)
	bool bEnableMaxCount; // 0x125(0x01)
	int32_t MaxCount; // 0x128(0x04)
	float MinThickness; // 0x12c(0x04)
	bool bDetectBoxes; // 0x130(0x01)
	bool bDetectSpheres; // 0x131(0x01)
	bool bDetectCapsules; // 0x132(0x01)
	bool bSimplifyHulls; // 0x133(0x01)
	int32_t HullTargetFaceCount; // 0x134(0x04)
	int32_t MaxHullsPerMesh; // 0x138(0x04)
	float ConvexDecompositionSearchFactor; // 0x13c(0x04)
	float AddHullsErrorTolerance; // 0x140(0x04)
	float MinPartThickness; // 0x144(0x04)
	bool bSimplifyPolygons; // 0x148(0x01)
	float HullTolerance; // 0x14c(0x04)
	enum class EProjectedHullAxis SweepAxis; // 0x150(0x04)
	int32_t LevelSetResolution; // 0x154(0x04)
	enum class ECollisionGeometryMode SetCollisionType; // 0x158(0x04)
	bool bUsingMultipleInputs; // 0x15c(0x01)
	char pad_15e[0x2]; // 0x15e(0x02)
};

// Class MeshModelingToolsExp.SetCollisionGeometryTool
// Size: 0x390 (Inherited: 0x130)
struct USetCollisionGeometryTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct USetCollisionGeometryToolProperties* Settings; // 0x138(0x08)
	struct UPolygroupLayersProperties* PolygroupLayerProperties; // 0x140(0x08)
	struct UCollisionGeometryVisualizationProperties* VizSettings; // 0x148(0x08)
	struct UPhysicsObjectToolPropertySet* CollisionProps; // 0x150(0x08)
	char pad_158[0x8]; // 0x158(0x08)
	struct UPreviewGeometry* PreviewGeom; // 0x160(0x08)
	char pad_168[0x228]; // 0x168(0x228)
};

// Class MeshModelingToolsExp.SimpleCollisionEditorToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USimpleCollisionEditorToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties
// Size: 0x120 (Inherited: 0x120)
struct USimpleCollisionEditorToolActionProperties : UInteractiveToolPropertySet {

	void Duplicate(); // Function MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties.Duplicate // (Final|Native|Public) // @ game+0x96e3610
	void DeleteAll(); // Function MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties.DeleteAll // (Final|Native|Public) // @ game+0x96b7ad0
	void Delete(); // Function MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties.Delete // (Final|Native|Public) // @ game+0x96a3c60
	void AddSphere(); // Function MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties.AddSphere // (Final|Native|Public) // @ game+0x96e3cf0
	void AddCapsule(); // Function MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties.AddCapsule // (Final|Native|Public) // @ game+0x96ca330
	void AddBox(); // Function MeshModelingToolsExp.SimpleCollisionEditorToolActionProperties.AddBox // (Final|Native|Public) // @ game+0x96e2c30
};

// Class MeshModelingToolsExp.SimpleCollisionEditorTool
// Size: 0x160 (Inherited: 0x130)
struct USimpleCollisionEditorTool : USingleSelectionMeshEditingTool {
	struct USimpleCollisionEditorToolActionProperties* ActionProperties; // 0x130(0x08)
	char pad_138[0x28]; // 0x138(0x28)
};

// Class MeshModelingToolsExp.PlaneCutToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UPlaneCutToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.PlaneCutToolProperties
// Size: 0x130 (Inherited: 0x120)
struct UPlaneCutToolProperties : UInteractiveToolPropertySet {
	bool bKeepBothHalves; // 0x118(0x01)
	float SpacingBetweenHalves; // 0x11c(0x04)
	bool bExportSeparatedPiecesAsNewMeshAssets; // 0x120(0x01)
	bool bShowPreview; // 0x121(0x01)
	bool bFillCutHole; // 0x122(0x01)
	bool bFillSpans; // 0x123(0x01)
	bool bSimplifyAlongCut; // 0x124(0x01)
	char pad_12a[0x6]; // 0x12a(0x06)
};

// Class MeshModelingToolsExp.PlaneCutOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UPlaneCutOperatorFactory : UObject {
	struct UPlaneCutTool* CutTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.PlaneCutTool
// Size: 0x210 (Inherited: 0x130)
struct UPlaneCutTool : UMultiSelectionMeshEditingTool {
	struct UPlaneCutToolProperties* BasicProperties; // 0x130(0x08)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews; // 0x138(0x10)
	struct TArray<struct UDynamicMeshReplacementChangeTarget*> MeshesToCut; // 0x148(0x10)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x158(0x08)
	char pad_160[0xb0]; // 0x160(0xb0)

	void FlipPlane(); // Function MeshModelingToolsExp.PlaneCutTool.FlipPlane // (Final|Native|Protected) // @ game+0x96cbff0
	void Cut(); // Function MeshModelingToolsExp.PlaneCutTool.Cut // (Final|Native|Protected) // @ game+0x96a7310
};

// Class MeshModelingToolsExp.ProjectToTargetToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UProjectToTargetToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.RemeshMeshToolProperties
// Size: 0x150 (Inherited: 0x130)
struct URemeshMeshToolProperties : URemeshProperties {
	int32_t TargetTriangleCount; // 0x128(0x04)
	enum class ERemeshSmoothingType SmoothingType; // 0x12c(0x01)
	bool bDiscardAttributes; // 0x12d(0x01)
	bool bShowGroupColors; // 0x12e(0x01)
	enum class ERemeshType RemeshType; // 0x12f(0x01)
	int32_t RemeshIterations; // 0x130(0x04)
	int32_t MaxRemeshIterations; // 0x134(0x04)
	int32_t ExtraProjectionIterations; // 0x138(0x04)
	bool bUseTargetEdgeLength; // 0x13c(0x01)
	float TargetEdgeLength; // 0x140(0x04)
	bool bReproject; // 0x144(0x01)
	bool bReprojectConstraints; // 0x145(0x01)
	float BoundaryCornerAngleThreshold; // 0x148(0x04)
	char pad_14f[0x1]; // 0x14f(0x01)
};

// Class MeshModelingToolsExp.ProjectToTargetToolProperties
// Size: 0x170 (Inherited: 0x150)
struct UProjectToTargetToolProperties : URemeshMeshToolProperties {
	bool bWorldSpace; // 0x150(0x01)
	bool bParallel; // 0x151(0x01)
	char pad_152[0x2]; // 0x152(0x02)
	int32_t FaceProjectionPassesPerRemeshIteration; // 0x154(0x04)
	float SurfaceProjectionSpeed; // 0x158(0x04)
	float NormalAlignmentSpeed; // 0x15c(0x04)
	bool bSmoothInFillAreas; // 0x160(0x01)
	char pad_161[0x3]; // 0x161(0x03)
	float FillAreaDistanceMultiplier; // 0x164(0x04)
	float FillAreaSmoothMultiplier; // 0x168(0x04)
	char pad_16c[0x4]; // 0x16c(0x04)
};

// Class MeshModelingToolsExp.RemeshMeshTool
// Size: 0x180 (Inherited: 0x130)
struct URemeshMeshTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct URemeshMeshToolProperties* BasicProperties; // 0x138(0x08)
	struct UMeshStatisticsProperties* MeshStatisticsProperties; // 0x140(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x148(0x08)
	struct UMeshElementsVisualizer* MeshElementsDisplay; // 0x150(0x08)
	char pad_158[0x28]; // 0x158(0x28)
};

// Class MeshModelingToolsExp.ProjectToTargetTool
// Size: 0x190 (Inherited: 0x180)
struct UProjectToTargetTool : URemeshMeshTool {
	char pad_180[0x10]; // 0x180(0x10)
};

// Class MeshModelingToolsExp.MeshAnalysisProperties
// Size: 0x140 (Inherited: 0x120)
struct UMeshAnalysisProperties : UInteractiveToolPropertySet {
	struct FString SurfaceArea; // 0x118(0x10)
	struct FString Volume; // 0x128(0x10)
};

// Class MeshModelingToolsExp.MeshStatisticsProperties
// Size: 0x150 (Inherited: 0x120)
struct UMeshStatisticsProperties : UInteractiveToolPropertySet {
	struct FString Mesh; // 0x118(0x10)
	struct FString UV; // 0x128(0x10)
	struct FString Attributes; // 0x138(0x10)
};

// Class MeshModelingToolsExp.RemeshMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct URemeshMeshToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.RemoveOccludedTrianglesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct URemoveOccludedTrianglesToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.RemoveOccludedTrianglesToolProperties
// Size: 0x150 (Inherited: 0x120)
struct URemoveOccludedTrianglesToolProperties : UInteractiveToolPropertySet {
	enum class EOcclusionCalculationUIMode OcclusionTestMethod; // 0x118(0x01)
	enum class EOcclusionTriangleSamplingUIMode TriangleSampling; // 0x119(0x01)
	double WindingIsoValue; // 0x120(0x08)
	int32_t AddRandomRays; // 0x128(0x04)
	int32_t AddTriangleSamples; // 0x12c(0x04)
	bool bOnlySelfOcclude; // 0x130(0x01)
	char pad_133[0x1]; // 0x133(0x01)
	int32_t ShrinkRemoval; // 0x134(0x04)
	double MinAreaIsland; // 0x138(0x08)
	int32_t MinTriCountIsland; // 0x140(0x04)
	enum class EOccludedAction Action; // 0x144(0x01)
	char pad_145[0xb]; // 0x145(0x0b)
};

// Class MeshModelingToolsExp.RemoveOccludedTrianglesAdvancedProperties
// Size: 0x120 (Inherited: 0x120)
struct URemoveOccludedTrianglesAdvancedProperties : UInteractiveToolPropertySet {
};

// Class MeshModelingToolsExp.RemoveOccludedTrianglesOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct URemoveOccludedTrianglesOperatorFactory : UObject {
	struct URemoveOccludedTrianglesTool* Tool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.RemoveOccludedTrianglesTool
// Size: 0x250 (Inherited: 0x130)
struct URemoveOccludedTrianglesTool : UMultiSelectionMeshEditingTool {
	struct URemoveOccludedTrianglesToolProperties* BasicProperties; // 0x130(0x08)
	struct UPolygroupLayersProperties* PolygroupLayersProperties; // 0x138(0x08)
	struct URemoveOccludedTrianglesAdvancedProperties* AdvancedProperties; // 0x140(0x08)
	struct TArray<struct UMeshOpPreviewWithBackgroundCompute*> Previews; // 0x148(0x10)
	struct TArray<struct UPreviewMesh*> PreviewCopies; // 0x158(0x10)
	char pad_168[0xe8]; // 0x168(0xe8)
};

// Class MeshModelingToolsExp.RevolveBoundaryToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct URevolveBoundaryToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.RevolveBoundaryOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct URevolveBoundaryOperatorFactory : UObject {
	struct URevolveBoundaryTool* RevolveBoundaryTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.RevolveBoundaryToolProperties
// Size: 0x1c0 (Inherited: 0x190)
struct URevolveBoundaryToolProperties : URevolveProperties {
	enum class ERevolvePropertiesCapFillMode CapFillMode; // 0x188(0x01)
	bool bDisplayInputMesh; // 0x189(0x01)
	struct FVector AxisOrigin; // 0x190(0x18)
	struct FVector2D AxisOrientation; // 0x1a8(0x10)
	char pad_1ba[0x6]; // 0x1ba(0x06)
};

// Class MeshModelingToolsExp.RevolveBoundaryTool
// Size: 0x290 (Inherited: 0x220)
struct URevolveBoundaryTool : UMeshBoundaryToolBase {
	char pad_220[0x18]; // 0x220(0x18)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x238(0x08)
	struct URevolveBoundaryToolProperties* Settings; // 0x240(0x08)
	struct UNewMeshMaterialProperties* MaterialProperties; // 0x248(0x08)
	struct UConstructionPlaneMechanic* PlaneMechanic; // 0x250(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x258(0x08)
	char pad_260[0x30]; // 0x260(0x30)
};

// Class MeshModelingToolsExp.SculptBrushProperties
// Size: 0x150 (Inherited: 0x120)
struct USculptBrushProperties : UInteractiveToolPropertySet {
	struct FBrushToolRadius BrushSize; // 0x118(0x14)
	float BrushFalloffAmount; // 0x12c(0x04)
	bool bShowFalloff; // 0x130(0x01)
	float Depth; // 0x134(0x04)
	bool bHitBackFaces; // 0x138(0x01)
	float FlowRate; // 0x13c(0x04)
	float Spacing; // 0x140(0x04)
	float Lazyness; // 0x144(0x04)
	bool bShowPerBrushProps; // 0x148(0x01)
	bool bShowLazyness; // 0x149(0x01)
	bool bShowFlowRate; // 0x14a(0x01)
	bool bShowSpacing; // 0x14b(0x01)
	char pad_14e[0x2]; // 0x14e(0x02)
};

// Class MeshModelingToolsExp.KelvinBrushProperties
// Size: 0x130 (Inherited: 0x120)
struct UKelvinBrushProperties : UInteractiveToolPropertySet {
	float FalloffDistance; // 0x118(0x04)
	float Stiffness; // 0x11c(0x04)
	float Incompressiblity; // 0x120(0x04)
	int32_t BrushSteps; // 0x124(0x04)
};

// Class MeshModelingToolsExp.WorkPlaneProperties
// Size: 0x160 (Inherited: 0x120)
struct UWorkPlaneProperties : UInteractiveToolPropertySet {
	bool bPropertySetEnabled; // 0x118(0x01)
	bool bShowGizmo; // 0x119(0x01)
	struct FVector Position; // 0x120(0x18)
	char pad_13a[0x6]; // 0x13a(0x06)
	struct FQuat Rotation; // 0x140(0x20)
};

// Class MeshModelingToolsExp.SculptMaxBrushProperties
// Size: 0x120 (Inherited: 0x120)
struct USculptMaxBrushProperties : UInteractiveToolPropertySet {
	float MaxHeight; // 0x118(0x04)
	bool bFreezeCurrentHeight; // 0x11c(0x01)
};

// Class MeshModelingToolsExp.SeamSculptToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USeamSculptToolBuilder : UMeshSurfacePointMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.SeamSculptToolProperties
// Size: 0x120 (Inherited: 0x120)
struct USeamSculptToolProperties : UInteractiveToolPropertySet {
	bool bShowWireframe; // 0x118(0x01)
	bool bHitBackFaces; // 0x119(0x01)
};

// Class MeshModelingToolsExp.SeamSculptTool
// Size: 0x430 (Inherited: 0x340)
struct USeamSculptTool : UDynamicMeshBrushTool {
	struct USeamSculptToolProperties* Settings; // 0x340(0x08)
	struct UPreviewGeometry* PreviewGeom; // 0x348(0x08)
	char pad_350[0xe0]; // 0x350(0xe0)
};

// Class MeshModelingToolsExp.SelfUnionMeshesToolProperties
// Size: 0x130 (Inherited: 0x120)
struct USelfUnionMeshesToolProperties : UInteractiveToolPropertySet {
	bool bTrimFlaps; // 0x118(0x01)
	bool bTryFixHoles; // 0x119(0x01)
	bool bTryCollapseEdges; // 0x11a(0x01)
	float WindingThreshold; // 0x11c(0x04)
	bool bShowNewBoundaryEdges; // 0x120(0x01)
	bool bOnlyUseFirstMeshMaterials; // 0x121(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.SelfUnionMeshesTool
// Size: 0x1c0 (Inherited: 0x180)
struct USelfUnionMeshesTool : UBaseCreateFromSelectedTool {
	struct USelfUnionMeshesToolProperties* Properties; // 0x178(0x08)
	struct ULineSetComponent* DrawnLineSet; // 0x180(0x08)
	char pad_190[0x30]; // 0x190(0x30)
};

// Class MeshModelingToolsExp.SelfUnionMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USelfUnionMeshesToolBuilder : UBaseCreateFromSelectedToolBuilder {
};

// Class MeshModelingToolsExp.SmoothMeshToolProperties
// Size: 0x120 (Inherited: 0x120)
struct USmoothMeshToolProperties : UInteractiveToolPropertySet {
	enum class ESmoothMeshToolSmoothType SmoothingType; // 0x118(0x01)
};

// Class MeshModelingToolsExp.IterativeSmoothProperties
// Size: 0x130 (Inherited: 0x120)
struct UIterativeSmoothProperties : UInteractiveToolPropertySet {
	float SmoothingPerStep; // 0x118(0x04)
	int32_t Steps; // 0x11c(0x04)
	bool bSmoothBoundary; // 0x120(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.DiffusionSmoothProperties
// Size: 0x130 (Inherited: 0x120)
struct UDiffusionSmoothProperties : UInteractiveToolPropertySet {
	float SmoothingPerStep; // 0x118(0x04)
	int32_t Steps; // 0x11c(0x04)
	bool bPreserveUVs; // 0x120(0x01)
	char pad_129[0x7]; // 0x129(0x07)
};

// Class MeshModelingToolsExp.ImplicitSmoothProperties
// Size: 0x130 (Inherited: 0x120)
struct UImplicitSmoothProperties : UInteractiveToolPropertySet {
	float SmoothSpeed; // 0x118(0x04)
	float Smoothness; // 0x11c(0x04)
	bool bPreserveUVs; // 0x120(0x01)
	float VolumeCorrection; // 0x124(0x04)
	char pad_12d[0x3]; // 0x12d(0x03)
};

// Class MeshModelingToolsExp.SmoothWeightMapSetProperties
// Size: 0x140 (Inherited: 0x140)
struct USmoothWeightMapSetProperties : UWeightMapSetProperties {
	float MinSmoothMultiplier; // 0x138(0x04)
};

// Class MeshModelingToolsExp.SmoothMeshTool
// Size: 0x4b0 (Inherited: 0x480)
struct USmoothMeshTool : UBaseMeshProcessingTool {
	struct USmoothMeshToolProperties* SmoothProperties; // 0x480(0x08)
	struct UIterativeSmoothProperties* IterativeProperties; // 0x488(0x08)
	struct UDiffusionSmoothProperties* DiffusionProperties; // 0x490(0x08)
	struct UImplicitSmoothProperties* ImplicitProperties; // 0x498(0x08)
	struct USmoothWeightMapSetProperties* WeightMapProperties; // 0x4a0(0x08)
	char pad_4a8[0x8]; // 0x4a8(0x08)
};

// Class MeshModelingToolsExp.SmoothMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USmoothMeshToolBuilder : UBaseMeshProcessingToolBuilder {
};

// Class MeshModelingToolsExp.SplitMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USplitMeshesToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.SplitMeshesToolProperties
// Size: 0x120 (Inherited: 0x120)
struct USplitMeshesToolProperties : UInteractiveToolPropertySet {
	bool bTransferMaterials; // 0x118(0x01)
};

// Class MeshModelingToolsExp.SplitMeshesTool
// Size: 0x170 (Inherited: 0x130)
struct USplitMeshesTool : UMultiSelectionMeshEditingTool {
	struct USplitMeshesToolProperties* BasicProperties; // 0x130(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x138(0x08)
	char pad_140[0x30]; // 0x140(0x30)
};

// Class MeshModelingToolsExp.TransferMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UTransferMeshToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.TransferMeshToolProperties
// Size: 0x190 (Inherited: 0x120)
struct UTransferMeshToolProperties : UInteractiveToolPropertySet {
	bool bTransferMaterials; // 0x118(0x01)
	bool bTransferCollision; // 0x119(0x01)
	struct FString SourceLOD; // 0x120(0x10)
	struct FString TargetLod; // 0x130(0x10)
	bool bIsStaticMeshSource; // 0x140(0x01)
	char pad_143[0x5]; // 0x143(0x05)
	struct TArray<struct FString> SourceLODNamesList; // 0x148(0x10)
	char pad_158[0x10]; // 0x158(0x10)
	struct TArray<struct FString> TargetLODNamesList; // 0x168(0x10)
	char pad_178[0x10]; // 0x178(0x10)
	bool bIsStaticMeshTarget; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)

	struct TArray<struct FString> GetTargetLODNamesFunc(); // Function MeshModelingToolsExp.TransferMeshToolProperties.GetTargetLODNamesFunc // (Final|Native|Public|Const) // @ game+0x96c3720
	struct TArray<struct FString> GetSourceLODNamesFunc(); // Function MeshModelingToolsExp.TransferMeshToolProperties.GetSourceLODNamesFunc // (Final|Native|Public|Const) // @ game+0x9592b50
};

// Class MeshModelingToolsExp.TransferMeshTool
// Size: 0x140 (Inherited: 0x130)
struct UTransferMeshTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UTransferMeshToolProperties* BasicProperties; // 0x138(0x08)
};

// Class MeshModelingToolsExp.TransformMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UTransformMeshesToolBuilder : UMultiSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.TransformMeshesToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UTransformMeshesToolProperties : UInteractiveToolPropertySet {
	enum class ETransformMeshesTransformMode TransformMode; // 0x118(0x01)
	bool bApplyToInstances; // 0x119(0x01)
	bool bSetPivotMode; // 0x11a(0x01)
	bool bEnableSnapDragging; // 0x11b(0x01)
	enum class ETransformMeshesSnapDragSource SnapDragSource; // 0x11c(0x01)
	enum class ETransformMeshesSnapDragRotationMode RotationMode; // 0x11d(0x01)
	bool bHaveInstances; // 0x11e(0x01)
};

// Class MeshModelingToolsExp.TransformMeshesTool
// Size: 0x210 (Inherited: 0x130)
struct UTransformMeshesTool : UMultiSelectionMeshEditingTool {
	char pad_130[0x8]; // 0x130(0x08)
	struct UTransformMeshesToolProperties* TransformProps; // 0x138(0x08)
	struct TArray<struct FTransformMeshesTarget> ActiveGizmos; // 0x140(0x10)
	struct UDragAlignmentMechanic* DragAlignmentMechanic; // 0x150(0x08)
	char pad_158[0xb8]; // 0x158(0xb8)
};

// Class MeshModelingToolsExp.TriangulateSplinesToolProperties
// Size: 0x150 (Inherited: 0x120)
struct UTriangulateSplinesToolProperties : UInteractiveToolPropertySet {
	double ErrorTolerance; // 0x118(0x08)
	enum class EFlattenCurveMethod FlattenMethod; // 0x120(0x01)
	enum class ECombineCurvesMethod CombineMethod; // 0x121(0x01)
	double Thickness; // 0x128(0x08)
	bool bFlipResult; // 0x130(0x01)
	enum class EOffsetOpenCurvesMethod OpenCurves; // 0x131(0x01)
	char pad_134[0x4]; // 0x134(0x04)
	double CurveOffset; // 0x138(0x08)
	enum class EOffsetClosedCurvesMethod OffsetClosedCurves; // 0x140(0x01)
	enum class EOpenCurveEndShapes EndShapes; // 0x141(0x01)
	enum class EOffsetJoinMethod JoinMethod; // 0x142(0x01)
	char pad_143[0x5]; // 0x143(0x05)
	double MiterLimit; // 0x148(0x08)
};

// Class MeshModelingToolsExp.TriangulateSplinesTool
// Size: 0x170 (Inherited: 0x110)
struct UTriangulateSplinesTool : UInteractiveTool {
	char pad_110[0x10]; // 0x110(0x10)
	struct UTriangulateSplinesToolProperties* TriangulateProperties; // 0x120(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x128(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* Preview; // 0x130(0x08)
	struct TWeakObjectPtr<struct UWorld> TargetWorld; // 0x138(0x08)
	struct TArray<struct TWeakObjectPtr<struct AActor>> ActorsWithSplines; // 0x140(0x10)
	char pad_150[0x20]; // 0x150(0x20)
};

// Class MeshModelingToolsExp.TriangulateSplinesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UTriangulateSplinesToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingToolsExp.VolumeToMeshToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UVolumeToMeshToolBuilder : UInteractiveToolBuilder {
};

// Class MeshModelingToolsExp.VolumeToMeshToolProperties
// Size: 0x120 (Inherited: 0x120)
struct UVolumeToMeshToolProperties : UInteractiveToolPropertySet {
	bool bWeldEdges; // 0x118(0x01)
	bool bAutoRepair; // 0x119(0x01)
	bool bOptimizeMesh; // 0x11a(0x01)
	bool bShowWireframe; // 0x11b(0x01)
};

// Class MeshModelingToolsExp.VolumeToMeshTool
// Size: 0x380 (Inherited: 0x110)
struct UVolumeToMeshTool : UInteractiveTool {
	struct UVolumeToMeshToolProperties* Settings; // 0x110(0x08)
	struct UCreateMeshObjectTypeProperties* OutputTypeProperties; // 0x118(0x08)
	struct UPreviewMesh* PreviewMesh; // 0x120(0x08)
	LazyObjectProperty TargetVolume; // 0x128(0x18)
	struct ULineSetComponent* VolumeEdgesSet; // 0x140(0x08)
	char pad_148[0x238]; // 0x148(0x238)
};

// Class MeshModelingToolsExp.VoxelBlendMeshesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UVoxelBlendMeshesToolProperties : UInteractiveToolPropertySet {
	double BlendPower; // 0x118(0x08)
	double BlendFalloff; // 0x120(0x08)
	enum class EVoxelBlendOperation Operation; // 0x128(0x01)
	bool bVoxWrap; // 0x129(0x01)
	bool bRemoveInternalsAfterVoxWrap; // 0x12a(0x01)
	double ThickenShells; // 0x130(0x08)
	char pad_13b[0x5]; // 0x13b(0x05)
};

// Class MeshModelingToolsExp.VoxelBlendMeshesTool
// Size: 0x1a0 (Inherited: 0x190)
struct UVoxelBlendMeshesTool : UBaseVoxelTool {
	struct UVoxelBlendMeshesToolProperties* BlendProperties; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class MeshModelingToolsExp.VoxelBlendMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UVoxelBlendMeshesToolBuilder : UBaseCreateFromSelectedToolBuilder {
};

// Class MeshModelingToolsExp.VoxelMorphologyMeshesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UVoxelMorphologyMeshesToolProperties : UInteractiveToolPropertySet {
	enum class EMorphologyOperation Operation; // 0x118(0x01)
	double Distance; // 0x120(0x08)
	bool bVoxWrap; // 0x128(0x01)
	bool bRemoveInternalsAfterVoxWrap; // 0x129(0x01)
	char pad_12b[0x5]; // 0x12b(0x05)
	double ThickenShells; // 0x130(0x08)
	char pad_138[0x8]; // 0x138(0x08)
};

// Class MeshModelingToolsExp.VoxelMorphologyMeshesTool
// Size: 0x1a0 (Inherited: 0x190)
struct UVoxelMorphologyMeshesTool : UBaseVoxelTool {
	struct UVoxelMorphologyMeshesToolProperties* MorphologyProperties; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class MeshModelingToolsExp.VoxelMorphologyMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UVoxelMorphologyMeshesToolBuilder : UBaseCreateFromSelectedToolBuilder {
};

// Class MeshModelingToolsExp.VoxelSolidifyMeshesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UVoxelSolidifyMeshesToolProperties : UInteractiveToolPropertySet {
	double WindingThreshold; // 0x118(0x08)
	double ExtendBounds; // 0x120(0x08)
	int32_t SurfaceSearchSteps; // 0x128(0x04)
	bool bSolidAtBoundaries; // 0x12c(0x01)
	bool bApplyThickenShells; // 0x12d(0x01)
	double ThickenShells; // 0x130(0x08)
	char pad_13e[0x2]; // 0x13e(0x02)
};

// Class MeshModelingToolsExp.VoxelSolidifyMeshesTool
// Size: 0x1a0 (Inherited: 0x190)
struct UVoxelSolidifyMeshesTool : UBaseVoxelTool {
	struct UVoxelSolidifyMeshesToolProperties* SolidifyProperties; // 0x190(0x08)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class MeshModelingToolsExp.VoxelSolidifyMeshesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UVoxelSolidifyMeshesToolBuilder : UBaseCreateFromSelectedToolBuilder {
};

// Class MeshModelingToolsExp.WeldMeshEdgesToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UWeldMeshEdgesToolBuilder : USingleSelectionMeshEditingToolBuilder {
};

// Class MeshModelingToolsExp.WeldMeshEdgesToolProperties
// Size: 0x140 (Inherited: 0x120)
struct UWeldMeshEdgesToolProperties : UInteractiveToolPropertySet {
	float Tolerance; // 0x118(0x04)
	bool bOnlyUnique; // 0x11c(0x01)
	bool bResolveTJunctions; // 0x11d(0x01)
	int32_t InitialEdges; // 0x120(0x04)
	int32_t RemainingEdges; // 0x124(0x04)
	enum class EWeldMeshEdgesAttributeUIMode AttrWeldingMode; // 0x128(0x01)
	float SplitNormalThreshold; // 0x12c(0x04)
	float SplitTangentsThreshold; // 0x130(0x04)
	float SplitUVThreshold; // 0x134(0x04)
	float SplitColorThreshold; // 0x138(0x04)
	char pad_13f[0x1]; // 0x13f(0x01)
};

// Class MeshModelingToolsExp.WeldMeshEdgesOperatorFactory
// Size: 0xb0 (Inherited: 0xa0)
struct UWeldMeshEdgesOperatorFactory : UObject {
	struct UWeldMeshEdgesTool* WeldMeshEdgesTool; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MeshModelingToolsExp.WeldMeshEdgesTool
// Size: 0x160 (Inherited: 0x130)
struct UWeldMeshEdgesTool : USingleSelectionMeshEditingTool {
	struct UWeldMeshEdgesToolProperties* Settings; // 0x130(0x08)
	struct UMeshOpPreviewWithBackgroundCompute* PreviewCompute; // 0x138(0x08)
	struct UMeshElementsVisualizer* MeshElementsDisplay; // 0x140(0x08)
	struct UWeldMeshEdgesOperatorFactory* OperatorFactory; // 0x148(0x08)
	char pad_150[0x10]; // 0x150(0x10)
};

