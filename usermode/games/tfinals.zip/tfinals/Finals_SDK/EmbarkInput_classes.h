// Class EmbarkInput.EmbarkAnalogCursorSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkAnalogCursorSubsystem : ULocalPlayerSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)

	struct UEmbarkAnalogCursorSubsystem* Get(struct ULocalPlayer* LocalPlayer); // Function EmbarkInput.EmbarkAnalogCursorSubsystem.Get // (Final|Native|Static|Public) // @ game+0x5a6c1f0
	void EnableAnalogCursor(bool bIsEnabled); // Function EmbarkInput.EmbarkAnalogCursorSubsystem.EnableAnalogCursor // (Final|Native|Public) // @ game+0x5a68a40
};

// Class EmbarkInput.EmbarkInputUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkInputUtils : UBlueprintFunctionLibrary {

	void RequestInputRebuildWithFlush(struct ULocalPlayer* LocalPlayer); // Function EmbarkInput.EmbarkInputUtils.RequestInputRebuildWithFlush // (Final|Native|Static|Public) // @ game+0x5a74d30
	void RemoveMappingContextFromLocalPlayer(struct UInputMappingContext* MappingContext, struct ULocalPlayer* LocalPlayer, struct FModifyContextOptions& Options); // Function EmbarkInput.EmbarkInputUtils.RemoveMappingContextFromLocalPlayer // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a75000
	enum class EEmbarkInputDevice PlatformDefaultInputDevice(); // Function EmbarkInput.EmbarkInputUtils.PlatformDefaultInputDevice // (Final|Native|Static|Public) // @ game+0x5a68e90
	bool IsEnhancedInputEnabledForCommonUI(); // Function EmbarkInput.EmbarkInputUtils.IsEnhancedInputEnabledForCommonUI // (Final|Native|Static|Public) // @ game+0x5a6cb30
	struct FName GetSupportedKeyboardLayout(); // Function EmbarkInput.EmbarkInputUtils.GetSupportedKeyboardLayout // (Final|Native|Static|Public) // @ game+0x5a67940
	enum class EUINavigation GetNavigationDirectionFromKey(struct FKeyEvent& InKeyEvent); // Function EmbarkInput.EmbarkInputUtils.GetNavigationDirectionFromKey // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a682a0
	enum class EUINavigation GetNavigationDirectionFromAnalog(struct FAnalogInputEvent& InAnalogEvent); // Function EmbarkInput.EmbarkInputUtils.GetNavigationDirectionFromAnalog // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a679a0
	enum class EUINavigationAction GetNavigationActionFromKey(struct FKeyEvent& InKeyEvent); // Function EmbarkInput.EmbarkInputUtils.GetNavigationActionFromKey // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a6ce70
	void AddMappingContextToLocalPlayer(struct UInputMappingContext* MappingContext, struct ULocalPlayer* LocalPlayer, int32_t Priority, struct FModifyContextOptions& Options); // Function EmbarkInput.EmbarkInputUtils.AddMappingContextToLocalPlayer // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a67ac0
};

// Class EmbarkInput.InputComponentPoolSubsystem
// Size: 0x140 (Inherited: 0x140)
struct UInputComponentPoolSubsystem : UEmbarkObjectPoolSubsystem {

	bool PoolInputComponent(struct UInputComponent* InputComponent); // Function EmbarkInput.InputComponentPoolSubsystem.PoolInputComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5a6ccc0
	struct UInputComponent* NextOrCreateInputComponent(); // Function EmbarkInput.InputComponentPoolSubsystem.NextOrCreateInputComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5a696c0
};

// Class EmbarkInput.EmbarkInputDebuggerSubsystem
// Size: 0x160 (Inherited: 0xa0)
struct UEmbarkInputDebuggerSubsystem : ULocalPlayerSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TArray<struct FInputActionRecordedState> PlayerTrackedPersistentData; // 0xa8(0x10)
	struct TArray<struct FInputActionRecordedState> PlayerTrackedDataToBeLogged; // 0xb8(0x10)
	struct TArray<struct FInputAxisRecordedState> AxisTrackedPersistentData; // 0xc8(0x10)
	struct TArray<struct FInputAxisRecordedState> AxisTrackedDataToBeLogged; // 0xd8(0x10)
	struct TArray<struct FInputErrorRecord> InputErrors; // 0xe8(0x10)
	struct TArray<struct FActionRouterStateChangeEvent> ActionRouterStateChanges; // 0xf8(0x10)
	char pad_108[0x58]; // 0x108(0x58)

	void SetSlateInputRouterDebuggerEnabled(bool bInIsEnabled); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.SetSlateInputRouterDebuggerEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5a66180
	void SetInputTrackingMode(enum class EPlayerInputTrackingInputMode InTrackingMode); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.SetInputTrackingMode // (Final|Native|Public|BlueprintCallable) // @ game+0x5a73120
	void SetInputLoggingEnabled(bool bEnabled); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.SetInputLoggingEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x5a6a8f0
	void LogStoredInputDebugState(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.LogStoredInputDebugState // (Final|Native|Public|BlueprintCallable) // @ game+0x5a6aa40
	bool IsSlateInputRouterDebuggerEnabled(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.IsSlateInputRouterDebuggerEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a66070
	bool IsInputLoggingEnabled(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.IsInputLoggingEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a69810
	struct TArray<struct FInputActionRecordedState> GetTrackedInputData(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetTrackedInputData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a663b0
	struct TArray<struct FInputAxisRecordedState> GetTrackedAxisInputData(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetTrackedAxisInputData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a6f890
	struct TArray<struct FEmbarkInputRoutingEventData> GetRecentRoutingEventsByType(enum class ESlateDebuggingInputEvent EventType); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetRecentRoutingEventsByType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a70cd0
	enum class EPlayerInputTrackingInputMode GetPlayerTrackingMode(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetPlayerTrackingMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a69ba0
	struct TArray<struct FInputErrorRecord> GetInputErrors(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetInputErrors // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a6fdb0
	struct TArray<enum class ESlateDebuggingInputEvent> GetAvailableRoutingEventTypes(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetAvailableRoutingEventTypes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3389d20
	struct TArray<struct FActionRouterStateChangeEvent> GetActionRouterStateChanges(); // Function EmbarkInput.EmbarkInputDebuggerSubsystem.GetActionRouterStateChanges // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a66c30
};

// Class EmbarkInput.EmbarkModifierKeysStateWrapper
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkModifierKeysStateWrapper : UObject {

	bool IsShiftDown(); // Function EmbarkInput.EmbarkModifierKeysStateWrapper.IsShiftDown // (Final|Native|Public|Const) // @ game+0x5a6c020
	bool IsCtrlDown(); // Function EmbarkInput.EmbarkModifierKeysStateWrapper.IsCtrlDown // (Final|Native|Public|Const) // @ game+0x5a730c0
	bool IsAltDown(); // Function EmbarkInput.EmbarkModifierKeysStateWrapper.IsAltDown // (Final|Native|Public|Const) // @ game+0x5a6b000
	void FetchCurrentState(); // Function EmbarkInput.EmbarkModifierKeysStateWrapper.FetchCurrentState // (Final|Native|Public) // @ game+0x5a6a6f0
};

// Class EmbarkInput.EmbarkInputSubsystem
// Size: 0xe0 (Inherited: 0xa0)
struct UEmbarkInputSubsystem : ULocalPlayerSubsystem {
	char pad_a0[0x18]; // 0xa0(0x18)
	struct FMulticastInlineDelegate OnInputDeviceChanged; // 0xb8(0x10)
	char pad_c8[0x18]; // 0xc8(0x18)

	bool IsUsingGamepad(); // Function EmbarkInput.EmbarkInputSubsystem.IsUsingGamepad // (Final|Native|Public|Const) // @ game+0x5a6ae60
	bool IsMouseAndKeyboard(); // Function EmbarkInput.EmbarkInputSubsystem.IsMouseAndKeyboard // (Final|Native|Public|Const) // @ game+0x5a69b80
	struct UEmbarkModifierKeysStateWrapper* GetModifierKeys(); // Function EmbarkInput.EmbarkInputSubsystem.GetModifierKeys // (Final|Native|Public|Const) // @ game+0x5a6a390
	enum class EEmbarkInputDevice GetCurrentInputDevice(); // Function EmbarkInput.EmbarkInputSubsystem.GetCurrentInputDevice // (Final|Native|Public|Const) // @ game+0x5a6c080
};

// Class EmbarkInput.EmbarkLocalPlayerInputSubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UEmbarkLocalPlayerInputSubsystem : ULocalPlayerSubsystem {
	struct TArray<struct UInputMappingContext*> InputMappingContexts; // 0xa0(0x10)
	struct TMap<struct FName, struct UInputAction*> InputActions; // 0xb0(0x50)

	void RedirectKeysForKeyboardLayout(struct FName& KeyboardLayout); // Function EmbarkInput.EmbarkLocalPlayerInputSubsystem.RedirectKeysForKeyboardLayout // (Final|Native|Public|HasOutParms) // @ game+0x5a74690
	struct UInputAction* FindInputActionWithName(struct FName& InInputActionName); // Function EmbarkInput.EmbarkLocalPlayerInputSubsystem.FindInputActionWithName // (Final|Native|Public|HasOutParms) // @ game+0x5a6fef0
};

// Class EmbarkInput.EmbarkPlayerMappableSettings
// Size: 0x110 (Inherited: 0x100)
struct UEmbarkPlayerMappableSettings : UPlayerMappableKeySettings {
	struct FText HintTextOverride; // 0xf8(0x18)
};

// Class EmbarkInput.KeyboardRedirectSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UKeyboardRedirectSettings : UDeveloperSettings {
	struct TArray<struct FLocalizedKeyboardRedirect> LocalizedKeyboards; // 0xa8(0x10)

	bool GetKeyboardRedirectsForKeyboardLayout(struct FName& KeyboardLayout, struct FLocalizedKeyboardRedirect& OutKeyboardRedirect); // Function EmbarkInput.KeyboardRedirectSettings.GetKeyboardRedirectsForKeyboardLayout // (Final|Native|Public|HasOutParms|Const) // @ game+0x5a66a20
	struct TArray<struct FName> GetKeyboardLayouts(); // Function EmbarkInput.KeyboardRedirectSettings.GetKeyboardLayouts // (Final|Native|Static|Public) // @ game+0x5a73270
};

