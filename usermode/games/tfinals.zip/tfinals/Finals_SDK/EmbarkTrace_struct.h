// Enum EmbarkTrace.EQueryResult
enum class EQueryResult : uint8_t {
	GQB_Failed = 0,
	GQB_Miss = 1,
	GQB_Success = 2,
	GQB_MAX = 3
};

// ScriptStruct EmbarkTrace.EmbarkTraceLineSeg
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkTraceLineSeg {
	struct FVector Start; // 0x00(0x18)
	struct FVector End; // 0x18(0x18)
};

// ScriptStruct EmbarkTrace.RayHitSimple
// Size: 0x50 (Inherited: 0x00)
struct FRayHitSimple {
	struct FVector Location; // 0x00(0x18)
	struct FVector CacheLocation; // 0x18(0x18)
	struct FVector Normal; // 0x30(0x18)
	bool bIsHit; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

