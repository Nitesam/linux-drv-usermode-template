// ScriptStruct EmbarkDynamics.SecondOrderDynamicParameters
// Size: 0x0c (Inherited: 0x00)
struct FSecondOrderDynamicParameters {
	float Frequency; // 0x00(0x04)
	float Damping; // 0x04(0x04)
	float Response; // 0x08(0x04)
};

// ScriptStruct EmbarkDynamics.ConeParameters
// Size: 0x28 (Inherited: 0x00)
struct FConeParameters {
	float Angle; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector Direction; // 0x08(0x18)
	bool bIsLocalToOrigin; // 0x20(0x01)
	bool bIsSoftConstraint; // 0x21(0x01)
	char pad_22[0x2]; // 0x22(0x02)
	float SoftConstrainTime; // 0x24(0x04)
};

// ScriptStruct EmbarkDynamics.EulerIntegrationParameters
// Size: 0x40 (Inherited: 0x00)
struct FEulerIntegrationParameters {
	float Damping; // 0x00(0x04)
	float Mass; // 0x04(0x04)
	struct FVector Gravity; // 0x08(0x18)
	struct FVector Tension; // 0x20(0x18)
	bool bTensionIsLocalToOrigin; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkDynamics.EmbarkDynamicsBoxCollider
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkDynamicsBoxCollider {
	struct FTransform Offset; // 0x00(0x60)
	bool bIsLocalToOrigin; // 0x60(0x01)
	char pad_61[0x1f]; // 0x61(0x1f)
};

// ScriptStruct EmbarkDynamics.EmbarkDynamicsConeCollider
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkDynamicsConeCollider {
	float Angle; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector Direction; // 0x08(0x18)
	bool bIsLocalToOrigin; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EmbarkDynamics.EmbarkDynamicsSphereCollider
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkDynamicsSphereCollider {
	struct FVector Center; // 0x00(0x18)
	float Radius; // 0x18(0x04)
	bool bIsLocalToOrigin; // 0x1c(0x01)
	char pad_1d[0x3]; // 0x1d(0x03)
};

// ScriptStruct EmbarkDynamics.EmbarkDynamicsCapsuleCollider
// Size: 0x38 (Inherited: 0x00)
struct FEmbarkDynamicsCapsuleCollider {
	struct FVector base; // 0x00(0x18)
	struct FVector Tip; // 0x18(0x18)
	float Radius; // 0x30(0x04)
	bool bIsLocalToOrigin; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct EmbarkDynamics.SpringPlot
// Size: 0x2e0 (Inherited: 0x00)
struct FSpringPlot {
	char pad_0[0x2e0]; // 0x00(0x2e0)
};

// ScriptStruct EmbarkDynamics.SODSpringPlotInterface
// Size: 0x28 (Inherited: 0x00)
struct FSODSpringPlotInterface {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct EmbarkDynamics.EmbarkPBDParticleSystemSettings
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkPBDParticleSystemSettings {
	bool bUseFixedTimeSteps; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVector3f Gravity; // 0x04(0x0c)
};

// ScriptStruct EmbarkDynamics.SIEPendulumTransform
// Size: 0x180 (Inherited: 0x00)
struct FSIEPendulumTransform {
	struct FTransform Result; // 0x00(0x60)
	struct FVector Velocity; // 0x60(0x18)
	struct FVector Acceleration; // 0x78(0x18)
	char pad_90[0xf0]; // 0x90(0xf0)
};

// ScriptStruct EmbarkDynamics.SIEPendulumChainTransforms
// Size: 0x140 (Inherited: 0x00)
struct FSIEPendulumChainTransforms {
	struct TArray<struct FTransform> Transforms; // 0x00(0x10)
	char pad_10[0x130]; // 0x10(0x130)
};

// ScriptStruct EmbarkDynamics.EmbarkPendulumParams
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkPendulumParams {
	float Damping; // 0x00(0x04)
	float Mass; // 0x04(0x04)
	struct FVector Gravity; // 0x08(0x18)
	struct FVector Tension; // 0x20(0x18)
	bool bTensionIsLocalToOrigin; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct EmbarkDynamics.EmbarkPendulum
// Size: 0x200 (Inherited: 0x00)
struct FEmbarkPendulum {
	struct FVector PrimitiveBoxDimentions; // 0x00(0x18)
	struct FRotator PrimitiveBoxOrientation; // 0x18(0x18)
	float PrimitiveRadius; // 0x30(0x04)
	float PrimitiveLength; // 0x34(0x04)
	float PendulumLength; // 0x38(0x04)
	int32_t MinimumIterationsPerSecond; // 0x3c(0x04)
	int32_t MaximumCollisionSubstepsPerIteration; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct FEmbarkPendulumParams PendulumParams; // 0x48(0x40)
	struct TArray<struct FEmbarkDynamicsConeCollider> ConeColliders; // 0x88(0x10)
	struct TArray<struct FEmbarkDynamicsBoxCollider> BoxColliders; // 0x98(0x10)
	struct TArray<struct FEmbarkDynamicsSphereCollider> SphereColliders; // 0xa8(0x10)
	struct TArray<struct FEmbarkDynamicsCapsuleCollider> CapsuleColliders; // 0xb8(0x10)
	char pad_c8[0x138]; // 0xc8(0x138)
};

// ScriptStruct EmbarkDynamics.SimpleExactDamper
// Size: 0x14 (Inherited: 0x00)
struct FSimpleExactDamper {
	float Target; // 0x00(0x04)
	float Value; // 0x04(0x04)
	float Velocity; // 0x08(0x04)
	float HalfLife; // 0x0c(0x04)
	float HalfDamping; // 0x10(0x04)
};

// ScriptStruct EmbarkDynamics.DoubleExactDamper
// Size: 0x28 (Inherited: 0x00)
struct FDoubleExactDamper {
	struct FSimpleExactDamper Damper1; // 0x00(0x14)
	struct FSimpleExactDamper Damper2; // 0x14(0x14)
};

// ScriptStruct EmbarkDynamics.DoubleExactDamperVec
// Size: 0x78 (Inherited: 0x00)
struct FDoubleExactDamperVec {
	struct FDoubleExactDamper X; // 0x00(0x28)
	struct FDoubleExactDamper Y; // 0x28(0x28)
	struct FDoubleExactDamper Z; // 0x50(0x28)
};

// ScriptStruct EmbarkDynamics.SODSpringFloat
// Size: 0x34 (Inherited: 0x00)
struct FSODSpringFloat {
	float Value; // 0x00(0x04)
	float Velocity; // 0x04(0x04)
	float Acceleration; // 0x08(0x04)
	char pad_c[0x28]; // 0x0c(0x28)
};

// ScriptStruct EmbarkDynamics.SODSpringVector
// Size: 0x88 (Inherited: 0x00)
struct FSODSpringVector {
	struct FVector Value; // 0x00(0x18)
	struct FVector Velocity; // 0x18(0x18)
	struct FVector Acceleration; // 0x30(0x18)
	char pad_48[0x40]; // 0x48(0x40)
};

// ScriptStruct EmbarkDynamics.MinJerk
// Size: 0xd0 (Inherited: 0x00)
struct FMinJerk {
	double Target; // 0x00(0x08)
	double Value; // 0x08(0x08)
	double Speed; // 0x10(0x08)
	double Accel; // 0x18(0x08)
	char pad_20[0xb0]; // 0x20(0xb0)
};

// ScriptStruct EmbarkDynamics.MinJerkVec
// Size: 0x270 (Inherited: 0x00)
struct FMinJerkVec {
	struct FMinJerk MinJerkX; // 0x00(0xd0)
	struct FMinJerk MinJerkY; // 0xd0(0xd0)
	struct FMinJerk MinJerkZ; // 0x1a0(0xd0)
};

// ScriptStruct EmbarkDynamics.MinJerkVec2D
// Size: 0x1a0 (Inherited: 0x00)
struct FMinJerkVec2D {
	struct FMinJerk MinJerkX; // 0x00(0xd0)
	struct FMinJerk MinJerkY; // 0xd0(0xd0)
};

// ScriptStruct EmbarkDynamics.SimpleSpringDamperSettings
// Size: 0x48 (Inherited: 0x00)
struct FSimpleSpringDamperSettings {
	struct FVector2D ValueClamp; // 0x00(0x10)
	struct FVector2D ValueWrap; // 0x10(0x10)
	struct FVector2D CriticalStretchLimits; // 0x20(0x10)
	float Stiffness; // 0x30(0x04)
	float Damping; // 0x34(0x04)
	float CriticalStretchTransitionSize; // 0x38(0x04)
	float CriticalStretchStiffness; // 0x3c(0x04)
	float CriticalStretchDamping; // 0x40(0x04)
	bool bUseValueWrap; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
};

// ScriptStruct EmbarkDynamics.SimpleSpringDamper
// Size: 0x58 (Inherited: 0x00)
struct FSimpleSpringDamper {
	float Target; // 0x00(0x04)
	float Value; // 0x04(0x04)
	float Velocity; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FSimpleSpringDamperSettings Settings; // 0x10(0x48)
};

// ScriptStruct EmbarkDynamics.SimpleSpringDamperVector
// Size: 0x108 (Inherited: 0x00)
struct FSimpleSpringDamperVector {
	struct FSimpleSpringDamper X; // 0x00(0x58)
	struct FSimpleSpringDamper Y; // 0x58(0x58)
	struct FSimpleSpringDamper Z; // 0xb0(0x58)
};

// ScriptStruct EmbarkDynamics.EmbarkCtrlRigPBD_Particle
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkCtrlRigPBD_Particle {
	struct FVector AnimatedLocation; // 0x00(0x18)
	bool bIsDynamic; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float MaxDistance; // 0x1c(0x04)
	float Mass; // 0x20(0x04)
	float ExtraDamping; // 0x24(0x04)
	struct FVector ExternalForce; // 0x28(0x18)
};

// ScriptStruct EmbarkDynamics.EmbarkCtrlRigPBD_Link
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkCtrlRigPBD_Link {
	float DistanceMultiplier; // 0x00(0x04)
	float PushingStiffness; // 0x04(0x04)
	float PullingStiffness; // 0x08(0x04)
	int32_t ParticleIndexA; // 0x0c(0x04)
	int32_t ParticleIndexB; // 0x10(0x04)
};

// ScriptStruct EmbarkDynamics.EmbarkCtrlRigPBD_Sphere
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkCtrlRigPBD_Sphere {
	int32_t FirstParticleRangeIndex; // 0x00(0x04)
	int32_t LastParticleRangeIndex; // 0x04(0x04)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform Transform; // 0x10(0x60)
	float PushingFriction; // 0x70(0x04)
	float PullingFriction; // 0x74(0x04)
	float PushingStiffness; // 0x78(0x04)
	float PullingStiffness; // 0x7c(0x04)
};

// ScriptStruct EmbarkDynamics.EmbarkCtrlRigPBD_Plane
// Size: 0x80 (Inherited: 0x00)
struct FEmbarkCtrlRigPBD_Plane {
	int32_t FirstParticleRangeIndex; // 0x00(0x04)
	int32_t LastParticleRangeIndex; // 0x04(0x04)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform Transform; // 0x10(0x60)
	float PushingFriction; // 0x70(0x04)
	float PullingFriction; // 0x74(0x04)
	float PushingStiffness; // 0x78(0x04)
	float PullingStiffness; // 0x7c(0x04)
};

// ScriptStruct EmbarkDynamics.EmbarkCtrlRigPBD_ThreeParticlePlane
// Size: 0x1c (Inherited: 0x00)
struct FEmbarkCtrlRigPBD_ThreeParticlePlane {
	int32_t FirstParticleRangeIndex; // 0x00(0x04)
	int32_t LastParticleRangeIndex; // 0x04(0x04)
	int32_t A; // 0x08(0x04)
	int32_t B; // 0x0c(0x04)
	int32_t C; // 0x10(0x04)
	float PushingStiffness; // 0x14(0x04)
	float PullingStiffness; // 0x18(0x04)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkPBDSolver
// Size: 0x300 (Inherited: 0x160)
struct FRigUnit_EmbarkPBDSolver : FRigUnit_HighlevelBaseMutable {
	struct TArray<struct FEmbarkCtrlRigPBD_Particle> Particles; // 0x160(0x10)
	int32_t SolveStepsPerSecond; // 0x170(0x04)
	bool bShouldResetNextUpdate; // 0x174(0x01)
	bool bIsSimulatedInWorldSpace; // 0x175(0x01)
	bool bUseWorldGravityZ; // 0x176(0x01)
	char pad_177[0x1]; // 0x177(0x01)
	struct FVector AdditionalGravity; // 0x178(0x18)
	struct FVector GlobalExternalForce; // 0x190(0x18)
	float GlobalDamping; // 0x1a8(0x04)
	char pad_1ac[0x4]; // 0x1ac(0x04)
	struct TArray<struct FVector> ParticleLocations; // 0x1b0(0x10)
	struct TArray<struct FVector> PrevParticleLocations; // 0x1c0(0x10)
	struct TArray<struct FVector> ParticleVelocities; // 0x1d0(0x10)
	struct TArray<struct FVector> SimSpaceAnimLocations; // 0x1e0(0x10)
	struct TArray<struct FVector> InterpAnimLocations; // 0x1f0(0x10)
	struct TArray<struct FVector> PrevInterpAnimLocations; // 0x200(0x10)
	struct TArray<struct FEmbarkCtrlRigPBD_Link> Links; // 0x210(0x10)
	struct TArray<float> LinkDistances; // 0x220(0x10)
	struct TArray<struct FEmbarkCtrlRigPBD_Sphere> Spheres; // 0x230(0x10)
	struct TArray<struct FTransform> SimSpaceSphereTransforms; // 0x240(0x10)
	struct TArray<struct FTransform> InterpSphereTransforms; // 0x250(0x10)
	struct TArray<struct FTransform> PrevInterpSphereTransforms; // 0x260(0x10)
	struct TArray<struct FEmbarkCtrlRigPBD_Plane> Planes; // 0x270(0x10)
	struct TArray<struct FTransform> SimSpacePlaneTransforms; // 0x280(0x10)
	struct TArray<struct FTransform> InterpPlaneTransforms; // 0x290(0x10)
	struct TArray<struct FTransform> PrevInterpPlaneTransforms; // 0x2a0(0x10)
	struct TArray<struct FEmbarkCtrlRigPBD_ThreeParticlePlane> ThreeParticlePlanes; // 0x2b0(0x10)
	bool bDebugDrawing; // 0x2c0(0x01)
	bool bDrawParticleLocations; // 0x2c1(0x01)
	char pad_2c2[0x2]; // 0x2c2(0x02)
	float ParticleDrawingSize; // 0x2c4(0x04)
	float ParticleDrawingThickness; // 0x2c8(0x04)
	bool bDrawMaxDistanceConstraint; // 0x2cc(0x01)
	bool bDrawLinks; // 0x2cd(0x01)
	bool bDrawSpheres; // 0x2ce(0x01)
	bool bDrawPlanes; // 0x2cf(0x01)
	bool bDrawThreeParticlePlanes; // 0x2d0(0x01)
	char pad_2d1[0x3]; // 0x2d1(0x03)
	float TimeStepLength; // 0x2d4(0x04)
	float RemainingTime; // 0x2d8(0x04)
	int32_t NumTimeStepsThisUpdate; // 0x2dc(0x04)
	int32_t CurrentTimeStep; // 0x2e0(0x04)
	bool bIsInitialized; // 0x2e4(0x01)
	char pad_2e5[0x3]; // 0x2e5(0x03)
	struct TArray<struct FVector> ResultLocations; // 0x2e8(0x10)
	char pad_2f8[0x8]; // 0x2f8(0x08)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkPendulumItem
// Size: 0x4b0 (Inherited: 0x160)
struct FRigUnit_EmbarkPendulumItem : FRigUnit_HighlevelBaseMutable {
	struct FTransform CharacterWorld; // 0x160(0x60)
	float WorldInfluence; // 0x1c0(0x04)
	int32_t MinimumIterations; // 0x1c4(0x04)
	float Length; // 0x1c8(0x04)
	char pad_1cc[0x4]; // 0x1cc(0x04)
	struct FEulerIntegrationParameters PhysicsParameters; // 0x1d0(0x40)
	struct TArray<struct FVector> ExternalForces; // 0x210(0x10)
	struct TArray<struct FConeParameters> ConeConstraints; // 0x220(0x10)
	bool bDebugDrawing; // 0x230(0x01)
	char pad_231[0x3]; // 0x231(0x03)
	struct FRigElementKey OriginItem; // 0x234(0x0c)
	struct FRigElementKey AlignmentItem; // 0x240(0x0c)
	struct FRigElementKey SimulatedItem; // 0x24c(0x0c)
	char pad_258[0x8]; // 0x258(0x08)
	struct FSIEPendulumTransform SimulationObject; // 0x260(0x180)
	struct FCachedRigElement CachedOriginItem; // 0x3e0(0x20)
	struct FCachedRigElement CachedAlignmentItem; // 0x400(0x20)
	struct FCachedRigElement CachedSimulatedItem; // 0x420(0x20)
	struct FTransform AlignmentToSimulatedCorrection; // 0x440(0x60)
	bool bIsInitialized; // 0x4a0(0x01)
	char pad_4a1[0xf]; // 0x4a1(0x0f)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkRigJiggler_Bone
// Size: 0x20 (Inherited: 0x00)
struct FRigUnit_EmbarkRigJiggler_Bone {
	struct FName Name; // 0x00(0x08)
	struct FVector WeightedAxes; // 0x08(0x18)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkRigJiggler_Section
// Size: 0x40 (Inherited: 0x00)
struct FRigUnit_EmbarkRigJiggler_Section {
	struct FVector Target; // 0x00(0x18)
	struct FSecondOrderDynamicParameters Parameters; // 0x18(0x0c)
	float Influence; // 0x24(0x04)
	int32_t LOD; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
	struct TArray<struct FRigUnit_EmbarkRigJiggler_Bone> JiggleBones; // 0x30(0x10)
};

// ScriptStruct EmbarkDynamics.RigUnit_BonesData
// Size: 0x50 (Inherited: 0x00)
struct FRigUnit_BonesData {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkRigJiggler
// Size: 0x260 (Inherited: 0x160)
struct FRigUnit_EmbarkRigJiggler : FRigUnit_HighlevelBaseMutable {
	int32_t CurrentLOD; // 0x160(0x04)
	bool bResetAll; // 0x164(0x01)
	char pad_165[0xb]; // 0x165(0x0b)
	struct FTransform SimulationRelativeSpace; // 0x170(0x60)
	struct TArray<struct FRigUnit_EmbarkRigJiggler_Section> Sections; // 0x1d0(0x10)
	struct FRigUnit_BonesData BonesData; // 0x1e0(0x50)
	bool bIsInitialized; // 0x230(0x01)
	char pad_231[0x7]; // 0x231(0x07)
	struct TArray<struct FSODSpringVector> Solvers; // 0x238(0x10)
	struct TArray<bool> SolversToReset; // 0x248(0x10)
	char pad_258[0x8]; // 0x258(0x08)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkSODFloat
// Size: 0x7a0 (Inherited: 0x160)
struct FRigUnit_EmbarkSODFloat : FRigUnit_HighlevelBaseMutable {
	float Target; // 0x160(0x04)
	struct FSecondOrderDynamicParameters Parameters; // 0x164(0x0c)
	struct FSODSpringFloat Result; // 0x170(0x34)
	char pad_1a4[0x4]; // 0x1a4(0x04)
	struct FSpringPlot InPlot; // 0x1a8(0x2e0)
	struct FSpringPlot OutPlot; // 0x488(0x2e0)
	struct FSODSpringPlotInterface PlotInterface; // 0x768(0x28)
	bool bNeedsInit; // 0x790(0x01)
	char pad_791[0xf]; // 0x791(0x0f)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkSODVector
// Size: 0x800 (Inherited: 0x160)
struct FRigUnit_EmbarkSODVector : FRigUnit_HighlevelBaseMutable {
	struct FVector Target; // 0x160(0x18)
	struct FSecondOrderDynamicParameters Parameters; // 0x178(0x0c)
	char pad_184[0x4]; // 0x184(0x04)
	struct FSODSpringVector Result; // 0x188(0x88)
	struct FSpringPlot InPlot; // 0x210(0x2e0)
	struct FSpringPlot OutPlot; // 0x4f0(0x2e0)
	struct FSODSpringPlotInterface PlotInterface; // 0x7d0(0x28)
	bool bNeedsInit; // 0x7f8(0x01)
	char pad_7f9[0x7]; // 0x7f9(0x07)
};

// ScriptStruct EmbarkDynamics.RigUnit_EmbarkSpringGraph
// Size: 0x490 (Inherited: 0x160)
struct FRigUnit_EmbarkSpringGraph : FRigUnit_HighlevelBaseMutable {
	struct FVector GraphOrigin; // 0x160(0x18)
	float FirstThickness; // 0x178(0x04)
	float LastThickness; // 0x17c(0x04)
	struct FLinearColor FirstColor; // 0x180(0x10)
	struct FLinearColor LastColor; // 0x190(0x10)
	float GraphSize; // 0x1a0(0x04)
	char pad_1a4[0x4]; // 0x1a4(0x04)
	struct FSpringPlot InPlot; // 0x1a8(0x2e0)
	char pad_488[0x8]; // 0x488(0x08)
};

