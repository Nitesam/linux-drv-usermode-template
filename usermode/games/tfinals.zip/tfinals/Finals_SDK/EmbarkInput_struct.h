// Enum EmbarkInput.EEmbarkInputDevice
enum class EEmbarkInputDevice : uint8_t {
	Unknown = 0,
	MouseAndKeyboard = 1,
	Gamepad = 2,
	EEmbarkInputDevice_MAX = 3
};

// Enum EmbarkInput.EPlayerInputTrackingInputMode
enum class EPlayerInputTrackingInputMode : uint8_t {
	None = 0,
	KeysOnly = 1,
	MouseOnly = 2,
	AxisOnly = 3,
	All = 4,
	EPlayerInputTrackingInputMode_MAX = 5
};

// Enum EmbarkInput.EInputRouterChangeType
enum class EInputRouterChangeType : uint8_t {
	None = 0,
	ActiveNode = 1,
	InputConfig = 2,
	ActiveNodeList = 3,
	ActiveNodesListItem = 4,
	InputIgnoreState = 5,
	EInputRouterChangeType_MAX = 6
};

// ScriptStruct EmbarkInput.ActionRouterStateChangeEvent
// Size: 0x70 (Inherited: 0x00)
struct FActionRouterStateChangeEvent {
	enum class EInputRouterChangeType ChangeType; // 0x00(0x01)
	enum class ECommonInputMode InputMode; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FCommonUIActionRouterRootNodeDebugEntry ActiveRootNode; // 0x08(0x20)
	struct FCommonUIActionRouterDebugData FullDebugData; // 0x28(0x38)
	struct FDateTime Timestamp; // 0x60(0x08)
	bool bIgnoreMoveInput; // 0x68(0x01)
	bool bIgnoreLookInput; // 0x69(0x01)
	char pad_6a[0x6]; // 0x6a(0x06)
};

// ScriptStruct EmbarkInput.EmbarkInputRoutingEventData
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkInputRoutingEventData {
	enum class ESlateDebuggingInputEvent EventType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Stage; // 0x08(0x10)
	struct FString Context; // 0x18(0x10)
	bool bHandled; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FDateTime Timestamp; // 0x30(0x08)
	int32_t HierarchyLevel; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
};

// ScriptStruct EmbarkInput.EmbarkInputRoutingEventCollection
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkInputRoutingEventCollection {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkInput.EnhancedInputHandles
// Size: 0x10 (Inherited: 0x00)
struct FEnhancedInputHandles {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkInput.EnhancedInputBindingsWrapper
// Size: 0x58 (Inherited: 0x00)
struct FEnhancedInputBindingsWrapper {
	struct TMap<struct UInputAction*, struct FEnhancedInputHandles> ActionHandles; // 0x00(0x50)
	char pad_50[0x8]; // 0x50(0x08)
};

// ScriptStruct EmbarkInput.KeyRedirect
// Size: 0x30 (Inherited: 0x00)
struct FKeyRedirect {
	struct FKey OriginalKey; // 0x00(0x18)
	struct FKey RedirectedKey; // 0x18(0x18)
};

// ScriptStruct EmbarkInput.LocalizedKeyboardRedirect
// Size: 0x18 (Inherited: 0x00)
struct FLocalizedKeyboardRedirect {
	struct FName KeyboardLayout; // 0x00(0x08)
	struct TArray<struct FKeyRedirect> KeyRedirects; // 0x08(0x10)
};

