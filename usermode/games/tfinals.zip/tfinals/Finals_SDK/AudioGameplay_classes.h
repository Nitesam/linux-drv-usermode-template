// Class AudioGameplay.AudioComponentGroupExtension
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioComponentGroupExtension : UInterface {
};

// Class AudioGameplay.AudioGameplayCondition
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioGameplayCondition : UInterface {

	bool ConditionMet_Position(struct FVector& Position); // Function AudioGameplay.AudioGameplayCondition.ConditionMet_Position // (RequiredAPI|Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x67db480
	bool ConditionMet(); // Function AudioGameplay.AudioGameplayCondition.ConditionMet // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x67d5010
};

// Class AudioGameplay.AudioGameplayVolumeInteraction
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioGameplayVolumeInteraction : UInterface {

	void OnListenerExit(); // Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x67d49e0
	void OnListenerEnter(); // Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x1520a60
};

// Class AudioGameplay.AudioComponentGroup
// Size: 0x570 (Inherited: 0x3c0)
struct UAudioComponentGroup : USceneComponent {
	char pad_3c0[0x8]; // 0x3c0(0x08)
	struct FMulticastInlineDelegate OnStopped; // 0x3c8(0x10)
	struct FMulticastInlineDelegate OnKilled; // 0x3d8(0x10)
	struct FMulticastInlineDelegate OnVirtualized; // 0x3e8(0x10)
	struct FMulticastInlineDelegate OnUnvirtualized; // 0x3f8(0x10)
	struct TArray<struct UAudioComponent*> Components; // 0x408(0x10)
	struct TArray<struct FAudioParameter> ParamsToSet; // 0x418(0x10)
	struct TArray<struct FAudioParameter> PersistentParams; // 0x428(0x10)
	struct TArray<struct TScriptInterface<IAudioComponentGroupExtension>> Extensions; // 0x438(0x10)
	char pad_448[0x128]; // 0x448(0x128)

	void UnsubscribeObject(struct UObject* Object); // Function AudioGameplay.AudioComponentGroup.UnsubscribeObject // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67da910
	void SubscribeToStringParam(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToStringParam // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d48e0
	void SubscribeToEvent(struct FName EventName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d7c40
	void SubscribeToBool(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToBool // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d5570
	void StopSound(struct USoundBase* Sound, float FadeTime); // Function AudioGameplay.AudioComponentGroup.StopSound // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67ddad0
	struct UAudioComponentGroup* StaticGetOrCreateComponentGroup(struct AActor* Actor); // Function AudioGameplay.AudioComponentGroup.StaticGetOrCreateComponentGroup // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0x67d6d70
	void SetVolumeMultiplier(float InVolume); // Function AudioGameplay.AudioComponentGroup.SetVolumeMultiplier // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d9c20
	void SetPitchMultiplier(float InPitch); // Function AudioGameplay.AudioComponentGroup.SetPitchMultiplier // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d86a0
	void SetLowPassFilter(float InFrequency); // Function AudioGameplay.AudioComponentGroup.SetLowPassFilter // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x5a16840
	void RemoveExtension(struct TScriptInterface<IAudioComponentGroupExtension> NewExtension); // Function AudioGameplay.AudioComponentGroup.RemoveExtension // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67db290
	bool IsVirtualized(); // Function AudioGameplay.AudioComponentGroup.IsVirtualized // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67d8b40
	bool IsPlayingAny(); // Function AudioGameplay.AudioComponentGroup.IsPlayingAny // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67dd8f0
	struct FString GetStringParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetStringParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67de880
	float GetFloatParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetFloatParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67daee0
	bool GetBoolParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetBoolParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67d6900
	void EnableVirtualization(); // Function AudioGameplay.AudioComponentGroup.EnableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d5cf0
	void DisableVirtualization(); // Function AudioGameplay.AudioComponentGroup.DisableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d6370
	void BroadcastStopAll(); // Function AudioGameplay.AudioComponentGroup.BroadcastStopAll // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d8900
	void BroadcastKill(); // Function AudioGameplay.AudioComponentGroup.BroadcastKill // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d68e0
	void BroadcastEvent(struct FName EventName); // Function AudioGameplay.AudioComponentGroup.BroadcastEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67d7920
	void AddExternalComponent(struct UAudioComponent* ComponentToAdd); // Function AudioGameplay.AudioComponentGroup.AddExternalComponent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67dad10
	void AddExtension(struct TScriptInterface<IAudioComponentGroupExtension> NewExtension); // Function AudioGameplay.AudioComponentGroup.AddExtension // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x67db140
};

// Class AudioGameplay.AudioGameplayComponent
// Size: 0x160 (Inherited: 0x160)
struct UAudioGameplayComponent : UActorComponent {
};

// Class AudioGameplay.AudioRequirementPreset
// Size: 0xf0 (Inherited: 0xa0)
struct UAudioRequirementPreset : UDataAsset {
	struct FGameplayTagQuery Query; // 0xa0(0x48)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class AudioGameplay.AudioParameterComponent
// Size: 0x190 (Inherited: 0x160)
struct UAudioParameterComponent : UAudioGameplayComponent {
	char pad_160[0x10]; // 0x160(0x10)
	struct TArray<struct TWeakObjectPtr<struct UAudioComponent>> ActiveComponents; // 0x170(0x10)
	struct TArray<struct FAudioParameter> Parameters; // 0x180(0x10)

	struct TArray<struct FAudioParameter> GetParameters(); // Function AudioGameplay.AudioParameterComponent.GetParameters // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x67d6a10
};

