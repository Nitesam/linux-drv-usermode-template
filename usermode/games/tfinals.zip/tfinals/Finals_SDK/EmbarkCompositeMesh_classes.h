// Class EmbarkCompositeMesh.EmbarkCompositeMeshActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AEmbarkCompositeMeshActor : AActor {
	struct UEmbarkCompositeMeshComponent* CompositeMeshComponent; // 0x398(0x08)
};

// Class EmbarkCompositeMesh.EmbarkCompositeMeshComponent
// Size: 0x810 (Inherited: 0x790)
struct UEmbarkCompositeMeshComponent : UStaticMeshComponent {
	char pad_790[0x10]; // 0x790(0x10)
	char NumParts; // 0x7a0(0x01)
	char bOverrideMaxLOD : 1; // 0x7a1(0x01)
	char pad_7a1_1 : 7; // 0x7a1(0x01)
	char pad_7a2[0x2]; // 0x7a2(0x02)
	int32_t MaxLOD; // 0x7a4(0x04)
	bool bSupportRayTracing; // 0x7a8(0x01)
	char pad_7a9[0x7]; // 0x7a9(0x07)
	struct TArray<struct UMaterialInterface*> DisabledMaterialsWithOriginalPartTransforms; // 0x7b0(0x10)
	char pad_7c0[0x50]; // 0x7c0(0x50)

	void SetPartCustomData(char PartIndex, struct FVector4f& CustomData); // Function EmbarkCompositeMesh.EmbarkCompositeMeshComponent.SetPartCustomData // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5ba6780
	struct FVector4f GetPartCustomData(char PartIndex); // Function EmbarkCompositeMesh.EmbarkCompositeMeshComponent.GetPartCustomData // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ba5ba0
};

// Class EmbarkCompositeMesh.MaterialExpressionEmbarkCompositeMeshCustomData
// Size: 0x150 (Inherited: 0x120)
struct UMaterialExpressionEmbarkCompositeMeshCustomData : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0x120(0x28)
	float ConstDefaultValue; // 0x148(0x04)
	uint32_t DataIndex; // 0x14c(0x04)
};

// Class EmbarkCompositeMesh.MaterialExpressionEmbarkCompositeMeshCustomData4Vector
// Size: 0x170 (Inherited: 0x120)
struct UMaterialExpressionEmbarkCompositeMeshCustomData4Vector : UMaterialExpression {
	struct FExpressionInput DefaultValue; // 0x120(0x28)
	char pad_148[0x8]; // 0x148(0x08)
	struct FVector4 ConstDefaultValue; // 0x150(0x20)
};

