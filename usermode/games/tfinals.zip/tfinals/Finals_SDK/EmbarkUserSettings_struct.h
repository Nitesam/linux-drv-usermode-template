// Enum EmbarkUserSettings.EResolutionScalingMethod
enum class EResolutionScalingMethod : uint8_t {
	NoAA = 0,
	TAAU = 1,
	TSR = 2,
	DLSS = 3,
	FSR3 = 4,
	XeSS = 5,
	Invalid = 255,
	EResolutionScalingMethod_MAX = 256
};

// Enum EmbarkUserSettings.EResolutionScaleMode
enum class EResolutionScaleMode : uint8_t {
	Auto = 0,
	Manual = 1,
	COUNT = 2,
	EResolutionScaleMode_MAX = 3
};

// Enum EmbarkUserSettings.EDLSSModel
enum class EDLSSModel : uint8_t {
	CNN = 0,
	Transformer = 1,
	COUNT = 2,
	EDLSSModel_MAX = 3
};

// Enum EmbarkUserSettings.EFSR3Mode
enum class EFSR3Mode : uint8_t {
	NativeAA = 0,
	Quality = 1,
	Balanced = 2,
	Performance = 3,
	UltraPerformance = 4,
	Off = 5,
	Count = 6,
	EFSR3Mode_MAX = 7
};

// Enum EmbarkUserSettings.EFSR3FrameGenerationMode
enum class EFSR3FrameGenerationMode : uint8_t {
	Off = 0,
	On = 1,
	Count = 2,
	EFSR3FrameGenerationMode_MAX = 3
};

// Enum EmbarkUserSettings.ERTXGIQuality
enum class ERTXGIQuality : uint8_t {
	Static = 0,
	DynamicLow = 1,
	DynamicMedium = 2,
	DynamicHigh = 3,
	DynamicEpic = 4,
	CountExcludingSoftware = 5,
	DynamicSoftware = 5,
	Count = 6,
	Invalid = 255,
	ERTXGIQuality_MAX = 256
};

// Enum EmbarkUserSettings.EPerformanceOverlayMode
enum class EPerformanceOverlayMode : uint8_t {
	Disabled = 0,
	Simple = 1,
	Detailed = 2,
	Developer = 3,
	Count = 4,
	EPerformanceOverlayMode_MAX = 5
};

// Enum EmbarkUserSettings.ESwapchainHookFeature
enum class ESwapchainHookFeature : uint8_t {
	Latewarp = 0,
	DLSSG = 1,
	FSR3G = 2,
	ESwapchainHookFeature_MAX = 3
};

// Enum EmbarkUserSettings.EMotionBlurMode
enum class EMotionBlurMode : uint8_t {
	Off = 0,
	ForegroundOnly = 1,
	Full = 2,
	EMotionBlurMode_MAX = 3
};

// ScriptStruct EmbarkUserSettings.ScalabilityText
// Size: 0x78 (Inherited: 0x00)
struct FScalabilityText {
	struct FText LowScalabilityText; // 0x00(0x18)
	struct FText MediumScalabilityText; // 0x18(0x18)
	struct FText HighScalabilityText; // 0x30(0x18)
	struct FText EpicScalabilityText; // 0x48(0x18)
	struct FText CinematicScalabilityText; // 0x60(0x18)
};

