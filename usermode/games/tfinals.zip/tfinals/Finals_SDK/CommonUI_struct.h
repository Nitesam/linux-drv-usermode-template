// Enum CommonUI.ECommonNumericType
enum class ECommonNumericType : uint8_t {
	Number = 0,
	Percentage = 1,
	Seconds = 2,
	Distance = 3,
	ECommonNumericType_MAX = 4
};

// Enum CommonUI.ERichTextInlineIconDisplayMode
enum class ERichTextInlineIconDisplayMode : uint8_t {
	IconOnly = 0,
	TextOnly = 1,
	IconAndText = 2,
	MAX = 3
};

// Enum CommonUI.EInputActionState
enum class EInputActionState : uint8_t {
	Enabled = 0,
	Disabled = 1,
	Hidden = 2,
	HiddenAndDisabled = 3,
	EInputActionState_MAX = 4
};

// Enum CommonUI.ECommonSwitcherTransition
enum class ECommonSwitcherTransition : uint8_t {
	FadeOnly = 0,
	Horizontal = 1,
	Vertical = 2,
	Zoom = 3,
	ECommonSwitcherTransition_MAX = 4
};

// Enum CommonUI.ETransitionCurve
enum class ETransitionCurve : uint8_t {
	Linear = 0,
	QuadIn = 1,
	QuadOut = 2,
	QuadInOut = 3,
	CubicIn = 4,
	CubicOut = 5,
	CubicInOut = 6,
	ETransitionCurve_MAX = 7
};

// ScriptStruct CommonUI.CommonNumberFormattingOptions
// Size: 0x14 (Inherited: 0x00)
struct FCommonNumberFormattingOptions {
	enum class ERoundingMode RoundingMode; // 0x00(0x01)
	bool UseGrouping; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t MinimumIntegralDigits; // 0x04(0x04)
	int32_t MaximumIntegralDigits; // 0x08(0x04)
	int32_t MinimumFractionalDigits; // 0x0c(0x04)
	int32_t MaximumFractionalDigits; // 0x10(0x04)
};

// ScriptStruct CommonUI.CommonRegisteredTabInfo
// Size: 0x18 (Inherited: 0x00)
struct FCommonRegisteredTabInfo {
	int32_t TabIndex; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UCommonButtonBase* TabButton; // 0x08(0x08)
	struct UWidget* ContentInstance; // 0x10(0x08)
};

// ScriptStruct CommonUI.UIInputConfig
// Size: 0x05 (Inherited: 0x00)
struct FUIInputConfig {
	bool bIgnoreMoveInput; // 0x00(0x01)
	bool bIgnoreLookInput; // 0x01(0x01)
	enum class ECommonInputMode InputMode; // 0x02(0x01)
	enum class EMouseCaptureMode MouseCaptureMode; // 0x03(0x01)
	bool bHideCursorDuringViewportCapture; // 0x04(0x01)
};

// ScriptStruct CommonUI.UITag
// Size: 0x08 (Inherited: 0x08)
struct FUITag : FGameplayTag {
};

// ScriptStruct CommonUI.UIActionTag
// Size: 0x08 (Inherited: 0x08)
struct FUIActionTag : FUITag {
};

// ScriptStruct CommonUI.CommonInputActionHandlerData
// Size: 0x20 (Inherited: 0x00)
struct FCommonInputActionHandlerData {
	struct FDataTableRowHandle InputActionRow; // 0x00(0x10)
	enum class EInputActionState State; // 0x10(0x01)
	char pad_11[0xf]; // 0x11(0x0f)
};

// ScriptStruct CommonUI.CommonButtonStyleOptionalSlateSound
// Size: 0x20 (Inherited: 0x00)
struct FCommonButtonStyleOptionalSlateSound {
	bool bHasSound; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSlateSound Sound; // 0x08(0x18)
};

// ScriptStruct CommonUI.RichTextIconData
// Size: 0x58 (Inherited: 0x08)
struct FRichTextIconData : FTableRowBase {
	struct FText DisplayName; // 0x08(0x18)
	struct TSoftObjectPtr<UObject> ResourceObject; // 0x20(0x28)
	struct FVector2D ImageSize; // 0x48(0x10)
};

// ScriptStruct CommonUI.CommonInputTypeInfo
// Size: 0x100 (Inherited: 0x00)
struct FCommonInputTypeInfo {
	struct FKey Key; // 0x00(0x18)
	enum class EInputActionState OverrrideState; // 0x18(0x01)
	bool bActionRequiresHold; // 0x19(0x01)
	char pad_1a[0x2]; // 0x1a(0x02)
	float HoldTime; // 0x1c(0x04)
	float HoldRollbackTime; // 0x20(0x04)
	char pad_24[0xc]; // 0x24(0x0c)
	struct FSlateBrush OverrideBrush; // 0x30(0xd0)
};

// ScriptStruct CommonUI.CommonInputActionDataBase
// Size: 0x390 (Inherited: 0x08)
struct FCommonInputActionDataBase : FTableRowBase {
	struct FText DisplayName; // 0x08(0x18)
	struct FText HoldDisplayName; // 0x20(0x18)
	int32_t NavBarPriority; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
	struct FCommonInputTypeInfo KeyboardInputTypeInfo; // 0x40(0x100)
	struct FCommonInputTypeInfo DefaultGamepadInputTypeInfo; // 0x140(0x100)
	struct TMap<struct FName, struct FCommonInputTypeInfo> GamepadInputOverrides; // 0x240(0x50)
	struct FCommonInputTypeInfo TouchInputTypeInfo; // 0x290(0x100)
};

// ScriptStruct CommonUI.CommonUIActionRouterRootNodeDebugEntry
// Size: 0x20 (Inherited: 0x00)
struct FCommonUIActionRouterRootNodeDebugEntry {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString DebugString; // 0x08(0x10)
	bool bIsActive; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct CommonUI.CommonUIActionRouterDebugData
// Size: 0x38 (Inherited: 0x00)
struct FCommonUIActionRouterDebugData {
	struct FCommonUIActionRouterRootNodeDebugEntry ActiveNode; // 0x00(0x20)
	struct TArray<struct FCommonUIActionRouterRootNodeDebugEntry> FullNodeList; // 0x20(0x10)
	struct FUIInputConfig InputConfig; // 0x30(0x05)
	char pad_35[0x3]; // 0x35(0x03)
};

// ScriptStruct CommonUI.UIActionKeyMapping
// Size: 0x20 (Inherited: 0x00)
struct FUIActionKeyMapping {
	struct FKey Key; // 0x00(0x18)
	float HoldTime; // 0x18(0x04)
	float HoldRollbackTime; // 0x1c(0x04)
};

// ScriptStruct CommonUI.UIInputAction
// Size: 0x30 (Inherited: 0x00)
struct FUIInputAction {
	struct FUIActionTag ActionTag; // 0x00(0x08)
	struct FText DefaultDisplayName; // 0x08(0x18)
	struct TArray<struct FUIActionKeyMapping> KeyMappings; // 0x20(0x10)
};

// ScriptStruct CommonUI.CommonAnalogCursorSettings
// Size: 0x24 (Inherited: 0x00)
struct FCommonAnalogCursorSettings {
	int32_t PreprocessorPriority; // 0x00(0x04)
	bool bEnableCursorAcceleration; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	float CursorAcceleration; // 0x08(0x04)
	float CursorMaxSpeed; // 0x0c(0x04)
	float CursorDeadZone; // 0x10(0x04)
	float HoverSlowdownFactor; // 0x14(0x04)
	float ScrollDeadZone; // 0x18(0x04)
	float ScrollUpdatePeriod; // 0x1c(0x04)
	float ScrollMultiplier; // 0x20(0x04)
};

