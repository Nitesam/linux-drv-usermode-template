// Class NetCore.NetAnalyticsAggregatorConfig
// Size: 0xb0 (Inherited: 0xa0)
struct UNetAnalyticsAggregatorConfig : UObject {
	struct TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData; // 0x98(0x10)
};

// Class NetCore.StatePerObjectConfig
// Size: 0xe0 (Inherited: 0xa0)
struct UStatePerObjectConfig : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct FString PerObjectConfigSection; // 0xc0(0x10)
	bool bEnabled; // 0xd0(0x01)
	char pad_d1[0xf]; // 0xd1(0x0f)
};

// Class NetCore.EscalationManagerConfig
// Size: 0x100 (Inherited: 0xe0)
struct UEscalationManagerConfig : UStatePerObjectConfig {
	struct TArray<struct FString> EscalationSeverity; // 0xd8(0x10)
	char pad_f0[0x10]; // 0xf0(0x10)
};

