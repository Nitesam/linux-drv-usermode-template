// Class DiscoveryAudio.DynamicCommentaryPlayerNameManager
// Size: 0x160 (Inherited: 0xa0)
struct UDynamicCommentaryPlayerNameManager : UObject {
	struct UObject* WorldContextObject; // 0x98(0x08)
	char pad_a8[0xb8]; // 0xa8(0xb8)

	void RequestPlayerName(struct FEmbarkUserId& EmbarkID, struct FString PlayerName, struct FTenancyUserId& TenancyUserId); // Function DiscoveryAudio.DynamicCommentaryPlayerNameManager.RequestPlayerName // (Final|Native|Public|HasOutParms) // @ game+0x681e7f0
	void RequestAnonymousName(struct FEmbarkUserId& EmbarkID, struct FString PlayerName); // Function DiscoveryAudio.DynamicCommentaryPlayerNameManager.RequestAnonymousName // (Final|Native|Public|HasOutParms) // @ game+0x681ed50
	void Initialize(struct UObject* InWorldContext, float InApiTimeoutSeconds, float InBatchDelaySeconds); // Function DiscoveryAudio.DynamicCommentaryPlayerNameManager.Initialize // (Final|Native|Public) // @ game+0x6818af0
	struct FString GetResolvedName(struct FEmbarkUserId& EmbarkID); // Function DiscoveryAudio.DynamicCommentaryPlayerNameManager.GetResolvedName // (Final|Native|Public|HasOutParms|Const) // @ game+0x6820a60
};

// Class DiscoveryAudio.AudioDownloadFutureUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioDownloadFutureUtils : UBlueprintFunctionLibrary {

	enum class EAsyncOperationState GetState(struct FAudioDownloadFuture& Handler); // Function DiscoveryAudio.AudioDownloadFutureUtils.GetState // (Final|Native|Static|Public|HasOutParms) // @ game+0x681c890
	struct USoundWave* GetSoundWave(struct FAudioDownloadFuture& Handler); // Function DiscoveryAudio.AudioDownloadFutureUtils.GetSoundWave // (Final|Native|Static|Public|HasOutParms) // @ game+0x681e000
	struct FString GetError(struct FAudioDownloadFuture& Handler); // Function DiscoveryAudio.AudioDownloadFutureUtils.GetError // (Final|Native|Static|Public|HasOutParms) // @ game+0x6819f30
	double GetElapsedTime(struct FAudioDownloadFuture& Handler); // Function DiscoveryAudio.AudioDownloadFutureUtils.GetElapsedTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x6818c60
	void Cancel(struct FAudioDownloadFuture& Handler); // Function DiscoveryAudio.AudioDownloadFutureUtils.Cancel // (Final|Native|Static|Public|HasOutParms) // @ game+0x681e4a0
};

// Class DiscoveryAudio.DynamicCommentaryFutureUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UDynamicCommentaryFutureUtils : UBlueprintFunctionLibrary {

	bool IsInitialized(struct FDynamicCommentaryFuture& Future); // Function DiscoveryAudio.DynamicCommentaryFutureUtils.IsInitialized // (Final|Native|Static|Public|HasOutParms) // @ game+0x681d560
	enum class EAsyncOperationState GetState(struct FDynamicCommentaryFuture& Future); // Function DiscoveryAudio.DynamicCommentaryFutureUtils.GetState // (Final|Native|Static|Public|HasOutParms) // @ game+0x681c890
	struct FDynamicCommentaryResult GetResult(struct FDynamicCommentaryFuture& Future); // Function DiscoveryAudio.DynamicCommentaryFutureUtils.GetResult // (Final|Native|Static|Public|HasOutParms) // @ game+0x6818650
	struct FString GetError(struct FDynamicCommentaryFuture& Future); // Function DiscoveryAudio.DynamicCommentaryFutureUtils.GetError // (Final|Native|Static|Public|HasOutParms) // @ game+0x6819f30
	double GetElapsedTime(struct FDynamicCommentaryFuture& Future); // Function DiscoveryAudio.DynamicCommentaryFutureUtils.GetElapsedTime // (Final|Native|Static|Public|HasOutParms) // @ game+0x6818c60
	void Cancel(struct FDynamicCommentaryFuture& Future); // Function DiscoveryAudio.DynamicCommentaryFutureUtils.Cancel // (Final|Native|Static|Public|HasOutParms) // @ game+0x681e4a0
};

// Class DiscoveryAudio.DynamicCommentaryUtilities
// Size: 0xa0 (Inherited: 0xa0)
struct UDynamicCommentaryUtilities : UBlueprintFunctionLibrary {

	struct FDynamicCommentaryFuture RequestDynamicCommentaryAsync(struct UObject* WorldContext, struct FString Prompt, struct FDynamicCommentaryConfig& Config); // Function DiscoveryAudio.DynamicCommentaryUtilities.RequestDynamicCommentaryAsync // (Final|Native|Static|Public|HasOutParms) // @ game+0x681d780
	struct FAudioDownloadFuture DownloadAndDecodeAudioAsync(struct FString AudioUrl, float TimeoutSeconds); // Function DiscoveryAudio.DynamicCommentaryUtilities.DownloadAndDecodeAudioAsync // (Final|Native|Static|Public) // @ game+0x68190b0
};

