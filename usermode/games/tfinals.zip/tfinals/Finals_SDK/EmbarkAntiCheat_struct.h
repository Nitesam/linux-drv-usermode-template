// ScriptStruct EmbarkAntiCheat.EmbarkStatManagerSnapshot
// Size: 0xb8 (Inherited: 0x00)
struct FEmbarkStatManagerSnapshot {
	struct FRotator PlayerControllerRotation; // 0x00(0x18)
	struct FVector PlayerControllerRotationVelocity; // 0x18(0x18)
	struct FVector PlayerLocalMovementInput; // 0x30(0x18)
	struct FVector PlayerPosition; // 0x48(0x18)
	struct FVector PlayerVelocity; // 0x60(0x18)
	struct FVector PlayerLookOrigin; // 0x78(0x18)
	struct FVector PlayerLookOriginVelocity; // 0x90(0x18)
	struct FGameplayTag EquippedItemTag; // 0xa8(0x08)
	bool bIsFiring; // 0xb0(0x01)
	bool bIsUsingGamepad; // 0xb1(0x01)
	bool bAimAssistEnabled; // 0xb2(0x01)
	char pad_b3[0x1]; // 0xb3(0x01)
	float Latency; // 0xb4(0x04)
};

// ScriptStruct EmbarkAntiCheat.EmbarkStatManagerData
// Size: 0x4b88 (Inherited: 0x00)
struct FEmbarkStatManagerData {
	char pad_0[0x4b88]; // 0x00(0x4b88)
};

