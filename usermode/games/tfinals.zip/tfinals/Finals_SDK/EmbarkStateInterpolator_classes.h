// Class EmbarkStateInterpolator.EmbarkCharacterStateInterpolatorDataBase
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkCharacterStateInterpolatorDataBase : UObject {
};

// Class EmbarkStateInterpolator.StateInterpolator
// Size: 0x170 (Inherited: 0xa0)
struct UStateInterpolator : UObject {
	char pad_a0[0xd0]; // 0xa0(0xd0)

	void RemoveStateInstance(struct FStateInstanceId& InstanceId); // Function EmbarkStateInterpolator.StateInterpolator.RemoveStateInstance // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a1b670
	bool HasInstanceForActor(struct AActor* Actor); // Function EmbarkStateInterpolator.StateInterpolator.HasInstanceForActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1bfa0
	bool HasInstance(struct FStateInstanceId& StateInstance); // Function EmbarkStateInterpolator.StateInterpolator.HasInstance // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1c0f0
	void AddStateInstance(struct FStateInstanceId& InstanceId); // Function EmbarkStateInterpolator.StateInterpolator.AddStateInstance // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a1afb0
};

// Class EmbarkStateInterpolator.LinearBufferStateInterpolator
// Size: 0x2d0 (Inherited: 0x170)
struct ULinearBufferStateInterpolator : UStateInterpolator {
	char pad_170[0x160]; // 0x170(0x160)
};

// Class EmbarkStateInterpolator.ObjectInterpolator
// Size: 0x340 (Inherited: 0x2d0)
struct UObjectInterpolator : ULinearBufferStateInterpolator {
	char pad_2d0[0x20]; // 0x2d0(0x20)
	struct TArray<struct UObject*> PooledStateObjs; // 0x2f0(0x10)
	struct TArray<struct UObject*> InputStateObjs; // 0x300(0x10)
	struct TArray<struct UObject*> InterpolatedStateObjs; // 0x310(0x10)
	struct TArray<struct UObject*> LatestStateObjs; // 0x320(0x10)
	struct TArray<struct FObjectInterpolatorStateObjQueue> QueuedStateObjs; // 0x330(0x10)
};

// Class EmbarkStateInterpolator.BPObjectInterpolator
// Size: 0x340 (Inherited: 0x340)
struct UBPObjectInterpolator : UObjectInterpolator {

	void Interpolate_BP(struct TArray<struct UObject*>& A_Array, struct TArray<struct UObject*>& B_Array, struct TArray<float>& Alphas, struct TArray<struct UObject*>& OutResults); // Function EmbarkStateInterpolator.BPObjectInterpolator.Interpolate_BP // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	struct UObject* GetObjectType_BP(); // Function EmbarkStateInterpolator.BPObjectInterpolator.GetObjectType_BP // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	struct UObject* GetLatestStateObj_BP(struct FStateInstanceId& InstanceId); // Function EmbarkStateInterpolator.BPObjectInterpolator.GetLatestStateObj_BP // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a18670
	struct UObject* GetInterpolatedStateObj_BP(struct FStateInstanceId& InstanceId); // Function EmbarkStateInterpolator.BPObjectInterpolator.GetInterpolatedStateObj_BP // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a16230
	struct UObject* GetInputStateObj_BP(struct FStateInstanceId& InstanceId); // Function EmbarkStateInterpolator.BPObjectInterpolator.GetInputStateObj_BP // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a18390
};

// Class EmbarkStateInterpolator.EmbarkCharacterStateInterpolatorBase
// Size: 0x340 (Inherited: 0x340)
struct UEmbarkCharacterStateInterpolatorBase : UBPObjectInterpolator {
};

// Class EmbarkStateInterpolator.InterpolatedTestActor
// Size: 0x440 (Inherited: 0x3a0)
struct AInterpolatedTestActor : AActor {
	struct UStaticMeshComponent* Mesh; // 0x398(0x08)
	struct UStateInterpolatorComponent* StateInterpolatorComponent; // 0x3a0(0x08)
	struct UReplicationSettingsComponent* ReplicationSettingsComponent; // 0x3a8(0x08)
	struct FReplicatedTransform Transform; // 0x3b0(0x68)
	bool bEnableInterpolation; // 0x418(0x01)
	char pad_421[0x1f]; // 0x421(0x1f)

	void SetVelocity(struct FVector& Velocity); // Function EmbarkStateInterpolator.InterpolatedTestActor.SetVelocity // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5a17da0
	void SetAngularVelocity(struct FVector& Velocity); // Function EmbarkStateInterpolator.InterpolatedTestActor.SetAngularVelocity // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5a1d580
	void OnRep_Transform(); // Function EmbarkStateInterpolator.InterpolatedTestActor.OnRep_Transform // (Final|Native|Public) // @ game+0x5a19280
};

// Class EmbarkStateInterpolator.InterpolationUtilsStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UInterpolationUtilsStatics : UBlueprintFunctionLibrary {

	struct FVector SinusoidalVector(struct FVector A, struct FVector B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.SinusoidalVector // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a18e40
	float SinusoidalFloat(float A, float B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.SinusoidalFloat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a1daf0
	int32_t MinInt(int32_t A, int32_t B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.MinInt // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a189b0
	float MinFloat(float A, float B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.MinFloat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a19930
	bool MinBool(bool A, bool B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.MinBool // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a168e0
	int32_t MaxInt(int32_t A, int32_t B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.MaxInt // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a1c280
	float MaxFloat(float A, float B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.MaxFloat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a17ef0
	bool MaxBool(bool A, bool B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.MaxBool // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a1ace0
	struct FVector LinearVector(struct FVector A, struct FVector B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.LinearVector // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x3362150
	float LinearFloat(float A, float B, float Alpha); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.LinearFloat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a194b0
	struct FVector CutoffVector(struct FVector A, struct FVector B, float Alpha, float CutoffPoint); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.CutoffVector // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5a16600
	int32_t CutoffInt(int32_t A, int32_t B, float Alpha, float CutoffPoint); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.CutoffInt // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a1e9d0
	float CutoffFloat(float A, float B, float Alpha, float CutoffPoint); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.CutoffFloat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a16e80
	bool CutoffBool(bool A, bool B, float Alpha, float CutoffPoint); // Function EmbarkStateInterpolator.InterpolationUtilsStatics.CutoffBool // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a196d0
};

// Class EmbarkStateInterpolator.FakeLinearBufferStateInterpolator
// Size: 0x2d0 (Inherited: 0x2d0)
struct UFakeLinearBufferStateInterpolator : ULinearBufferStateInterpolator {
};

// Class EmbarkStateInterpolator.FakeObjectStateDataObj
// Size: 0xb0 (Inherited: 0xa0)
struct UFakeObjectStateDataObj : UObject {
	float TestFloat; // 0x98(0x04)
	int32_t TestInt; // 0x9c(0x04)
	bool TestBool; // 0xa0(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
};

// Class EmbarkStateInterpolator.FakeObjectStateInterpolator
// Size: 0x340 (Inherited: 0x340)
struct UFakeObjectStateInterpolator : UObjectInterpolator {
};

// Class EmbarkStateInterpolator.StateInstanceIdMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UStateInstanceIdMixinLibrary : UObject {

	bool IsValid(struct FStateInstanceId& StateInstanceId); // Function EmbarkStateInterpolator.StateInstanceIdMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5a18c60
	int32_t GetKey(struct FStateInstanceId& StateInstanceId); // Function EmbarkStateInterpolator.StateInstanceIdMixinLibrary.GetKey // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5a1ef00
	struct AActor* GetActor(struct FStateInstanceId& StateInstanceId); // Function EmbarkStateInterpolator.StateInstanceIdMixinLibrary.GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5a1bbe0
};

// Class EmbarkStateInterpolator.StateInterpolatorReplicationEventActorInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UStateInterpolatorReplicationEventActorInterface : UInterface {
};

// Class EmbarkStateInterpolator.StateInterpolatorComponent
// Size: 0x200 (Inherited: 0x160)
struct UStateInterpolatorComponent : UActorComponent {
	struct FActorStateInterpolatorSettings Settings; // 0x158(0x28)
	struct TArray<struct FStateDependency> StateDependencies; // 0x180(0x10)
	struct UStateInterpolatorSubsystem* StateInterpolatorSubsystem; // 0x190(0x08)
	char pad_1a0[0x20]; // 0x1a0(0x20)
	struct TArray<struct UStateInterpolator*> StateInterpolators; // 0x1c0(0x10)
	char pad_1d0[0x30]; // 0x1d0(0x30)

	void UpdateSettings(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.UpdateSettings // (Final|Native|Public) // @ game+0x5a1cd80
	void PreUpdateInputForOwnerEvent_RemoveUFunction(struct UObject* Object, struct FName& FunctionName); // Function EmbarkStateInterpolator.StateInterpolatorComponent.PreUpdateInputForOwnerEvent_RemoveUFunction // (Final|Native|Public|HasOutParms) // @ game+0x5a15d30
	void PreUpdateInputForOwnerEvent_AddUFunction(struct UObject* Object, struct FName& FunctionName); // Function EmbarkStateInterpolator.StateInterpolatorComponent.PreUpdateInputForOwnerEvent_AddUFunction // (Final|Native|Public|HasOutParms) // @ game+0x5a1e440
	void PreUpdateEvent_RemoveFunction(struct UObject* Object, struct FName& FunctionName); // Function EmbarkStateInterpolator.StateInterpolatorComponent.PreUpdateEvent_RemoveFunction // (Final|Native|Public|HasOutParms) // @ game+0x5a1be00
	void PreUpdateEvent_AddUFunction(struct UObject* Object, struct FName& FunctionName); // Function EmbarkStateInterpolator.StateInterpolatorComponent.PreUpdateEvent_AddUFunction // (Final|Native|Public|HasOutParms) // @ game+0x5a18210
	bool IsInitialized(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.IsInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1efb0
	bool HasAnyActiveInterpolator(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.HasAnyActiveInterpolator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1ce20
	struct UStateInterpolatorSubsystem* GetStateInterpolatorSubsystem(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetStateInterpolatorSubsystem // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1c050
	struct UStateInterpolator* GetStateInterpolator(struct UStateInterpolator* StateClass); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetStateInterpolator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1e730
	float GetLatestSyncTimestamp(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetLatestSyncTimestamp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a15cc0
	float GetEstimatedLocalInterpolationDelayTarget(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetEstimatedLocalInterpolationDelayTarget // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1d1f0
	struct FStateInstanceId GetDefaultStateInstanceId(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetDefaultStateInstanceId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1e690
	float GetCurrentTotalInterpolationDelay(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetCurrentTotalInterpolationDelay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a1bc90
	float GetCurrentInterpolationTimestamp(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GetCurrentInterpolationTimestamp // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a17c10
	struct FStateInstanceId GenerateUniqueStateInstanceId(); // Function EmbarkStateInterpolator.StateInterpolatorComponent.GenerateUniqueStateInstanceId // (Final|Native|Public) // @ game+0x5a1e5c0
};

// Class EmbarkStateInterpolator.StateInterpolatorComponentFake
// Size: 0x200 (Inherited: 0x200)
struct UStateInterpolatorComponentFake : UStateInterpolatorComponent {
};

// Class EmbarkStateInterpolator.StateInterpolatorFake
// Size: 0x1c0 (Inherited: 0x170)
struct UStateInterpolatorFake : UStateInterpolator {
	char pad_170[0x50]; // 0x170(0x50)
};

// Class EmbarkStateInterpolator.StateInterpolatorFakeEmpty1
// Size: 0x1c0 (Inherited: 0x1c0)
struct UStateInterpolatorFakeEmpty1 : UStateInterpolatorFake {
};

// Class EmbarkStateInterpolator.StateInterpolatorFakeEmpty2
// Size: 0x1c0 (Inherited: 0x1c0)
struct UStateInterpolatorFakeEmpty2 : UStateInterpolatorFake {
};

// Class EmbarkStateInterpolator.StateInterpolatorSubsystem
// Size: 0x460 (Inherited: 0xa0)
struct UStateInterpolatorSubsystem : UWorldSubsystem {
	char pad_a0[0x128]; // 0xa0(0x128)
	struct TArray<struct FSubsystemOwnedStateInterpolator> StateInterpolators; // 0x1c8(0x10)
	char pad_1d8[0x288]; // 0x1d8(0x288)

	void SetGlobalMinInterpolationReplicationDelayOverride(float Delay); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetGlobalMinInterpolationReplicationDelayOverride // (Final|Native|Public) // @ game+0x5a16840
	void SetDebugModeForInstanceOnInterpolator(struct UStateInterpolator* StateInterpolatorClass, struct FStateInstanceId& StateInstance, enum class EStateInterpolatorDebugMode DebugMode); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetDebugModeForInstanceOnInterpolator // (Final|Native|Public|HasOutParms) // @ game+0x5a1b070
	void SetDebugModeForInstance(struct FStateInstanceId& StateInstance, enum class EStateInterpolatorDebugMode DebugMode); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetDebugModeForInstance // (Final|Native|Public|HasOutParms) // @ game+0x5a1c3f0
	void SetDebugModeForAllOnInterpolator(struct UStateInterpolator* StateInterpolatorClass, enum class EStateInterpolatorDebugMode DebugMode); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetDebugModeForAllOnInterpolator // (Final|Native|Public) // @ game+0x5a1bcc0
	void SetDebugModeForAll(enum class EStateInterpolatorDebugMode DebugMode); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetDebugModeForAll // (Final|Native|Public) // @ game+0x5a1d9d0
	void SetDebugModeForActorOnInterpolator(struct UStateInterpolator* StateInterpolatorClass, struct AActor* Actor, enum class EStateInterpolatorDebugMode DebugMode); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetDebugModeForActorOnInterpolator // (Final|Native|Public) // @ game+0x5a19ab0
	void SetDebugModeForActor(struct AActor* Actor, enum class EStateInterpolatorDebugMode DebugMode); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.SetDebugModeForActor // (Final|Native|Public) // @ game+0x5a1bcc0
	void ResetExistingState(); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.ResetExistingState // (Final|Native|Public) // @ game+0x5a15980
	void ManuallySetActorHasNewState(struct AActor* Actor); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.ManuallySetActorHasNewState // (Final|Native|Public) // @ game+0x5a16de0
	float GetServerTime(); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.GetServerTime // (Final|Native|Public|Const) // @ game+0x5a16d10
	struct UStateInterpolator* GetOrCreateStateInterpolator(struct UStateInterpolator* StateClass); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.GetOrCreateStateInterpolator // (Final|Native|Public) // @ game+0x5a1d7e0
	float GetLocalTime(); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.GetLocalTime // (Final|Native|Public|Const) // @ game+0x5a1a380
	float GetLocalPing(); // Function EmbarkStateInterpolator.StateInterpolatorSubsystem.GetLocalPing // (Final|Native|Public|Const) // @ game+0x5a1e9a0
};

// Class EmbarkStateInterpolator.StateInterpolatorStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UStateInterpolatorStatics : UBlueprintFunctionLibrary {

	struct UStateInterpolatorSubsystem* GetSubsystem(struct UObject* WorldContextObject); // Function EmbarkStateInterpolator.StateInterpolatorStatics.GetSubsystem // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a1b1d0
};

// Class EmbarkStateInterpolator.StateInterpolatorSubsystemFake
// Size: 0x460 (Inherited: 0x460)
struct UStateInterpolatorSubsystemFake : UStateInterpolatorSubsystem {
};

// Class EmbarkStateInterpolator.StateInterpolatorFakeChild
// Size: 0x1c0 (Inherited: 0x1c0)
struct UStateInterpolatorFakeChild : UStateInterpolatorFake {
};

// Class EmbarkStateInterpolator.TransformInterpolatorBatchedUpdateSystem
// Size: 0x460 (Inherited: 0x3a0)
struct ATransformInterpolatorBatchedUpdateSystem : AEmbarkGlobalActor {
	char pad_3a0[0x8]; // 0x3a0(0x08)
	struct TArray<struct AActor*> RegisteredActors; // 0x3a8(0x10)
	char pad_3b8[0xa8]; // 0x3b8(0xa8)

	void SetTransformUpdateEnabledForActor(struct AActor* Actor, bool bEnabled); // Function EmbarkStateInterpolator.TransformInterpolatorBatchedUpdateSystem.SetTransformUpdateEnabledForActor // (Final|Native|Public|BlueprintCallable) // @ game+0x5a213a0
	bool IsTransformUpdateEnabledForActor(struct AActor* Actor); // Function EmbarkStateInterpolator.TransformInterpolatorBatchedUpdateSystem.IsTransformUpdateEnabledForActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a27d60
	bool IsInUpdatePhase(); // Function EmbarkStateInterpolator.TransformInterpolatorBatchedUpdateSystem.IsInUpdatePhase // (Final|Native|Public|BlueprintCallable) // @ game+0x3709dd0
	bool IsActorRegistered(struct AActor* Actor); // Function EmbarkStateInterpolator.TransformInterpolatorBatchedUpdateSystem.IsActorRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a21020
};

// Class EmbarkStateInterpolator.TransformInterpolator
// Size: 0x350 (Inherited: 0x2d0)
struct UTransformInterpolator : ULinearBufferStateInterpolator {
	char pad_2d0[0x80]; // 0x2d0(0x80)

	void SetInput(struct FStateInstanceId& InstanceId, struct FTransformInterpolatorData& InputData); // Function EmbarkStateInterpolator.TransformInterpolator.SetInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a31f10
	bool GetLatestState(struct FStateInstanceId& InstanceId, struct FTransformInterpolatorData& OutTransformInterpolatorData); // Function EmbarkStateInterpolator.TransformInterpolator.GetLatestState // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a23a20
	bool GetInterpolatedState(struct FStateInstanceId& InstanceId, struct FTransformInterpolatorData& OutTransformInterpolatorData); // Function EmbarkStateInterpolator.TransformInterpolator.GetInterpolatedState // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a31d00
};

