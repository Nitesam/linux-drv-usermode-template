// Class OnlineSubsystemAngelscript.VoiceChatModelUserBlocker
// Size: 0xb0 (Inherited: 0xa0)
struct UVoiceChatModelUserBlocker : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)

	bool ShouldBlockUser(struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.VoiceChatModelUserBlocker.ShouldBlockUser // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x53d0d50
	void NotifyBlockerChanged(); // Function OnlineSubsystemAngelscript.VoiceChatModelUserBlocker.NotifyBlockerChanged // (Final|Native|Protected|Const) // @ game+0x53cc700
};

// Class OnlineSubsystemAngelscript.BlockedUsersUserBlocker
// Size: 0xc0 (Inherited: 0xb0)
struct UBlockedUsersUserBlocker : UVoiceChatModelUserBlocker {
	struct UServiceBlockedPlayersList* BlockedList; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)

	void OnBlockListUpdated(struct UServiceBlockedPlayersList* InBlockedList); // Function OnlineSubsystemAngelscript.BlockedUsersUserBlocker.OnBlockListUpdated // (Final|Native|Private) // @ game+0x5376f40
	void OnBlockListSynced(bool bSuccess); // Function OnlineSubsystemAngelscript.BlockedUsersUserBlocker.OnBlockListSynced // (Final|Native|Private) // @ game+0x53783e0
};

// Class OnlineSubsystemAngelscript.ClanRoleUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UClanRoleUtils : UObject {

	bool IsValidRole(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.IsValidRole // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x536dbb0
	bool HasPermission(struct FString ID, struct FString Permission); // Function OnlineSubsystemAngelscript.ClanRoleUtils.HasPermission // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5371870
	int32_t GetRolePriority(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.GetRolePriority // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53778a0
	struct FString GetManagerRole(); // Function OnlineSubsystemAngelscript.ClanRoleUtils.GetManagerRole // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53745e0
	struct FString GetDefaultRole(); // Function OnlineSubsystemAngelscript.ClanRoleUtils.GetDefaultRole // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5371ba0
	struct FString GetCreatorRole(); // Function OnlineSubsystemAngelscript.ClanRoleUtils.GetCreatorRole // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5370c40
	struct FString GetCoachRole(); // Function OnlineSubsystemAngelscript.ClanRoleUtils.GetCoachRole // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53704d0
	bool CanKick(struct FString ID, struct FString OtherId); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanKick // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53766a0
	bool CanInvite(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanInvite // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53762f0
	bool CanEditSearchTags(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanEditSearchTags // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53719d0
	bool CanEditClanTag(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanEditClanTag // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5376d80
	bool CanEditClanName(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanEditClanName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5375b50
	bool CanEditClanIcon(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanEditClanIcon // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5371450
	bool CanChangeRoles(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanChangeRoles // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5374ad0
	bool CanChangeRole(struct FString ID, struct FString OtherId, struct FString NewId); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanChangeRole // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5372070
	bool CanBan(struct FString ID, struct FString OtherId); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanBan // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53728b0
	bool CanAnswerRequests(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.CanAnswerRequests // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x536dd10
	bool BelowAllowedLimit(struct FString ID, int32_t NumMembers); // Function OnlineSubsystemAngelscript.ClanRoleUtils.BelowAllowedLimit // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5372e10
	int32_t AllowedLimit(struct FString ID); // Function OnlineSubsystemAngelscript.ClanRoleUtils.AllowedLimit // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x536f7b0
};

// Class OnlineSubsystemAngelscript.EmbarkOnlineServiceBase
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkOnlineServiceBase : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)

	void Shutdown(); // Function OnlineSubsystemAngelscript.EmbarkOnlineServiceBase.Shutdown // (Native|Event|Public|BlueprintEvent) // @ game+0x2b95cb0
	void Init(); // Function OnlineSubsystemAngelscript.EmbarkOnlineServiceBase.Init // (Native|Event|Public|BlueprintEvent) // @ game+0x2b96540
	struct UProfileCache* GetProfileCache(); // Function OnlineSubsystemAngelscript.EmbarkOnlineServiceBase.GetProfileCache // (Final|Native|Public|Const) // @ game+0x53974f0
	struct UEmbarkHttpContext* GetContext(); // Function OnlineSubsystemAngelscript.EmbarkOnlineServiceBase.GetContext // (Final|Native|Public|Const) // @ game+0x5395ec0
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineAnnouncementsModel
// Size: 0xc0 (Inherited: 0xb0)
struct UIEmbarkOnlineAnnouncementsModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncAnnouncementsCompleted; // 0xa8(0x10)

	void SyncAnnouncements(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineAnnouncementsModel.SyncAnnouncements // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
	struct UServiceAnnouncements* GetAnnouncements(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineAnnouncementsModel.GetAnnouncements // (Native|Event|Public|BlueprintEvent) // @ game+0x2a01890
};

// Class OnlineSubsystemAngelscript.DefaultAnnouncementsModel
// Size: 0xc0 (Inherited: 0xc0)
struct UDefaultAnnouncementsModel : UIEmbarkOnlineAnnouncementsModel {
	struct UServiceAnnouncements* Announcements; // 0xb8(0x08)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineBuildModel
// Size: 0x100 (Inherited: 0xb0)
struct UIEmbarkOnlineBuildModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnGetLatestBuildComplete; // 0xa8(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)
	struct FString StartupBuildId; // 0xd0(0x10)
	struct FString RequestBuildId; // 0xe0(0x10)
	bool UpdateAvailable; // 0xf0(0x01)
	char pad_f1[0xf]; // 0xf1(0x0f)

	bool RequestLatestBuild(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineBuildModel.RequestLatestBuild // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd3930
	bool IsBuildOutdated(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineBuildModel.IsBuildOutdated // (Native|Event|Public|BlueprintEvent) // @ game+0x2b960b0
};

// Class OnlineSubsystemAngelscript.DefaultBuildModel
// Size: 0x120 (Inherited: 0x100)
struct UDefaultBuildModel : UIEmbarkOnlineBuildModel {
	char pad_100[0x20]; // 0x100(0x20)
};

// Class OnlineSubsystemAngelscript.IEOSAudioInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UIEOSAudioInterface : UObject {
};

// Class OnlineSubsystemAngelscript.DefaultEOSAudioInterface
// Size: 0x130 (Inherited: 0xa0)
struct UDefaultEOSAudioInterface : UIEOSAudioInterface {
	char pad_a0[0x90]; // 0xa0(0x90)
};

// Class OnlineSubsystemAngelscript.IEOSRTCInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UIEOSRTCInterface : UObject {
};

// Class OnlineSubsystemAngelscript.DefaultEOSRTCInterface
// Size: 0xb0 (Inherited: 0xa0)
struct UDefaultEOSRTCInterface : UIEOSRTCInterface {
	struct UDefaultEOSAudioInterface* AudioInterface; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineGameSettingsModel
// Size: 0xe0 (Inherited: 0xb0)
struct UIEmbarkOnlineGameSettingsModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncGameSettingsCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnFrontendTweakablesSuccessResponse; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnFrontendTweakablesErrorResponse; // 0xc8(0x10)

	void SyncGameSettings(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineGameSettingsModel.SyncGameSettings // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	struct UEmbarkOnlineGameSettings* GetGameSettings(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineGameSettingsModel.GetGameSettings // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2a00080
	void GetFrontendTweakablesAsync(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineGameSettingsModel.GetFrontendTweakablesAsync // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
};

// Class OnlineSubsystemAngelscript.DefaultGameSettingsModel
// Size: 0xe0 (Inherited: 0xe0)
struct UDefaultGameSettingsModel : UIEmbarkOnlineGameSettingsModel {
	struct UEmbarkOnlineGameSettings* GameSettings; // 0xd8(0x08)
};

// Class OnlineSubsystemAngelscript.DefaultInboxServiceModel
// Size: 0x110 (Inherited: 0xb0)
struct UDefaultInboxServiceModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncInboxMessagesCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnMarkMessageFavoriteCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnDeleteInboxMessagesCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnDeleteInboxMessagesStarted; // 0xd8(0x10)
	struct UOnlineInboxServiceMessages* InboxMessages; // 0xe8(0x08)
	char pad_f8[0x18]; // 0xf8(0x18)

	void SyncInboxMessages(bool bIncludeSeenMessages); // Function OnlineSubsystemAngelscript.DefaultInboxServiceModel.SyncInboxMessages // (Native|Event|Public|BlueprintEvent) // @ game+0x325ff90
	void MarkMessageFavorite(int64_t MessageId, bool bFavorite); // Function OnlineSubsystemAngelscript.DefaultInboxServiceModel.MarkMessageFavorite // (Native|Event|Public|BlueprintEvent) // @ game+0x5372770
	void MarkMessageAsSeenByType(enum class EApiGatewaySharedInboxMessagePayloadType MessageTypeFilter); // Function OnlineSubsystemAngelscript.DefaultInboxServiceModel.MarkMessageAsSeenByType // (Native|Event|Public|BlueprintEvent) // @ game+0x53767e0
	void MarkMessageAsSeenById(int64_t MessageId); // Function OnlineSubsystemAngelscript.DefaultInboxServiceModel.MarkMessageAsSeenById // (Native|Event|Public|BlueprintEvent) // @ game+0x5373060
	struct TArray<struct FApiGatewaySharedInboxMessage> GetInboxMessages(enum class EApiGatewaySharedInboxMessagePayloadType MessageTypeFilter); // Function OnlineSubsystemAngelscript.DefaultInboxServiceModel.GetInboxMessages // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5371e50
	void DeleteInboxMessages(struct TArray<int64_t>& Messages); // Function OnlineSubsystemAngelscript.DefaultInboxServiceModel.DeleteInboxMessages // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5373470
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineLocalizationModel
// Size: 0xc0 (Inherited: 0xb0)
struct UIEmbarkOnlineLocalizationModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncLocalizationCompleted; // 0xa8(0x10)

	void SyncLocalization(struct FString Locale); // Function OnlineSubsystemAngelscript.IEmbarkOnlineLocalizationModel.SyncLocalization // (Native|Event|Public|BlueprintEvent) // @ game+0x537bb70
	struct UEmbarkOnlineLocalization* GetLocalization(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineLocalizationModel.GetLocalization // (Native|Event|Public|BlueprintEvent) // @ game+0x2a01890
};

// Class OnlineSubsystemAngelscript.DefaultLocalizationModel
// Size: 0xc0 (Inherited: 0xc0)
struct UDefaultLocalizationModel : UIEmbarkOnlineLocalizationModel {
	struct UEmbarkOnlineLocalization* Localization; // 0xb8(0x08)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel
// Size: 0xd0 (Inherited: 0xb0)
struct UIEmbarkOnlineManifestModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncManifestCompleteResult; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnManifestExpirationDetected; // 0xb8(0x10)

	void SyncManifest(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel.SyncManifest // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void SetManifestRequestId(int64_t ManifestId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel.SetManifestRequestId // (Native|Event|Public|BlueprintEvent) // @ game+0x537cee0
	void SetManifestDeferredOverride(bool bIsDeferred); // Function OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel.SetManifestDeferredOverride // (Native|Event|Public|BlueprintEvent) // @ game+0x2cdc960
	void OverrideManifest(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel.OverrideManifest // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	bool IsUpToDate(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel.IsUpToDate // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b960b0
	struct UServiceManifest* GetManifest(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineManifestModel.GetManifest // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376880
};

// Class OnlineSubsystemAngelscript.DefaultManifestModel
// Size: 0x140 (Inherited: 0xd0)
struct UDefaultManifestModel : UIEmbarkOnlineManifestModel {
	struct UServiceManifest* CurrentManifest; // 0xc8(0x08)
	struct UServiceManifest* CachedManifest; // 0xd0(0x08)
	char pad_e0[0x60]; // 0xe0(0x60)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel
// Size: 0x1b0 (Inherited: 0xb0)
struct UIEmbarkOnlineMatchmakingModel : UEmbarkOnlineServiceBase {
	char pad_b0[0x28]; // 0xb0(0x28)
	struct FMulticastInlineDelegate OnMatchmakingValidatePrerequisitesComplete; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnMatchmakingStarted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnMatchmakingChanged; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnMatchmakingCompleted; // 0x108(0x10)
	struct FMulticastInlineDelegate OnRequestingServerStarted; // 0x118(0x10)
	struct FMulticastInlineDelegate OnMatchmakingStopped; // 0x128(0x10)
	struct FMulticastInlineDelegate OnMatchmakingStatusChanged; // 0x138(0x10)
	struct FMulticastInlineDelegate OnPartyMatchmakingInfoReceived; // 0x148(0x10)
	struct FMulticastInlineDelegate OnPartyMatchmakingCompleted; // 0x158(0x10)
	struct FMulticastInlineDelegate OnRefreshTimeEstimatesCompleted; // 0x168(0x10)
	struct FMulticastInlineDelegate OnOnlineModelMatchSessionStateCompleted; // 0x178(0x10)
	struct FMulticastInlineDelegate OnOnlineModelAbandonCurrentSessionCompleted; // 0x188(0x10)
	struct FMulticastInlineDelegate OnMatchmakingCancelled; // 0x198(0x10)
	char pad_1a8[0x8]; // 0x1a8(0x08)

	void StartReconnectCurrentSession(struct FString MatchId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.StartReconnectCurrentSession // (Native|Event|Public|BlueprintEvent) // @ game+0x5382ba0
	bool StartMatchmaking(struct FMatchmakingParameters& Parameters); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.StartMatchmaking // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5378660
	bool SkipMatchmaking(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.SkipMatchmaking // (Native|Event|Public|BlueprintEvent) // @ game+0x3235920
	void SetMatchmakingSearchSettings(struct FMatchmakingSearchSettings& Settings); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.SetMatchmakingSearchSettings // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5383720
	bool RefreshMatchmakingTimeEstimates(struct TArray<struct FString>& Scenarios); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.RefreshMatchmakingTimeEstimates // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5382090
	bool Reconnect(struct FGameServer& GameServer, struct FEmbarkOnlineModelConnectionParameters& OptionalParameters); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.Reconnect // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x537acb0
	void PollGameServer(struct FString MatchId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.PollGameServer // (Native|Event|Public|BlueprintEvent) // @ game+0x537d550
	bool JoinSession(struct FEmbarkOnlineModelConnectionParameters& OptionalParameters); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.JoinSession // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x537c110
	bool JoinLocalServer(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.JoinLocalServer // (Native|Event|Public|BlueprintEvent) // @ game+0x537ff90
	bool IsSkipMatchmakingPending(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.IsSkipMatchmakingPending // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x31dafa0
	bool IsMatchmaking(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.IsMatchmaking // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537f670
	bool HasMatchmakingAuthority(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.HasMatchmakingAuthority // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2cd3930
	struct FMatchmakingTimeEstimates GetMatchmakingTimeEstimates(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetMatchmakingTimeEstimates // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5381120
	enum class EMatchmakingStatus GetMatchmakingStatus(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetMatchmakingStatus // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5378d00
	struct FMatchmakingSession GetMatchmakingSession(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetMatchmakingSession // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5378c30
	struct FGameServer GetMatchmakingServer(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetMatchmakingServer // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537f2c0
	struct FMatchmakingParameters GetMatchmakingParameters(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetMatchmakingParameters // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537c990
	int64_t GetLastTimeFinishedMatchmakingState(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetLastTimeFinishedMatchmakingState // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537efc0
	bool GetCurrentMatchmakingSession(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.GetCurrentMatchmakingSession // (Native|Event|Public|BlueprintEvent) // @ game+0x537e5a0
	void ForceCancelMatchmaking(struct FString TicketId, struct FMatchmakingCancelParamaters& OptionalParameters); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.ForceCancelMatchmaking // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x537e6f0
	bool ConfirmPartyMatchmaking(struct FString MatchId, struct FString Region, bool bEnableVoice); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.ConfirmPartyMatchmaking // (Native|Event|Public|BlueprintEvent) // @ game+0x537bf20
	bool CanStartMatchmaking(struct FMatchmakingParameters& Parameters); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.CanStartMatchmaking // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x537a250
	bool CanSkipMatchmaking(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.CanSkipMatchmaking // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b1c860
	bool CanJoinSession(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.CanJoinSession // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x32b2150
	void CancelPollGameServer(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.CancelPollGameServer // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	bool CancelMatchmaking(struct FMatchmakingCancelParamaters& OptionalParameters); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.CancelMatchmaking // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x537f430
	bool CanCancelMatchmaking(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.CanCancelMatchmaking // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537f3c0
	void AbandonCurrentSession(struct FString InMatchId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchmakingModel.AbandonCurrentSession // (Native|Event|Public|BlueprintEvent) // @ game+0x48cfc20
};

// Class OnlineSubsystemAngelscript.DefaultMatchmakingModel
// Size: 0x460 (Inherited: 0x1b0)
struct UDefaultMatchmakingModel : UIEmbarkOnlineMatchmakingModel {
	char pad_1b0[0x2b0]; // 0x1b0(0x2b0)

	void OnPreloadMap(struct FString MapName); // Function OnlineSubsystemAngelscript.DefaultMatchmakingModel.OnPreloadMap // (Final|Native|Protected) // @ game+0x5371da0
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel
// Size: 0x160 (Inherited: 0xb0)
struct UIEmbarkOnlineMentorshipModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnInviteSentCallback; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnAnswerInviteCallback; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnSentInviteSyncedCallback; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnReceivedInviteSyncedCallback; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnEligibleTraineesSyncedCallback; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnMentorshipRemovedCallback; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnInviteReceived; // 0x108(0x10)
	struct FMulticastInlineDelegate OnInviteAnswered; // 0x118(0x10)
	struct FMulticastInlineDelegate OnTraineeRemoved; // 0x128(0x10)
	struct FMulticastInlineDelegate OnSentInviteRemoved; // 0x138(0x10)
	struct FMulticastInlineDelegate OnReceivedInviteRemoved; // 0x148(0x10)

	void SyncMentorshipSentInvites(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.SyncMentorshipSentInvites // (Native|Event|Public|BlueprintEvent) // @ game+0x29f4230
	void SyncMentorshipReceivedInvites(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.SyncMentorshipReceivedInvites // (Native|Event|Public|BlueprintEvent) // @ game+0x2f60440
	void SyncEligibleTrainees(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.SyncEligibleTrainees // (Native|Event|Public|BlueprintEvent) // @ game+0x32add10
	void SendMentorshipInviteByDisplayName(struct FString DisplayName, struct FString DisplayNameDiscriminator); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.SendMentorshipInviteByDisplayName // (Native|Event|Public|BlueprintEvent) // @ game+0x538af50
	void SendMentorshipInvite(struct UServicePlayerProfile* Trainee); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.SendMentorshipInvite // (Native|Event|Public|BlueprintEvent) // @ game+0x2a57b60
	void RemoveMentorship(struct FTenancyUserId& UserId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.RemoveMentorship // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538b300
	struct TArray<struct UServicePlayerProfile*> GetTrainees(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.GetTrainees // (Native|Event|Public|BlueprintEvent) // @ game+0x538b760
	struct TArray<struct UMentorshipInvite*> GetMentorshipSentInvites(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.GetMentorshipSentInvites // (Native|Event|Public|BlueprintEvent) // @ game+0x538a4f0
	struct TArray<struct UMentorshipInvite*> GetMentorshipReceivedInvites(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.GetMentorshipReceivedInvites // (Native|Event|Public|BlueprintEvent) // @ game+0x3236570
	struct UServicePlayerProfile* GetMentor(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.GetMentor // (Native|Event|Public|BlueprintEvent) // @ game+0x53745b0
	struct TArray<struct UServicePlayerProfile*> GetElligbleTrainees(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.GetElligbleTrainees // (Native|Event|Public|BlueprintEvent) // @ game+0x538e1f0
	void AnswerMentorshipInvite(struct UServicePlayerProfile* Mentor, bool bAccept); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMentorshipModel.AnswerMentorshipInvite // (Native|Event|Public|BlueprintEvent) // @ game+0x538aad0
};

// Class OnlineSubsystemAngelscript.DefaultMentorshipModel
// Size: 0x1c0 (Inherited: 0x160)
struct UDefaultMentorshipModel : UIEmbarkOnlineMentorshipModel {
	struct TArray<struct UMentorshipInvite*> SentInvites; // 0x158(0x10)
	struct TArray<struct UMentorshipInvite*> ReceivedInvites; // 0x168(0x10)
	struct TArray<struct UServicePlayerProfile*> EligibleTrainees; // 0x178(0x10)
	char pad_190[0x30]; // 0x190(0x30)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface
// Size: 0x100 (Inherited: 0xb0)
struct UIEmbarkOnlineMatchSessionInterface : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnCreateGameMatchCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnJoinGameMatchComplete; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnGameMatchStatusUpdateComplete; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnUpdateGameMatchDetailsComplete; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnGameMatchReportComplete; // 0xe8(0x10)

	void UpdateMatchStatus_LocalPlayer(struct FString Match, enum class EEmbarkUpdateGameMatchStatus Status); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.UpdateMatchStatus_LocalPlayer // (Native|Event|Public|BlueprintEvent) // @ game+0x538dc00
	void UpdateMatchStatus(struct FUniqueNetIdRepl& Sender, struct FString Match, enum class EEmbarkUpdateGameMatchStatus Status); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.UpdateMatchStatus // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538bcd0
	void UpdateMatchDetails_LocalPlayer(struct FString Match, struct FEmbarkGameMatchRoster& Roster); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.UpdateMatchDetails_LocalPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538c530
	void UpdateMatchDetails(struct FUniqueNetIdRepl& Sender, struct FString Match, struct FEmbarkGameMatchRoster& Roster); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.UpdateMatchDetails // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5387740
	void ReportMatchResults_LocalPlayer(struct FString Match, struct FEmbarkFinalGameMatchReport& MatchReport); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.ReportMatchResults_LocalPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538b9f0
	void ReportMatchResults(struct FUniqueNetIdRepl& Sender, struct FString Match, struct FEmbarkFinalGameMatchReport& MatchReport); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.ReportMatchResults // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5389ea0
	void LeaveMatch_LocalPlayer(struct FString Match, struct TArray<struct FEmbarkLeaveGameMatchPlayer>& LeaveData); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.LeaveMatch_LocalPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538be90
	void LeaveMatch(struct FUniqueNetIdRepl& Sender, struct FString Match, struct TArray<struct FEmbarkLeaveGameMatchPlayer>& LeaveData); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.LeaveMatch // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5383e10
	void JoinMatch_LocalPlayer(struct FString Match, struct TArray<struct FEmbarkJoinGameMatchPlayer>& JoinData); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.JoinMatch_LocalPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538b860
	void JoinMatch(struct FUniqueNetIdRepl& Sender, struct FString Match, struct TArray<struct FEmbarkJoinGameMatchPlayer>& JoinData); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.JoinMatch // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5383a00
	void CreateMatch_LocalPlayer(struct FEmbarkGameMatchesData& MatchesData); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.CreateMatch_LocalPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53854f0
	void CreateMatch(struct FUniqueNetIdRepl& Sender, struct FEmbarkGameMatchesData& MatchesData); // Function OnlineSubsystemAngelscript.IEmbarkOnlineMatchSessionInterface.CreateMatch // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538dd10
};

// Class OnlineSubsystemAngelscript.DefaultOnlineMatchSessionModel
// Size: 0x120 (Inherited: 0x100)
struct UDefaultOnlineMatchSessionModel : UIEmbarkOnlineMatchSessionInterface {
	char pad_100[0x20]; // 0x100(0x20)
};

// Class OnlineSubsystemAngelscript.DefaultPartyModel
// Size: 0xd0 (Inherited: 0xb0)
struct UDefaultPartyModel : UEmbarkOnlineServiceBase {
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel
// Size: 0xe0 (Inherited: 0xb0)
struct UIEmbarkOnlinePersistentPlayerKeysModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncPersistentPlayerKeysCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnSetPersistentPlayerKey; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnCommitPersistentPlayerKeysCompleted; // 0xc8(0x10)

	void SyncPersistentPlayerKeys(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.SyncPersistentPlayerKeys // (Native|Event|Public|BlueprintEvent) // @ game+0x2f60440
	void SetPersistentPlayerKey(struct FGameplayTag& Key, struct FString Value); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.SetPersistentPlayerKey // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538b650
	bool HasPersistentPlayerKey(struct FGameplayTag& Key); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.HasPersistentPlayerKey // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x538aca0
	bool HasPendingMutations(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.HasPendingMutations // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x538cf70
	bool HasCompletedSync(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.HasCompletedSync // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5384830
	struct FString GetPersistentPlayerKey(struct FGameplayTag& Key); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.GetPersistentPlayerKey // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5384030
	bool CommitOperations(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.CommitOperations // (Native|Event|Public|BlueprintEvent) // @ game+0x340c590
	void ClearPersistentPlayerKeys(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePersistentPlayerKeysModel.ClearPersistentPlayerKeys // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
};

// Class OnlineSubsystemAngelscript.DefaultPersistentPlayerKeysModel
// Size: 0x1a0 (Inherited: 0xe0)
struct UDefaultPersistentPlayerKeysModel : UIEmbarkOnlinePersistentPlayerKeysModel {
	char pad_e0[0xc0]; // 0xe0(0xc0)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlinePlayerActivityModel
// Size: 0xe0 (Inherited: 0xb0)
struct UIEmbarkOnlinePlayerActivityModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncPlayerActivityCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnAbandonMatchCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnCancelMatchmakingCompleted; // 0xc8(0x10)

	bool SyncPlayerActivity(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePlayerActivityModel.SyncPlayerActivity // (Native|Event|Public|BlueprintEvent) // @ game+0x48d40b0
	struct FPlayerActivity GetPlayerActivity(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePlayerActivityModel.GetPlayerActivity // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5391c60
	bool CancelMatchmaking(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePlayerActivityModel.CancelMatchmaking // (Native|Event|Public|BlueprintEvent) // @ game+0x2b960b0
	bool AbandonMatch(); // Function OnlineSubsystemAngelscript.IEmbarkOnlinePlayerActivityModel.AbandonMatch // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd3930
};

// Class OnlineSubsystemAngelscript.DefaultPlayerActivityModel
// Size: 0x160 (Inherited: 0xe0)
struct UDefaultPlayerActivityModel : UIEmbarkOnlinePlayerActivityModel {
	char pad_e0[0x80]; // 0xe0(0x80)
};

// Class OnlineSubsystemAngelscript.EmbarkID
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkID : UObject {

	int64_t ToInt64(struct FUniqueNetIdRepl& Value); // Function OnlineSubsystemAngelscript.EmbarkID.ToInt64 // (Final|Native|Static|Public|HasOutParms) // @ game+0x5374190
	struct FUniqueNetIdRepl Invalid(); // Function OnlineSubsystemAngelscript.EmbarkID.Invalid // (Final|Native|Static|Public) // @ game+0x536f090
	struct FUniqueNetIdRepl CreateFromString(struct FString Value); // Function OnlineSubsystemAngelscript.EmbarkID.CreateFromString // (Final|Native|Static|Public) // @ game+0x536fe20
	struct FUniqueNetIdRepl Create(int64_t Value); // Function OnlineSubsystemAngelscript.EmbarkID.Create // (Final|Native|Static|Public) // @ game+0x5375f30
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineClientServices
// Size: 0xc0 (Inherited: 0xa0)
struct UIEmbarkOnlineClientServices : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UProfileCache* ProfileCache; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)

	void ShowExternalUI(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.ShowExternalUI // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b95cb0
	bool IsInTestMode(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.IsInTestMode // (Final|Native|Static|Public) // @ game+0x5198790
	struct USharedVoiceChatModel* GetVoiceChatModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetVoiceChatModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2c582c0
	struct USharedSocialModel* GetSocialModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetSocialModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5374160
	struct UIEmbarkOnlinePlayerActivityModel* GetPlayerActivityModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetPlayerActivityModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376210
	struct UIEmbarkOnlinePersistentPlayerKeysModel* GetPersistentPlayerKeysModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetPersistentPlayerKeysModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5378330
	struct UDefaultPartyModel* GetPartyModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetPartyModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5375c00
	struct UIEmbarkOnlineMentorshipModel* GetMentorshipModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetMentorshipModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5374580
	struct UIEmbarkOnlineMatchmakingModel* GetMatchmakingModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetMatchmakingModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5373240
	struct UIEmbarkOnlineMatchSessionInterface* GetMatchesModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetMatchesModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2a01890
	struct UIEmbarkOnlineManifestModel* GetManifestModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetManifestModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5374740
	struct UIEmbarkOnlineLocalizationModel* GetLocalizationModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetLocalizationModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2c546d0
	struct UIEmbarkOnlineInventoryModel* GetInventoryModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetInventoryModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376240
	struct UDefaultInboxServiceModel* GetInboxServiceModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetInboxServiceModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5374e70
	struct USharedIdentityModel* GetIdentityModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetIdentityModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53751e0
	struct UIEmbarkOnlineGameSettingsModel* GetGameSettingsModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetGameSettingsModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53745b0
	struct UEmbarkHttpContext* GetContext(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetContext // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x38206c0
	struct USharedClanModel* GetClanModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetClanModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3245140
	struct UIEmbarkOnlineBuildModel* GetBuildModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetBuildModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376880
	struct UIEmbarkOnlineAnnouncementsModel* GetAnnouncementsModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetAnnouncementsModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376e30
	struct USharedAchievementsModel* GetAchievementsModel(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.GetAchievementsModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2a00080
	struct UIEmbarkOnlineClientServices* Get(struct UObject* InObj); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.Get // (Final|Native|Static|Public) // @ game+0x536fa90
	void Deinitialize(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineClientServices.Deinitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x3b0f2e0
};

// Class OnlineSubsystemAngelscript.EmbarkOnlineGameSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkOnlineGameSettings : UObject {
	struct TArray<struct FApiGatewaySharedGameSettingEntry> Entries; // 0x98(0x10)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel
// Size: 0x110 (Inherited: 0xb0)
struct UIEmbarkOnlineInventoryModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncInventoryComplete; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnInventoryChanged; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnUserInventoryChanged; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnClientTournamentsInventoriesCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnlineModelQuestDescriptionComplete; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnRestoreRoundLockedItemsComplete; // 0xf8(0x10)

	void SyncQuestDescription(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.SyncQuestDescription // (Native|Event|Public|BlueprintEvent) // @ game+0x2d0aea0
	void SyncInventory(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.SyncInventory // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void SyncActiveTournamentInventories(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.SyncActiveTournamentInventories // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	void RestoreRoundLockedItems(struct FString RoundId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.RestoreRoundLockedItems // (Native|Event|Public|BlueprintEvent) // @ game+0x537bb70
	struct UInventoryServiceInventory* GetPlayerTournamentInventory(struct FUniqueNetIdRepl& PartyMemberNetId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.GetPlayerTournamentInventory // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x53794f0
	struct UInventoryServiceInventory* GetInventory(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.GetInventory // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2c546d0
	void ClearCurrentTournamentInventories(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineInventoryModel.ClearCurrentTournamentInventories // (Native|Event|Public|BlueprintEvent) // @ game+0x16fe6f0
};

// Class OnlineSubsystemAngelscript.EmbarkOnlineLocalization
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkOnlineLocalization : UObject {
	struct TArray<struct FApiGatewaySharedLocalizationEntry> Entries; // 0x98(0x10)
};

// Class OnlineSubsystemAngelscript.IEmbarkOnlineServerServices
// Size: 0x330 (Inherited: 0xa0)
struct UIEmbarkOnlineServerServices : UObject {
	struct FMulticastInlineDelegate OnTweakablesSuccessResponse; // 0x98(0x10)
	struct FMulticastInlineDelegate OnTweakablesErrorResponse; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnReportDisconnectedPlayerCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnUpdateBackfillStateCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnReportServerHeartbeatCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnBatchGetPlayerActivityCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnBatchUpdatePlayerActivityFinishMatchCompleted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnBatchUpdatePlayerActivityAbandonMatchCompleted; // 0x108(0x10)
	struct FMulticastInlineDelegate OnSyncPersistentPlayerKeysCompleted; // 0x118(0x10)
	struct FMulticastInlineDelegate OnSyncGameSettingsCompleted; // 0x128(0x10)
	struct UEmbarkHttpContext* GatewayContext; // 0x138(0x08)
	struct UServiceManifest* ManifestData; // 0x140(0x08)
	struct TArray<struct FApiGatewaySharedServerTweakables> Tweakables; // 0x148(0x10)
	struct UEmbarkOnlineGameSettings* GameSettings; // 0x158(0x08)
	char pad_168[0x178]; // 0x168(0x178)
	struct TMap<struct FTenancyUserId, struct FApiGatewaySharedServerProfile> LoadedPlayerProfiles; // 0x2e0(0x50)

	void UpdateBackfillState(struct FString MatchId, bool bIsBackfillOpen); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.UpdateBackfillState // (Native|Event|Public|BlueprintEvent) // @ game+0x5391830
	void SyncPersistentPlayerKeys(struct TArray<struct FUniqueNetIdRepl>& PlayerIds); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.SyncPersistentPlayerKeys // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53973d0
	void SyncGameSettings(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.SyncGameSettings // (Native|Event|Public|BlueprintEvent) // @ game+0x5390860
	void SetServerIpAddress(struct FString ServerIp); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.SetServerIpAddress // (Native|Event|Public|BlueprintEvent) // @ game+0x48d0f10
	void SetPersistentSquadVoipBaseId(struct FString InPersistentSquadVoipBaseId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.SetPersistentSquadVoipBaseId // (Native|Event|Public|BlueprintEvent) // @ game+0x5391220
	void ReportServerHeartbeat(struct FString MatchId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.ReportServerHeartbeat // (Native|Event|Public|BlueprintEvent) // @ game+0x537d550
	void ReportPlayerDisconnected(struct FString MatchId, struct FUniqueNetIdRepl& PlayerId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.ReportPlayerDisconnected // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53938a0
	bool RegisterSquadsFromAnnotation(struct FString JsonBlob); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.RegisterSquadsFromAnnotation // (Native|Event|Public|BlueprintEvent) // @ game+0x538eed0
	bool RegisterPlayerToSquad(struct FString SquadId, struct FUniqueNetIdRepl& NetId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.RegisterPlayerToSquad // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53930c0
	void QuerySquadVoipChannelsForRegisteredSquads(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.QuerySquadVoipChannelsForRegisteredSquads // (Native|Event|Public|BlueprintEvent) // @ game+0x5393a40
	void QuerySquadVoipChannelsBySquadIds(struct TArray<struct FString>& SquadIds); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.QuerySquadVoipChannelsBySquadIds // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53928b0
	void QuerySquadVoipChannelsByPlayerId(struct FString SquadId, struct FUniqueNetIdRepl& NetId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.QuerySquadVoipChannelsByPlayerId // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53914c0
	void QueryProximityVoipChannel(struct FUniqueNetIdRepl& NetId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.QueryProximityVoipChannel // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5393260
	void KickPlayerFromSquadVoipChannelWithPersistentCheck(struct FUniqueNetIdRepl& NetId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.KickPlayerFromSquadVoipChannelWithPersistentCheck // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x539a1a0
	void KickPlayerFromSquadVoipChannel(struct FUniqueNetIdRepl& NetId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.KickPlayerFromSquadVoipChannel // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538e610
	bool IsSquadRegistered(struct FString SquadId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.IsSquadRegistered // (Native|Event|Public|BlueprintEvent) // @ game+0x5395500
	bool IsInTestMode(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.IsInTestMode // (Final|Native|Static|Public) // @ game+0x5198790
	struct UIEmbarkOnlineServerServices* Initialize(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x38438c0
	void IncreaseMatchSize(struct FString MatchId, int64_t AddedCapacity); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.IncreaseMatchSize // (Native|Event|Public|BlueprintEvent) // @ game+0x5397150
	bool HasPersistentPlayerKeys(struct TArray<struct FUniqueNetIdRepl>& PlayerIds); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.HasPersistentPlayerKeys // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5394860
	bool GetTweakablesAsync(struct FString MatchmakingScenarioID); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetTweakablesAsync // (Native|Event|Public|BlueprintEvent) // @ game+0x538fa70
	bool GetSquadVoipChannel(struct FUniqueNetIdRepl& NetId, struct FVoiceChannelInfo& OutVoiceChannelInfo); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetSquadVoipChannel // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x53912d0
	bool GetRegisteredSquads(struct TMap<struct FString, struct FOnlineSquadInfo>& OutSquads); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetRegisteredSquads // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5392ea0
	bool GetProximityVoipChannel(struct FUniqueNetIdRepl& NetId, struct FVoiceChannelInfo& OutVoiceChannelInfo); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetProximityVoipChannel // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x538e750
	struct FPlayerPersistentKeysMap GetPersistentPlayerKeys(struct FUniqueNetIdRepl& PlayerId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetPersistentPlayerKeys // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x53903f0
	struct FString GetPersistentPlayerKey(struct FUniqueNetIdRepl& PlayerId, struct FGameplayTag InTag); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetPersistentPlayerKey // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5392710
	struct UServiceManifest* GetManifest(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetManifest // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x538f470
	struct UEmbarkOnlineGameSettings* GetGameSettings(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetGameSettings // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537efc0
	struct UEmbarkHttpContext* GetContext(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.GetContext // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5393670
	struct UIEmbarkOnlineServerServices* Get(struct UObject* WorldContextObject); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.Get // (Final|Native|Static|Public) // @ game+0x538ea20
	void Deinitialize(); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.Deinitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x2f6f690
	void BatchUpdatePlayerActivityOnFinishMatch(struct TArray<struct FUniqueNetIdRepl>& PlayerIds, struct FString MatchId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.BatchUpdatePlayerActivityOnFinishMatch // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5398690
	void BatchUpdatePlayerActivityOnAbandonMatch(struct TArray<struct FUniqueNetIdRepl>& PlayerIds, struct FString MatchId); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.BatchUpdatePlayerActivityOnAbandonMatch // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x538f010
	void BatchGetPlayerActivity(struct TArray<struct FUniqueNetIdRepl>& PlayerIds); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.BatchGetPlayerActivity // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5399d20
	void ArrangeParty(struct TArray<struct FTenancyUserId>& PlayerIds, struct FDelegate& ArrangePartyCompletedDelegate); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.ArrangeParty // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x5391940
	bool ApplyManifest(struct FString ManifestContent); // Function OnlineSubsystemAngelscript.IEmbarkOnlineServerServices.ApplyManifest // (Native|Event|Public|BlueprintEvent) // @ game+0x538fec0
};

// Class OnlineSubsystemAngelscript.EmbarkOnlineServerSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkOnlineServerSubsystem : UGameInstanceSubsystem {
	struct UIEmbarkOnlineServerServices* ServerServices; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)

	void AddDependancyIfCreating(struct UObject* InOuter, struct TArray<struct USubsystem*>& OutDependencies); // Function OnlineSubsystemAngelscript.EmbarkOnlineServerSubsystem.AddDependancyIfCreating // (Final|Native|Static|Public|HasOutParms) // @ game+0x5398cd0
};

// Class OnlineSubsystemAngelscript.VoiceRoomBase
// Size: 0x2a0 (Inherited: 0xa0)
struct UVoiceRoomBase : UObject {
	char pad_a0[0x200]; // 0xa0(0x200)
};

// Class OnlineSubsystemAngelscript.EOSVoiceRoom
// Size: 0x340 (Inherited: 0x2a0)
struct UEOSVoiceRoom : UVoiceRoomBase {
	char pad_2a0[0x10]; // 0x2a0(0x10)
	struct UIEOSRTCInterface* EosRtcInterface; // 0x2b0(0x08)
	struct UIEOSAudioInterface* EosAudioInterface; // 0x2b8(0x08)
	struct UEmbarkHttpContext* HttpContext; // 0x2c0(0x08)
	char pad_2c8[0x78]; // 0x2c8(0x78)
};

// Class OnlineSubsystemAngelscript.GDKUserBlocker
// Size: 0xe0 (Inherited: 0xb0)
struct UGDKUserBlocker : UVoiceChatModelUserBlocker {
	char pad_b0[0x30]; // 0xb0(0x30)
};

// Class OnlineSubsystemAngelscript.EmbarkOnlineClientSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkOnlineClientSubsystem : ULocalPlayerSubsystem {
	struct UIEmbarkOnlineClientServices* ClientServices; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class OnlineSubsystemAngelscript.SharedSocialModel
// Size: 0x660 (Inherited: 0xb0)
struct USharedSocialModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnBlockedUsersSynced; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnPlatformBlockedUsersSynced; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnPlatformMutedUsersSynced; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnRecentPlayersSynced; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnFriendsListChanged; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnPresenceArrayUpdated; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnSuggestedFriendsListChanged; // 0x108(0x10)
	struct FMulticastInlineDelegate OnRecentPlayersChanged; // 0x118(0x10)
	struct FMulticastInlineDelegate OnPartyCreated; // 0x128(0x10)
	struct FMulticastInlineDelegate OnPartyInvitationSent; // 0x138(0x10)
	struct FMulticastInlineDelegate OnIncomingPartyInvitation; // 0x148(0x10)
	struct FMulticastInlineDelegate OnIncomingPartyInvitationsChanged; // 0x158(0x10)
	struct FMulticastInlineDelegate OnOutgoingPartyInvitationsChanged; // 0x168(0x10)
	struct FMulticastInlineDelegate OnFriendRequestReceived; // 0x178(0x10)
	struct FMulticastInlineDelegate OnFriendRequestCompleted; // 0x188(0x10)
	struct FMulticastInlineDelegate OnSentFriendRequestAccepted; // 0x198(0x10)
	struct FMulticastInlineDelegate OnSentFriendRequestDeclined; // 0x1a8(0x10)
	struct FMulticastInlineDelegate OnFriendshipAdded; // 0x1b8(0x10)
	struct FMulticastInlineDelegate OnFriendshipRemoved; // 0x1c8(0x10)
	struct FMulticastInlineDelegate OnPartyInviteCompleted; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnKickPartyMemberCompleted; // 0x1e8(0x10)
	struct FMulticastInlineDelegate OnPartyJoinCompleted; // 0x1f8(0x10)
	struct FMulticastInlineDelegate OnPartyJoined; // 0x208(0x10)
	struct FMulticastInlineDelegate OnPartyLeft; // 0x218(0x10)
	struct FMulticastInlineDelegate OnPartyMemberJoined; // 0x228(0x10)
	struct FMulticastInlineDelegate OnPartyMemberRemoved; // 0x238(0x10)
	struct FMulticastInlineDelegate OnPartyMembersChanged; // 0x248(0x10)
	struct FMulticastInlineDelegate OnBlockedPlayersChanged; // 0x258(0x10)
	struct FMulticastInlineDelegate OnDebugContextReceived; // 0x268(0x10)
	struct FMulticastInlineDelegate OnPartyMemberReadyForMatchmaking; // 0x278(0x10)
	struct FMulticastInlineDelegate OnPartyMemberPlatformSet; // 0x288(0x10)
	struct FMulticastInlineDelegate OnSendChatMessageCompleted; // 0x298(0x10)
	struct FMulticastInlineDelegate OnSendPartyChatMessageCompleted; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnSendPrivateLobbyChatMessageCompleted; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnSendSquadChatMessageCompleted; // 0x2c8(0x10)
	struct FMulticastInlineDelegate OnSendWhisperChatMessageCompleted; // 0x2d8(0x10)
	struct FMulticastInlineDelegate OnPartyChatMessage; // 0x2e8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyChatMessage; // 0x2f8(0x10)
	struct FMulticastInlineDelegate OnSquadChatMessage; // 0x308(0x10)
	struct FMulticastInlineDelegate OnWhisperChatMessage; // 0x318(0x10)
	struct FMulticastInlineDelegate OnFrontendPartyEffect; // 0x328(0x10)
	struct FMulticastInlineDelegate OnUserPresenceUpdated; // 0x338(0x10)
	struct FMulticastInlineDelegate OnTotalOnlineFriendsCountUpdated; // 0x348(0x10)
	struct FMulticastInlineDelegate OnPartyAttributesUpdated; // 0x358(0x10)
	struct FMulticastInlineDelegate OnPartyPrivacyChanged; // 0x368(0x10)
	struct UServiceRelationshipsList* Relationships; // 0x378(0x08)
	struct UServiceRelationshipsList* SuggestedFriendsList; // 0x380(0x08)
	struct UServiceBlockedPlayersList* MergedBlockedPlayersList; // 0x388(0x08)
	struct UServiceBlockedPlayersList* BlockedEmbarkPlayersList; // 0x398(0x08)
	struct UServiceBlockedPlayersList* BlockedPlatformPlayersList; // 0x3a0(0x08)
	struct UServiceBlockedPlayersList* PlatformMutedPlayersList; // 0x3a8(0x08)
	struct UServiceRecentPlayersList* RecentPlayersList; // 0x3b0(0x08)
	struct UServiceParty* Party; // 0x3b8(0x08)
	struct UServicePartyInvitationsInfo* PartyInvitations; // 0x3c0(0x08)
	struct UServicePartySettings* PartySettings; // 0x3c8(0x08)
	struct UPlayerReporting* PlayerReporting; // 0x3d0(0x08)
	bool bTriedBootToGame; // 0x3d8(0x01)
	char pad_3d9[0xaf]; // 0x3d9(0xaf)
	struct UIEmbarkOnlineMatchmakingModel* OnlineMatchmakingModel; // 0x488(0x08)
	struct UIEmbarkOnlineBuildModel* OnlineBuildModel; // 0x490(0x08)
	struct USharedIdentityModel* IdentityModel; // 0x498(0x08)
	char pad_4a0[0x190]; // 0x4a0(0x190)
	struct FMulticastInlineDelegate OnFriendsListSynced; // 0x630(0x10)
	struct FMulticastInlineDelegate OnPlatformFriendsListSynced; // 0x640(0x10)
	char pad_650[0x10]; // 0x650(0x10)

	void UpdatePartyData(enum class EApiGatewaySharedPartyPrivacy PartyPrivacy, struct FDelegate& OnCompleted, enum class EApiGatewaySharedPartyInvitePermission InvitePermission); // Function OnlineSubsystemAngelscript.SharedSocialModel.UpdatePartyData // (Final|Native|Public|HasOutParms) // @ game+0x53ca720
	void UpdatePartyAttributes(struct TMap<struct FString, struct FString>& Attributes, struct FDelegate& OnCompleted); // Function OnlineSubsystemAngelscript.SharedSocialModel.UpdatePartyAttributes // (Final|Native|Public|HasOutParms) // @ game+0x53ca870
	void UnblockPlayer(struct FTenancyUserId& TenancyUserId, struct FDelegate& OnCompleted); // Function OnlineSubsystemAngelscript.SharedSocialModel.UnblockPlayer // (Final|Native|Public|HasOutParms) // @ game+0x53c5e90
	void TriggerFrontendPartyEffect(struct FApiGatewaySharedTriggerFrontendPartyEffectRequest& RequestBody); // Function OnlineSubsystemAngelscript.SharedSocialModel.TriggerFrontendPartyEffect // (Final|Native|Public|HasOutParms) // @ game+0x53c8910
	void SyncWhisperChatMessages(); // Function OnlineSubsystemAngelscript.SharedSocialModel.SyncWhisperChatMessages // (Final|Native|Public) // @ game+0x53c4500
	void SyncRecentPlayers(); // Function OnlineSubsystemAngelscript.SharedSocialModel.SyncRecentPlayers // (Final|Native|Public) // @ game+0x53c4d90
	void SyncPlatformMutedUsers(); // Function OnlineSubsystemAngelscript.SharedSocialModel.SyncPlatformMutedUsers // (Final|Native|Public) // @ game+0x53c5d60
	void SyncParty(); // Function OnlineSubsystemAngelscript.SharedSocialModel.SyncParty // (Final|Native|Public) // @ game+0x53c9000
	void SyncFriends(); // Function OnlineSubsystemAngelscript.SharedSocialModel.SyncFriends // (Final|Native|Public) // @ game+0x53cbb90
	void SyncBlockedUsers(); // Function OnlineSubsystemAngelscript.SharedSocialModel.SyncBlockedUsers // (Final|Native|Public) // @ game+0x53c9020
	void ShowPlatformProfileUI(struct FUniqueNetIdRepl& Requestor, struct FUniqueNetIdRepl& Requestee); // Function OnlineSubsystemAngelscript.SharedSocialModel.ShowPlatformProfileUI // (Final|Native|Public|HasOutParms) // @ game+0x53c5260
	void SetRichPresenceStatus(struct FString RichPresenceStatus, struct TMap<struct FString, struct FString>& RichPresenceAttributes, struct FString FormattedPresenceStr, bool bHidePresence); // Function OnlineSubsystemAngelscript.SharedSocialModel.SetRichPresenceStatus // (Final|Native|Public|HasOutParms) // @ game+0x53c2130
	void SetReadyForMatchmaking(bool bReadyForMatchmaking); // Function OnlineSubsystemAngelscript.SharedSocialModel.SetReadyForMatchmaking // (Final|Native|Public) // @ game+0x53c6270
	void SetCrossPlayEnabled(bool bEnabled); // Function OnlineSubsystemAngelscript.SharedSocialModel.SetCrossPlayEnabled // (Final|Native|Public) // @ game+0x53ca5c0
	int32_t SendWhisperChatMessage(struct FTenancyUserId& ToTenancyUserId, struct FString Message); // Function OnlineSubsystemAngelscript.SharedSocialModel.SendWhisperChatMessage // (Final|Native|Public|HasOutParms) // @ game+0x53caf30
	int32_t SendSquadChatMessage(struct FString SquadId, struct TArray<struct FTenancyUserId>& ToPlayers, struct FString Message); // Function OnlineSubsystemAngelscript.SharedSocialModel.SendSquadChatMessage // (Final|Native|Public|HasOutParms) // @ game+0x53c4a80
	int32_t SendPrivateLobbyChatMessage(struct FString Message); // Function OnlineSubsystemAngelscript.SharedSocialModel.SendPrivateLobbyChatMessage // (Final|Native|Public) // @ game+0x53ca0e0
	int32_t SendPartyChatMessage(struct FString Message); // Function OnlineSubsystemAngelscript.SharedSocialModel.SendPartyChatMessage // (Final|Native|Public) // @ game+0x53c5520
	void SendChatMessage(struct FString Message); // Function OnlineSubsystemAngelscript.SharedSocialModel.SendChatMessage // (Final|Native|Public) // @ game+0x53c8640
	void RequestFriendshipByName(struct FString DisplayName, struct FString DisplayNameDiscriminator); // Function OnlineSubsystemAngelscript.SharedSocialModel.RequestFriendshipByName // (Final|Native|Public) // @ game+0x53c5d80
	void ReportPlayer(struct FTenancyUserId& TenancyUserId, enum class EReportPlayerReason ReportReason, struct FString Message); // Function OnlineSubsystemAngelscript.SharedSocialModel.ReportPlayer // (Final|Native|Public|HasOutParms) // @ game+0x53cb730
	void LeaveParty(); // Function OnlineSubsystemAngelscript.SharedSocialModel.LeaveParty // (Final|Native|Public) // @ game+0x53c9370
	void KickFromParty(struct FTenancyUserId& UserId); // Function OnlineSubsystemAngelscript.SharedSocialModel.KickFromParty // (Final|Native|Public|HasOutParms) // @ game+0x53c5880
	void JoinParty(struct FString PartyId, struct FDiscordJoinSecret JoinSecret, bool bIsOpenParty); // Function OnlineSubsystemAngelscript.SharedSocialModel.JoinParty // (Final|Native|Public) // @ game+0x53c7ba0
	bool IsPlayerFriendOnPlatform(struct UServicePlayerProfile* Player); // Function OnlineSubsystemAngelscript.SharedSocialModel.IsPlayerFriendOnPlatform // (Final|Native|Public|Const) // @ game+0x53c3da0
	bool IsPlayerBlockedOnPlatform(struct UServicePlayerProfile* Player); // Function OnlineSubsystemAngelscript.SharedSocialModel.IsPlayerBlockedOnPlatform // (Final|Native|Public|Const) // @ game+0x53cb680
	bool IsPartyMemberReadyForMatchmaking(struct FTenancyUserId& TenancyUserId); // Function OnlineSubsystemAngelscript.SharedSocialModel.IsPartyMemberReadyForMatchmaking // (Final|Native|Public|HasOutParms|Const) // @ game+0x53c35c0
	bool IsPartyLeader(struct FTenancyUserId& MemberTenancyId); // Function OnlineSubsystemAngelscript.SharedSocialModel.IsPartyLeader // (Final|Native|Public|HasOutParms) // @ game+0x53c8730
	bool IsCrossplayEnabledForPartyMember(struct FTenancyUserId& TenancyUserId); // Function OnlineSubsystemAngelscript.SharedSocialModel.IsCrossplayEnabledForPartyMember // (Final|Native|Public|HasOutParms|Const) // @ game+0x53c9880
	bool IsCrossplayEnabledForAllPartyMembers(); // Function OnlineSubsystemAngelscript.SharedSocialModel.IsCrossplayEnabledForAllPartyMembers // (Final|Native|Public|Const) // @ game+0x53c91c0
	void InviteToParty(struct UServicePlayerProfile* Profile); // Function OnlineSubsystemAngelscript.SharedSocialModel.InviteToParty // (Final|Native|Public) // @ game+0x53c4460
	bool HasTriedBootToGame(); // Function OnlineSubsystemAngelscript.SharedSocialModel.HasTriedBootToGame // (Final|Native|Public) // @ game+0x53c3ae0
	struct TArray<struct FApiGatewaySharedChatMessage> GetWhisperChatMessages(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetWhisperChatMessages // (Final|Native|Public) // @ game+0x53c13c0
	int32_t GetTotalOnlineFriendsCount(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetTotalOnlineFriendsCount // (Final|Native|Public|Const) // @ game+0x53c23b0
	struct UServiceRelationshipsList* GetSuggestedFriendsList(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetSuggestedFriendsList // (Final|Native|Public|Const) // @ game+0x53c6900
	struct UServiceRelationshipsList* GetRelationships(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetRelationships // (Final|Native|Public|Const) // @ game+0x53ca550
	struct UServiceRecentPlayersList* GetRecentPlayersList(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetRecentPlayersList // (Final|Native|Public|Const) // @ game+0x53c9970
	struct UServiceBlockedPlayersList* GetPlatformMutedPlayersList(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetPlatformMutedPlayersList // (Final|Native|Public|Const) // @ game+0x53c41e0
	struct UServicePartySettings* GetPartySettings(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetPartySettings // (Final|Native|Public|Const) // @ game+0x53c61c0
	struct UServiceParty* GetParty(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetParty // (Final|Native|Public|Const) // @ game+0x53cbaa0
	struct UServicePartyInvitationsInfo* GetInvitationsInfo(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetInvitationsInfo // (Final|Native|Public|Const) // @ game+0x53c9730
	struct UServiceBlockedPlayersList* GetBlockedPlayersList(); // Function OnlineSubsystemAngelscript.SharedSocialModel.GetBlockedPlayersList // (Native|Public) // @ game+0x2a01890
	void DeleteFriendship(struct UServiceRelationship* Relationship); // Function OnlineSubsystemAngelscript.SharedSocialModel.DeleteFriendship // (Final|Native|Public) // @ game+0x53c3910
	void DeclineInvitation(struct FString PartyId); // Function OnlineSubsystemAngelscript.SharedSocialModel.DeclineInvitation // (Final|Native|Public) // @ game+0x53c9a30
	bool CanBlockThroughPlatform(); // Function OnlineSubsystemAngelscript.SharedSocialModel.CanBlockThroughPlatform // (Final|Native|Public|Const) // @ game+0x5198790
	void BlockPlayer(struct FTenancyUserId& TenancyUserId, struct FDelegate& OnCompleted); // Function OnlineSubsystemAngelscript.SharedSocialModel.BlockPlayer // (Final|Native|Public|HasOutParms) // @ game+0x53c9ae0
	void AddRecentPlayers(struct TArray<struct FUniqueNetIdRepl>& TenancyUserIds); // Function OnlineSubsystemAngelscript.SharedSocialModel.AddRecentPlayers // (Final|Native|Public|HasOutParms) // @ game+0x53c15f0
	void AcceptFriendship(struct UServiceRelationship* Relationship); // Function OnlineSubsystemAngelscript.SharedSocialModel.AcceptFriendship // (Final|Native|Public) // @ game+0x53c0e70
};

// Class OnlineSubsystemAngelscript.MockEmbarkOnlineSocialModel
// Size: 0x660 (Inherited: 0x660)
struct UMockEmbarkOnlineSocialModel : USharedSocialModel {
	struct UServiceBlockedPlayersList* BlockedPlayersList; // 0x658(0x08)
};

// Class OnlineSubsystemAngelscript.MockEOSRTCInterface
// Size: 0x190 (Inherited: 0xa0)
struct UMockEOSRTCInterface : UIEOSRTCInterface {
	char pad_a0[0xe8]; // 0xa0(0xe8)
	struct UMockEOSAudioInterface* MockAudioInterface; // 0x188(0x08)
};

// Class OnlineSubsystemAngelscript.MockEOSAudioInterface
// Size: 0x1f0 (Inherited: 0xa0)
struct UMockEOSAudioInterface : UIEOSAudioInterface {
	char pad_a0[0x150]; // 0xa0(0x150)
};

// Class OnlineSubsystemAngelscript.ServiceAnnouncements
// Size: 0xb0 (Inherited: 0xa0)
struct UServiceAnnouncements : UObject {
	struct TArray<struct FApiGatewaySharedAnnouncement> Announcements; // 0x98(0x10)
};

// Class OnlineSubsystemAngelscript.Clan
// Size: 0x130 (Inherited: 0xa0)
struct UClan : UObject {
	bool bIsOfficial; // 0x98(0x01)
	struct TArray<struct FString> SearchTags; // 0xa0(0x10)
	struct FString ClanId; // 0xb0(0x10)
	enum class EClanPrivacy Privacy; // 0xc0(0x01)
	char pad_c2[0x2]; // 0xc2(0x02)
	int32_t Membership; // 0xc4(0x04)
	int32_t MaxSize; // 0xc8(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)
	struct TArray<struct UClanMember*> Members; // 0xd0(0x10)
	struct UClanCustomizationData* CustomizationData; // 0xe0(0x08)
	struct UServicePlayerProfile* LeaderProfile; // 0xe8(0x08)
	char pad_f0[0x40]; // 0xf0(0x40)

	struct TArray<struct UClanMember*> GetMembersOfRole(struct FString Role); // Function OnlineSubsystemAngelscript.Clan.GetMembersOfRole // (Final|Native|Public|Const) // @ game+0x539cf20
	struct FString GetClanTag(bool bForceRealTag); // Function OnlineSubsystemAngelscript.Clan.GetClanTag // (Final|Native|Public|Const) // @ game+0x539aa70
	struct FString GetClanName(bool bForceRealName); // Function OnlineSubsystemAngelscript.Clan.GetClanName // (Final|Native|Public|Const) // @ game+0x539fe30
	struct TArray<struct UClanMember*> GetAllMembers(); // Function OnlineSubsystemAngelscript.Clan.GetAllMembers // (Final|Native|Public|Const) // @ game+0x539ef80
};

// Class OnlineSubsystemAngelscript.OfficialClanInfo
// Size: 0xd0 (Inherited: 0xa0)
struct UOfficialClanInfo : UObject {
	struct FString ClanId; // 0x98(0x10)
	struct FString ClanName; // 0xa8(0x10)
	struct FString ClanTag; // 0xb8(0x10)
	int64_t ClanLogo; // 0xc8(0x08)
};

// Class OnlineSubsystemAngelscript.ClanMember
// Size: 0xc0 (Inherited: 0xa0)
struct UClanMember : UObject {
	struct FString Role; // 0x98(0x10)
	struct UServicePlayerProfile* Profile; // 0xa8(0x08)
	struct FTenancyUserId TenancyUserId; // 0xb0(0x10)
};

// Class OnlineSubsystemAngelscript.ClanInvite
// Size: 0x100 (Inherited: 0xa0)
struct UClanInvite : UObject {
	struct FString ClanName; // 0x98(0x10)
	struct FString ClanId; // 0xa8(0x10)
	struct UServicePlayerProfile* RecieverProfile; // 0xb8(0x08)
	struct UServicePlayerProfile* SenderProfile; // 0xc0(0x08)
	struct FString CreatedAt; // 0xc8(0x10)
	int64_t ClanLogo; // 0xd8(0x08)
	int64_t ClanBorder; // 0xe0(0x08)
	int64_t ClanBackground; // 0xe8(0x08)
	int64_t ClanMembership; // 0xf0(0x08)
};

// Class OnlineSubsystemAngelscript.ClanTimelineMessage
// Size: 0x110 (Inherited: 0xa0)
struct UClanTimelineMessage : UObject {
	struct FTenancyUserId TenancyUserId; // 0x98(0x10)
	struct FString AuthorName; // 0xa8(0x10)
	struct FString ClanId; // 0xb8(0x10)
	struct FString MessageId; // 0xc8(0x10)
	struct FString CreateTime; // 0xd8(0x10)
	struct FString Message; // 0xe8(0x10)
	enum class EClanTimelineMessageType MessageType; // 0xf8(0x01)
	struct UClanTimelinePartyUpMessage* PartyUpMessage; // 0x100(0x08)
	struct UClanTimelineRoleChangedMessage* RoleChangedMessage; // 0x108(0x08)
};

// Class OnlineSubsystemAngelscript.ClanTimelinePartyUpMessage
// Size: 0xd0 (Inherited: 0xa0)
struct UClanTimelinePartyUpMessage : UObject {
	struct FString PartyId; // 0x98(0x10)
	struct FString ExpireAt; // 0xa8(0x10)
	struct FString GameMode; // 0xb8(0x10)
};

// Class OnlineSubsystemAngelscript.ClanTimelineRoleChangedMessage
// Size: 0xc0 (Inherited: 0xa0)
struct UClanTimelineRoleChangedMessage : UObject {
	struct FString OldRole; // 0x98(0x10)
	struct FString NewRole; // 0xa8(0x10)
};

// Class OnlineSubsystemAngelscript.ClanMessage
// Size: 0xf0 (Inherited: 0xa0)
struct UClanMessage : UObject {
	struct FString Message; // 0x98(0x10)
	struct FString PurifiedMessage; // 0xa8(0x10)
	struct FString SentAt; // 0xb8(0x10)
	struct FTenancyUserId SentByUserTenancyID; // 0xc8(0x10)
	struct FString SentByUserName; // 0xd8(0x10)
	bool bIsFlagged; // 0xe8(0x01)
};

// Class OnlineSubsystemAngelscript.JoinClanApplication
// Size: 0x100 (Inherited: 0xa0)
struct UJoinClanApplication : UObject {
	struct FString ClanId; // 0x98(0x10)
	struct FString ClanName; // 0xa8(0x10)
	struct FString ClanTag; // 0xb8(0x10)
	int64_t ClanLogo; // 0xc8(0x08)
	int64_t ClanBorder; // 0xd0(0x08)
	int64_t ClanBackground; // 0xd8(0x08)
	struct UServicePlayerProfile* Profile; // 0xe0(0x08)
	struct FString CreatedAt; // 0xe8(0x10)
};

// Class OnlineSubsystemAngelscript.ClanPlayerInfo
// Size: 0x100 (Inherited: 0xa0)
struct UClanPlayerInfo : UObject {
	struct FTenancyUserId TenancyUserExternalId; // 0x98(0x10)
	struct FString Role; // 0xa8(0x10)
	struct FString ClanId; // 0xb8(0x10)
	struct FString ClanName; // 0xc8(0x10)
	struct FString ClanTag; // 0xd8(0x10)
	int64_t Logo; // 0xe8(0x08)
	bool bIsOfficial; // 0xf0(0x01)
	enum class EClanPrivacy ClanPrivacyMode; // 0xf1(0x01)
	char pad_fa[0x6]; // 0xfa(0x06)
};

// Class OnlineSubsystemAngelscript.ClanCustomizationData
// Size: 0xb0 (Inherited: 0xa0)
struct UClanCustomizationData : UObject {
	int64_t Logo; // 0x98(0x08)
	int64_t Background; // 0xa0(0x08)
	int64_t Border; // 0xa8(0x08)
};

// Class OnlineSubsystemAngelscript.ServiceRelationship
// Size: 0xb0 (Inherited: 0xa0)
struct UServiceRelationship : UObject {
	struct UServicePlayerProfile* Profile; // 0x98(0x08)
	enum class EServiceRelationshipType RelationshipType; // 0xa0(0x01)
	bool bIsEmbarkFriend; // 0xa1(0x01)
	bool bIsPlatformFriend; // 0xa2(0x01)
	char pad_ab[0x5]; // 0xab(0x05)

	bool IsPlatformFriend(); // Function OnlineSubsystemAngelscript.ServiceRelationship.IsPlatformFriend // (Final|Native|Public|Const) // @ game+0x53a0ec0
	bool IsInvite(); // Function OnlineSubsystemAngelscript.ServiceRelationship.IsInvite // (Final|Native|Public|Const) // @ game+0x539f430
	bool IsFriend(); // Function OnlineSubsystemAngelscript.ServiceRelationship.IsFriend // (Final|Native|Public|Const) // @ game+0x53a1e30
	bool IsEmbarkFriend(); // Function OnlineSubsystemAngelscript.ServiceRelationship.IsEmbarkFriend // (Final|Native|Public|Const) // @ game+0x539e210
	bool IsDiscordFriend(); // Function OnlineSubsystemAngelscript.ServiceRelationship.IsDiscordFriend // (Final|Native|Public|Const) // @ game+0x53a0e40
	int32_t Compare(struct UServiceRelationship* Other); // Function OnlineSubsystemAngelscript.ServiceRelationship.Compare // (Final|Native|Public) // @ game+0x539b410
	char CalculateSortingPriority(); // Function OnlineSubsystemAngelscript.ServiceRelationship.CalculateSortingPriority // (Final|Native|Public|Const) // @ game+0x539f640
};

// Class OnlineSubsystemAngelscript.ServiceRelationshipsList
// Size: 0xf0 (Inherited: 0xa0)
struct UServiceRelationshipsList : UObject {
	struct TMap<struct FTenancyUserId, struct UServiceRelationship*> Relationships; // 0x98(0x50)

	bool Remove(struct FTenancyUserId& ID); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.Remove // (Final|Native|Public|HasOutParms) // @ game+0x53a03f0
	void GetFriendsSorted(struct TArray<struct UServiceRelationship*>& OutFriends); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.GetFriendsSorted // (Final|Native|Public|HasOutParms|Const) // @ game+0x539ac70
	struct TMap<struct FTenancyUserId, struct UServiceRelationship*> GetFriends(); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.GetFriends // (Final|Native|Public|Const) // @ game+0x53a2f60
	bool FindFriendByName(struct FString DisplayName, struct FString DisplayNameDiscriminator, struct UServiceRelationship*& Result); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.FindFriendByName // (Final|Native|Public|HasOutParms|Const) // @ game+0x53a2bf0
	bool Find(struct FTenancyUserId& ID, struct UServiceRelationship*& Result); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.Find // (Final|Native|Public|HasOutParms|Const) // @ game+0x539d820
	bool Contains(struct FTenancyUserId& ID); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.Contains // (Final|Native|Public|HasOutParms|Const) // @ game+0x539e780
	void Add(struct UServiceRelationship* Relationship); // Function OnlineSubsystemAngelscript.ServiceRelationshipsList.Add // (Final|Native|Public) // @ game+0x53a3cf0
};

// Class OnlineSubsystemAngelscript.ServiceBlockedPlayersList
// Size: 0xf0 (Inherited: 0xa0)
struct UServiceBlockedPlayersList : UObject {
	struct TMap<struct FTenancyUserId, struct FBlockedPlayerProfile> BlockedPlayers; // 0x98(0x50)
};

// Class OnlineSubsystemAngelscript.ServiceRecentPlayersList
// Size: 0xf0 (Inherited: 0xa0)
struct UServiceRecentPlayersList : UObject {
	struct TMap<struct FTenancyUserId, struct FRecentPlayer> RecentPlayers; // 0x98(0x50)

	struct TArray<struct FRecentPlayer> GetSortedPlayersByLastSeen(); // Function OnlineSubsystemAngelscript.ServiceRecentPlayersList.GetSortedPlayersByLastSeen // (Final|Native|Public) // @ game+0x539ee90
};

// Class OnlineSubsystemAngelscript.DiscordFriendList
// Size: 0xf0 (Inherited: 0xa0)
struct UDiscordFriendList : UObject {
	struct TMap<struct FTenancyUserId, struct FDiscordUserDataView> DiscordFriends; // 0x98(0x50)
};

// Class OnlineSubsystemAngelscript.ServicePartyInvitation
// Size: 0xc0 (Inherited: 0xa0)
struct UServicePartyInvitation : UObject {
	struct FString PartyId; // 0x98(0x10)
	struct UServicePlayerProfile* Profile; // 0xa8(0x08)
	struct FDateTime Timestamp; // 0xb0(0x08)
};

// Class OnlineSubsystemAngelscript.ServicePartyInvitationsInfo
// Size: 0xc0 (Inherited: 0xa0)
struct UServicePartyInvitationsInfo : UObject {
	struct TArray<struct UServicePartyInvitation*> IncomingInvitations; // 0x98(0x10)
	struct TArray<struct UServicePartyInvitation*> OutgoingInvitations; // 0xa8(0x10)
};

// Class OnlineSubsystemAngelscript.ServiceParty
// Size: 0x160 (Inherited: 0xa0)
struct UServiceParty : UObject {
	struct FString PartyId; // 0x98(0x10)
	struct TMap<struct FTenancyUserId, struct UServicePlayerProfile*> PartyMembers; // 0xa8(0x50)
	bool bIsJoinable; // 0xf8(0x01)
	enum class EApiGatewaySharedPartyPrivacy PartyPrivacy; // 0xf9(0x01)
	enum class EApiGatewaySharedPartyInvitePermission InvitePermission; // 0xfa(0x01)
	char pad_103[0xd]; // 0x103(0x0d)
	struct TMap<struct FString, struct FString> PartyAttributes; // 0x110(0x50)

	bool IsValid(); // Function OnlineSubsystemAngelscript.ServiceParty.IsValid // (Final|Native|Public|Const) // @ game+0x539b4c0
	struct TMap<struct FString, struct FString> GetPartyAttributes(); // Function OnlineSubsystemAngelscript.ServiceParty.GetPartyAttributes // (Final|Native|Public|Const) // @ game+0x53a0560
};

// Class OnlineSubsystemAngelscript.ServicePartySettings
// Size: 0xa0 (Inherited: 0xa0)
struct UServicePartySettings : UObject {
	int32_t MaxPartySize; // 0x98(0x04)
};

// Class OnlineSubsystemAngelscript.ServicePlayerProfile
// Size: 0x340 (Inherited: 0xa0)
struct UServicePlayerProfile : UObject {
	struct FEmbarkUserId EmbarkUserId; // 0x98(0x10)
	struct FTenancyUserId TenancyUserId; // 0xa8(0x10)
	struct FString TenancyName; // 0xb8(0x10)
	struct TMap<struct FString, struct FString> RichPresenceAttributes; // 0xc8(0x50)
	struct FPrivateProfileInformation PrivateProfileInfo; // 0x118(0x48)
	struct UTexture2DDynamic* DynamicAvatarTexture; // 0x160(0x08)
	struct FDateTime CreatedAt; // 0x168(0x08)
	struct FString ClanRole; // 0x170(0x10)
	bool bIsMemberOfSameClan; // 0x180(0x01)
	struct FDiscordUserDataView DiscordUserData; // 0x188(0x60)
	struct UServiceRelationship* RelationshipUserData; // 0x1e8(0x08)
	bool bVoiceChatModerationConsent; // 0x1f0(0x01)
	bool bRichPresenceInitialized; // 0x1f1(0x01)
	char pad_1f3[0x5]; // 0x1f3(0x05)
	struct FString DisplayName; // 0x1f8(0x10)
	struct FString DisplayNameDiscriminator; // 0x208(0x10)
	char pad_218[0x128]; // 0x218(0x128)

	void SetRichPresence(struct FString RichPresence); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.SetRichPresence // (Final|Native|Public) // @ game+0x53a8500
	void SetPresence(enum class EServicePlayerOnlineState InOnlineState); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.SetPresence // (Final|Native|Public) // @ game+0x53a6ab0
	void SetPlatformPresence(enum class EServicePlayerOnlineState InOnlineState); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.SetPlatformPresence // (Final|Native|Public) // @ game+0x53a4e70
	bool IsRichPresenceAttributeTrue(struct FString AttribKey); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsRichPresenceAttributeTrue // (Final|Native|Public|Const) // @ game+0x53a9ec0
	bool IsPlatformFriend(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsPlatformFriend // (Final|Native|Public|Const) // @ game+0x53a7fd0
	bool IsOnSamePlatform(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsOnSamePlatform // (Final|Native|Public|Const) // @ game+0x53aa1b0
	bool IsOnlineOnPlatform(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsOnlineOnPlatform // (Final|Native|Public|Const) // @ game+0x53ab6e0
	bool IsOnlineOnDiscord(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsOnlineOnDiscord // (Final|Native|Public|Const) // @ game+0x53a61c0
	bool IsOnlineInGame(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsOnlineInGame // (Final|Native|Public|Const) // @ game+0x53ad0f0
	bool IsOnlineElsewhere(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsOnlineElsewhere // (Final|Native|Public|Const) // @ game+0x53abac0
	bool IsOnline(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsOnline // (Final|Native|Public|Const) // @ game+0x53a4740
	bool IsMe(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsMe // (Final|Native|Public|Const) // @ game+0x53a6690
	bool IsFriend(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsFriend // (Final|Native|Public|Const) // @ game+0x53a6ed0
	bool IsEmbarkFriend(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsEmbarkFriend // (Final|Native|Public|Const) // @ game+0x53ac880
	bool IsDiscordFriend(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.IsDiscordFriend // (Final|Native|Public|Const) // @ game+0x53aa140
	bool HasDiscordLinked(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.HasDiscordLinked // (Final|Native|Public|Const) // @ game+0x53a8fa0
	bool HasDiscordAssociation(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.HasDiscordAssociation // (Final|Native|Public|Const) // @ game+0x53ab730
	struct FString GetRichPresenceString(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetRichPresenceString // (Final|Native|Public|Const) // @ game+0x53a7400
	struct FPresenceInfo GetPreviousPresenceInfo(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetPreviousPresenceInfo // (Final|Native|Public|Const) // @ game+0x53add60
	struct FString GetPreferredDisplayName(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetPreferredDisplayName // (Final|Native|Public|Const) // @ game+0x53ab630
	enum class EServicePlayerOnlineState GetPlatformOnlineState(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetPlatformOnlineState // (Final|Native|Public|Const) // @ game+0x53a50d0
	struct FUniqueNetIdRepl GetPlatformId(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetPlatformId // (Final|Native|Public|Const) // @ game+0x53aabd0
	struct FString GetPlatformDisplayName(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetPlatformDisplayName // (Final|Native|Public|Const) // @ game+0x53abcc0
	enum class EServicePlayerOnlineState GetOnlineState(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetOnlineState // (Final|Native|Public|Const) // @ game+0x53ac350
	struct FPresenceInfo GetCurrentPresenceInfo(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.GetCurrentPresenceInfo // (Final|Native|Public|Const) // @ game+0x53a85b0
	bool DidPresenceChange(); // Function OnlineSubsystemAngelscript.ServicePlayerProfile.DidPresenceChange // (Final|Native|Public|Const) // @ game+0x53a63a0
};

// Class OnlineSubsystemAngelscript.OnlineInboxServiceMessages
// Size: 0xb0 (Inherited: 0xa0)
struct UOnlineInboxServiceMessages : UObject {
	struct TArray<struct FApiGatewaySharedInboxMessage> Messages; // 0x98(0x10)

	bool IsEmpty(); // Function OnlineSubsystemAngelscript.OnlineInboxServiceMessages.IsEmpty // (Final|Native|Public|Const) // @ game+0x53ad610
};

// Class OnlineSubsystemAngelscript.SyncedInventoriesResult
// Size: 0xb0 (Inherited: 0xa0)
struct USyncedInventoriesResult : UObject {
	struct TArray<struct USyncedNamedInventoryData*> PlayerInventories; // 0x98(0x10)
	enum class EInventorySyncInventoryReason Reason; // 0xa8(0x01)
};

// Class OnlineSubsystemAngelscript.SyncedNamedInventoryData
// Size: 0xc0 (Inherited: 0xa0)
struct USyncedNamedInventoryData : UObject {
	struct FString PlayerId; // 0x98(0x10)
	struct TArray<struct UInventoryServiceItemBase*> Items; // 0xa8(0x10)
};

// Class OnlineSubsystemAngelscript.InventoryServiceItemBase
// Size: 0xf0 (Inherited: 0xa0)
struct UInventoryServiceItemBase : UObject {
	struct FString ItemId; // 0x98(0x10)
	int64_t AssetId; // 0xa8(0x08)
	int64_t Generation; // 0xb0(0x08)
	int64_t Amount; // 0xb8(0x08)
	float Durability; // 0xc0(0x04)
	float MaxDurability; // 0xc4(0x04)
	struct FString LockedInRound; // 0xc8(0x10)
	bool bHasSeen; // 0xd8(0x01)
	int64_t CreatedAt; // 0xe0(0x08)
	char pad_e9[0x7]; // 0xe9(0x07)
};

// Class OnlineSubsystemAngelscript.InventoryServiceInventory
// Size: 0x1f0 (Inherited: 0xa0)
struct UInventoryServiceInventory : UObject {
	struct TArray<struct UInventoryServiceItemBase*> Items; // 0x98(0x10)
	struct TMap<struct FString, struct UInventoryServiceItemBase*> ItemByItemIdMap; // 0xa8(0x50)
	char pad_100[0xf0]; // 0x100(0xf0)

	bool UpdateDerivedProperties(); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.UpdateDerivedProperties // (Final|Native|Public) // @ game+0x53abc90
	bool HasItemsByItemType(struct UStruct* ItemType); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.HasItemsByItemType // (Final|Native|Public|Const) // @ game+0x53a6c10
	bool HasItemsByAssetId(int64_t AssetId); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.HasItemsByAssetId // (Final|Native|Public|Const) // @ game+0x53a74e0
	bool HasItemByItemId(struct FString ItemId); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.HasItemByItemId // (Final|Native|Public|Const) // @ game+0x53a65d0
	void GetItemsWithRoundLock(struct FString RoundId, struct TArray<struct UInventoryServiceItemBase*>& OutItems); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.GetItemsWithRoundLock // (Final|Native|Public|HasOutParms|Const) // @ game+0x53a9db0
	void GetItemsByItemType(struct UStruct* ItemType, struct TArray<struct UInventoryServiceItemBase*>& OutItems); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.GetItemsByItemType // (Final|Native|Public|HasOutParms|Const) // @ game+0x53a9ca0
	void GetItemsByAssetId(int64_t AssetId, struct TArray<struct UInventoryServiceItemBase*>& OutItems); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.GetItemsByAssetId // (Final|Native|Public|HasOutParms|Const) // @ game+0x53a4f90
	struct UInventoryServiceItemBase* GetItemByItemType(struct UStruct* ItemType); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.GetItemByItemType // (Final|Native|Public|Const) // @ game+0x53aad20
	struct UInventoryServiceItemBase* GetItemByItemId(struct FString ItemId); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.GetItemByItemId // (Final|Native|Public|Const) // @ game+0x53a4930
	struct UInventoryServiceItemBase* GetItemByAssetId(int64_t AssetId); // Function OnlineSubsystemAngelscript.InventoryServiceInventory.GetItemByAssetId // (Final|Native|Public|Const) // @ game+0x53a7060
};

// Class OnlineSubsystemAngelscript.ServiceManifest
// Size: 0x190 (Inherited: 0xa0)
struct UServiceManifest : UObject {
	int64_t ID; // 0x98(0x08)
	struct FString BuildId; // 0xa0(0x10)
	int64_t PlaytestId; // 0xb0(0x08)
	struct FString PartitioningHash; // 0xb8(0x10)
	struct FString NonPartitioningHash; // 0xc8(0x10)
	struct TMap<struct FString, struct FString> PartitioningBody; // 0xd8(0x50)
	struct TMap<struct FString, struct FString> NonPartitioningBody; // 0x128(0x50)
	int64_t RetrievedAt; // 0x178(0x08)
	int64_t ValidFrom; // 0x180(0x08)
	int64_t ValidUntil; // 0x188(0x08)
};

// Class OnlineSubsystemAngelscript.MentorshipInvite
// Size: 0xc0 (Inherited: 0xa0)
struct UMentorshipInvite : UObject {
	struct UServicePlayerProfile* Mentor; // 0x98(0x08)
	struct UServicePlayerProfile* Trainee; // 0xa0(0x08)
	struct FString CreatedAt; // 0xa8(0x10)
	bool bAccepted; // 0xb8(0x01)
};

// Class OnlineSubsystemAngelscript.OnlineTimeOverrideSubsystem
// Size: 0xe0 (Inherited: 0xa0)
struct UOnlineTimeOverrideSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x40]; // 0xa0(0x40)

	struct FDateTime UtcNow(struct UObject* WorldContextObject); // Function OnlineSubsystemAngelscript.OnlineTimeOverrideSubsystem.UtcNow // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x53b04f0
	bool HasOverride(); // Function OnlineSubsystemAngelscript.OnlineTimeOverrideSubsystem.HasOverride // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x53b5a80
	struct FDateTime GetUtcNow(); // Function OnlineSubsystemAngelscript.OnlineTimeOverrideSubsystem.GetUtcNow // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x53b1dc0
};

// Class OnlineSubsystemAngelscript.PlatformMutedUserBlocker
// Size: 0xc0 (Inherited: 0xb0)
struct UPlatformMutedUserBlocker : UVoiceChatModelUserBlocker {
	struct UServiceBlockedPlayersList* MutedList; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)

	void OnBlockListSynced(bool bSuccess); // Function OnlineSubsystemAngelscript.PlatformMutedUserBlocker.OnBlockListSynced // (Final|Native|Private) // @ game+0x53783e0
};

// Class OnlineSubsystemAngelscript.PlayerReporting
// Size: 0xb0 (Inherited: 0xa0)
struct UPlayerReporting : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class OnlineSubsystemAngelscript.AvatarDeveloperSettings
// Size: 0xd0 (Inherited: 0xb0)
struct UAvatarDeveloperSettings : UDeveloperSettings {
	struct TSoftObjectPtr<UTexture2D> DefaultAvatar; // 0xa8(0x28)
};

// Class OnlineSubsystemAngelscript.ProfileCache
// Size: 0x1a0 (Inherited: 0xa0)
struct UProfileCache : UObject {
	struct TMap<struct FTenancyUserId, struct UServicePlayerProfile*> TenancyUsersProfiles; // 0x98(0x50)
	struct TMap<struct FEmbarkUserId, struct UServicePlayerProfile*> EmbarkUsersProfiles; // 0xe8(0x50)
	char pad_140[0x58]; // 0x140(0x58)
	struct UTexture2DDynamic* DefaultAvatarTextureDynamic; // 0x198(0x08)

	struct UServicePlayerProfile* CreateUpdateProfile(struct FApiGatewaySharedProfile InProfile); // Function OnlineSubsystemAngelscript.ProfileCache.CreateUpdateProfile // (Final|Native|Public) // @ game+0x53aee10
};

// Class OnlineSubsystemAngelscript.ProximityVoipSynthComponent
// Size: 0xa40 (Inherited: 0xa20)
struct UProximityVoipSynthComponent : USynthComponent {
	char pad_a20[0x20]; // 0xa20(0x20)

	void SetPlayerId(struct FTenancyUserId& InPlayerId); // Function OnlineSubsystemAngelscript.ProximityVoipSynthComponent.SetPlayerId // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x53b2900
};

// Class OnlineSubsystemAngelscript.ProximityVoipStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UProximityVoipStatics : UObject {
};

// Class OnlineSubsystemAngelscript.RegexHelper
// Size: 0xa0 (Inherited: 0xa0)
struct URegexHelper : UObject {

	struct FString Replace(struct FString Pattern, struct FString Subject, struct FString Replacement); // Function OnlineSubsystemAngelscript.RegexHelper.Replace // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53ae3e0
	bool Match(struct FString Pattern, struct FString Subject); // Function OnlineSubsystemAngelscript.RegexHelper.Match // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x53ae710
};

// Class OnlineSubsystemAngelscript.SecurityAPI
// Size: 0xa0 (Inherited: 0xa0)
struct USecurityAPI : UBlueprintFunctionLibrary {

	uint32_t GetSecurityToken(struct UObject* WorldContextObject); // Function OnlineSubsystemAngelscript.SecurityAPI.GetSecurityToken // (Final|Native|Static|Public) // @ game+0x53b42f0
	void GameRoundEnd(struct UObject* WorldContextObject); // Function OnlineSubsystemAngelscript.SecurityAPI.GameRoundEnd // (Final|Native|Static|Public) // @ game+0x53b24f0
	void AddRpcMismatch(struct UObject* WorldContextObject, int64_t PlayerId, struct FName FunctionName, uint32_t Optional); // Function OnlineSubsystemAngelscript.SecurityAPI.AddRpcMismatch // (Final|Native|Static|Public) // @ game+0x53b3190
};

// Class OnlineSubsystemAngelscript.SharedAchievementsModel
// Size: 0xc0 (Inherited: 0xb0)
struct USharedAchievementsModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnAchievementsChanged; // 0xa8(0x10)
	struct UAchievementSubsystem* AchievementSubsystem; // 0xb8(0x08)

	void SyncAchievements(); // Function OnlineSubsystemAngelscript.SharedAchievementsModel.SyncAchievements // (Native|Event|Public|BlueprintEvent) // @ game+0x2d0aea0
	void SetAchievementProgress(struct FString AchievementID, int32_t TimesToTrigger); // Function OnlineSubsystemAngelscript.SharedAchievementsModel.SetAchievementProgress // (Native|Event|Public|BlueprintEvent) // @ game+0x53b0d20
	bool ResetAchievements(); // Function OnlineSubsystemAngelscript.SharedAchievementsModel.ResetAchievements // (Native|Event|Public|BlueprintEvent) // @ game+0x2b960b0
	void AddAchievementProgress(struct FString AchievementID, int32_t TimesToTrigger); // Function OnlineSubsystemAngelscript.SharedAchievementsModel.AddAchievementProgress // (Native|Event|Public|BlueprintEvent) // @ game+0x53b1020
};

// Class OnlineSubsystemAngelscript.SharedClanModel
// Size: 0x460 (Inherited: 0xb0)
struct USharedClanModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnTimelineMessagesSyncedCallback; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnTimelineMessageReceived; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnTimelineMessageUpdateReceived; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnTimelineMessagePartyUpFailedCallback; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnTimelineMessagePartyUpCallback; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnTimelineMessageCreateCallback; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnClanNameCheckedCallback; // 0x108(0x10)
	struct FMulticastInlineDelegate OnClanTagCheckedCallback; // 0x118(0x10)
	struct FMulticastInlineDelegate OnClanStateSyncedCallback; // 0x128(0x10)
	struct FMulticastInlineDelegate OnClanUpdated; // 0x138(0x10)
	struct FMulticastInlineDelegate OnClanUpdateCallback; // 0x148(0x10)
	struct FMulticastInlineDelegate OnClanUpdateReceived; // 0x158(0x10)
	struct FMulticastInlineDelegate OnClanInviteSentCallback; // 0x168(0x10)
	struct FMulticastInlineDelegate OnClanInviteAnswerCallback; // 0x178(0x10)
	struct FMulticastInlineDelegate OnClanInviteAnswerReceived; // 0x188(0x10)
	struct FMulticastInlineDelegate OnClanOutgoingInviteReceived; // 0x198(0x10)
	struct FMulticastInlineDelegate OnClanInviteWithdrawnCallback; // 0x1a8(0x10)
	struct FMulticastInlineDelegate OnClanInviteWithdrawnRecieved; // 0x1b8(0x10)
	struct FMulticastInlineDelegate OnClanOutgoingInviteWithdrawnReceived; // 0x1c8(0x10)
	struct FMulticastInlineDelegate OnClanInvitesForClanSyncedCallback; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnClanInvitesForUserSyncedCallback; // 0x1e8(0x10)
	struct FMulticastInlineDelegate OnClanInviteReceived; // 0x1f8(0x10)
	struct FMulticastInlineDelegate OnClanCreatedCallback; // 0x208(0x10)
	struct FMulticastInlineDelegate OnClanSearchCallback; // 0x218(0x10)
	struct FMulticastInlineDelegate OnClanChatMessagesSyncedCallback; // 0x228(0x10)
	struct FMulticastInlineDelegate OnClanChatMessageReceived; // 0x238(0x10)
	struct FMulticastInlineDelegate OnClanMemberJoinReceived; // 0x248(0x10)
	struct FMulticastInlineDelegate OnClanCurrentPlayerJoinReceived; // 0x258(0x10)
	struct FMulticastInlineDelegate OnClanMemberLeaveReceived; // 0x268(0x10)
	struct FMulticastInlineDelegate OnClanCurrentPlayerLeaveCallback; // 0x278(0x10)
	struct FMulticastInlineDelegate OnClanReportedCallback; // 0x288(0x10)
	struct FMulticastInlineDelegate OnClanMemberRoleChangeReceived; // 0x298(0x10)
	struct FMulticastInlineDelegate OnClanMemberRoleChangeCallback; // 0x2a8(0x10)
	struct FMulticastInlineDelegate OnClanCurrentPlayerKickReceived; // 0x2b8(0x10)
	struct FMulticastInlineDelegate OnClanMemberKickedCallback; // 0x2c8(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationSentCallback; // 0x2d8(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationAnswerReceived; // 0x2e8(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationAnswerCallback; // 0x2f8(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationWithdrawReceived; // 0x308(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationWithdrawByCurrentPlayerCallback; // 0x318(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationCreateReceived; // 0x328(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationsForClanSyncedCallback; // 0x338(0x10)
	struct FMulticastInlineDelegate OnJoinClanApplicationsForUserSyncedCallback; // 0x348(0x10)
	struct FMulticastInlineDelegate OnFetchClanInfoForPlayersCallback; // 0x358(0x10)
	struct FMulticastInlineDelegate OnOfficialClansInfoReceived; // 0x368(0x10)
	char pad_380[0x8]; // 0x380(0x08)
	struct UClan* Clan; // 0x388(0x08)
	struct TArray<struct UClanInvite*> ClanInvitesSentByClan; // 0x390(0x10)
	struct TArray<struct UClanInvite*> ClanInvitesReceivedForUser; // 0x3a0(0x10)
	struct TArray<struct UClan*> ClanSearchResult; // 0x3b0(0x10)
	struct TArray<struct UClanTimelineMessage*> ClanTimelineMessages; // 0x3c0(0x10)
	struct TArray<struct UClanMessage*> ClanMessages; // 0x3d0(0x10)
	struct TArray<struct UJoinClanApplication*> JoinClanApplicationsSentByUser; // 0x3e0(0x10)
	struct TArray<struct UJoinClanApplication*> JoinClanApplicationsReceivedForClan; // 0x3f0(0x10)
	struct TArray<struct UOfficialClanInfo*> OfficialClans; // 0x400(0x10)
	char pad_410[0x50]; // 0x410(0x50)

	void WithdrawJoinClanApplication(struct FString ClanId); // Function OnlineSubsystemAngelscript.SharedClanModel.WithdrawJoinClanApplication // (Native|Event|Public|BlueprintEvent) // @ game+0x53b7b70
	void WithdrawClanInvite(struct UServicePlayerProfile* Invitee); // Function OnlineSubsystemAngelscript.SharedClanModel.WithdrawClanInvite // (Native|Event|Public|BlueprintEvent) // @ game+0x38550b0
	void SyncOfficialClansInfo(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncOfficialClansInfo // (Native|Event|Public|BlueprintEvent) // @ game+0x53b91f0
	void SyncJoinClanApplicationsForUser(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncJoinClanApplicationsForUser // (Native|Event|Public|BlueprintEvent) // @ game+0x2f4bfc0
	void SyncJoinClanApplicationsForClan(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncJoinClanApplicationsForClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53b9320
	void SyncClanTimelineMessages(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncClanTimelineMessages // (Native|Event|Public|BlueprintEvent) // @ game+0x2f6fbb0
	void SyncClanInvitesForUser(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncClanInvitesForUser // (Native|Event|Public|BlueprintEvent) // @ game+0x2f946c0
	void SyncClanInvitesForClan(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncClanInvitesForClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53b6f20
	void SyncClanChatMessages(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncClanChatMessages // (Native|Event|Public|BlueprintEvent) // @ game+0x5390860
	void SyncClan(); // Function OnlineSubsystemAngelscript.SharedClanModel.SyncClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53b84c0
	void SetClanTag(struct FString Tag); // Function OnlineSubsystemAngelscript.SharedClanModel.SetClanTag // (Native|Event|Public|BlueprintEvent) // @ game+0x53bb480
	void SetClanSearchTags(struct TArray<struct FString>& SearchTags); // Function OnlineSubsystemAngelscript.SharedClanModel.SetClanSearchTags // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53bc760
	void SetClanPrivacyMode(enum class EClanPrivacy PrivacyMode); // Function OnlineSubsystemAngelscript.SharedClanModel.SetClanPrivacyMode // (Native|Event|Public|BlueprintEvent) // @ game+0x53bd420
	void SetClanName(struct FString Name); // Function OnlineSubsystemAngelscript.SharedClanModel.SetClanName // (Native|Event|Public|BlueprintEvent) // @ game+0x53bf910
	void SendClanChatMessage(struct FString Message); // Function OnlineSubsystemAngelscript.SharedClanModel.SendClanChatMessage // (Native|Event|Public|BlueprintEvent) // @ game+0x53c0a10
	void SearchClans(struct FString NameQuery, struct TArray<struct FString>& SearchTags, enum class EClanSearchView View, int32_t Limit, bool bExcludeFull); // Function OnlineSubsystemAngelscript.SharedClanModel.SearchClans // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53b6930
	void ReportClan(struct FString ClanId, enum class EReportClanReason& Reason, struct FString Message); // Function OnlineSubsystemAngelscript.SharedClanModel.ReportClan // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53bbd10
	void LeaveClan(); // Function OnlineSubsystemAngelscript.SharedClanModel.LeaveClan // (Native|Event|Public|BlueprintEvent) // @ game+0x2f877e0
	void Kick(struct FTenancyUserId& MemberToKick); // Function OnlineSubsystemAngelscript.SharedClanModel.Kick // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53b7210
	bool IsPromotion(struct UServicePlayerProfile* Other, struct FString Role); // Function OnlineSubsystemAngelscript.SharedClanModel.IsPromotion // (Native|Event|Public|BlueprintEvent) // @ game+0x53bb6e0
	bool IsClanMember(); // Function OnlineSubsystemAngelscript.SharedClanModel.IsClanMember // (Native|Event|Public|BlueprintEvent) // @ game+0x3235920
	void InviteToClanByDisplayName(struct FString DisplayName, struct FString DisplayNameDiscriminator); // Function OnlineSubsystemAngelscript.SharedClanModel.InviteToClanByDisplayName // (Native|Event|Public|BlueprintEvent) // @ game+0x53bd290
	void InviteToClan(struct UServicePlayerProfile* Invitee); // Function OnlineSubsystemAngelscript.SharedClanModel.InviteToClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53b8d30
	struct TArray<struct UOfficialClanInfo*> GetOfficialClansInfo(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetOfficialClansInfo // (Native|Event|Public|BlueprintEvent) // @ game+0x53bffa0
	struct TArray<struct UClanTimelineMessage*> GetClanTimelineMessages(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanTimelineMessages // (Native|Event|Public|BlueprintEvent) // @ game+0x53b7370
	struct TArray<struct UClan*> GetClanSearchResult(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanSearchResult // (Native|Event|Public|BlueprintEvent) // @ game+0x53bd580
	struct TArray<struct UClanMessage*> GetClanMessages(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanMessages // (Native|Event|Public|BlueprintEvent) // @ game+0x53b7e40
	struct TArray<struct UClanInvite*> GetClanInvitesForUserReceived(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanInvitesForUserReceived // (Native|Event|Public|BlueprintEvent) // @ game+0x53b9120
	struct TArray<struct UClanInvite*> GetClanInvitesForClanSent(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanInvitesForClanSent // (Native|Event|Public|BlueprintEvent) // @ game+0x53b7f50
	struct TArray<struct UJoinClanApplication*> GetClanApplicationsForUserSent(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanApplicationsForUserSent // (Native|Event|Public|BlueprintEvent) // @ game+0x53bba60
	struct TArray<struct UJoinClanApplication*> GetClanApplicationsForClanReceived(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClanApplicationsForClanReceived // (Native|Event|Public|BlueprintEvent) // @ game+0x53bcbb0
	struct UClan* GetClan(); // Function OnlineSubsystemAngelscript.SharedClanModel.GetClan // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53b7c20
	void FetchRichPresenceForAllMembers(); // Function OnlineSubsystemAngelscript.SharedClanModel.FetchRichPresenceForAllMembers // (Native|Event|Public|BlueprintEvent) // @ game+0x2cdea40
	void FetchClanInfoForPlayers(struct TArray<struct FTenancyUserId>& PlayerIds); // Function OnlineSubsystemAngelscript.SharedClanModel.FetchClanInfoForPlayers // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53bc9e0
	void CreatePartyUpClanTimelineMessage(struct FString PartyId, struct FString GameMode, struct FString ExpireAt); // Function OnlineSubsystemAngelscript.SharedClanModel.CreatePartyUpClanTimelineMessage // (Native|Event|Public|BlueprintEvent) // @ game+0x53c0b00
	void CreateClan(struct FString Name, struct FString Tag, enum class EClanPrivacy Privacy, struct UClanCustomizationData* InCustomizationData); // Function OnlineSubsystemAngelscript.SharedClanModel.CreateClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53b61a0
	void CommitCustomizationData(struct UClanCustomizationData* InCustomizationData); // Function OnlineSubsystemAngelscript.SharedClanModel.CommitCustomizationData // (Native|Event|Public|BlueprintEvent) // @ game+0x53bb530
	void CommitClan(); // Function OnlineSubsystemAngelscript.SharedClanModel.CommitClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53c0790
	void ClaimPartyUpClanTimelineMessage(struct FString PartyId, struct FString MessageId); // Function OnlineSubsystemAngelscript.SharedClanModel.ClaimPartyUpClanTimelineMessage // (Native|Event|Public|BlueprintEvent) // @ game+0x53bf800
	void CheckClanTag(struct FString Tag); // Function OnlineSubsystemAngelscript.SharedClanModel.CheckClanTag // (Native|Event|Public|BlueprintEvent) // @ game+0x53bbf00
	void CheckClanName(struct FString Name); // Function OnlineSubsystemAngelscript.SharedClanModel.CheckClanName // (Native|Event|Public|BlueprintEvent) // @ game+0x53b8870
	void ChangeRoleOfMember(struct FTenancyUserId& MemberToChange, struct FString Role); // Function OnlineSubsystemAngelscript.SharedClanModel.ChangeRoleOfMember // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53b8fe0
	bool CanKick(struct UServicePlayerProfile* Other); // Function OnlineSubsystemAngelscript.SharedClanModel.CanKick // (Native|Event|Public|BlueprintEvent) // @ game+0x4faf1c0
	bool CanInvite(); // Function OnlineSubsystemAngelscript.SharedClanModel.CanInvite // (Native|Event|Public|BlueprintEvent) // @ game+0x31dafa0
	bool CanEditSearchTags(); // Function OnlineSubsystemAngelscript.SharedClanModel.CanEditSearchTags // (Native|Event|Public|BlueprintEvent) // @ game+0x340c590
	bool CanEditClanTag(); // Function OnlineSubsystemAngelscript.SharedClanModel.CanEditClanTag // (Native|Event|Public|BlueprintEvent) // @ game+0x327bee0
	bool CanEditClanName(); // Function OnlineSubsystemAngelscript.SharedClanModel.CanEditClanName // (Native|Event|Public|BlueprintEvent) // @ game+0x48d40b0
	bool CanEditClanIcon(); // Function OnlineSubsystemAngelscript.SharedClanModel.CanEditClanIcon // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd3930
	bool CanChangeRole(struct UServicePlayerProfile* Other, struct FString Role); // Function OnlineSubsystemAngelscript.SharedClanModel.CanChangeRole // (Native|Event|Public|BlueprintEvent) // @ game+0x53bcde0
	bool CanBan(struct UServicePlayerProfile* Other); // Function OnlineSubsystemAngelscript.SharedClanModel.CanBan // (Native|Event|Public|BlueprintEvent) // @ game+0x53bc850
	bool CanAnswerRequests(); // Function OnlineSubsystemAngelscript.SharedClanModel.CanAnswerRequests // (Native|Event|Public|BlueprintEvent) // @ game+0x5384830
	void ApplyToJoinClan(struct FString ClanId); // Function OnlineSubsystemAngelscript.SharedClanModel.ApplyToJoinClan // (Native|Event|Public|BlueprintEvent) // @ game+0x53beda0
	void AnswerJoinClanApplication(struct FString ClanId, struct FTenancyUserId& Applicant, bool bAccept); // Function OnlineSubsystemAngelscript.SharedClanModel.AnswerJoinClanApplication // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x53bcf50
	void AnswerClanInvite(struct FString ClanId, bool bAccept); // Function OnlineSubsystemAngelscript.SharedClanModel.AnswerClanInvite // (Native|Event|Public|BlueprintEvent) // @ game+0x53bb260
};

// Class OnlineSubsystemAngelscript.SharedIdentityModel
// Size: 0x1f0 (Inherited: 0xb0)
struct USharedIdentityModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnLoginChanged; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnLoginComplete; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnGetPlayerProfileComplete; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnPlayerProfilesUpdated; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnLocalProfileNameUpdated; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnConnectionStatusDidChange; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnCrossPlaySettingChanged; // 0x108(0x10)
	char pad_120[0x10]; // 0x120(0x10)
	struct FDelegate OnDiscordAccountLinkStatusChange; // 0x130(0x10)
	struct FMulticastInlineDelegate OnDiscordAccountConnectionChange; // 0x140(0x10)
	char pad_150[0xa0]; // 0x150(0xa0)

	void ValidateDisplayName(struct FString DisplayName, struct FDelegate& Delegate); // Function OnlineSubsystemAngelscript.SharedIdentityModel.ValidateDisplayName // (Final|Native|Public|HasOutParms) // @ game+0x53c9760
	void UpdateSpectatingMultiplayerOnline(bool bIsSpectatingMultiplayerOnline); // Function OnlineSubsystemAngelscript.SharedIdentityModel.UpdateSpectatingMultiplayerOnline // (Final|Native|Public) // @ game+0x53c8e90
	void UpdateProfileVoiceChatConsent(bool bVoiceChatModerationConsent, struct FDelegate& Delegate); // Function OnlineSubsystemAngelscript.SharedIdentityModel.UpdateProfileVoiceChatConsent // (Final|Native|Public|HasOutParms) // @ game+0x53c1430
	void UpdateProfileDisplayName(struct FString DisplayName, struct FDelegate& Delegate); // Function OnlineSubsystemAngelscript.SharedIdentityModel.UpdateProfileDisplayName // (Final|Native|Public|HasOutParms) // @ game+0x53c5760
	void UpdateProfile(struct FUpdateProfileArguments& Arguments, struct FDelegate& Delegate); // Function OnlineSubsystemAngelscript.SharedIdentityModel.UpdateProfile // (Final|Native|Public|HasOutParms) // @ game+0x53c8c40
	void UpdatePlayingMultiplayerOnline(bool bIsPlayingMultiplayerOnline); // Function OnlineSubsystemAngelscript.SharedIdentityModel.UpdatePlayingMultiplayerOnline // (Final|Native|Public) // @ game+0x53c90e0
	void UnlinkDiscordAccount(struct FDelegate& Completed); // Function OnlineSubsystemAngelscript.SharedIdentityModel.UnlinkDiscordAccount // (Final|Native|Public|HasOutParms) // @ game+0x53cade0
	bool ShowWebURL(struct FString URL, bool bRequestPredeterminedContent); // Function OnlineSubsystemAngelscript.SharedIdentityModel.ShowWebURL // (Final|Native|Public) // @ game+0x53c25a0
	bool ShowStoreUI(int32_t LocalUserNum, struct FString Category, struct FString ProductId, bool bAddToCart, int32_t SonyServiceLabelOverride); // Function OnlineSubsystemAngelscript.SharedIdentityModel.ShowStoreUI // (Final|Native|Public) // @ game+0x53c80f0
	void ResendVerifyEmail(struct FDelegate& Delegate); // Function OnlineSubsystemAngelscript.SharedIdentityModel.ResendVerifyEmail // (Final|Native|Public|HasOutParms) // @ game+0x53c8480
	void RequestIsUserRestricted(struct FDelegate& Delegate); // Function OnlineSubsystemAngelscript.SharedIdentityModel.RequestIsUserRestricted // (Final|Native|Public|HasOutParms) // @ game+0x53c1710
	void Logout(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.Logout // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void LoginWithLink(bool bLink); // Function OnlineSubsystemAngelscript.SharedIdentityModel.LoginWithLink // (Native|Event|Public|BlueprintEvent) // @ game+0x325ff90
	void Login(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.Login // (Native|Event|Public|BlueprintEvent) // @ game+0x32add10
	void LinkDiscordAccount(struct FDelegate& Completed); // Function OnlineSubsystemAngelscript.SharedIdentityModel.LinkDiscordAccount // (Final|Native|Public|HasOutParms) // @ game+0x53c8b80
	bool IsWebUrlPredeterminedContent(struct FString URL); // Function OnlineSubsystemAngelscript.SharedIdentityModel.IsWebUrlPredeterminedContent // (Final|Native|Public|Const) // @ game+0x53c0db0
	bool IsLoggedIn(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.IsLoggedIn // (Native|Event|Public|BlueprintEvent) // @ game+0x327bee0
	bool IsCrossPlayEnabled(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.IsCrossPlayEnabled // (Final|Native|Public|Const) // @ game+0x53c5fe0
	bool HasVerifiedEmail(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.HasVerifiedEmail // (Final|Native|Public|Const) // @ game+0x53c6350
	bool HasUserGeneratedContentPrivilege(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.HasUserGeneratedContentPrivilege // (Final|Native|Public|Const) // @ game+0x53c88a0
	bool HasEmail(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.HasEmail // (Final|Native|Public|Const) // @ game+0x53c6010
	bool HasCrossPlayPrivilege(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.HasCrossPlayPrivilege // (Final|Native|Public|Const) // @ game+0x53c4520
	bool HasActiveUserRestriction(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.HasActiveUserRestriction // (Final|Native|Public|Const) // @ game+0x53cab30
	struct TArray<struct FString> GetWebUrlPredeterminedContent(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetWebUrlPredeterminedContent // (Final|Native|Public|Const) // @ game+0x53c3810
	struct FEmbarkUserRestriction GetUserRestriction(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetUserRestriction // (Final|Native|Public) // @ game+0x53c5480
	struct FString GetUserId(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetUserId // (Final|Native|Public|Const) // @ game+0x53c89d0
	struct FUniqueNetIdRepl GetUniqueNetId(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetUniqueNetId // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53c9f90
	int32_t GetRetryAfterSeconds(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetRetryAfterSeconds // (Final|Native|Public) // @ game+0x53c9f20
	struct UServicePlayerProfile* GetProfileByTenancyUserId(struct FTenancyUserId& ID); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetProfileByTenancyUserId // (Final|Native|Public|HasOutParms|Const) // @ game+0x53c39f0
	struct UServicePlayerProfile* GetProfileByEmbarkAccountId(struct FEmbarkUserId& ID); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetProfileByEmbarkAccountId // (Final|Native|Public|HasOutParms|Const) // @ game+0x53c3f00
	struct UServicePlayerProfile* GetProfile(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetProfile // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5373240
	struct FString GetPlatformDisplayName(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetPlatformDisplayName // (Final|Native|Public|Const) // @ game+0x53c4550
	struct FName GetPlatform(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetPlatform // (Final|Native|Public|Const) // @ game+0x53c9040
	int32_t GetLocalPlayerNum(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetLocalPlayerNum // (Final|Native|Public|Const) // @ game+0x53c3ed0
	struct FEmbarkLinkingCode GetLinkingCode(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetLinkingCode // (Native|Event|Public|BlueprintEvent) // @ game+0x53c8a60
	struct FString GetDisplayName(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetDisplayName // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x538b760
	struct FString GetDefaultedCountry(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.GetDefaultedCountry // (Final|Native|Public) // @ game+0x53c8f30
	void CheckPlatformMultiplayerPrivilege(bool bShowUpgradeUI, struct FDelegate& OnCompleted); // Function OnlineSubsystemAngelscript.SharedIdentityModel.CheckPlatformMultiplayerPrivilege // (Final|Native|Public|HasOutParms) // @ game+0x53c66b0
	bool CanCommunicateOnline(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.CanCommunicateOnline // (Final|Native|Public) // @ game+0x53c94e0
	void AutoLogin(); // Function OnlineSubsystemAngelscript.SharedIdentityModel.AutoLogin // (Final|Native|Public) // @ game+0x53cba80
};

// Class OnlineSubsystemAngelscript.SharedVoiceChatModel
// Size: 0x490 (Inherited: 0xb0)
struct USharedVoiceChatModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnEnabledChanged; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnAvailableAudioDevicesChanged; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnMuteUpdate; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnBlockUpdate; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnToggleVoiceChatEnabled; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnRoomCreated; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnRoomJoined; // 0x108(0x10)
	struct FMulticastInlineDelegate OnRoomLeft; // 0x118(0x10)
	struct FMulticastInlineDelegate OnRoomFailure; // 0x128(0x10)
	struct FMulticastInlineDelegate OnRoomFailureRecovered; // 0x138(0x10)
	struct FMulticastInlineDelegate OnRoomEnabledUpdate; // 0x148(0x10)
	struct FMulticastInlineDelegate OnRoomParticipantsUpdate; // 0x158(0x10)
	struct FMulticastInlineDelegate OnRoomParticipantStatusUpdate; // 0x168(0x10)
	struct FMulticastInlineDelegate OnRoomParticipantTalkingUpdate; // 0x178(0x10)
	struct FMulticastInlineDelegate OnPushToTalkChanged; // 0x188(0x10)
	struct FMulticastInlineDelegate OnProximityVoipPushToTalkChanged; // 0x198(0x10)
	struct FDelegate CanProximityPushToTalkBeTriggered; // 0x1a8(0x10)
	struct FMulticastInlineDelegate OnMicrophoneAmplitudeChanged; // 0x1b8(0x10)
	char pad_1d0[0x110]; // 0x1d0(0x110)
	struct TMap<enum class EVoiceChannel, struct UVoiceChatRoomController*> VoiceRoomControllers; // 0x2e0(0x50)
	char pad_330[0x80]; // 0x330(0x80)
	struct UInputComponent* VoipInputBindings; // 0x3b0(0x08)
	struct UVoiceChatProviderBase* VoiceChatProvider; // 0x3b8(0x08)
	struct USharedSocialModel* SocialModel; // 0x3c0(0x08)
	struct TArray<struct UVoiceChatModelUserBlocker*> UserBlockers; // 0x3c8(0x10)
	struct UBlockedUsersUserBlocker* BlockedUsersUserBlocker; // 0x3d8(0x08)
	struct UGDKUserBlocker* GDKUserBlocker; // 0x3e0(0x08)
	struct UPlatformMutedUserBlocker* PlatformMutedUserBlocker; // 0x3e8(0x08)
	struct UVoiceConversionDataAsset* VoiceConversionDataAsset; // 0x3f0(0x08)
	char pad_3f8[0x98]; // 0x3f8(0x98)

	void UnblockAllParticipantsInChannel(enum class EVoiceChannel InChannel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.UnblockAllParticipantsInChannel // (Final|Native|Public) // @ game+0x53ce780
	void TryRecoverMicrophoneAccess(bool bShouldTry); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.TryRecoverMicrophoneAccess // (Final|Native|Public) // @ game+0x53d1070
	void StopMicrophoneTest(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.StopMicrophoneTest // (Final|Native|Public) // @ game+0x53cc6a0
	void StartMicrophoneTest(struct FDelegate& OnComplete); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.StartMicrophoneTest // (Final|Native|Public|HasOutParms) // @ game+0x53d0c90
	void SetVoiceConversionSpeakerIndex(int32_t Index); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetVoiceConversionSpeakerIndex // (Final|Native|Public) // @ game+0x53cfbc0
	void SetVoiceConversionHeardByMode(enum class EVoiceConversionHeardBy Mode); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetVoiceConversionHeardByMode // (Final|Native|Public) // @ game+0x53d0720
	void SetProximityVoipMode(enum class EVoiceChatMode InMode); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetProximityVoipMode // (Final|Native|Public) // @ game+0x53cda20
	void SetPlayerSelectivelyMutedInChannel(enum class EVoiceChannel InChannel, struct FTenancyUserId& PlayerId, bool bIsMuted); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetPlayerSelectivelyMutedInChannel // (Final|Native|Public|HasOutParms) // @ game+0x53d0240
	void SetPlayerMuted(struct FTenancyUserId& PlayerId, bool bIsMuted); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetPlayerMuted // (Final|Native|Public|HasOutParms) // @ game+0x53d0840
	void SetPlayerBlockedInChannel(enum class EVoiceChannel InChannel, struct FTenancyUserId& PlayerId, bool bIsBlocked); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetPlayerBlockedInChannel // (Final|Native|Public|HasOutParms) // @ game+0x53ccfc0
	void SetOutputVolume(float InVolume); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetOutputVolume // (Final|Native|Public) // @ game+0x53cdf30
	void SetOutputDeviceId(struct FString InputDeviceId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetOutputDeviceId // (Final|Native|Public) // @ game+0x53cffe0
	void SetMode(enum class EVoiceChatMode InMode); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetMode // (Final|Native|Public) // @ game+0x53d04f0
	void SetInputVolume(float InVolume); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetInputVolume // (Final|Native|Public) // @ game+0x53d05d0
	void SetInputDeviceId(struct FString InputDeviceId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetInputDeviceId // (Final|Native|Public) // @ game+0x53cd1c0
	void SetEnabled(bool Enabled); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetEnabled // (Final|Native|Public) // @ game+0x53d0090
	void SetChannelInfo(enum class EVoiceChannel Channel, struct FVoiceChannelInfo& VoiceChannelInfo); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.SetChannelInfo // (Final|Native|Public|HasOutParms) // @ game+0x53d1630
	void ResetProximityPushToTalkState(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.ResetProximityPushToTalkState // (Final|Native|Public) // @ game+0x53d17a0
	bool RemoveUserBlocker(struct UVoiceChatModelUserBlocker* UserBlocker); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.RemoveUserBlocker // (Final|Native|Public) // @ game+0x53cbe70
	void QueryConsolePlayerChatPermission(struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.QueryConsolePlayerChatPermission // (Final|Native|Public|HasOutParms) // @ game+0x53cfda0
	void LeaveVoiceChat(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.LeaveVoiceChat // (Final|Native|Public) // @ game+0x53d1840
	void JoinVoiceChat(enum class EVoiceChannel Channel, bool bEnableRoom, bool bEnableEcho); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.JoinVoiceChat // (Final|Native|Public) // @ game+0x53cc240
	bool IsVoiceConversionEnabledInRoom(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsVoiceConversionEnabledInRoom // (Final|Native|Public|Const) // @ game+0x53d09b0
	bool IsTestingMicrophone(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsTestingMicrophone // (Final|Native|Public|Const) // @ game+0x53d0f50
	bool IsPushToTalkPressed(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsPushToTalkPressed // (Final|Native|Public|Const) // @ game+0x53ccf90
	bool IsProximityVoipPushToTalkPressed(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsProximityVoipPushToTalkPressed // (Final|Native|Public|Const) // @ game+0x53d18e0
	bool IsPlayerMuted(struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsPlayerMuted // (Final|Native|Public|HasOutParms|Const) // @ game+0x53cbc40
	bool IsParticipantTalkingInRoom(enum class EVoiceChannel Channel, struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsParticipantTalkingInRoom // (Final|Native|Public|HasOutParms|Const) // @ game+0x53cc760
	bool IsParticipantMutedInRoom(enum class EVoiceChannel Channel, struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsParticipantMutedInRoom // (Final|Native|Public|HasOutParms|Const) // @ game+0x53d1b70
	bool IsParticipantInRoom(enum class EVoiceChannel Channel, struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsParticipantInRoom // (Final|Native|Public|HasOutParms|Const) // @ game+0x53d03c0
	bool IsParticipantBlockedInRoom(enum class EVoiceChannel Channel, struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsParticipantBlockedInRoom // (Final|Native|Public|HasOutParms|Const) // @ game+0x53cc460
	bool IsParticipantActiveInRoom(enum class EVoiceChannel Channel, struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsParticipantActiveInRoom // (Final|Native|Public|HasOutParms|Const) // @ game+0x53d1d60
	bool IsInVoiceChat(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsInVoiceChat // (Final|Native|Public|Const) // @ game+0x53d1150
	bool IsInVoiceChannel(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsInVoiceChannel // (Final|Native|Public|Const) // @ game+0x53d2010
	bool IsEnabled(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsEnabled // (Final|Native|Public|Const) // @ game+0x53d0210
	bool IsConsolePlayerMuted(struct FTenancyUserId& PlayerId); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.IsConsolePlayerMuted // (Final|Native|Public|HasOutParms|Const) // @ game+0x53d0f80
	void InitProximityVoipSpectatorMode(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.InitProximityVoipSpectatorMode // (Final|Native|Public) // @ game+0x53ccf70
	bool HasInvalidOutputAudioDevicesInRoom(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.HasInvalidOutputAudioDevicesInRoom // (Final|Native|Public|Const) // @ game+0x53d1a30
	bool HasInvalidOutputAudioDevices(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.HasInvalidOutputAudioDevices // (Final|Native|Public|Const) // @ game+0x53cbf60
	bool HasInvalidInputAudioDevicesInRoom(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.HasInvalidInputAudioDevicesInRoom // (Final|Native|Public|Const) // @ game+0x53d1950
	bool HasInvalidInputAudioDevices(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.HasInvalidInputAudioDevices // (Final|Native|Public|Const) // @ game+0x53d1360
	struct UInputComponent* GetVoipInputBindings(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetVoipInputBindings // (Final|Native|Public) // @ game+0x53c9970
	struct TSoftObjectPtr<USoundBase> GetVoiceConversionPreviewSound(int32_t Index); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetVoiceConversionPreviewSound // (Final|Native|Public) // @ game+0x53cc150
	enum class EVoiceRoomState GetRoomState(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetRoomState // (Final|Native|Public|Const) // @ game+0x53ce690
	void GetRoomParticipants(enum class EVoiceChannel Channel, struct TMap<struct FTenancyUserId, struct FEmbarkVoiceRoomParticipantState>& OutParticipants); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetRoomParticipants // (Final|Native|Public|HasOutParms|Const) // @ game+0x53d13d0
	struct FString GetOutputDeviceId(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetOutputDeviceId // (Final|Native|Public|Const) // @ game+0x53cd820
	struct FString GetInputDeviceId(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetInputDeviceId // (Final|Native|Public|Const) // @ game+0x53d0e80
	void GetFailures(struct TArray<struct FVoiceChatFailure>& OutFailures); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetFailures // (Final|Native|Public|HasOutParms) // @ game+0x53d1e90
	struct FString GetDefaultOutputDeviceId(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetDefaultOutputDeviceId // (Final|Native|Public|Const) // @ game+0x53cc3d0
	struct FString GetDefaultInputDeviceId(); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetDefaultInputDeviceId // (Final|Native|Public|Const) // @ game+0x53cc8c0
	void GetAvailableOutputDevices(struct TArray<struct FVoiceDeviceInfo>& Output); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetAvailableOutputDevices // (Final|Native|Public|HasOutParms|Const) // @ game+0x53cc050
	void GetAvailableInputDevices(struct TArray<struct FVoiceDeviceInfo>& Output); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.GetAvailableInputDevices // (Final|Native|Public|HasOutParms|Const) // @ game+0x53ce430
	void EnableRoom(enum class EVoiceChannel Channel, bool bEnable); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.EnableRoom // (Final|Native|Public) // @ game+0x53d0b50
	void EnableAutoGainControl(bool bEnabled); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.EnableAutoGainControl // (Final|Native|Public) // @ game+0x53d0130
	void DeleteChannelInfo(enum class EVoiceChannel Channel); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.DeleteChannelInfo // (Final|Native|Public) // @ game+0x53d1ad0
	void AddUserBlocker(struct UVoiceChatModelUserBlocker* UserBlocker); // Function OnlineSubsystemAngelscript.SharedVoiceChatModel.AddUserBlocker // (Final|Native|Public) // @ game+0x53cfe80
};

// Class OnlineSubsystemAngelscript.VoiceChatDevices
// Size: 0x110 (Inherited: 0xb0)
struct UVoiceChatDevices : UIEmbarkDynamicEnum {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct UIEOSAudioInterface* AudioInterface; // 0xb8(0x08)
	struct FText SystemDefaultText; // 0xc0(0x18)
	struct FText NoDevicesText; // 0xd8(0x18)
	char pad_f0[0x8]; // 0xf0(0x08)
	struct TArray<struct FVoiceDeviceInfo> Devices; // 0xf8(0x10)
	char pad_108[0x8]; // 0x108(0x08)
};

// Class OnlineSubsystemAngelscript.VoiceChatEnabledSetting
// Size: 0xf0 (Inherited: 0xf0)
struct UVoiceChatEnabledSetting : UEmbarkOptionBool {
};

// Class OnlineSubsystemAngelscript.VoiceChatInputDevices
// Size: 0x130 (Inherited: 0x110)
struct UVoiceChatInputDevices : UVoiceChatDevices {
	struct FText NoMicrophoneFoundText; // 0x110(0x18)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class OnlineSubsystemAngelscript.VoiceChatModeSetting
// Size: 0x160 (Inherited: 0xd0)
struct UVoiceChatModeSetting : UIEmbarkOptionEnum {
	struct FText InvalidDisplayText; // 0xd0(0x18)
	struct FText OpenMicText; // 0xe8(0x18)
	struct FText PushToTalkText; // 0x100(0x18)
	struct FText ToggleToTalkText; // 0x118(0x18)
	struct FText PushToTalkTextFormattedText; // 0x130(0x18)
	bool bIsProximityVoip; // 0x148(0x01)
	char pad_149[0x17]; // 0x149(0x17)

	void SetMode(enum class EVoiceChatMode NewMode); // Function OnlineSubsystemAngelscript.VoiceChatModeSetting.SetMode // (Final|Native|Public) // @ game+0x5412940
	struct FText GetDisplayTextForPlayerController(struct APlayerController* PlayerController); // Function OnlineSubsystemAngelscript.VoiceChatModeSetting.GetDisplayTextForPlayerController // (Final|Native|Public|Const) // @ game+0x53fd490
	enum class EVoiceChatMode GetCurrentMode(); // Function OnlineSubsystemAngelscript.VoiceChatModeSetting.GetCurrentMode // (Final|Native|Public|Const) // @ game+0x54191d0
	enum class EVoiceChatMode DefaultForPlatform(); // Function OnlineSubsystemAngelscript.VoiceChatModeSetting.DefaultForPlatform // (Final|Native|Public|Const) // @ game+0x542c9d0
};

// Class OnlineSubsystemAngelscript.VoiceChatOutputDevices
// Size: 0x130 (Inherited: 0x110)
struct UVoiceChatOutputDevices : UVoiceChatDevices {
	struct FText NoSpeakerFoundText; // 0x110(0x18)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class OnlineSubsystemAngelscript.VoiceChatProviderBase
// Size: 0xa0 (Inherited: 0xa0)
struct UVoiceChatProviderBase : UObject {
};

// Class OnlineSubsystemAngelscript.EOSVoiceChatProvider
// Size: 0xc0 (Inherited: 0xa0)
struct UEOSVoiceChatProvider : UVoiceChatProviderBase {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UIEOSRTCInterface* EosRtcInterface; // 0xb0(0x08)
	struct UIEOSAudioInterface* EosAudioInterface; // 0xb8(0x08)
};

// Class OnlineSubsystemAngelscript.VoiceChatRoomController
// Size: 0x150 (Inherited: 0xa0)
struct UVoiceChatRoomController : UObject {
	char pad_a0[0x90]; // 0xa0(0x90)
	struct UVoiceRoomBase* VoiceRoom; // 0x130(0x08)
	struct USharedVoiceChatModel* VoiceChatModel; // 0x138(0x08)
	char pad_140[0x10]; // 0x140(0x10)
};

