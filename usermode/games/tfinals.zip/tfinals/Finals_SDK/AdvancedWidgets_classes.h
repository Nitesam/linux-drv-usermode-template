// Class AdvancedWidgets.RadialSlider
// Size: 0x880 (Inherited: 0x1f0)
struct URadialSlider : UWidget {
	float Value; // 0x1f0(0x04)
	struct FDelegate ValueDelegate; // 0x1f4(0x10)
	bool bUseCustomDefaultValue; // 0x204(0x01)
	char pad_205[0x3]; // 0x205(0x03)
	float CustomDefaultValue; // 0x208(0x04)
	char pad_20c[0x4]; // 0x20c(0x04)
	struct FRuntimeFloatCurve SliderRange; // 0x210(0x88)
	struct TArray<float> ValueTags; // 0x298(0x10)
	float SliderHandleStartAngle; // 0x2a8(0x04)
	float SliderHandleEndAngle; // 0x2ac(0x04)
	float AngularOffset; // 0x2b0(0x04)
	char pad_2b4[0x4]; // 0x2b4(0x04)
	struct FVector2D HandStartEndRatio; // 0x2b8(0x10)
	char pad_2c8[0x8]; // 0x2c8(0x08)
	struct FSliderStyle WidgetStyle; // 0x2d0(0x500)
	struct FLinearColor SliderBarColor; // 0x7d0(0x10)
	struct FLinearColor SliderProgressColor; // 0x7e0(0x10)
	struct FLinearColor SliderHandleColor; // 0x7f0(0x10)
	struct FLinearColor CenterBackgroundColor; // 0x800(0x10)
	bool Locked; // 0x810(0x01)
	bool MouseUsesStep; // 0x811(0x01)
	bool RequiresControllerLock; // 0x812(0x01)
	char pad_813[0x1]; // 0x813(0x01)
	float StepSize; // 0x814(0x04)
	bool IsFocusable; // 0x818(0x01)
	bool UseVerticalDrag; // 0x819(0x01)
	bool ShowSliderHandle; // 0x81a(0x01)
	bool ShowSliderHand; // 0x81b(0x01)
	char pad_81c[0x4]; // 0x81c(0x04)
	struct FMulticastInlineDelegate OnMouseCaptureBegin; // 0x820(0x10)
	struct FMulticastInlineDelegate OnMouseCaptureEnd; // 0x830(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureBegin; // 0x840(0x10)
	struct FMulticastInlineDelegate OnControllerCaptureEnd; // 0x850(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x860(0x10)
	char pad_870[0x10]; // 0x870(0x10)

	void SetValueTags(struct TArray<float>& InValueTags); // Function AdvancedWidgets.RadialSlider.SetValueTags // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8f49fd0
	void SetValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f625b0
	void SetUseVerticalDrag(bool InUseVerticalDrag); // Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f413c0
	void SetStepSize(float InValue); // Function AdvancedWidgets.RadialSlider.SetStepSize // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f41dc0
	void SetSliderRange(struct FRuntimeFloatCurve& InSliderRange); // Function AdvancedWidgets.RadialSlider.SetSliderRange // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8f4ef10
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderProgressColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f57f80
	void SetSliderHandleStartAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f39050
	void SetSliderHandleEndAngle(float InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f3e3d0
	void SetSliderHandleColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderHandleColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f62650
	void SetSliderBarColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetSliderBarColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f56970
	void SetShowSliderHandle(bool InShowSliderHandle); // Function AdvancedWidgets.RadialSlider.SetShowSliderHandle // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f60e60
	void SetShowSliderHand(bool InShowSliderHand); // Function AdvancedWidgets.RadialSlider.SetShowSliderHand // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f49ec0
	void SetLocked(bool InValue); // Function AdvancedWidgets.RadialSlider.SetLocked // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f3fd50
	void SetHandStartEndRatio(struct FVector2D InValue); // Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f4bc40
	void SetCustomDefaultValue(float InValue); // Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f43060
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f54fd0
	void SetAngularOffset(float InValue); // Function AdvancedWidgets.RadialSlider.SetAngularOffset // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x8f49cf0
	float GetValue(); // Function AdvancedWidgets.RadialSlider.GetValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8f54f40
	float GetNormalizedSliderHandlePosition(); // Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8f3cc80
	float GetCustomDefaultValue(); // Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8f5d780
};

