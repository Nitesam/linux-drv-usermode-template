// Class DataflowCore.DataflowSettings
// Size: 0x150 (Inherited: 0xb0)
struct UDataflowSettings : UDeveloperSettings {
	struct FLinearColor ArrayPinTypeColor; // 0xa8(0x10)
	struct FLinearColor ManagedArrayCollectionPinTypeColor; // 0xb8(0x10)
	struct FLinearColor BoxPinTypeColor; // 0xc8(0x10)
	struct FLinearColor SpherePinTypeColor; // 0xd8(0x10)
	struct TMap<struct FName, struct FNodeColors> NodeColorsMap; // 0xe8(0x50)
	char pad_140[0x10]; // 0x140(0x10)
};

