// Class MovieSceneTracks.MovieSceneTransformOrigin
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneTransformOrigin : UInterface {

	struct FTransform BP_GetTransformOrigin(); // Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin // (RequiredAPI|Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x4abfe0
};

// Class MovieSceneTracks.MovieSceneConsoleVariableTrackInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneConsoleVariableTrackInterface : UInterface {
};

// Class MovieSceneTracks.MovieSceneDecomposerTestObject
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneDecomposerTestObject : UObject {
	float FloatProperty; // 0x98(0x04)
};

// Class MovieSceneTracks.MovieSceneTestSequence
// Size: 0x100 (Inherited: 0xe0)
struct UMovieSceneTestSequence : UMovieSceneSequence {
	struct UMovieScene* MovieScene; // 0xd8(0x08)
	struct TArray<struct UObject*> BoundObjects; // 0xe0(0x10)
	struct TArray<struct FGuid> BindingGuids; // 0xf0(0x10)
};

// Class MovieSceneTracks.MovieSceneDoublePerlinNoiseChannelContainer
// Size: 0x130 (Inherited: 0xd0)
struct UMovieSceneDoublePerlinNoiseChannelContainer : UMovieSceneChannelOverrideContainer {
	struct FMovieSceneDoublePerlinNoiseChannel PerlinNoiseChannel; // 0xc8(0x68)
};

// Class MovieSceneTracks.MovieSceneFloatPerlinNoiseChannelContainer
// Size: 0x130 (Inherited: 0xd0)
struct UMovieSceneFloatPerlinNoiseChannelContainer : UMovieSceneChannelOverrideContainer {
	struct FMovieSceneFloatPerlinNoiseChannel PerlinNoiseChannel; // 0xc8(0x68)
};

// Class MovieSceneTracks.MovieSceneInterrogatedPropertyInstantiatorSystem
// Size: 0x260 (Inherited: 0xb0)
struct UMovieSceneInterrogatedPropertyInstantiatorSystem : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0x1b0]; // 0xb0(0x1b0)
};

// Class MovieSceneTracks.MovieSceneCameraShakeEvaluator
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneCameraShakeEvaluator : UObject {
};

// Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0x190 (Inherited: 0x160)
struct UMovieScene3DConstraintSection : UMovieSceneSection {
	struct FGuid ConstraintId; // 0x160(0x10)
	struct FMovieSceneObjectBindingID ConstraintBindingID; // 0x170(0x18)
	char pad_188[0x8]; // 0x188(0x08)

	void SetConstraintBindingID(struct FMovieSceneObjectBindingID& InConstraintBindingID); // Function MovieSceneTracks.MovieScene3DConstraintSection.SetConstraintBindingID // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2741660
	struct FMovieSceneObjectBindingID GetConstraintBindingID(); // Function MovieSceneTracks.MovieScene3DConstraintSection.GetConstraintBindingID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26eb830
};

// Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0x1b0 (Inherited: 0x190)
struct UMovieScene3DAttachSection : UMovieScene3DConstraintSection {
	struct FName AttachSocketName; // 0x190(0x08)
	struct FName AttachComponentName; // 0x198(0x08)
	enum class EAttachmentRule AttachmentLocationRule; // 0x1a0(0x01)
	enum class EAttachmentRule AttachmentRotationRule; // 0x1a1(0x01)
	enum class EAttachmentRule AttachmentScaleRule; // 0x1a2(0x01)
	enum class EDetachmentRule DetachmentLocationRule; // 0x1a3(0x01)
	enum class EDetachmentRule DetachmentRotationRule; // 0x1a4(0x01)
	enum class EDetachmentRule DetachmentScaleRule; // 0x1a5(0x01)
	char pad_1a6[0xa]; // 0x1a6(0x0a)
};

// Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x2a0 (Inherited: 0x190)
struct UMovieScene3DPathSection : UMovieScene3DConstraintSection {
	struct FMovieSceneFloatChannel TimingCurve; // 0x188(0x110)
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // 0x298(0x01)
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // 0x299(0x01)
	char bFollow : 1; // 0x29c(0x01)
	char bReverse : 1; // 0x29c(0x01)
	char bForceUpright : 1; // 0x29c(0x01)
};

// Class MovieSceneTracks.MovieScene3DTransformSectionConstraints
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieScene3DTransformSectionConstraints : UObject {
	struct TArray<struct FConstraintAndActiveChannel> ConstraintsChannels; // 0x98(0x10)
};

// Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0xcb0 (Inherited: 0x160)
struct UMovieScene3DTransformSection : UMovieSceneSection {
	char pad_160[0x40]; // 0x160(0x40)
	struct FMovieSceneTransformMask TransformMask; // 0x1a0(0x04)
	char pad_1a4[0x4]; // 0x1a4(0x04)
	struct FMovieSceneDoubleChannel Translation[0x3]; // 0x1a8(0x348)
	struct FMovieSceneDoubleChannel Rotation[0x3]; // 0x4f0(0x348)
	struct FMovieSceneDoubleChannel Scale[0x3]; // 0x838(0x348)
	struct FMovieSceneFloatChannel ManualWeight; // 0xb80(0x110)
	struct UMovieSceneSectionChannelOverrideRegistry* OverrideRegistry; // 0xc90(0x08)
	struct UMovieScene3DTransformSectionConstraints* Constraints; // 0xc98(0x08)
	bool bUseQuaternionInterpolation; // 0xca0(0x01)
	char pad_ca1[0xf]; // 0xca1(0x0f)
};

// Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x310 (Inherited: 0x160)
struct UMovieSceneActorReferenceSection : UMovieSceneSection {
	struct FMovieSceneActorReferenceData ActorReferenceData; // 0x160(0x120)
	struct FIntegralCurve ActorGuidIndexCurve; // 0x280(0x80)
	struct TArray<struct FString> ActorGuidStrings; // 0x300(0x10)
};

// Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x6a0 (Inherited: 0x160)
struct UMovieSceneAudioSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct USoundBase* Sound; // 0x168(0x08)
	struct FFrameNumber StartFrameOffset; // 0x170(0x04)
	float StartOffset; // 0x174(0x04)
	float AudioStartTime; // 0x178(0x04)
	float AudioDilationFactor; // 0x17c(0x04)
	float AudioVolume; // 0x180(0x04)
	char pad_184[0x4]; // 0x184(0x04)
	struct FMovieSceneFloatChannel SoundVolume; // 0x188(0x110)
	struct FMovieSceneFloatChannel PitchMultiplier; // 0x298(0x110)
	struct TMap<struct FName, struct FMovieSceneFloatChannel> Inputs_Float; // 0x3a8(0x50)
	struct TMap<struct FName, struct FMovieSceneStringChannel> Inputs_String; // 0x3f8(0x50)
	struct TMap<struct FName, struct FMovieSceneBoolChannel> Inputs_Bool; // 0x448(0x50)
	struct TMap<struct FName, struct FMovieSceneIntegerChannel> Inputs_Int; // 0x498(0x50)
	struct TMap<struct FName, struct FMovieSceneAudioTriggerChannel> Inputs_Trigger; // 0x4e8(0x50)
	struct FMovieSceneActorReferenceData AttachActorData; // 0x538(0x120)
	bool bLooping; // 0x658(0x01)
	bool bSuppressSubtitles; // 0x659(0x01)
	bool bOverrideAttenuation; // 0x65a(0x01)
	char pad_65b[0x5]; // 0x65b(0x05)
	struct USoundAttenuation* AttenuationSettings; // 0x660(0x08)
	struct FDelegate OnQueueSubtitles; // 0x668(0x10)
	struct FMulticastInlineDelegate OnAudioFinished; // 0x678(0x10)
	struct FMulticastInlineDelegate OnAudioPlaybackPercent; // 0x688(0x10)
	char pad_698[0x8]; // 0x698(0x08)

	void SetSuppressSubtitles(bool bInSuppressSubtitles); // Function MovieSceneTracks.MovieSceneAudioSection.SetSuppressSubtitles // (Final|Native|Public|BlueprintCallable) // @ game+0x27626e0
	void SetStartOffset(struct FFrameNumber InStartOffset); // Function MovieSceneTracks.MovieSceneAudioSection.SetStartOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x279fcb0
	void SetSound(struct USoundBase* InSound); // Function MovieSceneTracks.MovieSceneAudioSection.SetSound // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x275c9a0
	void SetOverrideAttenuation(bool bInOverrideAttenuation); // Function MovieSceneTracks.MovieSceneAudioSection.SetOverrideAttenuation // (Final|Native|Public|BlueprintCallable) // @ game+0x26dc930
	void SetLooping(bool bInLooping); // Function MovieSceneTracks.MovieSceneAudioSection.SetLooping // (Final|Native|Public|BlueprintCallable) // @ game+0x27a40f0
	void SetAttenuationSettings(struct USoundAttenuation* InAttenuationSettings); // Function MovieSceneTracks.MovieSceneAudioSection.SetAttenuationSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x2781990
	bool GetSuppressSubtitles(); // Function MovieSceneTracks.MovieSceneAudioSection.GetSuppressSubtitles // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2786690
	struct FFrameNumber GetStartOffset(); // Function MovieSceneTracks.MovieSceneAudioSection.GetStartOffset // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x273b610
	struct USoundBase* GetSound(); // Function MovieSceneTracks.MovieSceneAudioSection.GetSound // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2785b80
	bool GetOverrideAttenuation(); // Function MovieSceneTracks.MovieSceneAudioSection.GetOverrideAttenuation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2744640
	bool GetLooping(); // Function MovieSceneTracks.MovieSceneAudioSection.GetLooping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2751a70
	struct USoundAttenuation* GetAttenuationSettings(); // Function MovieSceneTracks.MovieSceneAudioSection.GetAttenuationSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x276c9a0
};

// Class MovieSceneTracks.MovieSceneBaseCacheSection
// Size: 0x170 (Inherited: 0x160)
struct UMovieSceneBaseCacheSection : UMovieSceneSection {
	char pad_160[0x10]; // 0x160(0x10)
};

// Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x270 (Inherited: 0x160)
struct UMovieSceneByteSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneByteChannel ByteCurve; // 0x168(0x108)
};

// Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0x210 (Inherited: 0x160)
struct UMovieSceneCameraCutSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	bool bLockPreviousCamera; // 0x168(0x01)
	char pad_169[0x3]; // 0x169(0x03)
	struct FGuid CameraGuid; // 0x16c(0x10)
	struct FMovieSceneObjectBindingID CameraBindingID; // 0x17c(0x18)
	char pad_194[0xc]; // 0x194(0x0c)
	struct FTransform InitialCameraCutTransform; // 0x1a0(0x60)
	bool bHasInitialCameraCutTransform; // 0x200(0x01)
	char pad_201[0xf]; // 0x201(0x0f)

	void SetCameraBindingID(struct FMovieSceneObjectBindingID& InCameraBindingID); // Function MovieSceneTracks.MovieSceneCameraCutSection.SetCameraBindingID // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x26d5370
	struct FMovieSceneObjectBindingID GetCameraBindingID(); // Function MovieSceneTracks.MovieSceneCameraCutSection.GetCameraBindingID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26f8c40
};

// Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0x1b0 (Inherited: 0x160)
struct UMovieSceneCameraShakeSection : UMovieSceneSection {
	struct FMovieSceneCameraShakeSectionData ShakeData; // 0x160(0x28)
	struct UCameraShakeBase* ShakeClass; // 0x188(0x08)
	float PlayScale; // 0x190(0x04)
	enum class ECameraShakePlaySpace PlaySpace; // 0x194(0x01)
	char pad_195[0x3]; // 0x195(0x03)
	struct FRotator UserDefinedPlaySpace; // 0x198(0x18)
};

// Class MovieSceneTracks.MovieSceneCameraShakeSourceShakeSection
// Size: 0x190 (Inherited: 0x160)
struct UMovieSceneCameraShakeSourceShakeSection : UMovieSceneSection {
	struct FMovieSceneCameraShakeSectionData ShakeData; // 0x160(0x28)
	char pad_188[0x8]; // 0x188(0x08)
};

// Class MovieSceneTracks.MovieSceneCameraShakeSourceTriggerSection
// Size: 0x260 (Inherited: 0x160)
struct UMovieSceneCameraShakeSourceTriggerSection : UMovieSceneSection {
	struct FMovieSceneCameraShakeSourceTriggerChannel Channel; // 0x160(0xf8)
	char pad_258[0x8]; // 0x258(0x08)
};

// Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x1d0 (Inherited: 0x1b0)
struct UMovieSceneCinematicShotSection : UMovieSceneSubSection {
	struct FString ShotDisplayName; // 0x1a8(0x10)
	struct FText DisplayName; // 0x1b8(0x18)

	void SetShotDisplayName(struct FString InShotDisplayName); // Function MovieSceneTracks.MovieSceneCinematicShotSection.SetShotDisplayName // (Final|Native|Public|BlueprintCallable) // @ game+0x277fe50
	struct FString GetShotDisplayName(); // Function MovieSceneTracks.MovieSceneCinematicShotSection.GetShotDisplayName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x271f0a0
};

// Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x5b0 (Inherited: 0x160)
struct UMovieSceneColorSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneFloatChannel RedCurve; // 0x168(0x110)
	struct FMovieSceneFloatChannel GreenCurve; // 0x278(0x110)
	struct FMovieSceneFloatChannel BlueCurve; // 0x388(0x110)
	struct FMovieSceneFloatChannel AlphaCurve; // 0x498(0x110)
	char pad_5a8[0x8]; // 0x5a8(0x08)
};

// Class MovieSceneTracks.MovieSceneConstrainedSection
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneConstrainedSection : UInterface {
};

// Class MovieSceneTracks.MovieSceneCVarSection
// Size: 0x1d0 (Inherited: 0x160)
struct UMovieSceneCVarSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct TArray<struct FMovieSceneConsoleVariableCollection> ConsoleVariableCollections; // 0x168(0x10)
	struct FMovieSceneCVarOverrides ConsoleVariables; // 0x178(0x50)
	char pad_1c8[0x8]; // 0x1c8(0x08)

	void SetFromString(struct FString InString); // Function MovieSceneTracks.MovieSceneCVarSection.SetFromString // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2713030
	struct FString GetString(); // Function MovieSceneTracks.MovieSceneCVarSection.GetString // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27a3310
};

// Class MovieSceneTracks.MovieSceneDataLayerSection
// Size: 0x190 (Inherited: 0x160)
struct UMovieSceneDataLayerSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct TArray<struct FActorDataLayer> DataLayers; // 0x168(0x10)
	struct TArray<struct UDataLayerAsset*> DataLayerAssets; // 0x178(0x10)
	enum class EDataLayerRuntimeState DesiredState; // 0x188(0x01)
	enum class EDataLayerRuntimeState PrerollState; // 0x189(0x01)
	bool bFlushOnUnload; // 0x18a(0x01)
	char pad_18b[0x5]; // 0x18b(0x05)

	void SetPrerollState(enum class EDataLayerRuntimeState InPrerollState); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetPrerollState // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2702e10
	void SetFlushOnUnload(bool bFlushOnUnload); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetFlushOnUnload // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2700a30
	void SetDesiredState(enum class EDataLayerRuntimeState InDesiredState); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetDesiredState // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x27807f0
	void SetDataLayers(struct TArray<struct FActorDataLayer>& InDataLayers); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetDataLayers // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x26fd890
	void SetDataLayerAssets(struct TArray<struct UDataLayerAsset*>& InDataLayerAssets); // Function MovieSceneTracks.MovieSceneDataLayerSection.SetDataLayerAssets // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2741ce0
	enum class EDataLayerRuntimeState GetPrerollState(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetPrerollState // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27174a0
	bool GetFlushOnUnload(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetFlushOnUnload // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2799440
	enum class EDataLayerRuntimeState GetDesiredState(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetDesiredState // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27530d0
	struct TArray<struct FActorDataLayer> GetDataLayers(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetDataLayers // (Final|Native|Private|BlueprintCallable|BlueprintPure|Const) // @ game+0x274a560
	struct TArray<struct UDataLayerAsset*> GetDataLayerAssets(); // Function MovieSceneTracks.MovieSceneDataLayerSection.GetDataLayerAssets // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x26d4710
};

// Class MovieSceneTracks.MovieSceneDoubleSection
// Size: 0x280 (Inherited: 0x160)
struct UMovieSceneDoubleSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneDoubleChannel DoubleCurve; // 0x168(0x118)
};

// Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x270 (Inherited: 0x160)
struct UMovieSceneEnumSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneByteChannel EnumCurve; // 0x168(0x108)
};

// Class MovieSceneTracks.MovieSceneEventSectionBase
// Size: 0x160 (Inherited: 0x160)
struct UMovieSceneEventSectionBase : UMovieSceneSection {
};

// Class MovieSceneTracks.MovieSceneEventRepeaterSection
// Size: 0x190 (Inherited: 0x160)
struct UMovieSceneEventRepeaterSection : UMovieSceneEventSectionBase {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneEvent Event; // 0x168(0x28)
};

// Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x2d0 (Inherited: 0x160)
struct UMovieSceneEventSection : UMovieSceneSection {
	struct FNameCurve Events; // 0x160(0x78)
	struct FMovieSceneEventSectionData EventData; // 0x1d8(0xf8)
};

// Class MovieSceneTracks.MovieSceneEventTriggerSection
// Size: 0x260 (Inherited: 0x160)
struct UMovieSceneEventTriggerSection : UMovieSceneEventSectionBase {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneEventChannel EventChannel; // 0x168(0xf8)
};

// Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x290 (Inherited: 0x160)
struct UMovieSceneFadeSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneFloatChannel FloatCurve; // 0x168(0x110)
	struct FLinearColor FadeColor; // 0x278(0x10)
	char bFadeAudio : 1; // 0x288(0x01)
	char pad_288_1 : 7; // 0x288(0x01)
	char pad_289[0x7]; // 0x289(0x07)
};

// Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x290 (Inherited: 0x160)
struct UMovieSceneFloatSection : UMovieSceneSection {
	char pad_160[0x10]; // 0x160(0x10)
	struct FMovieSceneFloatChannel FloatCurve; // 0x170(0x110)
	struct UMovieSceneSectionChannelOverrideRegistry* OverrideRegistry; // 0x280(0x08)
	char pad_288[0x8]; // 0x288(0x08)
};

// Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x270 (Inherited: 0x160)
struct UMovieSceneIntegerSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneIntegerChannel IntegerCurve; // 0x168(0x100)
	char pad_268[0x8]; // 0x268(0x08)
};

// Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0x180 (Inherited: 0x160)
struct UMovieSceneLevelVisibilitySection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	enum class ELevelVisibility Visibility; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
	struct TArray<struct FName> LevelNames; // 0x170(0x10)

	void SetVisibility(enum class ELevelVisibility InVisibility); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetVisibility // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x27d0380
	void SetLevelNames(struct TArray<struct FName>& InLevelNames); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetLevelNames // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x27c6b60
	enum class ELevelVisibility GetVisibility(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetVisibility // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27e7ce0
	struct TArray<struct FName> GetLevelNames(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetLevelNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x27e2dd0
};

// Class MovieSceneTracks.MovieSceneObjectPropertySection
// Size: 0x290 (Inherited: 0x160)
struct UMovieSceneObjectPropertySection : UMovieSceneSection {
	struct FMovieSceneObjectPathChannel ObjectChannel; // 0x160(0x130)
};

// Class MovieSceneTracks.MovieSceneParameterSectionExtender
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieSceneParameterSectionExtender : UInterface {
};

// Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0x1d0 (Inherited: 0x160)
struct UMovieSceneParameterSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct TArray<struct FBoolParameterNameAndCurve> BoolParameterNamesAndCurves; // 0x168(0x10)
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // 0x178(0x10)
	struct TArray<struct FVector2DParameterNameAndCurves> Vector2DParameterNamesAndCurves; // 0x188(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // 0x198(0x10)
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // 0x1a8(0x10)
	struct TArray<struct FTransformParameterNameAndCurves> TransformParameterNamesAndCurves; // 0x1b8(0x10)
	char pad_1c8[0x8]; // 0x1c8(0x08)

	bool RemoveVectorParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveVectorParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2831ef0
	bool RemoveVector2DParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveVector2DParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x27f2550
	bool RemoveTransformParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveTransformParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x27ef7f0
	bool RemoveScalarParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveScalarParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2843cb0
	bool RemoveColorParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveColorParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2849350
	bool RemoveBoolParameter(struct FName InParameterName); // Function MovieSceneTracks.MovieSceneParameterSection.RemoveBoolParameter // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x28456f0
	void GetParameterNames(struct TSet<struct FName>& ParameterNames); // Function MovieSceneTracks.MovieSceneParameterSection.GetParameterNames // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x27cc0d0
	void AddVectorParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FVector InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddVectorParameterKey // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x27e9290
	void AddVector2DParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FVector2D InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddVector2DParameterKey // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x283b950
	void AddTransformParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FTransform& InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddTransformParameterKey // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x27cfcd0
	void AddScalarParameterKey(struct FName InParameterName, struct FFrameNumber InTime, float InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddScalarParameterKey // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x27fc660
	void AddColorParameterKey(struct FName InParameterName, struct FFrameNumber InTime, struct FLinearColor InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddColorParameterKey // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x283df50
	void AddBoolParameterKey(struct FName InParameterName, struct FFrameNumber InTime, bool InValue); // Function MovieSceneTracks.MovieSceneParameterSection.AddBoolParameterKey // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x27cd930
};

// Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x270 (Inherited: 0x160)
struct UMovieSceneParticleSection : UMovieSceneSection {
	struct FMovieSceneParticleChannel ParticleKeys; // 0x160(0x108)
	char pad_268[0x8]; // 0x268(0x08)
};

// Class MovieSceneTracks.MovieScenePrimitiveMaterialSection
// Size: 0x2a0 (Inherited: 0x160)
struct UMovieScenePrimitiveMaterialSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneObjectPathChannel MaterialChannel; // 0x168(0x130)
	char pad_298[0x8]; // 0x298(0x08)
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x3d0 (Inherited: 0x160)
struct UMovieSceneSkeletalAnimationSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneSkeletalAnimationParams Params; // 0x168(0x150)
	struct UAnimSequence* AnimSequence; // 0x2b8(0x08)
	struct UAnimSequenceBase* Animation; // 0x2c0(0x08)
	float StartOffset; // 0x2c8(0x04)
	float EndOffset; // 0x2cc(0x04)
	float PlayRate; // 0x2d0(0x04)
	char bReverse : 1; // 0x2d4(0x01)
	char pad_2d4_1 : 7; // 0x2d4(0x01)
	char pad_2d5[0x3]; // 0x2d5(0x03)
	struct FName SlotName; // 0x2d8(0x08)
	struct FVector StartLocationOffset; // 0x2e0(0x18)
	struct FRotator StartRotationOffset; // 0x2f8(0x18)
	bool bMatchWithPrevious; // 0x310(0x01)
	char pad_311[0x3]; // 0x311(0x03)
	struct FName MatchedBoneName; // 0x314(0x08)
	char pad_31c[0x4]; // 0x31c(0x04)
	struct FVector MatchedLocationOffset; // 0x320(0x18)
	struct FRotator MatchedRotationOffset; // 0x338(0x18)
	bool bMatchTranslation; // 0x350(0x01)
	bool bMatchIncludeZHeight; // 0x351(0x01)
	bool bMatchRotationYaw; // 0x352(0x01)
	bool bMatchRotationPitch; // 0x353(0x01)
	bool bMatchRotationRoll; // 0x354(0x01)
	char pad_355[0x7b]; // 0x355(0x7b)
};

// Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x270 (Inherited: 0x160)
struct UMovieSceneSlomoSection : UMovieSceneSection {
	struct FMovieSceneFloatChannel FloatCurve; // 0x160(0x110)
};

// Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x280 (Inherited: 0x160)
struct UMovieSceneStringSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneStringChannel StringCurve; // 0x168(0x110)
	char pad_278[0x8]; // 0x278(0x08)
};

// Class MovieSceneTracks.MovieSceneFloatVectorSection
// Size: 0x5b0 (Inherited: 0x160)
struct UMovieSceneFloatVectorSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneFloatChannel Curves[0x4]; // 0x168(0x440)
	int32_t ChannelsUsed; // 0x5a8(0x04)
	char pad_5ac[0x4]; // 0x5ac(0x04)
};

// Class MovieSceneTracks.MovieSceneDoubleVectorSection
// Size: 0x5d0 (Inherited: 0x160)
struct UMovieSceneDoubleVectorSection : UMovieSceneSection {
	char pad_160[0x8]; // 0x160(0x08)
	struct FMovieSceneDoubleChannel Curves[0x4]; // 0x168(0x460)
	int32_t ChannelsUsed; // 0x5c8(0x04)
	char pad_5cc[0x4]; // 0x5cc(0x04)
};

// Class MovieSceneTracks.BoolChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UBoolChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.ByteChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UByteChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.DoubleChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UDoubleChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.DoublePerlinNoiseChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UDoublePerlinNoiseChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.FloatChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UFloatChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.FloatPerlinNoiseChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UFloatPerlinNoiseChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.IntegerChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UIntegerChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.MovieScenePropertySystem
// Size: 0xd0 (Inherited: 0xb0)
struct UMovieScenePropertySystem : UMovieSceneEntitySystem {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct UMovieScenePropertyInstantiatorSystem* InstantiatorSystem; // 0xb8(0x08)
	char pad_c0[0x10]; // 0xc0(0x10)
};

// Class MovieSceneTracks.MovieScene3DTransformPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieScene3DTransformPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneAudioSystem
// Size: 0x160 (Inherited: 0xb0)
struct UMovieSceneAudioSystem : UMovieSceneEntitySystem {
	char pad_b0[0xb0]; // 0xb0(0xb0)
};

// Class MovieSceneTracks.MovieSceneBaseValueEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneBaseValueEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.MovieSceneBoolPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneBoolPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneBytePropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneBytePropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneColorPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneColorPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneComponentAttachmentInvalidatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneComponentAttachmentInvalidatorSystem : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieSceneTracks.MovieSceneComponentAttachmentSystem
// Size: 0x240 (Inherited: 0xb0)
struct UMovieSceneComponentAttachmentSystem : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0x190]; // 0xb0(0x190)
};

// Class MovieSceneTracks.MovieSceneComponentMaterialSystem
// Size: 0x210 (Inherited: 0xb0)
struct UMovieSceneComponentMaterialSystem : UMovieSceneEntitySystem {
	char pad_b0[0x160]; // 0xb0(0x160)
};

// Class MovieSceneTracks.MovieSceneComponentMobilitySystem
// Size: 0x2a0 (Inherited: 0xb0)
struct UMovieSceneComponentMobilitySystem : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0x1f0]; // 0xb0(0x1f0)
};

// Class MovieSceneTracks.MovieSceneComponentTransformSystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneComponentTransformSystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneConstraintSystem
// Size: 0xc0 (Inherited: 0xb0)
struct UMovieSceneConstraintSystem : UMovieSceneEntitySystem {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class MovieSceneTracks.MovieSceneDataLayerSystem
// Size: 0x140 (Inherited: 0xb0)
struct UMovieSceneDataLayerSystem : UMovieSceneEntitySystem {
	char pad_b0[0x90]; // 0xb0(0x90)
};

// Class MovieSceneTracks.MovieSceneDeferredComponentMovementSystem
// Size: 0xd0 (Inherited: 0xb0)
struct UMovieSceneDeferredComponentMovementSystem : UMovieSceneEntitySystem {
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class MovieSceneTracks.MovieSceneDoublePropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneDoublePropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneEnumPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneEnumPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneEulerTransformPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneEulerTransformPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneEventSystem
// Size: 0x100 (Inherited: 0xb0)
struct UMovieSceneEventSystem : UMovieSceneEntitySystem {
	char pad_b0[0x50]; // 0xb0(0x50)
};

// Class MovieSceneTracks.MovieScenePreSpawnEventSystem
// Size: 0x100 (Inherited: 0x100)
struct UMovieScenePreSpawnEventSystem : UMovieSceneEventSystem {
};

// Class MovieSceneTracks.MovieScenePostSpawnEventSystem
// Size: 0x100 (Inherited: 0x100)
struct UMovieScenePostSpawnEventSystem : UMovieSceneEventSystem {
};

// Class MovieSceneTracks.MovieScenePostEvalEventSystem
// Size: 0x100 (Inherited: 0x100)
struct UMovieScenePostEvalEventSystem : UMovieSceneEventSystem {
};

// Class MovieSceneTracks.MovieSceneFadeSystem
// Size: 0xc0 (Inherited: 0xb0)
struct UMovieSceneFadeSystem : UMovieSceneEntitySystem {
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class MovieSceneTracks.MovieSceneFloatPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneFloatPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneHierarchicalBiasSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneHierarchicalBiasSystem : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieSceneTracks.MovieSceneInitialValueSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneInitialValueSystem : UMovieSceneEntityInstantiatorSystem {
};

// Class MovieSceneTracks.MovieSceneIntegerPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneIntegerPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneLevelVisibilitySystem
// Size: 0x220 (Inherited: 0xb0)
struct UMovieSceneLevelVisibilitySystem : UMovieSceneEntitySystem {
	char pad_b0[0x170]; // 0xb0(0x170)
};

// Class MovieSceneTracks.MovieSceneMaterialParameterCollectionSystem
// Size: 0xd0 (Inherited: 0xb0)
struct UMovieSceneMaterialParameterCollectionSystem : UMovieSceneEntitySystem {
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class MovieSceneTracks.MovieSceneMaterialParameterSystem
// Size: 0x3c0 (Inherited: 0xb0)
struct UMovieSceneMaterialParameterSystem : UMovieSceneEntitySystem {
	char pad_b0[0x300]; // 0xb0(0x300)
	struct UMovieScenePiecewiseDoubleBlenderSystem* DoubleBlenderSystem; // 0x3b0(0x08)
	char pad_3b8[0x8]; // 0x3b8(0x08)
};

// Class MovieSceneTracks.MovieSceneMotionVectorSimulationSystem
// Size: 0x110 (Inherited: 0xb0)
struct UMovieSceneMotionVectorSimulationSystem : UMovieSceneEntitySystem {
	char pad_b0[0x60]; // 0xb0(0x60)
};

// Class MovieSceneTracks.MovieScenePiecewiseBoolBlenderSystem
// Size: 0x100 (Inherited: 0xe0)
struct UMovieScenePiecewiseBoolBlenderSystem : UMovieSceneBlenderSystem {
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class MovieSceneTracks.MovieScenePiecewiseByteBlenderSystem
// Size: 0x100 (Inherited: 0xe0)
struct UMovieScenePiecewiseByteBlenderSystem : UMovieSceneBlenderSystem {
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class MovieSceneTracks.MovieScenePiecewiseDoubleBlenderSystem
// Size: 0x1a0 (Inherited: 0xe0)
struct UMovieScenePiecewiseDoubleBlenderSystem : UMovieSceneBlenderSystem {
	char pad_e0[0xc0]; // 0xe0(0xc0)
};

// Class MovieSceneTracks.MovieScenePiecewiseEnumBlenderSystem
// Size: 0x100 (Inherited: 0xe0)
struct UMovieScenePiecewiseEnumBlenderSystem : UMovieSceneBlenderSystem {
	char pad_e0[0x20]; // 0xe0(0x20)
};

// Class MovieSceneTracks.MovieScenePiecewiseIntegerBlenderSystem
// Size: 0x120 (Inherited: 0xe0)
struct UMovieScenePiecewiseIntegerBlenderSystem : UMovieSceneBlenderSystem {
	char pad_e0[0x40]; // 0xe0(0x40)
};

// Class MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction
// Size: 0xf0 (Inherited: 0xa0)
struct UMovieSceneAsyncAction_SequencePrediction : UBlueprintAsyncActionBase {
	struct FMulticastInlineDelegate Result; // 0xa0(0x10)
	struct FMulticastInlineDelegate Failure; // 0xb0(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)
	struct UMovieSceneSequencePlayer* SequencePlayer; // 0xd0(0x08)
	struct USceneComponent* SceneComponent; // 0xd8(0x08)
	char pad_e0[0x10]; // 0xe0(0x10)

	struct UMovieSceneAsyncAction_SequencePrediction* PredictWorldTransformAtTime(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, float TimeInSeconds); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictWorldTransformAtTime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2861350
	struct UMovieSceneAsyncAction_SequencePrediction* PredictWorldTransformAtFrame(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, struct FFrameTime FrameTime); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictWorldTransformAtFrame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x284ea90
	struct UMovieSceneAsyncAction_SequencePrediction* PredictLocalTransformAtTime(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, float TimeInSeconds); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictLocalTransformAtTime // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x2885990
	struct UMovieSceneAsyncAction_SequencePrediction* PredictLocalTransformAtFrame(struct UMovieSceneSequencePlayer* Player, struct USceneComponent* TargetComponent, struct FFrameTime FrameTime); // Function MovieSceneTracks.MovieSceneAsyncAction_SequencePrediction.PredictLocalTransformAtFrame // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x287de60
};

// Class MovieSceneTracks.MovieScenePredictionSystem
// Size: 0x160 (Inherited: 0xb0)
struct UMovieScenePredictionSystem : UMovieSceneEntitySystem {
	char pad_b0[0x90]; // 0xb0(0x90)
	struct TArray<struct UMovieSceneAsyncAction_SequencePrediction*> PendingPredictions; // 0x140(0x10)
	struct TArray<struct UMovieSceneAsyncAction_SequencePrediction*> ProcessingPredictions; // 0x150(0x10)
};

// Class MovieSceneTracks.MovieScenePropertyInstantiatorSystem
// Size: 0x2e0 (Inherited: 0xb0)
struct UMovieScenePropertyInstantiatorSystem : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0x230]; // 0xb0(0x230)
};

// Class MovieSceneTracks.MovieSceneQuaternionBlenderSystem
// Size: 0x140 (Inherited: 0xe0)
struct UMovieSceneQuaternionBlenderSystem : UMovieSceneBlenderSystem {
	char pad_e0[0x60]; // 0xe0(0x60)
};

// Class MovieSceneTracks.MovieSceneQuaternionInterpolationRotationSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneQuaternionInterpolationRotationSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationSystem
// Size: 0x150 (Inherited: 0xb0)
struct UMovieSceneSkeletalAnimationSystem : UMovieSceneEntitySystem {
	char pad_b0[0xa0]; // 0xb0(0xa0)
};

// Class MovieSceneTracks.MovieSceneStringPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneStringPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneTransformOriginInstantiatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UMovieSceneTransformOriginInstantiatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.MovieSceneTransformOriginSystem
// Size: 0xf0 (Inherited: 0xb0)
struct UMovieSceneTransformOriginSystem : UMovieSceneEntitySystem {
	char pad_b0[0x40]; // 0xb0(0x40)
};

// Class MovieSceneTracks.MovieSceneFloatVectorPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneFloatVectorPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.MovieSceneDoubleVectorPropertySystem
// Size: 0xd0 (Inherited: 0xd0)
struct UMovieSceneDoubleVectorPropertySystem : UMovieScenePropertySystem {
};

// Class MovieSceneTracks.ObjectPathChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UObjectPathChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.StringChannelEvaluatorSystem
// Size: 0xb0 (Inherited: 0xb0)
struct UStringChannelEvaluatorSystem : UMovieSceneEntitySystem {
};

// Class MovieSceneTracks.MovieSceneHierarchicalEasingInstantiatorSystem
// Size: 0x150 (Inherited: 0xb0)
struct UMovieSceneHierarchicalEasingInstantiatorSystem : UMovieSceneEntityInstantiatorSystem {
	char pad_b0[0x88]; // 0xb0(0x88)
	struct UWeightAndEasingEvaluatorSystem* EvaluatorSystem; // 0x138(0x08)
	char pad_140[0x10]; // 0x140(0x10)
};

// Class MovieSceneTracks.MovieSceneHierarchicalEasingFinalizationSystem
// Size: 0xc0 (Inherited: 0xb0)
struct UMovieSceneHierarchicalEasingFinalizationSystem : UMovieSceneEntityInstantiatorSystem {
	struct UMovieSceneHierarchicalEasingInstantiatorSystem* InstantiatorSystem; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class MovieSceneTracks.WeightAndEasingEvaluatorSystem
// Size: 0xd0 (Inherited: 0xb0)
struct UWeightAndEasingEvaluatorSystem : UMovieSceneEntitySystem {
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class MovieSceneTracks.MovieSceneCameraCutTrackInstance
// Size: 0x140 (Inherited: 0xc0)
struct UMovieSceneCameraCutTrackInstance : UMovieSceneTrackInstance {
	char pad_c0[0x80]; // 0xc0(0x80)
};

// Class MovieSceneTracks.MovieSceneCVarTrackInstance
// Size: 0x110 (Inherited: 0xc0)
struct UMovieSceneCVarTrackInstance : UMovieSceneTrackInstance {
	char pad_c0[0x50]; // 0xc0(0x50)
};

// Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieScene3DConstraintTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> ConstraintSections; // 0x108(0x10)
};

// Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0x120 (Inherited: 0x120)
struct UMovieScene3DAttachTrack : UMovieScene3DConstraintTrack {
};

// Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0x120 (Inherited: 0x120)
struct UMovieScene3DPathTrack : UMovieScene3DConstraintTrack {
};

// Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0x140 (Inherited: 0x110)
struct UMovieScenePropertyTrack : UMovieSceneNameableTrack {
	struct UMovieSceneSection* SectionToKey; // 0x108(0x08)
	struct FMovieScenePropertyBinding PropertyBinding; // 0x110(0x14)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x128(0x10)
	char pad_13c[0x4]; // 0x13c(0x04)
};

// Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0x150 (Inherited: 0x140)
struct UMovieScene3DTransformTrack : UMovieScenePropertyTrack {
	struct UMovieSceneBlenderSystem* BlenderSystemClass; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneActorReferenceTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneAudioTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AudioSections; // 0x108(0x10)
};

// Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneBoolTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneByteTrack : UMovieScenePropertyTrack {
	struct UEnum* Enum; // 0x138(0x08)
};

// Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneCameraCutTrack : UMovieSceneNameableTrack {
	bool bCanBlend; // 0x108(0x01)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x110(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraShakeSourceShakeTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneCameraShakeSourceShakeTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // 0x110(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraShakeSourceTriggerTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneCameraShakeSourceTriggerTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x110(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneCameraShakeTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // 0x110(0x10)
};

// Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0x120 (Inherited: 0x120)
struct UMovieSceneCinematicShotTrack : UMovieSceneSubTrack {
};

// Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneColorTrack : UMovieScenePropertyTrack {
	bool bIsSlateColor; // 0x138(0x01)
};

// Class MovieSceneTracks.MovieSceneCVarTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneCVarTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
};

// Class MovieSceneTracks.MovieSceneDataLayerTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneDataLayerTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
};

// Class MovieSceneTracks.MovieSceneDoubleTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneDoubleTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneEnumTrack : UMovieScenePropertyTrack {
	struct UEnum* Enum; // 0x138(0x08)
};

// Class MovieSceneTracks.MovieSceneEulerTransformTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneEulerTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0x130 (Inherited: 0x110)
struct UMovieSceneEventTrack : UMovieSceneNameableTrack {
	char pad_110[0x8]; // 0x110(0x08)
	char bFireEventsWhenForwards : 1; // 0x118(0x01)
	char bFireEventsWhenBackwards : 1; // 0x118(0x01)
	char pad_118_2 : 6; // 0x118(0x01)
	char pad_119[0x3]; // 0x119(0x03)
	enum class EFireEventsAtPosition EventPosition; // 0x11c(0x01)
	char pad_11d[0x3]; // 0x11d(0x03)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x120(0x10)
};

// Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneFloatTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneFadeTrack : UMovieSceneFloatTrack {
};

// Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneIntegerTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneLevelVisibilityTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
};

// Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneMaterialTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x108(0x10)
	struct UMovieSceneSection* SectionToKey; // 0x118(0x08)
};

// Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0x140 (Inherited: 0x120)
struct UMovieSceneMaterialParameterCollectionTrack : UMovieSceneMaterialTrack {
	char pad_120[0x10]; // 0x120(0x10)
	struct UMaterialParameterCollection* MPC; // 0x130(0x08)
	char pad_138[0x8]; // 0x138(0x08)
};

// Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0x140 (Inherited: 0x120)
struct UMovieSceneComponentMaterialTrack : UMovieSceneMaterialTrack {
	char pad_120[0x10]; // 0x120(0x10)
	int32_t MaterialIndex; // 0x130(0x04)
	char pad_134[0xc]; // 0x134(0x0c)
};

// Class MovieSceneTracks.MovieSceneObjectPropertyTrack
// Size: 0x150 (Inherited: 0x140)
struct UMovieSceneObjectPropertyTrack : UMovieScenePropertyTrack {
	ClassPtrProperty PropertyClass; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneParticleParameterTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x110(0x10)
};

// Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneParticleTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> ParticleSections; // 0x110(0x10)
};

// Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieScenePrimitiveMaterialTrack : UMovieScenePropertyTrack {
	int32_t MaterialIndex; // 0x138(0x04)
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0x1b0 (Inherited: 0x110)
struct UMovieSceneSkeletalAnimationTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AnimationSections; // 0x108(0x10)
	bool bUseLegacySectionIndexBlend; // 0x118(0x01)
	struct FMovieSceneSkeletalAnimRootMotionTrackParams RootMotionParams; // 0x120(0x80)
	bool bBlendFirstChildOfRoot; // 0x1a0(0x01)
	enum class ESwapRootBone SwapRootBone; // 0x1a1(0x01)
	char pad_1a3[0xd]; // 0x1a3(0x0d)

	void SetSwapRootBone(enum class ESwapRootBone InValue); // Function MovieSceneTracks.MovieSceneSkeletalAnimationTrack.SetSwapRootBone // (Final|RequiredAPI|Native|Public) // @ game+0x28aa200
	enum class ESwapRootBone GetSwapRootBone(); // Function MovieSceneTracks.MovieSceneSkeletalAnimationTrack.GetSwapRootBone // (Final|RequiredAPI|Native|Public|Const) // @ game+0x28a85a0
};

// Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneSlomoTrack : UMovieSceneFloatTrack {
};

// Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneStringTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneFloatVectorTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneFloatVectorTrack : UMovieScenePropertyTrack {
	int32_t NumChannelsUsed; // 0x138(0x04)
};

// Class MovieSceneTracks.MovieSceneDoubleVectorTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneDoubleVectorTrack : UMovieScenePropertyTrack {
	int32_t NumChannelsUsed; // 0x138(0x04)
};

// Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0x140 (Inherited: 0x140)
struct UMovieSceneVisibilityTrack : UMovieSceneBoolTrack {
};

