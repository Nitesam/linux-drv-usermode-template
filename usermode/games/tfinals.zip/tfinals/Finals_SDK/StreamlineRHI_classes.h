// Class StreamlineRHI.StreamlineOverrideSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UStreamlineOverrideSettings : UObject {
	enum class EStreamlineSettingOverride EnableDLSSFGInPlayInEditorViewportsOverride; // 0x98(0x01)
	enum class EStreamlineSettingOverride LoadDebugOverlayOverride; // 0x99(0x01)
};

// Class StreamlineRHI.StreamlineSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UStreamlineSettings : UObject {
	bool bEnableStreamlineD3D12; // 0x98(0x01)
	bool bEnableStreamlineD3D11; // 0x99(0x01)
	bool bEnableDLSSFGInPlayInEditorViewports; // 0x9a(0x01)
	bool bLoadDebugOverlay; // 0x9b(0x01)
	bool bAllowOTAUpdate; // 0x9c(0x01)
	int32_t NVIDIANGXApplicationId; // 0xa0(0x04)
	char pad_a9[0x7]; // 0xa9(0x07)
};

