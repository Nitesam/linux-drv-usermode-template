// Enum EmbarkWaterPhysics.EWaterPhysicsDebugLevel
enum class EWaterPhysicsDebugLevel : uint8_t {
	None = 0,
	Normal = 1,
	Verbose = 2,
	EWaterPhysicsDebugLevel_MAX = 3
};

// Enum EmbarkWaterPhysics.EWaterPhysicsTessellationMode
enum class EWaterPhysicsTessellationMode : uint8_t {
	Levels = 0,
	Area = 1,
	EWaterPhysicsTessellationMode_MAX = 2
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterPhysicsForce
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkWaterPhysicsForce {
	struct FVector Force; // 0x00(0x18)
	struct FVector Torque; // 0x18(0x18)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterBodyPhysicsState
// Size: 0xb0 (Inherited: 0x00)
struct FEmbarkWaterBodyPhysicsState {
	struct FVector LinearVelocity; // 0x00(0x18)
	struct FVector AngularVelocity; // 0x18(0x18)
	struct FVector CenterOfMass; // 0x30(0x18)
	float Mass; // 0x48(0x04)
	char pad_4c[0x4]; // 0x4c(0x04)
	struct FTransform Transform; // 0x50(0x60)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterBodyMesh
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkWaterBodyMesh {
	struct TArray<struct FVector> Vertices; // 0x00(0x10)
	struct TArray<int32_t> Indices; // 0x10(0x10)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkSubmergedTriangleData
// Size: 0x110 (Inherited: 0x00)
struct FEmbarkSubmergedTriangleData {
	struct FVector Centroid; // 0x00(0x18)
	struct FVector Normal; // 0x18(0x18)
	float Area; // 0x30(0x04)
	float AvgDepth; // 0x34(0x04)
	struct FVector Velocity; // 0x38(0x18)
	struct FVector VelocityNormal; // 0x50(0x18)
	float VelocityNormalDot; // 0x68(0x04)
	float VelocitySize; // 0x6c(0x04)
	float VelocityNormalDirectionSize; // 0x70(0x04)
	float VelocitySizeSquared; // 0x74(0x04)
	int32_t OriginalTriangleIndex; // 0x78(0x04)
	char pad_7c[0x94]; // 0x7c(0x94)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterPhysicsBody
// Size: 0x1b0 (Inherited: 0x00)
struct FEmbarkWaterPhysicsBody {
	struct FEmbarkWaterBodyPhysicsState PhysicsState; // 0x00(0xb0)
	struct FEmbarkWaterBodyMesh RefMesh; // 0xb0(0x20)
	bool bEnableWaterPhysics; // 0xd0(0x01)
	char pad_d1[0x7]; // 0xd1(0x07)
	struct FEmbarkWaterSurfaceInfo WaterSurfaceInfo; // 0xd8(0x48)
	struct FEmbarkWaterPhysicsSettings WaterPhysicsSettings; // 0x120(0x40)
	struct UObject* UserObject; // 0x160(0x08)
	struct TArray<float> TrianglesSweptWaterArea; // 0x168(0x10)
	struct FEmbarkWaterPhysicsForce TotalWaterPhysicsForce; // 0x178(0x30)
	float SubmersionDepth; // 0x1a8(0x04)
	char pad_1ac[0x4]; // 0x1ac(0x04)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterPhysicsSettings
// Size: 0x40 (Inherited: 0x00)
struct FEmbarkWaterPhysicsSettings {
	char bOverride_FluidDensity : 1; // 0x00(0x01)
	char bOverride_FluidKinematicViscocity : 1; // 0x00(0x01)
	char bOverride_SubmergedTessellationSettings : 1; // 0x00(0x01)
	char bOverride_PressureCoefficientOfLinearSpeed : 1; // 0x00(0x01)
	char bOverride_PressureCoefficientOfExponentialSpeed : 1; // 0x00(0x01)
	char bOverride_PressureAngularDependence : 1; // 0x00(0x01)
	char bOverride_SuctionCoefficientOfLinearSpeed : 1; // 0x00(0x01)
	char bOverride_SuctionCoefficientOfExponentialSpeed : 1; // 0x00(0x01)
	char bOverride_SuctionAngularDependence : 1; // 0x01(0x01)
	char bOverride_DragReferenceSpeed : 1; // 0x01(0x01)
	char bOverride_MaxSlammingForceAtAcceleration : 1; // 0x01(0x01)
	char bOverride_SlammingForceExponent : 1; // 0x01(0x01)
	char bOverride_bEnableBuoyancyForce : 1; // 0x01(0x01)
	char bOverride_bEnableViscousFluidResistance : 1; // 0x01(0x01)
	char bOverride_bEnablePressureDragForce : 1; // 0x01(0x01)
	char bOverride_bEnableSlammingForce : 1; // 0x01(0x01)
	char bOverride_DebugSubmersion : 1; // 0x02(0x01)
	char bOverride_DebugTriangleData : 1; // 0x02(0x01)
	char bOverride_DebugBuoyancyForce : 1; // 0x02(0x01)
	char bOverride_DebugViscousFluidResistance : 1; // 0x02(0x01)
	char bOverride_DebugPressureDragForce : 1; // 0x02(0x01)
	char bOverride_DebugSlammingForce : 1; // 0x02(0x01)
	char bOverride_DebugFluidVelocity : 1; // 0x02(0x01)
	char pad_2_7 : 1; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	float FluidDensity; // 0x04(0x04)
	float FluidKinematicViscocity; // 0x08(0x04)
	struct FEmbarkWaterTessellationSettings SubmergedTessellationSettings; // 0x0c(0x0c)
	float PressureCoefficientOfLinearSpeed; // 0x18(0x04)
	float PressureCoefficientOfExponentialSpeed; // 0x1c(0x04)
	float PressureAngularDependence; // 0x20(0x04)
	float SuctionCoefficientOfLinearSpeed; // 0x24(0x04)
	float SuctionCoefficientOfExponentialSpeed; // 0x28(0x04)
	float SuctionAngularDependence; // 0x2c(0x04)
	float DragReferenceSpeed; // 0x30(0x04)
	float MaxSlammingForceAtAcceleration; // 0x34(0x04)
	float SlammingForceExponent; // 0x38(0x04)
	bool bEnableBuoyancyForce; // 0x3c(0x01)
	bool bEnableViscousFluidResistance; // 0x3d(0x01)
	bool bEnablePressureDragForce; // 0x3e(0x01)
	bool bEnableSlammingForce; // 0x3f(0x01)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterTessellationSettings
// Size: 0x0c (Inherited: 0x00)
struct FEmbarkWaterTessellationSettings {
	enum class EWaterPhysicsTessellationMode TessellationMode; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float MaxArea; // 0x04(0x04)
	int32_t Levels; // 0x08(0x04)
};

// ScriptStruct EmbarkWaterPhysics.EmbarkWaterSurfaceInfo
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkWaterSurfaceInfo {
	struct FVector WaterSurfaceLocation; // 0x00(0x18)
	struct FVector WaterSurfaceNormal; // 0x18(0x18)
	struct FVector WaterVelocity; // 0x30(0x18)
};

