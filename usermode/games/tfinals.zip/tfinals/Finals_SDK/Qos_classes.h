// Class Qos.QosBeaconClient
// Size: 0x460 (Inherited: 0x430)
struct AQosBeaconClient : AOnlineBeaconClient {
	char pad_430[0x30]; // 0x430(0x30)

	void ServerQosRequest(struct FString InSessionId); // Function Qos.QosBeaconClient.ServerQosRequest // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0x8cefef0
	void ClientQosResponse(enum class EQosResponseType Response); // Function Qos.QosBeaconClient.ClientQosResponse // (Net|NetReliableNative|Event|Protected|NetClient) // @ game+0x8ceb4c0
};

// Class Qos.QosBeaconHost
// Size: 0x3d0 (Inherited: 0x3c0)
struct AQosBeaconHost : AOnlineBeaconHostObject {
	char pad_3c0[0x10]; // 0x3c0(0x10)
};

// Class Qos.QosEvaluator
// Size: 0xf0 (Inherited: 0xa0)
struct UQosEvaluator : UObject {
	char pad_a0[0x18]; // 0xa0(0x18)
	bool bInProgress; // 0xb8(0x01)
	bool bCancelOperation; // 0xb9(0x01)
	char pad_ba[0x6]; // 0xba(0x06)
	struct TArray<struct FDatacenterQosInstance> DataCenters; // 0xc0(0x10)
	char pad_d0[0x20]; // 0xd0(0x20)
};

// Class Qos.QosRegionManager
// Size: 0x170 (Inherited: 0xa0)
struct UQosRegionManager : UObject {
	int32_t NumTestsPerRegion; // 0x98(0x04)
	float PingTimeout; // 0x9c(0x04)
	bool bEnableSubspaceBiasOrder; // 0xa0(0x01)
	struct FString SubspaceDelimiter; // 0xa8(0x10)
	struct TArray<struct FQosRegionInfo> RegionDefinitions; // 0xb8(0x10)
	struct TArray<struct FQosDatacenterInfo> DatacenterDefinitions; // 0xc8(0x10)
	struct FDateTime LastCheckTimestamp; // 0xd8(0x08)
	struct UQosEvaluator* Evaluator; // 0xe0(0x08)
	enum class EQosCompletionResult QosEvalResult; // 0xe8(0x01)
	char pad_ea[0x6]; // 0xea(0x06)
	struct TArray<struct FRegionQosInstance> RegionOptions; // 0xf0(0x10)
	struct FString ForceRegionId; // 0x100(0x10)
	bool bRegionForcedViaCommandline; // 0x110(0x01)
	char pad_111[0x7]; // 0x111(0x07)
	struct FString SelectedRegionId; // 0x118(0x10)
	char pad_128[0x48]; // 0x128(0x48)
};

