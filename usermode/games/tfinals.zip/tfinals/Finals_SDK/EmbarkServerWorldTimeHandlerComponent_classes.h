// Class EmbarkServerWorldTimeHandlerComponent.ServerWorldTimeHandlerComponentFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UServerWorldTimeHandlerComponentFactory : UHandlerComponentFactory {
};

