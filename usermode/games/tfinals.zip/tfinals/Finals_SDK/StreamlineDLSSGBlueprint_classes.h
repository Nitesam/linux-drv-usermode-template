// Class StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG
// Size: 0xa0 (Inherited: 0xa0)
struct UStreamlineLibraryDLSSG : UBlueprintFunctionLibrary {

	void SetDLSSGMode(enum class EStreamlineDLSSGMode DLSSGMode); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.SetDLSSGMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x54c3510
	enum class EStreamlineFeatureSupport QueryDLSSGSupport(); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.QueryDLSSGSupport // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c3700
	bool IsDLSSGSupported(); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.IsDLSSGSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c6580
	bool IsDLSSGModeSupported(enum class EStreamlineDLSSGMode DLSSGMode); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.IsDLSSGModeSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c3920
	struct TArray<enum class EStreamlineDLSSGMode> GetSupportedDLSSGModes(); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.GetSupportedDLSSGModes // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c3b40
	enum class EStreamlineDLSSGMode GetDLSSGMode(); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.GetDLSSGMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c2de0
	void GetDLSSGFrameTiming(float& FrameRateInHertz, int32_t& FramesPresented); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.GetDLSSGFrameTiming // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x54c3780
	enum class EStreamlineDLSSGMode GetDefaultDLSSGMode(); // Function StreamlineDLSSGBlueprint.StreamlineLibraryDLSSG.GetDefaultDLSSGMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x54c3d30
};

