// ScriptStruct EmbarkPerformanceRecorder.EmbarkNetDriverPerformanceRecording
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkNetDriverPerformanceRecording {
	struct TArray<char> FrameTimeData; // 0x00(0x10)
};

