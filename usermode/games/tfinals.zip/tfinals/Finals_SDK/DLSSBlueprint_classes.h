// Class DLSSBlueprint.DLSSLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDLSSLibrary : UBlueprintFunctionLibrary {

	void SetDLSSSharpness(float Sharpness); // Function DLSSBlueprint.DLSSLibrary.SetDLSSSharpness // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5aaf010
	void SetDLSSMode(struct UObject* WorldContextObject, enum class UDLSSMode DLSSMode); // Function DLSSBlueprint.DLSSLibrary.SetDLSSMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5aace30
	enum class UDLSSSupport QueryDLSSSupport(); // Function DLSSBlueprint.DLSSLibrary.QueryDLSSSupport // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aac960
	enum class UDLSSSupport QueryDLSSRRSupport(); // Function DLSSBlueprint.DLSSLibrary.QueryDLSSRRSupport // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aa9780
	bool IsRayTracingAvailable(); // Function DLSSBlueprint.DLSSLibrary.IsRayTracingAvailable // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aaf1b0
	bool IsDLSSSupported(); // Function DLSSBlueprint.DLSSLibrary.IsDLSSSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aac400
	bool IsDLSSRRSupported(); // Function DLSSBlueprint.DLSSLibrary.IsDLSSRRSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aacf90
	bool IsDLSSRREnabled(); // Function DLSSBlueprint.DLSSLibrary.IsDLSSRREnabled // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aaf0b0
	bool IsDLSSModeSupported(enum class UDLSSMode DLSSMode); // Function DLSSBlueprint.DLSSLibrary.IsDLSSModeSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aaeb40
	bool IsDLSSEnabled(); // Function DLSSBlueprint.DLSSLibrary.IsDLSSEnabled // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aae430
	bool IsDLAAEnabled(); // Function DLSSBlueprint.DLSSLibrary.IsDLAAEnabled // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aaec70
	struct TArray<enum class UDLSSMode> GetSupportedDLSSModes(); // Function DLSSBlueprint.DLSSLibrary.GetSupportedDLSSModes // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aabff0
	float GetDLSSSharpness(); // Function DLSSBlueprint.DLSSLibrary.GetDLSSSharpness // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aadb80
	void GetDLSSScreenPercentageRange(float& MinScreenPercentage, float& MaxScreenPercentage); // Function DLSSBlueprint.DLSSLibrary.GetDLSSScreenPercentageRange // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5aacc10
	void GetDLSSRRMinimumDriverVersion(int32_t& MinDriverVersionMajor, int32_t& MinDriverVersionMinor); // Function DLSSBlueprint.DLSSLibrary.GetDLSSRRMinimumDriverVersion // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5aad070
	void GetDLSSModeInformation(enum class UDLSSMode DLSSMode, struct FVector2D ScreenResolution, bool& bIsSupported, float& OptimalScreenPercentage, bool& bIsFixedScreenPercentage, float& MinScreenPercentage, float& MaxScreenPercentage, float& OptimalSharpness); // Function DLSSBlueprint.DLSSLibrary.GetDLSSModeInformation // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5aae4a0
	enum class UDLSSMode GetDLSSMode(); // Function DLSSBlueprint.DLSSLibrary.GetDLSSMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aaca80
	void GetDLSSMinimumDriverVersion(int32_t& MinDriverVersionMajor, int32_t& MinDriverVersionMinor); // Function DLSSBlueprint.DLSSLibrary.GetDLSSMinimumDriverVersion // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5aae8a0
	enum class UDLSSMode GetDefaultDLSSMode(); // Function DLSSBlueprint.DLSSLibrary.GetDefaultDLSSMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5aac080
	void EnableDLSSRR(bool bEnabled); // Function DLSSBlueprint.DLSSLibrary.EnableDLSSRR // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5aa92e0
	void EnableDLSS(bool bEnabled); // Function DLSSBlueprint.DLSSLibrary.EnableDLSS // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5aad7d0
	void EnableDLAA(bool bEnabled); // Function DLSSBlueprint.DLSSLibrary.EnableDLAA // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5aacb30
};

