// Class Party.Chatroom
// Size: 0xd0 (Inherited: 0xa0)
struct UChatroom : UObject {
	struct FString CurrentChatRoomId; // 0x98(0x10)
	int32_t MaxChatRoomRetries; // 0xa8(0x04)
	int32_t NumChatRoomRetries; // 0xac(0x04)
	char pad_b8[0x18]; // 0xb8(0x18)
};

// Class Party.SocialManager
// Size: 0x220 (Inherited: 0xa0)
struct USocialManager : UObject {
	char pad_a0[0x78]; // 0xa0(0x78)
	struct TArray<struct USocialToolkit*> SocialToolkits; // 0x118(0x10)
	struct USocialDebugTools* SocialDebugTools; // 0x128(0x08)
	char pad_130[0xf0]; // 0x130(0xf0)
};

// Class Party.SocialToolkit
// Size: 0x320 (Inherited: 0xa0)
struct USocialToolkit : UObject {
	char pad_a0[0x38]; // 0xa0(0x38)
	struct USocialUser* LocalUser; // 0xd8(0x08)
	struct TArray<struct USocialUser*> AllUsers; // 0xe0(0x10)
	char pad_f0[0x50]; // 0xf0(0x50)
	bool bRemoveInvalidatedUserFromMaps; // 0x140(0x01)
	char pad_141[0x3]; // 0x141(0x03)
	struct TWeakObjectPtr<struct ULocalPlayer> LocalPlayerOwner; // 0x144(0x08)
	char pad_14c[0x4]; // 0x14c(0x04)
	struct USocialChatManager* SocialChatManager; // 0x150(0x08)
	char pad_158[0x1c8]; // 0x158(0x1c8)
};

// Class Party.SocialChatManager
// Size: 0x290 (Inherited: 0xa0)
struct USocialChatManager : UObject {
	char pad_a0[0x48]; // 0xa0(0x48)
	struct TMap<struct TWeakObjectPtr<struct USocialUser>, struct USocialPrivateMessageChannel*> DirectChannelsByTargetUser; // 0xe8(0x50)
	struct TMap<struct FString, struct USocialChatRoom*> ChatRoomsById; // 0x138(0x50)
	struct TMap<struct FString, struct USocialReadOnlyChatChannel*> ReadOnlyChannelsByDisplayName; // 0x188(0x50)
	bool bEnableChatSlashCommands; // 0x1d8(0x01)
	char pad_1d9[0x7]; // 0x1d9(0x07)
	struct TMap<struct FUniqueNetIdRepl, struct USocialGroupChannel*> GroupChannels; // 0x1e0(0x50)
	char pad_230[0x60]; // 0x230(0x60)
};

// Class Party.SocialChatChannel
// Size: 0x160 (Inherited: 0xa0)
struct USocialChatChannel : UObject {
	char pad_a0[0xc0]; // 0xa0(0xc0)
};

// Class Party.SocialChatRoom
// Size: 0x170 (Inherited: 0x160)
struct USocialChatRoom : USocialChatChannel {
	char pad_160[0x10]; // 0x160(0x10)
};

// Class Party.SocialGroupChannel
// Size: 0x110 (Inherited: 0xa0)
struct USocialGroupChannel : UObject {
	struct USocialUser* SocialUser; // 0x98(0x08)
	struct FUniqueNetIdRepl GroupId; // 0xa0(0x30)
	struct FText DisplayName; // 0xd0(0x18)
	struct TArray<struct USocialUser*> Members; // 0xe8(0x10)
	char pad_100[0x10]; // 0x100(0x10)
};

// Class Party.SocialPartyChatRoom
// Size: 0x170 (Inherited: 0x170)
struct USocialPartyChatRoom : USocialChatRoom {
};

// Class Party.SocialPrivateMessageChannel
// Size: 0x160 (Inherited: 0x160)
struct USocialPrivateMessageChannel : USocialChatChannel {
	struct USocialUser* TargetUser; // 0x158(0x08)
};

// Class Party.SocialReadOnlyChatChannel
// Size: 0x160 (Inherited: 0x160)
struct USocialReadOnlyChatChannel : USocialChatChannel {
};

// Class Party.SocialParty
// Size: 0x3f0 (Inherited: 0xa0)
struct USocialParty : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)
	struct APartyBeaconClient* ReservationBeaconClientClass; // 0xd0(0x08)
	struct ASpectatorBeaconClient* SpectatorBeaconClientClass; // 0xd8(0x08)
	char pad_e0[0x10]; // 0xe0(0x10)
	struct FUniqueNetIdRepl OwningLocalUserId; // 0xf0(0x30)
	struct FUniqueNetIdRepl CurrentLeaderId; // 0x120(0x30)
	struct TMap<struct FUniqueNetIdRepl, struct UPartyMember*> PartyMembersById; // 0x150(0x50)
	bool bEnableAutomaticPartyRejoin; // 0x1a0(0x01)
	char pad_1a1[0x57]; // 0x1a1(0x57)
	double PlatformUserInviteCooldown; // 0x1f8(0x08)
	double PrimaryUserInviteCooldown; // 0x200(0x08)
	char pad_208[0x74]; // 0x208(0x74)
	struct TWeakObjectPtr<struct APartyBeaconClient> ReservationBeaconClient; // 0x27c(0x08)
	char pad_284[0x8]; // 0x284(0x08)
	struct TWeakObjectPtr<struct ASpectatorBeaconClient> SpectatorBeaconClient; // 0x28c(0x08)
	char pad_294[0x2c]; // 0x294(0x2c)
	float JoinInProgressTimerRate; // 0x2c0(0x04)
	int32_t JoinInProgressRequestTimeout; // 0x2c4(0x04)
	int32_t JoinInProgressResponseTimeout; // 0x2c8(0x04)
	char pad_2cc[0x124]; // 0x2cc(0x124)
};

// Class Party.PartyMember
// Size: 0x180 (Inherited: 0xa0)
struct UPartyMember : UObject {
	char pad_a0[0x40]; // 0xa0(0x40)
	struct USocialUser* SocialUser; // 0xe0(0x08)
	char pad_e8[0x98]; // 0xe8(0x98)
};

// Class Party.SocialDebugTools
// Size: 0x100 (Inherited: 0xa0)
struct USocialDebugTools : UObject {
	char pad_a0[0x60]; // 0xa0(0x60)
};

// Class Party.SocialSettings
// Size: 0xe0 (Inherited: 0xa0)
struct USocialSettings : UObject {
	struct TArray<struct FName> OssNamesWithEnvironmentIdPrefix; // 0x98(0x10)
	int32_t DefaultMaxPartySize; // 0xa8(0x04)
	bool bPreferPlatformInvites; // 0xac(0x01)
	bool bMustSendPrimaryInvites; // 0xad(0x01)
	bool bLeavePartyOnDisconnect; // 0xae(0x01)
	bool bSetDesiredPrivacyOnLocalPlayerBecomesLeader; // 0xaf(0x01)
	float UserListAutoUpdateRate; // 0xb0(0x04)
	int32_t MinNicknameLength; // 0xb4(0x04)
	int32_t MaxNicknameLength; // 0xb8(0x04)
	struct TArray<struct FSocialPlatformDescription> SocialPlatformDescriptions; // 0xc0(0x10)
	struct TArray<struct FName> SonyOSSNames; // 0xd0(0x10)
};

// Class Party.SocialUser
// Size: 0x240 (Inherited: 0xa0)
struct USocialUser : UObject {
	char pad_a0[0x1a0]; // 0xa0(0x1a0)
};

