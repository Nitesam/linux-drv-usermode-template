// Class BinkMediaPlayer.BinkFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UBinkFunctionLibrary : UBlueprintFunctionLibrary {

	void SetBinkEncryptionDatabase(struct TMap<struct FString, struct FString>& FilenameToKeyMap); // Function BinkMediaPlayer.BinkFunctionLibrary.SetBinkEncryptionDatabase // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fcb960
	struct FTimespan BinkLoadingMovie_GetTime(); // Function BinkMediaPlayer.BinkFunctionLibrary.BinkLoadingMovie_GetTime // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4fd4b80
	struct FTimespan BinkLoadingMovie_GetDuration(); // Function BinkMediaPlayer.BinkFunctionLibrary.BinkLoadingMovie_GetDuration // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x4fd3a30
	void Bink_DrawOverlays(); // Function BinkMediaPlayer.BinkFunctionLibrary.Bink_DrawOverlays // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x4fcd0e0
};

// Class BinkMediaPlayer.BinkMediaPlayer
// Size: 0x180 (Inherited: 0xa0)
struct UBinkMediaPlayer : UObject {
	struct FMulticastInlineDelegate OnMediaClosed; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnMediaOpened; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnMediaReachedEnd; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnPlaybackSuspended; // 0xd0(0x10)
	char Looping : 1; // 0xe0(0x01)
	char StartImmediately : 1; // 0xe0(0x01)
	char DelayedOpen : 1; // 0xe0(0x01)
	char pad_e0_3 : 5; // 0xe0(0x01)
	char pad_e1[0x7]; // 0xe1(0x07)
	struct FVector2D BinkDestinationUpperLeft; // 0xe8(0x10)
	struct FVector2D BinkDestinationLowerRight; // 0xf8(0x10)
	struct FString URL; // 0x108(0x10)
	enum class EBinkMediaPlayerBinkBufferModes BinkBufferMode; // 0x118(0x01)
	enum class EBinkMediaPlayerBinkSoundTrack BinkSoundTrack; // 0x119(0x01)
	char pad_11a[0x2]; // 0x11a(0x02)
	int32_t BinkSoundTrackStart; // 0x11c(0x04)
	enum class EBinkMediaPlayerBinkDrawStyle BinkDrawStyle; // 0x120(0x01)
	char pad_121[0x3]; // 0x121(0x03)
	int32_t BinkLayerDepth; // 0x124(0x04)
	char pad_128[0x58]; // 0x128(0x58)

	bool SupportsSeeking(); // Function BinkMediaPlayer.BinkMediaPlayer.SupportsSeeking // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ae8f50
	bool SupportsScrubbing(); // Function BinkMediaPlayer.BinkMediaPlayer.SupportsScrubbing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2ae8f50
	bool SupportsRate(float Rate, bool Unthinned); // Function BinkMediaPlayer.BinkMediaPlayer.SupportsRate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fcccf0
	void Stop(); // Function BinkMediaPlayer.BinkMediaPlayer.Stop // (Final|Native|Public|BlueprintCallable) // @ game+0x4fcd5a0
	void SetVolume(float Rate); // Function BinkMediaPlayer.BinkMediaPlayer.SetVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x4fc9750
	bool SetRate(float Rate); // Function BinkMediaPlayer.BinkMediaPlayer.SetRate // (Final|Native|Public|BlueprintCallable) // @ game+0x4fd3bb0
	bool SetLooping(bool InLooping); // Function BinkMediaPlayer.BinkMediaPlayer.SetLooping // (Final|Native|Public|BlueprintCallable) // @ game+0x4fd41b0
	bool Seek(struct FTimespan& InTime); // Function BinkMediaPlayer.BinkMediaPlayer.Seek // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x4fd2640
	bool Rewind(); // Function BinkMediaPlayer.BinkMediaPlayer.Rewind // (Final|Native|Public|BlueprintCallable) // @ game+0x4fd5bf0
	bool Play(); // Function BinkMediaPlayer.BinkMediaPlayer.Play // (Final|Native|Public|BlueprintCallable) // @ game+0x4fcce80
	bool Pause(); // Function BinkMediaPlayer.BinkMediaPlayer.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0x4fd3c60
	bool OpenUrl(struct FString NewUrl); // Function BinkMediaPlayer.BinkMediaPlayer.OpenUrl // (Final|Native|Public|BlueprintCallable) // @ game+0x4fd84e0
	bool IsStopped(); // Function BinkMediaPlayer.BinkMediaPlayer.IsStopped // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fd1f30
	bool IsPlaying(); // Function BinkMediaPlayer.BinkMediaPlayer.IsPlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fcacf0
	bool IsPaused(); // Function BinkMediaPlayer.BinkMediaPlayer.IsPaused // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fcb5a0
	bool IsLooping(); // Function BinkMediaPlayer.BinkMediaPlayer.IsLooping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fca3b0
	bool IsInitialized(); // Function BinkMediaPlayer.BinkMediaPlayer.IsInitialized // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fd60f0
	struct FString GetUrl(); // Function BinkMediaPlayer.BinkMediaPlayer.GetUrl // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fcce00
	struct FTimespan GetTime(); // Function BinkMediaPlayer.BinkMediaPlayer.GetTime // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fdbc00
	float GetRate(); // Function BinkMediaPlayer.BinkMediaPlayer.GetRate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fca050
	struct FTimespan GetDuration(); // Function BinkMediaPlayer.BinkMediaPlayer.GetDuration // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fcd4c0
	void Draw(struct UTexture* Texture, bool tonemap, int32_t out_nits, float Alpha, bool srgb_decode, bool hdr); // Function BinkMediaPlayer.BinkMediaPlayer.Draw // (Final|Native|Public|BlueprintCallable) // @ game+0x4fcdb50
	void CloseUrl(); // Function BinkMediaPlayer.BinkMediaPlayer.CloseUrl // (Final|Native|Public|BlueprintCallable) // @ game+0x4fce040
	bool CanPlay(); // Function BinkMediaPlayer.BinkMediaPlayer.CanPlay // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fd60f0
	bool CanPause(); // Function BinkMediaPlayer.BinkMediaPlayer.CanPause // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fcacf0
};

// Class BinkMediaPlayer.BinkMediaTexture
// Size: 0x2e0 (Inherited: 0x2a0)
struct UBinkMediaTexture : UTexture {
	enum class TextureAddress AddressX; // 0x2a0(0x01)
	enum class TextureAddress AddressY; // 0x2a1(0x01)
	char pad_2a2[0x6]; // 0x2a2(0x06)
	struct UBinkMediaPlayer* MediaPlayer; // 0x2a8(0x08)
	enum class EPixelFormat PixelFormat; // 0x2b0(0x01)
	bool tonemap; // 0x2b1(0x01)
	char pad_2b2[0x2]; // 0x2b2(0x02)
	float OutputNits; // 0x2b4(0x04)
	float Alpha; // 0x2b8(0x04)
	bool DecodeSRGB; // 0x2bc(0x01)
	char pad_2bd[0x23]; // 0x2bd(0x23)

	void SetMediaPlayer(struct UBinkMediaPlayer* InMediaPlayer); // Function BinkMediaPlayer.BinkMediaTexture.SetMediaPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x4fda880
	void Clear(); // Function BinkMediaPlayer.BinkMediaTexture.Clear // (Final|Native|Public|BlueprintCallable) // @ game+0x4fc9d80
};

// Class BinkMediaPlayer.BinkMoviePlayerSettings
// Size: 0xd0 (Inherited: 0xa0)
struct UBinkMoviePlayerSettings : UObject {
	enum class EBinkMoviePlayerBinkBufferModes BinkBufferMode; // 0x98(0x01)
	enum class EBinkMoviePlayerBinkSoundTrack BinkSoundTrack; // 0x99(0x01)
	int32_t BinkSoundTrackStart; // 0x9c(0x04)
	struct FVector2D BinkDestinationUpperLeft; // 0xa0(0x10)
	struct FVector2D BinkDestinationLowerRight; // 0xb0(0x10)
	enum class EPixelFormat BinkPixelFormat; // 0xc0(0x01)
	char pad_c7[0x9]; // 0xc7(0x09)
};

