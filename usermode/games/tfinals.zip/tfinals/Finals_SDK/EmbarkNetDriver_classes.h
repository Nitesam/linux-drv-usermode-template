// Class EmbarkNetDriver.EmbarkControlChannel
// Size: 0x230 (Inherited: 0xf0)
struct UEmbarkControlChannel : UControlChannel {
	char pad_f0[0x140]; // 0xf0(0x140)
};

// Class EmbarkNetDriver.EmbarkIpConnection
// Size: 0x1f60 (Inherited: 0x1f00)
struct UEmbarkIpConnection : UIpConnection {
	char pad_1f00[0x18]; // 0x1f00(0x18)
	double UnresponsiveConnectionTimeoutSeconds; // 0x1f18(0x08)
	char pad_1f20[0x40]; // 0x1f20(0x40)

	void SetUnresponsiveConnectionTelemetryEnabled(bool bEnabled); // Function EmbarkNetDriver.EmbarkIpConnection.SetUnresponsiveConnectionTelemetryEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x59f0d10
};

// Class EmbarkNetDriver.EmbarkNetDriver
// Size: 0x990 (Inherited: 0x8f0)
struct UEmbarkNetDriver : UIpNetDriver {
	char pad_8f0[0xa0]; // 0x8f0(0xa0)
};

