// Class NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffect
// Size: 0xf0 (Inherited: 0xa0)
struct UAnimNotifyState_TimedNiagaraEffect : UAnimNotifyState {
	struct UNiagaraSystem* Template; // 0xa0(0x08)
	struct FName SocketName; // 0xa8(0x08)
	struct FVector LocationOffset; // 0xb0(0x18)
	struct FRotator RotationOffset; // 0xc8(0x18)
	bool bDestroyAtEnd; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)

	struct UFXSystemComponent* GetSpawnedEffect(struct UMeshComponent* MeshComp); // Function NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffect.GetSpawnedEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x6822010
};

// Class NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffectAdvanced
// Size: 0x160 (Inherited: 0xf0)
struct UAnimNotifyState_TimedNiagaraEffectAdvanced : UAnimNotifyState_TimedNiagaraEffect {
	bool bEnableNormalizedNotifyProgress; // 0xe8(0x01)
	struct FName NotifyProgressUserParameter; // 0xec(0x08)
	struct TArray<struct FCurveParameterPair> AnimCurves; // 0xf8(0x10)
	char pad_109[0x57]; // 0x109(0x57)

	float GetNotifyProgress(struct UMeshComponent* MeshComp); // Function NiagaraAnimNotifies.AnimNotifyState_TimedNiagaraEffectAdvanced.GetNotifyProgress // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x6824490
};

// Class NiagaraAnimNotifies.AnimNotify_PlayNiagaraEffect
// Size: 0x140 (Inherited: 0xb0)
struct UAnimNotify_PlayNiagaraEffect : UAnimNotify {
	struct UNiagaraSystem* Template; // 0xa8(0x08)
	struct FVector LocationOffset; // 0xb0(0x18)
	struct FRotator RotationOffset; // 0xc8(0x18)
	struct FVector Scale; // 0xe0(0x18)
	bool bAbsoluteScale; // 0xf8(0x01)
	char pad_101[0x2f]; // 0x101(0x2f)
	char Attached : 1; // 0x130(0x01)
	char pad_130_1 : 7; // 0x130(0x01)
	char pad_131[0x3]; // 0x131(0x03)
	struct FName SocketName; // 0x134(0x08)
	char pad_13c[0x4]; // 0x13c(0x04)

	struct UFXSystemComponent* GetSpawnedEffect(); // Function NiagaraAnimNotifies.AnimNotify_PlayNiagaraEffect.GetSpawnedEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x32ab230
};

