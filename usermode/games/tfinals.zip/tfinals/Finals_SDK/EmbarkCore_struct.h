// ScriptStruct EmbarkCore.TenancyUserId
// Size: 0x10 (Inherited: 0x00)
struct FTenancyUserId {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkCore.EmbarkUserId
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkUserId {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkCore.EmbarkServerPerformanceBudgetScope
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkServerPerformanceBudgetScope {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkCore.EmbarkScriptStruct
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkScriptStruct {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct EmbarkCore.EmbarkScriptStructMap
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkScriptStructMap {
	struct TMap<struct FName, struct FEmbarkScriptStruct> Structs; // 0x00(0x50)
};

// ScriptStruct EmbarkCore.EmbarkScriptStructHolder
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkScriptStructHolder {
	struct TMap<struct FName, struct FEmbarkScriptStructMap> StructMap; // 0x00(0x50)
};

// ScriptStruct EmbarkCore.FeatureFlagLock
// Size: 0x20 (Inherited: 0x00)
struct FFeatureFlagLock {
	struct FString EnableFeatureFlag; // 0x00(0x10)
	struct FString DisableFeatureFlag; // 0x10(0x10)
};

// ScriptStruct EmbarkCore.FeatureFlag
// Size: 0x10 (Inherited: 0x00)
struct FFeatureFlag {
	struct FString Name; // 0x00(0x10)
};

// ScriptStruct EmbarkCore.ScopedFeatureFlagOverride
// Size: 0x10 (Inherited: 0x00)
struct FScopedFeatureFlagOverride {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkCore.ManifestInfo
// Size: 0x50 (Inherited: 0x00)
struct FManifestInfo {
	struct FString CL; // 0x00(0x10)
	struct FString Identifier; // 0x10(0x10)
	struct FString BaseIdentifier; // 0x20(0x10)
	struct FString BuildNumber; // 0x30(0x10)
	struct FString Configuration; // 0x40(0x10)
};

// ScriptStruct EmbarkCore.VersionInfo
// Size: 0x48 (Inherited: 0x00)
struct FVersionInfo {
	int32_t DataVersion; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Build; // 0x08(0x10)
	struct FString BaseIdentifier; // 0x18(0x10)
	struct FString BuildNumber; // 0x28(0x10)
	struct FString Configuration; // 0x38(0x10)
};

