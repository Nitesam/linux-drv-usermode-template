// ScriptStruct AngelscriptGAS.AngelscriptModifiedAttribute
// Size: 0x10 (Inherited: 0x00)
struct FAngelscriptModifiedAttribute {
	struct FName Name; // 0x00(0x08)
	float OldValue; // 0x08(0x04)
	float NewValue; // 0x0c(0x04)
};

// ScriptStruct AngelscriptGAS.AngelscriptInputBindData
// Size: 0x28 (Inherited: 0x00)
struct FAngelscriptInputBindData {
	struct FName ConfirmTargetCommand; // 0x00(0x08)
	struct FName CancelTargetCommand; // 0x08(0x08)
	struct FTopLevelAssetPath EnumName; // 0x10(0x10)
	int32_t ConfirmTargetInputID; // 0x20(0x04)
	int32_t CancelTargetInputID; // 0x24(0x04)
};

// ScriptStruct AngelscriptGAS.AngelscriptAttributeChangedData
// Size: 0x48 (Inherited: 0x00)
struct FAngelscriptAttributeChangedData {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct AngelscriptGAS.DelegateHandleWrapper
// Size: 0x08 (Inherited: 0x00)
struct FDelegateHandleWrapper {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct AngelscriptGAS.AngelscriptGameplayAttributeData
// Size: 0x18 (Inherited: 0x10)
struct FAngelscriptGameplayAttributeData : FGameplayAttributeData {
	struct FName AttributeName; // 0x10(0x08)
};

// ScriptStruct AngelscriptGAS.GameplayEffectExecutionParameters
// Size: 0x68 (Inherited: 0x00)
struct FGameplayEffectExecutionParameters {
	char pad_0[0x68]; // 0x00(0x68)
};

// ScriptStruct AngelscriptGAS.AngelscriptTagContainerAggregator
// Size: 0x60 (Inherited: 0x00)
struct FAngelscriptTagContainerAggregator {
	struct FGameplayTagContainer CapturedActorTags; // 0x00(0x20)
	struct FGameplayTagContainer CapturedSpecTags; // 0x20(0x20)
	struct FGameplayTagContainer AggregatedTags; // 0x40(0x20)
};

