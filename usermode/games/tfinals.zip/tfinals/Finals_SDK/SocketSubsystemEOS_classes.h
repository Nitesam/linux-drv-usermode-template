// Class SocketSubsystemEOS.NetConnectionEOS
// Size: 0x1f10 (Inherited: 0x1f00)
struct UNetConnectionEOS : UIpConnection {
	char pad_1f00[0x10]; // 0x1f00(0x10)
};

// Class SocketSubsystemEOS.NetDriverEOSBase
// Size: 0x8f0 (Inherited: 0x8f0)
struct UNetDriverEOSBase : UIpNetDriver {
	bool bIsPassthrough; // 0x8e8(0x01)
	bool bIsUsingP2PSockets; // 0x8e9(0x01)
};

