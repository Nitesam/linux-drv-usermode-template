// Class AvfMediaFactory.AvfMediaSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UAvfMediaSettings : UObject {
	bool NativeAudioOut; // 0x98(0x01)
};

