// Class DiscoveryOnline.ServiceBattlePass
// Size: 0x140 (Inherited: 0xa0)
struct UServiceBattlePass : UObject {
	struct FApiGatewayDiscoveryBattlePassDescription Pack; // 0x98(0x68)
	struct FServiceBattlePassState State; // 0x100(0x40)
};

// Class DiscoveryOnline.InventoryServiceItemSkin
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceItemSkin : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceItemAnimation
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceItemAnimation : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceSchematicItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceSchematicItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceLoadoutItem
// Size: 0x140 (Inherited: 0xf0)
struct UInventoryServiceLoadoutItem : UInventoryServiceItemBase {
	struct TArray<struct FString> SchematicIds; // 0xe8(0x10)
	struct TArray<struct UInventoryServiceSchematicItem*> Schematics; // 0xf8(0x10)
	int64_t CosmeticNumber; // 0x108(0x08)
	struct FString CharacterId; // 0x110(0x10)
	struct UInventoryServiceCharacterItem* Character; // 0x120(0x08)
	struct FString Etag; // 0x128(0x10)
};

// Class DiscoveryOnline.InventoryServiceCurrencyItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceCurrencyItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceCharacterItem
// Size: 0x130 (Inherited: 0xf0)
struct UInventoryServiceCharacterItem : UInventoryServiceItemBase {
	struct TArray<struct FString> SelectedSkinIds; // 0xe8(0x10)
	struct TArray<struct UInventoryServiceCharacterSkinItem*> SelectedSkins; // 0xf8(0x10)
	struct TArray<struct FString> SelectedSchematicIds; // 0x108(0x10)
	struct TArray<struct UInventoryServiceSchematicItem*> SelectedSchematics; // 0x118(0x10)
};

// Class DiscoveryOnline.InventoryServiceCharacterSkinItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceCharacterSkinItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceBucketItem
// Size: 0x100 (Inherited: 0xf0)
struct UInventoryServiceBucketItem : UInventoryServiceItemBase {
	struct FString BucketId; // 0xe8(0x10)
};

// Class DiscoveryOnline.InventoryServiceBattlepassItem
// Size: 0x100 (Inherited: 0xf0)
struct UInventoryServiceBattlepassItem : UInventoryServiceItemBase {
	struct TArray<int64_t> ClaimedEntries; // 0xe8(0x10)
	int64_t ConsumedLevels; // 0xf8(0x08)
};

// Class DiscoveryOnline.InventoryServiceItemCharmItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceItemCharmItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceItemStickerItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceItemStickerItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceSprayItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceSprayItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceEmoticonItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceEmoticonItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceSkillItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceSkillItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceSanctionItem
// Size: 0x110 (Inherited: 0xf0)
struct UInventoryServiceSanctionItem : UInventoryServiceItemBase {
	enum class EApiGatewayDiscoverySanctionType SanctionType; // 0xe8(0x01)
	int32_t Tier; // 0xec(0x04)
	int64_t TimeOfSanction; // 0xf0(0x08)
	int64_t Duration; // 0xf8(0x08)
	struct FString Etag; // 0x100(0x10)
};

// Class DiscoveryOnline.InventoryServiceQuestItem
// Size: 0x190 (Inherited: 0xf0)
struct UInventoryServiceQuestItem : UInventoryServiceItemBase {
	int32_t Week; // 0xe8(0x04)
	int64_t SlotId; // 0xf0(0x08)
	bool Accepted; // 0xf8(0x01)
	char pad_fd[0x3]; // 0xfd(0x03)
	struct FPlayerPersistenceQuestReward QuestReward; // 0x100(0x50)
	bool bIsTracked; // 0x150(0x01)
	bool bIsDebugGenerated; // 0x151(0x01)
	char pad_152[0x6]; // 0x152(0x06)
	struct FMulticastInlineDelegate OnQuestItemChanged; // 0x158(0x10)
	bool bHasSetQuestTimeState; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
	int64_t UpdatedAt; // 0x170(0x08)
	struct FQuestTimeStateEntry QuestTimeStateEntry; // 0x178(0x10)
	char pad_188[0x8]; // 0x188(0x08)

	bool SetQuestTimeState(struct FQuestTimeStateEntry& InQuestStateEntry); // Function DiscoveryOnline.InventoryServiceQuestItem.SetQuestTimeState // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60483d0
	struct FQuestTimeStateEntry GetQuestStateTimeEntry(); // Function DiscoveryOnline.InventoryServiceQuestItem.GetQuestStateTimeEntry // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x604a040
};

// Class DiscoveryOnline.InventoryServiceItemAttachment
// Size: 0x110 (Inherited: 0xa0)
struct UInventoryServiceItemAttachment : UObject {
	struct FString ItemId; // 0x98(0x10)
	struct UInventoryServiceSchematicItem* Item; // 0xa8(0x08)
	struct TArray<struct FString> AttachedItemIds; // 0xb0(0x10)
	struct TArray<struct UInventoryServiceItemSkin*> AttachedSkins; // 0xc0(0x10)
	struct TArray<struct UInventoryServiceItemCharmItem*> AttachedCharms; // 0xd0(0x10)
	struct TArray<struct UInventoryServiceItemStickerItem*> AttachedStickers; // 0xe0(0x10)
	struct TArray<struct UInventoryServiceItemAnimation*> AttachedAnimationCustomizations; // 0xf0(0x10)
	struct TArray<struct UInventoryServiceWeaponAttachmentItem*> AttachedWeaponAttachments; // 0x100(0x10)
};

// Class DiscoveryOnline.InventoryServiceDiscoveryContestantPackItem
// Size: 0x2a0 (Inherited: 0xf0)
struct UInventoryServiceDiscoveryContestantPackItem : UInventoryServiceItemBase {
	struct FString ArchetypeId; // 0xe8(0x10)
	struct UInventoryServiceCharacterItem* Archetype; // 0xf8(0x08)
	struct TArray<struct FString> FirstHandIds; // 0x100(0x10)
	struct TArray<struct UInventoryServiceItemBase*> FirstHandItems; // 0x110(0x10)
	struct TArray<struct FString> ReservedIds; // 0x120(0x10)
	struct TArray<struct UInventoryServiceItemBase*> ReservedItems; // 0x130(0x10)
	struct TArray<struct FString> CustomizationIds; // 0x140(0x10)
	struct TArray<struct UInventoryServiceCharacterSkinItem*> CustomizationItems; // 0x150(0x10)
	struct TMap<struct FString, struct UInventoryServiceItemAttachment*> ItemAttachments; // 0x160(0x50)
	struct FString ExpressionItemId; // 0x1b0(0x10)
	struct UInventoryServiceItemBase* ExpressionItem; // 0x1c0(0x08)
	struct TArray<struct FString> ActionWheel01ItemIds; // 0x1c8(0x10)
	struct TArray<struct UInventoryServiceItemBase*> ActionWheel01Items; // 0x1d8(0x10)
	struct TArray<struct FString> ActionWheel02ItemIds; // 0x1e8(0x10)
	struct TArray<struct UInventoryServiceItemBase*> ActionWheel02Items; // 0x1f8(0x10)
	struct TArray<struct FString> ActionWheel03ItemIds; // 0x208(0x10)
	struct TArray<struct UInventoryServiceItemBase*> ActionWheel03Items; // 0x218(0x10)
	struct FString IntroPoseItemId; // 0x228(0x10)
	struct UInventoryServiceCharacterSkinItem* IntroPoseItem; // 0x238(0x08)
	struct FString VictoryPoseItemId; // 0x240(0x10)
	struct FString OutfitPackId; // 0x250(0x10)
	struct FString ObjectiveStickerId; // 0x260(0x10)
	struct UInventoryServiceItemBase* ObjectiveStickerItem; // 0x270(0x08)
	struct UInventoryServiceCharacterSkinItem* VictoryPoseItem; // 0x278(0x08)
	struct FString Etag; // 0x280(0x10)
	struct FString Title; // 0x290(0x10)

	bool IsEmpty(); // Function DiscoveryOnline.InventoryServiceDiscoveryContestantPackItem.IsEmpty // (Final|Native|Public|Const) // @ game+0x6047ee0
};

// Class DiscoveryOnline.InventoryServiceDiscoveryPlayerCardCustomizationItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceDiscoveryPlayerCardCustomizationItem : UInventoryServiceItemBase {
	int64_t Level; // 0xe8(0x08)
};

// Class DiscoveryOnline.InventoryServiceDiscoveryPlayerCardItem
// Size: 0x180 (Inherited: 0xf0)
struct UInventoryServiceDiscoveryPlayerCardItem : UInventoryServiceItemBase {
	struct FString Etag; // 0xe8(0x10)
	int64_t UpdatedAt; // 0xf8(0x08)
	struct FString BackgroundItemId; // 0x100(0x10)
	struct UInventoryServiceDiscoveryPlayerCardCustomizationItem* Background; // 0x110(0x08)
	struct FString BorderItemId; // 0x118(0x10)
	struct UInventoryServiceDiscoveryPlayerCardCustomizationItem* Border; // 0x128(0x08)
	struct FString BadgeOneItemId; // 0x130(0x10)
	struct UInventoryServiceDiscoveryPlayerCardCustomizationItem* BadgeOne; // 0x140(0x08)
	struct FString BadgeTwoItemId; // 0x148(0x10)
	struct UInventoryServiceDiscoveryPlayerCardCustomizationItem* BadgeTwo; // 0x158(0x08)
	struct FString BadgeThreeItemId; // 0x160(0x10)
	struct UInventoryServiceDiscoveryPlayerCardCustomizationItem* BadgeThree; // 0x170(0x08)
};

// Class DiscoveryOnline.InventoryServiceWeaponAttachmentItem
// Size: 0xf0 (Inherited: 0xf0)
struct UInventoryServiceWeaponAttachmentItem : UInventoryServiceItemBase {
};

// Class DiscoveryOnline.InventoryServiceClansCustomizationItem
// Size: 0x100 (Inherited: 0xf0)
struct UInventoryServiceClansCustomizationItem : UInventoryServiceItemBase {
	struct FString Etag; // 0xe8(0x10)
};

// Class DiscoveryOnline.InventoryServicePersistentEntityItem
// Size: 0x110 (Inherited: 0xf0)
struct UInventoryServicePersistentEntityItem : UInventoryServiceItemBase {
	struct FString Etag; // 0xe8(0x10)
	struct FString RawProperties; // 0xf8(0x10)
};

// Class DiscoveryOnline.InventoryServiceItemChange
// Size: 0x120 (Inherited: 0xa0)
struct UInventoryServiceItemChange : UObject {
	enum class EApiGatewayDiscoveryInventoryItemChangeReason Reason; // 0x98(0x01)
	enum class EApiGatewayDiscoveryInventoryItemChangeSource Source; // 0x99(0x01)
	enum class EApiGatewayDiscoveryInventoryItemChangeActionType Action; // 0x9a(0x01)
	struct FApiGatewayDiscoveryInventoryItemChangeDetails Details; // 0xa0(0x08)
	struct FApiGatewayDiscoveryInventoryItemChangeNotification Notification; // 0xa8(0x60)
	struct FString InstanceId; // 0x108(0x10)
	int64_t AmountDelta; // 0x118(0x08)
};

// Class DiscoveryOnline.DiscoveryItemLiveMeta
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoveryItemLiveMeta : UObject {
	int64_t ItemId; // 0x98(0x08)
	struct FString LocalizedTitle; // 0xa0(0x10)
	struct FString LocalizedDescription; // 0xb0(0x10)
	struct FString Rarity; // 0xc0(0x10)
};

// Class DiscoveryOnline.DiscoveryItemLiveMetaList
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoveryItemLiveMetaList : UObject {
	struct TArray<struct UDiscoveryItemLiveMeta*> LiveMetas; // 0x98(0x10)
};

// Class DiscoveryOnline.DiscoveryLeaderboards
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoveryLeaderboards : UObject {
	struct TArray<struct FApiGatewayDiscoveryLeaderboardDescription> LeaderboardsDescription; // 0x98(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardData> AllLeaderboards; // 0xa8(0x10)
	struct TArray<struct FApiGatewayDiscoveryLeaderboardData> FilteredLeaderboards; // 0xb8(0x10)
};

// Class DiscoveryOnline.DiscoveryOnlineBattlePassModel
// Size: 0x140 (Inherited: 0xb0)
struct UDiscoveryOnlineBattlePassModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncBattlePassCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnBattlePassesUpdated; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnUpgradeBattlepassLevelCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnAutoClaimBattlePassEntriesCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnSyncBattlePassDescriptionsCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnPurchaseHistoricalBattlePassEntryCompleted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnBatchPurchaseHistoricalBattlePassEntriesCompleted; // 0x108(0x10)
	struct UServiceBattlePass* CurrentBattlePass; // 0x118(0x08)
	struct TArray<struct UServiceBattlePass*> BattlePasses; // 0x120(0x10)
	struct TArray<struct FApiGatewayDiscoveryBattlePassDescription> BattlePassDescriptions; // 0x130(0x10)

	void UpgradeBattlePassLevel(struct FString ItemId, int32_t NextLevel); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.UpgradeBattlePassLevel // (Native|Event|Public|BlueprintEvent) // @ game+0x6045e50
	void SyncBattlePassDescriptions(); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.SyncBattlePassDescriptions // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void SyncBattlePass(); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.SyncBattlePass // (Native|Event|Public|BlueprintEvent) // @ game+0x32add10
	void PurchaseHistoricalBattlePassEntries(int64_t BattlePassPackId, int64_t EntryId); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.PurchaseHistoricalBattlePassEntries // (Native|Event|Public|BlueprintEvent) // @ game+0x604b370
	void LocalSyncBattlePass(struct UInventoryServiceInventory* Inventory, struct UDiscoveryPlayerRankInfo* RankInfo); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.LocalSyncBattlePass // (Native|Event|Public|BlueprintEvent) // @ game+0x6047160
	struct TArray<struct FApiGatewayDiscoveryBattlePassDescription> GetBattlePassDescriptions(); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.GetBattlePassDescriptions // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6049ae0
	struct UServiceBattlePass* GetBattlePass(); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.GetBattlePass // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376240
	struct TArray<struct UServiceBattlePass*> GetAllBattlePasses(); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.GetAllBattlePasses // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x604b2d0
	void BatchPurchaseHistoricalBattlePassEntries(int64_t BattlePassPackId, struct TArray<int64_t>& EntryIds); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.BatchPurchaseHistoricalBattlePassEntries // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6049600
	void AutoClaimBattlePassEntries(); // Function DiscoveryOnline.DiscoveryOnlineBattlePassModel.AutoClaimBattlePassEntries // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
};

// Class DiscoveryOnline.SyncBattlePassCompleteResultListener
// Size: 0xc0 (Inherited: 0xb0)
struct USyncBattlePassCompleteResultListener : UEventListenerBase {
	char pad_b0[0x10]; // 0xb0(0x10)

	void OnEvent(bool _bSucceeded, bool _bHasNewClaimedEntries); // Function DiscoveryOnline.SyncBattlePassCompleteResultListener.OnEvent // (Final|Native|Public) // @ game+0x604d5a0
};

// Class DiscoveryOnline.UpgradeBattlePassLevelRequestCompleteResultListener
// Size: 0xc0 (Inherited: 0xb0)
struct UUpgradeBattlePassLevelRequestCompleteResultListener : UEventListenerBase {
	char pad_b0[0x10]; // 0xb0(0x10)

	void OnEvent(bool _bSuccess); // Function DiscoveryOnline.UpgradeBattlePassLevelRequestCompleteResultListener.OnEvent // (Final|Native|Public) // @ game+0x60508e0
};

// Class DiscoveryOnline.AutoClaimBattlePassEntriesCompleteResultListener
// Size: 0xc0 (Inherited: 0xb0)
struct UAutoClaimBattlePassEntriesCompleteResultListener : UEventListenerBase {
	char pad_b0[0x10]; // 0xb0(0x10)

	void OnEvent(bool _bSucceeded, int32_t _NumClaimedEntries); // Function DiscoveryOnline.AutoClaimBattlePassEntriesCompleteResultListener.OnEvent // (Final|Native|Public) // @ game+0x604ceb0
};

// Class DiscoveryOnline.DiscoveryOnlineCareerModel
// Size: 0xf0 (Inherited: 0xb0)
struct UDiscoveryOnlineCareerModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncPlayerCareerCompletedDelegate; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnSyncSponsorSyncCompletedDelegate; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnSignSponsorCompletedDelegate; // 0xc8(0x10)
	struct UServicePlayerCareer* Career; // 0xd8(0x08)
	struct UServiceCareerSponsors* Sponsors; // 0xe0(0x08)

	void SyncSponsorsV2(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.SyncSponsorsV2 // (Native|Event|Public|BlueprintEvent) // @ game+0x32add10
	void SyncSponsors(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.SyncSponsors // (Native|Event|Public|BlueprintEvent) // @ game+0x2f60440
	void SyncCareerV2(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.SyncCareerV2 // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void SyncCareer(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.SyncCareer // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void SignSponsor(int64_t InSponsorId); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.SignSponsor // (Native|Event|Public|BlueprintEvent) // @ game+0x537cee0
	bool HasFinishedInitialization(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.HasFinishedInitialization // (Native|Event|Public|BlueprintEvent) // @ game+0x2b960b0
	struct UServiceCareerSponsors* GetSponsors(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.GetSponsors // (Native|Event|Public|BlueprintEvent) // @ game+0x2a01890
	struct UServicePlayerCareer* GetCareer(); // Function DiscoveryOnline.DiscoveryOnlineCareerModel.GetCareer // (Native|Event|Public|BlueprintEvent) // @ game+0x2a00080
};

// Class DiscoveryOnline.ServicePlayerCareer
// Size: 0x120 (Inherited: 0xa0)
struct UServicePlayerCareer : UObject {
	struct FMulticastInlineDelegate OnChanged; // 0x98(0x10)
	struct FPlayerCareerData PlayerCareerData; // 0xa8(0x78)

	struct FString ToDebugString(); // Function DiscoveryOnline.ServicePlayerCareer.ToDebugString // (Final|Native|Public|Const) // @ game+0x604ce20
	void SetSponsor(int64_t InSponsorId); // Function DiscoveryOnline.ServicePlayerCareer.SetSponsor // (Final|Native|Public) // @ game+0x604dc00
	struct UServicePlayerCareer* CreatePlayerCareer(struct UObject* InOuter, struct FApiGatewayDiscoveryGetPlayerCareerResponse& InResponse); // Function DiscoveryOnline.ServicePlayerCareer.CreatePlayerCareer // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x604c2f0
};

// Class DiscoveryOnline.ServiceCareerSponsorEntry
// Size: 0xe0 (Inherited: 0xa0)
struct UServiceCareerSponsorEntry : UObject {
	struct FMulticastInlineDelegate OnSponsorEntryUpdated; // 0x98(0x10)
	int64_t SponsorAssetId; // 0xa8(0x08)
	int64_t CurrentSponsorLevel; // 0xb0(0x08)
	int64_t PreviousSponsorLevel; // 0xb8(0x08)
	int64_t NextLevelProgress; // 0xc0(0x08)
	bool bIsPlayerCareerSponsor; // 0xc8(0x01)
	struct TArray<struct FSponsorTrackEntry> SponsorTrackEntries; // 0xd0(0x10)

	void DumpToLog(); // Function DiscoveryOnline.ServiceCareerSponsorEntry.DumpToLog // (Final|Native|Public) // @ game+0x604f960
};

// Class DiscoveryOnline.ServiceCareerSponsors
// Size: 0xf0 (Inherited: 0xa0)
struct UServiceCareerSponsors : UObject {
	struct TMap<int64_t, struct UServiceCareerSponsorEntry*> SponsorToEntry; // 0x98(0x50)
	bool bPendingFullData; // 0xe8(0x01)

	void DumpToLog(); // Function DiscoveryOnline.ServiceCareerSponsors.DumpToLog // (Final|Native|Public) // @ game+0x60508c0
	struct UServiceCareerSponsors* CreateServiceSponsors2(struct UObject* InOuter, struct FApiGatewayDiscoveryPeekSponsorsResponse& InPeekResponse, struct FApiGatewayDiscoveryGetPlayerCareerResponse& InPlayerResponse); // Function DiscoveryOnline.ServiceCareerSponsors.CreateServiceSponsors2 // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x604bc00
	struct UServiceCareerSponsors* CreateServiceSponsors(struct UObject* InOuter, struct FApiGatewayDiscoveryGetSponsorsResponse& InResponses); // Function DiscoveryOnline.ServiceCareerSponsors.CreateServiceSponsors // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x6051290
};

// Class DiscoveryOnline.InventoryServiceQuestDescriptionModel
// Size: 0xf0 (Inherited: 0xa0)
struct UInventoryServiceQuestDescriptionModel : UObject {
	struct FQuestRerollCost RerollCost; // 0x98(0x10)
	struct TArray<int64_t> DailyQuestSlotsIds; // 0xa8(0x10)
	struct TArray<int64_t> DailyClanQuestSlotIds; // 0xb8(0x10)
	int64_t DailyClanQuestMaxAccepted; // 0xc8(0x08)
	struct FDateTime DailyExpirationTime; // 0xd0(0x08)
	struct TArray<struct FCircuit> Circuits; // 0xd8(0x10)

	bool IsSlotIdOfType(enum class ECircuitType InCircuitType, int64_t InSlotId); // Function DiscoveryOnline.InventoryServiceQuestDescriptionModel.IsSlotIdOfType // (Final|Native|Public|BlueprintCallable) // @ game+0x6050a70
	struct FQuestTimeStateEntry GetQuestSlotTimeState(int64_t InSlotId); // Function DiscoveryOnline.InventoryServiceQuestDescriptionModel.GetQuestSlotTimeState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x604d4f0
	struct TArray<struct FCircuit> GetCircuitsOfType(enum class ECircuitType InType, bool bIncludeExpired); // Function DiscoveryOnline.InventoryServiceQuestDescriptionModel.GetCircuitsOfType // (Final|Native|Public|BlueprintCallable) // @ game+0x6050c30
	bool GetCircuitAndSlotDataFromInstanceSlotId(int64_t InSlotId, int64_t& OutCircuitId, int64_t& OutStageId); // Function DiscoveryOnline.InventoryServiceQuestDescriptionModel.GetCircuitAndSlotDataFromInstanceSlotId // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604f200
	struct TArray<int64_t> GetAllQuestSlotIds(); // Function DiscoveryOnline.InventoryServiceQuestDescriptionModel.GetAllQuestSlotIds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x604def0
	void DumpToLog(); // Function DiscoveryOnline.InventoryServiceQuestDescriptionModel.DumpToLog // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x604e2d0
};

// Class DiscoveryOnline.DiscoveryOnlineClanModel
// Size: 0xd0 (Inherited: 0xb0)
struct UDiscoveryOnlineClanModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnGetClanStats; // 0xa8(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)

	void SyncClanStats(struct FString ClanId); // Function DiscoveryOnline.DiscoveryOnlineClanModel.SyncClanStats // (Native|Event|Public|BlueprintEvent) // @ game+0x5391220
	struct TArray<struct FApiGatewayDiscoveryClanStatsPerPlayer> GetClanStats(); // Function DiscoveryOnline.DiscoveryOnlineClanModel.GetClanStats // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x604e930
};

// Class DiscoveryOnline.DiscoveryOnlineClientAdmin
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryOnlineClientAdmin : UObject {
	struct UEmbarkHttpContext* Context; // 0x98(0x08)

	void ResetTenancyUserResources(struct TArray<enum class EApiGatewayDiscoveryAdminResetResource> Resources, struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.ResetTenancyUserResources // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6050f40
	void ResetRoundStats(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.ResetRoundStats // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604c230
	void ResetProgression(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.ResetProgression // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604c230
	void ResetInventory(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.ResetInventory // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604ee40
	void HasAccess(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.HasAccess // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604c590
	void GiveCurrency(int64_t Amount, struct FDelegate& Delegate, enum class EApiGatewayDiscoveryAdminCurrencyType& CurrencyType); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.GiveCurrency // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6050dd0
	struct FString GetDevInstanceKey(); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.GetDevInstanceKey // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60500f0
	void ClearReconnect(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.ClearReconnect // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604f980
	void ClearBan(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.ClearBan // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604c230
	void AddFans(int64_t Amount, struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.AddFans // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6052540
	void AddBan(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.AddBan // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604c6d0
	void AbandonMatch(struct FDelegate& Delegate); // Function DiscoveryOnline.DiscoveryOnlineClientAdmin.AbandonMatch // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x604c230
};

// Class DiscoveryOnline.DiscoveryOnlineClientServices
// Size: 0x210 (Inherited: 0xc0)
struct UDiscoveryOnlineClientServices : UIEmbarkOnlineClientServices {
	struct UIEmbarkOnlineAnnouncementsModel* AnnouncementsModel; // 0xc0(0x08)
	struct UDefaultInboxServiceModel* InboxServiceModel; // 0xc8(0x08)
	struct UIEmbarkOnlineGameSettingsModel* GameSettingsModel; // 0xd0(0x08)
	struct UDiscoveryOnlineBattlePassModel* BattlePassModel; // 0xd8(0x08)
	struct USharedSocialModel* SocialModel; // 0xe0(0x08)
	struct USharedIdentityModel* IdentityModel; // 0xe8(0x08)
	struct UDiscoveryOnlineInventoryModel* InventoryModel; // 0xf0(0x08)
	struct UIEmbarkOnlineManifestModel* ManifestModel; // 0xf8(0x08)
	struct UIEmbarkOnlineMatchmakingModel* MatchmakingModel; // 0x100(0x08)
	struct UDiscoveryOnlineSurveySettingsModel* SurveySettingsModel; // 0x108(0x08)
	struct UDiscoveryOnlineRoundStatModel* RoundStatModel; // 0x110(0x08)
	struct UDiscoveryOnlineStoreModel* StoreModel; // 0x118(0x08)
	struct UDiscoveryOnlineTournamentsModel* TournamentsModel; // 0x120(0x08)
	struct USharedVoiceChatModel* VoiceChatModel; // 0x128(0x08)
	struct UIEmbarkOnlineBuildModel* BuildModel; // 0x130(0x08)
	struct UIEmbarkOnlinePersistentPlayerKeysModel* PersistentPlayerKeysModel; // 0x138(0x08)
	struct UIEmbarkOnlineMatchSessionInterface* MatchSessionModel; // 0x140(0x08)
	struct UIEmbarkOnlineLocalizationModel* LocalizationModel; // 0x148(0x08)
	struct USharedClanModel* ClanModel; // 0x150(0x08)
	struct UIEmbarkOnlinePlayerActivityModel* PlayerActivityModel; // 0x158(0x08)
	struct UIEmbarkOnlineMentorshipModel* MentorshipModel; // 0x160(0x08)
	struct UDiscoveryOnlineScenarioModel* ScenarioModel; // 0x168(0x08)
	struct UDiscoveryOnlineItemLiveMetaModel* ItemLiveMetaModel; // 0x170(0x08)
	struct UDiscoveryOnlineRankModel* RankModel; // 0x178(0x08)
	struct UDiscoveryOnlineLeagueModel* LeagueModel; // 0x180(0x08)
	struct UDiscoveryOnlineContestantPackModel* ContestantPackModel; // 0x188(0x08)
	struct UDiscoveryOnlineLeaderboardsModel* LeaderboardsModel; // 0x190(0x08)
	struct UDiscoveryOnlinePrivateLobbyModel* PrivateLobbyModel; // 0x198(0x08)
	struct UDiscoveryOnlineCareerModel* CareerModel; // 0x1a0(0x08)
	struct UDiscoveryOnlineRewardWheelModel* RewardWheelModel; // 0x1a8(0x08)
	struct UDiscoveryOnlineCollectionEventModel* CollectionEventModel; // 0x1b0(0x08)
	struct UDiscoveryOnlineClanModel* ClanProgressionModel; // 0x1b8(0x08)
	struct UDiscoveryOnlineGiftingModel* GiftingModel; // 0x1c0(0x08)
	struct UDiscoveryOnlineClientAdmin* AdminModel; // 0x1c8(0x08)
	struct USharedAchievementsModel* AchievementsModel; // 0x1d0(0x08)
	struct UEmbarkHttpContext* GatewayContext; // 0x1d8(0x08)
	char pad_1e0[0x30]; // 0x1e0(0x30)

	struct UDiscoveryOnlineTournamentsModel* GetTournamentsModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetTournamentsModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6057000
	struct UDiscoveryOnlineSurveySettingsModel* GetSurveySettingsModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetSurveySettingsModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605c860
	struct UDiscoveryOnlineStoreModel* GetStoreModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetStoreModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6053fe0
	struct UDiscoveryOnlineScenarioModel* GetScenarioModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetScenarioModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6059360
	struct UDiscoveryOnlineRoundStatModel* GetRoundStatModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetRoundStatModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605c680
	struct UDiscoveryOnlineRewardWheelModel* GetRewardWheelModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetRewardWheelModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6057460
	struct UDiscoveryOnlineRankModel* GetRankModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetRankModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605aa30
	struct UDiscoveryOnlinePrivateLobbyModel* GetPrivateLobbyModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetPrivateLobbyModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5393670
	struct UDiscoveryOnlineLeagueModel* GetLeagueModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetLeagueModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605d6f0
	struct UDiscoveryOnlineLeaderboardsModel* GetLeaderboardsModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetLeaderboardsModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605b640
	struct UDiscoveryOnlineItemLiveMetaModel* GetItemLiveMetaModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetItemLiveMetaModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x38438c0
	struct UDiscoveryOnlineGiftingModel* GetGiftingModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetGiftingModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605d550
	struct UDiscoveryOnlineClientServices* GetDiscoveryOnlineClientServices(struct UObject* InObj); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetDiscoveryOnlineClientServices // (Final|Native|Static|Public) // @ game+0x605af70
	struct UDiscoveryOnlineInventoryModel* GetDiscoveryInventoryModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetDiscoveryInventoryModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x38403c0
	struct UDiscoveryOnlineContestantPackModel* GetContestantPackModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetContestantPackModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605cc20
	struct UDiscoveryOnlineCollectionEventModel* GetCollectionEventModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetCollectionEventModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2e27590
	struct UDiscoveryOnlineClanModel* GetClanProgressionModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetClanProgressionModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605d040
	struct UDiscoveryOnlineCareerModel* GetCareerModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetCareerModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x537efc0
	struct UDiscoveryOnlineBattlePassModel* GetBattlePassModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetBattlePassModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605c180
	struct UDiscoveryOnlineClientAdmin* GetAdminModel(); // Function DiscoveryOnline.DiscoveryOnlineClientServices.GetAdminModel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x538f470
};

// Class DiscoveryOnline.CollectionEvent
// Size: 0xb0 (Inherited: 0xa0)
struct UCollectionEvent : UObject {
	struct TArray<struct FApiGatewayDiscoveryCollectionEventItem> Items; // 0x98(0x10)
};

// Class DiscoveryOnline.DiscoveryOnlineCollectionEventModel
// Size: 0xe0 (Inherited: 0xb0)
struct UDiscoveryOnlineCollectionEventModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncCollectionEventCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnOpenCollectionEventItemCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnOpenRandomCollectionEventItemCompleted; // 0xc8(0x10)
	struct UCollectionEvent* CollectionEvent; // 0xd8(0x08)

	void SyncCollectionEvent(); // Function DiscoveryOnline.DiscoveryOnlineCollectionEventModel.SyncCollectionEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x2d0aea0
	void OpenRandomCollectionEventItem(); // Function DiscoveryOnline.DiscoveryOnlineCollectionEventModel.OpenRandomCollectionEventItem // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
	void OpenCollectionEventItem(int64_t ItemId); // Function DiscoveryOnline.DiscoveryOnlineCollectionEventModel.OpenCollectionEventItem // (Native|Event|Public|BlueprintEvent) // @ game+0x6054fd0
	struct UCollectionEvent* GetCollectionEvent(); // Function DiscoveryOnline.DiscoveryOnlineCollectionEventModel.GetCollectionEvent // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2a00080
};

// Class DiscoveryOnline.DiscoveryOnlineContestantPackModel
// Size: 0x110 (Inherited: 0xb0)
struct UDiscoveryOnlineContestantPackModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnRequestContestantPacksCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnAddContestantPackCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnRemoveContestantPackCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnUpdateContestantPackCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnBatchUpdateContestantPacksCompleted; // 0xe8(0x10)
	char pad_100[0x10]; // 0x100(0x10)

	void RequestUpdateContestantPack(struct FApiGatewayDiscoveryPlayerPersistenceContestantPack& Pack); // Function DiscoveryOnline.DiscoveryOnlineContestantPackModel.RequestUpdateContestantPack // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605d420
	void RequestRemoveContestantPack(struct FString InstanceId, struct FString Etag); // Function DiscoveryOnline.DiscoveryOnlineContestantPackModel.RequestRemoveContestantPack // (Native|Event|Public|BlueprintEvent) // @ game+0x6053a60
	void RequestContestantPacks(); // Function DiscoveryOnline.DiscoveryOnlineContestantPackModel.RequestContestantPacks // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void RequestBatchUpdateContestantPacks(struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack>& packs); // Function DiscoveryOnline.DiscoveryOnlineContestantPackModel.RequestBatchUpdateContestantPacks // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6058fa0
	void RequestAddContestantPack(struct FApiGatewayDiscoveryCreateContestantPackRequest& req); // Function DiscoveryOnline.DiscoveryOnlineContestantPackModel.RequestAddContestantPack // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6055160
	struct TArray<struct FApiGatewayDiscoveryPlayerPersistenceContestantPack> GetContestantPacks(); // Function DiscoveryOnline.DiscoveryOnlineContestantPackModel.GetContestantPacks // (Native|Event|Public|BlueprintEvent) // @ game+0x6054940
};

// Class DiscoveryOnline.DiscoveryOnlineGiftingModel
// Size: 0xe0 (Inherited: 0xb0)
struct UDiscoveryOnlineGiftingModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSendGiftCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnCanSendGiftsCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnDoPlayersOwnItemCompleted; // 0xc8(0x10)

	void SendGiftTo(int64_t EmbarkProductId, struct FString InTransactionId, struct UServicePlayerProfile* EmbarkID); // Function DiscoveryOnline.DiscoveryOnlineGiftingModel.SendGiftTo // (Native|Event|Public|BlueprintEvent) // @ game+0x60596d0
	void DoPlayersOwnItem(struct TArray<int64_t>& ItemGameAssetIds, struct TArray<struct UServicePlayerProfile*>& Profiles); // Function DiscoveryOnline.DiscoveryOnlineGiftingModel.DoPlayersOwnItem // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x60559f0
	void CanSendGifts(); // Function DiscoveryOnline.DiscoveryOnlineGiftingModel.CanSendGifts // (Native|Event|Public|BlueprintEvent) // @ game+0x16fe6f0
};

// Class DiscoveryOnline.DiscoveryOnlineInventoryModel
// Size: 0x420 (Inherited: 0x110)
struct UDiscoveryOnlineInventoryModel : UIEmbarkOnlineInventoryModel {
	struct FMulticastInlineDelegate OnAddContestantPackComplete; // 0x108(0x10)
	struct FMulticastInlineDelegate OnRemoveContestantPackComplete; // 0x118(0x10)
	struct FMulticastInlineDelegate OnUpdateContestantPackComplete; // 0x128(0x10)
	struct FMulticastInlineDelegate OnBatchUpdateContestantPacksComplete; // 0x138(0x10)
	struct FMulticastInlineDelegate OnRerollQuestsComplete; // 0x148(0x10)
	struct FMulticastInlineDelegate OnAcceptQuestComplete; // 0x158(0x10)
	struct FMulticastInlineDelegate OnQuestTrackingDataChanged; // 0x168(0x10)
	struct FMulticastInlineDelegate OnUpdatePlayerCardComplete; // 0x178(0x10)
	struct FMulticastInlineDelegate OnSyncItemUnlockCostsComplete; // 0x188(0x10)
	struct FMulticastInlineDelegate OnUnlockItemComplete; // 0x198(0x10)
	struct FMulticastInlineDelegate OnSetActiveContestantPackComplete; // 0x1a8(0x10)
	struct FMulticastInlineDelegate OnSetCosmeticNumberComplete; // 0x1b8(0x10)
	struct FMulticastInlineDelegate OnSavePersistentEntitiesComplete; // 0x1c8(0x10)
	struct FMulticastInlineDelegate OnDeletePersistenceEntitiesComplete; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnPartyLoadoutsUpdated; // 0x1e8(0x10)
	struct UInventoryServiceInventory* Inventory; // 0x1f8(0x08)
	struct TMap<struct FTenancyUserId, struct UInventoryServiceInventory*> PartyLoadouts; // 0x200(0x50)
	struct TMap<struct FEmbarkUserId, struct UInventoryServiceInventory*> PlayerTournamentInventories; // 0x250(0x50)
	struct UInventoryServiceQuestDescriptionModel* QuestDescriptionModel; // 0x2a0(0x08)
	struct TMap<int64_t, struct FApiGatewayDiscoveryItemUnlockCost> ItemUnlockCosts; // 0x2a8(0x50)
	struct TSet<struct FString> SyncedChangelists; // 0x2f8(0x50)
	struct TArray<struct UInventoryServiceItemChange*> SyncChangesCache; // 0x348(0x10)
	char pad_360[0xc0]; // 0x360(0xc0)

	void UpdatePlayerCard(struct UInventoryServiceDiscoveryPlayerCardItem* PlayerCard); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.UpdatePlayerCard // (Native|Event|Public|BlueprintEvent) // @ game+0x2f935c0
	bool UpdateContestantPack(struct UInventoryServiceItemBase* Item); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.UpdateContestantPack // (Native|Event|Public|BlueprintEvent) // @ game+0x6054240
	void UnlockItem(int64_t ItemAssetId); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.UnlockItem // (Native|Event|Public|BlueprintEvent) // @ game+0x6052e50
	void SyncItemUnlockCosts(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.SyncItemUnlockCosts // (Native|Event|Public|BlueprintEvent) // @ game+0x3b06180
	void SetQuestTrackingState(bool bNewState, struct TArray<struct FString>& QuestInstanceIds); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.SetQuestTrackingState // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605b940
	void SetCosmeticNumber(int64_t Number); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.SetCosmeticNumber // (Native|Event|Public|BlueprintEvent) // @ game+0x605c0d0
	void SetActiveContestantPack(struct FString CharacterId); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.SetActiveContestantPack // (Native|Event|Public|BlueprintEvent) // @ game+0x53b7b70
	void SavePersistentEntities(struct TArray<struct UInventoryServicePersistentEntityItem*>& Entities); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.SavePersistentEntities // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6055640
	bool RerollQuests(struct TArray<struct FString>& QuestInstanceIds); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.RerollQuests // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6058ea0
	void RemoveContestantPack(struct FString InstanceId, struct FString Etag); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.RemoveContestantPack // (Native|Event|Public|BlueprintEvent) // @ game+0x6059390
	void RefreshQuestInventoryStates(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.RefreshQuestInventoryStates // (Final|Native|Private) // @ game+0x60594a0
	void OnSetPlayerPersistenceKey(struct FGameplayTag& Key, struct FString Value); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.OnSetPlayerPersistenceKey // (Final|Native|Private|HasOutParms) // @ game+0x605c3e0
	void OnPartyMemberJoined(struct UServicePlayerProfile* Profile); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.OnPartyMemberJoined // (Final|Native|Private) // @ game+0x6053d80
	void OnPartyJoined(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.OnPartyJoined // (Final|Native|Private) // @ game+0x60541e0
	void OnGetQuestTrackingData(bool bSucceeded); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.OnGetQuestTrackingData // (Final|Native|Private) // @ game+0x605bff0
	bool HasSyncChanges(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.HasSyncChanges // (Native|Event|Public|BlueprintEvent) // @ game+0x3235920
	struct FDiscoveryQuestTrackingData GetQuestTrackingData(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.GetQuestTrackingData // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6056f00
	struct UInventoryServiceQuestDescriptionModel* GetQuestDescription(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.GetQuestDescription // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6057460
	struct UInventoryServiceInventory* GetPlayerLoadout(struct FTenancyUserId& PlayerId); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.GetPlayerLoadout // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x60533b0
	struct FApiGatewayDiscoveryItemUnlockCost GetItemUnlockCost(int64_t ItemAssetId); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.GetItemUnlockCost // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6055f60
	struct TArray<struct FApiGatewayDiscoveryCreditExpiration> GetCreditExpirations(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.GetCreditExpirations // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605abe0
	struct TArray<struct UInventoryServiceItemChange*> DrainSyncChangesCache(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.DrainSyncChangesCache // (Native|Event|Public|BlueprintEvent) // @ game+0x60539d0
	void DeletePersistentEntities(struct TArray<struct UInventoryServicePersistentEntityItem*>& Entities); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.DeletePersistentEntities // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605aa60
	void CleanSyncChangesets(); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.CleanSyncChangesets // (Native|Event|Public|BlueprintEvent) // @ game+0x29f4230
	void BatchUpdateContestantPacks(struct TArray<struct UInventoryServiceItemBase*>& Items); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.BatchUpdateContestantPacks // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605ace0
	void AddContestantPack(struct FApiGatewayDiscoveryCreateContestantPackRequest& req); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.AddContestantPack // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605c570
	bool AcceptQuest(struct FString QuestInstanceId); // Function DiscoveryOnline.DiscoveryOnlineInventoryModel.AcceptQuest // (Native|Event|Public|BlueprintEvent) // @ game+0x6058670
};

// Class DiscoveryOnline.SyncInventoryCompleteResultListener
// Size: 0xc0 (Inherited: 0xb0)
struct USyncInventoryCompleteResultListener : UEventListenerBase {
	char pad_b0[0x10]; // 0xb0(0x10)

	void OnEvent(bool _bWasSuccessful, enum class ESyncInventoryResult _SyncInventoryResult); // Function DiscoveryOnline.SyncInventoryCompleteResultListener.OnEvent // (Final|Native|Public) // @ game+0x6060740
};

// Class DiscoveryOnline.SetActiveContestantPackCompleteResultListener
// Size: 0xc0 (Inherited: 0xb0)
struct USetActiveContestantPackCompleteResultListener : UEventListenerBase {
	char pad_b0[0x10]; // 0xb0(0x10)

	void OnEvent(bool _bWasSuccessful, enum class ESetActiveContestantPackResult _SetActiveContestantPackResult); // Function DiscoveryOnline.SetActiveContestantPackCompleteResultListener.OnEvent // (Final|Native|Public) // @ game+0x60633c0
};

// Class DiscoveryOnline.DiscoveryOnlineItemLiveMetaModel
// Size: 0xc0 (Inherited: 0xb0)
struct UDiscoveryOnlineItemLiveMetaModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnItemLiveMetasChanged; // 0xa8(0x10)
	struct UDiscoveryItemLiveMetaList* ItemLiveMetaList; // 0xb8(0x08)

	void SyncItemLiveMetaList(); // Function DiscoveryOnline.DiscoveryOnlineItemLiveMetaModel.SyncItemLiveMetaList // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	struct UDiscoveryItemLiveMetaList* GetItemLiveMetaList(); // Function DiscoveryOnline.DiscoveryOnlineItemLiveMetaModel.GetItemLiveMetaList // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53745b0
};

// Class DiscoveryOnline.DiscoveryOnlineLeaderboardsModel
// Size: 0x130 (Inherited: 0xb0)
struct UDiscoveryOnlineLeaderboardsModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnLeaderboardsUpdated; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnFilteredLeaderboardsUpdated; // 0xb8(0x10)
	struct UDiscoveryLeaderboards* Leaderboards; // 0xc8(0x08)
	struct TSet<struct FName> LeaderboardKindsToSync; // 0xd0(0x50)
	int32_t RowsLimitPerLeaderboard; // 0x120(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)

	void SyncLeaderboardsWithFilters(struct TArray<struct FApiGatewayDiscoveryGetLeaderboardSpecification>& LeaderboardSpecifications, int32_t RowsLimit); // Function DiscoveryOnline.DiscoveryOnlineLeaderboardsModel.SyncLeaderboardsWithFilters // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x60628f0
	void SyncLeaderboards(struct TSet<struct FName>& LeaderboardKinds, int32_t RowsLimit); // Function DiscoveryOnline.DiscoveryOnlineLeaderboardsModel.SyncLeaderboards // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6064ab0
	struct UDiscoveryLeaderboards* GetLeaderboards(); // Function DiscoveryOnline.DiscoveryOnlineLeaderboardsModel.GetLeaderboards // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2a00080
};

// Class DiscoveryOnline.DiscoveryOnlineLeagueModel
// Size: 0x150 (Inherited: 0xb0)
struct UDiscoveryOnlineLeagueModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnLeagueRankComplete; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnPartyRankComplete; // 0xb8(0x10)
	char pad_d0[0x80]; // 0xd0(0x80)

	bool HasCompletedRankFetch(); // Function DiscoveryOnline.DiscoveryOnlineLeagueModel.HasCompletedRankFetch // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48d40b0
	int32_t GetPartyMemberLeagueRank(struct FEmbarkUserId& EmbarkID); // Function DiscoveryOnline.DiscoveryOnlineLeagueModel.GetPartyMemberLeagueRank // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605f740
	struct FApiGatewayDiscoveryGetLeagueRankResponse GetLeagueRank(); // Function DiscoveryOnline.DiscoveryOnlineLeagueModel.GetLeagueRank // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x60667e0
	void FetchPlayerRank(); // Function DiscoveryOnline.DiscoveryOnlineLeagueModel.FetchPlayerRank // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void FetchPartyRanks(); // Function DiscoveryOnline.DiscoveryOnlineLeagueModel.FetchPartyRanks // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
};

// Class DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel
// Size: 0x1f0 (Inherited: 0xb0)
struct UDiscoveryOnlinePrivateLobbyModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnPrivateLobbyCreated; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyLocalPlayerJoined; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyLeaderChanged; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyLocalPlayerLeft; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyPlayerJoined; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyPlayerLeft; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyGameStarted; // 0x108(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyIncomingInvite; // 0x118(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyInviteAccepted; // 0x128(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyGameServerFound; // 0x138(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyUpdated; // 0x148(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyPlayerChangedSquads; // 0x158(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyGameStateChanged; // 0x168(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbyPartyDisbanded; // 0x178(0x10)
	struct FMulticastInlineDelegate OnPrivateLobbySquadsOveridden; // 0x188(0x10)
	struct UDiscoveryPrivateLobby* CurrentLobby; // 0x198(0x08)
	char pad_1a8[0x48]; // 0x1a8(0x48)

	void UpdatePrivateLobby(struct FString GameMode, struct FDiscoveryPrivateLobbyMapSelection& MapSettings); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.UpdatePrivateLobby // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6060490
	void SyncPrivateLobby(); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.SyncPrivateLobby // (Native|Event|Public|BlueprintEvent) // @ game+0x3b06180
	void StartPrivateLobby(); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.StartPrivateLobby // (Native|Event|Public|BlueprintEvent) // @ game+0x2ce7e50
	void PromoteToLobbyLeader(struct FEmbarkUserId& EmbarkUserId); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.PromoteToLobbyLeader // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6063980
	void MovePlayer(struct FEmbarkUserId& EmbarkUserId, struct FDiscoveryLobbyPlayerAssignmentKey ToSquadIndex); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.MovePlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605fa90
	void LeavePrivateLobby(); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.LeavePrivateLobby // (Native|Event|Public|BlueprintEvent) // @ game+0x2f930f0
	void KickPlayer(struct FEmbarkUserId& EmbarkUserId); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.KickPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6062c80
	void JoinPrivateLobby(struct FString LobbyId); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.JoinPrivateLobby // (Native|Event|Public|BlueprintEvent) // @ game+0x2f4bfe0
	void InviteToLobby(struct UServicePlayerProfile* Profile); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.InviteToLobby // (Native|Event|Public|BlueprintEvent) // @ game+0x2de1e30
	struct UDiscoveryPrivateLobby* GetCurrentLobby(); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.GetCurrentLobby // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53745b0
	void CustomizeSquads(struct TMap<struct FDiscoveryLobbyPlayerAssignmentKey, struct FDiscoveryPrivateLobbyCustomSquadSettings>& CustomSquadSettings); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CustomizeSquads // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6061410
	void CreatePrivateLobby(struct FString GameMode, int32_t MaxNumPlayers, struct FDiscoveryPrivateLobbyMapSelection& MapSettings); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CreatePrivateLobby // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x605e420
	bool CanPromoteToLobbyLeader(struct FEmbarkUserId& EmbarkUserId); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CanPromoteToLobbyLeader // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x6066170
	bool CanMovePlayerToDestination(struct FEmbarkUserId& EmbarkUserId, struct FDiscoveryLobbyPlayerAssignmentKey Destination); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CanMovePlayerToDestination // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x60662e0
	bool CanMovePlayer(struct FEmbarkUserId& EmbarkUserId); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CanMovePlayer // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x6062f80
	bool CanKickPlayer(struct FEmbarkUserId& EmbarkUserId); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CanKickPlayer // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x6065690
	bool CanInviteToLobby(); // Function DiscoveryOnline.DiscoveryOnlinePrivateLobbyModel.CanInviteToLobby // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x327bee0
};

// Class DiscoveryOnline.DiscoveryOnlineRankModel
// Size: 0xf0 (Inherited: 0xb0)
struct UDiscoveryOnlineRankModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnRankRewardsChanged; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnRanksChanged; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnGetProgressiveItemsCompleted; // 0xc8(0x10)
	struct UServiceProgressionRewards* RankRewards; // 0xd8(0x08)
	struct UDiscoveryPlayerRankInfo* PlayerRankInfo; // 0xe0(0x08)
	struct UProgressiveItems* ProgressiveItems; // 0xe8(0x08)

	void SyncRankRewards(); // Function DiscoveryOnline.DiscoveryOnlineRankModel.SyncRankRewards // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void SyncProgressiveItems(); // Function DiscoveryOnline.DiscoveryOnlineRankModel.SyncProgressiveItems // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	void SyncPlayerRanks(); // Function DiscoveryOnline.DiscoveryOnlineRankModel.SyncPlayerRanks // (Native|Event|Public|BlueprintEvent) // @ game+0x16fe6f0
	struct UServiceProgressionRewards* GetRankRewards(); // Function DiscoveryOnline.DiscoveryOnlineRankModel.GetRankRewards // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5376880
	struct UProgressiveItems* GetProgressiveItems(); // Function DiscoveryOnline.DiscoveryOnlineRankModel.GetProgressiveItems // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53745b0
	struct UDiscoveryPlayerRankInfo* GetPlayerRankInfo(); // Function DiscoveryOnline.DiscoveryOnlineRankModel.GetPlayerRankInfo // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5378330
};

// Class DiscoveryOnline.RewardWheel
// Size: 0xb0 (Inherited: 0xa0)
struct URewardWheel : UObject {
	struct TArray<struct FApiGatewayDiscoveryRewardWheelItem> Items; // 0x98(0x10)
};

// Class DiscoveryOnline.DiscoveryOnlineRewardWheelModel
// Size: 0xd0 (Inherited: 0xb0)
struct UDiscoveryOnlineRewardWheelModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnSyncRewardWheelCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnSpinRewardWheelCompleted; // 0xb8(0x10)
	struct URewardWheel* RewardWheel; // 0xc8(0x08)

	void SyncRewardWheel(); // Function DiscoveryOnline.DiscoveryOnlineRewardWheelModel.SyncRewardWheel // (Native|Event|Public|BlueprintEvent) // @ game+0x16fe6f0
	void SpinRewardWheel(); // Function DiscoveryOnline.DiscoveryOnlineRewardWheelModel.SpinRewardWheel // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
	struct URewardWheel* GetRewardWheel(); // Function DiscoveryOnline.DiscoveryOnlineRewardWheelModel.GetRewardWheel // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2a01890
};

// Class DiscoveryOnline.DiscoveryOnlineRoundStatModel
// Size: 0xb80 (Inherited: 0xb0)
struct UDiscoveryOnlineRoundStatModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnRequestRoundStatCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnRequestRoundStatSummaryCompleted; // 0xb8(0x10)
	char pad_d0[0xab0]; // 0xd0(0xab0)

	void RequestRoundStatSummary(); // Function DiscoveryOnline.DiscoveryOnlineRoundStatModel.RequestRoundStatSummary // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void RequestRoundStat(); // Function DiscoveryOnline.DiscoveryOnlineRoundStatModel.RequestRoundStat // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	bool HasCompletedRoundStatSummarySync(); // Function DiscoveryOnline.DiscoveryOnlineRoundStatModel.HasCompletedRoundStatSummarySync // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2b960b0
	struct FApiGatewayDiscoveryWorldTourRoundStatSummary GetWorldTourSummary(); // Function DiscoveryOnline.DiscoveryOnlineRoundStatModel.GetWorldTourSummary // (Native|Event|Public|BlueprintEvent) // @ game+0x606bca0
	struct FApiGatewayDiscoveryRoundStatSummary GetRoundStatSummary(enum class EServiceRoundStatSummaryType Type); // Function DiscoveryOnline.DiscoveryOnlineRoundStatModel.GetRoundStatSummary // (Native|Event|Public|BlueprintEvent) // @ game+0x6069430
	struct TArray<struct FApiGatewayDiscoveryRoundStats> GetRoundStats(); // Function DiscoveryOnline.DiscoveryOnlineRoundStatModel.GetRoundStats // (Native|Event|Public|BlueprintEvent) // @ game+0x6069030
};

// Class DiscoveryOnline.DiscoveryOnlineScenarioModel
// Size: 0xc0 (Inherited: 0xb0)
struct UDiscoveryOnlineScenarioModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnScenariosChanged; // 0xa8(0x10)
	struct UDiscoveryScenarioList* ScenarioList; // 0xb8(0x08)

	void SyncScenarioList(); // Function DiscoveryOnline.DiscoveryOnlineScenarioModel.SyncScenarioList // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	struct UDiscoveryScenarioList* GetScenarioList(); // Function DiscoveryOnline.DiscoveryOnlineScenarioModel.GetScenarioList // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x53745b0
};

// Class DiscoveryOnline.DiscoveryOnlineServerServices
// Size: 0x4e0 (Inherited: 0x330)
struct UDiscoveryOnlineServerServices : UIEmbarkOnlineServerServices {
	struct FMulticastInlineDelegate OnInventoryChanged; // 0x330(0x10)
	struct FMulticastInlineDelegate OnReportAbandonedPlayerCompleted; // 0x340(0x10)
	struct FMulticastInlineDelegate OnQuestDescrptionCompleted; // 0x350(0x10)
	struct FMulticastInlineDelegate OnlineReportMatchResultCompleted; // 0x360(0x10)
	struct FMulticastInlineDelegate OnSyncPlayerInfoComplete; // 0x370(0x10)
	struct FMulticastInlineDelegate OnOnlineSubmitMatchReportCompleted; // 0x380(0x10)
	struct FMulticastInlineDelegate OnOnlineSyncLiveBattlePassCompleted; // 0x390(0x10)
	struct FMulticastInlineDelegate OnSyncActiveBattlePassesMetadataCompleted; // 0x3a0(0x10)
	struct TMap<struct FTenancyUserId, struct UInventoryServiceInventory*> Inventories; // 0x3b0(0x50)
	struct TMap<struct FString, struct FApiGatewayDiscoveryGetTournamentSessionResponse> PlayerTournamentSessions; // 0x400(0x50)
	struct UInventoryServiceQuestDescriptionModel* QuestDescriptionModel; // 0x450(0x08)
	struct TMap<struct FTenancyUserId, struct FApiGatewayDiscoveryServerPlayerInfo> PlayerInfos; // 0x458(0x50)
	struct FApiGatewayDiscoveryServerGetLiveBattlePassDescriptionResponse LiveBattlePass; // 0x4a8(0x18)
	struct TArray<struct FApiGatewayDiscoveryServerBattlePassMetadata> ActiveBattlePassesMetadata; // 0x4c0(0x10)
	char pad_4d0[0x10]; // 0x4d0(0x10)

	void SyncQuestDescription(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SyncQuestDescription // (Native|Event|Public|BlueprintEvent) // @ game+0x606ef30
	void SyncPlayerInfo(struct TArray<struct FUniqueNetIdRepl>& UniqueNetIdRepls); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SyncPlayerInfo // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6067710
	void SyncLiveBattlePassDescription(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SyncLiveBattlePassDescription // (Native|Event|Public|BlueprintEvent) // @ game+0x2f90290
	bool SyncInventories(struct TArray<struct FUniqueNetIdRepl>& UniqueNetIdRepls); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SyncInventories // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x606b300
	void SyncActiveBattlePassesMetadata(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SyncActiveBattlePassesMetadata // (Native|Event|Public|BlueprintEvent) // @ game+0x4e6bc40
	bool SubmitMatchReport(struct FSubmitMatchReportRequest& InRequest); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SubmitMatchReport // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x60679c0
	bool SendMatchHeartbeat(struct FString TournamentId, struct FString MatchId); // Function DiscoveryOnline.DiscoveryOnlineServerServices.SendMatchHeartbeat // (Native|Event|Public|BlueprintEvent) // @ game+0x6071dc0
	void ResolveSanctions(struct TArray<struct FUniqueNetIdRepl>& PlayerIds, struct FString TournamentId); // Function DiscoveryOnline.DiscoveryOnlineServerServices.ResolveSanctions // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x606cf60
	bool ReportTournamentMatchResult(struct FSubmitTournamentMatchResult& InRequest); // Function DiscoveryOnline.DiscoveryOnlineServerServices.ReportTournamentMatchResult // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x606d0e0
	bool ReportTournamentMatchProgress(struct FString TournamentId, struct FString MatchId, int32_t ExpectedEndTime); // Function DiscoveryOnline.DiscoveryOnlineServerServices.ReportTournamentMatchProgress // (Native|Event|Public|BlueprintEvent) // @ game+0x6072120
	void ReportPlayerAbandoned(struct FUniqueNetIdRepl& PlayerId, struct FString TournamentId, int64_t TimeOfAbandon, bool bImposeSanction, struct FString GameServer, bool bForcePenalty); // Function DiscoveryOnline.DiscoveryOnlineServerServices.ReportPlayerAbandoned // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x606d370
	bool HasQuestDescription(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.HasQuestDescription // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6068330
	bool HasPlayerInfos(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.HasPlayerInfos // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x606d6c0
	bool HasPlayerInfo(struct FUniqueNetIdRepl& PlayerId); // Function DiscoveryOnline.DiscoveryOnlineServerServices.HasPlayerInfo // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x6066f10
	bool HasInventories(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.HasInventories // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x6070300
	struct UInventoryServiceQuestDescriptionModel* GetQuestDescription(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.GetQuestDescription // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x606a750
	struct FApiGatewayDiscoveryServerPlayerInfo GetPlayerInfo(struct FUniqueNetIdRepl& PlayerId, bool bInWarnOnMissing); // Function DiscoveryOnline.DiscoveryOnlineServerServices.GetPlayerInfo // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x606b5b0
	struct FApiGatewayDiscoveryServerGetLiveBattlePassDescriptionResponse GetLiveBattlePassDescription(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.GetLiveBattlePassDescription // (Native|Event|Public|BlueprintEvent) // @ game+0x6071880
	struct UInventoryServiceInventory* GetInventory(struct FUniqueNetIdRepl& PlayerId); // Function DiscoveryOnline.DiscoveryOnlineServerServices.GetInventory // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x606e880
	struct TArray<struct UInventoryServiceInventory*> GetAllInventories(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.GetAllInventories // (Native|Event|Public|BlueprintEvent) // @ game+0x6067930
	struct TArray<struct FApiGatewayDiscoveryServerBattlePassMetadata> GetActiveBattlePassesMetadata(); // Function DiscoveryOnline.DiscoveryOnlineServerServices.GetActiveBattlePassesMetadata // (Native|Event|Public|BlueprintEvent) // @ game+0x60719c0
};

// Class DiscoveryOnline.DiscoveryOnlineStoreModel
// Size: 0x230 (Inherited: 0xb0)
struct UDiscoveryOnlineStoreModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate SubscriptionsCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate ProductViewsChanged; // 0xb8(0x10)
	struct FMulticastInlineDelegate StorePurchaseCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnRedeemOutstandingThirdPartyPurchases; // 0xd8(0x10)
	struct FMulticastInlineDelegate ClaimGiftsCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate UnexpectedThirdPartyPurchaseCompleted; // 0xf8(0x10)
	char pad_110[0x70]; // 0x110(0x70)
	struct UProductViews* ProductViews; // 0x180(0x08)
	struct USubscriptions* Subscriptions; // 0x188(0x08)
	struct TArray<struct UStoreReconciledProduct*> PurchasedItemsCache; // 0x190(0x10)
	struct TArray<struct UStoreReconciledProduct*> GiftItemsCache; // 0x1a0(0x10)
	char pad_1b0[0x80]; // 0x1b0(0x80)

	void SyncSubscriptions(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.SyncSubscriptions // (Native|Event|Public|BlueprintEvent) // @ game+0x5393a40
	void SyncProductViews(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.SyncProductViews // (Native|Event|Public|BlueprintEvent) // @ game+0x2cdea40
	void ShowThirdPartyStoreProduct(struct FString ThirdPartyOfferId); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.ShowThirdPartyStoreProduct // (Native|Event|Public|BlueprintEvent) // @ game+0x5391220
	void RedeemOutstandingThirdPartyPurchases(struct FString InTransactionId, bool bShouldBroadcast); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.RedeemOutstandingThirdPartyPurchases // (Native|Event|Public|BlueprintEvent) // @ game+0x6071290
	void PurchaseThirdPartyStoreOffer(struct FString InTransactionId, struct FString InThirdPartyOfferId); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.PurchaseThirdPartyStoreOffer // (Native|Event|Public|BlueprintEvent) // @ game+0x60737d0
	void PurchaseStoreOffer(struct FString InTransactionId, int64_t InOfferId); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.PurchaseStoreOffer // (Native|Event|Public|BlueprintEvent) // @ game+0x6067d20
	void PurchasePlaystyle(int64_t PlaystyleId); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.PurchasePlaystyle // (Native|Event|Public|BlueprintEvent) // @ game+0x6073170
	void PurchaseDownloadableContent(struct FString InTransactionId, struct FString InThirdPartyOfferId); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.PurchaseDownloadableContent // (Native|Event|Public|BlueprintEvent) // @ game+0x606ef90
	void LeaveStore(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.LeaveStore // (Native|Event|Public|BlueprintEvent) // @ game+0x2d0aea0
	bool IsInStore(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.IsInStore // (Native|Event|Public|BlueprintEvent) // @ game+0x48d40b0
	bool HasPurchasedItemsCache(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.HasPurchasedItemsCache // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3235920
	bool HasProductViews(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.HasProductViews // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x606a720
	bool HasGiftItemsCache(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.HasGiftItemsCache // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x15c6d40
	struct FString GetThirdPartyStoreTelemetryName(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.GetThirdPartyStoreTelemetryName // (Native|Event|Public|BlueprintEvent) // @ game+0x604e930
	struct USubscriptions* GetSubscriptions(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.GetSubscriptions // (Native|Event|Public|BlueprintEvent) // @ game+0x6073960
	struct TArray<struct UStoreReconciledProduct*> GetPurchasedItemsCache(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.GetPurchasedItemsCache // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x60539d0
	struct UProductViews* GetProductViews(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.GetProductViews // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x605d550
	struct TArray<struct UStoreReconciledProduct*> GetGiftItemsCache(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.GetGiftItemsCache // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x48e7a80
	void EnterStore(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.EnterStore // (Native|Event|Public|BlueprintEvent) // @ game+0x2f0e200
	void ClearPurchasedItemsCache(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.ClearPurchasedItemsCache // (Native|Event|Public|BlueprintEvent) // @ game+0x29f4230
	void ClearGiftItemsCache(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.ClearGiftItemsCache // (Native|Event|Public|BlueprintEvent) // @ game+0x537cec0
	void ClaimGifts(); // Function DiscoveryOnline.DiscoveryOnlineStoreModel.ClaimGifts // (Native|Event|Public|BlueprintEvent) // @ game+0x5d60060
};

// Class DiscoveryOnline.StoreThirdPartyProduct
// Size: 0x170 (Inherited: 0xa0)
struct UStoreThirdPartyProduct : UObject {
	int64_t ThirdPartyProductId; // 0x98(0x08)
	enum class EStoreThirdPartyStoreId ThirdPartyStoreId; // 0xa0(0x01)
	struct FString ThirdPartyOfferId; // 0xa8(0x10)
	struct FString ThirdPartyItemId; // 0xb8(0x10)
	bool bIsFree; // 0xc8(0x01)
	char pad_ca[0x6]; // 0xca(0x06)
	struct FText DisplayCost; // 0xd0(0x18)
	int64_t Cost; // 0xe8(0x08)
	struct FText DisplayRegularCost; // 0xf0(0x18)
	int64_t RegularCost; // 0x108(0x08)
	struct FString CurrencyCode; // 0x110(0x10)
	struct FText Title; // 0x120(0x18)
	struct FText Description; // 0x138(0x18)
	struct UTexture2D* Image; // 0x150(0x08)
	bool bIsDownloadableContent; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
	struct FString RegionId; // 0x160(0x10)
};

// Class DiscoveryOnline.StoreBundleItem
// Size: 0xb0 (Inherited: 0xa0)
struct UStoreBundleItem : UObject {
	int64_t AssetId; // 0x98(0x08)
	int64_t ProductId; // 0xa0(0x08)
	int64_t Cost; // 0xa8(0x08)
};

// Class DiscoveryOnline.StoreEmbarkProduct
// Size: 0x140 (Inherited: 0xa0)
struct UStoreEmbarkProduct : UObject {
	int64_t EmbarkProductId; // 0x98(0x08)
	struct FStoreItem AllItemsFullPrice; // 0xa0(0x18)
	struct FStoreItem UnaquiredItemsFullPrice; // 0xb8(0x18)
	struct FStoreItem AllItemsDiscountPrice; // 0xd0(0x18)
	struct FStoreItem UnaquiredItemsDiscountPrice; // 0xe8(0x18)
	struct FStoreItem CostItem; // 0x100(0x18)
	bool bHasCostItem; // 0x118(0x01)
	int64_t InitialCost; // 0x120(0x08)
	struct TArray<struct UStoreBundleItem*> BundleItems; // 0x128(0x10)
	char pad_139[0x7]; // 0x139(0x07)

	void SetCostItem(struct FStoreItem Item); // Function DiscoveryOnline.StoreEmbarkProduct.SetCostItem // (Final|Native|Public) // @ game+0x6075410
};

// Class DiscoveryOnline.StoreOffer
// Size: 0xe0 (Inherited: 0xa0)
struct UStoreOffer : UObject {
	int64_t AssetId; // 0x98(0x08)
	struct UStoreEmbarkProduct* EmbarkProduct; // 0xa0(0x08)
	struct UStoreThirdPartyProduct* ThirdPartyProduct; // 0xa8(0x08)
	struct TArray<struct FStoreItem> ItemList; // 0xb0(0x10)
	bool bOwned; // 0xc0(0x01)
	int64_t StartTime; // 0xc8(0x08)
	int64_t EndTime; // 0xd0(0x08)
	enum class EApiGatewayDiscoveryGameStoreTransactionSource TransactionSource; // 0xd8(0x01)
	enum class EApiGatewayDiscoveryGameStoreProvider Provider; // 0xd9(0x01)
	char pad_db[0x5]; // 0xdb(0x05)

	bool HasThirdPartyProduct(); // Function DiscoveryOnline.StoreOffer.HasThirdPartyProduct // (Final|Native|Public|Const) // @ game+0x6078800
	bool HasEmbarkProduct(); // Function DiscoveryOnline.StoreOffer.HasEmbarkProduct // (Final|Native|Public|Const) // @ game+0x60740c0
	struct UStoreBundleItem* GetBundleItem(int64_t ItemAssetId); // Function DiscoveryOnline.StoreOffer.GetBundleItem // (Final|Native|Public|Const) // @ game+0x6075260
};

// Class DiscoveryOnline.StoreReconciledProduct
// Size: 0xc0 (Inherited: 0xa0)
struct UStoreReconciledProduct : UObject {
	int64_t ProductId; // 0x98(0x08)
	int64_t GameAssetId; // 0xa0(0x08)
	enum class EStoreReconciledProductOrigin Origin; // 0xa8(0x01)
	struct TArray<struct FStoreItem> Items; // 0xb0(0x10)
};

// Class DiscoveryOnline.ProductView
// Size: 0xb0 (Inherited: 0xa0)
struct UProductView : UObject {
	int64_t ViewId; // 0x98(0x08)
	struct TArray<struct UStoreOffer*> OfferList; // 0xa0(0x10)
};

// Class DiscoveryOnline.ProductViews
// Size: 0xc0 (Inherited: 0xa0)
struct UProductViews : UObject {
	struct TArray<struct UProductView*> StoreSections; // 0x98(0x10)
	struct TArray<struct UProductView*> Views; // 0xa8(0x10)
	int64_t NewTimestamp; // 0xb8(0x08)
};

// Class DiscoveryOnline.Subscriptions
// Size: 0xa0 (Inherited: 0xa0)
struct USubscriptions : UObject {
	bool MicrosoftGamePass; // 0x98(0x01)
};

// Class DiscoveryOnline.DiscoveryOnlineSurveySettingsModel
// Size: 0xd0 (Inherited: 0xb0)
struct UDiscoveryOnlineSurveySettingsModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnRequestSurveySettingsCompleted; // 0xa8(0x10)
	char pad_c0[0x10]; // 0xc0(0x10)

	void RequestSurveySettings(struct FString Locale); // Function DiscoveryOnline.DiscoveryOnlineSurveySettingsModel.RequestSurveySettings // (Native|Event|Public|BlueprintEvent) // @ game+0x5391220
	struct FApiGatewaySharedGetSurveySettingsResponse GetSurveySettings(); // Function DiscoveryOnline.DiscoveryOnlineSurveySettingsModel.GetSurveySettings // (Native|Event|Public|BlueprintEvent) // @ game+0x6077de0
};

// Class DiscoveryOnline.DiscoveryOnlineTournamentsModel
// Size: 0x180 (Inherited: 0xb0)
struct UDiscoveryOnlineTournamentsModel : UEmbarkOnlineServiceBase {
	struct FMulticastInlineDelegate OnJoinTournamentMatchStarted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnJoinTournamentMatchUpdated; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnJoinTournamentMatchStopped; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnJoinTournamentMatchError; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnMonitorTournamentCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnGetTournamentSessionCompleted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnAbandonTournamentCompleted; // 0x108(0x10)
	struct TMap<struct FGuid, struct FTournamentRequestEntry> AllJoinData; // 0x118(0x50)
	struct FGuid CurrentActiveRequestGuid; // 0x168(0x10)

	void TriggerRetryTournamentJoinRequest(struct FGuid InRelevantGuid); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.TriggerRetryTournamentJoinRequest // (Final|Native|Protected|HasDefaults) // @ game+0x60740e0
	bool TravelToTierMatch(struct FApiGatewayDiscoveryGameServer& TournamentGameServer, struct FEmbarkOnlineModelConnectionParameters& OptionalParameters); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.TravelToTierMatch // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x6074df0
	void OnPreloadMap(struct FString MapName); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.OnPreloadMap // (Final|Native|Protected) // @ game+0x6078750
	void MonitorTournament(struct FString TournamentId); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.MonitorTournament // (Native|Event|Public|BlueprintEvent) // @ game+0x48cfc20
	void JoinTournamentMatch(float InGacTimeoutInterval); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.JoinTournamentMatch // (Native|Event|Public|BlueprintEvent) // @ game+0x2f65830
	void JoinGameserverMatch(struct FString InGacId, struct FGuid InGuid); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.JoinGameserverMatch // (Final|Native|Protected|HasDefaults) // @ game+0x6076d10
	bool IsJoiningTournament(); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.IsJoiningTournament // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd3930
	void GetTournamentSession(); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.GetTournamentSession // (Native|Event|Public|BlueprintEvent) // @ game+0x2d0aea0
	void ExecuteJoinTournamentRequestOnGuid(struct FGuid InDesiredGuid); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.ExecuteJoinTournamentRequestOnGuid // (Final|Native|Protected|HasDefaults) // @ game+0x60788a0
	void AbandonTournament(struct FString TournamentId); // Function DiscoveryOnline.DiscoveryOnlineTournamentsModel.AbandonTournament // (Native|Event|Public|BlueprintEvent) // @ game+0x537bb70
};

// Class DiscoveryOnline.DiscoveryPersistentEntityBase
// Size: 0xa0 (Inherited: 0xa0)
struct UDiscoveryPersistentEntityBase : UObject {

	struct FString ToJsonString(struct TMap<struct FName, struct FString>& BackendFields); // Function DiscoveryOnline.DiscoveryPersistentEntityBase.ToJsonString // (Final|Native|Public|HasOutParms|Const) // @ game+0x60780f0
	struct FString GetEntityType(); // Function DiscoveryOnline.DiscoveryPersistentEntityBase.GetEntityType // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3389d20
	struct FString GetEntitySchema(); // Function DiscoveryOnline.DiscoveryPersistentEntityBase.GetEntitySchema // (Final|Native|Public|Const) // @ game+0x23da620
	struct TMap<struct FName, struct FString> GetBackendFields(); // Function DiscoveryOnline.DiscoveryPersistentEntityBase.GetBackendFields // (Final|Native|Public|Const) // @ game+0x60769a0
	bool FromJsonString(struct FString RawProperties, struct TMap<struct FName, struct FString>& BackendFields); // Function DiscoveryOnline.DiscoveryPersistentEntityBase.FromJsonString // (Final|Native|Public|HasOutParms) // @ game+0x6079780
};

// Class DiscoveryOnline.SoMuchPersistentEntity
// Size: 0xc0 (Inherited: 0xa0)
struct USoMuchPersistentEntity : UDiscoveryPersistentEntityBase {
	struct FString ItemRefProperty; // 0x98(0x10)
	int64_t SomeIntProperty; // 0xa8(0x08)
	struct TArray<struct FString> AwooPets; // 0xb0(0x10)
};

// Class DiscoveryOnline.DiscoveryPrivateLobby
// Size: 0x190 (Inherited: 0xa0)
struct UDiscoveryPrivateLobby : UObject {
	enum class EDiscoveryPrivateLobbyState State; // 0x98(0x01)
	enum class EDiscoveryPrivateLobbyGameState GameState; // 0x99(0x01)
	int32_t MaxNumPlayers; // 0x9c(0x04)
	struct FString LobbyId; // 0xa0(0x10)
	struct FString GameMode; // 0xb0(0x10)
	struct FDiscoveryPrivateLobbyMapSelection MapSettings; // 0xc0(0x50)
	struct FEmbarkUserId LeaderId; // 0x110(0x10)
	struct FEmbarkUserId LocalPlayerId; // 0x120(0x10)
	char NumberOfSquads; // 0x130(0x01)
	char pad_137[0x1]; // 0x137(0x01)
	struct TMap<struct FDiscoveryLobbyPlayerAssignmentKey, struct FDiscoveryPrivateLobbySquad> Players; // 0x138(0x50)
	char pad_188[0x8]; // 0x188(0x08)

	struct TMap<struct FEmbarkUserId, struct UServicePlayerProfile*> GetPlayers(struct FDiscoveryLobbyPlayerAssignmentKey Key); // Function DiscoveryOnline.DiscoveryPrivateLobby.GetPlayers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x607f190
	struct UServicePlayerProfile* GetPlayerProfile(struct FEmbarkUserId& Player); // Function DiscoveryOnline.DiscoveryPrivateLobby.GetPlayerProfile // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x607dc40
	bool GetPlayerAssignment(struct FEmbarkUserId& PlayerId, struct FDiscoveryLobbyPlayerAssignmentKey& OutAssignment); // Function DiscoveryOnline.DiscoveryPrivateLobby.GetPlayerAssignment // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6081020
	struct TMap<struct FDiscoveryLobbyPlayerAssignmentKey, struct FDiscoveryPrivateLobbySquad> GetAllPlayers(); // Function DiscoveryOnline.DiscoveryPrivateLobby.GetAllPlayers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x607e320
};

// Class DiscoveryOnline.BlueprintMutableDiscoveryPrivateLobby
// Size: 0x190 (Inherited: 0x190)
struct UBlueprintMutableDiscoveryPrivateLobby : UDiscoveryPrivateLobby {

	struct UServicePlayerProfile* BP_RemovePlayer(struct FEmbarkUserId& Player); // Function DiscoveryOnline.BlueprintMutableDiscoveryPrivateLobby.BP_RemovePlayer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x607c9e0
	void BP_AddPlayer(struct UServicePlayerProfile* Profile, struct FDiscoveryLobbyPlayerAssignmentKey Destination); // Function DiscoveryOnline.BlueprintMutableDiscoveryPrivateLobby.BP_AddPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0x607fb50
};

// Class DiscoveryOnline.DiscoveryRankInfo
// Size: 0xd0 (Inherited: 0xa0)
struct UDiscoveryRankInfo : UObject {
	struct FString BucketId; // 0x98(0x10)
	int64_t TotalXP; // 0xa8(0x08)
	int64_t CurrentRank; // 0xb0(0x08)
	struct FString Etag; // 0xb8(0x10)
};

// Class DiscoveryOnline.DiscoveryPlayerRankInfo
// Size: 0x120 (Inherited: 0xa0)
struct UDiscoveryPlayerRankInfo : UObject {
	struct FString User; // 0x98(0x10)
	struct TArray<struct UDiscoveryRankInfo*> Ranks; // 0xa8(0x10)
	struct FString ActiveItemRankBucketId; // 0xb8(0x10)
	char pad_d0[0x50]; // 0xd0(0x50)

	bool UpdateDerivedProperties(); // Function DiscoveryOnline.DiscoveryPlayerRankInfo.UpdateDerivedProperties // (Final|Native|Public) // @ game+0x607a850
	bool HasRankInfoByBucketId(struct FString BucketId); // Function DiscoveryOnline.DiscoveryPlayerRankInfo.HasRankInfoByBucketId // (Final|Native|Public|Const) // @ game+0x607fda0
	struct UDiscoveryRankInfo* GetRankInfoByBucketId(struct FString BucketId); // Function DiscoveryOnline.DiscoveryPlayerRankInfo.GetRankInfoByBucketId // (Final|Native|Public|Const) // @ game+0x607fe80
};

// Class DiscoveryOnline.ProgressiveItems
// Size: 0xb0 (Inherited: 0xa0)
struct UProgressiveItems : UObject {
	struct TArray<struct FApiGatewayDiscoveryProgressiveItem> Items; // 0x98(0x10)
};

// Class DiscoveryOnline.ServiceProgressionReward
// Size: 0xe0 (Inherited: 0xa0)
struct UServiceProgressionReward : UObject {
	struct UServiceProgressionReward* Last; // 0x98(0x08)
	struct UServiceProgressionReward* Next; // 0xa0(0x08)
	int64_t Rank; // 0xa8(0x08)
	int64_t RequiredXp; // 0xb0(0x08)
	int64_t LastRequiredXP; // 0xb8(0x08)
	int64_t NextRequiredXP; // 0xc0(0x08)
	struct TArray<struct FServiceProgressionRewardItem> Items; // 0xc8(0x10)
};

// Class DiscoveryOnline.ServiceProgressionRewardBucket
// Size: 0x120 (Inherited: 0xa0)
struct UServiceProgressionRewardBucket : UObject {
	struct FString BucketId; // 0x98(0x10)
	int64_t XPSlot; // 0xa8(0x08)
	int64_t RankSlot; // 0xb0(0x08)
	struct TArray<struct UServiceProgressionReward*> Rewards; // 0xb8(0x10)
	char pad_d0[0x50]; // 0xd0(0x50)

	bool UpdateDerivedProperties(); // Function DiscoveryOnline.ServiceProgressionRewardBucket.UpdateDerivedProperties // (Final|Native|Public) // @ game+0x607dc10
	bool HasRewardsByItemAssetId(int64_t AssetId); // Function DiscoveryOnline.ServiceProgressionRewardBucket.HasRewardsByItemAssetId // (Final|Native|Public|Const) // @ game+0x607a660
	bool HasRewardByXP(int64_t CurrentXp); // Function DiscoveryOnline.ServiceProgressionRewardBucket.HasRewardByXP // (Final|Native|Public|Const) // @ game+0x607eaa0
	bool HasRewardByRank(int64_t Rank); // Function DiscoveryOnline.ServiceProgressionRewardBucket.HasRewardByRank // (Final|Native|Public|Const) // @ game+0x6081da0
	void GetRewardsByItemAssetId(int64_t AssetId, struct TArray<struct UServiceProgressionReward*>& OutRewards); // Function DiscoveryOnline.ServiceProgressionRewardBucket.GetRewardsByItemAssetId // (Final|Native|Public|HasOutParms|Const) // @ game+0x6080ee0
	struct UServiceProgressionReward* GetRewardByXP(int64_t CurrentXp); // Function DiscoveryOnline.ServiceProgressionRewardBucket.GetRewardByXP // (Final|Native|Public|Const) // @ game+0x607e530
	struct UServiceProgressionReward* GetRewardByRank(int64_t Rank); // Function DiscoveryOnline.ServiceProgressionRewardBucket.GetRewardByRank // (Final|Native|Public|Const) // @ game+0x607be40
	struct UServiceProgressionReward* GetFirstRewardByItemAssetId(int64_t AssetId); // Function DiscoveryOnline.ServiceProgressionRewardBucket.GetFirstRewardByItemAssetId // (Final|Native|Public|Const) // @ game+0x607d710
};

// Class DiscoveryOnline.ServiceProgressionRewards
// Size: 0x100 (Inherited: 0xa0)
struct UServiceProgressionRewards : UObject {
	struct TArray<struct UServiceProgressionRewardBucket*> Buckets; // 0x98(0x10)
	char pad_b0[0x50]; // 0xb0(0x50)

	bool UpdateDerivedProperties(); // Function DiscoveryOnline.ServiceProgressionRewards.UpdateDerivedProperties // (Final|Native|Public) // @ game+0x607cda0
	bool HasBucketByBucketId(struct FString BucketId); // Function DiscoveryOnline.ServiceProgressionRewards.HasBucketByBucketId // (Final|Native|Public|Const) // @ game+0x53a65d0
	struct UServiceProgressionRewardBucket* GetBucketByBucketId(struct FString BucketId); // Function DiscoveryOnline.ServiceProgressionRewards.GetBucketByBucketId // (Final|Native|Public|Const) // @ game+0x53a4930
};

// Class DiscoveryOnline.DiscoveryScenario
// Size: 0x180 (Inherited: 0xa0)
struct UDiscoveryScenario : UObject {
	struct FString ScenarioName; // 0x98(0x10)
	struct FDiscoveryScenarioConditions Conditions; // 0xa8(0x01)
	struct FDiscoveryScenarioUISettings UISettings; // 0xb0(0x18)
	struct FDiscoveryScenarioMatchmakingParameters Parameters; // 0xc8(0xb0)
	char pad_179[0x7]; // 0x179(0x07)
};

// Class DiscoveryOnline.DiscoveryScenarioList
// Size: 0xb0 (Inherited: 0xa0)
struct UDiscoveryScenarioList : UObject {
	struct TArray<struct UDiscoveryScenario*> Scenarios; // 0x98(0x10)
};

// Class DiscoveryOnline.GameServerHelper
// Size: 0xa0 (Inherited: 0xa0)
struct UGameServerHelper : UObject {
};

// Class DiscoveryOnline.InventoryConversion
// Size: 0xa0 (Inherited: 0xa0)
struct UInventoryConversion : UObject {

	bool RerollQuestsFromGateway(struct UInventoryServiceInventory* Inventory, struct FApiGatewayDiscoveryRerollQuestsResponse& Response); // Function DiscoveryOnline.InventoryConversion.RerollQuestsFromGateway // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x607bc50
	bool FillInInventoryModel(struct UInventoryServiceQuestDescriptionModel* ModelToFillIn, struct FApiGatewayDiscoveryGetQuestDescriptionResponse& InContext); // Function DiscoveryOnline.InventoryConversion.FillInInventoryModel // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60813c0
};

