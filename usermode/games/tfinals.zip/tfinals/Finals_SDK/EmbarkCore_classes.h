// Class EmbarkCore.AssetDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAssetDataMixinLibrary : UObject {

	bool GetTagValueString(struct FAssetData& AssetData, struct FName& Tag, struct FString& OutValue); // Function EmbarkCore.AssetDataMixinLibrary.GetTagValueString // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x42bc200
};

// Class EmbarkCore.EmbarkFeatureFlagEditorUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkFeatureFlagEditorUtils : UBlueprintFunctionLibrary {

	bool DynamicSetOrAddFeatureFlagInEditor(struct FString FlagName, bool bFlagValue, struct FString FeatureFlagSubSection); // Function EmbarkCore.EmbarkFeatureFlagEditorUtils.DynamicSetOrAddFeatureFlagInEditor // (Final|Native|Static|Public) // @ game+0x42bcf40
};

// Class EmbarkCore.GameModeClassAliasUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UGameModeClassAliasUtils : UBlueprintFunctionLibrary {

	bool DynamicAddGameModeClassAliasInEditor(struct FName& Alias); // Function EmbarkCore.GameModeClassAliasUtils.DynamicAddGameModeClassAliasInEditor // (Final|Native|Static|Public|HasOutParms) // @ game+0x42bb520
};

// Class EmbarkCore.RewardGainedEvent
// Size: 0xd0 (Inherited: 0xa0)
struct URewardGainedEvent : UObject {
	int32_t PlayerId; // 0x98(0x04)
	int64_t GameAssetId; // 0xa0(0x08)
	int64_t Amount; // 0xa8(0x08)
	int64_t Generation; // 0xb0(0x08)
	struct FString ID; // 0xb8(0x10)
	bool bHasSeen; // 0xc8(0x01)
	char pad_cd[0x3]; // 0xcd(0x03)
};

// Class EmbarkCore.RankChangeEvent
// Size: 0xc0 (Inherited: 0xa0)
struct URankChangeEvent : UObject {
	int32_t PlayerId; // 0x98(0x04)
	int64_t PreviousRank; // 0xa0(0x08)
	int64_t CurrentRank; // 0xa8(0x08)
	struct FString BucketId; // 0xb0(0x10)
};

// Class EmbarkCore.ClassWithIdsInside
// Size: 0xc0 (Inherited: 0xa0)
struct UClassWithIdsInside : UObject {
	struct FTenancyUserId TenancyUserId; // 0x98(0x10)
	struct FEmbarkUserId EmbarkUserId; // 0xa8(0x10)
};

// Class EmbarkCore.EmbarkInputComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkInputComponentMixinLibrary : UObject {

	void SetPriority(struct UInputComponent* Component, int32_t Priority); // Function EmbarkCore.EmbarkInputComponentMixinLibrary.SetPriority // (Final|Native|Static|Public) // @ game+0x42b1130
	void SetBlockInput(struct UInputComponent* Component, bool bBlockInput); // Function EmbarkCore.EmbarkInputComponentMixinLibrary.SetBlockInput // (Final|Native|Static|Public) // @ game+0x42bed40
};

// Class EmbarkCore.EmbarkNetworkJitterInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkNetworkJitterInterface : UInterface {
};

// Class EmbarkCore.FFeatureFlagLockMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFFeatureFlagLockMixinLibrary : UObject {

	bool IsFeatureEnabled(struct FFeatureFlagLock& FeatureFlagLock); // Function EmbarkCore.FFeatureFlagLockMixinLibrary.IsFeatureEnabled // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x42b62f0
};

// Class EmbarkCore.EmbarkFeatureFlag
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkFeatureFlag : UObject {

	struct FString ToCommandLine(struct FString Prefix); // Function EmbarkCore.EmbarkFeatureFlag.ToCommandLine // (Final|Native|Static|Public) // @ game+0x42b4730
	bool RawIsEnabled(struct FString FeatureFlagName); // Function EmbarkCore.EmbarkFeatureFlag.RawIsEnabled // (Final|Native|Static|Public) // @ game+0x42b0990
	bool IsEnabled(struct FFeatureFlag& Flag); // Function EmbarkCore.EmbarkFeatureFlag.IsEnabled // (Final|Native|Static|Public|HasOutParms) // @ game+0x42bf330
	bool IsDeclared(struct FString FeatureFlagName); // Function EmbarkCore.EmbarkFeatureFlag.IsDeclared // (Final|Native|Static|Public) // @ game+0x42b71b0
};

// Class EmbarkCore.UEmbarkFeatureFlagStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UUEmbarkFeatureFlagStatics : UObject {

	void ApplyFromAgonesLabel(struct FString AgonesLabel); // Function EmbarkCore.UEmbarkFeatureFlagStatics.ApplyFromAgonesLabel // (Final|Native|Static|Public) // @ game+0x33d3c00
};

// Class EmbarkCore.FVersionInfoStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UFVersionInfoStatics : UBlueprintFunctionLibrary {

	bool TryGetGlobalVersionInfo(struct FVersionInfo& OutVersionInfo); // Function EmbarkCore.FVersionInfoStatics.TryGetGlobalVersionInfo // (Final|Native|Static|Public|HasOutParms) // @ game+0x42ba030
};

