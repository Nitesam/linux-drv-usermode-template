// Class GeometryCache.GeometryCache
// Size: 0x100 (Inherited: 0xa0)
struct UGeometryCache : UObject {
	struct TArray<struct UMaterialInterface*> Materials; // 0xa0(0x10)
	struct TArray<struct FName> MaterialSlotNames; // 0xb0(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks; // 0xc0(0x10)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0xd0(0x10)
	char pad_e0[0x8]; // 0xe0(0x08)
	int32_t StartFrame; // 0xe8(0x04)
	int32_t EndFrame; // 0xec(0x04)
	uint64_t Hash; // 0xf0(0x08)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class GeometryCache.GeometryCacheActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AGeometryCacheActor : AActor {
	struct UGeometryCacheComponent* GeometryCacheComponent; // 0x398(0x08)

	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x33032c0
};

// Class GeometryCache.GeometryCacheCodecBase
// Size: 0xb0 (Inherited: 0xa0)
struct UGeometryCacheCodecBase : UObject {
	struct TArray<int32_t> TopologyRanges; // 0x98(0x10)
};

// Class GeometryCache.GeometryCacheCodecRaw
// Size: 0xb0 (Inherited: 0xb0)
struct UGeometryCacheCodecRaw : UGeometryCacheCodecBase {
	int32_t DummyProperty; // 0xa8(0x04)
};

// Class GeometryCache.GeometryCacheCodecV1
// Size: 0xb0 (Inherited: 0xb0)
struct UGeometryCacheCodecV1 : UGeometryCacheCodecBase {
};

// Class GeometryCache.GeometryCacheComponent
// Size: 0x780 (Inherited: 0x6f0)
struct UGeometryCacheComponent : UMeshComponent {
	struct UGeometryCache* GeometryCache; // 0x6f0(0x08)
	bool bRunning; // 0x6f8(0x01)
	bool bLooping; // 0x6f9(0x01)
	bool bExtrapolateFrames; // 0x6fa(0x01)
	char pad_6fb[0x1]; // 0x6fb(0x01)
	float StartTimeOffset; // 0x6fc(0x04)
	float PlaybackSpeed; // 0x700(0x04)
	float MotionVectorScale; // 0x704(0x04)
	int32_t NumTracks; // 0x708(0x04)
	float ElapsedTime; // 0x70c(0x04)
	char pad_710[0x4c]; // 0x710(0x4c)
	float Duration; // 0x75c(0x04)
	bool bManualTick; // 0x760(0x01)
	bool bOverrideWireframeColor; // 0x761(0x01)
	char pad_762[0x2]; // 0x762(0x02)
	struct FLinearColor WireframeOverrideColor; // 0x764(0x10)
	char pad_774[0xc]; // 0x774(0x0c)

	void TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping); // Function GeometryCache.GeometryCacheComponent.TickAtThisTime // (Final|Native|Public|BlueprintCallable) // @ game+0x989fb70
	void Stop(); // Function GeometryCache.GeometryCacheComponent.Stop // (Final|Native|Public|BlueprintCallable) // @ game+0x989cd40
	void SetWireframeOverrideColor(struct FLinearColor Color); // Function GeometryCache.GeometryCacheComponent.SetWireframeOverrideColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x98b5990
	void SetStartTimeOffset(float NewStartTimeOffset); // Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset // (Final|Native|Public|BlueprintCallable) // @ game+0x9899b70
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed // (Final|Native|Public|BlueprintCallable) // @ game+0x98a6b50
	void SetOverrideWireframeColor(bool bOverride); // Function GeometryCache.GeometryCacheComponent.SetOverrideWireframeColor // (Final|Native|Public|BlueprintCallable) // @ game+0x98b03e0
	void SetMotionVectorScale(float NewMotionVectorScale); // Function GeometryCache.GeometryCacheComponent.SetMotionVectorScale // (Final|Native|Public|BlueprintCallable) // @ game+0x98ae880
	void SetLooping(bool bNewLooping); // Function GeometryCache.GeometryCacheComponent.SetLooping // (Final|Native|Public|BlueprintCallable) // @ game+0x9894c30
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Function GeometryCache.GeometryCacheComponent.SetGeometryCache // (Final|Native|Public|BlueprintCallable) // @ game+0x98945f0
	void SetExtrapolateFrames(bool bNewExtrapolating); // Function GeometryCache.GeometryCacheComponent.SetExtrapolateFrames // (Final|Native|Public|BlueprintCallable) // @ game+0x98b05c0
	void PlayReversedFromEnd(); // Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd // (Final|Native|Public|BlueprintCallable) // @ game+0x98b0660
	void PlayReversed(); // Function GeometryCache.GeometryCacheComponent.PlayReversed // (Final|Native|Public|BlueprintCallable) // @ game+0x9894b70
	void PlayFromStart(); // Function GeometryCache.GeometryCacheComponent.PlayFromStart // (Final|Native|Public|BlueprintCallable) // @ game+0x98946a0
	void Play(); // Function GeometryCache.GeometryCacheComponent.Play // (Final|Native|Public|BlueprintCallable) // @ game+0x98b0510
	void Pause(); // Function GeometryCache.GeometryCacheComponent.Pause // (Final|Native|Public|BlueprintCallable) // @ game+0x98ac060
	bool IsPlayingReversed(); // Function GeometryCache.GeometryCacheComponent.IsPlayingReversed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9898400
	bool IsPlaying(); // Function GeometryCache.GeometryCacheComponent.IsPlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98a61a0
	bool IsLooping(); // Function GeometryCache.GeometryCacheComponent.IsLooping // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98a6e10
	bool IsExtrapolatingFrames(); // Function GeometryCache.GeometryCacheComponent.IsExtrapolatingFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ae980
	struct FLinearColor GetWireframeOverrideColor(); // Function GeometryCache.GeometryCacheComponent.GetWireframeOverrideColor // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x98941e0
	float GetStartTimeOffset(); // Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98b0d20
	float GetPlaybackSpeed(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98b0720
	float GetPlaybackDirection(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98b4ff0
	bool GetOverrideWireframeColor(); // Function GeometryCache.GeometryCacheComponent.GetOverrideWireframeColor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98abf50
	int32_t GetNumberOfFrames(); // Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9899c40
	float GetMotionVectorScale(); // Function GeometryCache.GeometryCacheComponent.GetMotionVectorScale // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ad1c0
	float GetDuration(); // Function GeometryCache.GeometryCacheComponent.GetDuration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9897c00
	float GetAnimationTime(); // Function GeometryCache.GeometryCacheComponent.GetAnimationTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98adca0
};

// Class GeometryCache.GeometryCacheTrack
// Size: 0xd0 (Inherited: 0xa0)
struct UGeometryCacheTrack : UObject {
	float Duration; // 0x98(0x04)
	char pad_a4[0x2c]; // 0xa4(0x2c)
};

// Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0xf0 (Inherited: 0xd0)
struct UGeometryCacheTrack_FlipbookAnimation : UGeometryCacheTrack {
	uint32_t NumMeshSamples; // 0xc8(0x04)
	char pad_d4[0x1c]; // 0xd4(0x1c)

	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample // (Final|Native|Public|HasOutParms) // @ game+0x989f910
};

// Class GeometryCache.GeometryCacheTrackStreamable
// Size: 0x140 (Inherited: 0xd0)
struct UGeometryCacheTrackStreamable : UGeometryCacheTrack {
	struct UGeometryCacheCodecBase* Codec; // 0xc8(0x08)
	char pad_d8[0x58]; // 0xd8(0x58)
	float StartSampleTime; // 0x130(0x04)
	char pad_134[0xc]; // 0x134(0x0c)
};

// Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0x190 (Inherited: 0xd0)
struct UGeometryCacheTrack_TransformAnimation : UGeometryCacheTrack {
	char pad_d0[0xc0]; // 0xd0(0xc0)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh // (Final|Native|Public|HasOutParms) // @ game+0x98a29e0
};

// Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0x190 (Inherited: 0xd0)
struct UGeometryCacheTrack_TransformGroupAnimation : UGeometryCacheTrack {
	char pad_d0[0xc0]; // 0xd0(0xc0)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh // (Final|Native|Public|HasOutParms) // @ game+0x98a29e0
};

// Class GeometryCache.NiagaraGeometryCacheRendererProperties
// Size: 0x360 (Inherited: 0x130)
struct UNiagaraGeometryCacheRendererProperties : UNiagaraRendererProperties {
	struct TArray<struct FNiagaraGeometryCacheReference> GeometryCaches; // 0x130(0x10)
	enum class ENiagaraRendererSourceDataMode SourceMode; // 0x140(0x01)
	bool bIsLooping; // 0x141(0x01)
	char pad_142[0x2]; // 0x142(0x02)
	uint32_t ComponentCountLimit; // 0x144(0x04)
	struct FNiagaraVariableAttributeBinding PositionBinding; // 0x148(0x38)
	struct FNiagaraVariableAttributeBinding RotationBinding; // 0x180(0x38)
	struct FNiagaraVariableAttributeBinding ScaleBinding; // 0x1b8(0x38)
	struct FNiagaraVariableAttributeBinding ElapsedTimeBinding; // 0x1f0(0x38)
	struct FNiagaraVariableAttributeBinding EnabledBinding; // 0x228(0x38)
	struct FNiagaraVariableAttributeBinding ArrayIndexBinding; // 0x260(0x38)
	struct FNiagaraVariableAttributeBinding RendererVisibilityTagBinding; // 0x298(0x38)
	int32_t RendererVisibility; // 0x2d0(0x04)
	bool bAssignComponentsOnParticleID; // 0x2d4(0x01)
	char pad_2d5[0x3]; // 0x2d5(0x03)
	struct FNiagaraRendererMaterialParameters MaterialParameters; // 0x2d8(0x50)
	char pad_328[0x38]; // 0x328(0x38)
};

