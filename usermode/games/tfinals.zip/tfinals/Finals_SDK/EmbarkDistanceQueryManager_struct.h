// Enum EmbarkDistanceQueryManager.EEmbarkDistanceQueryCallbackFlags
enum class EEmbarkDistanceQueryCallbackFlags : uint8_t {
	None = 0,
	Source = 1,
	Target = 2,
	SourceAndTarget = 3,
	EEmbarkDistanceQueryCallbackFlags_MAX = 4
};

// Enum EmbarkDistanceQueryManager.EEmbarkDistanceQueryVectorMask
enum class EEmbarkDistanceQueryVectorMask : uint8_t {
	None = 0,
	X = 1,
	Y = 2,
	Z = 4,
	XY = 3,
	XYZ = 7,
	EEmbarkDistanceQueryVectorMask_MAX = 8
};

// Enum EmbarkDistanceQueryManager.EEmbarkDistanceQueryLocationType
enum class EEmbarkDistanceQueryLocationType : uint8_t {
	ComponentLocation = 0,
	BoundsOrigin = 1,
	EEmbarkDistanceQueryLocationType_MAX = 2
};

// ScriptStruct EmbarkDistanceQueryManager.EmbarkDistanceQueryInfo
// Size: 0x48 (Inherited: 0x00)
struct FEmbarkDistanceQueryInfo {
	struct FEmbarkDistanceQueryKey SourceKey; // 0x00(0x18)
	struct FEmbarkDistanceQueryKey TargetKey; // 0x18(0x18)
	struct AActor* Source; // 0x30(0x08)
	struct AActor* Target; // 0x38(0x08)
	float Distance; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct EmbarkDistanceQueryManager.EmbarkDistanceQueryKey
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkDistanceQueryKey {
	char pad_0[0x13]; // 0x00(0x13)
	char pad_13_0 : 1; // 0x13(0x01)
	char IsValid : 1; // 0x13(0x01)
	char pad_13_2 : 6; // 0x13(0x01)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct EmbarkDistanceQueryManager.EmbarkDistanceQueryKeySet
// Size: 0x2268 (Inherited: 0x00)
struct FEmbarkDistanceQueryKeySet {
	char pad_0[0x2268]; // 0x00(0x2268)
};

// ScriptStruct EmbarkDistanceQueryManager.EmbarkDistanceQueryHandle
// Size: 0x20 (Inherited: 0x18)
struct FEmbarkDistanceQueryHandle : FEmbarkDistanceQueryKey {
	char pad_18[0x8]; // 0x18(0x08)
};

// ScriptStruct EmbarkDistanceQueryManager.EmbarkDistanceQueryOwnedHandle
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkDistanceQueryOwnedHandle {
	char pad_0[0x20]; // 0x00(0x20)
};

