// Class EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkPSOCacheBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetPSOPrecompilationBatchMode(enum class EPSOPrecompilationBatchMode InMode); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.SetPSOPrecompilationBatchMode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a7d440
	void SetPSOCacheUsageMask(int32_t MaterialQuality); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.SetPSOCacheUsageMask // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a7e790
	void ResumePSOPrecompilation(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.ResumePSOPrecompilation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a7dfd0
	void PausePSOPrecompilation(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.PausePSOPrecompilation // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a7e000
	struct FPSOTimingStats GetPSOTimingStats(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.GetPSOTimingStats // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a7c200
	int32_t GetPSOPrecompilationPercentage(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.GetPSOPrecompilationPercentage // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a7df30
	int32_t GetNumPrecompilingPSOsRemaining(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.GetNumPrecompilingPSOsRemaining // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a7d280
	int32_t GetNumPrecompilingEssentialPSOsRemaining(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.GetNumPrecompilingEssentialPSOsRemaining // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a7b790
	int32_t GetEssentialPSOPrecompilationPercentage(); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.GetEssentialPSOPrecompilationPercentage // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a7c2f0
	bool AnyDrawsSkipped(uint64_t Frame); // Function EmbarkPSOCache.EmbarkPSOCacheBlueprintLibrary.AnyDrawsSkipped // (Final|Native|Static|Public) // @ game+0x5a7b6f0
};

