// Class DeveloperSettings.DeveloperSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UDeveloperSettings : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class DeveloperSettings.DeveloperSettingsBackedByCVars
// Size: 0xb0 (Inherited: 0xb0)
struct UDeveloperSettingsBackedByCVars : UDeveloperSettings {
};

// Class DeveloperSettings.PlatformSettings
// Size: 0xb0 (Inherited: 0xa0)
struct UPlatformSettings : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class DeveloperSettings.PlatformSettingsManager
// Size: 0xf0 (Inherited: 0xa0)
struct UPlatformSettingsManager : UObject {
	struct TMap<struct UPlatformSettings*, struct FPlatformSettingsInstances> SettingsMap; // 0x98(0x50)
};

