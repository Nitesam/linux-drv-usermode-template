// Class EmbarkAINavigation.EmbarkAINavigationFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAINavigationFunctionLibrary : UBlueprintFunctionLibrary {

	void ReconfigureAndRecreateNavSystem(struct UObject* WorldContextObject, struct UNavigationSystemConfig* Config); // Function EmbarkAINavigation.EmbarkAINavigationFunctionLibrary.ReconfigureAndRecreateNavSystem // (Final|Native|Static|Public) // @ game+0x5ef7dd0
	void RebuildAllNavDataSync(struct UNavigationSystemV1* NavigationSystem); // Function EmbarkAINavigation.EmbarkAINavigationFunctionLibrary.RebuildAllNavDataSync // (Final|Native|Static|Public) // @ game+0x5ef7610
	bool HasPath(struct ARecastNavMesh* NavMeshData, struct FVector& From, struct FVector& To, struct FVector& ProjectionExtent, float MaxPathDistance, float& OutPathLength); // Function EmbarkAINavigation.EmbarkAINavigationFunctionLibrary.HasPath // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5ef2ca0
	bool BatchHasPath(struct ARecastNavMesh* NavMeshData, struct FVector& From, struct TArray<struct FVector>& ToPoints, struct FVector& ProjectionExtent, float MaxPathDistance, struct TArray<bool>& OutHasPaths); // Function EmbarkAINavigation.EmbarkAINavigationFunctionLibrary.BatchHasPath // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5ef4580
	bool BatchAnyPointHasPath(struct ARecastNavMesh* NavMeshData, struct TArray<struct FVector>& FromPoints, struct TArray<struct FVector>& ToPoints, struct FVector& ProjectionExtentTarget, float MaxPathDistance, struct TArray<bool>& OutHasPaths); // Function EmbarkAINavigation.EmbarkAINavigationFunctionLibrary.BatchAnyPointHasPath // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5ef5fb0
};

// Class EmbarkAINavigation.EmbarkAINavLinkDataComponent
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkAINavLinkDataComponent : UActorComponent {
};

// Class EmbarkAINavigation.EmbarkAINavLinkAssetUserData
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAINavLinkAssetUserData : UAssetUserData {
};

// Class EmbarkAINavigation.EmbarkAINavLinkManager
// Size: 0x3a0 (Inherited: 0x3a0)
struct AEmbarkAINavLinkManager : AActor {
};

// Class EmbarkAINavigation.EmbarkHierarchicalHeightMap
// Size: 0x3d0 (Inherited: 0x3a0)
struct AEmbarkHierarchicalHeightMap : AActor {
	struct USceneComponent* SceneComponent; // 0x398(0x08)
	int32_t BaseCellSize; // 0x3a0(0x04)
	int32_t BaseDesiredDimensions; // 0x3a4(0x04)
	struct UEmbarkHierarchicalHeightMapData* Data; // 0x3a8(0x08)
	struct FHierarchicalHeightMapData HeightmapData; // 0x3b0(0x20)

	void LoadData(); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.LoadData // (Final|Native|Public|BlueprintCallable) // @ game+0x5ef6b70
	bool IsValid(); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.IsValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef2170
	bool IsLocationInsideHeightMap(struct FVector WorldLocation); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.IsLocationInsideHeightMap // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef4de0
	bool IsLocationIndoors(struct FVector WorldLocation, float Radius, float MinCellSize, float FractionThreshold); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.IsLocationIndoors // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef7880
	int32_t GridSearchForHeights(struct FVector CenterWorldLoc, float MinDist2D, float MaxDist2D, float HeightDiffThreshold, struct FRandomStream& RandStream, struct TArray<struct FVector>& OutLocations, float MinCellSize, int32_t MaxClusterSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GridSearchForHeights // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef5800
	struct FBox GetHeightMapBounds(); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetHeightMapBounds // (Final|Native|Public|HasDefaults|Const) // @ game+0x5ef7800
	float GetHeight(struct FVector Location, float MinCellSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetHeight // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef76b0
	struct FVector GetGroundCellLocation(struct FVector Location, float MinCellSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetGroundCellLocation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef1420
	bool GetCollisionInStraightLine(struct FVector Start, struct FVector End, struct FVector& OutCollision, float MinCellSize, bool bInvertCollision); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetCollisionInStraightLine // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef4330
	float GetBestCellSize(float MinCellSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetBestCellSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef6c10
	float GetAverageGroundHeight(struct FVector CenterWorldLoc, float GridRadius, float MinCellSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetAverageGroundHeight // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef5320
	float GetAreaBelowHeightMapFraction(struct FVector WorldLocation, float Radius, float MinCellSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GetAreaBelowHeightMapFraction // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef5e40
	void GenerateSpiralGroundLocations(struct FVector CenterWorldLoc, struct TArray<float>& MinCellSizes, struct TArray<struct FVector>& OutLocations); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.GenerateSpiralGroundLocations // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef2fe0
	bool FindHeightDropOnLine(struct FVector Start, struct FVector End, struct FVector& OutLocation, float HeightDiffThreshold, float MinCellSize, float FlatDistRequired); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.FindHeightDropOnLine // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef4a20
	void AlignToCellGrid(struct FVector& Location, float CellSize); // Function EmbarkAINavigation.EmbarkHierarchicalHeightMap.AlignToCellGrid // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef41c0
};

// Class EmbarkAINavigation.EmbarkHierarchicalHeightMapData
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkHierarchicalHeightMapData : UDataAsset {
	struct TArray<struct FHierarchicalHeightMapLayer> DataLayers; // 0xa0(0x10)
	float BaseCellSize; // 0xb0(0x04)
	int32_t BaseDimensions; // 0xb4(0x04)
	float MinHeight; // 0xb8(0x04)
	float Granularity; // 0xbc(0x04)
};

// Class EmbarkAINavigation.EmbarkOctreeNavigation
// Size: 0x440 (Inherited: 0x3a0)
struct AEmbarkOctreeNavigation : AActor {
	struct USceneComponent* SceneComponent; // 0x398(0x08)
	int32_t VoxelSize; // 0x3a0(0x04)
	struct FIntVector WorldBounds; // 0x3a4(0x0c)
	bool bUseOversizedVoxels; // 0x3b0(0x01)
	int32_t Bounds; // 0x3b4(0x04)
	int32_t Partitions; // 0x3b8(0x04)
	struct TArray<struct FEmbarkOctreeNavigationNode> Octree; // 0x3c0(0x10)
	struct TArray<char> Voxels; // 0x3d0(0x10)
	char pad_3e1[0x5f]; // 0x3e1(0x5f)

	void RecalculateWorldBounds(); // Function EmbarkAINavigation.EmbarkOctreeNavigation.RecalculateWorldBounds // (Final|Native|Private|BlueprintCallable) // @ game+0x5ef5ca0
	void OptimizePathSolution(struct FVector Start, struct FVector End, struct TArray<struct FEmbarkOctreeNavigationNodeTransform>& PathSolution, struct TArray<struct FVector>& OutPathSolutionOptimized); // Function EmbarkAINavigation.EmbarkOctreeNavigation.OptimizePathSolution // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef0ec0
	bool IsValid(); // Function EmbarkAINavigation.EmbarkOctreeNavigation.IsValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef1150
	struct FBox GetOctreeBounds(); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetOctreeBounds // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef2510
	struct FEmbarkOctreeNavigationNodeTransform GetNodeTransform(struct FEmbarkOctreeNavigationPosition Node); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetNodeTransform // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef6a70
	void GetNeighbours(struct FEmbarkOctreeNavigationPosition Node, struct TArray<struct FEmbarkOctreeNavigationPosition>& Neighbours); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetNeighbours // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef2060
	struct FBox GetNavigableBounds(); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetNavigableBounds // (Final|Native|Public|HasDefaults|Const) // @ game+0x5ef2240
	float GetEffectiveVoxelSize(); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetEffectiveVoxelSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef6e70
	bool GetCollisionInStraightLine(struct FVector Start, struct FVector End, struct FVector& OutCollision); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetCollisionInStraightLine // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef2380
	float GetBounds(); // Function EmbarkAINavigation.EmbarkOctreeNavigation.GetBounds // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef1e90
	void FindPathSynchronously(struct FVector Origin, struct FVector Destination, struct TArray<struct FEmbarkOctreeNavigationNodeTransform>& OutPathSolution, int32_t& OutOpenedNodes); // Function EmbarkAINavigation.EmbarkOctreeNavigation.FindPathSynchronously // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef2960
	bool FindNode(struct FVector Location, struct FEmbarkOctreeNavigationPosition& OutNode); // Function EmbarkAINavigation.EmbarkOctreeNavigation.FindNode // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef7500
	void FindMultiplePathsSynchronously(struct FVector Origin, struct TArray<struct FVector> Destinations, struct TArray<struct FEmbarkOctreeNavigationPath>& OutPathSolutions, int32_t& OutOpenedNodes); // Function EmbarkAINavigation.EmbarkOctreeNavigation.FindMultiplePathsSynchronously // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef3b60
	bool FindClosestNavigableNode(struct FVector Location, float CollisionRadius, bool bWithLeniency, struct FEmbarkOctreeNavigationPosition& OutNode, struct FVector& AdjustedLocation); // Function EmbarkAINavigation.EmbarkOctreeNavigation.FindClosestNavigableNode // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef3dd0
	bool CanPathInStraightLine(struct FVector Start, struct FVector End); // Function EmbarkAINavigation.EmbarkOctreeNavigation.CanPathInStraightLine // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef16a0
};

// Class EmbarkAINavigation.OctreeNavSubGridFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UOctreeNavSubGridFunctionLibrary : UBlueprintFunctionLibrary {

	void VoxelToIndexShift(struct FOctreeNavSubGrid& SubGrid, int64_t VoxelX, int64_t VoxelY, int64_t VoxelZ, int64_t& OutIndex, int32_t& OutShift); // Function EmbarkAINavigation.OctreeNavSubGridFunctionLibrary.VoxelToIndexShift // (Final|Native|Static|Public|HasOutParms) // @ game+0x5f00320
	void SetVoxel(struct FOctreeNavSubGrid& SubGrid, int64_t VoxelX, int64_t VoxelY, int64_t VoxelZ, bool bSet); // Function EmbarkAINavigation.OctreeNavSubGridFunctionLibrary.SetVoxel // (Final|Native|Static|Public|HasOutParms) // @ game+0x5efeca0
	struct FOctreeNavSubGrid New(struct FVector WorldOrigin, int64_t GridX, int64_t GridY, int64_t GridZ, int64_t OctreeDim, int64_t VoxelSize); // Function EmbarkAINavigation.OctreeNavSubGridFunctionLibrary.New // (Final|Native|Static|Public|HasDefaults) // @ game+0x5f01f80
	bool IsOccupied(struct FOctreeNavSubGrid& SubGrid, int64_t VoxelX, int64_t VoxelY, int64_t VoxelZ); // Function EmbarkAINavigation.OctreeNavSubGridFunctionLibrary.IsOccupied // (Final|Native|Static|Public|HasOutParms) // @ game+0x5ef9360
	void AddVoxel(struct FOctreeNavSubGrid& SubGrid, uint64_t Voxel); // Function EmbarkAINavigation.OctreeNavSubGridFunctionLibrary.AddVoxel // (Final|Native|Static|Public|HasOutParms) // @ game+0x5efe910
};

// Class EmbarkAINavigation.EmbarkRecastNavigationData
// Size: 0x790 (Inherited: 0x6d0)
struct AEmbarkRecastNavigationData : ARecastNavMesh {
	struct FEmbarkRecastNavLinkGenerationConfig NavLinkGenerationConfig; // 0x6c8(0x34)
	struct FString EnabledByFeatureFlag; // 0x700(0x10)
	char pad_714[0x7c]; // 0x714(0x7c)
};

// Class EmbarkAINavigation.EmbarkRecastNavLinkArea
// Size: 0xc0 (Inherited: 0xc0)
struct UEmbarkRecastNavLinkArea : UNavArea {
};

// Class EmbarkAINavigation.EmbarkRecastDefaultNavLinkArea
// Size: 0xc0 (Inherited: 0xc0)
struct UEmbarkRecastDefaultNavLinkArea : UEmbarkRecastNavLinkArea {
};

// Class EmbarkAINavigation.EmbarkRecastNavMeshDebugComponent
// Size: 0x1b0 (Inherited: 0x160)
struct UEmbarkRecastNavMeshDebugComponent : UActorComponent {
	char pad_160[0x50]; // 0x160(0x50)

	void ClientSendVertices(struct TArray<struct FVector_NetQuantize10> InVertices); // Function EmbarkAINavigation.EmbarkRecastNavMeshDebugComponent.ClientSendVertices // (Final|Net|Native|Event|Private|NetClient) // @ game+0x5efb580
	void ClientSendNavLinks(float AgentRadius, float AgentHeight, struct TArray<struct FEmbarkRecastDebugNavLinkHeader> InNavLinkHeaders, struct TArray<struct FVector_NetQuantize10> Starts, struct TArray<struct FVector_NetQuantize10> Ends, struct TArray<char> InInvalidNavLinks); // Function EmbarkAINavigation.EmbarkRecastNavMeshDebugComponent.ClientSendNavLinks // (Final|Net|Native|Event|Private|NetClient) // @ game+0x5f005e0
};

// Class EmbarkAINavigation.EmbarkNavLinkProxy
// Size: 0x3b0 (Inherited: 0x3a0)
struct AEmbarkNavLinkProxy : AActor {
	struct USceneComponent* RootProxy; // 0x398(0x08)
	struct UNavigationSystemV1* NavigationSystem; // 0x3a0(0x08)
};

// Class EmbarkAINavigation.EmbarkRecastNavLinkBase
// Size: 0x430 (Inherited: 0x3c0)
struct UEmbarkRecastNavLinkBase : USceneComponent {
	char pad_3c0[0x10]; // 0x3c0(0x10)
	struct FVector Left; // 0x3d0(0x18)
	struct FVector Right; // 0x3e8(0x18)
	enum class ENavLinkDirection Direction; // 0x400(0x01)
	char pad_401[0x7]; // 0x401(0x07)
	struct UEmbarkRecastNavLinkArea* NavLinkAreaOverride; // 0x408(0x08)
	char pad_410[0x20]; // 0x410(0x20)

	int64_t GetNavLinkId(); // Function EmbarkAINavigation.EmbarkRecastNavLinkBase.GetNavLinkId // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5eff6c0
};

// Class EmbarkAINavigation.EmbarkRecastNavLink
// Size: 0x4a0 (Inherited: 0x430)
struct UEmbarkRecastNavLink : UEmbarkRecastNavLinkBase {
	struct FVector ObstaclePoint; // 0x430(0x18)
	struct TWeakObjectPtr<struct UPrimitiveComponent> StartPrimitive; // 0x448(0x08)
	struct TWeakObjectPtr<struct UPrimitiveComponent> EndPrimitive; // 0x450(0x08)
	struct TWeakObjectPtr<struct UPrimitiveComponent> DestructibleBlockerComponent; // 0x458(0x08)
	bool bIsHorizontalNavLink; // 0x460(0x01)
	char pad_461[0x7]; // 0x461(0x07)
	struct FVector EdgeStart; // 0x468(0x18)
	struct FVector EdgeEnd; // 0x480(0x18)
	char pad_498[0x8]; // 0x498(0x08)
};

// Class EmbarkAINavigation.EmbarkRecastNavigationSubsystem
// Size: 0x270 (Inherited: 0xb0)
struct UEmbarkRecastNavigationSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x10]; // 0xb0(0x10)
	struct AEmbarkNavLinkProxy* NavLinkProxy; // 0xc0(0x08)
	char pad_c8[0x10]; // 0xc8(0x10)
	struct UNavigationSystemV1* NavSystem; // 0xd8(0x08)
	char pad_e0[0x10]; // 0xe0(0x10)
	struct TMap<struct FNavLinkId, struct UEmbarkRecastNavLink*> ActiveNavLinks; // 0xf0(0x50)
	struct TArray<struct UEmbarkRecastNavLink*> UnusedNavLinks; // 0x140(0x10)
	struct TMap<struct FNavLinkId, struct UEmbarkRecastNavLinkBase*> ManuallyAddedNavLinks; // 0x150(0x50)
	char pad_1a0[0x50]; // 0x1a0(0x50)
	struct TSet<struct AEmbarkRecastNavigationData*> MonitoredNavData; // 0x1f0(0x50)
	char pad_240[0x30]; // 0x240(0x30)

	void UnregisterTileRebuiltDelegate(int32_t Handle); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.UnregisterTileRebuiltDelegate // (Final|Native|Public) // @ game+0x5eff3c0
	void SetNavMeshFrameBudgetMs(float BudgetMs); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.SetNavMeshFrameBudgetMs // (Final|Native|Public|BlueprintCallable) // @ game+0x5efb630
	void SetNavlinkFrameBudgetMs(float BudgetMs); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.SetNavlinkFrameBudgetMs // (Final|Native|Public|BlueprintCallable) // @ game+0x5efcfa0
	bool RemoveManualNavLink(struct UEmbarkRecastNavLinkBase* NavLink); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.RemoveManualNavLink // (Final|Native|Public|BlueprintCallable) // @ game+0x5efba90
	int32_t RegisterTileRebuiltDelegate(struct FVector WorldLocation, struct FName AgentName, struct FDelegate Delegate); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.RegisterTileRebuiltDelegate // (Final|Native|Public|HasDefaults) // @ game+0x5eff500
	struct FEmbarkNavProjectionResult ProjectPointToNavMesh(struct FVector WorldLocation, struct FName NavMeshAgentName, struct FVector ProjectionExtent); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.ProjectPointToNavMesh // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5efa050
	bool NavMeshRaycast(struct FVector StartLocation, struct FVector EndLocation, struct FName NavMeshAgentName, struct FVector& OutHitLocation, float& OutHitDistance); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.NavMeshRaycast // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5ef9c50
	bool IsPointOnNavMesh(struct FVector WorldLocation, struct FName NavMeshAgentName, float HorizontalExtent, float VerticalExtent); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.IsPointOnNavMesh // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5ef89a0
	bool IsNavLinkIdValid(int64_t NavLinkId); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.IsNavLinkIdValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5efc710
	bool IsManualNavLinkRegistered(struct UEmbarkRecastNavLinkBase* NavLink); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.IsManualNavLinkRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5efb6d0
	bool IsGeneratingNavLinks(); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.IsGeneratingNavLinks // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef9f00
	bool GetNavMeshTrianglesInArea(struct FVector Center, struct FVector Extent, struct FName NavMeshAgentName, struct TArray<struct FVector>& OutTriangleVertices); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetNavMeshTrianglesInArea // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f01170
	float GetNavMeshFrameBudgetMs(); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetNavMeshFrameBudgetMs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2cfc090
	bool GetNavLinksInArea(struct FVector Center, float Radius, struct TArray<struct UEmbarkRecastNavLink*>& OutNavLinks); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetNavLinksInArea // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5ef99d0
	float GetNavLinkFrameBudgetMs(); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetNavLinkFrameBudgetMs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f01e40
	bool GetNavDataConfig(struct FName NavMeshAgentName, struct FNavDataConfig& OutConfig); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetNavDataConfig // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5effea0
	struct UNavAreaBase* GetNavAreaClassAtLocation(struct FVector WorldLocation, struct FName NavMeshAgentName, struct FVector ProjectionExtent); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetNavAreaClassAtLocation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5efaef0
	int32_t GetActiveGenerationCount(); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GetActiveGenerationCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1700c90
	void GenerateNavLinks(struct FName NavMeshAgentName, struct FBox& GenerationArea); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.GenerateNavLinks // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f01010
	struct FEmbarkNavPathSegmentResult FindPathSync(struct FVector StartLocation, struct FVector EndLocation, struct FName NavMeshAgentName); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.FindPathSync // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5efd6b0
	void CancelAllNavLinkGeneration(); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.CancelAllNavLinkGeneration // (Final|Native|Public|BlueprintCallable) // @ game+0x5ef9810
	bool ArePointsOnSameNavMeshPolygon(struct FVector LocationA, struct FVector LocationB, struct FName NavMeshAgentName, struct FVector ProjectionExtent); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.ArePointsOnSameNavMeshPolygon // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5f00030
	bool AddManualNavLink(struct UEmbarkRecastNavLinkBase* NavLink); // Function EmbarkAINavigation.EmbarkRecastNavigationSubsystem.AddManualNavLink // (Final|Native|Public|BlueprintCallable) // @ game+0x5f00270
};

// Class EmbarkAINavigation.HpaNavigation
// Size: 0x7f0 (Inherited: 0x3a0)
struct AHpaNavigation : AActor {
	struct USceneComponent* SceneComponent; // 0x398(0x08)
	int32_t VoxelSize; // 0x3a0(0x04)
	int32_t XGridSize; // 0x3a4(0x04)
	int32_t YGridSize; // 0x3a8(0x04)
	int32_t ZGridSize; // 0x3ac(0x04)
	bool bUseDiagonalMovementVolumes; // 0x3b0(0x01)
	bool bUseDiagonalMovementVoxels; // 0x3b1(0x01)
	float VoxelVoxelCost; // 0x3b4(0x04)
	float VoxelVolumeCost; // 0x3b8(0x04)
	float VolumeVoxelCost; // 0x3bc(0x04)
	float VolumeVolumeCost; // 0x3c0(0x04)
	struct UHpaVoxelData* Data; // 0x3c8(0x08)
	bool bDisplayWorldBoundary; // 0x3d0(0x01)
	char pad_3d3[0x1]; // 0x3d3(0x01)
	struct FIntVector WorldOrigin; // 0x3d4(0x0c)
	struct FIntVector GridMax; // 0x3e0(0x0c)
	int32_t VolumeSize; // 0x3ec(0x04)
	struct TArray<uint64_t> VoxelData; // 0x3f0(0x10)
	struct TArray<uint16_t> HeightmapData; // 0x400(0x10)
	char pad_410[0x100]; // 0x410(0x100)
	struct AActor* DebugOrigin; // 0x510(0x08)
	struct AActor* DebugDestination; // 0x518(0x08)
	char pad_520[0x2d0]; // 0x520(0x2d0)

	void LoadData(); // Function EmbarkAINavigation.HpaNavigation.LoadData // (Final|Native|Public|BlueprintCallable) // @ game+0x5effc60
	bool IsLocationIndoors(struct FVector WorldLocation, bool bCheckAdjacentVoxels, float FractionThreshold); // Function EmbarkAINavigation.HpaNavigation.IsLocationIndoors // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f01ce0
	float GetLocationBelowHeightMapFraction(struct FVector WorldLocation, bool bCheckAdjacentVoxels); // Function EmbarkAINavigation.HpaNavigation.GetLocationBelowHeightMapFraction // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f00ca0
	bool GetCollisionInStraightLine(struct FVector Start, struct FVector End, struct FVector& OutCollision); // Function EmbarkAINavigation.HpaNavigation.GetCollisionInStraightLine // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5ef2380
	bool GetClosestVoxel(struct FVector WorldLocation, struct FVector& OutVoxelLocation, bool& OutNavigable); // Function EmbarkAINavigation.HpaNavigation.GetClosestVoxel // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef8350
	void FindVoxelsInTaperedCapsule(struct FTransform& CapsuleTransform, float SourceSphereRadius, float TargetSphereRadius, float CapsuleLength, bool bOnlyOneMatchingVoxelPerZColumn, bool bFindGroundVoxel, struct TArray<struct FVector>& OutVoxels); // Function EmbarkAINavigation.HpaNavigation.FindVoxelsInTaperedCapsule // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5efd320
	struct FVector FindGroundVoxelLocationInWorld(float WorldLocationX, float WorldLocationY); // Function EmbarkAINavigation.HpaNavigation.FindGroundVoxelLocationInWorld // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f01e60
	struct FVector FindGroundVoxelLocationFromPoint(struct FVector WorldLocation); // Function EmbarkAINavigation.HpaNavigation.FindGroundVoxelLocationFromPoint // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5efb3d0
	bool FindClosestNavigablePositionInRange(struct FVector WorldLocation, int32_t Range, struct FVector& OutLocation); // Function EmbarkAINavigation.HpaNavigation.FindClosestNavigablePositionInRange // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ef95e0
	bool FindBidirectionalPath_DebugStressTest(struct FVector Origin, struct FVector Destination, struct TArray<struct FVector>& OutPathSolution, int32_t& OutOpenedNodes, bool Optimize); // Function EmbarkAINavigation.HpaNavigation.FindBidirectionalPath_DebugStressTest // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5eff7e0
	bool FindBidirectionalPath_DebugStep(struct FVector Origin, struct FVector Destination, int32_t& OutOpenedNodes, struct FVector& ForwardNode, struct FVector& BackwardNode); // Function EmbarkAINavigation.HpaNavigation.FindBidirectionalPath_DebugStep // (Final|Native|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5efc7c0
	bool CanPathInStraightLine(struct FVector Start, struct FVector End); // Function EmbarkAINavigation.HpaNavigation.CanPathInStraightLine // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5ef16a0
};

// Class EmbarkAINavigation.HpaNavigationObstacleComponent
// Size: 0x160 (Inherited: 0x160)
struct UHpaNavigationObstacleComponent : UActorComponent {
	bool bUseRVO; // 0x158(0x01)
};

// Class EmbarkAINavigation.HpaNavigationDynamicObstacleComponent
// Size: 0x1a0 (Inherited: 0x160)
struct UHpaNavigationDynamicObstacleComponent : UHpaNavigationObstacleComponent {
	struct FBox ObstacleDimensions; // 0x160(0x38)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class EmbarkAINavigation.HpaNavigationStaticObstacleComponent
// Size: 0x160 (Inherited: 0x160)
struct UHpaNavigationStaticObstacleComponent : UHpaNavigationObstacleComponent {
};

// Class EmbarkAINavigation.HpaNavigationManager
// Size: 0x3a0 (Inherited: 0x3a0)
struct AHpaNavigationManager : AActor {
};

// Class EmbarkAINavigation.HpaNavigationSubsystem
// Size: 0xdbe0 (Inherited: 0xb0)
struct UHpaNavigationSubsystem : UTickableWorldSubsystem {
	int32_t MaxNodesPushedOntoOpenSetEachFrame; // 0xb0(0x04)
	int32_t MaxSimultaniousTasks; // 0xb4(0x04)
	float DynamicObstacleUpdateTime; // 0xb8(0x04)
	int32_t MaxTaskIterations; // 0xbc(0x04)
	float TaskQueryTimeout; // 0xc0(0x04)
	char pad_c4[0x4]; // 0xc4(0x04)
	struct TArray<struct UHpaNavigationObstacleComponent*> AvoidanceObjects; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnAnyNavDataChanged; // 0xd8(0x10)
	struct TArray<struct AHpaNavigation*> NavigationGraphs; // 0xe8(0x10)
	char pad_f8[0x38]; // 0xf8(0x38)
	struct TArray<struct AEmbarkOctreeNavigation*> NavigationOctrees; // 0x130(0x10)
	char pad_140[0x38]; // 0x140(0x38)
	struct TArray<struct AEmbarkHierarchicalHeightMap*> HeightMaps; // 0x178(0x10)
	char pad_188[0xda00]; // 0x188(0xda00)
	struct TSet<struct AActor*> ActiveNavigationTaskOwners; // 0xdb88(0x50)
	char pad_dbd8[0x8]; // 0xdbd8(0x08)

	void UnregisterDynamicObstacle(struct UHpaNavigationDynamicObstacleComponent* Obstacle); // Function EmbarkAINavigation.HpaNavigationSubsystem.UnregisterDynamicObstacle // (Final|Native|Public|BlueprintCallable) // @ game+0x5f16600
	void UnregisterAvoidanceObstacle(struct UHpaNavigationObstacleComponent* Obstacle); // Function EmbarkAINavigation.HpaNavigationSubsystem.UnregisterAvoidanceObstacle // (Final|Native|Public|BlueprintCallable) // @ game+0x5f0c6c0
	struct AEmbarkOctreeNavigation* SelectBestOctree(float Radius, struct FVector Location); // Function EmbarkAINavigation.HpaNavigationSubsystem.SelectBestOctree // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f03720
	struct AEmbarkHierarchicalHeightMap* SelectBestHeightMap(struct FVector Location); // Function EmbarkAINavigation.HpaNavigationSubsystem.SelectBestHeightMap // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f093a0
	struct AHpaNavigation* SelectBestGraph(float Radius, struct FVector Location); // Function EmbarkAINavigation.HpaNavigationSubsystem.SelectBestGraph // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f03720
	bool SchedulePathfindingTaskWithOrigin(struct FHpaNavDataHandle& Handle, struct AActor* Actor, struct FVector Origin, struct FVector Destination, struct FHpaNavigationQueryParams QueryParams, struct FDelegate ResultHandlerDelegate); // Function EmbarkAINavigation.HpaNavigationSubsystem.SchedulePathfindingTaskWithOrigin // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5f1b9b0
	bool SchedulePathfindingTask(struct FHpaNavDataHandle& Handle, struct AActor* Actor, struct FVector Destination, struct FHpaNavigationQueryParams QueryParams, struct FDelegate ResultHandlerDelegate); // Function EmbarkAINavigation.HpaNavigationSubsystem.SchedulePathfindingTask // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f12050
	void RegisterDynamicObstacle(struct UHpaNavigationDynamicObstacleComponent* Obstacle); // Function EmbarkAINavigation.HpaNavigationSubsystem.RegisterDynamicObstacle // (Final|Native|Public|BlueprintCallable) // @ game+0x5f168c0
	void RegisterAvoidanceObstacle(struct UHpaNavigationObstacleComponent* Obstacle); // Function EmbarkAINavigation.HpaNavigationSubsystem.RegisterAvoidanceObstacle // (Final|Native|Public|BlueprintCallable) // @ game+0x5f10280
	void RegenerateArea(struct FVector Origin, struct FVector BoxExtent, bool bClearData); // Function EmbarkAINavigation.HpaNavigationSubsystem.RegenerateArea // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5f09920
	bool IsValid(); // Function EmbarkAINavigation.HpaNavigationSubsystem.IsValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f15130
	bool IsNavDataHandleValid(struct FHpaNavDataHandle& Handle); // Function EmbarkAINavigation.HpaNavigationSubsystem.IsNavDataHandleValid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f13c70
	bool IsLocationNavigable(struct FHpaNavDataHandle& Handle, struct FVector WorldLocation, struct FVector& OutLocation); // Function EmbarkAINavigation.HpaNavigationSubsystem.IsLocationNavigable // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f03c50
	bool IsLocationIndoors(struct FVector Location, float SearchRadius, float HeightMapGranularity, float FractionThreshold); // Function EmbarkAINavigation.HpaNavigationSubsystem.IsLocationIndoors // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f094c0
	bool HasTask(struct AActor* Actor); // Function EmbarkAINavigation.HpaNavigationSubsystem.HasTask // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f169f0
	float GetNavigationVoxelSize(struct FVector Location, float CollisionRadius); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetNavigationVoxelSize // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f09290
	bool GetNavigationBounds(struct FVector Location, float AgentRadius, struct FBox& OutNavBox); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetNavigationBounds // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f06d40
	struct FHpaNavDataHandle GetNavDataHandle(struct FVector Location, float AgentRadius); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetNavDataHandle // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f05110
	bool GetMaximumNavigableBounds(struct FBox& OutNavBox); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetMaximumNavigableBounds // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5f14600
	float GetHeightMapGranularity(struct FVector Location, float MinCellSize); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetHeightMapGranularity // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f10e30
	struct FVector GetGroundCellLocation(struct FHpaNavDataHandle& NavData, struct FVector Location); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetGroundCellLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f13020
	struct UHpaNavigationSubsystem* GetCurrent(struct UWorld* World); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetCurrent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5f13b90
	bool GetCollisionInStraightLine(struct FHpaNavDataHandle& Handle, struct FVector Start, struct FVector End, struct FVector& OutCollision); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetCollisionInStraightLine // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f1b270
	bool GetClosestNavigableNode(struct FHpaNavDataHandle& Handle, struct FVector WorldLocation, struct FVector& OutNodeLocation); // Function EmbarkAINavigation.HpaNavigationSubsystem.GetClosestNavigableNode // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f03c50
	void FindGroundCellLocationsInTaperedCapsule(struct FHpaNavDataHandle& NavData, struct FTransform& CapsuleTransform, float SourceSphereRadius, float TargetSphereRadius, float CapsuleLength, bool bOnlyOneMatchingVoxelPerZColumn, bool bFindGroundVoxel, struct TArray<struct FVector>& OutLocations); // Function EmbarkAINavigation.HpaNavigationSubsystem.FindGroundCellLocationsInTaperedCapsule // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5f14230
	struct FVector FindGroundCellLocationDownFromPoint(struct FHpaNavDataHandle& NavData, struct FVector Location); // Function EmbarkAINavigation.HpaNavigationSubsystem.FindGroundCellLocationDownFromPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f07b60
	bool CanPathInStraightLine(struct FHpaNavDataHandle& Handle, struct FVector Start, struct FVector End); // Function EmbarkAINavigation.HpaNavigationSubsystem.CanPathInStraightLine // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5f16b30
	void AbortPathfindingTask(struct AActor* Actor); // Function EmbarkAINavigation.HpaNavigationSubsystem.AbortPathfindingTask // (Final|Native|Public|BlueprintCallable) // @ game+0x2424450
};

// Class EmbarkAINavigation.HpaVoxelData
// Size: 0xd0 (Inherited: 0xa0)
struct UHpaVoxelData : UDataAsset {
	struct TArray<uint64_t> Data; // 0xa0(0x10)
	float VoxelSize; // 0xb0(0x04)
	struct FIntVector WorldOrigin; // 0xb4(0x0c)
	int32_t XGridSize; // 0xc0(0x04)
	int32_t YGridSize; // 0xc4(0x04)
	int32_t ZGridSize; // 0xc8(0x04)
	char pad_cc[0x4]; // 0xcc(0x04)
};

// Class EmbarkAINavigation.HpaTestingPawn
// Size: 0x480 (Inherited: 0x420)
struct AHpaTestingPawn : APawn {
	struct USceneComponent* SceneComponent; // 0x420(0x08)
	enum class EHpaGraphSize GraphSize; // 0x428(0x01)
	char pad_429[0x3]; // 0x429(0x03)
	int32_t DrawSize; // 0x42c(0x04)
	struct FColor Color; // 0x430(0x04)
	char pad_434[0x4]; // 0x434(0x04)
	struct UHpaNavigationSubsystem* HpaNavSys; // 0x438(0x08)
	struct AHpaNavigation* CurrentNavGraph; // 0x440(0x08)
	struct AEmbarkOctreeNavigation* CurrentOctree; // 0x448(0x08)
	char pad_450[0x30]; // 0x450(0x30)
};

