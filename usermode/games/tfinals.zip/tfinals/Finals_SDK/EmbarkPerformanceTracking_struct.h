// Enum EmbarkPerformanceTracking.EGameThreadFrameBudget
enum class EGameThreadFrameBudget : uint8_t {
	InputSampling = 0,
	NetworkReplication = 1,
	StateInterpolation = 2,
	PrePhysics = 3,
	StartPhysics = 4,
	DuringPhysics = 5,
	EndPhysics = 6,
	PostPhysics = 7,
	PostUpdateWork = 8,
	LastDemotable = 9,
	SlateUI = 10,
	WaitForRenderThread = 11,
	Count = 12,
	EGameThreadFrameBudget_MAX = 13
};

// Enum EmbarkPerformanceTracking.EServerFrameBudget
enum class EServerFrameBudget : uint8_t {
	NetworkReplication = 0,
	GameModeTick = 1,
	DestructionClusterSystem = 2,
	RespawnSystem = 3,
	MovementGlobalActor = 4,
	StartPhysicsTick = 5,
	ProcessPhysScene = 6,
	EndPhysicsTick = 7,
	StrainSolver = 8,
	FireSystem = 9,
	BallisticSystem = 10,
	NetBroadcast = 11,
	Count = 12,
	EServerFrameBudget_MAX = 13
};

