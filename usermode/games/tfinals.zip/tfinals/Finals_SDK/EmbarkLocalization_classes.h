// Class EmbarkLocalization.EmbarkLocalizationManager
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkLocalizationManager : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)

	void SetUpDisplayStringOverride(struct FString Namespace, struct FString Key, struct FString Source, struct FString Localized); // Function EmbarkLocalization.EmbarkLocalizationManager.SetUpDisplayStringOverride // (Final|Native|Public) // @ game+0x48cd070
	struct FString GetCurrentLanguage(); // Function EmbarkLocalization.EmbarkLocalizationManager.GetCurrentLanguage // (Final|Native|Public|Const) // @ game+0x331fec0
	struct TArray<struct FString> GetAvailableLanguages(); // Function EmbarkLocalization.EmbarkLocalizationManager.GetAvailableLanguages // (Final|Native|Public|Const) // @ game+0x48c8380
	struct UEmbarkLocalizationManager* Get(); // Function EmbarkLocalization.EmbarkLocalizationManager.Get // (Final|Native|Static|Public) // @ game+0x48c8940
	void ClearDisplayStringOverrides(); // Function EmbarkLocalization.EmbarkLocalizationManager.ClearDisplayStringOverrides // (Final|Native|Public) // @ game+0x48ca560
	void ApplyDisplayStringOverrides(); // Function EmbarkLocalization.EmbarkLocalizationManager.ApplyDisplayStringOverrides // (Final|Native|Public) // @ game+0x48c8f40
};

// Class EmbarkLocalization.EmbarkLocalizationSettings
// Size: 0xc0 (Inherited: 0xb0)
struct UEmbarkLocalizationSettings : UDeveloperSettings {
	struct UEmbarkLocalizationSourceSet* SourceSet; // 0xa8(0x08)
	struct TArray<struct FEmbarkLocalizationSourceConfig> SourceConfigs; // 0xb0(0x10)

	struct UEmbarkLocalizationSettings* Get(); // Function EmbarkLocalization.EmbarkLocalizationSettings.Get // (Final|Native|Static|Public) // @ game+0x48c91e0
};

// Class EmbarkLocalization.EmbarkLocalizationSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkLocalizationSubsystem : UEngineSubsystem {
	struct UEmbarkLocalizationManager* Manager; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class EmbarkLocalization.EmbarkLocalizationSourceSet
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkLocalizationSourceSet : UObject {
	struct TArray<struct UEmbarkLocalizationSource*> Sources; // 0x98(0x10)
};

// Class EmbarkLocalization.EmbarkLocalizationSource
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkLocalizationSource : UObject {
	struct FEmbarkLocalizationSourceConfig SourceConfig; // 0x98(0x28)
};

