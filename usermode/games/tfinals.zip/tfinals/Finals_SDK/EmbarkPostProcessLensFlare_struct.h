// ScriptStruct EmbarkPostProcessLensFlare.LensFlareGhostSettings
// Size: 0x14 (Inherited: 0x00)
struct FLensFlareGhostSettings {
	struct FLinearColor Color; // 0x00(0x10)
	float Scale; // 0x10(0x04)
};

