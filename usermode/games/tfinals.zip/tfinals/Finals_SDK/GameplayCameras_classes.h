// Class GameplayCameras.LegacyCameraShake
// Size: 0x260 (Inherited: 0x150)
struct ULegacyCameraShake : UCameraShakeBase {
	float OscillationDuration; // 0x148(0x04)
	float OscillationBlendInTime; // 0x14c(0x04)
	float OscillationBlendOutTime; // 0x150(0x04)
	struct FROscillator RotOscillation; // 0x154(0x24)
	struct FVOscillator LocOscillation; // 0x178(0x24)
	struct FFOscillator FOVOscillation; // 0x19c(0x0c)
	float AnimPlayRate; // 0x1a8(0x04)
	float AnimScale; // 0x1ac(0x04)
	float AnimBlendInTime; // 0x1b0(0x04)
	float AnimBlendOutTime; // 0x1b4(0x04)
	float RandomAnimSegmentDuration; // 0x1b8(0x04)
	struct UCameraAnimationSequence* AnimSequence; // 0x1c0(0x08)
	char bRandomAnimSegment : 1; // 0x1c8(0x01)
	float OscillatorTimeRemaining; // 0x1cc(0x04)
	char pad_1d0_1 : 7; // 0x1d0(0x01)
	char pad_1d1[0x6f]; // 0x1d1(0x6f)
	struct USequenceCameraShakePattern* SequenceShakePattern; // 0x240(0x08)
	char pad_248[0x18]; // 0x248(0x18)

	struct ULegacyCameraShake* StartLegacyCameraShakeFromSource(struct APlayerCameraManager* PlayerCameraManager, struct ULegacyCameraShake* ShakeClass, struct UCameraShakeSourceComponent* SourceComponent, float Scale, enum class ECameraShakePlaySpace PlaySpace, struct FRotator UserPlaySpaceRot); // Function GameplayCameras.LegacyCameraShake.StartLegacyCameraShakeFromSource // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x69ff700
	struct ULegacyCameraShake* StartLegacyCameraShake(struct APlayerCameraManager* PlayerCameraManager, struct ULegacyCameraShake* ShakeClass, float Scale, enum class ECameraShakePlaySpace PlaySpace, struct FRotator UserPlaySpaceRot); // Function GameplayCameras.LegacyCameraShake.StartLegacyCameraShake // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x69fc430
	void ReceiveStopShake(bool bImmediately); // Function GameplayCameras.LegacyCameraShake.ReceiveStopShake // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePlayShake(float Scale); // Function GameplayCameras.LegacyCameraShake.ReceivePlayShake // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveIsFinished(); // Function GameplayCameras.LegacyCameraShake.ReceiveIsFinished // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3247a90
	void BlueprintUpdateCameraShake(float DeltaTime, float Alpha, struct FMinimalViewInfo& POV, struct FMinimalViewInfo& ModifiedPOV); // Function GameplayCameras.LegacyCameraShake.BlueprintUpdateCameraShake // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class GameplayCameras.LegacyCameraShakePattern
// Size: 0xa0 (Inherited: 0xa0)
struct ULegacyCameraShakePattern : UCameraShakePattern {
};

// Class GameplayCameras.LegacyCameraShakeFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULegacyCameraShakeFunctionLibrary : UBlueprintFunctionLibrary {

	struct ULegacyCameraShake* Conv_LegacyCameraShake(struct UCameraShakeBase* CameraShake); // Function GameplayCameras.LegacyCameraShakeFunctionLibrary.Conv_LegacyCameraShake // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x51afc20
};

// Class GameplayCameras.CameraAnimationCameraModifier
// Size: 0xd0 (Inherited: 0xc0)
struct UCameraAnimationCameraModifier : UCameraModifier {
	struct TArray<struct FActiveCameraAnimationInfo> ActiveAnimations; // 0xb8(0x10)
	uint16_t NextInstanceSerialNumber; // 0xc8(0x02)

	void StopCameraAnimation(struct FCameraAnimationHandle& Handle, bool bImmediate); // Function GameplayCameras.CameraAnimationCameraModifier.StopCameraAnimation // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69fc0b0
	void StopAllCameraAnimationsOf(struct UCameraAnimationSequence* Sequence, bool bImmediate); // Function GameplayCameras.CameraAnimationCameraModifier.StopAllCameraAnimationsOf // (Final|Native|Public|BlueprintCallable) // @ game+0x6a01bb0
	void StopAllCameraAnimations(bool bImmediate); // Function GameplayCameras.CameraAnimationCameraModifier.StopAllCameraAnimations // (Native|Public|BlueprintCallable) // @ game+0x6a08460
	struct FCameraAnimationHandle PlayCameraAnimation(struct UCameraAnimationSequence* Sequence, struct FCameraAnimationParams Params); // Function GameplayCameras.CameraAnimationCameraModifier.PlayCameraAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x6a01460
	bool IsCameraAnimationActive(struct FCameraAnimationHandle& Handle); // Function GameplayCameras.CameraAnimationCameraModifier.IsCameraAnimationActive // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x69fbd80
	struct UCameraAnimationCameraModifier* GetCameraAnimationCameraModifierFromPlayerController(struct APlayerController* PlayerController); // Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifierFromPlayerController // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a08d50
	struct UCameraAnimationCameraModifier* GetCameraAnimationCameraModifierFromID(struct UObject* WorldContextObject, int32_t ControllerId); // Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifierFromID // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a00770
	struct UCameraAnimationCameraModifier* GetCameraAnimationCameraModifier(struct UObject* WorldContextObject, int32_t PlayerIndex); // Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifier // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a09900
};

// Class GameplayCameras.GameplayCamerasFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayCamerasFunctionLibrary : UBlueprintFunctionLibrary {

	enum class ECameraShakePlaySpace Conv_CameraShakePlaySpace(enum class ECameraAnimationPlaySpace CameraAnimationPlaySpace); // Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraShakePlaySpace // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a02750
	enum class ECameraAnimationPlaySpace Conv_CameraAnimationPlaySpace(enum class ECameraShakePlaySpace CameraShakePlaySpace); // Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraAnimationPlaySpace // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a02750
	struct UCameraAnimationCameraModifier* Conv_CameraAnimationCameraModifier(struct APlayerCameraManager* PlayerCameraManager); // Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraAnimationCameraModifier // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x6a00170
};

// Class GameplayCameras.CompositeCameraShakePattern
// Size: 0xb0 (Inherited: 0xa0)
struct UCompositeCameraShakePattern : UCameraShakePattern {
	struct TArray<struct UCameraShakePattern*> ChildPatterns; // 0x98(0x10)
};

// Class GameplayCameras.DefaultCameraShakeBase
// Size: 0x150 (Inherited: 0x150)
struct UDefaultCameraShakeBase : UCameraShakeBase {
};

// Class GameplayCameras.GameplayCamerasSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayCamerasSubsystem : UWorldSubsystem {

	void StopCameraAnimation(struct APlayerController* PlayerController, struct FCameraAnimationHandle& Handle, bool bImmediate); // Function GameplayCameras.GameplayCamerasSubsystem.StopCameraAnimation // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x69fc2f0
	void StopAllCameraAnimationsOf(struct APlayerController* PlayerController, struct UCameraAnimationSequence* Sequence, bool bImmediate); // Function GameplayCameras.GameplayCamerasSubsystem.StopAllCameraAnimationsOf // (Final|Native|Public|BlueprintCallable) // @ game+0x6a086b0
	void StopAllCameraAnimations(struct APlayerController* PlayerController, bool bImmediate); // Function GameplayCameras.GameplayCamerasSubsystem.StopAllCameraAnimations // (Final|Native|Public|BlueprintCallable) // @ game+0x6a094f0
	struct FCameraAnimationHandle PlayCameraAnimation(struct APlayerController* PlayerController, struct UCameraAnimationSequence* Sequence, struct FCameraAnimationParams Params); // Function GameplayCameras.GameplayCamerasSubsystem.PlayCameraAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x69fed20
	bool IsCameraAnimationActive(struct APlayerController* PlayerController, struct FCameraAnimationHandle& Handle); // Function GameplayCameras.GameplayCamerasSubsystem.IsCameraAnimationActive // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6a07520
};

// Class GameplayCameras.SimpleCameraShakePattern
// Size: 0xd0 (Inherited: 0xa0)
struct USimpleCameraShakePattern : UCameraShakePattern {
	float Duration; // 0x98(0x04)
	float BlendInTime; // 0x9c(0x04)
	float BlendOutTime; // 0xa0(0x04)
	char pad_ac[0x24]; // 0xac(0x24)
};

// Class GameplayCameras.PerlinNoiseCameraShakePattern
// Size: 0x150 (Inherited: 0xd0)
struct UPerlinNoiseCameraShakePattern : USimpleCameraShakePattern {
	float LocationAmplitudeMultiplier; // 0xc8(0x04)
	float LocationFrequencyMultiplier; // 0xcc(0x04)
	struct FPerlinNoiseShaker X; // 0xd0(0x08)
	struct FPerlinNoiseShaker Y; // 0xd8(0x08)
	struct FPerlinNoiseShaker Z; // 0xe0(0x08)
	float RotationAmplitudeMultiplier; // 0xe8(0x04)
	float RotationFrequencyMultiplier; // 0xec(0x04)
	struct FPerlinNoiseShaker Pitch; // 0xf0(0x08)
	struct FPerlinNoiseShaker Yaw; // 0xf8(0x08)
	struct FPerlinNoiseShaker Roll; // 0x100(0x08)
	struct FPerlinNoiseShaker FOV; // 0x108(0x08)
	char pad_118[0x38]; // 0x118(0x38)
};

// Class GameplayCameras.TestCameraShake
// Size: 0x150 (Inherited: 0x150)
struct UTestCameraShake : UCameraShakeBase {
};

// Class GameplayCameras.ConstantCameraShakePattern
// Size: 0x100 (Inherited: 0xd0)
struct UConstantCameraShakePattern : USimpleCameraShakePattern {
	struct FVector LocationOffset; // 0xc8(0x18)
	struct FRotator RotationOffset; // 0xe0(0x18)
};

// Class GameplayCameras.WaveOscillatorCameraShakePattern
// Size: 0x170 (Inherited: 0xd0)
struct UWaveOscillatorCameraShakePattern : USimpleCameraShakePattern {
	float LocationAmplitudeMultiplier; // 0xc8(0x04)
	float LocationFrequencyMultiplier; // 0xcc(0x04)
	struct FWaveOscillator X; // 0xd0(0x0c)
	struct FWaveOscillator Y; // 0xdc(0x0c)
	struct FWaveOscillator Z; // 0xe8(0x0c)
	float RotationAmplitudeMultiplier; // 0xf4(0x04)
	float RotationFrequencyMultiplier; // 0xf8(0x04)
	struct FWaveOscillator Pitch; // 0xfc(0x0c)
	struct FWaveOscillator Yaw; // 0x108(0x0c)
	struct FWaveOscillator Roll; // 0x114(0x0c)
	struct FWaveOscillator FOV; // 0x120(0x0c)
	char pad_134[0x3c]; // 0x134(0x3c)
};

