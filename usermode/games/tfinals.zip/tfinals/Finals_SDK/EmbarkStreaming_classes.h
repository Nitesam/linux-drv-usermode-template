// Class EmbarkStreaming.EmbarkStreamingDataAsset
// Size: 0x110 (Inherited: 0xb0)
struct UEmbarkStreamingDataAsset : UOptionalPrimaryDataAsset {
	struct TMap<struct FSoftObjectPath, struct UObject*> LoadedAssetPtrs; // 0xb0(0x50)
	bool bEnableSoftReferenceScanning; // 0x100(0x01)
	enum class EEmbarkStreamingFilter StreamingFilter; // 0x101(0x01)
	char pad_102[0xe]; // 0x102(0x0e)

	bool UseSoftReferenceScanning(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.UseSoftReferenceScanning // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x554c660
	void ScheduleStreamingHintsForAllStreamableDataAssets(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ScheduleStreamingHintsForAllStreamableDataAssets // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x554d9c0
	struct UObject* ResolveSoftObjectPath(struct FSoftObjectPath& ObjectPath, struct FName& DebugPropertyName); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ResolveSoftObjectPath // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x554de90
	struct UObject* ResolveSoftClassPath(struct FSoftClassPath& ClassPath, struct FName& DebugPropertyName); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ResolveSoftClassPath // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5548d20
	struct UObject* ResolveObject(struct FName& DebugPropertyName, struct FSoftObjectPath& ObjectPath, struct UObject* ResolvedObject); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ResolveObject // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5548680
	struct UObject* ResolveClassBlocking(struct FName& DebugPropertyName, struct FSoftClassPath& ClassPath, struct UObject* ResolvedClass); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ResolveClassBlocking // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x554d390
	struct UObject* ResolveClass(struct FName& DebugPropertyName, struct FSoftClassPath& ClassPath, struct UObject* ResolvedClass); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ResolveClass // (Final|Native|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5547a50
	void ReceiveStreamingHint(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ReceiveStreamingHint // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnStreamingDataAssetComplete(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ReceiveOnStreamingDataAssetComplete // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnStreamingDataAssetComplete(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.OnStreamingDataAssetComplete // (Final|Native|Protected) // @ game+0x5545aa0
	void DispatchStreamingHint(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.DispatchStreamingHint // (Final|Native|Public|BlueprintCallable) // @ game+0x5546830
	void ClearLoadedAssetsCache(); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ClearLoadedAssetsCache // (Final|Native|Public|BlueprintCallable) // @ game+0x5546ed0
	void ClearAllLoadedAssetsCache(bool bForceGC); // Function EmbarkStreaming.EmbarkStreamingDataAsset.ClearAllLoadedAssetsCache // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x554a8b0
};

// Class EmbarkStreaming.EmbarkStreaming
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStreaming : UBlueprintFunctionLibrary {

	void SuspendAsyncLoads(float Timeout); // Function EmbarkStreaming.EmbarkStreaming.SuspendAsyncLoads // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x554cce0
	void ResumeAsyncLoads(); // Function EmbarkStreaming.EmbarkStreaming.ResumeAsyncLoads // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x554bb70
	struct UObject* ResolveObject(struct FName& PropertyName, struct FSoftObjectPath& ObjectPath, struct UObject* ResolvedObject); // Function EmbarkStreaming.EmbarkStreaming.ResolveObject // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5546d70
	struct UObject* ResolveClassBlocking(struct FName& PropertyName, struct FSoftClassPath& ClassPath, struct UObject* ResolvedClass); // Function EmbarkStreaming.EmbarkStreaming.ResolveClassBlocking // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x554bf00
	struct UObject* ResolveClass(struct FName& PropertyName, struct FSoftClassPath& ClassPath, struct UObject* ResolvedClass); // Function EmbarkStreaming.EmbarkStreaming.ResolveClass // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x554dc80
	void LoadClassAsync(struct FSoftClassPath& TargetToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadClassAsync // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x554da70
	void LoadAsync(struct FSoftObjectPath& TargetToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadAsync // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5545e70
	void LoadAssetsAsync(struct TArray<struct FAssetData>& AssetsToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadAssetsAsync // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x55481c0
	void LoadAssetAsync(struct FAssetData& AssetToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadAssetAsync // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x554b8a0
	void LoadAllClassesAsync(struct TArray<struct FSoftClassPath>& TargetsToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadAllClassesAsync // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x55516e0
	void LoadAllAsyncEx(struct TArray<struct FSoftObjectPath>& TargetsToStream, struct TArray<struct FSoftClassPath>& ClassesToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadAllAsyncEx // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x55456d0
	void LoadAllAsync(struct TArray<struct FSoftObjectPath>& TargetsToStream, struct UObject* Opt_CallbackObject, struct FName Opt_CallbackFunctionName, struct FString Opt_DebugName); // Function EmbarkStreaming.EmbarkStreaming.LoadAllAsync // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5547c30
	void GetAsyncLoadState(bool& bOutPending, bool& bOutSuspended); // Function EmbarkStreaming.EmbarkStreaming.GetAsyncLoadState // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x55466b0
	void FlushAsyncLoads(enum class EEmbarkStreamingFlushMode FlushMode); // Function EmbarkStreaming.EmbarkStreaming.FlushAsyncLoads // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5547e70
};

// Class EmbarkStreaming.EmbarkStreamingSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkStreamingSubsystem : UWorldSubsystem {
};

