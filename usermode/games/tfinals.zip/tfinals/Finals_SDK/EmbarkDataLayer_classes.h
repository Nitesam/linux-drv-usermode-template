// Class EmbarkDataLayer.EmbarkDataLayerAsset
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkDataLayerAsset : UDataLayerAsset {
};

// Class EmbarkDataLayer.OptionalRuntimeOnlyDataLayerAsset
// Size: 0xb0 (Inherited: 0xb0)
struct UOptionalRuntimeOnlyDataLayerAsset : UEmbarkDataLayerAsset {
};

