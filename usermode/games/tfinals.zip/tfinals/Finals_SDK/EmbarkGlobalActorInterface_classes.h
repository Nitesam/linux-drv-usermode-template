// Class EmbarkGlobalActorInterface.EmbarkGlobalActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AEmbarkGlobalActor : AActor {
	char bCreateOnListenServer : 1; // 0x398(0x01)
	char bCreateOnDedicatedServer : 1; // 0x398(0x01)
	char bCreateOnClients : 1; // 0x398(0x01)
};

// Class EmbarkGlobalActorInterface.EmbarkGlobalActorFactorySubsystemInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkGlobalActorFactorySubsystemInterface : UWorldSubsystem {

	struct AEmbarkGlobalActor* GetGlobalActor(struct AEmbarkGlobalActor* GlobalActorClass); // Function EmbarkGlobalActorInterface.EmbarkGlobalActorFactorySubsystemInterface.GetGlobalActor // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x58bf960
};

