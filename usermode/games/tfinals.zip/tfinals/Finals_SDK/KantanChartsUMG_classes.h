// Class KantanChartsUMG.KantanChart
// Size: 0x240 (Inherited: 0x1f0)
struct UKantanChart : UWidget {
	struct FMargin Margins; // 0x1f0(0x10)
	struct FText ChartTitle; // 0x200(0x18)
	struct FMargin TitlePadding; // 0x218(0x10)
	float UpdateTickRate; // 0x228(0x04)
	char pad_22c[0x14]; // 0x22c(0x14)

	void SetUpdateTickRate(float InRate); // Function KantanChartsUMG.KantanChart.SetUpdateTickRate // (Final|Native|Public|BlueprintCallable) // @ game+0x6a430a0
	void SetMargins(struct FMargin& InMargins); // Function KantanChartsUMG.KantanChart.SetMargins // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a39640
	void SetChartTitlePadding(struct FMargin& InPadding); // Function KantanChartsUMG.KantanChart.SetChartTitlePadding // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a33ea0
	void SetChartTitle(struct FText& InTitle); // Function KantanChartsUMG.KantanChart.SetChartTitle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3ca90
};

// Class KantanChartsUMG.KantanCategoryChart
// Size: 0x260 (Inherited: 0x240)
struct UKantanCategoryChart : UKantanChart {
	bool bAutoPerCategoryStyles; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct UKantanCategoryStyleSet* CategoryStyleSet; // 0x248(0x08)
	struct TArray<struct FCategoryStyleManualMapping> ManualStyleMappings; // 0x250(0x10)

	void AddCategoryStyleOverride(struct FName CategoryId, struct FLinearColor Color); // Function KantanChartsUMG.KantanCategoryChart.AddCategoryStyleOverride // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6a37a50
};

// Class KantanChartsUMG.KantanBarChartBase
// Size: 0x440 (Inherited: 0x260)
struct UKantanBarChartBase : UKantanCategoryChart {
	struct FKantanBarChartStyle WidgetStyle; // 0x260(0x180)
	enum class EKantanBarChartOrientation Orientation; // 0x3e0(0x01)
	char pad_3e1[0x3]; // 0x3e1(0x03)
	float MaxBarValue; // 0x3e4(0x04)
	enum class EKantanBarLabelPosition LabelPosition; // 0x3e8(0x01)
	char pad_3e9[0x3]; // 0x3e9(0x03)
	float BarToGapRatio; // 0x3ec(0x04)
	enum class EKantanBarValueExtents ValueExtentsDisplay; // 0x3f0(0x01)
	char pad_3f1[0x7]; // 0x3f1(0x07)
	struct FCartesianAxisConfig ValueAxisCfg; // 0x3f8(0x48)

	void SetValueAxisConfig(struct FCartesianAxisConfig& InCfg); // Function KantanChartsUMG.KantanBarChartBase.SetValueAxisConfig // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a40060
	void SetOrientation(enum class EKantanBarChartOrientation InOrientation); // Function KantanChartsUMG.KantanBarChartBase.SetOrientation // (Final|Native|Public|BlueprintCallable) // @ game+0x6a347e0
	void SetMaxBarValue(float InMaxValue); // Function KantanChartsUMG.KantanBarChartBase.SetMaxBarValue // (Final|Native|Public|BlueprintCallable) // @ game+0x6a35d00
	void SetLabelPosition(enum class EKantanBarLabelPosition InPosition); // Function KantanChartsUMG.KantanBarChartBase.SetLabelPosition // (Final|Native|Public|BlueprintCallable) // @ game+0x6a37940
	void SetExtentsDisplay(enum class EKantanBarValueExtents InExtents); // Function KantanChartsUMG.KantanBarChartBase.SetExtentsDisplay // (Final|Native|Public|BlueprintCallable) // @ game+0x6a35e10
	void SetBarToGapRatio(float InRatio); // Function KantanChartsUMG.KantanBarChartBase.SetBarToGapRatio // (Final|Native|Public|BlueprintCallable) // @ game+0x6a3c2c0
};

// Class KantanChartsUMG.BarChart
// Size: 0x450 (Inherited: 0x440)
struct UBarChart : UKantanBarChartBase {
	struct UObject* DataSource; // 0x440(0x08)
	char pad_448[0x8]; // 0x448(0x08)

	bool SetDatasource(struct UObject* InDatasource); // Function KantanChartsUMG.BarChart.SetDatasource // (Final|Native|Public|BlueprintCallable) // @ game+0x6a36e90
};

// Class KantanChartsUMG.KantanCartesianChartBase
// Size: 0x4c0 (Inherited: 0x240)
struct UKantanCartesianChartBase : UKantanChart {
	struct FKantanCartesianChartStyle WidgetStyle; // 0x240(0x180)
	struct FKantanCartesianPlotScale PlotScale; // 0x3c0(0x38)
	enum class EKantanDataPointSize DataPointSize; // 0x3f8(0x01)
	char pad_3f9[0x7]; // 0x3f9(0x07)
	struct FCartesianAxisConfig XAxisCfg; // 0x400(0x48)
	struct FCartesianAxisConfig YAxisCfg; // 0x448(0x48)
	struct FMargin AxisTitlePadding; // 0x490(0x10)
	struct UKantanSeriesStyleSet* SeriesStyleSet; // 0x4a0(0x08)
	struct TArray<struct FSeriesStyleManualMapping> ManualStyleMappings; // 0x4a8(0x10)
	bool bAntiAlias; // 0x4b8(0x01)
	char pad_4b9[0x7]; // 0x4b9(0x07)

	void SetYAxisConfig(struct FCartesianAxisConfig& InCfg); // Function KantanChartsUMG.KantanCartesianChartBase.SetYAxisConfig // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a36bf0
	void SetXAxisConfig(struct FCartesianAxisConfig& InCfg); // Function KantanChartsUMG.KantanCartesianChartBase.SetXAxisConfig // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a39980
	void SetPlotScaleByRange(struct FCartesianAxisRange& InRangeX, struct FCartesianAxisRange& InRangeY); // Function KantanChartsUMG.KantanCartesianChartBase.SetPlotScaleByRange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a35fb0
	void SetPlotScale(struct FVector2D& InScale, struct FVector2D& InFocalCoords); // Function KantanChartsUMG.KantanCartesianChartBase.SetPlotScale // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6a417c0
	void SetDataPointSize(enum class EKantanDataPointSize InSize); // Function KantanChartsUMG.KantanCartesianChartBase.SetDataPointSize // (Final|Native|Public|BlueprintCallable) // @ game+0x6a438d0
	void SetAxisTitlePadding(struct FMargin& InPadding); // Function KantanChartsUMG.KantanCartesianChartBase.SetAxisTitlePadding // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a36150
	void EnableSeries(struct FName ID, bool bEnable); // Function KantanChartsUMG.KantanCartesianChartBase.EnableSeries // (Final|Native|Public|BlueprintCallable) // @ game+0x6a3db50
	void ConfigureSeries(struct FName ID, bool bDrawPoints, bool bDrawLines); // Function KantanChartsUMG.KantanCartesianChartBase.ConfigureSeries // (Final|Native|Public|BlueprintCallable) // @ game+0x6a34930
	void AddSeriesStyleOverride(struct FName SeriesId, struct UKantanPointStyle* PointStyle, struct FLinearColor Color); // Function KantanChartsUMG.KantanCartesianChartBase.AddSeriesStyleOverride // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x6a3b980
};

// Class KantanChartsUMG.KantanCartesianPlotBase
// Size: 0x4c0 (Inherited: 0x4c0)
struct UKantanCartesianPlotBase : UKantanCartesianChartBase {
};

// Class KantanChartsUMG.CartesianPlot
// Size: 0x4d0 (Inherited: 0x4c0)
struct UCartesianPlot : UKantanCartesianPlotBase {
	struct UObject* DataSource; // 0x4c0(0x08)
	char pad_4c8[0x8]; // 0x4c8(0x08)

	bool SetDatasource(struct UObject* InDatasource); // Function KantanChartsUMG.CartesianPlot.SetDatasource // (Final|Native|Public|BlueprintCallable) // @ game+0x6a38d80
};

// Class KantanChartsUMG.KantanChartLegend
// Size: 0x300 (Inherited: 0x1f0)
struct UKantanChartLegend : UWidget {
	struct FMargin Margins; // 0x1f0(0x10)
	struct FMargin SeriesPadding; // 0x200(0x10)
	struct FSlateBrush Background; // 0x210(0xd0)
	int32_t FontSize; // 0x2e0(0x04)
	struct TWeakObjectPtr<struct UKantanCartesianChartBase> Chart; // 0x2e4(0x08)
	char pad_2ec[0x14]; // 0x2ec(0x14)

	void SetSeriesPadding(struct FMargin& InPadding); // Function KantanChartsUMG.KantanChartLegend.SetSeriesPadding // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3da80
	void SetMargins(struct FMargin& InMargins); // Function KantanChartsUMG.KantanChartLegend.SetMargins // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3b770
	void SetFontSize(int32_t InFontSize); // Function KantanChartsUMG.KantanChartLegend.SetFontSize // (Final|Native|Public|BlueprintCallable) // @ game+0x6a38030
	void SetChart(struct UKantanCartesianChartBase* InChart); // Function KantanChartsUMG.KantanChartLegend.SetChart // (Final|Native|Public|BlueprintCallable) // @ game+0x6a38920
	void SetBackground(struct FSlateBrush& InBrush); // Function KantanChartsUMG.KantanChartLegend.SetBackground // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a42e90
};

// Class KantanChartsUMG.KantanTimeSeriesPlotBase
// Size: 0x4f0 (Inherited: 0x4c0)
struct UKantanTimeSeriesPlotBase : UKantanCartesianChartBase {
	bool bUseFixedTimeRange; // 0x4c0(0x01)
	char pad_4c1[0x3]; // 0x4c1(0x03)
	float DisplayTimeRange; // 0x4c4(0x04)
	struct FCartesianRangeBound LowerTimeBound; // 0x4c8(0x08)
	struct FCartesianRangeBound UpperTimeBound; // 0x4d0(0x08)
	struct FCartesianRangeBound LowerValueBound; // 0x4d8(0x08)
	struct FCartesianRangeBound UpperValueBound; // 0x4e0(0x08)
	bool bExtendValueRangeToZero; // 0x4e8(0x01)
	char pad_4e9[0x7]; // 0x4e9(0x07)

	void SetUpperValueBound(struct FCartesianRangeBound InUpperBound); // Function KantanChartsUMG.KantanTimeSeriesPlotBase.SetUpperValueBound // (Final|Native|Public|BlueprintCallable) // @ game+0x6a366a0
	void SetUpperTimeBound(struct FCartesianRangeBound InUpperBound); // Function KantanChartsUMG.KantanTimeSeriesPlotBase.SetUpperTimeBound // (Final|Native|Public|BlueprintCallable) // @ game+0x6a37f20
	void SetLowerValueBound(struct FCartesianRangeBound InLowerBound); // Function KantanChartsUMG.KantanTimeSeriesPlotBase.SetLowerValueBound // (Final|Native|Public|BlueprintCallable) // @ game+0x6a394f0
	void SetLowerTimeBound(struct FCartesianRangeBound InLowerBound); // Function KantanChartsUMG.KantanTimeSeriesPlotBase.SetLowerTimeBound // (Final|Native|Public|BlueprintCallable) // @ game+0x6a3a1f0
	void SetFixedTimeRange(bool bEnableFixedRange, float TimeRange); // Function KantanChartsUMG.KantanTimeSeriesPlotBase.SetFixedTimeRange // (Final|Native|Public|BlueprintCallable) // @ game+0x6a3a9f0
};

// Class KantanChartsUMG.SimpleBarChart
// Size: 0x460 (Inherited: 0x440)
struct USimpleBarChart : UKantanBarChartBase {
	char pad_440[0x20]; // 0x440(0x20)

	void BP_UpdateCategoryValue(struct FName ID, float Value, bool& bSuccess); // Function KantanChartsUMG.SimpleBarChart.BP_UpdateCategoryValue // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a39e30
	void BP_RemoveCategory(struct FName ID, bool& bSuccess); // Function KantanChartsUMG.SimpleBarChart.BP_RemoveCategory // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3c5d0
	void BP_RemoveAllCategories(); // Function KantanChartsUMG.SimpleBarChart.BP_RemoveAllCategories // (Final|Native|Public|BlueprintCallable) // @ game+0x6a3d9b0
	void BP_AddCategoryWithId(struct FName ID, struct FText Name, bool& bSuccess); // Function KantanChartsUMG.SimpleBarChart.BP_AddCategoryWithId // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a40ec0
	void BP_AddCategory(struct FText Name, struct FName& CatId); // Function KantanChartsUMG.SimpleBarChart.BP_AddCategory // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3b500
};

// Class KantanChartsUMG.SimpleCartesianPlot
// Size: 0x4e0 (Inherited: 0x4c0)
struct USimpleCartesianPlot : UKantanCartesianPlotBase {
	char pad_4c0[0x20]; // 0x4c0(0x20)

	void BP_RemoveSeries(struct FName ID, bool& bSuccess); // Function KantanChartsUMG.SimpleCartesianPlot.BP_RemoveSeries // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3a530
	void BP_RemoveAllSeries(); // Function KantanChartsUMG.SimpleCartesianPlot.BP_RemoveAllSeries // (Final|Native|Public|BlueprintCallable) // @ game+0x6a3dd60
	void BP_AddSeriesWithId(bool& bSuccess, struct FName ID, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines); // Function KantanChartsUMG.SimpleCartesianPlot.BP_AddSeriesWithId // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a41450
	void BP_AddSeries(struct FName& SeriesId, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines); // Function KantanChartsUMG.SimpleCartesianPlot.BP_AddSeries // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a36fe0
	void BP_AddDatapoint(struct FName SeriesId, struct FVector2D& Point, bool& bSuccess); // Function KantanChartsUMG.SimpleCartesianPlot.BP_AddDatapoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6a389c0
};

// Class KantanChartsUMG.SimpleTimeSeriesPlot
// Size: 0x510 (Inherited: 0x4f0)
struct USimpleTimeSeriesPlot : UKantanTimeSeriesPlotBase {
	char pad_4f0[0x20]; // 0x4f0(0x20)

	void BP_SetDatapointLimit(int32_t Limit); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_SetDatapointLimit // (Final|Native|Public|BlueprintCallable) // @ game+0x6a420d0
	void BP_RemoveSeries(struct FName ID, bool& bSuccess); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_RemoveSeries // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a39130
	void BP_RemoveAllSeries(); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_RemoveAllSeries // (Final|Native|Public|BlueprintCallable) // @ game+0x6a34410
	void BP_AddSeriesWithId(bool& bSuccess, struct FName ID, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddSeriesWithId // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a3d170
	void BP_AddSeries(struct FName& SeriesId, struct FText Name, bool bEnabled, bool bShowPoints, bool bShowLines); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddSeries // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a410e0
	void BP_AddDatapointNow(struct FName SeriesId, float Value, bool& bSuccess); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddDatapointNow // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6a39fc0
	void BP_AddDatapoint(struct FName SeriesId, struct FVector2D& Point, bool& bSuccess); // Function KantanChartsUMG.SimpleTimeSeriesPlot.BP_AddDatapoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x6a40d60
};

// Class KantanChartsUMG.TimeSeriesPlot
// Size: 0x500 (Inherited: 0x4f0)
struct UTimeSeriesPlot : UKantanTimeSeriesPlotBase {
	struct UObject* DataSource; // 0x4f0(0x08)
	char pad_4f8[0x8]; // 0x4f8(0x08)

	bool SetDatasource(struct UObject* InDatasource); // Function KantanChartsUMG.TimeSeriesPlot.SetDatasource // (Final|Native|Public|BlueprintCallable) // @ game+0x6a437a0
};

