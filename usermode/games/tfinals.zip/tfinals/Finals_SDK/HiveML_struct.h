// Enum HiveML.EAgentResetFlags
enum class EAgentResetFlags : uint8_t {
	None = 0,
	HardReset = 1,
	SoftReset = 2,
	EAgentResetFlags_MAX = 3
};

// Enum HiveML.EHiveEpisodeState
enum class EHiveEpisodeState : uint8_t {
	EPISODE_STATE_RUNNING = 0,
	EPISODE_STATE_INTERRUPTED = 1,
	EPISODE_STATE_TERMINAL = 2,
	EPISODE_STATE_INITIAL = 3,
	EPISODE_STATE_MAX = 4
};

// Enum HiveML.EHiveComputeType
enum class EHiveComputeType : uint8_t {
	COMPUTE_TYPE_CPU = 0,
	COMPUTE_TYPE_GPU = 1,
	COMPUTE_TYPE_GPU_LARGE = 2,
	COMPUTE_TYPE_GPU_L4 = 3,
	COMPUTE_TYPE_GPU_TEST = 4,
	COMPUTE_TYPE_UNKNOWN = 255,
	COMPUTE_TYPE_MAX = 256
};

// Enum HiveML.EHiveServiceClass
enum class EHiveServiceClass : uint8_t {
	SERVICE_CLASS_UNSPECIFIED = 0,
	SERVICE_CLASS_STANDARD = 1,
	SERVICE_CLASS_SWEEP = 2,
	SERVICE_CLASS_MAX = 3
};

// Enum HiveML.EHiveProviderKind
enum class EHiveProviderKind : uint8_t {
	PROVIDER_KIND_WORKER = 0,
	PROVIDER_KIND_BRAIN = 1,
	PROVIDER_KIND_MAX = 2
};

// Enum HiveML.EHiveProtectionFilter
enum class EHiveProtectionFilter : uint8_t {
	PROTECTION_FILTER_UNSPECIFIED = 0,
	PROTECTION_FILTER_PROTECTED = 1,
	PROTECTION_FILTER_UNPROTECTED = 2,
	PROTECTION_FILTER_MAX = 3
};

// Enum HiveML.EHiveTerminationReason
enum class EHiveTerminationReason : uint8_t {
	TERMINATION_REASON_UNSPECIFIED = 0,
	TERMINATION_REASON_INTERRUPTED = 1,
	TERMINATION_REASON_TERMINAL = 2,
	TERMINATION_REASON_MAX = 3
};

// Enum HiveML.EMLExecutionMode
enum class EMLExecutionMode : uint8_t {
	Training = 0,
	Inference = 1,
	EMLExecutionMode_MAX = 2
};

// Enum HiveML.EMLAgentMode
enum class EMLAgentMode : uint8_t {
	Training = 0,
	Validation = 1,
	EMLAgentMode_MAX = 2
};

// Enum HiveML.EHiveTerminalReason
enum class EHiveTerminalReason : uint8_t {
	NOT_TERMINAL = 0,
	TERMINAL = 1,
	INTERRUPTED = 2,
	EHiveTerminalReason_MAX = 3
};

// ScriptStruct HiveML.ProtoMessageBP
// Size: 0x08 (Inherited: 0x00)
struct FProtoMessageBP {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct HiveML.HiveMetaData
// Size: 0xa8 (Inherited: 0x08)
struct FHiveMetaData : FProtoMessageBP {
	struct TMap<struct FString, float> Info; // 0x08(0x50)
	struct TMap<struct FString, struct FHiveFloatList> InfoLists; // 0x58(0x50)
};

// ScriptStruct HiveML.HiveFloatList
// Size: 0x18 (Inherited: 0x08)
struct FHiveFloatList : FProtoMessageBP {
	struct TArray<float> Values; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveStatus
// Size: 0x30 (Inherited: 0x08)
struct FHiveStatus : FProtoMessageBP {
	bool bOk; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	int32_t ErrorCode; // 0x0c(0x04)
	struct FString ErrorMsg; // 0x10(0x10)
	struct FString Msg; // 0x20(0x10)
};

// ScriptStruct HiveML.HiveGetCheckpointResponse
// Size: 0x58 (Inherited: 0x08)
struct FHiveGetCheckpointResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FString CheckpointDownloadUrl; // 0x38(0x10)
	struct FString ConfigurationId; // 0x48(0x10)
};

// ScriptStruct HiveML.HiveChunkResponse
// Size: 0x50 (Inherited: 0x08)
struct FHiveChunkResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	int32_t ChunkIndex; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
	struct TArray<char> Data; // 0x40(0x10)
};

// ScriptStruct HiveML.HiveEndpointResponse
// Size: 0x60 (Inherited: 0x08)
struct FHiveEndpointResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	int32_t Port; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
	struct FString Host; // 0x40(0x10)
	struct FString RunId; // 0x50(0x10)
};

// ScriptStruct HiveML.HiveExperimentList
// Size: 0x48 (Inherited: 0x08)
struct FHiveExperimentList : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveExperiment> Experiments; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveExperiment
// Size: 0xe0 (Inherited: 0x08)
struct FHiveExperiment : FProtoMessageBP {
	struct FString ExperimentName; // 0x08(0x10)
	struct FString RunId; // 0x18(0x10)
	struct FString BuildId; // 0x28(0x10)
	struct TArray<struct FString> ConfigurationIds; // 0x38(0x10)
	struct TArray<struct FString> Configurations; // 0x48(0x10)
	struct FString CogCommit; // 0x58(0x10)
	struct FString CogImage; // 0x68(0x10)
	enum class EHiveComputeType ComputeType; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct FString ExperimentStatus; // 0x80(0x10)
	struct FString StartedAt; // 0x90(0x10)
	struct FString EndedAt; // 0xa0(0x10)
	int64_t WorkerCount; // 0xb0(0x08)
	int64_t MaxDuration; // 0xb8(0x08)
	struct FString ClonedFrom; // 0xc0(0x10)
	struct TArray<struct FString> Events; // 0xd0(0x10)
};

// ScriptStruct HiveML.HiveSerializedModel
// Size: 0x68 (Inherited: 0x08)
struct FHiveSerializedModel : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FString CheckpointName; // 0x38(0x10)
	int64_t Timestamp; // 0x48(0x08)
	struct FString ModelFormat; // 0x50(0x10)
	int32_t ChunkCount; // 0x60(0x04)
	int32_t TotalBytes; // 0x64(0x04)
};

// ScriptStruct HiveML.HiveBuildIdList
// Size: 0x48 (Inherited: 0x08)
struct FHiveBuildIdList : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveBuild> Builds; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveBuild
// Size: 0x40 (Inherited: 0x08)
struct FHiveBuild : FProtoMessageBP {
	struct FString ID; // 0x08(0x10)
	struct FString Label; // 0x18(0x10)
	int64_t CreatedAt; // 0x28(0x08)
	struct FString Commit; // 0x30(0x10)
};

// ScriptStruct HiveML.HiveConfigurationDataResponse
// Size: 0x70 (Inherited: 0x08)
struct FHiveConfigurationDataResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveConfiguration Configuration; // 0x38(0x28)
	struct FString RunId; // 0x60(0x10)
};

// ScriptStruct HiveML.HiveConfiguration
// Size: 0x28 (Inherited: 0x08)
struct FHiveConfiguration : FProtoMessageBP {
	struct FString Name; // 0x08(0x10)
	struct FString JsonBlob; // 0x18(0x10)
};

// ScriptStruct HiveML.HiveCompressExperimentResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveCompressExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveCompressRunResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveCompressRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveCompressTrialResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveCompressTrialResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveContinueRunResponse
// Size: 0xc0 (Inherited: 0x08)
struct FHiveContinueRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveRun Run; // 0x38(0x88)
};

// ScriptStruct HiveML.HiveRun
// Size: 0x88 (Inherited: 0x08)
struct FHiveRun : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	int64_t TrialId; // 0x10(0x08)
	struct FString ArtifactLocation; // 0x18(0x10)
	int64_t StartedAtUnix; // 0x28(0x08)
	int64_t EndedAtUnix; // 0x30(0x08)
	int64_t UpdatedAtUnix; // 0x38(0x08)
	bool bIsInfer; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	int64_t InferSource; // 0x48(0x08)
	bool bIsBeta; // 0x50(0x01)
	bool bIsProtected; // 0x51(0x01)
	bool bIsCompressed; // 0x52(0x01)
	char pad_53[0x5]; // 0x53(0x05)
	struct FString Status; // 0x58(0x10)
	int64_t SequenceNumber; // 0x68(0x08)
	enum class EHiveServiceClass ServiceClass; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	struct TArray<struct FHiveEvent> Events; // 0x78(0x10)
};

// ScriptStruct HiveML.HiveEvent
// Size: 0x40 (Inherited: 0x08)
struct FHiveEvent : FProtoMessageBP {
	struct FString Source; // 0x08(0x10)
	struct FString Reason; // 0x18(0x10)
	struct FString Detail; // 0x28(0x10)
	int64_t Timestamp; // 0x38(0x08)
};

// ScriptStruct HiveML.HiveCreateExperimentResponse
// Size: 0x88 (Inherited: 0x08)
struct FHiveCreateExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveExperimentV2 Experiment; // 0x38(0x50)
};

// ScriptStruct HiveML.HiveExperimentV2
// Size: 0x50 (Inherited: 0x08)
struct FHiveExperimentV2 : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	struct FString Name; // 0x10(0x10)
	struct FString Description; // 0x20(0x10)
	bool bIsProtected; // 0x30(0x01)
	bool bIsGcsStorage; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
	int64_t UnixTimestamp; // 0x38(0x08)
	struct TArray<struct FHiveEvent> Events; // 0x40(0x10)
};

// ScriptStruct HiveML.HiveCreateRunResponse
// Size: 0xc0 (Inherited: 0x08)
struct FHiveCreateRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveRun Run; // 0x38(0x88)
};

// ScriptStruct HiveML.HiveCreateTrialResponse
// Size: 0x100 (Inherited: 0x08)
struct FHiveCreateTrialResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveTrial Trial; // 0x38(0xc8)
};

// ScriptStruct HiveML.HiveTrial
// Size: 0xc8 (Inherited: 0x08)
struct FHiveTrial : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	int64_t ExperimentId; // 0x10(0x08)
	struct FString Name; // 0x18(0x10)
	struct FString Description; // 0x28(0x10)
	bool bIsProtected; // 0x38(0x01)
	enum class EHiveServiceClass ServiceClass; // 0x39(0x01)
	char pad_3a[0x6]; // 0x3a(0x06)
	struct FString Configuration; // 0x40(0x10)
	int64_t DurationSeconds; // 0x50(0x08)
	enum class EHiveComputeType ComputeType; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct FString CogCommitOverride; // 0x60(0x10)
	struct FString CogImageOverride; // 0x70(0x10)
	int64_t ClonedFrom; // 0x80(0x08)
	struct FString WorkerBuildId; // 0x88(0x10)
	struct FString BrainBuildId; // 0x98(0x10)
	int64_t WorkerCount; // 0xa8(0x08)
	int64_t UnixTimestamp; // 0xb0(0x08)
	struct TArray<struct FHiveEvent> Events; // 0xb8(0x10)
};

// ScriptStruct HiveML.HiveDeleteExperimentResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveDeleteExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveDeleteRunResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveDeleteRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveDeleteTrialResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveDeleteTrialResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveGetCheckpointChunkResponse
// Size: 0x50 (Inherited: 0x08)
struct FHiveGetCheckpointChunkResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	int32_t ChunkIndex; // 0x38(0x04)
	char pad_3c[0x4]; // 0x3c(0x04)
	struct TArray<char> Data; // 0x40(0x10)
};

// ScriptStruct HiveML.HiveGetExperimentResponse
// Size: 0x88 (Inherited: 0x08)
struct FHiveGetExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveExperimentV2 Experiment; // 0x38(0x50)
};

// ScriptStruct HiveML.HiveGetExperimentsResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveGetExperimentsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveExperimentV2> Experiments; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveGetRunCheckpointResponse
// Size: 0x68 (Inherited: 0x08)
struct FHiveGetRunCheckpointResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FString CheckpointName; // 0x38(0x10)
	int64_t Timestamp; // 0x48(0x08)
	struct FString ModelFormat; // 0x50(0x10)
	int32_t ChunkCount; // 0x60(0x04)
	int32_t TotalBytes; // 0x64(0x04)
};

// ScriptStruct HiveML.HiveGetRunResponse
// Size: 0xc0 (Inherited: 0x08)
struct FHiveGetRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveRun Run; // 0x38(0x88)
};

// ScriptStruct HiveML.HiveGetRunsResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveGetRunsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveRun> Runs; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveGetTrialResponse
// Size: 0x100 (Inherited: 0x08)
struct FHiveGetTrialResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveTrial Trial; // 0x38(0xc8)
};

// ScriptStruct HiveML.HiveGetTrialsResponse
// Size: 0x58 (Inherited: 0x08)
struct FHiveGetTrialsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveTrial> Trials; // 0x38(0x10)
	struct TArray<struct FHiveTrial> Linked; // 0x48(0x10)
};

// ScriptStruct HiveML.HiveLinkTrialsToExperimentResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveLinkTrialsToExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveListBuildProvidersResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveListBuildProvidersResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveProviderInfo> Providers; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveProviderInfo
// Size: 0x30 (Inherited: 0x08)
struct FHiveProviderInfo : FProtoMessageBP {
	struct FString App; // 0x08(0x10)
	struct FString Label; // 0x18(0x10)
	enum class EHiveProviderKind Kind; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct HiveML.HiveListBuildsResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveListBuildsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveBuild> Builds; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveProtectExperimentResponse
// Size: 0x88 (Inherited: 0x08)
struct FHiveProtectExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveExperimentV2 Experiment; // 0x38(0x50)
};

// ScriptStruct HiveML.HiveProtectRunResponse
// Size: 0xc0 (Inherited: 0x08)
struct FHiveProtectRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveRun Run; // 0x38(0x88)
};

// ScriptStruct HiveML.HiveProtectTrialResponse
// Size: 0x100 (Inherited: 0x08)
struct FHiveProtectTrialResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveTrial Trial; // 0x38(0xc8)
};

// ScriptStruct HiveML.HiveSearchAuthorsResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveSearchAuthorsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FString> Emails; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveSearchExperimentsResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveSearchExperimentsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveExperimentV2> Experiments; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveStopRunResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveStopRunResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveUnlinkTrialsFromExperimentResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveUnlinkTrialsFromExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveUpdateExperimentResponse
// Size: 0x88 (Inherited: 0x08)
struct FHiveUpdateExperimentResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveExperimentV2 Experiment; // 0x38(0x50)
};

// ScriptStruct HiveML.HiveUpdateTrialResponse
// Size: 0x100 (Inherited: 0x08)
struct FHiveUpdateTrialResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveTrial Trial; // 0x38(0xc8)
};

// ScriptStruct HiveML.HiveResponseGroup
// Size: 0x90 (Inherited: 0x08)
struct FHiveResponseGroup : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	int64_t Handle; // 0x38(0x08)
	struct TMap<int64_t, struct FHiveResponse> Responses; // 0x40(0x50)
};

// ScriptStruct HiveML.HiveResponse
// Size: 0xc0 (Inherited: 0x08)
struct FHiveResponse : FProtoMessageBP {
	float Value; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct TArray<float> Actions; // 0x10(0x10)
	struct TMap<struct FString, struct FHiveFloatList> ListData; // 0x20(0x50)
	struct TMap<struct FString, float> ScalarData; // 0x70(0x50)
};

// ScriptStruct HiveML.HiveMetaDataResponse
// Size: 0xe0 (Inherited: 0x08)
struct FHiveMetaDataResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct FHiveMetaData MetaData; // 0x38(0xa8)
};

// ScriptStruct HiveML.HiveCheckpointsResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveCheckpointsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveSerializedModel> Checkpoints; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveDeleteCheckpointResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveDeleteCheckpointResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveExportCheckpointResponse
// Size: 0x48 (Inherited: 0x08)
struct FHiveExportCheckpointResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveCheckpointInfo> Checkpoints; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveCheckpointInfo
// Size: 0x38 (Inherited: 0x08)
struct FHiveCheckpointInfo : FProtoMessageBP {
	struct FString Name; // 0x08(0x10)
	struct FString Handle; // 0x18(0x10)
	int64_t Timestamp; // 0x28(0x08)
	int32_t ChunkCount; // 0x30(0x04)
	int32_t TotalBytes; // 0x34(0x04)
};

// ScriptStruct HiveML.HiveInitializeResponse
// Size: 0x58 (Inherited: 0x08)
struct FHiveInitializeResponse : FProtoMessageBP {
	struct FHiveResult Result; // 0x08(0x30)
	struct FHiveServerInfo Server; // 0x38(0x18)
	int32_t IdentityPrefix; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct HiveML.HiveServerInfo
// Size: 0x18 (Inherited: 0x08)
struct FHiveServerInfo : FProtoMessageBP {
	struct FString HostName; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveResult
// Size: 0x30 (Inherited: 0x08)
struct FHiveResult : FProtoMessageBP {
	char pad_8[0x28]; // 0x08(0x28)
};

// ScriptStruct HiveML.HivePushEpisodeResponse
// Size: 0x38 (Inherited: 0x08)
struct FHivePushEpisodeResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveSetValidationMetricsResponse
// Size: 0x38 (Inherited: 0x08)
struct FHiveSetValidationMetricsResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
};

// ScriptStruct HiveML.HiveEmptyResponse
// Size: 0x08 (Inherited: 0x08)
struct FHiveEmptyResponse : FProtoMessageBP {
};

// ScriptStruct HiveML.HivePingResponse
// Size: 0x10 (Inherited: 0x08)
struct FHivePingResponse : FProtoMessageBP {
	int64_t Timestamp; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveConnectAsBrainResponse
// Size: 0x50 (Inherited: 0x08)
struct FHiveConnectAsBrainResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	int64_t RunId; // 0x38(0x08)
	struct FString Json; // 0x40(0x10)
};

// ScriptStruct HiveML.HiveConnectAsWorkerResponse
// Size: 0x70 (Inherited: 0x08)
struct FHiveConnectAsWorkerResponse : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	int64_t RunId; // 0x38(0x08)
	struct FString Json; // 0x40(0x10)
	struct FHiveEndpoint Endpoint; // 0x50(0x20)
};

// ScriptStruct HiveML.HiveEndpoint
// Size: 0x20 (Inherited: 0x08)
struct FHiveEndpoint : FProtoMessageBP {
	struct FString Host; // 0x08(0x10)
	int32_t Port; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct HiveML.ObservationSetEntry
// Size: 0x48 (Inherited: 0x00)
struct FObservationSetEntry {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct HiveML.MLBlackboard
// Size: 0x78 (Inherited: 0x00)
struct FMLBlackboard {
	float TimeAlive; // 0x00(0x04)
	int32_t ActionsTaken; // 0x04(0x04)
	float AccumulatedReward; // 0x08(0x04)
	float CurrentValue; // 0x0c(0x04)
	float SentAtTime; // 0x10(0x04)
	int32_t SentAtTick; // 0x14(0x04)
	float LastReceivedAtTime; // 0x18(0x04)
	int32_t AccumulatedWaitTime; // 0x1c(0x04)
	bool bAwaitingAction; // 0x20(0x01)
	bool bIsInitial; // 0x21(0x01)
	bool bIsDecisionStep; // 0x22(0x01)
	enum class EHiveTerminalReason IsTerminal; // 0x23(0x01)
	enum class EAgentResetFlags ResetFlags; // 0x24(0x01)
	char pad_25[0x53]; // 0x25(0x53)
};

// ScriptStruct HiveML.HiveRpcContext
// Size: 0x10 (Inherited: 0x00)
struct FHiveRpcContext {
	struct FString BearerToken; // 0x00(0x10)
};

// ScriptStruct HiveML.HivePingRequest
// Size: 0x10 (Inherited: 0x08)
struct FHivePingRequest : FProtoMessageBP {
	int64_t Timestamp; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveEmptyRequest
// Size: 0x08 (Inherited: 0x08)
struct FHiveEmptyRequest : FProtoMessageBP {
};

// ScriptStruct HiveML.HiveGetCheckpointRequest
// Size: 0x38 (Inherited: 0x08)
struct FHiveGetCheckpointRequest : FProtoMessageBP {
	struct FString ExperimentName; // 0x08(0x10)
	struct FString RunId; // 0x18(0x10)
	struct FString CheckpointIndex; // 0x28(0x10)
};

// ScriptStruct HiveML.HiveGetExperimentCheckpointRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveGetExperimentCheckpointRequest : FProtoMessageBP {
	struct FString RunId; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveChunkRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveChunkRequest : FProtoMessageBP {
	struct FString ResourceName; // 0x08(0x10)
	int32_t ChunkIndex; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct HiveML.HiveSelector
// Size: 0x28 (Inherited: 0x08)
struct FHiveSelector : FProtoMessageBP {
	struct FString Name; // 0x08(0x10)
	struct FString Value; // 0x18(0x10)
};

// ScriptStruct HiveML.HiveQueryRequest
// Size: 0x28 (Inherited: 0x08)
struct FHiveQueryRequest : FProtoMessageBP {
	struct FString App; // 0x08(0x10)
	struct TArray<struct FHiveSelector> Selectors; // 0x18(0x10)
};

// ScriptStruct HiveML.HiveDeployRequest
// Size: 0x90 (Inherited: 0x08)
struct FHiveDeployRequest : FProtoMessageBP {
	struct FString BuildId; // 0x08(0x10)
	struct TArray<struct FString> Configurations; // 0x18(0x10)
	struct FString ExperimentName; // 0x28(0x10)
	int64_t TrainingDurationInSeconds; // 0x38(0x08)
	int64_t WorkerCount; // 0x40(0x08)
	struct FString CogCommit; // 0x48(0x10)
	struct FString CogImage; // 0x58(0x10)
	enum class EHiveComputeType ComputeType; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FString ClonedFrom; // 0x70(0x10)
	struct FString Namespace; // 0x80(0x10)
};

// ScriptStruct HiveML.HiveStopRequest
// Size: 0x38 (Inherited: 0x08)
struct FHiveStopRequest : FProtoMessageBP {
	struct FString BuildId; // 0x08(0x10)
	struct FString ExperimentName; // 0x18(0x10)
	struct FString RunId; // 0x28(0x10)
};

// ScriptStruct HiveML.HiveExperimentQuery
// Size: 0x18 (Inherited: 0x08)
struct FHiveExperimentQuery : FProtoMessageBP {
	struct FString RunId; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveConfigurationDataRequest
// Size: 0x28 (Inherited: 0x08)
struct FHiveConfigurationDataRequest : FProtoMessageBP {
	struct FString RunId; // 0x08(0x10)
	struct FString ConfigurationName; // 0x18(0x10)
};

// ScriptStruct HiveML.HiveEndpointRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveEndpointRequest : FProtoMessageBP {
	struct FString RunId; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveFilter
// Size: 0x68 (Inherited: 0x08)
struct FHiveFilter : FProtoMessageBP {
	struct FString AuthorEmail; // 0x08(0x10)
	struct FString Name; // 0x18(0x10)
	int64_t Offset; // 0x28(0x08)
	int64_t Limit; // 0x30(0x08)
	bool bReverseOrder; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
	struct TArray<enum class EHiveServiceClass> ServiceClasses; // 0x40(0x10)
	struct TArray<struct FString> Phases; // 0x50(0x10)
	enum class EHiveProtectionFilter ProtectionFilter; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct HiveML.HiveGetExperimentsRequest
// Size: 0x70 (Inherited: 0x08)
struct FHiveGetExperimentsRequest : FProtoMessageBP {
	struct FHiveFilter Filter; // 0x08(0x68)
};

// ScriptStruct HiveML.HiveGetExperimentRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveGetExperimentRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveCreateExperimentRequest
// Size: 0x40 (Inherited: 0x08)
struct FHiveCreateExperimentRequest : FProtoMessageBP {
	struct FString Name; // 0x08(0x10)
	struct FString Description; // 0x18(0x10)
	bool bProtected; // 0x28(0x01)
	bool bUseGcsStore; // 0x29(0x01)
	char pad_2a[0x6]; // 0x2a(0x06)
	struct FString OverrideUser; // 0x30(0x10)
};

// ScriptStruct HiveML.HiveUpdateExperimentRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveUpdateExperimentRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	struct FString Description; // 0x10(0x10)
};

// ScriptStruct HiveML.HiveProtectExperimentRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveProtectExperimentRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	bool bProtected; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct HiveML.HiveDeleteExperimentRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveDeleteExperimentRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveCompressExperimentRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveCompressExperimentRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveGetTrialsRequest
// Size: 0x80 (Inherited: 0x08)
struct FHiveGetTrialsRequest : FProtoMessageBP {
	struct TArray<int64_t> Experiments; // 0x08(0x10)
	struct FHiveFilter Filter; // 0x18(0x68)
};

// ScriptStruct HiveML.HiveGetTrialRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveGetTrialRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveCreateTrialRequest
// Size: 0xb8 (Inherited: 0x08)
struct FHiveCreateTrialRequest : FProtoMessageBP {
	int64_t ExperimentId; // 0x08(0x08)
	struct FString Name; // 0x10(0x10)
	struct FString Description; // 0x20(0x10)
	struct FString Configuration; // 0x30(0x10)
	int64_t DurationSeconds; // 0x40(0x08)
	enum class EHiveComputeType ComputeType; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FString CogCommitOverride; // 0x50(0x10)
	struct FString CogImageOverride; // 0x60(0x10)
	struct FString BrainBuildId; // 0x70(0x10)
	int64_t ClonedFrom; // 0x80(0x08)
	struct FString WorkerBuildId; // 0x88(0x10)
	int64_t WorkerCount; // 0x98(0x08)
	enum class EHiveServiceClass ServiceClass; // 0xa0(0x01)
	char pad_a1[0x7]; // 0xa1(0x07)
	struct FString OverrideUser; // 0xa8(0x10)
};

// ScriptStruct HiveML.HiveDeleteTrialRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveDeleteTrialRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveUpdateTrialRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveUpdateTrialRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	struct FString Description; // 0x10(0x10)
};

// ScriptStruct HiveML.HiveCompressTrialRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveCompressTrialRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveProtectTrialRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveProtectTrialRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	bool bProtected; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct HiveML.HiveGetRunCheckpointRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveGetRunCheckpointRequest : FProtoMessageBP {
	int64_t RunId; // 0x08(0x08)
	int64_t CheckpointId; // 0x10(0x08)
};

// ScriptStruct HiveML.HiveGetCheckpointChunkRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveGetCheckpointChunkRequest : FProtoMessageBP {
	struct FString ResourceName; // 0x08(0x10)
	int32_t ChunkIndex; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct HiveML.HiveGetRunsRequest
// Size: 0x80 (Inherited: 0x08)
struct FHiveGetRunsRequest : FProtoMessageBP {
	struct TArray<int64_t> Trials; // 0x08(0x10)
	struct FHiveFilter Filter; // 0x18(0x68)
};

// ScriptStruct HiveML.HiveGetRunRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveGetRunRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveCreateRunRequest
// Size: 0x30 (Inherited: 0x08)
struct FHiveCreateRunRequest : FProtoMessageBP {
	int64_t TrialId; // 0x08(0x08)
	bool bIsInfer; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	int64_t InferSource; // 0x18(0x08)
	struct FString OverrideUser; // 0x20(0x10)
};

// ScriptStruct HiveML.HiveStopRunRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveStopRunRequest : FProtoMessageBP {
	int64_t RunId; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveContinueRunRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveContinueRunRequest : FProtoMessageBP {
	int64_t RunId; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveDeleteRunRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveDeleteRunRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveCompressRunRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveCompressRunRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveProtectRunRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveProtectRunRequest : FProtoMessageBP {
	int64_t ID; // 0x08(0x08)
	bool bProtected; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct HiveML.HiveListBuildProvidersRequest
// Size: 0x08 (Inherited: 0x08)
struct FHiveListBuildProvidersRequest : FProtoMessageBP {
};

// ScriptStruct HiveML.HiveListBuildsRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveListBuildsRequest : FProtoMessageBP {
	struct FString App; // 0x08(0x10)
	enum class EHiveProviderKind Kind; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct HiveML.HiveLinkTrialsToExperimentRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveLinkTrialsToExperimentRequest : FProtoMessageBP {
	int64_t ExperimentId; // 0x08(0x08)
	struct TArray<int64_t> TrialIds; // 0x10(0x10)
};

// ScriptStruct HiveML.HiveUnlinkTrialsFromExperimentRequest
// Size: 0x20 (Inherited: 0x08)
struct FHiveUnlinkTrialsFromExperimentRequest : FProtoMessageBP {
	struct TArray<int64_t> TrialIds; // 0x08(0x10)
	int64_t ExperimentId; // 0x18(0x08)
};

// ScriptStruct HiveML.HiveSearchAuthorsRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveSearchAuthorsRequest : FProtoMessageBP {
	struct FString EmailPrefix; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveSearchExperimentsRequest
// Size: 0x18 (Inherited: 0x08)
struct FHiveSearchExperimentsRequest : FProtoMessageBP {
	struct FString NamePrefix; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveObservation
// Size: 0x1a8 (Inherited: 0x08)
struct FHiveObservation : FProtoMessageBP {
	struct TMap<struct FString, float> Rewards; // 0x08(0x50)
	float Reward; // 0x58(0x04)
	enum class EHiveEpisodeState EpisodeState; // 0x5c(0x01)
	bool bDone; // 0x5d(0x01)
	bool bInitial; // 0x5e(0x01)
	char pad_5f[0x1]; // 0x5f(0x01)
	struct FHiveMetaData MetaData; // 0x60(0xa8)
	struct TMap<struct FString, struct FHiveFloatList> ListData; // 0x108(0x50)
	struct TMap<struct FString, float> ScalarData; // 0x158(0x50)
};

// ScriptStruct HiveML.HiveObservationGroup
// Size: 0x60 (Inherited: 0x08)
struct FHiveObservationGroup : FProtoMessageBP {
	int64_t Handle; // 0x08(0x08)
	struct TMap<int64_t, struct FHiveObservation> Observations; // 0x10(0x50)
};

// ScriptStruct HiveML.HiveListCheckpointsParams
// Size: 0x08 (Inherited: 0x08)
struct FHiveListCheckpointsParams : FProtoMessageBP {
};

// ScriptStruct HiveML.HiveCreateCheckpointParams
// Size: 0x08 (Inherited: 0x08)
struct FHiveCreateCheckpointParams : FProtoMessageBP {
};

// ScriptStruct HiveML.HiveCheckpointHandle
// Size: 0x18 (Inherited: 0x08)
struct FHiveCheckpointHandle : FProtoMessageBP {
	struct FString CheckpointName; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveGetCheckpointParams
// Size: 0x18 (Inherited: 0x08)
struct FHiveGetCheckpointParams : FProtoMessageBP {
	struct FString DummyPleaseIgnore; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveMetricsQuery
// Size: 0x28 (Inherited: 0x08)
struct FHiveMetricsQuery : FProtoMessageBP {
	struct FString Filter; // 0x08(0x10)
	struct TArray<struct FString> Keys; // 0x18(0x10)
};

// ScriptStruct HiveML.HiveMetricsMessage
// Size: 0xb0 (Inherited: 0x08)
struct FHiveMetricsMessage : FProtoMessageBP {
	struct FHiveMetaData MetaData; // 0x08(0xa8)
};

// ScriptStruct HiveML.HiveMetadataMessage
// Size: 0x58 (Inherited: 0x08)
struct FHiveMetadataMessage : FProtoMessageBP {
	struct TMap<struct FString, struct FString> MetaData; // 0x08(0x50)
};

// ScriptStruct HiveML.HiveExperience
// Size: 0x280 (Inherited: 0x08)
struct FHiveExperience : FProtoMessageBP {
	struct FHiveObservation Observation; // 0x08(0x1a8)
	struct FHiveResponse Response; // 0x1b0(0xc0)
	struct TArray<float> Actions; // 0x270(0x10)
};

// ScriptStruct HiveML.HiveExperienceTimestep
// Size: 0x58 (Inherited: 0x08)
struct FHiveExperienceTimestep : FProtoMessageBP {
	struct TMap<int64_t, struct FHiveExperience> Experiences; // 0x08(0x50)
};

// ScriptStruct HiveML.HiveAugmentedExperiences
// Size: 0x18 (Inherited: 0x08)
struct FHiveAugmentedExperiences : FProtoMessageBP {
	struct TArray<struct FHiveExperienceTimestep> Timesteps; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveClientInfo
// Size: 0x18 (Inherited: 0x08)
struct FHiveClientInfo : FProtoMessageBP {
	struct FString HostName; // 0x08(0x10)
};

// ScriptStruct HiveML.HiveInitializeRequest
// Size: 0x30 (Inherited: 0x08)
struct FHiveInitializeRequest : FProtoMessageBP {
	struct FHiveClientInfo Client; // 0x08(0x18)
	struct FString DerivedConfig; // 0x20(0x10)
};

// ScriptStruct HiveML.HiveSuccess
// Size: 0x08 (Inherited: 0x08)
struct FHiveSuccess : FProtoMessageBP {
};

// ScriptStruct HiveML.HiveError
// Size: 0x20 (Inherited: 0x08)
struct FHiveError : FProtoMessageBP {
	int32_t Code; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FString Msg; // 0x10(0x10)
};

// ScriptStruct HiveML.HiveTimestep
// Size: 0x1f0 (Inherited: 0x08)
struct FHiveTimestep : FProtoMessageBP {
	struct TMap<struct FString, struct FHiveFloatList> ListData; // 0x08(0x50)
	struct TMap<struct FString, float> ScalarData; // 0x58(0x50)
	struct TMap<struct FString, float> Rewards; // 0xa8(0x50)
	struct FHiveMetaData MetaData; // 0xf8(0xa8)
	struct TMap<struct FString, struct FHiveFloatList> Outputs; // 0x1a0(0x50)
};

// ScriptStruct HiveML.HiveEpisode
// Size: 0x28 (Inherited: 0x08)
struct FHiveEpisode : FProtoMessageBP {
	int64_t AgentId; // 0x08(0x08)
	enum class EHiveTerminationReason TerminationReason; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TArray<struct FHiveTimestep> Timesteps; // 0x18(0x10)
};

// ScriptStruct HiveML.HivePushEpisodeRequest
// Size: 0x38 (Inherited: 0x08)
struct FHivePushEpisodeRequest : FProtoMessageBP {
	struct FHiveEpisode Episode; // 0x08(0x28)
	bool bContainsOnlyMetadata; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct HiveML.HiveExportCheckpointRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveExportCheckpointRequest : FProtoMessageBP {
	bool bTransient; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct HiveML.HiveDeleteCheckpointRequest
// Size: 0x48 (Inherited: 0x08)
struct FHiveDeleteCheckpointRequest : FProtoMessageBP {
	struct FHiveStatus Status; // 0x08(0x30)
	struct TArray<struct FHiveCheckpointInfo> Checkpoints; // 0x38(0x10)
};

// ScriptStruct HiveML.HiveSetValidationMetricsRequest
// Size: 0xb0 (Inherited: 0x08)
struct FHiveSetValidationMetricsRequest : FProtoMessageBP {
	struct FHiveMetaData MetaData; // 0x08(0xa8)
};

// ScriptStruct HiveML.HiveConnectAsBrainRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveConnectAsBrainRequest : FProtoMessageBP {
	int64_t RunId; // 0x08(0x08)
};

// ScriptStruct HiveML.HiveConnectAsWorkerRequest
// Size: 0x10 (Inherited: 0x08)
struct FHiveConnectAsWorkerRequest : FProtoMessageBP {
	int64_t RunId; // 0x08(0x08)
};

// ScriptStruct HiveML.ModelInfo
// Size: 0x18 (Inherited: 0x00)
struct FModelInfo {
	char pad_0[0x18]; // 0x00(0x18)
};

// ScriptStruct HiveML.HiveManagerEndPhysicsTickFunction
// Size: 0x40 (Inherited: 0x38)
struct FHiveManagerEndPhysicsTickFunction : FTickFunction {
	struct UHiveManager* Target; // 0x38(0x08)
};

// ScriptStruct HiveML.DummyGameKindDeserializer
// Size: 0x08 (Inherited: 0x00)
struct FDummyGameKindDeserializer {
	struct FName game_kind; // 0x00(0x08)
};

// ScriptStruct HiveML.MLPostInitData
// Size: 0x04 (Inherited: 0x00)
struct FMLPostInitData {
	int32_t TotalActionCount; // 0x00(0x04)
};

// ScriptStruct HiveML.ObservationFeature
// Size: 0x0c (Inherited: 0x00)
struct FObservationFeature {
	struct FName Name; // 0x00(0x08)
	int32_t Length; // 0x08(0x04)
};

// ScriptStruct HiveML.MLTaskConfiguration
// Size: 0x18 (Inherited: 0x00)
struct FMLTaskConfiguration {
	struct UMLTaskBehaviourConfigurationBase* Behaviour; // 0x00(0x08)
	struct TArray<struct UMLTaskModifierModuleConfigurationBase*> ModifierModules; // 0x08(0x10)
};

