// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkGameplayDebuggerBaseObject : UObject {
	struct FString CurrentCategory; // 0x98(0x10)

	void AddTextLineColorWithState(struct FString InTextLine, bool bInNewState); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddTextLineColorWithState // (Native|Public) // @ game+0x5a64430
	void AddTextLineColor(struct FString InTextLine, struct FColor InColor); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddTextLineColor // (Native|Public|HasDefaults) // @ game+0x5a62560
	void AddTextLine(struct FString InTextLine); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddTextLine // (Native|Public) // @ game+0x5a63520
	void AddPolyline(struct TArray<struct FVector>& Vertices, struct FColor& Color, struct FString Description, float Thickness); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddPolyline // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a65650
	void AddPolygon(struct TArray<struct FVector>& Vertices, struct FColor& Color, struct FString Description); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddPolygon // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a63120
	void AddPoint(struct FVector& InLocation, float InRadius, struct FColor& InColor, struct FString InDescription); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddPoint // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a641a0
	void AddLine(struct FVector& InStart, struct FVector& InEnd, struct FColor& InColor, struct FString InDescription, float InThickness, bool bEnableShadow); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddLine // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a62890
	void AddEmptyLines(int32_t InCount); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddEmptyLines // (Native|Public) // @ game+0x1703300
	void AddCircle(struct FVector& InCenter, float InRadius, struct FColor& InColor, struct FString InDescription); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddCircle // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a62690
	void AddCapsule(struct FVector& Center, struct FRotator& Rotation, float Radius, float HalfHeight, struct FColor& Color, struct FString Description); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddCapsule // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a65980
	void AddBox(struct FVector& Center, struct FVector& Extent, struct FColor& Color, struct FString Description); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddBox // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a65390
	void AddArrow(struct FVector& StartLocation, struct FVector& EndLocation, struct FColor& Color, struct FString Description); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerBaseObject.AddArrow // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5a647a0
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerComponent
// Size: 0x220 (Inherited: 0x160)
struct UEmbarkGameplayDebuggerComponent : UActorComponent {
	struct TArray<struct FName> CategoryStack; // 0x158(0x10)
	struct TMap<struct FName, int32_t> CategoryPageIndices; // 0x168(0x50)
	struct TMap<struct FName, bool> CategoryEnabledStates; // 0x1b8(0x50)
	bool bIsMonitoring; // 0x208(0x01)
	struct AGameplayDebuggerCategoryReplicator* CachedReplicator; // 0x210(0x08)
	char pad_219[0x7]; // 0x219(0x07)

	void ServerDeactivateCategory(struct FName CategoryName); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerComponent.ServerDeactivateCategory // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x5a64660
	void ServerChangePageIndex(struct FName InCategory, bool bIncrementPageIndex); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerComponent.ServerChangePageIndex // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x5a618c0
	void ServerActivateCategory(struct FName CategoryName); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerComponent.ServerActivateCategory // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0x5a63890
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerDrawerObject
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkGameplayDebuggerDrawerObject : UEmbarkGameplayDebuggerBaseObject {
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerGlobalCategoryObject
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkGameplayDebuggerGlobalCategoryObject : UObject {

	void DrawData(struct APlayerController* OwnerPC, struct AActor* InDebugActor, struct UEmbarkGameplayDebuggerBaseObject* DrawerObject); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerGlobalCategoryObject.DrawData // (Native|Event|Public|BlueprintEvent) // @ game+0x5a616d0
	void CollectData(struct APlayerController* OwnerPC, struct AActor* DebugActor, struct UEmbarkGameplayDebuggerBaseObject* DebuggerObject); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerGlobalCategoryObject.CollectData // (Native|Event|Public|BlueprintEvent) // @ game+0x5a612b0
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerObject
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkGameplayDebuggerObject : UEmbarkGameplayDebuggerBaseObject {
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerPage
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkGameplayDebuggerPage : UObject {

	bool ShouldShowPage(); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerPage.ShouldShowPage // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x29eeb30
	struct FString GetPageName(); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerPage.GetPageName // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5010990
	void DrawData(struct APlayerController* OwnerPC, struct AActor* InDebugActor, struct UEmbarkGameplayDebuggerBaseObject* DrawerObject); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerPage.DrawData // (Native|Event|Public|BlueprintEvent) // @ game+0x5a616d0
	void CollectData(struct APlayerController* OwnerPC, struct AActor* DebugActor, struct UEmbarkGameplayDebuggerBaseObject* DebuggerObject); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerPage.CollectData // (Native|Event|Public|BlueprintEvent) // @ game+0x5a612b0
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerConfig
// Size: 0xf0 (Inherited: 0xa0)
struct UEmbarkGameplayDebuggerConfig : UObject {
	struct TMap<struct FName, struct FEmbarkGameplayDebuggerCategoryConfig> CategoryConfigs; // 0x98(0x50)

	void PopulateCategoryConfigs(); // Function EmbarkGameplayDebugger.EmbarkGameplayDebuggerConfig.PopulateCategoryConfigs // (Native|Event|Public|BlueprintEvent) // @ game+0x2b95cb0
};

// Class EmbarkGameplayDebugger.EmbarkGameplayDebuggerSettings
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkGameplayDebuggerSettings : UObject {
	struct FSoftClassPath ConfigClass; // 0x98(0x20)
};

