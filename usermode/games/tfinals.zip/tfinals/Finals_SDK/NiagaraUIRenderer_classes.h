// Class NiagaraUIRenderer.NiagaraSystemWidget
// Size: 0x290 (Inherited: 0x1f0)
struct UNiagaraSystemWidget : UWidget {
	struct UNiagaraSystem* NiagaraSystemReference; // 0x1f0(0x08)
	struct TMap<struct UMaterialInterface*, struct UMaterialInterface*> MaterialRemapList; // 0x1f8(0x50)
	bool AutoActivate; // 0x248(0x01)
	bool TickWhenPaused; // 0x249(0x01)
	char pad_24a[0x6]; // 0x24a(0x06)
	struct FVector2D DesiredWidgetSize; // 0x250(0x10)
	bool FakeDepthScale; // 0x260(0x01)
	char pad_261[0x3]; // 0x261(0x03)
	float FakeDepthScaleDistance; // 0x264(0x04)
	bool ShowDebugSystemInWorld; // 0x268(0x01)
	bool PassDynamicParametersFromRibbon; // 0x269(0x01)
	bool DisableWarnings; // 0x26a(0x01)
	char pad_26b[0x15]; // 0x26b(0x15)
	struct ANiagaraUIActor* NiagaraActor; // 0x280(0x08)
	struct UNiagaraUIComponent* NiagaraComponent; // 0x288(0x08)

	void UpdateTickWhenPaused(bool NewTickWhenPaused); // Function NiagaraUIRenderer.NiagaraSystemWidget.UpdateTickWhenPaused // (Final|Native|Public|BlueprintCallable) // @ game+0x8f94320
	void UpdateNiagaraSystemReference(struct UNiagaraSystem* NewNiagaraSystem); // Function NiagaraUIRenderer.NiagaraSystemWidget.UpdateNiagaraSystemReference // (Final|Native|Public|BlueprintCallable) // @ game+0x8f96cc0
	void SetRemapMaterial(struct UMaterialInterface* OriginalMaterial, struct UMaterialInterface* RemapMaterial); // Function NiagaraUIRenderer.NiagaraSystemWidget.SetRemapMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x8f950c0
	void SetDesiredWidgetSize(struct FVector2D NewDesiredSize); // Function NiagaraUIRenderer.NiagaraSystemWidget.SetDesiredWidgetSize // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f967a0
	struct UMaterialInterface* GetRemapMaterial(struct UMaterialInterface* OriginalMaterial); // Function NiagaraUIRenderer.NiagaraSystemWidget.GetRemapMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x8f92df0
	struct UNiagaraUIComponent* GetNiagaraComponent(); // Function NiagaraUIRenderer.NiagaraSystemWidget.GetNiagaraComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x8f97700
	void DeactivateSystem(); // Function NiagaraUIRenderer.NiagaraSystemWidget.DeactivateSystem // (Final|Native|Public|BlueprintCallable) // @ game+0x8f959f0
	void ActivateSystem(bool Reset); // Function NiagaraUIRenderer.NiagaraSystemWidget.ActivateSystem // (Final|Native|Public|BlueprintCallable) // @ game+0x8f94240
};

// Class NiagaraUIRenderer.NiagaraUIActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct ANiagaraUIActor : AActor {
};

// Class NiagaraUIRenderer.NiagaraUIComponent
// Size: 0x960 (Inherited: 0x960)
struct UNiagaraUIComponent : UNiagaraComponent {
};

