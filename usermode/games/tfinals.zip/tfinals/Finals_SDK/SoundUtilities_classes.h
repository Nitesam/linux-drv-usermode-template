// Class SoundUtilities.SoundSimple
// Size: 0x1f0 (Inherited: 0x1e0)
struct USoundSimple : USoundBase {
	struct TArray<struct FSoundVariation> Variations; // 0x1d8(0x10)
	struct USoundWave* SoundWave; // 0x1e8(0x08)
};

// Class SoundUtilities.SoundUtilitiesBPFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USoundUtilitiesBPFunctionLibrary : UBlueprintFunctionLibrary {

	float GetQFromBandwidth(float InBandwidth); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetQFromBandwidth // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdc040
	float GetPitchScaleFromMIDIPitch(int32_t BaseMidiNote, int32_t TargetMidiNote); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetPitchScaleFromMIDIPitch // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdb6d0
	int32_t GetMIDIPitchFromFrequency(float Frequency); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetMIDIPitchFromFrequency // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdac90
	float GetLogFrequencyClamped(float InValue, struct FVector2D& InDomain, struct FVector2D& InRange); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetLogFrequencyClamped // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9cdbb80
	float GetLinearFrequencyClamped(float InValue, struct FVector2D& InDomain, struct FVector2D& InRange); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetLinearFrequencyClamped // (Final|Native|Static|Private|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9cdaf60
	float GetGainFromMidiVelocity(int32_t InVelocity); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetGainFromMidiVelocity // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdae40
	float GetFrequencyMultiplierFromSemitones(float InPitchSemitones); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetFrequencyMultiplierFromSemitones // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdb2f0
	float GetFrequencyFromMIDIPitch(int32_t MidiNote); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetFrequencyFromMIDIPitch // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdbda0
	float GetBeatTempo(float BeatsPerMinute, int32_t BeatMultiplier, int32_t DivisionsOfWholeNote); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetBeatTempo // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cd82f0
	float GetBandwidthFromQ(float InQ); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.GetBandwidthFromQ // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cdb8b0
	float ConvertLinearToDecibels(float InLinear, float InFloor); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.ConvertLinearToDecibels // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cda890
	float ConvertDecibelsToLinear(float InDecibels); // Function SoundUtilities.SoundUtilitiesBPFunctionLibrary.ConvertDecibelsToLinear // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x9cd8670
};

