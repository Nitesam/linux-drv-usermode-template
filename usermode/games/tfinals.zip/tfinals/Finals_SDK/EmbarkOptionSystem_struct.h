// Enum EmbarkOptionSystem.EEmbarkOptionExternalEvent
enum class EEmbarkOptionExternalEvent : uint8_t {
	Unknown = 0,
	ConsoleVariableChanged = 1,
	EEmbarkOptionExternalEvent_MAX = 2
};

