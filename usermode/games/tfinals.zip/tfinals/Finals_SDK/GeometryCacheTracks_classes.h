// Class GeometryCacheTracks.MovieSceneGeometryCacheSection
// Size: 0x1b0 (Inherited: 0x160)
struct UMovieSceneGeometryCacheSection : UMovieSceneSection {
	struct FMovieSceneGeometryCacheParams Params; // 0x160(0x48)
	char pad_1a8[0x8]; // 0x1a8(0x08)
};

// Class GeometryCacheTracks.MovieSceneGeometryCacheTrack
// Size: 0x120 (Inherited: 0x110)
struct UMovieSceneGeometryCacheTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AnimationSections; // 0x110(0x10)
};

