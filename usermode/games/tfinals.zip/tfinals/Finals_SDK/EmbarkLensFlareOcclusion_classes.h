// Class EmbarkLensFlareOcclusion.EmbarkLensFlareOcclusionSubsystem
// Size: 0x110 (Inherited: 0xa0)
struct UEmbarkLensFlareOcclusionSubsystem : UEngineSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TWeakObjectPtr<struct AActor> LensFlareActor; // 0xa8(0x08)
	struct TWeakObjectPtr<struct ULightComponent> LightComponent; // 0xb0(0x08)
	float SamplingRadius; // 0xb8(0x04)
	char pad_bc[0xc]; // 0xbc(0x0c)
	struct UTextureRenderTarget2D* OcclusionTarget; // 0xc8(0x08)
	char pad_d0[0x40]; // 0xd0(0x40)

	struct UTextureRenderTarget2D* GetOcclusionResultTexture(); // Function EmbarkLensFlareOcclusion.EmbarkLensFlareOcclusionSubsystem.GetOcclusionResultTexture // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ffce10
};

