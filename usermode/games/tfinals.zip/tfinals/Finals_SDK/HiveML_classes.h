// Class HiveML.BlackboardUtil
// Size: 0xa0 (Inherited: 0xa0)
struct UBlackboardUtil : UObject {

	void SetInt(struct FMLBlackboard& Blackboard, struct FName Key, int32_t Value); // Function HiveML.BlackboardUtil.SetInt // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa6d30
	void SetFString(struct FMLBlackboard& Blackboard, struct FName Key, struct FString Value); // Function HiveML.BlackboardUtil.SetFString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa63d0
	void SetFloat(struct FMLBlackboard& Blackboard, struct FName Key, float Value); // Function HiveML.BlackboardUtil.SetFloat // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa5600
	void SetBool(struct FMLBlackboard& Blackboard, struct FName Key, bool Value); // Function HiveML.BlackboardUtil.SetBool // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa57f0
	void ResetBlackboard(struct FMLBlackboard& Blackboard); // Function HiveML.BlackboardUtil.ResetBlackboard // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa7060
	bool HasKey(struct FMLBlackboard& Blackboard, struct FName Key); // Function HiveML.BlackboardUtil.HasKey // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa6870
	int32_t GetInt(struct FMLBlackboard& Blackboard, struct FName Key); // Function HiveML.BlackboardUtil.GetInt // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa7ae0
	struct FString GetFString(struct FMLBlackboard& Blackboard, struct FName Key); // Function HiveML.BlackboardUtil.GetFString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa59e0
	float GetFloat(struct FMLBlackboard& Blackboard, struct FName Key); // Function HiveML.BlackboardUtil.GetFloat // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa5fb0
	bool GetBool(struct FMLBlackboard& Blackboard, struct FName Key); // Function HiveML.BlackboardUtil.GetBool // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa51d0
	struct FString BlackboardToString(struct FMLBlackboard& Blackboard); // Function HiveML.BlackboardUtil.BlackboardToString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa6a70
};

// Class HiveML.HiveRpcClientBase
// Size: 0xb0 (Inherited: 0xa0)
struct UHiveRpcClientBase : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class HiveML.HivePingServiceRpcClient
// Size: 0xd0 (Inherited: 0xb0)
struct UHivePingServiceRpcClient : UHiveRpcClientBase {
	struct FMulticastInlineDelegate OnPingCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnEmptyCompleted; // 0xb8(0x10)

	bool PingBlocking(struct FHivePingRequest& Request, struct FHiveRpcContext& Context, struct FHivePingResponse& Response); // Function HiveML.HivePingServiceRpcClient.PingBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8faac60
	void Ping(struct FHivePingRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HivePingServiceRpcClient.Ping // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbfba0
	bool EmptyBlocking(struct FHiveEmptyRequest& Request, struct FHiveRpcContext& Context, struct FHiveEmptyResponse& Response); // Function HiveML.HivePingServiceRpcClient.EmptyBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbcd00
	void Empty(struct FHiveEmptyRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HivePingServiceRpcClient.Empty // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb2400
};

// Class HiveML.HiveMLRegistryRpcClient
// Size: 0x180 (Inherited: 0xb0)
struct UHiveMLRegistryRpcClient : UHiveRpcClientBase {
	struct FMulticastInlineDelegate OnDownloadCheckpointCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnGetLastCheckpointCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnGetCheckpointChunkCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnListBuildsCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnCreateExperimentCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnDestroyExperimentCompleted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnStopExperimentCompleted; // 0x108(0x10)
	struct FMulticastInlineDelegate OnListExperimentsCompleted; // 0x118(0x10)
	struct FMulticastInlineDelegate OnGetExperimentCompleted; // 0x128(0x10)
	struct FMulticastInlineDelegate OnPullConfigCompleted; // 0x138(0x10)
	struct FMulticastInlineDelegate OnDeployCompleted; // 0x148(0x10)
	struct FMulticastInlineDelegate OnShutdownCompleted; // 0x158(0x10)
	struct FMulticastInlineDelegate OnGetEndpointCompleted; // 0x168(0x10)

	bool StopExperimentBlocking(struct FHiveStopRequest& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveMLRegistryRpcClient.StopExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcd550
	void StopExperiment(struct FHiveStopRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.StopExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd3830
	bool ShutdownBlocking(struct FHiveStopRequest& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveMLRegistryRpcClient.ShutdownBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc6ab0
	void Shutdown(struct FHiveStopRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.Shutdown // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcb710
	bool PullConfigBlocking(struct FHiveConfigurationDataRequest& Request, struct FHiveRpcContext& Context, struct FHiveConfigurationDataResponse& Response); // Function HiveML.HiveMLRegistryRpcClient.PullConfigBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb05b0
	void PullConfig(struct FHiveConfigurationDataRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.PullConfig // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb9820
	bool ListExperimentsBlocking(struct FHiveQueryRequest& Request, struct FHiveRpcContext& Context, struct FHiveExperimentList& Response); // Function HiveML.HiveMLRegistryRpcClient.ListExperimentsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc9c00
	void ListExperiments(struct FHiveQueryRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.ListExperiments // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc6220
	bool ListBuildsBlocking(struct FHiveQueryRequest& Request, struct FHiveRpcContext& Context, struct FHiveBuildIdList& Response); // Function HiveML.HiveMLRegistryRpcClient.ListBuildsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcb3a0
	void ListBuilds(struct FHiveQueryRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.ListBuilds // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcec60
	bool GetLastCheckpointBlocking(struct FHiveGetExperimentCheckpointRequest& Request, struct FHiveRpcContext& Context, struct FHiveSerializedModel& Response); // Function HiveML.HiveMLRegistryRpcClient.GetLastCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa8de0
	void GetLastCheckpoint(struct FHiveGetExperimentCheckpointRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.GetLastCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc0d30
	bool GetExperimentBlocking(struct FHiveExperimentQuery& Request, struct FHiveRpcContext& Context, struct FHiveExperimentList& Response); // Function HiveML.HiveMLRegistryRpcClient.GetExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc0750
	void GetExperiment(struct FHiveExperimentQuery& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.GetExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd4c20
	bool GetEndpointBlocking(struct FHiveEndpointRequest& Request, struct FHiveRpcContext& Context, struct FHiveEndpointResponse& Response); // Function HiveML.HiveMLRegistryRpcClient.GetEndpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fadbb0
	void GetEndpoint(struct FHiveEndpointRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.GetEndpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc09b0
	bool GetCheckpointChunkBlocking(struct FHiveChunkRequest& Request, struct FHiveRpcContext& Context, struct FHiveChunkResponse& Response); // Function HiveML.HiveMLRegistryRpcClient.GetCheckpointChunkBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd2e90
	void GetCheckpointChunk(struct FHiveChunkRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.GetCheckpointChunk // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc9ed0
	bool DownloadCheckpointBlocking(struct FHiveGetCheckpointRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetCheckpointResponse& Response); // Function HiveML.HiveMLRegistryRpcClient.DownloadCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbb990
	void DownloadCheckpoint(struct FHiveGetCheckpointRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.DownloadCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcff60
	bool DestroyExperimentBlocking(struct FHiveStopRequest& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveMLRegistryRpcClient.DestroyExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc0220
	void DestroyExperiment(struct FHiveStopRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.DestroyExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fab680
	bool DeployBlocking(struct FHiveDeployRequest& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveMLRegistryRpcClient.DeployBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb11c0
	void Deploy(struct FHiveDeployRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.Deploy // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb5a20
	bool CreateExperimentBlocking(struct FHiveDeployRequest& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveMLRegistryRpcClient.CreateExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd0c90
	void CreateExperiment(struct FHiveDeployRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryRpcClient.CreateExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fab1e0
};

// Class HiveML.HiveMLRegistryServiceRpcClient
// Size: 0x290 (Inherited: 0xb0)
struct UHiveMLRegistryServiceRpcClient : UHiveRpcClientBase {
	struct FMulticastInlineDelegate OnGetExperimentsCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnGetExperimentCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnCreateExperimentCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnUpdateExperimentCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnProtectExperimentCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnDeleteExperimentCompleted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnCompressExperimentCompleted; // 0x108(0x10)
	struct FMulticastInlineDelegate OnGetTrialsCompleted; // 0x118(0x10)
	struct FMulticastInlineDelegate OnGetTrialCompleted; // 0x128(0x10)
	struct FMulticastInlineDelegate OnCreateTrialCompleted; // 0x138(0x10)
	struct FMulticastInlineDelegate OnDeleteTrialCompleted; // 0x148(0x10)
	struct FMulticastInlineDelegate OnUpdateTrialCompleted; // 0x158(0x10)
	struct FMulticastInlineDelegate OnCompressTrialCompleted; // 0x168(0x10)
	struct FMulticastInlineDelegate OnProtectTrialCompleted; // 0x178(0x10)
	struct FMulticastInlineDelegate OnGetRunCheckpointCompleted; // 0x188(0x10)
	struct FMulticastInlineDelegate OnGetCheckpointChunkCompleted; // 0x198(0x10)
	struct FMulticastInlineDelegate OnGetRunsCompleted; // 0x1a8(0x10)
	struct FMulticastInlineDelegate OnGetRunCompleted; // 0x1b8(0x10)
	struct FMulticastInlineDelegate OnCreateRunCompleted; // 0x1c8(0x10)
	struct FMulticastInlineDelegate OnStopRunCompleted; // 0x1d8(0x10)
	struct FMulticastInlineDelegate OnContinueRunCompleted; // 0x1e8(0x10)
	struct FMulticastInlineDelegate OnDeleteRunCompleted; // 0x1f8(0x10)
	struct FMulticastInlineDelegate OnCompressRunCompleted; // 0x208(0x10)
	struct FMulticastInlineDelegate OnProtectRunCompleted; // 0x218(0x10)
	struct FMulticastInlineDelegate OnListBuildProvidersCompleted; // 0x228(0x10)
	struct FMulticastInlineDelegate OnListBuildsCompleted; // 0x238(0x10)
	struct FMulticastInlineDelegate OnLinkTrialsToExperimentCompleted; // 0x248(0x10)
	struct FMulticastInlineDelegate OnUnlinkTrialsFromExperimentCompleted; // 0x258(0x10)
	struct FMulticastInlineDelegate OnSearchAuthorsCompleted; // 0x268(0x10)
	struct FMulticastInlineDelegate OnSearchExperimentsCompleted; // 0x278(0x10)

	bool UpdateTrialBlocking(struct FHiveUpdateTrialRequest& Request, struct FHiveRpcContext& Context, struct FHiveUpdateTrialResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.UpdateTrialBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc8ea0
	void UpdateTrial(struct FHiveUpdateTrialRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.UpdateTrial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb2fa0
	bool UpdateExperimentBlocking(struct FHiveUpdateExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveUpdateExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.UpdateExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb5d40
	void UpdateExperiment(struct FHiveUpdateExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.UpdateExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fae5a0
	bool UnlinkTrialsFromExperimentBlocking(struct FHiveUnlinkTrialsFromExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveUnlinkTrialsFromExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.UnlinkTrialsFromExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb0fa0
	void UnlinkTrialsFromExperiment(struct FHiveUnlinkTrialsFromExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.UnlinkTrialsFromExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc4a90
	bool StopRunBlocking(struct FHiveStopRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveStopRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.StopRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb7a90
	void StopRun(struct FHiveStopRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.StopRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa89c0
	bool SearchExperimentsBlocking(struct FHiveSearchExperimentsRequest& Request, struct FHiveRpcContext& Context, struct FHiveSearchExperimentsResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.SearchExperimentsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb0250
	void SearchExperiments(struct FHiveSearchExperimentsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.SearchExperiments // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd2a90
	bool SearchAuthorsBlocking(struct FHiveSearchAuthorsRequest& Request, struct FHiveRpcContext& Context, struct FHiveSearchAuthorsResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.SearchAuthorsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb1450
	void SearchAuthors(struct FHiveSearchAuthorsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.SearchAuthors // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbd3a0
	bool ProtectTrialBlocking(struct FHiveProtectTrialRequest& Request, struct FHiveRpcContext& Context, struct FHiveProtectTrialResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.ProtectTrialBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb4550
	void ProtectTrial(struct FHiveProtectTrialRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.ProtectTrial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fba2f0
	bool ProtectRunBlocking(struct FHiveProtectRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveProtectRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.ProtectRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbb180
	void ProtectRun(struct FHiveProtectRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.ProtectRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb0d10
	bool ProtectExperimentBlocking(struct FHiveProtectExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveProtectExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.ProtectExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcaac0
	void ProtectExperiment(struct FHiveProtectExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.ProtectExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc0eb0
	bool ListBuildsBlocking(struct FHiveListBuildsRequest& Request, struct FHiveRpcContext& Context, struct FHiveListBuildsResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.ListBuildsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbe170
	void ListBuilds(struct FHiveListBuildsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.ListBuilds // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd33a0
	bool ListBuildProvidersBlocking(struct FHiveListBuildProvidersRequest& Request, struct FHiveRpcContext& Context, struct FHiveListBuildProvidersResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.ListBuildProvidersBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8facc00
	void ListBuildProviders(struct FHiveListBuildProvidersRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.ListBuildProviders // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc5690
	bool LinkTrialsToExperimentBlocking(struct FHiveLinkTrialsToExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveLinkTrialsToExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.LinkTrialsToExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb38b0
	void LinkTrialsToExperiment(struct FHiveLinkTrialsToExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.LinkTrialsToExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcd1b0
	bool GetTrialsBlocking(struct FHiveGetTrialsRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetTrialsResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetTrialsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcd8f0
	void GetTrials(struct FHiveGetTrialsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetTrials // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb35e0
	bool GetTrialBlocking(struct FHiveGetTrialRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetTrialResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetTrialBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fade50
	void GetTrial(struct FHiveGetTrialRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetTrial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb30f0
	bool GetRunsBlocking(struct FHiveGetRunsRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetRunsResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetRunsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa9190
	void GetRuns(struct FHiveGetRunsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetRuns // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8faf290
	bool GetRunCheckpointBlocking(struct FHiveGetRunCheckpointRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetRunCheckpointResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetRunCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8faee10
	void GetRunCheckpoint(struct FHiveGetRunCheckpointRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetRunCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc4520
	bool GetRunBlocking(struct FHiveGetRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc5d10
	void GetRun(struct FHiveGetRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fa8890
	bool GetExperimentsBlocking(struct FHiveGetExperimentsRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetExperimentsResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetExperimentsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc8130
	void GetExperiments(struct FHiveGetExperimentsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetExperiments // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd30d0
	bool GetExperimentBlocking(struct FHiveGetExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc5f50
	void GetExperiment(struct FHiveGetExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb5730
	bool GetCheckpointChunkBlocking(struct FHiveGetCheckpointChunkRequest& Request, struct FHiveRpcContext& Context, struct FHiveGetCheckpointChunkResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.GetCheckpointChunkBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fac560
	void GetCheckpointChunk(struct FHiveGetCheckpointChunkRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.GetCheckpointChunk // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fad2b0
	bool DeleteTrialBlocking(struct FHiveDeleteTrialRequest& Request, struct FHiveRpcContext& Context, struct FHiveDeleteTrialResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.DeleteTrialBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb4980
	void DeleteTrial(struct FHiveDeleteTrialRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.DeleteTrial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb2a70
	bool DeleteRunBlocking(struct FHiveDeleteRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveDeleteRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.DeleteRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbd520
	void DeleteRun(struct FHiveDeleteRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.DeleteRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb66f0
	bool DeleteExperimentBlocking(struct FHiveDeleteExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveDeleteExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.DeleteExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcc820
	void DeleteExperiment(struct FHiveDeleteExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.DeleteExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb58f0
	bool CreateTrialBlocking(struct FHiveCreateTrialRequest& Request, struct FHiveRpcContext& Context, struct FHiveCreateTrialResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.CreateTrialBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd10f0
	void CreateTrial(struct FHiveCreateTrialRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.CreateTrial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8faa8e0
	bool CreateRunBlocking(struct FHiveCreateRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveCreateRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.CreateRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbf4c0
	void CreateRun(struct FHiveCreateRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.CreateRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc3c60
	bool CreateExperimentBlocking(struct FHiveCreateExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveCreateExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.CreateExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc8a90
	void CreateExperiment(struct FHiveCreateExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.CreateExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb3f90
	bool ContinueRunBlocking(struct FHiveContinueRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveContinueRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.ContinueRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc7ef0
	void ContinueRun(struct FHiveContinueRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.ContinueRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbc8e0
	bool CompressTrialBlocking(struct FHiveCompressTrialRequest& Request, struct FHiveRpcContext& Context, struct FHiveCompressTrialResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.CompressTrialBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc68b0
	void CompressTrial(struct FHiveCompressTrialRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.CompressTrial // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fad0a0
	bool CompressRunBlocking(struct FHiveCompressRunRequest& Request, struct FHiveRpcContext& Context, struct FHiveCompressRunResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.CompressRunBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fad7d0
	void CompressRun(struct FHiveCompressRunRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.CompressRun // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb72c0
	bool CompressExperimentBlocking(struct FHiveCompressExperimentRequest& Request, struct FHiveRpcContext& Context, struct FHiveCompressExperimentResponse& Response); // Function HiveML.HiveMLRegistryServiceRpcClient.CompressExperimentBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc74d0
	void CompressExperiment(struct FHiveCompressExperimentRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveMLRegistryServiceRpcClient.CompressExperiment // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd4a30
};

// Class HiveML.HiveModelRpcClient
// Size: 0x180 (Inherited: 0xb0)
struct UHiveModelRpcClient : UHiveRpcClientBase {
	struct FMulticastInlineDelegate OnInferCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnEvaluateCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnObserveCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnListCheckpointsCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnCreateCheckpointCompleted; // 0xe8(0x10)
	struct FMulticastInlineDelegate OnDeleteCheckpointCompleted; // 0xf8(0x10)
	struct FMulticastInlineDelegate OnGetLastCheckpointCompleted; // 0x108(0x10)
	struct FMulticastInlineDelegate OnGetMetricsCompleted; // 0x118(0x10)
	struct FMulticastInlineDelegate OnSetMetricsCompleted; // 0x128(0x10)
	struct FMulticastInlineDelegate OnGetCheckpointChunkCompleted; // 0x138(0x10)
	struct FMulticastInlineDelegate OnSetCheckpointMetadataCompleted; // 0x148(0x10)
	struct FMulticastInlineDelegate OnPushDemoExperienceCompleted; // 0x158(0x10)
	struct FMulticastInlineDelegate OnPushAugmentedExperiencesCompleted; // 0x168(0x10)

	bool SetMetricsBlocking(struct FHiveMetricsMessage& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveModelRpcClient.SetMetricsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fafb30
	void SetMetrics(struct FHiveMetricsMessage& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.SetMetrics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb4f20
	bool SetCheckpointMetadataBlocking(struct FHiveMetadataMessage& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveModelRpcClient.SetCheckpointMetadataBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fac8c0
	void SetCheckpointMetadata(struct FHiveMetadataMessage& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.SetCheckpointMetadata // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fad470
	bool PushDemoExperienceBlocking(struct FHiveAugmentedExperiences& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveModelRpcClient.PushDemoExperienceBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb41a0
	void PushDemoExperience(struct FHiveAugmentedExperiences& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.PushDemoExperience // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb21b0
	bool PushAugmentedExperiencesBlocking(struct FHiveAugmentedExperiences& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveModelRpcClient.PushAugmentedExperiencesBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc3500
	void PushAugmentedExperiences(struct FHiveAugmentedExperiences& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.PushAugmentedExperiences // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc1120
	bool ObserveBlocking(struct FHiveObservationGroup& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveModelRpcClient.ObserveBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb6f20
	void Observe(struct FHiveObservationGroup& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.Observe // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc4690
	bool ListCheckpointsBlocking(struct FHiveListCheckpointsParams& Request, struct FHiveRpcContext& Context, struct FHiveCheckpointsResponse& Response); // Function HiveML.HiveModelRpcClient.ListCheckpointsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb5f90
	void ListCheckpoints(struct FHiveListCheckpointsParams& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.ListCheckpoints // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb6590
	bool InferBlocking(struct FHiveObservationGroup& Request, struct FHiveRpcContext& Context, struct FHiveResponseGroup& Response); // Function HiveML.HiveModelRpcClient.InferBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcf0b0
	void Infer(struct FHiveObservationGroup& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.Infer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd0110
	bool GetMetricsBlocking(struct FHiveMetricsQuery& Request, struct FHiveRpcContext& Context, struct FHiveMetaDataResponse& Response); // Function HiveML.HiveModelRpcClient.GetMetricsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbd070
	void GetMetrics(struct FHiveMetricsQuery& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.GetMetrics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbfea0
	bool GetLastCheckpointBlocking(struct FHiveGetCheckpointParams& Request, struct FHiveRpcContext& Context, struct FHiveSerializedModel& Response); // Function HiveML.HiveModelRpcClient.GetLastCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fafd90
	void GetLastCheckpoint(struct FHiveGetCheckpointParams& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.GetLastCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcbd50
	bool GetCheckpointChunkBlocking(struct FHiveChunkRequest& Request, struct FHiveRpcContext& Context, struct FHiveChunkResponse& Response); // Function HiveML.HiveModelRpcClient.GetCheckpointChunkBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcbad0
	void GetCheckpointChunk(struct FHiveChunkRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.GetCheckpointChunk // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fac3d0
	bool EvaluateBlocking(struct FHiveObservationGroup& Request, struct FHiveRpcContext& Context, struct FHiveResponseGroup& Response); // Function HiveML.HiveModelRpcClient.EvaluateBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fce930
	void Evaluate(struct FHiveObservationGroup& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.Evaluate // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc7310
	bool DeleteCheckpointBlocking(struct FHiveCheckpointHandle& Request, struct FHiveRpcContext& Context, struct FHiveStatus& Response); // Function HiveML.HiveModelRpcClient.DeleteCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc6dd0
	void DeleteCheckpoint(struct FHiveCheckpointHandle& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.DeleteCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd2d50
	bool CreateCheckpointBlocking(struct FHiveCreateCheckpointParams& Request, struct FHiveRpcContext& Context, struct FHiveSerializedModel& Response); // Function HiveML.HiveModelRpcClient.CreateCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc9200
	void CreateCheckpoint(struct FHiveCreateCheckpointParams& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelRpcClient.CreateCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcc250
};

// Class HiveML.HiveModelServiceRpcClient
// Size: 0x100 (Inherited: 0xb0)
struct UHiveModelServiceRpcClient : UHiveRpcClientBase {
	struct FMulticastInlineDelegate OnInitializeCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnPushEpisodeCompleted; // 0xb8(0x10)
	struct FMulticastInlineDelegate OnExportCheckpointCompleted; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnDeleteCheckpointCompleted; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnSetValidationMetricsCompleted; // 0xe8(0x10)

	bool SetValidationMetricsBlocking(struct FHiveSetValidationMetricsRequest& Request, struct FHiveRpcContext& Context, struct FHiveSetValidationMetricsResponse& Response); // Function HiveML.HiveModelServiceRpcClient.SetValidationMetricsBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb74a0
	void SetValidationMetrics(struct FHiveSetValidationMetricsRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelServiceRpcClient.SetValidationMetrics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd4780
	bool PushEpisodeBlocking(struct FHivePushEpisodeRequest& Request, struct FHiveRpcContext& Context, struct FHivePushEpisodeResponse& Response); // Function HiveML.HiveModelServiceRpcClient.PushEpisodeBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcbfd0
	void PushEpisode(struct FHivePushEpisodeRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelServiceRpcClient.PushEpisode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd1570
	bool InitializeBlocking(struct FHiveInitializeRequest& Request, struct FHiveRpcContext& Context, struct FHiveInitializeResponse& Response); // Function HiveML.HiveModelServiceRpcClient.InitializeBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fcca20
	void Initialize(struct FHiveInitializeRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelServiceRpcClient.Initialize // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd5250
	bool ExportCheckpointBlocking(struct FHiveExportCheckpointRequest& Request, struct FHiveRpcContext& Context, struct FHiveExportCheckpointResponse& Response); // Function HiveML.HiveModelServiceRpcClient.ExportCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd44a0
	void ExportCheckpoint(struct FHiveExportCheckpointRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelServiceRpcClient.ExportCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb94b0
	bool DeleteCheckpointBlocking(struct FHiveDeleteCheckpointRequest& Request, struct FHiveRpcContext& Context, struct FHiveDeleteCheckpointResponse& Response); // Function HiveML.HiveModelServiceRpcClient.DeleteCheckpointBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb7f90
	void DeleteCheckpoint(struct FHiveDeleteCheckpointRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveModelServiceRpcClient.DeleteCheckpoint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbd950
};

// Class HiveML.HiveRegistryServiceRpcClient
// Size: 0xd0 (Inherited: 0xb0)
struct UHiveRegistryServiceRpcClient : UHiveRpcClientBase {
	struct FMulticastInlineDelegate OnConnectAsBrainCompleted; // 0xa8(0x10)
	struct FMulticastInlineDelegate OnConnectAsWorkerCompleted; // 0xb8(0x10)

	bool ConnectAsWorkerBlocking(struct FHiveConnectAsWorkerRequest& Request, struct FHiveRpcContext& Context, struct FHiveConnectAsWorkerResponse& Response); // Function HiveML.HiveRegistryServiceRpcClient.ConnectAsWorkerBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fb9970
	void ConnectAsWorker(struct FHiveConnectAsWorkerRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveRegistryServiceRpcClient.ConnectAsWorker // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fc9440
	bool ConnectAsBrainBlocking(struct FHiveConnectAsBrainRequest& Request, struct FHiveRpcContext& Context, struct FHiveConnectAsBrainResponse& Response); // Function HiveML.HiveRegistryServiceRpcClient.ConnectAsBrainBlocking // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fac1b0
	void ConnectAsBrain(struct FHiveConnectAsBrainRequest& Request, struct FHiveRpcContext& Context); // Function HiveML.HiveRegistryServiceRpcClient.ConnectAsBrain // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fbef30
};

// Class HiveML.HiveRuntimeSettings
// Size: 0x140 (Inherited: 0xb0)
struct UHiveRuntimeSettings : UDeveloperSettings {
	struct TMap<struct FName, struct TSoftClassPtr<UObject>> GameKindToConfigClass; // 0xa8(0x50)
	struct TArray<struct TSoftClassPtr<UObject>> DebugModules; // 0xf8(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> TrainingModules; // 0x108(0x10)
	struct FString HiveUrl; // 0x118(0x10)
	struct FString BearerToken; // 0x128(0x10)
};

// Class HiveML.HiveManager
// Size: 0x220 (Inherited: 0x160)
struct UHiveManager : UActorComponent {
	struct FMulticastInlineDelegate OnModelReady; // 0x158(0x10)
	struct TMap<struct FName, struct UMLDataAssetBase*> Configurations; // 0x168(0x50)
	struct TArray<struct UMLModelData*> InferenceAssets; // 0x1b8(0x10)
	char pad_1d0[0x8]; // 0x1d0(0x08)
	struct FHiveManagerEndPhysicsTickFunction EndPhysicsTickFunction; // 0x1d8(0x40)
	char pad_218[0x8]; // 0x218(0x08)

	void UnregisterAgentType(struct FName AgentTypeName); // Function HiveML.HiveManager.UnregisterAgentType // (Native|Public|BlueprintCallable) // @ game+0x8fde750
	void UnregisterAgent(struct UMLAgentComponent* AgentComponent); // Function HiveML.HiveManager.UnregisterAgent // (Final|Native|Public) // @ game+0x8fde570
	void RegisterAgent(struct UMLAgentComponent* AgentComponent, struct FName AgentTypeName, enum class EMLAgentMode Mode); // Function HiveML.HiveManager.RegisterAgent // (Final|Native|Public) // @ game+0x8fde860
	struct UMLDataAssetBase* ParseConfigurationWithMode(struct FName Name, struct FString& JsonBlob, enum class EMLExecutionMode ExecutionMode); // Function HiveML.HiveManager.ParseConfigurationWithMode // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x8fde1d0
	struct UMLDataAssetBase* ParseConfiguration(struct FName Name, struct FString& JsonBlob); // Function HiveML.HiveManager.ParseConfiguration // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x8fde420
	bool IsTraining(); // Function HiveML.HiveManager.IsTraining // (Final|Native|Public|Const) // @ game+0x8fddfb0
};

// Class HiveML.HiveTrainingManager
// Size: 0x280 (Inherited: 0x220)
struct UHiveTrainingManager : UHiveManager {
	struct FString HiveUrl; // 0x220(0x10)
	struct FString ExperimentName; // 0x230(0x10)
	bool bIsCloudInfer; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct FMulticastInlineDelegate OnRestartTraining; // 0x248(0x10)
	struct FString BearerToken; // 0x258(0x10)
	bool bUseLocalInference; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)
	struct URegistryClient* RegistryClient; // 0x270(0x08)
	char pad_278[0x8]; // 0x278(0x08)

	void SoftReset(struct UMLAgentComponent* AgentComponent); // Function HiveML.HiveTrainingManager.SoftReset // (Final|Native|Public|BlueprintCallable) // @ game+0x8fd71a0
	void RegisterHiveAgentType(struct FName AgentTypeName, int64_t RunId); // Function HiveML.HiveTrainingManager.RegisterHiveAgentType // (Final|Native|Public|BlueprintCallable) // @ game+0x8fd6650
	void PushValidationMetrics(struct UMLDataAssetBase* AssociatedConfiguration, struct FHiveMetaData& Metrics); // Function HiveML.HiveTrainingManager.PushValidationMetrics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd74e0
	void PushMetrics(struct UMLDataAssetBase* AssociatedConfiguration, struct FHiveMetricsMessage& Metrics); // Function HiveML.HiveTrainingManager.PushMetrics // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8fd7ee0
	void OnSetValidationMetricsResponse(struct UHiveModelServiceRpcClient* Client, bool bSuccess, struct FHiveSetValidationMetricsResponse& Response, struct FString ErrorMessage); // Function HiveML.HiveTrainingManager.OnSetValidationMetricsResponse // (Final|Native|Public|HasOutParms) // @ game+0x8fd7b10
	void OnSetMetricsResponse(struct UHiveModelRpcClient* Client, bool bSuccess, struct FHiveStatus& Message, struct FString ErrorMessage); // Function HiveML.HiveTrainingManager.OnSetMetricsResponse // (Final|Native|Public|HasOutParms) // @ game+0x8fd6240
	void OnSendMetadataResponse(struct UHiveModelRpcClient* Client, bool bSuccessful, struct FHiveStatus& Message, struct FString ErrorMsg); // Function HiveML.HiveTrainingManager.OnSendMetadataResponse // (Final|Native|Public|HasOutParms) // @ game+0x8fd6240
	void OnMetricsResponse(struct UHiveModelRpcClient* Client, bool bSuccessful, struct FHiveMetaDataResponse& Message, struct FString ErrorMsg); // Function HiveML.HiveTrainingManager.OnMetricsResponse // (Final|Native|Public|HasOutParms) // @ game+0x8fd7690
	void OnInferResponse(struct UHiveModelRpcClient* Client, bool bSuccessful, struct FHiveResponseGroup& Message, struct FString ErrorMsg); // Function HiveML.HiveTrainingManager.OnInferResponse // (Final|Native|Public|HasOutParms) // @ game+0x8fd5f90
	void OnConnectAsWorkerResponse(int64_t RunId, struct FString Json, struct FString Endpoint, bool bIsRestart); // Function HiveML.HiveTrainingManager.OnConnectAsWorkerResponse // (Final|Native|Public) // @ game+0x8fd6970
	struct FHiveRpcContext GetRegistryGrpcContext(struct FString RegistryUrl); // Function HiveML.HiveTrainingManager.GetRegistryGrpcContext // (Native|Event|Public|BlueprintEvent) // @ game+0x8fd6460
	struct UHiveTrainingManager* GetFromWorld(struct UWorld* World); // Function HiveML.HiveTrainingManager.GetFromWorld // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fd68d0
	bool GenerateDerivedData(struct UMLDataAssetBase* base, struct FString& Out); // Function HiveML.HiveTrainingManager.GenerateDerivedData // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x8fd7290
};

// Class HiveML.MetricsCache
// Size: 0x1a0 (Inherited: 0xa0)
struct UMetricsCache : UObject {
	int32_t Generation; // 0x98(0x04)
	char pad_a4[0xfc]; // 0xa4(0xfc)

	bool GetMetricValue(struct FName Name, float& OutMetricValue); // Function HiveML.MetricsCache.GetMetricValue // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fd8550
	bool GetMetricList(struct FName Name, struct TArray<float>& OutMetricValue); // Function HiveML.MetricsCache.GetMetricList // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fd8170
	void AddMetricName(struct FName Name); // Function HiveML.MetricsCache.AddMetricName // (Final|Native|Public|BlueprintCallable) // @ game+0x8fd8440
};

// Class HiveML.MLAgentComponent
// Size: 0x250 (Inherited: 0x170)
struct UMLAgentComponent : UActorComponentReplicatedSubobjects {
	struct FMulticastInlineDelegate OnAgentReset; // 0x170(0x10)
	struct FMLBlackboard Blackboard; // 0x180(0x78)
	struct UMLDataAssetBase* MLData; // 0x1f8(0x08)
	enum class EMLAgentMode Mode; // 0x200(0x01)
	char pad_201[0x3]; // 0x201(0x03)
	int32_t FeatureCount; // 0x204(0x04)
	int32_t ActionCount; // 0x208(0x04)
	struct FName AgentType; // 0x20c(0x08)
	char pad_214[0x24]; // 0x214(0x24)
	struct UMLModelData* InferenceData; // 0x238(0x08)
	struct UMLModelData* TestingInferenceData; // 0x240(0x08)
	char pad_248[0x8]; // 0x248(0x08)

	void Unregister(); // Function HiveML.MLAgentComponent.Unregister // (Native|Public|BlueprintCallable) // @ game+0x8fd9850
	enum class EAgentResetFlags ReceiveResetFlags(); // Function HiveML.MLAgentComponent.ReceiveResetFlags // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	bool ReceivePostObserve(struct FHiveObservation& Observation); // Function HiveML.MLAgentComponent.ReceivePostObserve // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnPrePhysics(float Delta); // Function HiveML.MLAgentComponent.ReceiveOnPrePhysics // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnPostPhysics(float Delta); // Function HiveML.MLAgentComponent.ReceiveOnPostPhysics // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnEnable(); // Function HiveML.MLAgentComponent.ReceiveOnEnable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnDisable(); // Function HiveML.MLAgentComponent.ReceiveOnDisable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnAgentUnregistered(); // Function HiveML.MLAgentComponent.ReceiveOnAgentUnregistered // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnAgentRegistered(); // Function HiveML.MLAgentComponent.ReceiveOnAgentRegistered // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveObserveRewards(struct FHiveObservation& Observation); // Function HiveML.MLAgentComponent.ReceiveObserveRewards // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveObserveMetadata(struct FHiveObservation& Observation); // Function HiveML.MLAgentComponent.ReceiveObserveMetadata // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveObserve(struct FHiveObservation& Observation); // Function HiveML.MLAgentComponent.ReceiveObserve // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	enum class EHiveTerminalReason ReceiveIsTerminal(); // Function HiveML.MLAgentComponent.ReceiveIsTerminal // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	bool ReceiveIsReady(); // Function HiveML.MLAgentComponent.ReceiveIsReady // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	bool ReceiveExtractActions(struct TArray<float>& Actions); // Function HiveML.MLAgentComponent.ReceiveExtractActions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	bool ReceiveApplyActions(); // Function HiveML.MLAgentComponent.ReceiveApplyActions // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool IsRegistered(); // Function HiveML.MLAgentComponent.IsRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fda8c0
	bool IsEnabled(); // Function HiveML.MLAgentComponent.IsEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdb210
	struct UMLModelData* GetUsedInferenceData(); // Function HiveML.MLAgentComponent.GetUsedInferenceData // (Final|Native|Public|Const) // @ game+0x8fd9700
	void Enable(); // Function HiveML.MLAgentComponent.Enable // (Final|Native|Public|BlueprintCallable) // @ game+0x8fda740
	void Disable(); // Function HiveML.MLAgentComponent.Disable // (Final|Native|Public|BlueprintCallable) // @ game+0x8fd9360
};

// Class HiveML.MLBehaviorState
// Size: 0xf0 (Inherited: 0xd0)
struct UMLBehaviorState : UReplicatedSubobject {
	struct FName BehaviorName; // 0xc8(0x08)
	struct TArray<struct UMLModule*> Modules; // 0xd0(0x10)
	int32_t FeatureCount; // 0xe0(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// Class HiveML.MLAgentModularComponent
// Size: 0x2c0 (Inherited: 0x250)
struct UMLAgentModularComponent : UMLAgentComponent {
	bool bShowDebugInfo; // 0x250(0x01)
	bool bShowObservationCount; // 0x251(0x01)
	char pad_252[0x6]; // 0x252(0x06)
	struct TArray<struct UMLBehaviorState*> Behaviors; // 0x258(0x10)
	struct FDelegate ConfigReceived; // 0x268(0x10)
	struct FMulticastInlineDelegate EpisodeDoneEvent; // 0x278(0x10)
	struct FMulticastInlineDelegate EpisodeStartEvent; // 0x288(0x10)
	char pad_298[0x10]; // 0x298(0x10)
	struct UObservationSet* Observations; // 0x2a8(0x08)
	char ActiveBehavior; // 0x2b0(0x01)
	bool bReplicateModules; // 0x2b1(0x01)
	char pad_2b2[0xe]; // 0x2b2(0x0e)

	void SetReplicateModules(bool bShouldReplicate); // Function HiveML.MLAgentModularComponent.SetReplicateModules // (Final|Native|Public) // @ game+0x8fdbfb0
	void SetActiveBehaviorByName(struct FName& BehaviorName); // Function HiveML.MLAgentModularComponent.SetActiveBehaviorByName // (Final|Native|Public|HasOutParms) // @ game+0x8fdc180
	void OnRep_bReplicateModules(); // Function HiveML.MLAgentModularComponent.OnRep_bReplicateModules // (Final|Native|Private) // @ game+0x8fdc730
	bool IsReplicatingModules(); // Function HiveML.MLAgentModularComponent.IsReplicatingModules // (Final|Native|Public|Const) // @ game+0x8fdb620
	bool HasBehaviorWithName(struct FName& BehaviorName); // Function HiveML.MLAgentModularComponent.HasBehaviorWithName // (Final|Native|Public|HasOutParms|Const) // @ game+0x8fdbd00
	int32_t GetTicksPerStep(); // Function HiveML.MLAgentModularComponent.GetTicksPerStep // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdb5f0
	char GetActiveBehaviorIndex(); // Function HiveML.MLAgentModularComponent.GetActiveBehaviorIndex // (Final|Native|Public|Const) // @ game+0x8fdc050
	struct UMLBehaviorState* GetActiveBehavior(); // Function HiveML.MLAgentModularComponent.GetActiveBehavior // (Final|Native|Public) // @ game+0x8fdc830
};

// Class HiveML.MLGameConfigurationBase
// Size: 0xf0 (Inherited: 0xa0)
struct UMLGameConfigurationBase : UObject {
	int32_t DecisionFrequency; // 0x98(0x04)
	int32_t TicksPerStep; // 0x9c(0x04)
	bool bEnableLockstepping; // 0xa0(0x01)
	int32_t TotalAgentCount; // 0xa4(0x04)
	int32_t TotalValidationAgentCount; // 0xa8(0x04)
	bool bObserveRewardScales; // 0xac(0x01)
	bool bObserveBehaviorIndex; // 0xad(0x01)
	struct FSoftClassPath TrainingComponentClass; // 0xb0(0x20)
	struct FSoftClassPath AgentPawnClass; // 0xd0(0x20)
};

// Class HiveML.MLBehaviorConfiguration
// Size: 0xc0 (Inherited: 0xa0)
struct UMLBehaviorConfiguration : UObject {
	struct FName BehaviorName; // 0x98(0x08)
	struct TArray<struct UMLModuleConfiguration*> ModuleConfigurations; // 0xa0(0x10)
	int32_t FeatureCount; // 0xb0(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// Class HiveML.MLDataAssetBase
// Size: 0xf0 (Inherited: 0xa0)
struct UMLDataAssetBase : UPrimaryDataAsset {
	struct FName AgentTypeName; // 0xa0(0x08)
	struct UMetricsCache* Metrics; // 0xa8(0x08)
	int64_t RunId; // 0xb0(0x08)
	struct UMLGameConfigurationBase* GameConfiguration; // 0xb8(0x08)
	struct TArray<struct UMLModuleConfiguration*> ModuleConfigurations; // 0xc0(0x10)
	struct TArray<struct UMLBehaviorConfiguration*> BehaviorConfigurations; // 0xd0(0x10)
	struct UMLTrainingConfigAsset* TrainingConfiguration; // 0xe0(0x08)
	char pad_e8[0x8]; // 0xe8(0x08)

	bool UpdateSchedules(); // Function HiveML.MLDataAssetBase.UpdateSchedules // (Native|Event|Public|BlueprintEvent) // @ game+0x29eeb30
	bool ToJSON(struct FString& Out); // Function HiveML.MLDataAssetBase.ToJSON // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x8fdd6d0
	void PostSetup(); // Function HiveML.MLDataAssetBase.PostSetup // (Native|Public|BlueprintCallable) // @ game+0x17031b0
	bool FromJSON(struct FString In, enum class EMLExecutionMode ExecutionMode); // Function HiveML.MLDataAssetBase.FromJSON // (Native|Event|Public|BlueprintEvent) // @ game+0x8fdcc60
};

// Class HiveML.MLIntentionComponentBase
// Size: 0x340 (Inherited: 0x160)
struct UMLIntentionComponentBase : UActorComponent {
	char pad_160[0x188]; // 0x160(0x188)
	struct TMap<struct FGameplayTag, struct UObject*> ObjectEntries; // 0x2e8(0x50)
	char pad_338[0x8]; // 0x338(0x08)

	bool TryGetVector(struct FGameplayTag Key, struct FVector& Out); // Function HiveML.MLIntentionComponentBase.TryGetVector // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf2a0
	bool TryGetObject(struct FGameplayTag Key, struct UObject*& Out); // Function HiveML.MLIntentionComponentBase.TryGetObject // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fe05f0
	bool TryGetInt(struct FGameplayTag Key, int32_t& Out); // Function HiveML.MLIntentionComponentBase.TryGetInt // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf3a0
	bool TryGetFloat(struct FGameplayTag Key, float& Out); // Function HiveML.MLIntentionComponentBase.TryGetFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdfa90
	bool TryGetBool(struct FGameplayTag Key, bool& Out); // Function HiveML.MLIntentionComponentBase.TryGetBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf4a0
	void SetVector(struct FGameplayTag Key, struct FVector Value); // Function HiveML.MLIntentionComponentBase.SetVector // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8fdecc0
	void SetObject(struct FGameplayTag Key, struct UObject* Obj); // Function HiveML.MLIntentionComponentBase.SetObject // (Final|Native|Public) // @ game+0x8fdf650
	void SetInt(struct FGameplayTag Key, int32_t Value); // Function HiveML.MLIntentionComponentBase.SetInt // (Final|Native|Public|BlueprintCallable) // @ game+0x8fdebc0
	void SetFloat(struct FGameplayTag Key, float Value); // Function HiveML.MLIntentionComponentBase.SetFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x8fdfb90
	void SetBool(struct FGameplayTag Key, bool Value); // Function HiveML.MLIntentionComponentBase.SetBool // (Final|Native|Public|BlueprintCallable) // @ game+0x8fdef40
	void SetBinding(struct FGameplayTag Key, struct FGameplayTag Binding); // Function HiveML.MLIntentionComponentBase.SetBinding // (Final|Native|Public|BlueprintCallable) // @ game+0x8fdee00
	struct FVector GetVector(struct FGameplayTag Key); // Function HiveML.MLIntentionComponentBase.GetVector // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fe04b0
	struct UObject* GetObject(struct FGameplayTag Key); // Function HiveML.MLIntentionComponentBase.GetObject // (Final|Native|Public|Const) // @ game+0x8fdf100
	int32_t GetInt(struct FGameplayTag Key); // Function HiveML.MLIntentionComponentBase.GetInt // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf900
	float GetFloat(struct FGameplayTag Key); // Function HiveML.MLIntentionComponentBase.GetFloat // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf040
	bool GetBool(struct FGameplayTag Key); // Function HiveML.MLIntentionComponentBase.GetBool // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf790
	struct FGameplayTag GetBinding(struct FGameplayTag Binding); // Function HiveML.MLIntentionComponentBase.GetBinding // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fdf5a0
};

// Class HiveML.MLModelData
// Size: 0x170 (Inherited: 0xa0)
struct UMLModelData : UPrimaryDataAsset {
	struct TArray<char> Data; // 0xa0(0x10)
	uint64_t DataSize; // 0xb0(0x08)
	struct FString SerializedConfig; // 0xb8(0x10)
	struct FString ProducerName; // 0xc8(0x10)
	struct FString ProducerVersion; // 0xd8(0x10)
	int64_t ModelVersion; // 0xe8(0x08)
	struct FString Domain; // 0xf0(0x10)
	struct FString DocString; // 0x100(0x10)
	struct TMap<struct FString, struct FString> MetaData; // 0x110(0x50)
	struct UMLDataAssetBase* DeserializedConfigurationCache; // 0x160(0x08)
	char pad_168[0x8]; // 0x168(0x08)

	bool TryGetModelInfo(struct FModelInfo& OutInfo); // Function HiveML.MLModelData.TryGetModelInfo // (Final|Native|Public|HasOutParms|Const) // @ game+0x8fe09d0
	bool GetSerializedConfiguration(struct FString& Out); // Function HiveML.MLModelData.GetSerializedConfiguration // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fe08c0
	struct UMLDataAssetBase* GetDeserializedConfiguration(struct UObject* Outer); // Function HiveML.MLModelData.GetDeserializedConfiguration // (Final|Native|Public) // @ game+0x8fe0810
};

// Class HiveML.MLModule
// Size: 0xd0 (Inherited: 0xd0)
struct UMLModule : UReplicatedSubobject {
	bool bShowDebugInfo; // 0xc8(0x01)
	bool bIsInitialized; // 0xc9(0x01)

	void ReceiveShowDebugInfo(float DeltaSeconds); // Function HiveML.MLModule.ReceiveShowDebugInfo // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void ReceiveSetVectorProperty(struct FName& Property, bool bIsEnabled, struct FVector NewValue); // Function HiveML.MLModule.ReceiveSetVectorProperty // (Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x8fe1eb0
	void ReceiveSetFloatProperty(struct FName& Property, float NewValue); // Function HiveML.MLModule.ReceiveSetFloatProperty // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x8fe2e50
	void ReceiveSetBoolProperty(struct FName& Property, bool bNewValue); // Function HiveML.MLModule.ReceiveSetBoolProperty // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x8fe1a30
	enum class EAgentResetFlags ReceiveResetFlags(); // Function HiveML.MLModule.ReceiveResetFlags // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x48d40b0
	void ReceivePrePhysicsTick(float Delta); // Function HiveML.MLModule.ReceivePrePhysicsTick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostPhysicsTick(float Delta); // Function HiveML.MLModule.ReceivePostPhysicsTick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostInitModule(struct FMLPostInitData& PostInitData); // Function HiveML.MLModule.ReceivePostInitModule // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnEnable(); // Function HiveML.MLModule.ReceiveOnEnable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnDisable(); // Function HiveML.MLModule.ReceiveOnDisable // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveObserveState(struct UObservationSet* Observation); // Function HiveML.MLModule.ReceiveObserveState // (Native|Event|Public|BlueprintEvent) // @ game+0x2b8dcf0
	void ReceiveObserveRewards(struct FHiveObservation& Observation); // Function HiveML.MLModule.ReceiveObserveRewards // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveObserveMetadata(struct FHiveObservation& Observation); // Function HiveML.MLModule.ReceiveObserveMetadata // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	enum class EHiveTerminalReason ReceiveIsTerminal(); // Function HiveML.MLModule.ReceiveIsTerminal // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x327bee0
	bool ReceiveInitModule2(struct AActor* Owner, struct UMLModuleConfiguration* Config); // Function HiveML.MLModule.ReceiveInitModule2 // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveInitModule(struct UMLAgentComponent* Agent, struct UMLModuleConfiguration* Config); // Function HiveML.MLModule.ReceiveInitModule // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct TMap<struct FString, struct FString> ReceiveGenerateDerivedData(struct UObservationSet* ObsSet); // Function HiveML.MLModule.ReceiveGenerateDerivedData // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveExtractActions(struct TArray<float>& Actions, int32_t& Offset); // Function HiveML.MLModule.ReceiveExtractActions // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveApplyActions(); // Function HiveML.MLModule.ReceiveApplyActions // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	int32_t QueryActionCount(); // Function HiveML.MLModule.QueryActionCount // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2cb7ed0
	bool InitModuleNative2(struct AActor* Owner, struct UMLModuleConfiguration* Config); // Function HiveML.MLModule.InitModuleNative2 // (Native|Public|BlueprintCallable) // @ game+0x8fe3560
	void InitModuleNative(struct UMLAgentComponent* Agent, struct UMLModuleConfiguration* Config); // Function HiveML.MLModule.InitModuleNative // (Native|Public|BlueprintCallable) // @ game+0x8fe3380
	bool Init2(struct AActor* Owner, struct UMLModuleConfiguration* Config); // Function HiveML.MLModule.Init2 // (Final|Native|Public|BlueprintCallable) // @ game+0x8fe1cb0
	void Init(struct UMLAgentComponent* Agent, struct UMLModuleConfiguration* Config); // Function HiveML.MLModule.Init // (Final|Native|Public|BlueprintCallable) // @ game+0x8fe3280
	int32_t GetCachedActionCount(); // Function HiveML.MLModule.GetCachedActionCount // (Final|Native|Public|Const) // @ game+0x8fe13e0
};

// Class HiveML.MLUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UMLUtils : UBlueprintFunctionLibrary {

	bool UClassToJsonSerializationWithOverrides(struct UObject* Object, struct FString& Result, struct FEncodeSettings& Settings, struct TSet<struct FName>& ExcludeFromWrap); // Function HiveML.MLUtils.UClassToJsonSerializationWithOverrides // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fe4730
	bool PerformDummyObservation(struct UMLAgentComponent* Component, struct FHiveObservation& DummyObs); // Function HiveML.MLUtils.PerformDummyObservation // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fe4ba0
	void LoadEngineIniSection(struct FString SectionName); // Function HiveML.MLUtils.LoadEngineIniSection // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8fe4640
	bool JsonObjectStringToUClassWithOverrides(struct FString JsonString, struct UObject* OutObject, struct TMap<struct FName, struct UObject*>& ClassOverrides, int32_t CheckFlags, int32_t SkipFlags); // Function HiveML.MLUtils.JsonObjectStringToUClassWithOverrides // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8fe4fd0
};

// Class HiveML.MLModularDataAsset
// Size: 0xf0 (Inherited: 0xf0)
struct UMLModularDataAsset : UMLDataAssetBase {
};

// Class HiveML.MLModuleConfiguration
// Size: 0xc0 (Inherited: 0xa0)
struct UMLModuleConfiguration : UDataAsset {
	int32_t MinimumVersion; // 0xa0(0x04)
	int32_t CurrentVersion; // 0xa4(0x04)
	int32_t ModuleVersion; // 0xa8(0x04)
	char pad_ac[0x4]; // 0xac(0x04)
	struct UMLModularDataAsset* Owner; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)

	bool UpdateSchedules(struct UMetricsCache* Cache); // Function HiveML.MLModuleConfiguration.UpdateSchedules // (Native|Event|Public|BlueprintEvent) // @ game+0x8fe5980
	void ResetVersion(); // Function HiveML.MLModuleConfiguration.ResetVersion // (Final|Native|Public|BlueprintCallable) // @ game+0x8fe5fd0
	void RegisterMetrics(struct UMetricsCache* Cache); // Function HiveML.MLModuleConfiguration.RegisterMetrics // (Native|Event|Public|BlueprintEvent) // @ game+0x5e4af30
	struct UObject* ReceiveGetModuleClass(); // Function HiveML.MLModuleConfiguration.ReceiveGetModuleClass // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3245140
};

// Class HiveML.ObservationSet
// Size: 0xd0 (Inherited: 0xa0)
struct UObservationSet : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class HiveML.RegistryClient
// Size: 0x120 (Inherited: 0xa0)
struct URegistryClient : UObject {
	char pad_a0[0x18]; // 0xa0(0x18)
	struct UHiveMLRegistryRpcClient* Client; // 0xb8(0x08)
	struct UHiveMLRegistryServiceRpcClient* ClientV2; // 0xc0(0x08)
	struct UHiveRegistryServiceRpcClient* ClientHV1; // 0xc8(0x08)
	char pad_d0[0x50]; // 0xd0(0x50)

	void OnConnectResponse__DelegateSignature(int64_t RunId, struct FString Configuration, struct FString Endpoint, bool bIsRestart); // DelegateFunction HiveML.RegistryClient.OnConnectResponse__DelegateSignature // (Public|Delegate) // @ game+0x4abfe0
	void OnConnectAsWorkerResponse(struct UHiveRegistryServiceRpcClient* Client, bool bSuccessful, struct FHiveConnectAsWorkerResponse& Message, struct FString ErrorMsg); // Function HiveML.RegistryClient.OnConnectAsWorkerResponse // (Final|Native|Public|HasOutParms) // @ game+0x8fe7060
};

// Class HiveML.MLTaskModifierModuleConfigurationBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMLTaskModifierModuleConfigurationBase : UDataAsset {
};

// Class HiveML.MLTaskBehaviourConfigurationBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMLTaskBehaviourConfigurationBase : UDataAsset {
};

// Class HiveML.MLTrainingConfigAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UMLTrainingConfigAsset : UDataAsset {

	bool ToJSON(struct FString& OutStr); // Function HiveML.MLTrainingConfigAsset.ToJSON // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fe8210
	void OnFullyUpgraded(); // Function HiveML.MLTrainingConfigAsset.OnFullyUpgraded // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool IsLatestVersion(); // Function HiveML.MLTrainingConfigAsset.IsLatestVersion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fe77e0
	struct UMLTrainingConfigAsset* GetUpgraded(); // Function HiveML.MLTrainingConfigAsset.GetUpgraded // (Final|Native|Public) // @ game+0x8fe8310
	struct UMLTrainingConfigAsset* GetNextVersion(); // Function HiveML.MLTrainingConfigAsset.GetNextVersion // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void FromPrevious(struct UMLTrainingConfigAsset* PreviousVersion); // Function HiveML.MLTrainingConfigAsset.FromPrevious // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool FromJSON(struct FString JsonString); // Function HiveML.MLTrainingConfigAsset.FromJSON // (Final|Native|Public|BlueprintCallable) // @ game+0x8fe74f0
};

