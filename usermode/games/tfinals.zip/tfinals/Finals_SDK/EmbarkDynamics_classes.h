// Class EmbarkDynamics.EmbarkDynamicsExactDamper
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDynamicsExactDamper : UBlueprintFunctionLibrary {
};

// Class EmbarkDynamics.EmbarkDynamicsEulerIntegrationUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDynamicsEulerIntegrationUtils : UBlueprintFunctionLibrary {
};

// Class EmbarkDynamics.EmbarkDynamicsCollision
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDynamicsCollision : UBlueprintFunctionLibrary {
};

// Class EmbarkDynamics.EmbarkDynamicsDebugDraw
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkDynamicsDebugDraw : UBlueprintFunctionLibrary {

	void DrawSpringGraph(struct UWorld* World, struct FSpringPlot& LastPlot, struct FVector& GraphOrigin, struct FLinearColor& FirstColor, struct FLinearColor& LastColor, float FirstLineThickness, float LastLineThickness, float GraphSize); // Function EmbarkDynamics.EmbarkDynamicsDebugDraw.DrawSpringGraph // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588a8d0
	void DrawOverlappingCones(struct UWorld* World, struct FTransform& Origin, struct TArray<struct FConeParameters>& ConeConstraints, float Length, int32_t NumSegments); // Function EmbarkDynamics.EmbarkDynamicsDebugDraw.DrawOverlappingCones // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587fa50
};

// Class EmbarkDynamics.EmbarkPendulumMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkPendulumMixinLibrary : UObject {

	struct FTransform Update(struct FEmbarkPendulum& Pend, struct FTransform& Origin, float DeltaSeconds, struct FVector& ExternalForces); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5880340
	void SetVelocity(struct FEmbarkPendulum& Pend, struct FVector& InVelocity); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.SetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587adb0
	void Reset(struct FEmbarkPendulum& Pend, struct FTransform& Origin); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58814d0
	void PushParticle(struct FEmbarkPendulum& Pend, struct FVector& PushVector); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.PushParticle // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588b070
	struct FVector GetVelocity(struct FEmbarkPendulum& Pend); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.GetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587e960
	struct FTransform GetResult(struct FEmbarkPendulum& Pend); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.GetResult // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587ee90
	void DebugDraw(struct FEmbarkPendulum& Pend, struct UWorld* World, struct FTransform& Origin, struct FTransform& WorldOffset); // Function EmbarkDynamics.EmbarkPendulumMixinLibrary.DebugDraw // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587bd20
};

// Class EmbarkDynamics.SimpleExactDamperMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USimpleExactDamperMixinLibrary : UObject {

	float UpdateWithTarget(struct FSimpleExactDamper& SED, float NewTarget, float DeltaSeconds); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.UpdateWithTarget // (Final|Native|Static|Public|HasOutParms) // @ game+0x587fd20
	float Update(struct FSimpleExactDamper& SED, float DeltaSeconds); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms) // @ game+0x587d5c0
	void SetVelocity(struct FSimpleExactDamper& SED, float InVelocity); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.SetVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x5889460
	void SetValue(struct FSimpleExactDamper& SED, float InValue); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.SetValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x587f610
	void SetHalfLife(struct FSimpleExactDamper& SED, float InHalfLife); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.SetHalfLife // (Final|Native|Static|Public|HasOutParms) // @ game+0x588c5d0
	void Reset(struct FSimpleExactDamper& SED); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x5885de0
	void Init(struct FSimpleExactDamper& SED, float InitValue, float InitVelocity); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms) // @ game+0x5880870
	float GetVelocity(struct FSimpleExactDamper& SED); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.GetVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x58838b0
	float GetValue(struct FSimpleExactDamper& SED); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.GetValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5879db0
	float GetHalfLife(struct FSimpleExactDamper& SED); // Function EmbarkDynamics.SimpleExactDamperMixinLibrary.GetHalfLife // (Final|Native|Static|Public|HasOutParms) // @ game+0x5882270
};

// Class EmbarkDynamics.DoubleExactDamperMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDoubleExactDamperMixinLibrary : UObject {

	float UpdateWithTarget(struct FDoubleExactDamper& DED, float NewTarget, float DeltaSeconds); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.UpdateWithTarget // (Final|Native|Static|Public|HasOutParms) // @ game+0x5881aa0
	float Update(struct FDoubleExactDamper& DED, float DeltaSeconds); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms) // @ game+0x5882bd0
	void Teleport(struct FDoubleExactDamper& DED, float InValue); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.Teleport // (Final|Native|Static|Public|HasOutParms) // @ game+0x587b870
	void SetTarget(struct FDoubleExactDamper& DED, float Target); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.SetTarget // (Final|Native|Static|Public|HasOutParms) // @ game+0x587c440
	void SetSmoothness(struct FDoubleExactDamper& DED, float InSmoothness); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.SetSmoothness // (Final|Native|Static|Public|HasOutParms) // @ game+0x588cf00
	void Reset(struct FDoubleExactDamper& DED); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x588d2c0
	void Init(struct FDoubleExactDamper& DED, float InitValue, float InitVelocity); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms) // @ game+0x58846c0
	float GetVelocity(struct FDoubleExactDamper& DED); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.GetVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x587d820
	float GetValue(struct FDoubleExactDamper& DED); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.GetValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x587db40
	float GetTarget(struct FDoubleExactDamper& DED); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.GetTarget // (Final|Native|Static|Public|HasOutParms) // @ game+0x5879eb0
	float GetSmoothness(struct FDoubleExactDamper& DED); // Function EmbarkDynamics.DoubleExactDamperMixinLibrary.GetSmoothness // (Final|Native|Static|Public|HasOutParms) // @ game+0x5884210
};

// Class EmbarkDynamics.DoubleExactDamperVecMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UDoubleExactDamperVecMixinLibrary : UObject {

	struct FVector UpdateWithTarget(struct FDoubleExactDamperVec& DED, struct FVector& NewTarget, float DeltaSeconds); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.UpdateWithTarget // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5888510
	struct FVector Update(struct FDoubleExactDamperVec& DED, float DeltaSeconds); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5884360
	void SetTarget(struct FDoubleExactDamperVec& DED, struct FVector& Target); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.SetTarget // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5887010
	void SetSmoothness(struct FDoubleExactDamperVec& DED, struct FVector& InSmoothness); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.SetSmoothness // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58879a0
	void Reset(struct FDoubleExactDamperVec& DED); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x5887c00
	void Init(struct FDoubleExactDamperVec& DED, struct FVector& InitValue, struct FVector& InitVelocity); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5881830
	struct FVector GetVelocity(struct FDoubleExactDamperVec& DED); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.GetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58882a0
	struct FVector GetValue(struct FDoubleExactDamperVec& DED); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.GetValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588a6e0
	struct FVector GetTarget(struct FDoubleExactDamperVec& DED); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.GetTarget // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5888890
	struct FVector GetSmoothness(struct FDoubleExactDamperVec& DED); // Function EmbarkDynamics.DoubleExactDamperVecMixinLibrary.GetSmoothness // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587e0b0
};

// Class EmbarkDynamics.SODSpringFloatMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USODSpringFloatMixinLibrary : UObject {

	void Update(struct FSODSpringFloat& SOD, float NewTarget, float DeltaSeconds); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms) // @ game+0x5882710
	void TeleportTo(struct FSODSpringFloat& SOD, float NewValue); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.TeleportTo // (Final|Native|Static|Public|HasOutParms) // @ game+0x5885ff0
	void SetVelocity(struct FSODSpringFloat& SOD, float InVelocity); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.SetVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x5884850
	void SetValue(struct FSODSpringFloat& SOD, float InValue); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.SetValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5884000
	void SetParameters(struct FSODSpringFloat& SOD, struct FSecondOrderDynamicParameters InParams); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.SetParameters // (Final|Native|Static|Public|HasOutParms) // @ game+0x5885a40
	void Reset(struct FSODSpringFloat& SOD); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x588bef0
	float GetVelocity(struct FSODSpringFloat& SOD); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.GetVelocity // (Final|Native|Static|Public|HasOutParms) // @ game+0x588ac10
	float GetValue(struct FSODSpringFloat& SOD); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.GetValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x5886d10
	float GetAcceleration(struct FSODSpringFloat& SOD); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.GetAcceleration // (Final|Native|Static|Public|HasOutParms) // @ game+0x587da70
	void Compute(struct FSODSpringFloat& SOD, float Frequency, float Damping, float Response); // Function EmbarkDynamics.SODSpringFloatMixinLibrary.Compute // (Final|Native|Static|Public|HasOutParms) // @ game+0x588d3a0
};

// Class EmbarkDynamics.SODSpringVectorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USODSpringVectorMixinLibrary : UObject {

	void Update(struct FSODSpringVector& SOD, struct FVector NewTarget, float DeltaSeconds); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58869d0
	void TeleportTo(struct FSODSpringVector& SOD, struct FVector NewValue); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.TeleportTo // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58831a0
	void SetVelocity(struct FSODSpringVector& SOD, struct FVector InVelocity); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.SetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5887540
	void SetValue(struct FSODSpringVector& SOD, struct FVector InValue); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.SetValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587ac40
	void SetParameters(struct FSODSpringVector& SOD, struct FSecondOrderDynamicParameters InParams); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.SetParameters // (Final|Native|Static|Public|HasOutParms) // @ game+0x588c970
	void ResetTo(struct FSODSpringVector& SOD, struct FVector InResetTo); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.ResetTo // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588cd90
	void Reset(struct FSODSpringVector& SOD); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x588a180
	struct FVector GetVelocity(struct FSODSpringVector& SOD); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.GetVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587bbd0
	struct FVector GetValue(struct FSODSpringVector& SOD); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.GetValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5885ea0
	struct FVector GetAcceleration(struct FSODSpringVector& SOD); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.GetAcceleration // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5889760
	void Compute(struct FSODSpringVector& SOD, float Frequency, float Damping, float Response); // Function EmbarkDynamics.SODSpringVectorMixinLibrary.Compute // (Final|Native|Static|Public|HasOutParms) // @ game+0x587b520
};

// Class EmbarkDynamics.MinJerkMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMinJerkMixinLibrary : UObject {

	double Update(struct FMinJerk& MinJerk, double Target, double TimeHorizon, double DeltaSeconds); // Function EmbarkDynamics.MinJerkMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms) // @ game+0x587cad0
	void Reset(struct FMinJerk& MinJerk); // Function EmbarkDynamics.MinJerkMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x58825f0
	bool IsSleeping(struct FMinJerk& MinJerk); // Function EmbarkDynamics.MinJerkMixinLibrary.IsSleeping // (Final|Native|Static|Public|HasOutParms) // @ game+0x58810c0
	void Init(struct FMinJerk& MinJerk, double ResetValue, double ResetSpeed, double ResetAccel); // Function EmbarkDynamics.MinJerkMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms) // @ game+0x587f2a0
};

// Class EmbarkDynamics.MinJerkVecMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMinJerkVecMixinLibrary : UObject {

	struct FVector Update(struct FMinJerkVec& MinJerkVec, struct FVector& TargetVec, float TimeHorizon, float DeltaSeconds); // Function EmbarkDynamics.MinJerkVecMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587f760
	void SetTarget(struct FMinJerkVec& MinJerkVec, struct FVector& Target); // Function EmbarkDynamics.MinJerkVecMixinLibrary.SetTarget // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58895b0
	void Reset(struct FMinJerkVec& MinJerkVec); // Function EmbarkDynamics.MinJerkVecMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x588c340
	bool IsSleeping(struct FMinJerkVec& MinJerkVec); // Function EmbarkDynamics.MinJerkVecMixinLibrary.IsSleeping // (Final|Native|Static|Public|HasOutParms) // @ game+0x58867e0
	void InitFromRotator(struct FMinJerkVec& MinJerkVec, struct FRotator& Rotation, struct FRotator& Velocity, struct FRotator& Acceleration); // Function EmbarkDynamics.MinJerkVecMixinLibrary.InitFromRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58835f0
	void Init(struct FMinJerkVec& MinJerkVec, struct FVector& CurrentVector, struct FVector& Velocity, struct FVector& Acceleration); // Function EmbarkDynamics.MinJerkVecMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58835f0
	struct FVector GetVelocityAsVector(struct FMinJerkVec& MinJerkVec); // Function EmbarkDynamics.MinJerkVecMixinLibrary.GetVelocityAsVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5882fb0
	struct FVector GetAsVector(struct FMinJerkVec& MinJerkVec); // Function EmbarkDynamics.MinJerkVecMixinLibrary.GetAsVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5884560
	struct FRotator GetAsRotator(struct FMinJerkVec& MinJerkVec); // Function EmbarkDynamics.MinJerkVecMixinLibrary.GetAsRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5884560
	struct FVector GetAccelerationAsVector(struct FMinJerkVec& MinJerkVec); // Function EmbarkDynamics.MinJerkVecMixinLibrary.GetAccelerationAsVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5884cf0
};

// Class EmbarkDynamics.MinJerkVec2DMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMinJerkVec2DMixinLibrary : UObject {

	struct FVector2D Update(struct FMinJerkVec2D& MinJerkVec, struct FVector2D& TargetVec, float TimeHorizon, float DeltaSeconds); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587d240
	void Reset(struct FMinJerkVec2D& MinJerkVec); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x587ccf0
	bool IsSleeping(struct FMinJerkVec2D& MinJerkVec); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.IsSleeping // (Final|Native|Static|Public|HasOutParms) // @ game+0x5886660
	void InitFromRotator(struct FMinJerkVec2D& MinJerkVec, struct FRotator& Rotation, struct FRotator& Velocity, struct FRotator& Acceleration); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.InitFromRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5879f90
	void Init(struct FMinJerkVec2D& MinJerkVec, struct FVector2D& CurrentVector, struct FVector2D& Velocity, struct FVector2D& Acceleration); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5881f50
	struct FVector2D GetVelocityAsVector(struct FMinJerkVec2D& MinJerkVec); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.GetVelocityAsVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5880fa0
	struct FVector2D GetAsVector2D(struct FMinJerkVec2D& MinJerkVec); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.GetAsVector2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5886370
	struct FRotator GetAsRotator(struct FMinJerkVec2D& MinJerkVec); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.GetAsRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588c000
	struct FVector2D GetAccelerationAsVector(struct FMinJerkVec2D& MinJerkVec); // Function EmbarkDynamics.MinJerkVec2DMixinLibrary.GetAccelerationAsVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588c850
};

// Class EmbarkDynamics.SimpleSpringDamperMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USimpleSpringDamperMixinLibrary : UObject {

	void Update(struct FSimpleSpringDamper& Spring, float DeltaTime, int32_t NumSubsteps); // Function EmbarkDynamics.SimpleSpringDamperMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms) // @ game+0x5889270
	void Reset(struct FSimpleSpringDamper& Spring); // Function EmbarkDynamics.SimpleSpringDamperMixinLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x5887d70
	void Init(struct FSimpleSpringDamper& Spring, float InitValue, float InitVelocity); // Function EmbarkDynamics.SimpleSpringDamperMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms) // @ game+0x588d8a0
};

// Class EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USimpleSpringDamperVectorMixinLibrary : UObject {

	void Update(struct FSimpleSpringDamperVector& SpringVec, float DeltaTime, int32_t NumSubsteps); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.Update // (Final|Native|Static|Public|HasOutParms) // @ game+0x5887e60
	void SetValueWrap(struct FSimpleSpringDamperVector& SpringVec, struct FVector2D& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetValueWrap // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587ced0
	void SetValueRotator(struct FSimpleSpringDamperVector& SpringVec, struct FRotator& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetValueRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5880a40
	void SetValueClamp(struct FSimpleSpringDamperVector& SpringVec, struct FVector2D& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetValueClamp // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587c7b0
	void SetValue(struct FSimpleSpringDamperVector& SpringVec, struct FVector& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5882890
	void SetTargetRotator(struct FSimpleSpringDamperVector& SpringVec, struct FRotator& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetTargetRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587ec80
	void SetTarget(struct FSimpleSpringDamperVector& SpringVec, struct FVector& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetTarget // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587b310
	void SetStiffness(struct FSimpleSpringDamperVector& SpringVec, float InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetStiffness // (Final|Native|Static|Public|HasOutParms) // @ game+0x587a270
	void SetDamping(struct FSimpleSpringDamperVector& SpringVec, float InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetDamping // (Final|Native|Static|Public|HasOutParms) // @ game+0x5889870
	void SetCriticalStretchTransitionSize(struct FSimpleSpringDamperVector& SpringVec, float InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetCriticalStretchTransitionSize // (Final|Native|Static|Public|HasOutParms) // @ game+0x5882410
	void SetCriticalStretchStiffness(struct FSimpleSpringDamperVector& SpringVec, float InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetCriticalStretchStiffness // (Final|Native|Static|Public|HasOutParms) // @ game+0x588bbd0
	void SetCriticalStretchLimits(struct FSimpleSpringDamperVector& SpringVec, struct FVector2D& InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetCriticalStretchLimits // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x58871e0
	void SetCriticalStretchDamping(struct FSimpleSpringDamperVector& SpringVec, float InVal); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.SetCriticalStretchDamping // (Final|Native|Static|Public|HasOutParms) // @ game+0x58854f0
	struct FVector GetVector(struct FSimpleSpringDamperVector& SpringVec); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.GetVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587a500
	struct FRotator GetRotator(struct FSimpleSpringDamperVector& SpringVec); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.GetRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x587c1a0
	void AddVelocityRotator(struct FSimpleSpringDamperVector& SpringVec, struct FRotator& Velocity); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.AddVelocityRotator // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5880ce0
	void AddVelocity(struct FSimpleSpringDamperVector& SpringVec, struct FVector& Velocity); // Function EmbarkDynamics.SimpleSpringDamperVectorMixinLibrary.AddVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x588ace0
};

