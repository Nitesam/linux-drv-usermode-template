// Enum EmbarkUI.EEmbarkButtonState
enum class EEmbarkButtonState : uint8_t {
	Normal = 0,
	Highlight = 1,
	Pressed = 2,
	EEmbarkButtonState_MAX = 3
};

// Enum EmbarkUI.EUITextureDownloadFailure
enum class EUITextureDownloadFailure : uint8_t {
	Undefined = 0,
	InvalidRequest = 1,
	CacheLoadFailed = 2,
	DownloadFailed = 3,
	DownloadReturnedError = 4,
	TextureCreationFailed = 5,
	StreamingTextureInvalid = 6,
	OptionalTextureNotProvided = 7,
	EUITextureDownloadFailure_MAX = 8
};

// Enum EmbarkUI.EEmbarkWidgetInputMode
enum class EEmbarkWidgetInputMode : uint8_t {
	Default = 0,
	GameAndMenu = 1,
	Game = 2,
	Menu = 3,
	MenuHiddenMouse = 4,
	EEmbarkWidgetInputMode_MAX = 5
};

// Enum EmbarkUI.ETransitionDirection
enum class ETransitionDirection : uint8_t {
	Forward = 0,
	Backward = 1,
	ETransitionDirection_MAX = 2
};

// Enum EmbarkUI.EUIConceptArtLoadingScreenSelectionStrategy
enum class EUIConceptArtLoadingScreenSelectionStrategy : uint8_t {
	Random = 0,
	Single = 1,
	EUIConceptArtLoadingScreenSelectionStrategy_MAX = 2
};

// Enum EmbarkUI.EMaterialBoxScaling
enum class EMaterialBoxScaling : uint8_t {
	ReLayout = 0,
	UniformResize = 1,
	Oversize = 2,
	EMaterialBoxScaling_MAX = 3
};

// Enum EmbarkUI.EUIWidgetProjectionStatus
enum class EUIWidgetProjectionStatus : uint8_t {
	OnScreen = 0,
	OffScreen = 1,
	EUIWidgetProjectionStatus_MAX = 2
};

// Enum EmbarkUI.EUIColorState
enum class EUIColorState : uint8_t {
	Neutral = 0,
	Positive = 1,
	Negative = 2,
	Highlight = 3,
	SquadMember1 = 4,
	SquadMember2 = 5,
	SquadMember3 = 6,
	RarityNone = 7,
	RarityCommon = 8,
	RarityRare = 9,
	RarityEpic = 10,
	RarityLegendary = 11,
	Friend = 12,
	Enemy = 13,
	Self = 14,
	SecondaryLight = 15,
	SecondaryMid = 16,
	SecondaryDark = 17,
	SecondaryPale = 18,
	Debug = 19,
	PlayerSquad = 20,
	OtherSquad = 21,
	ConstructableCore = 22,
	Primary = 23,
	Secondary = 24,
	ObjectiveMarker = 25,
	Complementary = 26,
	Headshot = 27,
	Seasonal = 28,
	SeasonalDark = 29,
	PioneerBrand1 = 30,
	PioneerBrand2 = 31,
	PioneerBrand3 = 32,
	PioneerBrand4 = 33,
	Tertiary = 34,
	RarityMythic = 35,
	OfficialTeam = 36,
	EUIColorState_MAX = 37
};

// Enum EmbarkUI.EUIOpacityState
enum class EUIOpacityState : uint8_t {
	Default = 0,
	Locked = 1,
	Backplate = 2,
	BackplateEmphasis = 3,
	Opacity1 = 4,
	Opacity2 = 5,
	Opacity3 = 6,
	Opacity4 = 7,
	Transparent = 8,
	EUIOpacityState_MAX = 9
};

// Enum EmbarkUI.EEmbarkUITextType
enum class EEmbarkUITextType : uint8_t {
	H1 = 0,
	H2 = 1,
	H3 = 2,
	H4 = 3,
	H5 = 4,
	H5_5 = 5,
	H6 = 6,
	Paragraph = 7,
	Subheader1 = 8,
	Subheader2 = 9,
	Body = 10,
	BodyEmphasis = 11,
	Caption = 12,
	Overline = 13,
	Button = 14,
	ButtonEmphasis = 15,
	InputKey = 16,
	Details = 17,
	SubtitleSmall = 18,
	SubtitleMedium = 19,
	SubtitleLarge = 20,
	HUD1 = 21,
	HUD2 = 22,
	HUD3 = 23,
	HUD4 = 24,
	HUD5 = 25,
	HUD6 = 26,
	BodyTooltip = 27,
	TagTooltip = 28,
	ExtraLarge = 29,
	MonoH1 = 30,
	PlayerName = 31,
	EEmbarkUITextType_MAX = 32
};

// Enum EmbarkUI.EUIAnimationParticipantState
enum class EUIAnimationParticipantState : uint8_t {
	Idle = 0,
	Before = 1,
	During = 2,
	After = 3,
	GlobalDone = 4,
	EUIAnimationParticipantState_MAX = 5
};

// Enum EmbarkUI.EUITextureProviderState
enum class EUITextureProviderState : uint8_t {
	Uninitialized = 0,
	Loading = 1,
	ContentReady = 2,
	ContentFailed = 3,
	EUITextureProviderState_MAX = 4
};

// ScriptStruct EmbarkUI.SuperUIHotspot
// Size: 0x50 (Inherited: 0x00)
struct FSuperUIHotspot {
	struct FVector2D Location; // 0x00(0x10)
	struct FVector2D Size; // 0x10(0x10)
	int64_t WidgetId; // 0x20(0x08)
	int32_t Layer; // 0x28(0x04)
	char pad_2c[0x4]; // 0x2c(0x04)
	struct FSuperUIAction Action; // 0x30(0x20)
};

// ScriptStruct EmbarkUI.SuperUIAction
// Size: 0x20 (Inherited: 0x00)
struct FSuperUIAction {
	struct FName Namespace; // 0x00(0x08)
	struct FName Command; // 0x08(0x08)
	int64_t Arg1; // 0x10(0x08)
	int64_t Arg2; // 0x18(0x08)
};

// ScriptStruct EmbarkUI.SuperUIMakeViewContext
// Size: 0x28 (Inherited: 0x00)
struct FSuperUIMakeViewContext {
	struct USuperUIDraw* Draw; // 0x00(0x08)
	struct TArray<struct FSuperUIInput> Inputs; // 0x08(0x10)
	float DeltaTime; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
	double CurrentTime; // 0x20(0x08)
};

// ScriptStruct EmbarkUI.SuperUIInput
// Size: 0x80 (Inherited: 0x00)
struct FSuperUIInput {
	struct FKey Key; // 0x00(0x18)
	struct FVector2D Location; // 0x18(0x10)
	enum class EInputEvent InputEvent; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FSuperUIHotspot HotSpot; // 0x30(0x50)
};

// ScriptStruct EmbarkUI.EmbarkOptionalSlateSound
// Size: 0x20 (Inherited: 0x00)
struct FEmbarkOptionalSlateSound {
	bool bHasSound; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSlateSound Sound; // 0x08(0x18)
};

// ScriptStruct EmbarkUI.EmbarkDesktopNotificationParams
// Size: 0x14 (Inherited: 0x00)
struct FEmbarkDesktopNotificationParams {
	float FadeInDuration; // 0x00(0x04)
	float FadeOutDuration; // 0x04(0x04)
	float ExpireDuration; // 0x08(0x04)
	float Width; // 0x0c(0x04)
	bool bShowOnlyWhenGameIsInBackground; // 0x10(0x01)
	bool bUseDefaultNotificationBackgroud; // 0x11(0x01)
	char pad_12[0x2]; // 0x12(0x02)
};

// ScriptStruct EmbarkUI.EmbarkTabDescriptor
// Size: 0x50 (Inherited: 0x00)
struct FEmbarkTabDescriptor {
	struct FName TabId; // 0x00(0x08)
	struct FText TabText; // 0x08(0x18)
	struct FString FeatureFlag; // 0x20(0x10)
	bool bHidden; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct UCommonButtonBase* TabButtonType; // 0x38(0x08)
	struct UCommonUserWidget* TabContentType; // 0x40(0x08)
	struct UWidget* CreatedTabContentWidget; // 0x48(0x08)
};

// ScriptStruct EmbarkUI.UILoadingScreenConfiguration
// Size: 0x80 (Inherited: 0x00)
struct FUILoadingScreenConfiguration {
	struct FSoftObjectPath BackgroundImageRef; // 0x00(0x20)
	struct FText Title1; // 0x20(0x18)
	struct FText Title2; // 0x38(0x18)
	struct FText Information1; // 0x50(0x18)
	struct FText Information2; // 0x68(0x18)
};

// ScriptStruct EmbarkUI.UIWorldToWidgetProjectionResult
// Size: 0x18 (Inherited: 0x00)
struct FUIWorldToWidgetProjectionResult {
	struct FVector2D ScreenPosition; // 0x00(0x10)
	enum class EUIWidgetProjectionStatus Status; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct EmbarkUI.EmbarkUIStyleCustomizableEnumColor
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkUIStyleCustomizableEnumColor {
	struct FName Tag; // 0x00(0x08)
};

// ScriptStruct EmbarkUI.EmbarkUIStyleCustomizableEnumOpacity
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkUIStyleCustomizableEnumOpacity {
	struct FName Tag; // 0x00(0x08)
};

// ScriptStruct EmbarkUI.EmbarkUIStyleCustomizableEnumTextStyle
// Size: 0x08 (Inherited: 0x00)
struct FEmbarkUIStyleCustomizableEnumTextStyle {
	struct FName Tag; // 0x00(0x08)
};

// ScriptStruct EmbarkUI.EmbarkUIStyleOption
// Size: 0x88 (Inherited: 0x00)
struct FEmbarkUIStyleOption {
	int32_t EnumValue; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FText Label; // 0x08(0x18)
	struct FLinearColor Color; // 0x20(0x10)
	struct FSlateFontInfo Font; // 0x30(0x58)
};

// ScriptStruct EmbarkUI.AudioTriggerAnimationCache
// Size: 0x18 (Inherited: 0x00)
struct FAudioTriggerAnimationCache {
	struct USoundBase* Sound; // 0x00(0x08)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct EmbarkUI.EventTriggerAnimationCache
// Size: 0x10 (Inherited: 0x00)
struct FEventTriggerAnimationCache {
	struct UFunction* EventFunction; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct EmbarkUI.ObjectAnimationPlayCache
// Size: 0x80 (Inherited: 0x00)
struct FObjectAnimationPlayCache {
	struct UObject* BindingObject; // 0x00(0x08)
	char pad_8[0x78]; // 0x08(0x78)
};

// ScriptStruct EmbarkUI.WidgetAnimationRuntimePlayCache
// Size: 0x88 (Inherited: 0x00)
struct FWidgetAnimationRuntimePlayCache {
	struct UWidgetAnimation* WidgetAnimation; // 0x00(0x08)
	struct UUserWidget* UserWidget; // 0x08(0x08)
	struct TArray<struct FObjectAnimationPlayCache> ObjectAnimations; // 0x10(0x10)
	struct TArray<struct FObjectAnimationPlayCache> MaterialObjectAnimations; // 0x20(0x10)
	struct TArray<struct FAudioTriggerAnimationCache> AudioTriggerAnimations; // 0x30(0x10)
	struct TArray<struct FEventTriggerAnimationCache> EventTriggerAnimations; // 0x40(0x10)
	char pad_50[0x38]; // 0x50(0x38)
};

// ScriptStruct EmbarkUI.PooledDynamicMaterial
// Size: 0x28 (Inherited: 0x00)
struct FPooledDynamicMaterial {
	struct UObject* OwningUserWidget; // 0x00(0x08)
	struct UObject* MaterialUser; // 0x08(0x08)
	struct UMaterialInstanceDynamic* Material; // 0x10(0x08)
	char pad_18[0x10]; // 0x18(0x10)
};

// ScriptStruct EmbarkUI.EmbarkWidgetAnimationArray
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkWidgetAnimationArray {
	struct TArray<struct UWidgetAnimation*> WidgetAnimations; // 0x00(0x10)
};

// ScriptStruct EmbarkUI.EmbarkWidgetAnimationIdNames
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkWidgetAnimationIdNames {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct EmbarkUI.QueuedWidgetAnimation
// Size: 0x18 (Inherited: 0x00)
struct FQueuedWidgetAnimation {
	struct UUserWidget* Widget; // 0x00(0x08)
	struct UWidgetAnimation* Animation; // 0x08(0x08)
	char pad_10[0x8]; // 0x10(0x08)
};

// ScriptStruct EmbarkUI.PerformanceOverlayStats
// Size: 0x1c (Inherited: 0x00)
struct FPerformanceOverlayStats {
	float AverageFPS; // 0x00(0x04)
	int32_t NumFramesPresented; // 0x04(0x04)
	float AverageFrameTimeMs; // 0x08(0x04)
	float GameThreadFrameTimeMs; // 0x0c(0x04)
	float RenderThreadFrameTimeMs; // 0x10(0x04)
	float RHIThreadFrameTimeMs; // 0x14(0x04)
	float GPUFrameTimeMs; // 0x18(0x04)
};

// ScriptStruct EmbarkUI.DeveloperPerformanceOverlayStats
// Size: 0x58 (Inherited: 0x00)
struct FDeveloperPerformanceOverlayStats {
	struct FString HardwareString; // 0x00(0x10)
	struct FIntPoint DisplayResolution; // 0x10(0x08)
	struct FIntPoint UpscaledResolution; // 0x18(0x08)
	struct FIntPoint RenderResolution; // 0x20(0x08)
	struct FString ResolutionScalingMethod; // 0x28(0x10)
	float MemUsedPhysicalGB; // 0x38(0x04)
	float MemTotalPhysicalGB; // 0x3c(0x04)
	float VRAMUsedGB; // 0x40(0x04)
	float VRAMBudgetGB; // 0x44(0x04)
	float VRAMTotalGB; // 0x48(0x04)
	float StreamingRequiredMB; // 0x4c(0x04)
	float StreamingPoolSizeMB; // 0x50(0x04)
	int32_t NumDrawsSkipped; // 0x54(0x04)
};

// ScriptStruct EmbarkUI.ScrollParameters
// Size: 0x14 (Inherited: 0x00)
struct FScrollParameters {
	float Speed; // 0x00(0x04)
	float StartDelay; // 0x04(0x04)
	float EndDelay; // 0x08(0x04)
	float FadeInDelay; // 0x0c(0x04)
	float FadeOutDelay; // 0x10(0x04)
};

// ScriptStruct EmbarkUI.SuperUILayout
// Size: 0x28 (Inherited: 0x00)
struct FSuperUILayout {
	struct FVector2D Location; // 0x00(0x10)
	struct FVector2D Size; // 0x10(0x10)
	int32_t Layer; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct EmbarkUI.UIAnimationTickParameter
// Size: 0x80 (Inherited: 0x00)
struct FUIAnimationTickParameter {
	float FrameDeltaTime; // 0x00(0x04)
	float ParticipantAnimationProgress; // 0x04(0x04)
	float GlobalAnimationProgress; // 0x08(0x04)
	enum class EUIAnimationParticipantState ParticipantAnimationState; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	struct FGeometry DriverGeometry; // 0x10(0x38)
	struct FGeometry ParticipantGeometry; // 0x48(0x38)
};

// ScriptStruct EmbarkUI.WatermarkGrid
// Size: 0x0c (Inherited: 0x00)
struct FWatermarkGrid {
	int32_t Rows; // 0x00(0x04)
	int32_t Columns; // 0x04(0x04)
	int32_t base; // 0x08(0x04)
};

