// Class EmbarkAbilitySystem.ActiveGameplayEffectHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UActiveGameplayEffectHandleMixinLibrary : UObject {

	bool IsValid(struct FActiveGameplayEffectHandle& Handle); // Function EmbarkAbilitySystem.ActiveGameplayEffectHandleMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5a3dce0
	void Invalidate(struct FActiveGameplayEffectHandle& Handle); // Function EmbarkAbilitySystem.ActiveGameplayEffectHandleMixinLibrary.Invalidate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5a46fc0
	struct UAbilitySystemComponent* GetOwningAbilitySystemComponent(struct FActiveGameplayEffectHandle& Handle); // Function EmbarkAbilitySystem.ActiveGameplayEffectHandleMixinLibrary.GetOwningAbilitySystemComponent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5a3cd80
};

// Class EmbarkAbilitySystem.AdditionalEffectsWithSetByCallerGameplayEffectComponent
// Size: 0xb0 (Inherited: 0xa0)
struct UAdditionalEffectsWithSetByCallerGameplayEffectComponent : UGameplayEffectComponent {
	bool bOnApplicationCopyDataFromOriginalSpec; // 0x98(0x01)
	struct TArray<struct FAdditionalEffectsWithSetByCallerEffects> OnAppliedEffects; // 0xa0(0x10)
};

// Class EmbarkAbilitySystem.EmbarkAbilitySystemComponent
// Size: 0x14c0 (Inherited: 0x1400)
struct UEmbarkAbilitySystemComponent : UAngelscriptAbilitySystemComponent {
	struct FMulticastInlineDelegate OnAbilityGranted; // 0x1400(0x10)
	struct FMulticastInlineDelegate OnEmbarkGameplayEffectAppliedDelegateToSelf; // 0x1410(0x10)
	struct FMulticastInlineDelegate OnEmbarkGameplayEffectAppliedDelegateToTarget; // 0x1420(0x10)
	struct FMulticastInlineDelegate OnEmbarkGameplayEffectRemovedDelegate; // 0x1430(0x10)
	bool bEnableForceReplication; // 0x1440(0x01)
	char pad_1441[0x7f]; // 0x1441(0x7f)

	void UnregisterGameplayTagEventWithParentRangeAll(struct FGameplayTag& StartTag, struct FGameplayTag& EndTag, struct UObject* Object, enum class EEmbarkGameplayTagEventType EventType); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.UnregisterGameplayTagEventWithParentRangeAll // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a3baa0
	void UnregisterGameplayTagEventWithParentRange(struct FGameplayTag& StartTag, struct FGameplayTag& EndTag, struct TArray<struct FDelegateHandleHolder>& DelegateHolders, enum class EEmbarkGameplayTagEventType EventType); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.UnregisterGameplayTagEventWithParentRange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a360f0
	void UnregisterGameplayTagEventsExactAll(struct FGameplayTag& Tag, struct UObject* Object, enum class EEmbarkGameplayTagEventType EventType); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.UnregisterGameplayTagEventsExactAll // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a408e0
	void UnregisterGameplayTagEventExact(struct FGameplayTag& Tag, struct FDelegateHandleHolder DelegateHolder, enum class EEmbarkGameplayTagEventType EventType); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.UnregisterGameplayTagEventExact // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a46050
	bool TryActivateAllAbilitiesByClass(struct UGameplayAbility* InAbilityToActivate, bool bAllowRemoteActivation); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.TryActivateAllAbilitiesByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x5a3c150
	bool TriggerAbilityFromGameplayEvent(struct FGameplayAbilitySpecHandle Handle, struct FGameplayTag& EventTag, struct FGameplayEventData& Payload); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.TriggerAbilityFromGameplayEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a494e0
	void RemoveMinimalTagsAndUnsubscribeFromChanges(); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.RemoveMinimalTagsAndUnsubscribeFromChanges // (Final|Native|Public) // @ game+0x5a48360
	struct TArray<struct FDelegateHandleHolder> RegisterGameplayTagEventWithParentRange(struct FGameplayTag& StartTag, struct FGameplayTag& EndTag, struct UObject* Object, struct FName& FunctionName, enum class EEmbarkGameplayTagEventType EventType); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.RegisterGameplayTagEventWithParentRange // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a36990
	struct FDelegateHandleHolder RegisterGameplayTagEventExact(struct FGameplayTag& Tag, struct UObject* Object, struct FName FunctionName, enum class EEmbarkGameplayTagEventType EventType); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.RegisterGameplayTagEventExact // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a34e90
	void ReAddMinimalTagsAndSubscribeToChanges(); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.ReAddMinimalTagsAndSubscribeToChanges // (Final|Native|Public) // @ game+0x5a342f0
	void OnAbilityEndedWithDataCallback(struct FAbilityEndedData& EndedData); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.OnAbilityEndedWithDataCallback // (Final|Native|Private|HasOutParms) // @ game+0x5a46c60
	struct FGameplayTagContainer GetMovementCancelAbilitiesWithTagsBuffer(); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.GetMovementCancelAbilitiesWithTagsBuffer // (Final|Native|Public|Const) // @ game+0x5a3fb50
	void EndEmbarkAbilityByHandle(struct FGameplayAbilitySpecHandle Handle); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.EndEmbarkAbilityByHandle // (Final|Native|Public|BlueprintCallable) // @ game+0x5a471c0
	void EndEmbarkAbilitiesByTags(struct FGameplayTagContainer& WithTags, struct FGameplayTagContainer& WithoutTags); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.EndEmbarkAbilitiesByTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a44170
	void ClearMovementCancelAbilitiesWithTagsBuffer(); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.ClearMovementCancelAbilitiesWithTagsBuffer // (Final|Native|Public) // @ game+0x5a49ff0
	void CancelAllActiveAbilities(struct UGameplayAbility* Ignore); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.CancelAllActiveAbilities // (Final|Native|Public|BlueprintCallable) // @ game+0x5a3e730
	struct FActiveGameplayEffectHandle ApplyGameplayEffectSpecDirectToTarget(struct FGameplayEffectSpec& Spec, struct UAbilitySystemComponent* Target); // Function EmbarkAbilitySystem.EmbarkAbilitySystemComponent.ApplyGameplayEffectSpecDirectToTarget // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5a3f1f0
};

// Class EmbarkAbilitySystem.EmbarkAbilitySystemComponent_MixedReplication
// Size: 0x14c0 (Inherited: 0x14c0)
struct UEmbarkAbilitySystemComponent_MixedReplication : UEmbarkAbilitySystemComponent {
};

// Class EmbarkAbilitySystem.EmbarkAbilitySystemComponent_MinimalReplication
// Size: 0x14c0 (Inherited: 0x14c0)
struct UEmbarkAbilitySystemComponent_MinimalReplication : UEmbarkAbilitySystemComponent {
};

// Class EmbarkAbilitySystem.EmbarkAbilitySystemGlobals
// Size: 0x320 (Inherited: 0x320)
struct UEmbarkAbilitySystemGlobals : UAbilitySystemGlobals {
};

// Class EmbarkAbilitySystem.EmbarkGameplayCueUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkGameplayCueUtils : UBlueprintFunctionLibrary {

	void RemoveLocalGameplayCue(struct AActor* TargetActor, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& Parameters); // Function EmbarkAbilitySystem.EmbarkGameplayCueUtils.RemoveLocalGameplayCue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fad890
	void ExecuteLocalGameplayCue(struct AActor* TargetActor, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& Parameters); // Function EmbarkAbilitySystem.EmbarkGameplayCueUtils.ExecuteLocalGameplayCue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4fae070
	void AddLocalGameplayCue(struct AActor* TargetActor, struct FGameplayTag GameplayCueTag, struct FGameplayCueParameters& Parameters); // Function EmbarkAbilitySystem.EmbarkGameplayCueUtils.AddLocalGameplayCue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x4faa590
};

// Class EmbarkAbilitySystem.EmbarkAbilitySystemUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAbilitySystemUtils : UBlueprintFunctionLibrary {

	bool IsGameplayAbilitySpecHandleValid(struct FGameplayAbilitySpecHandle& Handle); // Function EmbarkAbilitySystem.EmbarkAbilitySystemUtils.IsGameplayAbilitySpecHandleValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5a469d0
	struct FGameplayAbilityTargetData_LocationInfo GetTargetDataLocationInfo(struct FGameplayAbilityTargetDataHandle Handle, int32_t Index); // Function EmbarkAbilitySystem.EmbarkAbilitySystemUtils.GetTargetDataLocationInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a48b00
	struct FGameplayAbilityTargetDataHandle CreateEmbarkScriptStructTargetData(); // Function EmbarkAbilitySystem.EmbarkAbilitySystemUtils.CreateEmbarkScriptStructTargetData // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a39860
};

// Class EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2
// Size: 0xa0 (Inherited: 0xa0)
struct UAbilitySystemComponentMixinLibrary2 : UObject {

	bool IsAbilityGrantedByEffect(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpecHandle& Handle); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.IsAbilityGrantedByEffect // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a3e030
	struct FGameplayEffectContextHandle GetGameplayEffectContext(struct UAbilitySystemComponent* AbilitySystemComponent, struct FActiveGameplayEffectHandle& Handle); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.GetGameplayEffectContext // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a351f0
	float GetDurationForEffect(struct UAbilitySystemComponent* AbilitySystemComponent, struct FActiveGameplayEffectHandle& Handle); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.GetDurationForEffect // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a3ded0
	void GetCooldownTimeRemainingAndDurationForAbility(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpecHandle Handle, float& Cooldown, float& Duration); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.GetCooldownTimeRemainingAndDurationForAbility // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a496f0
	void GetActivatableGameplayAbilitySpecHandlesByAllMatchingTags(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayTagContainer& GameplayTagContainer, struct TArray<struct FGameplayAbilitySpecHandle>& MatchingGameplayAbilities, bool bOnlyAbilitiesThatSatisfyTagRequirements); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.GetActivatableGameplayAbilitySpecHandlesByAllMatchingTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a3b010
	struct UGameplayAbility* GetAbilityCDO(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpecHandle Handle); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.GetAbilityCDO // (Final|Native|Static|Public) // @ game+0x5a43050
	struct FActiveGameplayEffectHandle FindActiveGameplayEffectHandle(struct UAbilitySystemComponent* AbilitySystemComponent, struct FGameplayAbilitySpecHandle& Handle); // Function EmbarkAbilitySystem.AbilitySystemComponentMixinLibrary2.FindActiveGameplayEffectHandle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a45cf0
};

// Class EmbarkAbilitySystem.GameplayModMagnitudeCalculationMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayModMagnitudeCalculationMixinLibrary : UObject {

	bool GetCapturedAttributeMagnitude(struct UGameplayModMagnitudeCalculation* GameplayModMagnitudeCalculation, struct FGameplayEffectAttributeCaptureDefinition& Def, struct FGameplayEffectSpec& Spec, float& Magnitude); // Function EmbarkAbilitySystem.GameplayModMagnitudeCalculationMixinLibrary.GetCapturedAttributeMagnitude // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a3d6d0
};

// Class EmbarkAbilitySystem.GameplayCueParametersPartIDMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayCueParametersPartIDMixinLibrary : UObject {

	int32_t GetNumPartIDs(struct FGameplayCueParameters& Parameters); // Function EmbarkAbilitySystem.GameplayCueParametersPartIDMixinLibrary.GetNumPartIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a47b40
	int32_t GetFirstPartID(struct FGameplayCueParameters& Parameters); // Function EmbarkAbilitySystem.GameplayCueParametersPartIDMixinLibrary.GetFirstPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a45e40
	bool ArePartIDsValid(struct FGameplayCueParameters& Parameters); // Function EmbarkAbilitySystem.GameplayCueParametersPartIDMixinLibrary.ArePartIDsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a3d9b0
};

// Class EmbarkAbilitySystem.EmbarkAbilityTaskLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAbilityTaskLibrary : UBlueprintFunctionLibrary {

	struct UAbilityTask_NetworkSyncPoint* WaitNetSync(struct UGameplayAbility* OwningAbility, enum class EAbilityTaskNetSyncType SyncType); // Function EmbarkAbilitySystem.EmbarkAbilityTaskLibrary.WaitNetSync // (Final|Native|Static|Public) // @ game+0x4f97eb0
	struct UAbilityTask_WaitGameplayTagRemoved* WaitGameplayTagRemove(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // Function EmbarkAbilitySystem.EmbarkAbilityTaskLibrary.WaitGameplayTagRemove // (Final|Native|Static|Public) // @ game+0x4fa3c70
	struct UAbilityTask_WaitGameplayTagAdded* WaitGameplayTagAdd(struct UGameplayAbility* OwningAbility, struct FGameplayTag Tag, struct AActor* InOptionalExternalTarget, bool OnlyTriggerOnce); // Function EmbarkAbilitySystem.EmbarkAbilityTaskLibrary.WaitGameplayTagAdd // (Final|Native|Static|Public) // @ game+0x4f9aac0
	struct UAbilityTask_WaitGameplayEvent* WaitGameplayEvent(struct UGameplayAbility* OwningAbility, struct FGameplayTag EventTag, struct AActor* OptionalExternalTarget, bool OnlyTriggerOnce, bool OnlyMatchExact); // Function EmbarkAbilitySystem.EmbarkAbilityTaskLibrary.WaitGameplayEvent // (Final|Native|Static|Public) // @ game+0x4fa0860
	struct UAbilityTask_WaitDelay* WaitDelay(struct UGameplayAbility* OwningAbility, float Time); // Function EmbarkAbilitySystem.EmbarkAbilityTaskLibrary.WaitDelay // (Final|Native|Static|Public) // @ game+0x4f9bae0
	struct UAbilityTask_PlayMontageAndWait* PlayMontageAndWait(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct UAnimMontage* MontageToPlay, float Rate, struct FName StartSection, bool bStopWhenAbilityEnds, float AnimRootMotionTranslationScale, float InTimeToStartAnimMontageAt); // Function EmbarkAbilitySystem.EmbarkAbilityTaskLibrary.PlayMontageAndWait // (Final|Native|Static|Public) // @ game+0x4f9d880
};

// Class EmbarkAbilitySystem.EmbarkAbilityTask_ServerWaitForClientTargetData
// Size: 0x110 (Inherited: 0xf0)
struct UEmbarkAbilityTask_ServerWaitForClientTargetData : UAbilityTask {
	struct FMulticastInlineDelegate ValidData; // 0xf0(0x10)
	char pad_100[0x10]; // 0x100(0x10)

	struct UEmbarkAbilityTask_ServerWaitForClientTargetData* ServerWaitForClientTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, bool TriggerOnce); // Function EmbarkAbilitySystem.EmbarkAbilityTask_ServerWaitForClientTargetData.ServerWaitForClientTargetData // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5a42890
	void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle& Data, struct FGameplayTag ActivationTag); // Function EmbarkAbilitySystem.EmbarkAbilityTask_ServerWaitForClientTargetData.OnTargetDataReplicatedCallback // (Final|Native|Public|HasOutParms) // @ game+0x5a40cb0
};

// Class EmbarkAbilitySystem.EmbarkAbilityTask_WaitTargetData
// Size: 0x100 (Inherited: 0xf0)
struct UEmbarkAbilityTask_WaitTargetData : UAngelscriptAbilityTask {
	struct FMulticastInlineDelegate ValidData; // 0xf0(0x10)

	void SendTargetData(struct FGameplayAbilityTargetDataHandle& Data); // Function EmbarkAbilitySystem.EmbarkAbilityTask_WaitTargetData.SendTargetData // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x5a3a9f0
	void OnTargetDataReplicatedCallback(struct FGameplayAbilityTargetDataHandle& Data, struct FGameplayTag ActivationTag); // Function EmbarkAbilitySystem.EmbarkAbilityTask_WaitTargetData.OnTargetDataReplicatedCallback // (Final|Native|Private|HasOutParms) // @ game+0x5a3ce30
};

// Class EmbarkAbilitySystem.EmbarkActiveGameplayEffectExecution
// Size: 0xd0 (Inherited: 0xa0)
struct UEmbarkActiveGameplayEffectExecution : UObject {
	struct UWorld* AbilitySystemWorld; // 0x98(0x08)
	struct UAbilitySystemComponent* AbilitySystemComponent; // 0xa0(0x08)
	struct UGameplayEffect* GameplayEffect; // 0xa8(0x08)
	char pad_b8[0x18]; // 0xb8(0x18)

	struct UGameplayEffect* GetGameplayEffect(); // Function EmbarkAbilitySystem.EmbarkActiveGameplayEffectExecution.GetGameplayEffect // (Final|Native|Public|Const) // @ game+0x52d1c20
	struct FGameplayEffectContextHandle GetContext(); // Function EmbarkAbilitySystem.EmbarkActiveGameplayEffectExecution.GetContext // (Final|Native|Public|Const) // @ game+0x5a42b40
	struct UAbilitySystemComponent* GetAbilitySystemComponent(); // Function EmbarkAbilitySystem.EmbarkActiveGameplayEffectExecution.GetAbilitySystemComponent // (Final|Native|Public|Const) // @ game+0x2f3d5f0
	void BP_OnRemove(); // Function EmbarkAbilitySystem.EmbarkActiveGameplayEffectExecution.BP_OnRemove // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void BP_OnApply(); // Function EmbarkAbilitySystem.EmbarkActiveGameplayEffectExecution.BP_OnApply // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkAbilitySystem.EmbarkActiveGameplayEffectHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkActiveGameplayEffectHandleMixinLibrary : UObject {

	float GetStartWorldTime(struct FActiveGameplayEffect& Effect); // Function EmbarkAbilitySystem.EmbarkActiveGameplayEffectHandleMixinLibrary.GetStartWorldTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5a34da0
};

// Class EmbarkAbilitySystem.EmbarkAttributeInitializerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAttributeInitializerMixinLibrary : UObject {

	void Init(struct FEmbarkAttributeInitializer& AttributeInitializer, struct UAbilitySystemComponent* AbilitySystem); // Function EmbarkAbilitySystem.EmbarkAttributeInitializerMixinLibrary.Init // (Final|Native|Static|Public|HasOutParms) // @ game+0x5a3f340
};

// Class EmbarkAbilitySystem.EmbarkAttributeSet
// Size: 0xb0 (Inherited: 0xb0)
struct UEmbarkAttributeSet : UAngelscriptAttributeSet {
};

// Class EmbarkAbilitySystem.EmbarkGameplayAbility
// Size: 0x490 (Inherited: 0x460)
struct UEmbarkGameplayAbility : UGameplayAbility {
	struct FGameplayTagContainer CancelOnTagApplication; // 0x458(0x20)
	char pad_480[0x10]; // 0x480(0x10)

	void K2_RemoveGameplayCue_Static(struct UGameplayCueNotify_Static* GameplayCue); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_RemoveGameplayCue_Static // (Native|Public|BlueprintCallable) // @ game+0x4fa5cc0
	void K2_RemoveGameplayCue_Actor(struct AGameplayCueNotify_Actor* GameplayCue); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_RemoveGameplayCue_Actor // (Native|Public|BlueprintCallable) // @ game+0x4fac960
	void K2_OnRemoveAbility(struct FGameplayAbilityActorInfo& InActorInfo, struct FGameplayAbilitySpec& InSpec); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_OnRemoveAbility // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void K2_OnGiveAbility(struct FGameplayAbilityActorInfo& InActorInfo, struct FGameplayAbilitySpec& InSpec); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_OnGiveAbility // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	struct FGameplayAbilitySpecHandle K2_GetCurrentAbilitySpecHandle(); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_GetCurrentAbilitySpecHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5a3fb70
	void K2_ExecuteGameplayCueWithParams_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayCueParameters& GameplayCueParameters); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_ExecuteGameplayCueWithParams_Static // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa73a0
	void K2_ExecuteGameplayCueWithParams_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayCueParameters& GameplayCueParameters); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_ExecuteGameplayCueWithParams_Actor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fae980
	void K2_ExecuteGameplayCue_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayEffectContextHandle Context); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_ExecuteGameplayCue_Static // (Native|Public|BlueprintCallable) // @ game+0x4faf270
	void K2_ExecuteGameplayCue_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayEffectContextHandle Context); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_ExecuteGameplayCue_Actor // (Native|Public|BlueprintCallable) // @ game+0x4fa76b0
	bool K2_CanBeCanceled(); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_CanBeCanceled // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void K2_AddGameplayCueWithParams_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayCueParameters& GameplayCueParameter, bool bRemoveOnAbilityEnd); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_AddGameplayCueWithParams_Static // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fa8330
	void K2_AddGameplayCueWithParams_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayCueParameters& GameplayCueParameter, bool bRemoveOnAbilityEnd); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_AddGameplayCueWithParams_Actor // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fac0b0
	void K2_AddGameplayCue_Static(struct UGameplayCueNotify_Static* GameplayCue, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_AddGameplayCue_Static // (Native|Public|BlueprintCallable) // @ game+0x4fac3f0
	void K2_AddGameplayCue_Actor(struct AGameplayCueNotify_Actor* GameplayCue, struct FGameplayEffectContextHandle Context, bool bRemoveOnAbilityEnd); // Function EmbarkAbilitySystem.EmbarkGameplayAbility.K2_AddGameplayCue_Actor // (Native|Public|BlueprintCallable) // @ game+0x4fa8c40
};

// Class EmbarkAbilitySystem.EmbarkGameplayEffect
// Size: 0xb20 (Inherited: 0xb10)
struct UEmbarkGameplayEffect : UGameplayEffect {
	struct TArray<struct UEmbarkActiveGameplayEffectExecution*> OnActiveExecution; // 0xb08(0x10)

	void OnAddParametersForMinimalReplication(struct FGameplayEffectCue& Cue, struct FGameplayEffectSpec& Spec, struct FGameplayCueParameters& CueParameters); // Function EmbarkAbilitySystem.EmbarkGameplayEffect.OnAddParametersForMinimalReplication // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
};

