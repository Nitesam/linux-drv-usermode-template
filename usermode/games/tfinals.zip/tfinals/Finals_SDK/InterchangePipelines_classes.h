// Class InterchangePipelines.InterchangeGenericCommonMeshesProperties
// Size: 0x170 (Inherited: 0x160)
struct UInterchangeGenericCommonMeshesProperties : UInterchangePipelineBase {
	enum class EInterchangeForceMeshType ForceAllMeshAsType; // 0x158(0x01)
	bool bImportLods; // 0x159(0x01)
	bool bBakeMeshes; // 0x15a(0x01)
	enum class EInterchangeVertexColorImportOption VertexColorImportOption; // 0x15b(0x01)
	struct FColor VertexOverrideColor; // 0x15c(0x04)
	bool bRecomputeNormals; // 0x160(0x01)
	bool bRecomputeTangents; // 0x161(0x01)
	bool bUseMikkTSpace; // 0x162(0x01)
	bool bComputeWeightedNormals; // 0x163(0x01)
	bool bUseHighPrecisionTangentBasis; // 0x164(0x01)
	bool bUseFullPrecisionUVs; // 0x165(0x01)
	bool bUseBackwardsCompatibleF16TruncUVs; // 0x166(0x01)
	bool bRemoveDegenerates; // 0x167(0x01)
};

// Class InterchangePipelines.InterchangeGenericCommonSkeletalMeshesAndAnimationsProperties
// Size: 0x170 (Inherited: 0x160)
struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties : UInterchangePipelineBase {
	bool bImportOnlyAnimations; // 0x158(0x01)
	struct TWeakObjectPtr<struct USkeleton> Skeleton; // 0x15c(0x08)
	bool bImportMeshesInBoneHierarchy; // 0x164(0x01)
	bool bUseT0AsRefPose; // 0x165(0x01)
	bool bConvertStaticsWithMorphTargetsToSkeletals; // 0x166(0x01)
	char pad_16c[0x4]; // 0x16c(0x04)
};

// Class InterchangePipelines.GLTFPipelineSettings
// Size: 0x100 (Inherited: 0xb0)
struct UGLTFPipelineSettings : UDeveloperSettings {
	struct TMap<struct FString, struct FSoftObjectPath> MaterialParents; // 0xa8(0x50)
};

// Class InterchangePipelines.InterchangeGLTFPipeline
// Size: 0x170 (Inherited: 0x160)
struct UInterchangeGLTFPipeline : UInterchangePipelineBase {
	bool bUseGLTFMaterialInstanceLibrary; // 0x160(0x01)
	char pad_161[0xf]; // 0x161(0x0f)
};

// Class InterchangePipelines.MaterialXPipelineSettings
// Size: 0x100 (Inherited: 0xb0)
struct UMaterialXPipelineSettings : UDeveloperSettings {
	struct TMap<enum class EInterchangeMaterialXShaders, struct FSoftObjectPath> PredefinedSurfaceShaders; // 0xa8(0x50)
};

// Class InterchangePipelines.InterchangeMaterialXPipeline
// Size: 0x160 (Inherited: 0x160)
struct UInterchangeMaterialXPipeline : UInterchangePipelineBase {
};

// Class InterchangePipelines.InterchangeGenericAnimationPipeline
// Size: 0x1d0 (Inherited: 0x160)
struct UInterchangeGenericAnimationPipeline : UInterchangePipelineBase {
	struct TWeakObjectPtr<struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties> CommonSkeletalMeshesAndAnimationsProperties; // 0x158(0x08)
	struct TWeakObjectPtr<struct UInterchangeGenericCommonMeshesProperties> CommonMeshesProperties; // 0x160(0x08)
	bool bImportAnimations; // 0x168(0x01)
	bool bImportBoneTracks; // 0x169(0x01)
	enum class EInterchangeAnimationRange AnimationRange; // 0x16a(0x01)
	struct FInt32Interval FrameImportRange; // 0x16c(0x08)
	bool bUse30HzToBakeBoneAnimation; // 0x174(0x01)
	int32_t CustomBoneAnimationSampleRate; // 0x178(0x04)
	bool bSnapToClosestFrameBoundary; // 0x17c(0x01)
	bool bImportCustomAttribute; // 0x17d(0x01)
	bool bAddCurveMetadataToSkeleton; // 0x17e(0x01)
	bool bSetMaterialDriveParameterOnCustomAttribute; // 0x17f(0x01)
	struct TArray<struct FString> MaterialCurveSuffixes; // 0x180(0x10)
	bool bRemoveCurveRedundantKeys; // 0x190(0x01)
	bool bDoNotImportCurveWithZero; // 0x191(0x01)
	bool bDeleteExistingNonCurveCustomAttributes; // 0x192(0x01)
	bool bDeleteExistingCustomAttributeCurves; // 0x193(0x01)
	bool bDeleteExistingMorphTargetCurves; // 0x194(0x01)
	struct FString SourceAnimationName; // 0x198(0x10)
	bool bSceneImport; // 0x1a8(0x01)
	char pad_1aa[0x26]; // 0x1aa(0x26)
};

// Class InterchangePipelines.InterchangeGenericAssetsPipeline
// Size: 0x1f0 (Inherited: 0x160)
struct UInterchangeGenericAssetsPipeline : UInterchangePipelineBase {
	enum class EReimportStrategyFlags ReimportStrategy; // 0x158(0x01)
	bool bUseSourceNameForAsset; // 0x159(0x01)
	struct FString AssetName; // 0x160(0x10)
	struct FVector ImportOffsetTranslation; // 0x170(0x18)
	struct FRotator ImportOffsetRotation; // 0x188(0x18)
	float ImportOffsetUniformScale; // 0x1a0(0x04)
	char pad_1a6[0x2]; // 0x1a6(0x02)
	struct UInterchangeGenericCommonMeshesProperties* CommonMeshesProperties; // 0x1a8(0x08)
	struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties* CommonSkeletalMeshesAndAnimationsProperties; // 0x1b0(0x08)
	struct UInterchangeGenericMeshPipeline* MeshPipeline; // 0x1b8(0x08)
	struct UInterchangeGenericAnimationPipeline* AnimationPipeline; // 0x1c0(0x08)
	struct UInterchangeGenericMaterialPipeline* MaterialPipeline; // 0x1c8(0x08)
	char pad_1d0[0x20]; // 0x1d0(0x20)
};

// Class InterchangePipelines.InterchangeGenericMaterialPipeline
// Size: 0x1f0 (Inherited: 0x160)
struct UInterchangeGenericMaterialPipeline : UInterchangePipelineBase {
	bool bImportMaterials; // 0x158(0x01)
	struct FString AssetName; // 0x160(0x10)
	enum class EInterchangeMaterialImportOption MaterialImport; // 0x170(0x01)
	char pad_172[0x6]; // 0x172(0x06)
	struct FSoftObjectPath ParentMaterial; // 0x178(0x20)
	struct UInterchangeGenericTexturePipeline* TexturePipeline; // 0x198(0x08)
	struct UInterchangeBaseNodeContainer* BaseNodeContainer; // 0x1a0(0x08)
	char pad_1a8[0x48]; // 0x1a8(0x48)
};

// Class InterchangePipelines.InterchangeGenericMeshPipeline
// Size: 0x230 (Inherited: 0x160)
struct UInterchangeGenericMeshPipeline : UInterchangePipelineBase {
	struct TWeakObjectPtr<struct UInterchangeGenericCommonMeshesProperties> CommonMeshesProperties; // 0x158(0x08)
	struct TWeakObjectPtr<struct UInterchangeGenericCommonSkeletalMeshesAndAnimationsProperties> CommonSkeletalMeshesAndAnimationsProperties; // 0x160(0x08)
	bool bImportStaticMeshes; // 0x168(0x01)
	bool bCombineStaticMeshes; // 0x169(0x01)
	struct FName LODGroup; // 0x16c(0x08)
	bool bImportCollision; // 0x174(0x01)
	bool bImportCollisionAccordingToMeshName; // 0x175(0x01)
	bool bOneConvexHullPerUCX; // 0x176(0x01)
	bool bBuildNanite; // 0x177(0x01)
	bool bBuildReversedIndexBuffer; // 0x178(0x01)
	bool bGenerateLightmapUVs; // 0x179(0x01)
	bool bGenerateDistanceFieldAsIfTwoSided; // 0x17a(0x01)
	bool bSupportFaceRemap; // 0x17b(0x01)
	int32_t MinLightmapResolution; // 0x17c(0x04)
	int32_t SrcLightmapIndex; // 0x180(0x04)
	int32_t DstLightmapIndex; // 0x184(0x04)
	struct FVector BuildScale3D; // 0x188(0x18)
	float DistanceFieldResolutionScale; // 0x1a0(0x04)
	struct TWeakObjectPtr<struct UStaticMesh> DistanceFieldReplacementMesh; // 0x1a4(0x08)
	int32_t MaxLumenMeshCards; // 0x1ac(0x04)
	bool bImportSkeletalMeshes; // 0x1b0(0x01)
	enum class EInterchangeSkeletalMeshContentType SkeletalMeshImportContentType; // 0x1b1(0x01)
	enum class EInterchangeSkeletalMeshContentType LastSkeletalMeshImportContentType; // 0x1b2(0x01)
	bool bCombineSkeletalMeshes; // 0x1b3(0x01)
	bool bImportMorphTargets; // 0x1b4(0x01)
	bool bUpdateSkeletonReferencePose; // 0x1b5(0x01)
	bool bCreatePhysicsAsset; // 0x1b6(0x01)
	struct TWeakObjectPtr<struct UPhysicsAsset> PhysicsAsset; // 0x1b8(0x08)
	bool bUseHighPrecisionSkinWeights; // 0x1c0(0x01)
	float ThresholdPosition; // 0x1c4(0x04)
	float ThresholdTangentNormal; // 0x1c8(0x04)
	float ThresholdUV; // 0x1cc(0x04)
	float MorphThresholdPosition; // 0x1d0(0x04)
	int32_t BoneInfluenceLimit; // 0x1d4(0x04)
	char pad_1da[0x56]; // 0x1da(0x56)
};

// Class InterchangePipelines.InterchangeGenericLevelPipeline
// Size: 0x170 (Inherited: 0x160)
struct UInterchangeGenericLevelPipeline : UInterchangePipelineBase {
	enum class EReimportStrategyFlags ReimportPropertyStrategy; // 0x158(0x01)
	bool bDeleteMissingActors; // 0x159(0x01)
	bool bForceReimportDeletedActors; // 0x15a(0x01)
	bool bForceReimportDeletedAssets; // 0x15b(0x01)
	bool bDeleteMissingAssets; // 0x15c(0x01)
	bool bUsePhysicalInsteadOfStandardPerspectiveCamera; // 0x15d(0x01)
	char pad_166[0xa]; // 0x166(0x0a)
};

// Class InterchangePipelines.InterchangeGenericTexturePipeline
// Size: 0x1b0 (Inherited: 0x160)
struct UInterchangeGenericTexturePipeline : UInterchangePipelineBase {
	bool bImportTextures; // 0x158(0x01)
	struct FString AssetName; // 0x160(0x10)
	bool bAllowNonPowerOfTwo; // 0x170(0x01)
	char pad_172[0x6]; // 0x172(0x06)
	struct UInterchangeBaseNodeContainer* BaseNodeContainer; // 0x178(0x08)
	char pad_180[0x30]; // 0x180(0x30)
};

// Class InterchangePipelines.InterchangePipelineMeshesUtilities
// Size: 0x1a0 (Inherited: 0xa0)
struct UInterchangePipelineMeshesUtilities : UObject {
	char pad_a0[0x100]; // 0xa0(0x100)

	void SetContext(struct FInterchangePipelineMeshesUtilitiesContext& Context); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.SetContext // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a88530
	bool IsValidMeshInstanceUid(struct FString MeshInstanceUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.IsValidMeshInstanceUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a8f6c0
	bool IsValidMeshGeometryUid(struct FString MeshGeometryUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.IsValidMeshGeometryUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a80da0
	struct FString GetMeshInstanceSkeletonRootUid(struct FString MeshInstanceUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshInstanceSkeletonRootUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a8c1c0
	struct FInterchangeMeshInstance GetMeshInstanceByUid(struct FString MeshInstanceUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshInstanceByUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a63bf0
	struct FString GetMeshGeometrySkeletonRootUid(struct FString MeshGeometryUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshGeometrySkeletonRootUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a7de30
	struct FInterchangeMeshGeometry GetMeshGeometryByUid(struct FString MeshGeometryUid); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetMeshGeometryByUid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a6a230
	void GetAllStaticMeshInstance(struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllStaticMeshInstance // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5f770
	void GetAllStaticMeshGeometry(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllStaticMeshGeometry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a808f0
	void GetAllSkinnedMeshInstance(struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllSkinnedMeshInstance // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a5ebd0
	void GetAllSkinnedMeshGeometry(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllSkinnedMeshGeometry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a80bc0
	void GetAllMeshInstanceUidsUsingMeshGeometryUid(struct FString MeshGeometryUid, struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshInstanceUidsUsingMeshGeometryUid // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a7c4e0
	void GetAllMeshInstanceUids(struct TArray<struct FString>& MeshInstanceUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshInstanceUids // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a642c0
	void GetAllMeshGeometryNotInstanced(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshGeometryNotInstanced // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a6b7e0
	void GetAllMeshGeometry(struct TArray<struct FString>& MeshGeometryUids); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.GetAllMeshGeometry // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9a89330
	struct UInterchangePipelineMeshesUtilities* CreateInterchangePipelineMeshesUtilities(struct UInterchangeBaseNodeContainer* BaseNodeContainer); // Function InterchangePipelines.InterchangePipelineMeshesUtilities.CreateInterchangePipelineMeshesUtilities // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9a926e0
};

