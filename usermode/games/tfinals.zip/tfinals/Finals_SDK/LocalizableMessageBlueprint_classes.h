// Class LocalizableMessageBlueprint.LocalizableMessageLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct ULocalizableMessageLibrary : UBlueprintFunctionLibrary {

	void Reset_LocalizableMessage(struct FLocalizableMessage& Message); // Function LocalizableMessageBlueprint.LocalizableMessageLibrary.Reset_LocalizableMessage // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x988b940
	bool IsEmpty_LocalizableMessage(struct FLocalizableMessage& Message); // Function LocalizableMessageBlueprint.LocalizableMessageLibrary.IsEmpty_LocalizableMessage // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9889820
	struct FText Conv_LocalizableMessageToText(struct UObject* WorldContextObject, struct FLocalizableMessage& Message); // Function LocalizableMessageBlueprint.LocalizableMessageLibrary.Conv_LocalizableMessageToText // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x988b9f0
};

