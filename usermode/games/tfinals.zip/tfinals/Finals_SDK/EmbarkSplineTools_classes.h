// Class EmbarkSplineTools.SplineDistributionActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ASplineDistributionActor : AActor {
	struct UStaticMeshComponent* MergedStaticMeshComponent; // 0x398(0x08)
	struct USplineComponent* Spline; // 0x3a0(0x08)

	void ReceivePostRebuild(); // Function EmbarkSplineTools.SplineDistributionActor.ReceivePostRebuild // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkSplineTools.SplineLayerStyleDataAsset
// Size: 0xa0 (Inherited: 0xa0)
struct USplineLayerStyleDataAsset : UDataAsset {
};

