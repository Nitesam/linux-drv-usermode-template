// Class StructUtils.PropertyBagMissingObject
// Size: 0xa0 (Inherited: 0xa0)
struct UPropertyBagMissingObject : UObject {
};

// Class StructUtils.PropertyBag
// Size: 0x150 (Inherited: 0x140)
struct UPropertyBag : UScriptStruct {
	struct TArray<struct FPropertyBagPropertyDesc> PropertyDescs; // 0x138(0x10)
};

