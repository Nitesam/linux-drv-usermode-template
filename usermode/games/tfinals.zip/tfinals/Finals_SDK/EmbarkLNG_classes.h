// Class EmbarkLNG.EmbarkLNGUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkLNGUtils : UObject {

	struct FLNGPath SmoothPathCatmullRom(struct FLNGPath& OriginalPath, float GridSize, struct FVector& OffsetLocation, int32_t SubdivisionsPerSegment, float Tension); // Function EmbarkLNG.EmbarkLNGUtils.SmoothPathCatmullRom // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5d388a0
	struct FVector ConvertWorldToGrid(struct FVector& InWorld, float InGridSize, struct FVector& InLocationOffset); // Function EmbarkLNG.EmbarkLNGUtils.ConvertWorldToGrid // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5d41cb0
	struct FVector ConvertGridToWorld(struct FVector& InWorld, float InGridSize, struct FVector& InLocationOffset); // Function EmbarkLNG.EmbarkLNGUtils.ConvertGridToWorld // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5d36b80
};

// Class EmbarkLNG.EmbarkLNGVisualizationComponent
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkLNGVisualizationComponent : UActorComponent {
};

// Class EmbarkLNG.EmbarkLNGVolume
// Size: 0x530 (Inherited: 0x3d0)
struct AEmbarkLNGVolume : AVolume {
	char pad_3d0[0x68]; // 0x3d0(0x68)
	struct FLNGGraph Graph; // 0x438(0xc0)
	struct FLNGGenerationSettings GenerationSettings; // 0x4f8(0x18)
	int32_t DebugVisFlags; // 0x510(0x04)
	char pad_514[0x4]; // 0x514(0x04)
	struct FVector OverriddenExtent; // 0x518(0x18)

	void SetLNGDebugData(struct FLNGActorDebugData& NewDebugData); // Function EmbarkLNG.EmbarkLNGVolume.SetLNGDebugData // (Final|Native|Public|HasOutParms) // @ game+0x5d461c0
	struct FLNGActorDebugData GetLNGDebugData(); // Function EmbarkLNG.EmbarkLNGVolume.GetLNGDebugData // (Final|Native|Public|Const) // @ game+0x5d3efa0
	struct FBoxSphereBounds GetGenerationBounds(); // Function EmbarkLNG.EmbarkLNGVolume.GetGenerationBounds // (Final|Native|Public|HasDefaults|Const) // @ game+0x5d416d0
};

