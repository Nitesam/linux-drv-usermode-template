// Class RigVM.RigVMGraphFunctionHost
// Size: 0xa0 (Inherited: 0xa0)
struct URigVMGraphFunctionHost : UInterface {
};

// Class RigVM.RigVMBlueprintGeneratedClass
// Size: 0x480 (Inherited: 0x450)
struct URigVMBlueprintGeneratedClass : UBlueprintGeneratedClass {
	char pad_450[0x8]; // 0x450(0x08)
	struct FRigVMGraphFunctionStore GraphFunctionStore; // 0x458(0x20)
	char pad_478[0x8]; // 0x478(0x08)
};

// Class RigVM.RigVM
// Size: 0x320 (Inherited: 0xa0)
struct URigVM : UObject {
	struct URigVMMemoryStorage* WorkMemoryStorageObject; // 0x98(0x08)
	struct URigVMMemoryStorage* LiteralMemoryStorageObject; // 0xa0(0x08)
	struct URigVMMemoryStorage* DebugMemoryStorageObject; // 0xa8(0x08)
	char pad_b8[0x18]; // 0xb8(0x18)
	struct FRigVMByteCode ByteCodeStorage; // 0xd0(0xa0)
	char pad_170[0x8]; // 0x170(0x08)
	struct FRigVMInstructionArray Instructions; // 0x178(0x10)
	char pad_188[0x8]; // 0x188(0x08)
	struct TArray<struct FName> FunctionNamesStorage; // 0x190(0x10)
	char pad_1a0[0x38]; // 0x1a0(0x38)
	struct TArray<struct FRigVMParameter> Parameters; // 0x1d8(0x10)
	struct TMap<struct FName, int32_t> ParametersNameMap; // 0x1e8(0x50)
	char pad_238[0x98]; // 0x238(0x98)
	struct URigVM* DeferredVMToCopy; // 0x2d0(0x08)
	char pad_2d8[0x48]; // 0x2d8(0x48)

	void SetParameterValueVector2D(struct FName& InParameterName, struct FVector2D& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueVector2D // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55c25f0
	void SetParameterValueVector(struct FName& InParameterName, struct FVector& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueVector // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55a5ae0
	void SetParameterValueTransform(struct FName& InParameterName, struct FTransform& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55bab00
	void SetParameterValueString(struct FName& InParameterName, struct FString InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueString // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x558bb80
	void SetParameterValueQuat(struct FName& InParameterName, struct FQuat& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueQuat // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55bec10
	void SetParameterValueName(struct FName& InParameterName, struct FName& InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x55998e0
	void SetParameterValueInt(struct FName& InParameterName, int32_t InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueInt // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x55bded0
	void SetParameterValueFloat(struct FName& InParameterName, float InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x558d210
	void SetParameterValueDouble(struct FName& InParameterName, double InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueDouble // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x557a050
	void SetParameterValueBool(struct FName& InParameterName, bool InValue, int32_t InArrayIndex); // Function RigVM.RigVM.SetParameterValueBool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x55bb440
	struct FRigVMStatistics GetStatistics(); // Function RigVM.RigVM.GetStatistics // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55c2da0
	struct FString GetRigVMFunctionName(int32_t InFunctionIndex); // Function RigVM.RigVM.GetRigVMFunctionName // (Native|Public|Const) // @ game+0x559ecf0
	struct FVector2D GetParameterValueVector2D(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueVector2D // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x558b570
	struct FVector GetParameterValueVector(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueVector // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55b8830
	struct FTransform GetParameterValueTransform(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x557c120
	struct FString GetParameterValueString(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueString // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x55b3cd0
	struct FQuat GetParameterValueQuat(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueQuat // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5587c20
	struct FName GetParameterValueName(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5591a80
	int32_t GetParameterValueInt(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueInt // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5588f00
	float GetParameterValueFloat(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x55880f0
	double GetParameterValueDouble(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueDouble // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x557db50
	bool GetParameterValueBool(struct FName& InParameterName, int32_t InArrayIndex); // Function RigVM.RigVM.GetParameterValueBool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5599ac0
	bool Execute(struct FRigVMExtendedExecuteContext& Context, struct FName& InEntryName); // Function RigVM.RigVM.Execute // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x55a4180
	int32_t AddRigVMFunction(struct UScriptStruct* InRigVMStruct, struct FName& InMethodName); // Function RigVM.RigVM.AddRigVMFunction // (Native|Public|HasOutParms) // @ game+0x55b3a80
};

// Class RigVM.NameSpacedUserData
// Size: 0x170 (Inherited: 0xa0)
struct UNameSpacedUserData : UAssetUserData {
	struct FString Namespace; // 0x98(0x10)
	char pad_b0[0xc0]; // 0xb0(0xc0)
};

// Class RigVM.DataAssetLink
// Size: 0x180 (Inherited: 0x170)
struct UDataAssetLink : UNameSpacedUserData {
	struct UDataAsset* DataAsset; // 0x170(0x08)
	char pad_178[0x8]; // 0x178(0x08)

	void SetDataAsset(struct UDataAsset* InDataAsset); // Function RigVM.DataAssetLink.SetDataAsset // (Final|Native|Public|BlueprintCallable) // @ game+0x5590c50
	struct UDataAsset* GetDataAsset(); // Function RigVM.DataAssetLink.GetDataAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x557a8c0
};

// Class RigVM.RigVMMemoryStorageGeneratorClass
// Size: 0x330 (Inherited: 0x2f0)
struct URigVMMemoryStorageGeneratorClass : UClass {
	char pad_2f0[0x40]; // 0x2f0(0x40)
};

// Class RigVM.RigVMMemoryStorage
// Size: 0xa0 (Inherited: 0xa0)
struct URigVMMemoryStorage : UObject {
};

// Class RigVM.RigVMNativized
// Size: 0x340 (Inherited: 0x320)
struct URigVMNativized : URigVM {
	char pad_320[0x20]; // 0x320(0x20)
};

// Class RigVM.RigVMUserWorkflowOptions
// Size: 0x110 (Inherited: 0xa0)
struct URigVMUserWorkflowOptions : UObject {
	struct UObject* Subject; // 0x98(0x08)
	struct FRigVMUserWorkflow Workflow; // 0xa0(0x58)
	char pad_100[0x10]; // 0x100(0x10)

	bool RequiresDialog(); // Function RigVM.RigVMUserWorkflowOptions.RequiresDialog // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55c44d0
	void ReportWarning(struct FString InMessage); // Function RigVM.RigVMUserWorkflowOptions.ReportWarning // (Final|Native|Public|BlueprintCallable) // @ game+0x5647360
	void ReportInfo(struct FString InMessage); // Function RigVM.RigVMUserWorkflowOptions.ReportInfo // (Final|Native|Public|BlueprintCallable) // @ game+0x565b3d0
	void ReportError(struct FString InMessage); // Function RigVM.RigVMUserWorkflowOptions.ReportError // (Final|Native|Public|BlueprintCallable) // @ game+0x5639a10
	bool IsValid(); // Function RigVM.RigVMUserWorkflowOptions.IsValid // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5644c50
};

// Class RigVM.RigVMHost
// Size: 0x3b0 (Inherited: 0xa0)
struct URigVMHost : UObject {
	struct FRigVMRuntimeSettings VMRuntimeSettings; // 0xa0(0x18)
	char pad_b8[0x10]; // 0xb8(0x10)
	struct URigVM* VM; // 0xc8(0x08)
	struct FRigVMExtendedExecuteContext ExtendedExecuteContext; // 0xd0(0x1b8)
	struct FRigVMDrawContainer DrawContainer; // 0x288(0x18)
	char pad_2a0[0x18]; // 0x2a0(0x18)
	struct TArray<struct FName> EventQueue; // 0x2b8(0x10)
	char pad_2c8[0x90]; // 0x2c8(0x90)
	struct TArray<struct UAssetUserData*> AssetUserData; // 0x358(0x10)
	char pad_368[0x48]; // 0x368(0x48)

	bool SupportsEvent(struct FName& InEventName); // Function RigVM.RigVMHost.SupportsEvent // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5682eb0
	bool SetVariableFromString(struct FName& InVariableName, struct FString InValue); // Function RigVM.RigVMHost.SetVariableFromString // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x567bc40
	void SetFramesPerSecond(float InFramesPerSecond); // Function RigVM.RigVMHost.SetFramesPerSecond // (Final|Native|Public|BlueprintCallable) // @ game+0x567c7f0
	void SetDeltaTime(float InDeltaTime); // Function RigVM.RigVMHost.SetDeltaTime // (Final|Native|Public|BlueprintCallable) // @ game+0x5677a40
	void SetAbsoluteTime(float InAbsoluteTime, bool InSetDeltaTimeZero); // Function RigVM.RigVMHost.SetAbsoluteTime // (Final|Native|Public|BlueprintCallable) // @ game+0x5683990
	void SetAbsoluteAndDeltaTime(float InAbsoluteTime, float InDeltaTime); // Function RigVM.RigVMHost.SetAbsoluteAndDeltaTime // (Final|Native|Public|BlueprintCallable) // @ game+0x5686be0
	void RequestRunOnceEvent(struct FName& InEventName, int32_t InEventIndex); // Function RigVM.RigVMHost.RequestRunOnceEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x567d420
	void RequestInit(); // Function RigVM.RigVMHost.RequestInit // (Native|Public|BlueprintCallable) // @ game+0x537cec0
	bool RemoveRunOnceEvent(struct FName& InEventName); // Function RigVM.RigVMHost.RemoveRunOnceEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5681870
	struct URigVM* GetVM(); // Function RigVM.RigVMHost.GetVM // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x567c590
	struct FName GetVariableType(struct FName& InVariableName); // Function RigVM.RigVMHost.GetVariableType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x56720c0
	struct FString GetVariableAsString(struct FName& InVariableName); // Function RigVM.RigVMHost.GetVariableAsString // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5684b60
	struct TArray<struct FName> GetSupportedEvents(); // Function RigVM.RigVMHost.GetSupportedEvents // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x56827d0
	struct TArray<struct FName> GetScriptAccessibleVariables(); // Function RigVM.RigVMHost.GetScriptAccessibleVariables // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5686aa0
	struct FRigVMExtendedExecuteContext GetExtendedExecuteContext(); // Function RigVM.RigVMHost.GetExtendedExecuteContext // (Native|Public|BlueprintCallable) // @ game+0x567be00
	float GetDeltaTime(); // Function RigVM.RigVMHost.GetDeltaTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5674c50
	float GetCurrentFramesPerSecond(); // Function RigVM.RigVMHost.GetCurrentFramesPerSecond // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x567d5d0
	float GetAbsoluteTime(); // Function RigVM.RigVMHost.GetAbsoluteTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x567c670
	struct TArray<struct URigVMHost*> FindRigVMHosts(struct UObject* Outer, struct URigVMHost* OptionalClass); // Function RigVM.RigVMHost.FindRigVMHosts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5686350
	bool ExecuteEvent(struct FName& InEventName); // Function RigVM.RigVMHost.ExecuteEvent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5683e60
	bool Execute(struct FName& InEventName); // Function RigVM.RigVMHost.Execute // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x56817b0
	bool CanExecute(); // Function RigVM.RigVMHost.CanExecute // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b5ca40
};

// Class RigVM.RigVMEditorSettings
// Size: 0xb0 (Inherited: 0xb0)
struct URigVMEditorSettings : UDeveloperSettings {
};

