// Class EmbarkTrace.EmbarkCharacterTraceWorldSubsystem
// Size: 0x120 (Inherited: 0xa0)
struct UEmbarkCharacterTraceWorldSubsystem : UWorldSubsystem {
	char pad_a0[0x80]; // 0xa0(0x80)
};

// Class EmbarkTrace.EmbarkTrace
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkTrace : UBlueprintFunctionLibrary {

	bool SphereTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult& OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime, bool bForceMeshTwoSided); // Function EmbarkTrace.EmbarkTrace.SphereTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55526d0
	bool SphereTraceMulti(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult>& OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime, bool bForceMeshTwoSided); // Function EmbarkTrace.EmbarkTrace.SphereTraceMulti // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5558970
	bool QueryTraceHits(struct UObject* WorldContextObject, uint64_t InTraceHandle, struct TArray<struct FHitResult>& OutHits, bool bAppendHits); // Function EmbarkTrace.EmbarkTrace.QueryTraceHits // (Final|Native|Static|Public|HasOutParms) // @ game+0x5564a90
	bool PrimitiveTraceMultiByProfile(struct UObject* WorldContextObject, struct TArray<struct FHitResult>& OutOverlaps, struct FVector& TraceStart, struct FVector& TraceEnd, struct FRotator& TraceRot, struct FName ProfileName, struct TArray<struct AActor*> ActorsToIgnore, struct UPrimitiveComponent* PrimitiveComponent, struct FName BoneName); // Function EmbarkTrace.EmbarkTrace.PrimitiveTraceMultiByProfile // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x556aa60
	bool PrimitiveOverlapMultiByProfile(struct UObject* WorldContextObject, struct TArray<struct FOverlapResult>& OutOverlaps, struct FVector& Position, struct FQuat& Rotation, struct FName ProfileName, struct TArray<struct AActor*> ActorsToIgnore, struct UPrimitiveComponent* PrimitiveComponent, struct FName BoneName); // Function EmbarkTrace.EmbarkTrace.PrimitiveOverlapMultiByProfile // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5570560
	bool LineTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult& OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime, bool bForceMeshTwoSided); // Function EmbarkTrace.EmbarkTrace.LineTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55641a0
	bool LineTraceMulti(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult>& OutHits, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime, bool bForceMeshTwoSided); // Function EmbarkTrace.EmbarkTrace.LineTraceMulti // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x556ddc0
	bool LineTraceComponent(struct UPrimitiveComponent* PrimitiveComponent, struct FVector TraceStart, struct FVector TraceEnd, bool bTraceComplex, bool bShowTrace, bool bPersistentShowTrace, struct FVector& HitLocation, struct FVector& HitNormal, struct FName& BoneName, struct FHitResult& OutHit, enum class ECollisionChannel TraceChannel); // Function EmbarkTrace.EmbarkTrace.LineTraceComponent // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5567280
	bool CapsuleTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, float HalfHeight, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, enum class EDrawDebugTrace DrawDebugType, struct FHitResult& OutHit, bool bIgnoreSelf, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime, struct FRotator Orientation); // Function EmbarkTrace.EmbarkTrace.CapsuleTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x556fd10
	uint64_t BatchLineTraceSingleByProfile(struct UObject* WorldContextObject, struct TArray<struct FEmbarkTraceLineSeg>& LineSegs, struct FName ProfileName, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, bool bIgnoreSelf, struct TArray<struct FHitResult>& OutHits); // Function EmbarkTrace.EmbarkTrace.BatchLineTraceSingleByProfile // (Final|Native|Static|Public|HasOutParms) // @ game+0x5555b80
	uint64_t AsyncSphereTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, float Radius, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, bool bIgnoreSelf); // Function EmbarkTrace.EmbarkTrace.AsyncSphereTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5563480
	uint64_t AsyncLineTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, bool bIgnoreSelf); // Function EmbarkTrace.EmbarkTrace.AsyncLineTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5568020
	uint64_t AsyncCapsuleTraceSingle(struct UObject* WorldContextObject, struct FVector Start, struct FVector End, struct FRotator Orientation, float Radius, float HalfHeight, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, bool bIgnoreSelf); // Function EmbarkTrace.EmbarkTrace.AsyncCapsuleTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5556d50
	uint64_t AsyncBoxTraceSingle(struct UObject* WorldContextObject, struct FVector& Start, struct FVector& End, struct FVector& BoxHalfExtent, struct FQuat BoxRotation, enum class ETraceTypeQuery TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, bool bIgnoreSelf); // Function EmbarkTrace.EmbarkTrace.AsyncBoxTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x556d040
	bool ActorLineTraceSingle(struct AActor* AgainstActor, struct FVector& Start, struct FVector& End, enum class ECollisionChannel TraceChannel, bool bTraceComplex, struct FHitResult& OutHit); // Function EmbarkTrace.EmbarkTrace.ActorLineTraceSingle // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x55694d0
};

// Class EmbarkTrace.EmbarkRayQueryBuffer
// Size: 0x140 (Inherited: 0xa0)
struct UEmbarkRayQueryBuffer : UObject {
	struct UObject* WorldContextObject; // 0x98(0x08)
	struct TArray<struct FVector> Start; // 0xa0(0x10)
	struct TArray<struct FVector> End; // 0xb0(0x10)
	enum class ETraceTypeQuery TraceChannel; // 0xc0(0x01)
	bool bTraceComplex; // 0xc1(0x01)
	struct TArray<struct AActor*> ActorsToIgnore; // 0xc8(0x10)
	enum class EDrawDebugTrace DrawDebugType; // 0xd8(0x01)
	char pad_db[0x5]; // 0xdb(0x05)
	struct TArray<struct FRayHitSimple> Hits; // 0xe0(0x10)
	bool bIgnoreSelf; // 0xf0(0x01)
	char pad_f1[0x3]; // 0xf1(0x03)
	struct FLinearColor TraceColor; // 0xf4(0x10)
	struct FLinearColor TraceHitColor; // 0x104(0x10)
	float DrawTime; // 0x114(0x04)
	char pad_118[0x28]; // 0x118(0x28)

	void Tick(float DeltaTime); // Function EmbarkTrace.EmbarkRayQueryBuffer.Tick // (Final|Native|Public|BlueprintCallable) // @ game+0x555ba10
	void SetNum(int32_t Size); // Function EmbarkTrace.EmbarkRayQueryBuffer.SetNum // (Final|Native|Public|BlueprintCallable) // @ game+0x5553a90
	bool HasCompleted(); // Function EmbarkTrace.EmbarkRayQueryBuffer.HasCompleted // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55595c0
	void Execute(int32_t FrameDelay); // Function EmbarkTrace.EmbarkRayQueryBuffer.Execute // (Final|Native|Public|BlueprintCallable) // @ game+0x5553650
};

// Class EmbarkTrace.EmbarkGridQueryBuffer
// Size: 0x3b0 (Inherited: 0xa0)
struct UEmbarkGridQueryBuffer : UObject {
	struct UObject* WorldContextObject; // 0x98(0x08)
	enum class ETraceTypeQuery TraceChannel; // 0xa0(0x01)
	struct FName TraceProfile; // 0xa4(0x08)
	bool bTraceComplex; // 0xac(0x01)
	struct TArray<struct AActor*> ActorsToIgnore; // 0xb0(0x10)
	enum class EDrawDebugTrace DrawDebugType; // 0xc0(0x01)
	bool bIgnoreSelf; // 0xc1(0x01)
	struct FLinearColor TraceColor; // 0xc4(0x10)
	struct FLinearColor TraceHitColor; // 0xd4(0x10)
	float DrawTime; // 0xe4(0x04)
	bool bUseBilinearFilter; // 0xe8(0x01)
	char pad_e9[0x3]; // 0xe9(0x03)
	int32_t MaximumRaysPerTick; // 0xec(0x04)
	int32_t RaysPerTick; // 0xf0(0x04)
	bool bUseAdaptiveRayCount; // 0xf4(0x01)
	char pad_f5[0x3]; // 0xf5(0x03)
	int32_t AdaptiveGrowth; // 0xf8(0x04)
	int32_t AdaptiveDecay; // 0xfc(0x04)
	float FlushFrequency; // 0x100(0x04)
	int32_t CacheMissCount; // 0x104(0x04)
	bool bTreatPenetratingAsVerticalColumn; // 0x108(0x01)
	char pad_109[0x3]; // 0x109(0x03)
	float RayLength; // 0x10c(0x04)
	float RayStartHeight; // 0x110(0x04)
	bool bVisualizeGrid; // 0x114(0x01)
	char pad_115[0x3]; // 0x115(0x03)
	int32_t RayCount; // 0x118(0x04)
	char pad_11c[0x294]; // 0x11c(0x294)

	void Update(struct FVector& Location, float Orientation, struct FVector& LinearVelocity); // Function EmbarkTrace.EmbarkGridQueryBuffer.Update // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x556f460
	void Tick(float DeltaTime); // Function EmbarkTrace.EmbarkGridQueryBuffer.Tick // (Final|Native|Public|BlueprintCallable) // @ game+0x555f9e0
	void SetSize(int32_t SamplePointsX, int32_t SamplePointsY, float InternalResolutionRatio, float Width, float RayLength, float CacheScale); // Function EmbarkTrace.EmbarkGridQueryBuffer.SetSize // (Final|Native|Public|BlueprintCallable) // @ game+0x556aea0
	void SampleToBuffer(); // Function EmbarkTrace.EmbarkGridQueryBuffer.SampleToBuffer // (Final|Native|Public|BlueprintCallable) // @ game+0x555fba0
	struct FIntPoint ProjectToSampledGrid(struct FVector Location); // Function EmbarkTrace.EmbarkGridQueryBuffer.ProjectToSampledGrid // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5555e80
	int32_t GetSamplePointsY(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetSamplePointsY // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2545700
	int32_t GetSamplePointsX(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetSamplePointsX // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25326a0
	float GetSampleCellSize(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetSampleCellSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55555a0
	struct TArray<struct FRayHitSimple> GetResults(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetResults // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55533b0
	void GetCurrentSamplingLocations(struct FVector& Origin, struct FVector& StepSide, struct FVector& StepRow); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetCurrentSamplingLocations // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x556a410
	float GetCurrentOrientation(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetCurrentOrientation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f6c8d0
	struct FVector GetCurrentLocation(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetCurrentLocation // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x556bcc0
	float GetCellSize(); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetCellSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x55596e0
	bool GetAverageHeightsAboveGrid(struct TArray<struct FVector>& DesiredPoints, struct TArray<float>& QueryRadii, struct TArray<float>& OutHeights, struct TArray<enum class EQueryResult>& Status, bool bAverageNormals, struct TArray<struct FVector>& OutNormals, bool bVisualize); // Function EmbarkTrace.EmbarkGridQueryBuffer.GetAverageHeightsAboveGrid // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x556a620
	void ForceInvalidateCache(); // Function EmbarkTrace.EmbarkGridQueryBuffer.ForceInvalidateCache // (Final|Native|Public|BlueprintCallable) // @ game+0x5561030
	void CustomSampleToBuffer(struct TArray<struct FVector>& SamplePoints); // Function EmbarkTrace.EmbarkGridQueryBuffer.CustomSampleToBuffer // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5569410
};

