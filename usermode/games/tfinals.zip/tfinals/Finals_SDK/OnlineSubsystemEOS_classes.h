// Class OnlineSubsystemEOS.NetDriverEOS
// Size: 0x8f0 (Inherited: 0x8f0)
struct UNetDriverEOS : UNetDriverEOSBase {
};

// Class OnlineSubsystemEOS.EOSArtifactSettings
// Size: 0xa0 (Inherited: 0xa0)
struct UEOSArtifactSettings : UDataAsset {
};

// Class OnlineSubsystemEOS.EOSSettings
// Size: 0x110 (Inherited: 0xb0)
struct UEOSSettings : URuntimeOptionsBase {
	struct FString CacheDir; // 0xa8(0x10)
	struct FString DefaultArtifactName; // 0xb8(0x10)
	int32_t TickBudgetInMilliseconds; // 0xc8(0x04)
	bool bEnableOverlay; // 0xcc(0x01)
	bool bEnableSocialOverlay; // 0xcd(0x01)
	bool bEnableEditorOverlay; // 0xce(0x01)
	bool bShouldEnforceBeingLaunchedByEGS; // 0xcf(0x01)
	struct TArray<struct FString> TitleStorageTags; // 0xd0(0x10)
	int32_t TitleStorageReadChunkLength; // 0xe0(0x04)
	struct TArray<struct FArtifactSettings> Artifacts; // 0xe8(0x10)
	struct TArray<struct FString> AuthScopeFlags; // 0xf8(0x10)
	bool bUseEAS; // 0x108(0x01)
	bool bUseEOSConnect; // 0x109(0x01)
	bool bMirrorStatsToEOS; // 0x10a(0x01)
	bool bMirrorAchievementsToEOS; // 0x10b(0x01)
	bool bUseEOSSessions; // 0x10c(0x01)
	bool bMirrorPresenceToEAS; // 0x10d(0x01)
};

