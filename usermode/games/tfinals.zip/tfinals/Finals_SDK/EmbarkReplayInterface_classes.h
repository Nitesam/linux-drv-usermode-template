// Class EmbarkReplayInterface.EmbarkReplayGameInstanceInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkReplayGameInstanceInterface : UInterface {
};

// Class EmbarkReplayInterface.EmbarkReplayGameViewportClientInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkReplayGameViewportClientInterface : UInterface {
};

// Class EmbarkReplayInterface.EmbarkInstantReplaySetting
// Size: 0x140 (Inherited: 0xd0)
struct UEmbarkInstantReplaySetting : UIEmbarkOptionEnum {
	struct FText OnText; // 0xd0(0x18)
	struct FText OffText; // 0xe8(0x18)
	struct FText AutodetectFormatText; // 0x100(0x18)
	struct FText InvalidText; // 0x118(0x18)
	char pad_130[0x10]; // 0x130(0x10)
};

// Class EmbarkReplayInterface.EmbarkReplaySettingsTweakable
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkReplaySettingsTweakable : UTweakableObject {
	int32_t PlatformSupportOverride; // 0x98(0x04)
	int32_t AutoDetectSystemMemoryThresholdGB; // 0x9c(0x04)
	float AutoDetectCPUScoreThreshold; // 0xa0(0x04)
	float ReplayFileTransferTimeout_EarlyInit; // 0xa4(0x04)
	float ReplayFileTransferTimeout; // 0xa8(0x04)
};

// Class EmbarkReplayInterface.EmbarkReplaySettingStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkReplaySettingStatics : UObject {

	void LogInstantReplayBenchmarkAndSettings(struct UObject* WorldContext); // Function EmbarkReplayInterface.EmbarkReplaySettingStatics.LogInstantReplayBenchmarkAndSettings // (Final|Native|Static|Public) // @ game+0x5bbf110
	bool IsInstantReplaySupportedByPlatform(); // Function EmbarkReplayInterface.EmbarkReplaySettingStatics.IsInstantReplaySupportedByPlatform // (Final|Native|Static|Public) // @ game+0x5bbf030
	bool IsInstantReplayEnabledBySetting(struct UObject* WorldContext); // Function EmbarkReplayInterface.EmbarkReplaySettingStatics.IsInstantReplayEnabledBySetting // (Final|Native|Static|Public) // @ game+0x5bbf4a0
	bool IsHardwareMatchingMinimumRequirements(); // Function EmbarkReplayInterface.EmbarkReplaySettingStatics.IsHardwareMatchingMinimumRequirements // (Final|Native|Static|Public) // @ game+0x5bbf1b0
};

// Class EmbarkReplayInterface.EmbarkReplayUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkReplayUtils : UObject {

	bool IsReplayEnabledForWorld(struct UObject* WorldContextObject); // Function EmbarkReplayInterface.EmbarkReplayUtils.IsReplayEnabledForWorld // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5bc04d0
	bool IsInReplayWorld(struct UObject* WorldContextObject); // Function EmbarkReplayInterface.EmbarkReplayUtils.IsInReplayWorld // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5bbff40
	struct APlayerController* GetSourceWorldPlayerController(struct UObject* WorldContextObject); // Function EmbarkReplayInterface.EmbarkReplayUtils.GetSourceWorldPlayerController // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5bbf600
	struct UWorld* GetSourceWorld(struct UObject* WorldContextObject); // Function EmbarkReplayInterface.EmbarkReplayUtils.GetSourceWorld // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5bc0020
	struct UWorld* GetReplayWorld(struct UObject* WorldContextObject); // Function EmbarkReplayInterface.EmbarkReplayUtils.GetReplayWorld // (Final|Native|Static|Public) // @ game+0x5bc01c0
	uint64_t GetReplayNetGuidForActor(struct UObject* WorldContextObject, struct AActor* InSourceWorldActor); // Function EmbarkReplayInterface.EmbarkReplayUtils.GetReplayNetGuidForActor // (Final|Native|Static|Public) // @ game+0x5bbfc30
	struct AActor* GetReplayActorFromNetGuid(struct UWorld* ReplayWorld, uint64_t InNetGuid); // Function EmbarkReplayInterface.EmbarkReplayUtils.GetReplayActorFromNetGuid // (Final|Native|Static|Public) // @ game+0x5bc00c0
	float ConvertSourceTimeToReplayTime(struct UObject* WorldContextObject, float InSourceTime); // Function EmbarkReplayInterface.EmbarkReplayUtils.ConvertSourceTimeToReplayTime // (Final|Native|Static|Public) // @ game+0x5bbfe00
	float CalculateReplayTimeDilation(float TimeElapsed, float TimeTransitionDuration, float TimeDilationFinalValue); // Function EmbarkReplayInterface.EmbarkReplayUtils.CalculateReplayTimeDilation // (Final|Native|Static|Public) // @ game+0x5bbf900
	float CalculateRealTimeElapsedDuringDilation(float DilatedTimeLeft, float RealTimeTimeIntoDilation, float TimeTransitionDuration, float TimeDilationFinalValue); // Function EmbarkReplayInterface.EmbarkReplayUtils.CalculateRealTimeElapsedDuringDilation // (Final|Native|Static|Public) // @ game+0x5bbf6a0
};

