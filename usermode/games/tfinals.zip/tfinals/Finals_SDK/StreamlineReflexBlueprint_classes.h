// Class StreamlineReflexBlueprint.StreamlineLibraryReflex
// Size: 0xa0 (Inherited: 0xa0)
struct UStreamlineLibraryReflex : UBlueprintFunctionLibrary {

	void SetReflexMode(enum class EStreamlineReflexMode Mode); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.SetReflexMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5a81fc0
	enum class EStreamlineFeatureSupport QueryReflexSupport(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.QueryReflexSupport // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a80a60
	bool IsReflexSupported(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.IsReflexSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a81d40
	bool IsReflexModeSupported(enum class EStreamlineReflexMode ReflexMode); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.IsReflexModeSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a809c0
	struct TArray<enum class EStreamlineReflexMode> GetSupportedReflexModes(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.GetSupportedReflexModes // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a819f0
	float GetRenderLatencyInMs(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.GetRenderLatencyInMs // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a847d0
	enum class EStreamlineReflexMode GetReflexMode(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.GetReflexMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a81a80
	float GetGameToRenderLatencyInMs(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.GetGameToRenderLatencyInMs // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a80990
	float GetGameLatencyInMs(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.GetGameLatencyInMs // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a81100
	enum class EStreamlineReflexMode GetDefaultReflexMode(); // Function StreamlineReflexBlueprint.StreamlineLibraryReflex.GetDefaultReflexMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a81ab0
};

