// Class Quilkin.Quilkin
// Size: 0xb0 (Inherited: 0xa0)
struct UQuilkin : UEngineSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class Quilkin.QuilkinDeveloperSettings
// Size: 0x100 (Inherited: 0xb0)
struct UQuilkinDeveloperSettings : UDeveloperSettings {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct TArray<char> RoutingToken; // 0xb8(0x10)
	bool Enabled; // 0xc8(0x01)
	bool EnabledInPie; // 0xc9(0x01)
	bool MeasureEndpoints; // 0xca(0x01)
	char pad_cb[0x5]; // 0xcb(0x05)
	uint64_t PingThresholdMillis; // 0xd0(0x08)
	struct TArray<struct FQuilkinEndpoint> Endpoints; // 0xd8(0x10)
	bool IPv6Prioritised; // 0xe8(0x01)
	bool ProxyFailover; // 0xe9(0x01)
	char pad_ea[0x2]; // 0xea(0x02)
	int32_t FailoverCooldownDurationSec; // 0xec(0x04)
	int32_t InitialCooldownDurationSec; // 0xf0(0x04)
	float PacketLossThresholdPercent; // 0xf4(0x04)
	int32_t PacketLossThresholdDurationSec; // 0xf8(0x04)
	int32_t PacketJitterThresholdSec; // 0xfc(0x04)
};

// Class Quilkin.QuilkinConfigSubsystem
// Size: 0x2f0 (Inherited: 0xa0)
struct UQuilkinConfigSubsystem : UEngineSubsystem {
	bool PacketHandling; // 0xa0(0x01)
	char pad_a1[0x24f]; // 0xa1(0x24f)
};

