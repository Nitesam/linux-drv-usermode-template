// Enum AudioModulation.ESoundModulationLFOShape
enum class ESoundModulationLFOShape : uint8_t {
	Sine = 0,
	UpSaw = 1,
	DownSaw = 2,
	Square = 3,
	Triangle = 4,
	Exponential = 5,
	RandomSampleHold = 6,
	COUNT = 7,
	ESoundModulationLFOShape_MAX = 8
};

// ScriptStruct AudioModulation.SoundModulationADEnvelopeParams
// Size: 0x14 (Inherited: 0x00)
struct FSoundModulationADEnvelopeParams {
	float AttackTime; // 0x00(0x04)
	float DecayTime; // 0x04(0x04)
	float AttackCurve; // 0x08(0x04)
	float DecayCurve; // 0x0c(0x04)
	bool bLooping; // 0x10(0x01)
	bool bBypass; // 0x11(0x01)
	char pad_12[0x2]; // 0x12(0x02)
};

// ScriptStruct AudioModulation.EnvelopeFollowerGeneratorParams
// Size: 0x20 (Inherited: 0x00)
struct FEnvelopeFollowerGeneratorParams {
	bool bBypass; // 0x00(0x01)
	bool bInvert; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct UAudioBus* AudioBus; // 0x08(0x08)
	float Gain; // 0x10(0x04)
	float AttackTime; // 0x14(0x04)
	float ReleaseTime; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct AudioModulation.SoundModulationLFOParams
// Size: 0x20 (Inherited: 0x00)
struct FSoundModulationLFOParams {
	enum class ESoundModulationLFOShape Shape; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float ExponentialFactor; // 0x04(0x04)
	float Width; // 0x08(0x04)
	float Amplitude; // 0x0c(0x04)
	float Frequency; // 0x10(0x04)
	float Offset; // 0x14(0x04)
	float Phase; // 0x18(0x04)
	bool bLooping; // 0x1c(0x01)
	bool bBypass; // 0x1d(0x01)
	char pad_1e[0x2]; // 0x1e(0x02)
};

// ScriptStruct AudioModulation.SoundControlBusMixStage
// Size: 0x28 (Inherited: 0x00)
struct FSoundControlBusMixStage {
	struct USoundControlBus* Bus; // 0x00(0x08)
	struct FSoundModulationMixValue Value; // 0x08(0x20)
};

// ScriptStruct AudioModulation.SoundModulationMixValue
// Size: 0x20 (Inherited: 0x00)
struct FSoundModulationMixValue {
	float TargetValue; // 0x00(0x04)
	float AttackTime; // 0x04(0x04)
	float ReleaseTime; // 0x08(0x04)
	char pad_c[0x14]; // 0x0c(0x14)
};

// ScriptStruct AudioModulation.SoundModulationParameterSettings
// Size: 0x04 (Inherited: 0x00)
struct FSoundModulationParameterSettings {
	float ValueNormalized; // 0x00(0x04)
};

// ScriptStruct AudioModulation.SoundModulationTransform
// Size: 0xb8 (Inherited: 0xb8)
struct FSoundModulationTransform : FWaveTableTransform {
};

// ScriptStruct AudioModulation.SoundControlModulationInput
// Size: 0xc8 (Inherited: 0x00)
struct FSoundControlModulationInput {
	char bSampleAndHold : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSoundModulationTransform Transform; // 0x08(0xb8)
	struct USoundControlBus* Bus; // 0xc0(0x08)
};

// ScriptStruct AudioModulation.SoundControlModulationPatch
// Size: 0x20 (Inherited: 0x00)
struct FSoundControlModulationPatch {
	bool bBypass; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct USoundModulationParameter* OutputParameter; // 0x08(0x08)
	struct TArray<struct FSoundControlModulationInput> Inputs; // 0x10(0x10)
};

