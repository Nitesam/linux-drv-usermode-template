// ScriptStruct EmbarkFastReplicator.EmbarkFastReplicatorActorOrComponent
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkFastReplicatorActorOrComponent {
	struct UObject* Actor; // 0x00(0x08)
	struct UActorComponent* Component; // 0x08(0x08)
};

// ScriptStruct EmbarkFastReplicator.EmbarkFastReplicatorRegisterToken
// Size: 0x04 (Inherited: 0x00)
struct FEmbarkFastReplicatorRegisterToken {
	int32_t Key; // 0x00(0x04)
};

// ScriptStruct EmbarkFastReplicator.EmbarkFastArrayBase
// Size: 0x120 (Inherited: 0x110)
struct FEmbarkFastArrayBase : FFastArraySerializer {
	char pad_110[0x10]; // 0x110(0x10)
};

// ScriptStruct EmbarkFastReplicator.EmbarkFastArrayItemBase
// Size: 0x10 (Inherited: 0x0c)
struct FEmbarkFastArrayItemBase : FFastArraySerializerItem {
	char pad_c[0x4]; // 0x0c(0x04)
};

// ScriptStruct EmbarkFastReplicator.TestEmbarkFastArrayItemMockup
// Size: 0x20 (Inherited: 0x10)
struct FTestEmbarkFastArrayItemMockup : FEmbarkFastArrayItemBase {
	struct FEmbarkFastReplicatorActorOrComponent Ref; // 0x10(0x10)
};

// ScriptStruct EmbarkFastReplicator.TestEmbarkFastArrayMockup
// Size: 0x130 (Inherited: 0x120)
struct FTestEmbarkFastArrayMockup : FEmbarkFastArrayBase {
	struct TArray<struct FTestEmbarkFastArrayItemMockup> Items; // 0x120(0x10)
};

// ScriptStruct EmbarkFastReplicator.EmbarkFastArrayTransformItem
// Size: 0x88 (Inherited: 0x10)
struct FEmbarkFastArrayTransformItem : FEmbarkFastArrayItemBase {
	struct FEmbarkFastReplicatorActorOrComponent Ref; // 0x10(0x10)
	struct FReplicatedTransform Transform; // 0x20(0x68)
};

// ScriptStruct EmbarkFastReplicator.EmbarkFastArrayTransform
// Size: 0x130 (Inherited: 0x120)
struct FEmbarkFastArrayTransform : FEmbarkFastArrayBase {
	struct TArray<struct FEmbarkFastArrayTransformItem> Items; // 0x120(0x10)
};

