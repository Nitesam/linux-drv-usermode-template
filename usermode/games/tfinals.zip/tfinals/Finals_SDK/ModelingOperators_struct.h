// Enum ModelingOperators.ERecomputeUVsPropertiesUnwrapType
enum class ERecomputeUVsPropertiesUnwrapType : uint8_t {
	ExpMap = 0,
	Conformal = 1,
	SpectralConformal = 2,
	IslandMerging = 3,
	ERecomputeUVsPropertiesUnwrapType_MAX = 4
};

// Enum ModelingOperators.ERecomputeUVsPropertiesIslandMode
enum class ERecomputeUVsPropertiesIslandMode : uint8_t {
	PolyGroups = 0,
	ExistingUVs = 1,
	ERecomputeUVsPropertiesIslandMode_MAX = 2
};

// Enum ModelingOperators.ERecomputeUVsToolOrientationMode
enum class ERecomputeUVsToolOrientationMode : uint8_t {
	None = 0,
	MinBounds = 1,
	ERecomputeUVsToolOrientationMode_MAX = 2
};

// Enum ModelingOperators.ERecomputeUVsPropertiesLayoutType
enum class ERecomputeUVsPropertiesLayoutType : uint8_t {
	None = 0,
	Repack = 1,
	NormalizeToExistingBounds = 2,
	NormalizeToBounds = 3,
	NormalizeToWorld = 4,
	ERecomputeUVsPropertiesLayoutType_MAX = 5
};

// Enum ModelingOperators.EFlattenCurveMethod
enum class EFlattenCurveMethod : uint8_t {
	DoNotFlatten = 0,
	ToBestFitPlane = 1,
	AlongX = 2,
	AlongY = 3,
	AlongZ = 4,
	EFlattenCurveMethod_MAX = 5
};

// Enum ModelingOperators.ECombineCurvesMethod
enum class ECombineCurvesMethod : uint8_t {
	LeaveSeparate = 0,
	Union = 1,
	Intersect = 2,
	Difference = 3,
	ExclusiveOr = 4,
	ECombineCurvesMethod_MAX = 5
};

// Enum ModelingOperators.EOffsetClosedCurvesMethod
enum class EOffsetClosedCurvesMethod : uint8_t {
	DoNotOffset = 0,
	OffsetOuterSide = 1,
	OffsetBothSides = 2,
	EOffsetClosedCurvesMethod_MAX = 3
};

// Enum ModelingOperators.EOffsetOpenCurvesMethod
enum class EOffsetOpenCurvesMethod : uint8_t {
	TreatAsClosed = 0,
	Offset = 1,
	EOffsetOpenCurvesMethod_MAX = 2
};

// Enum ModelingOperators.EOffsetJoinMethod
enum class EOffsetJoinMethod : uint8_t {
	Square = 0,
	Miter = 1,
	Round = 2,
	EOffsetJoinMethod_MAX = 3
};

// Enum ModelingOperators.EOpenCurveEndShapes
enum class EOpenCurveEndShapes : uint8_t {
	Square = 0,
	Round = 1,
	Butt = 2,
	EOpenCurveEndShapes_MAX = 3
};

// Enum ModelingOperators.EUVLayoutType
enum class EUVLayoutType : uint8_t {
	Transform = 0,
	Stack = 1,
	Repack = 2,
	Normalize = 3,
	EUVLayoutType_MAX = 4
};

// Enum ModelingOperators.ENormalCalculationMethod
enum class ENormalCalculationMethod : uint8_t {
	AreaWeighted = 0,
	AngleWeighted = 1,
	AreaAngleWeighting = 2,
	ENormalCalculationMethod_MAX = 3
};

// Enum ModelingOperators.ESplitNormalMethod
enum class ESplitNormalMethod : uint8_t {
	UseExistingTopology = 0,
	FaceNormalThreshold = 1,
	FaceGroupID = 2,
	PerTriangle = 3,
	PerVertex = 4,
	ESplitNormalMethod_MAX = 5
};

// Enum ModelingOperators.EHoleFillOpFillType
enum class EHoleFillOpFillType : uint8_t {
	TriangleFan = 0,
	PolygonEarClipping = 1,
	Planar = 2,
	Minimal = 3,
	Smooth = 4,
	EHoleFillOpFillType_MAX = 5
};

// Enum ModelingOperators.ERemeshType
enum class ERemeshType : uint8_t {
	Standard = 0,
	FullPass = 1,
	NormalFlow = 2,
	ERemeshType_MAX = 3
};

// Enum ModelingOperators.ERemeshSmoothingType
enum class ERemeshSmoothingType : uint8_t {
	Uniform = 0,
	Cotangent = 1,
	MeanValue = 2,
	ERemeshSmoothingType_MAX = 3
};

// Enum ModelingOperators.ECSGOperation
enum class ECSGOperation : uint8_t {
	DifferenceAB = 0,
	DifferenceBA = 1,
	Intersect = 2,
	Union = 3,
	ECSGOperation_MAX = 4
};

// Enum ModelingOperators.ETrimOperation
enum class ETrimOperation : uint8_t {
	TrimA = 0,
	TrimB = 1,
	ETrimOperation_MAX = 2
};

// Enum ModelingOperators.ETrimSide
enum class ETrimSide : uint8_t {
	RemoveInside = 0,
	RemoveOutside = 1,
	ETrimSide_MAX = 2
};

// Enum ModelingOperators.EMorphologyOperation
enum class EMorphologyOperation : uint8_t {
	Dilate = 0,
	Contract = 1,
	Close = 2,
	Open = 3,
	EMorphologyOperation_MAX = 4
};

// Enum ModelingOperators.EUVProjectionMethod
enum class EUVProjectionMethod : uint8_t {
	Box = 0,
	Cylinder = 1,
	Plane = 2,
	ExpMap = 3,
	EUVProjectionMethod_MAX = 4
};

