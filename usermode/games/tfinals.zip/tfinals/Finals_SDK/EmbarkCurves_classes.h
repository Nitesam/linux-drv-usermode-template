// Class EmbarkCurves.CurveFloatMixin
// Size: 0xa0 (Inherited: 0xa0)
struct UCurveFloatMixin : UObject {

	struct TArray<struct FRichCurveKey> GetKeys(struct UCurveFloat* Curve); // Function EmbarkCurves.CurveFloatMixin.GetKeys // (Final|Native|Static|Public) // @ game+0x8cd7620
};

