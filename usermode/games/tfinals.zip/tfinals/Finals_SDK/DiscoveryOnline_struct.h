// Enum DiscoveryOnline.EStoreClaimGiftsResult
enum class EStoreClaimGiftsResult : uint8_t {
	Success = 0,
	Failed = 1,
	ChangesetFailed = 2,
	EStoreClaimGiftsResult_MAX = 3
};

// Enum DiscoveryOnline.EStorePurchaseResult
enum class EStorePurchaseResult : uint8_t {
	Success = 0,
	Cancelled = 1,
	PreventedByMatchmaking = 2,
	Failed = 3,
	ReconciliationFailed = 4,
	NotAllowed = 5,
	OverlayDisabled = 6,
	ChangesetFailed = 7,
	EStorePurchaseResult_MAX = 8
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyCreateLobbyResult
enum class EDiscoveryPrivateLobbyCreateLobbyResult : uint8_t {
	Unknown = 0,
	Success = 1,
	UserRestriction = 2,
	NotPartyLeader = 3,
	PartyTooBig = 4,
	EDiscoveryPrivateLobbyCreateLobbyResult_MAX = 5
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyStartLobbyResult
enum class EDiscoveryPrivateLobbyStartLobbyResult : uint8_t {
	Unknown = 0,
	Success = 1,
	LobbyNotFound = 2,
	NotEnoughPlayers = 3,
	MatchInProgress = 4,
	ScenarioIsNotSupportedForPlatform = 5,
	EDiscoveryPrivateLobbyStartLobbyResult_MAX = 6
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyGameState
enum class EDiscoveryPrivateLobbyGameState : uint8_t {
	Idle = 0,
	Matchmaking = 1,
	GameInProgress = 2,
	EDiscoveryPrivateLobbyGameState_MAX = 3
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyLeaderChangedResult
enum class EDiscoveryPrivateLobbyLeaderChangedResult : uint8_t {
	Unknown = 0,
	Success = 1,
	IsLobbyLeaderAlready = 2,
	EDiscoveryPrivateLobbyLeaderChangedResult_MAX = 3
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyJoinLobbyResult
enum class EDiscoveryPrivateLobbyJoinLobbyResult : uint8_t {
	Unknown = 0,
	Success = 1,
	UserRestriction = 2,
	UserBlocked = 3,
	LobbyNotFound = 4,
	PartyTooBig = 5,
	LobbyFull = 6,
	PlatformFailure = 7,
	EDiscoveryPrivateLobbyJoinLobbyResult_MAX = 8
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyLeaveLobbyResult
enum class EDiscoveryPrivateLobbyLeaveLobbyResult : uint8_t {
	Unknown = 0,
	Success = 1,
	Kicked = 2,
	EDiscoveryPrivateLobbyLeaveLobbyResult_MAX = 3
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyOverrideSquadsResult
enum class EDiscoveryPrivateLobbyOverrideSquadsResult : uint8_t {
	Unknown = 0,
	Success = 1,
	Failed = 2,
	EDiscoveryPrivateLobbyOverrideSquadsResult_MAX = 3
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyUpdateLobbyResult
enum class EDiscoveryPrivateLobbyUpdateLobbyResult : uint8_t {
	Unknown = 0,
	Success = 1,
	Failed = 2,
	EDiscoveryPrivateLobbyUpdateLobbyResult_MAX = 3
};

// Enum DiscoveryOnline.EDiscoveryOnlineJoinTournamentMatchError
enum class EDiscoveryOnlineJoinTournamentMatchError : uint8_t {
	Unavailable = 0,
	Unknown = 1,
	CancelledMapLoad = 2,
	EDiscoveryOnlineJoinTournamentMatchError_MAX = 3
};

// Enum DiscoveryOnline.ECircuitType
enum class ECircuitType : uint8_t {
	None = 0,
	FTUE = 1,
	Event = 2,
	Seasonal = 3,
	WorldTour = 4,
	Hidden = 5,
	WorldTourWeekend = 6,
	ECircuitType_MAX = 7
};

// Enum DiscoveryOnline.EQuestActiveOverride
enum class EQuestActiveOverride : uint8_t {
	EQuestActiveOverride_Dates = 0,
	EQuestActiveOverride_Active = 1,
	EQuestActiveOverride_Inactive = 2,
	EQuestActiveOverride_MAX = 3
};

// Enum DiscoveryOnline.EStoreRedeemOutstandingThirdPartyPurchasesResult
enum class EStoreRedeemOutstandingThirdPartyPurchasesResult : uint8_t {
	Success = 0,
	Failed = 1,
	EStoreRedeemOutstandingThirdPartyPurchasesResult_MAX = 2
};

// Enum DiscoveryOnline.EStoreThirdPartyStoreId
enum class EStoreThirdPartyStoreId : uint8_t {
	Epic = 0,
	Microsoft = 1,
	PlayStation = 2,
	Steam = 3,
	Unspecified = 4,
	EStoreThirdPartyStoreId_MAX = 5
};

// Enum DiscoveryOnline.EStoreReconciledProductOrigin
enum class EStoreReconciledProductOrigin : uint8_t {
	Purchase = 0,
	Twitch = 1,
	Giveaway = 2,
	EStoreReconciledProductOrigin_MAX = 3
};

// Enum DiscoveryOnline.EDiscoveryPrivateLobbyState
enum class EDiscoveryPrivateLobbyState : uint8_t {
	Unknown = 0,
	Creating = 1,
	Joining = 2,
	Active = 3,
	Leaving = 4,
	EDiscoveryPrivateLobbyState_MAX = 5
};

// Enum DiscoveryOnline.EServiceRoundStatSummaryType
enum class EServiceRoundStatSummaryType : uint8_t {
	Unknown = 0,
	Ranked = 1,
	Casual = 2,
	Total = 3,
	EServiceRoundStatSummaryType_MAX = 4
};

// ScriptStruct DiscoveryOnline.ItemOwnershipResult
// Size: 0x50 (Inherited: 0x00)
struct FItemOwnershipResult {
	struct TMap<struct FTenancyUserId, int64_t> Ownerships; // 0x00(0x50)
};

// ScriptStruct DiscoveryOnline.DiscoveryLobbyPlayerAssignmentKey
// Size: 0x02 (Inherited: 0x00)
struct FDiscoveryLobbyPlayerAssignmentKey {
	char pad_0[0x2]; // 0x00(0x02)
};

// ScriptStruct DiscoveryOnline.DiscoveryPrivateLobbyInvitation
// Size: 0x18 (Inherited: 0x00)
struct FDiscoveryPrivateLobbyInvitation {
	struct FString LobbyId; // 0x00(0x10)
	struct UServicePlayerProfile* SenderProfile; // 0x10(0x08)
};

// ScriptStruct DiscoveryOnline.DiscoveryOnlineTournamentSession
// Size: 0x28 (Inherited: 0x00)
struct FDiscoveryOnlineTournamentSession {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	bool PenaltyOnLeave; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct DiscoveryOnline.DiscoveryOnlineJoinTournamentUpdate
// Size: 0x78 (Inherited: 0x00)
struct FDiscoveryOnlineJoinTournamentUpdate {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	enum class EApiGatewayDiscoveryJoinTournamentStatus Status; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FApiGatewayDiscoveryGameServer GameServer; // 0x28(0x50)
};

// ScriptStruct DiscoveryOnline.DiscoveryOnlineMonitorTournament
// Size: 0x68 (Inherited: 0x00)
struct FDiscoveryOnlineMonitorTournament {
	struct FString TournamentId; // 0x00(0x10)
	int32_t CurrentTier; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TArray<struct FApiGatewayDiscoveryTournamentTier> Tiers; // 0x18(0x10)
	struct TArray<struct FApiGatewayDiscoveryTournamentMatch> Matches; // 0x28(0x10)
	struct TArray<struct FApiGatewayDiscoveryTournamentTeam> Teams; // 0x38(0x10)
	int32_t LocalMatchIndex; // 0x48(0x04)
	int32_t LocalTeamIndex; // 0x4c(0x04)
	struct FApiGatewayDiscoveryPrecalculatedTournamentResult PrecalculatedResult; // 0x50(0x18)
};

// ScriptStruct DiscoveryOnline.ServiceBattlePassState
// Size: 0x40 (Inherited: 0x00)
struct FServiceBattlePassState {
	struct TArray<struct FString> ClaimedCategories; // 0x00(0x10)
	struct TArray<int64_t> ClaimedEntries; // 0x10(0x10)
	int64_t Level; // 0x20(0x08)
	int64_t TotalXP; // 0x28(0x08)
	int64_t HistoricalCurrencySpent; // 0x30(0x08)
	int64_t BankedLevels; // 0x38(0x08)
};

// ScriptStruct DiscoveryOnline.PlayerCareerData
// Size: 0x78 (Inherited: 0x00)
struct FPlayerCareerData {
	int64_t CurrentFans; // 0x00(0x08)
	struct TMap<int64_t, int64_t> FansPerStop; // 0x08(0x50)
	int64_t SelectedSponsor; // 0x58(0x08)
	int64_t SponsorLevel; // 0x60(0x08)
	int64_t NextLevelProgress; // 0x68(0x08)
	int64_t BufferedFans; // 0x70(0x08)
};

// ScriptStruct DiscoveryOnline.SponsorTrackEntry
// Size: 0x70 (Inherited: 0x00)
struct FSponsorTrackEntry {
	int64_t Level; // 0x00(0x08)
	int64_t AmountFansRequired; // 0x08(0x08)
	int64_t OriginalUnlockPrice; // 0x10(0x08)
	int64_t UnlockPrice; // 0x18(0x08)
	int64_t NormalizedUnlockPrice; // 0x20(0x08)
	int64_t NormalizedOriginalUnlockPrice; // 0x28(0x08)
	struct FProductRewardData RewardData; // 0x30(0x38)
	int64_t TrackSeasonId; // 0x68(0x08)
};

// ScriptStruct DiscoveryOnline.ProductRewardData
// Size: 0x38 (Inherited: 0x00)
struct FProductRewardData {
	int64_t ProductId; // 0x00(0x08)
	int64_t ProductGameAssetId; // 0x08(0x08)
	struct TArray<struct FQuestRewardAssetIdEntry> RewardEntries; // 0x10(0x10)
	struct TArray<struct FRelatedProductIDReward> RelatedProductGameAssetIds; // 0x20(0x10)
	int64_t RankBucketRewardAmount; // 0x30(0x08)
};

// ScriptStruct DiscoveryOnline.RelatedProductIDReward
// Size: 0x10 (Inherited: 0x00)
struct FRelatedProductIDReward {
	int64_t AssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct DiscoveryOnline.QuestRewardAssetIdEntry
// Size: 0x10 (Inherited: 0x00)
struct FQuestRewardAssetIdEntry {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct DiscoveryOnline.QuestTimeStateEntry
// Size: 0x10 (Inherited: 0x00)
struct FQuestTimeStateEntry {
	int64_t StartAtTime; // 0x00(0x08)
	int64_t ExpiresAtTime; // 0x08(0x08)
};

// ScriptStruct DiscoveryOnline.PlayerPersistenceQuestReward
// Size: 0x50 (Inherited: 0x00)
struct FPlayerPersistenceQuestReward {
	struct FProductRewardData Product; // 0x00(0x38)
	int64_t RequiredProgress; // 0x38(0x08)
	int64_t GameAssetId; // 0x40(0x08)
	int64_t Amount; // 0x48(0x08)
};

// ScriptStruct DiscoveryOnline.StageQuestContext
// Size: 0x88 (Inherited: 0x00)
struct FStageQuestContext {
	struct TArray<int64_t> QuestInstanceSlotIds; // 0x00(0x10)
	struct FPlayerPersistenceQuestReward QuestReward; // 0x10(0x50)
	struct FDateTime StartAtTime; // 0x60(0x08)
	struct FDateTime EndsAtTime; // 0x68(0x08)
	enum class EQuestActiveOverride Override; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	int64_t GameAssetId; // 0x78(0x08)
	int64_t StageId; // 0x80(0x08)
};

// ScriptStruct DiscoveryOnline.Circuit
// Size: 0x90 (Inherited: 0x00)
struct FCircuit {
	struct TArray<struct FStageQuestContext> StageQuests; // 0x00(0x10)
	struct TArray<struct FStageQuestContext> HiddenStageQuests; // 0x10(0x10)
	struct FPlayerPersistenceQuestReward QuestReward; // 0x20(0x50)
	enum class ECircuitType Type; // 0x70(0x01)
	char pad_71[0x7]; // 0x71(0x07)
	int64_t GameAssetId; // 0x78(0x08)
	struct FDateTime EndsAt; // 0x80(0x08)
	int64_t CircuitId; // 0x88(0x08)
};

// ScriptStruct DiscoveryOnline.QuestRerollCost
// Size: 0x10 (Inherited: 0x00)
struct FQuestRerollCost {
	int64_t GameAssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct DiscoveryOnline.SyncWriteRequestData
// Size: 0x38 (Inherited: 0x00)
struct FSyncWriteRequestData {
	struct TArray<struct FGuid> PendingWriteGuids; // 0x00(0x10)
	struct FGuid LatestWriteGuid; // 0x10(0x10)
	struct FGuid LatestSyncGuid; // 0x20(0x10)
	bool bPendingSync; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct DiscoveryOnline.SubmitMatchSquadResult
// Size: 0x18 (Inherited: 0x00)
struct FSubmitMatchSquadResult {
	struct FString SquadId; // 0x00(0x10)
	int32_t Score; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct DiscoveryOnline.SubmitMatchReportRequest
// Size: 0x48 (Inherited: 0x00)
struct FSubmitMatchReportRequest {
	struct FString MatchId; // 0x00(0x10)
	struct FString ScenarioId; // 0x10(0x10)
	struct TArray<struct FOnlineMatchReportSquadEntry> ParticipatedSquads; // 0x20(0x10)
	struct TArray<struct FSubmitMatchSquadResult> SquadScores; // 0x30(0x10)
	bool bWasMatchCancelled; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
};

// ScriptStruct DiscoveryOnline.SubmitTournamentMatchResult
// Size: 0x98 (Inherited: 0x00)
struct FSubmitTournamentMatchResult {
	struct FString TournamentId; // 0x00(0x10)
	struct FString MatchId; // 0x10(0x10)
	struct TArray<int32_t> WinningTeamIds; // 0x20(0x10)
	struct TMap<struct FString, struct FString> TravelData; // 0x30(0x50)
	struct FString InGameTravelData; // 0x80(0x10)
	bool bInWasCancelled; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
};

// ScriptStruct DiscoveryOnline.StoreItem
// Size: 0x18 (Inherited: 0x00)
struct FStoreItem {
	int64_t AssetId; // 0x00(0x08)
	int64_t ItemQuantity; // 0x08(0x08)
	bool bOwned; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct DiscoveryOnline.TournamentRequestEntry
// Size: 0xa8 (Inherited: 0x00)
struct FTournamentRequestEntry {
	struct FApiGatewayDiscoveryGameServer GameServer; // 0x00(0x50)
	struct FString TournamentId; // 0x50(0x10)
	struct FString GacId; // 0x60(0x10)
	struct FString MatchId; // 0x70(0x10)
	int32_t JoiningTournamentRetries; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FTimerHandle RetryJoiningTournamentHandle; // 0x88(0x08)
	struct FTimerHandle JoiningGameServerHandle; // 0x90(0x08)
	enum class EApiGatewayDiscoveryJoinTournamentStatus Status; // 0x98(0x01)
	char pad_99[0x3]; // 0x99(0x03)
	float GacPollInterval; // 0x9c(0x04)
	bool bUseGameServerProxy; // 0xa0(0x01)
	bool bFinished; // 0xa1(0x01)
	enum class EDiscoveryOnlineJoinTournamentMatchError FailedCondition; // 0xa2(0x01)
	bool bFailed; // 0xa3(0x01)
	char pad_a4[0x4]; // 0xa4(0x04)
};

// ScriptStruct DiscoveryOnline.DiscoveryPrivateLobbyMapSelection
// Size: 0x50 (Inherited: 0x00)
struct FDiscoveryPrivateLobbyMapSelection {
	struct FString MapName; // 0x00(0x10)
	struct FString Variant; // 0x10(0x10)
	struct FString Condition; // 0x20(0x10)
	struct FString GameShow; // 0x30(0x10)
	struct TArray<struct FString> Decor; // 0x40(0x10)
};

// ScriptStruct DiscoveryOnline.DiscoveryPrivateLobbyCustomSquadSettings
// Size: 0x10 (Inherited: 0x00)
struct FDiscoveryPrivateLobbyCustomSquadSettings {
	int32_t BrandIndex; // 0x00(0x04)
	int32_t ColorIndex; // 0x04(0x04)
	int32_t SpectatorColorIndex; // 0x08(0x04)
	bool bIsSet; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
};

// ScriptStruct DiscoveryOnline.DiscoveryPrivateLobbySquad
// Size: 0x60 (Inherited: 0x00)
struct FDiscoveryPrivateLobbySquad {
	struct TMap<struct FEmbarkUserId, struct UServicePlayerProfile*> Players; // 0x00(0x50)
	struct FDiscoveryPrivateLobbyCustomSquadSettings CustomSquadSettings; // 0x50(0x10)
};

// ScriptStruct DiscoveryOnline.DiscoveryQuestTrackingData
// Size: 0x10 (Inherited: 0x00)
struct FDiscoveryQuestTrackingData {
	struct TArray<struct FString> QuestInstancesTracked; // 0x00(0x10)
};

// ScriptStruct DiscoveryOnline.ServiceProgressionRewardItem
// Size: 0x10 (Inherited: 0x00)
struct FServiceProgressionRewardItem {
	int64_t AssetId; // 0x00(0x08)
	int64_t Amount; // 0x08(0x08)
};

// ScriptStruct DiscoveryOnline.DiscoveryScenarioVisiblePeriod
// Size: 0x10 (Inherited: 0x00)
struct FDiscoveryScenarioVisiblePeriod {
	int64_t StartTime; // 0x00(0x08)
	int64_t EndTime; // 0x08(0x08)
};

// ScriptStruct DiscoveryOnline.DiscoveryScenarioUISettings
// Size: 0x18 (Inherited: 0x00)
struct FDiscoveryScenarioUISettings {
	bool ButtonVisible; // 0x00(0x01)
	bool ButtonDisabled; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct TArray<struct FDiscoveryScenarioVisiblePeriod> VisiblePeriods; // 0x08(0x10)
};

// ScriptStruct DiscoveryOnline.DiscoveryScenarioConditions
// Size: 0x01 (Inherited: 0x00)
struct FDiscoveryScenarioConditions {
	enum class EApiGatewayDiscoverySanctionType SanctionType; // 0x00(0x01)
};

// ScriptStruct DiscoveryOnline.DiscoveryScenarioMapOverrideRotationSettings
// Size: 0x28 (Inherited: 0x00)
struct FDiscoveryScenarioMapOverrideRotationSettings {
	int32_t TimeSwitchInterval; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FString> Maps; // 0x08(0x10)
	struct TArray<struct FString> Modifiers; // 0x18(0x10)
};

// ScriptStruct DiscoveryOnline.DiscoveryScenarioMatchmakingParameters
// Size: 0xb0 (Inherited: 0x00)
struct FDiscoveryScenarioMatchmakingParameters {
	struct FString GameMode; // 0x00(0x10)
	struct FString MapName; // 0x10(0x10)
	int32_t RoundsRequiredToPlay; // 0x20(0x04)
	int32_t MaxSquadSize; // 0x24(0x04)
	int32_t MaxSquads; // 0x28(0x04)
	int32_t MaxPlayers; // 0x2c(0x04)
	struct TMap<struct FString, bool> FeatureFlags; // 0x30(0x50)
	struct FDiscoveryScenarioMapOverrideRotationSettings MapOverrideRotationSettings; // 0x80(0x28)
	bool bAllowSplitParties; // 0xa8(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
};

