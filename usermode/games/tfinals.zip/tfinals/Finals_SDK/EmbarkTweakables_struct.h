// ScriptStruct EmbarkTweakables.OnlineTweakable
// Size: 0x38 (Inherited: 0x00)
struct FOnlineTweakable {
	struct FString ObjectPathName; // 0x00(0x10)
	struct FString PropertyName; // 0x10(0x10)
	struct FString PropertyValue; // 0x20(0x10)
	bool bApplyToInstances; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct EmbarkTweakables.OnlineTweakablesContainer
// Size: 0x10 (Inherited: 0x00)
struct FOnlineTweakablesContainer {
	struct TArray<struct FOnlineTweakable> Tweakables; // 0x00(0x10)
};

// ScriptStruct EmbarkTweakables.Tweakables
// Size: 0x10 (Inherited: 0x00)
struct FTweakables {
	struct TArray<struct FOnlineTweakable> TweakablesForObject; // 0x00(0x10)
};

// ScriptStruct EmbarkTweakables.TweakablesContainer
// Size: 0x50 (Inherited: 0x00)
struct FTweakablesContainer {
	struct TMap<struct FString, struct FTweakables> ObjectPathNameToTweakablesMap; // 0x00(0x50)
};

// ScriptStruct EmbarkTweakables.TweakableDefault
// Size: 0x30 (Inherited: 0x00)
struct FTweakableDefault {
	char pad_0[0x30]; // 0x00(0x30)
};

