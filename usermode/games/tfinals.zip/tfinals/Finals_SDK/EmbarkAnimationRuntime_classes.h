// Class EmbarkAnimationRuntime.CompiledPinExpressionsFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UCompiledPinExpressionsFunctionLibrary : UBlueprintFunctionLibrary {

	bool NotNull(struct UObject* Obj); // Function EmbarkAnimationRuntime.CompiledPinExpressionsFunctionLibrary.NotNull // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x58c2da0
	bool IsNull(struct UObject* Obj); // Function EmbarkAnimationRuntime.CompiledPinExpressionsFunctionLibrary.IsNull // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x58c4e40
};

// Class EmbarkAnimationRuntime.AnimNotify_EmbarkPlaySound
// Size: 0xd0 (Inherited: 0xd0)
struct UAnimNotify_EmbarkPlaySound : UAnimNotify_PlaySound {
	bool bPlaySoundOnNotify; // 0xc8(0x01)

	void PlaySound(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function EmbarkAnimationRuntime.AnimNotify_EmbarkPlaySound.PlaySound // (Final|Native|Public|Const) // @ game+0x58c8f10
};

// Class EmbarkAnimationRuntime.AnimSequenceMixer
// Size: 0x2a0 (Inherited: 0x270)
struct UAnimSequenceMixer : UAnimSequence {
	struct FSequenceMixerSettings MixerSettings; // 0x268(0x10)
	bool bHasValidBakedTracks; // 0x278(0x01)
	struct TArray<struct FSequenceMixerEntry> MixerEntries; // 0x280(0x10)
	char pad_291[0xf]; // 0x291(0x0f)
};

// Class EmbarkAnimationRuntime.AnimBlueprintCompiledPinExpressionsSettings
// Size: 0xe0 (Inherited: 0xb0)
struct UAnimBlueprintCompiledPinExpressionsSettings : UDeveloperSettings {
	struct FSoftClassPath VariableContainerClass; // 0xa8(0x20)
	struct TArray<int32_t> PropertyIndexToByteOffset; // 0xc8(0x10)
};

// Class EmbarkAnimationRuntime.BoneWeightsBlendArrayAsset
// Size: 0xe0 (Inherited: 0xa0)
struct UBoneWeightsBlendArrayAsset : UBoneWeightsBlendArrayAssetBase {
	struct TArray<struct FBoneWeightsBlendArrayEntry> Entries; // 0xa0(0x10)
	float ArrayMin; // 0xb0(0x04)
	float ArrayMax; // 0xb4(0x04)
	struct TArray<struct FBoneWeightsBlendArrayEntry> SortedEntries; // 0xb8(0x10)
	struct TArray<struct UBoneWeightsAsset*> AllUniqueBoneWeightsAssets; // 0xc8(0x10)
	char pad_d8[0x8]; // 0xd8(0x08)
};

// Class EmbarkAnimationRuntime.EmbarkAnimInstance_Base
// Size: 0x400 (Inherited: 0x3f0)
struct UEmbarkAnimInstance_Base : UAnimInstance {
	bool bNeedBlueprintPreUpdateAnimationAnyThread; // 0x3f0(0x01)
	char pad_3f1[0xf]; // 0x3f1(0x0f)

	void SetVariableContainerObjectForCompiledPinExpressions(struct UObject* ContainerObject); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.SetVariableContainerObjectForCompiledPinExpressions // (Final|Native|Public) // @ game+0x58c98c0
	int32_t RandomIntInRange_Threadsafe(int32_t Min, int32_t Max); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.RandomIntInRange_Threadsafe // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x58cd350
	float RandomFloatInRange_Threadsafe(float Min, float Max); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.RandomFloatInRange_Threadsafe // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x58ce000
	bool IsValid_Threadsafe(struct UObject* InObject); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.IsValid_Threadsafe // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x58c83b0
	float GetAnimPlayLengthSafe(struct UAnimSequence* AnimSequence, float ValueIfInvalid); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.GetAnimPlayLengthSafe // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x58cbe80
	struct UAnimSequence* GetAdditiveBaseSequence(struct UAnimSequence* InSequence, float& Time); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.GetAdditiveBaseSequence // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x58cd930
	float FilterInput_Float_InterpConstant(float Target, float InterpSpeed, int32_t ID); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.FilterInput_Float_InterpConstant // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x58c8540
	float FilterInput_BoolToFloat_InterpConstant(bool Target, float InterpSpeed, int32_t ID); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.FilterInput_BoolToFloat_InterpConstant // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x58cf860
	bool FilterInput_Bool_InterpConstant(bool Target, float InterpSpeed, int32_t ID); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.FilterInput_Bool_InterpConstant // (Final|Native|Private|BlueprintCallable|BlueprintPure) // @ game+0x58ca6b0
	float CalculatePlayRateToSpecifiedPoint(float Duration, float Endpoint); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.CalculatePlayRateToSpecifiedPoint // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x58cfb70
	bool BlueprintPreUpdateAnimationGameThread(float DeltaTimeX); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.BlueprintPreUpdateAnimationGameThread // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BlueprintPreUpdateAnimationAnyThread(float DeltaTimeX); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.BlueprintPreUpdateAnimationAnyThread // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BlueprintPostUpdateAnimationGameThread(float DeltaTimeX); // Function EmbarkAnimationRuntime.EmbarkAnimInstance_Base.BlueprintPostUpdateAnimationGameThread // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkAnimationRuntime.EmbarkAnimStateUpdaterComponent
// Size: 0x170 (Inherited: 0x160)
struct UEmbarkAnimStateUpdaterComponent : UActorComponent {
	bool bPausedUpdate; // 0x158(0x01)
	struct USkeletalMeshComponent* PairedMeshComponent; // 0x160(0x08)
	char pad_169[0x7]; // 0x169(0x07)

	void SetPairedMeshComponent(struct USkeletalMeshComponent* Comp); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterComponent.SetPairedMeshComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x58cd4f0
	void ParallelTick(float DeltaSeconds); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterComponent.ParallelTick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void MainThreadPreParallelTick(float DeltaSeconds, bool bIsMeshComponentTicking, bool bTickedPrevFrame, bool& bShouldRunParallelTick); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterComponent.MainThreadPreParallelTick // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void MainThreadDebugDraw(float DeltaSeconds); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterComponent.MainThreadDebugDraw // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkAnimationRuntime.EmbarkAnimStateUpdaterSystem
// Size: 0x3c0 (Inherited: 0x3a0)
struct AEmbarkAnimStateUpdaterSystem : AEmbarkGlobalActor {
	bool bParallelEval; // 0x3a0(0x01)
	char pad_3a1[0x7]; // 0x3a1(0x07)
	struct TArray<struct FEmbarkAnimStateUpdateRegistrationData> RegistrationEntries; // 0x3a8(0x10)
	char pad_3b8[0x8]; // 0x3b8(0x08)

	void SystemTickPostComponentUpdate(float DeltaSeconds); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterSystem.SystemTickPostComponentUpdate // (Native|Event|Public|BlueprintEvent) // @ game+0x2412c00
	void RegisterStateUpdaterComponent(struct UEmbarkAnimStateUpdaterComponent* StateUpdaterComponent, struct USkeletalMeshComponent* MeshComponent); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterSystem.RegisterStateUpdaterComponent // (Final|Native|Public) // @ game+0x58c7ce0
	bool IsStateUpdaterComponentRegistered(struct UEmbarkAnimStateUpdaterComponent* StateUpdaterComponent); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterSystem.IsStateUpdaterComponentRegistered // (Final|Native|Public) // @ game+0x58cabb0
	struct TArray<struct FEmbarkAnimStateUpdateRegistrationData> GetRegistrations(); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterSystem.GetRegistrations // (Final|Native|Public|Const) // @ game+0x58cfce0
	void DeregisterStateUpdaterComponent(struct UEmbarkAnimStateUpdaterComponent* StateUpdaterComponent); // Function EmbarkAnimationRuntime.EmbarkAnimStateUpdaterSystem.DeregisterStateUpdaterComponent // (Final|Native|Public) // @ game+0x58c89e0
};

// Class EmbarkAnimationRuntime.MockEmbarkAnimStateUpdaterComponent
// Size: 0x170 (Inherited: 0x170)
struct UMockEmbarkAnimStateUpdaterComponent : UEmbarkAnimStateUpdaterComponent {
};

// Class EmbarkAnimationRuntime.AnimNotifyEventReferenceMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAnimNotifyEventReferenceMixinLibrary : UObject {

	bool opEquals(struct FAnimNotifyEventReference& LHS, struct FAnimNotifyEventReference& RHS); // Function EmbarkAnimationRuntime.AnimNotifyEventReferenceMixinLibrary.opEquals // (Final|Native|Static|Public|HasOutParms) // @ game+0x58c8ce0
	float GetAuthoredNotifyTriggerTime(struct FAnimNotifyEventReference& EventReference); // Function EmbarkAnimationRuntime.AnimNotifyEventReferenceMixinLibrary.GetAuthoredNotifyTriggerTime // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x58cc5f0
};

