// Class EmbarkConstructable.FComponentOrStyleLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFComponentOrStyleLibrary : UObject {

	struct FComponentOrStyle MakeFromSceneComponent(struct USceneComponent* Component); // Function EmbarkConstructable.FComponentOrStyleLibrary.MakeFromSceneComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e28110
	struct FComponentOrStyle MakeFromPrimitiveComponent(struct UPrimitiveComponent* Component); // Function EmbarkConstructable.FComponentOrStyleLibrary.MakeFromPrimitiveComponent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e28110
	struct FComponentOrStyle MakeFromPhysicsBoneName(struct UPrimitiveComponent* Component, struct FName BoneName); // Function EmbarkConstructable.FComponentOrStyleLibrary.MakeFromPhysicsBoneName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e2c4c0
	struct FComponentOrStyle MakeFromPhysicsBodyIndex(struct UPrimitiveComponent* Component, int32_t BodyIndex); // Function EmbarkConstructable.FComponentOrStyleLibrary.MakeFromPhysicsBodyIndex // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e28d00
	struct FComponentOrStyle MakeFromPart(struct AConstructableBase* PartOwner, int32_t PartID); // Function EmbarkConstructable.FComponentOrStyleLibrary.MakeFromPart // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e2a200
	struct FComponentOrStyle MakeFromHitResult(struct FHitResult& HitResult); // Function EmbarkConstructable.FComponentOrStyleLibrary.MakeFromHitResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e26040
	bool IsValid(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e26320
	bool IsPartReference(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.IsPartReference // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e29e10
	bool IsPartAndDestroyed(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.IsPartAndDestroyed // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e26aa0
	bool IsPartAndAlive(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.IsPartAndAlive // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2c5d0
	struct FTransform GetWorldTransform(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5e27f50
	bool GetTransform(struct FComponentOrStyle& ComponentOrStyle, struct FTransform& OutTransform, bool bWorldTransform); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5e26f80
	struct AActor* GetOwner(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetOwner // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e24b30
	bool GetClosestPointOnCollision(struct FComponentOrStyle& ComponentOrStyle, struct FVector& Point, struct FVector& OutPointOnBody); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetClosestPointOnCollision // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5e2b0a0
	struct FVector GetCenterBounds(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetCenterBounds // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e29700
	bool GetBounds(struct FComponentOrStyle& ComponentOrStyle, struct FBox& Bounds); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetBounds // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e27200
	struct AActor* GetActor(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e24b30
	struct USceneComponent* AdvancedAPI_GetPartReference(struct FComponentOrStyle& ComponentOrStyle, int32_t& OutPartId); // Function EmbarkConstructable.FComponentOrStyleLibrary.AdvancedAPI_GetPartReference // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2a920
	struct USceneComponent* AdvancedAPI_GetComponent(struct FComponentOrStyle& ComponentOrStyle); // Function EmbarkConstructable.FComponentOrStyleLibrary.AdvancedAPI_GetComponent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2d110
};

// Class EmbarkConstructable.ComponentOrStyleTargetHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UComponentOrStyleTargetHandleMixinLibrary : UObject {

	struct FComponentOrStyle GetFirstValidComponentOrStyleTarget(struct FGameplayAbilityTargetDataHandle& Handle); // Function EmbarkConstructable.ComponentOrStyleTargetHandleMixinLibrary.GetFirstValidComponentOrStyleTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e29060
	struct FComponentOrStyle GetComponentOrStyleTarget(struct FGameplayAbilityTargetDataHandle& Handle, int32_t Index); // Function EmbarkConstructable.ComponentOrStyleTargetHandleMixinLibrary.GetComponentOrStyleTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e25740
	struct TArray<struct FComponentOrStyle> GetAllValidComponentOrStyleTargets(struct FGameplayAbilityTargetDataHandle& Handle); // Function EmbarkConstructable.ComponentOrStyleTargetHandleMixinLibrary.GetAllValidComponentOrStyleTargets // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2b280
	void AddComponentOrStyleTarget(struct FGameplayAbilityTargetDataHandle& Handle, struct FComponentOrStyle& Target); // Function EmbarkConstructable.ComponentOrStyleTargetHandleMixinLibrary.AddComponentOrStyleTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e273a0
};

// Class EmbarkConstructable.ConstructableAbilitySystemComponent
// Size: 0x4590 (Inherited: 0x14c0)
struct UConstructableAbilitySystemComponent : UEmbarkAbilitySystemComponent {
	struct FMulticastInlineDelegate OnPartTagsChanged; // 0x14b8(0x10)
	struct FMulticastInlineDelegate OnPartTagAdded; // 0x14c8(0x10)
	struct FMulticastInlineDelegate OnPartTagRemoved; // 0x14d8(0x10)
	struct TSet<int32_t> AllocatedPartIDs; // 0x14e8(0x50)
	struct TSet<struct UGameplayEffect*> PartAbilityResourceCostEffects; // 0x1538(0x50)
	char pad_1590[0x2fa0]; // 0x1590(0x2fa0)
	struct AConstructableBase* OwnerConstructable; // 0x4530(0x08)
	struct TMap<struct UGameplayEffect*, struct FConstructableCustomEffectState> ActivePartEffects; // 0x4538(0x50)
	char pad_4588[0x8]; // 0x4588(0x08)

	bool TrySetPartAttributeBaseValue_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, int32_t PartID, float NewValue); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.TrySetPartAttributeBaseValue_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5e26500
	bool TryGetPartAttributeCurrentValue_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, int32_t PartID, float& OutCurrentValue); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.TryGetPartAttributeCurrentValue_Server // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e27ca0
	bool TryGetPartAttributeBaseValue_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, int32_t PartID, float& OutBaseValue); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.TryGetPartAttributeBaseValue_Server // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e2bd20
	bool TryGetPartAttribute_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, int32_t PartID, struct FGameplayAttribute& OutGameplayAttribute); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.TryGetPartAttribute_Server // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e28e10
	void RemovePartTags(int32_t PartID, struct FGameplayTagContainer& TagsToRemove); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.RemovePartTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e24cb0
	void RemovePartTag(int32_t PartID, struct FGameplayTag& TagToRemove); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.RemovePartTag // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e28bc0
	void RegisterPartAttributeChangedCallbackForAllParts_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, struct UObject* CallbackObject, struct FName CallbackFunctionName_FOnAttributeChangeData); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.RegisterPartAttributeChangedCallbackForAllParts_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5e287d0
	void RegisterPartAttributeChangedCallback_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, int32_t PartID, struct UObject* CallbackObject, struct FName CallbackFunctionName_FOnAttributeChangeData); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.RegisterPartAttributeChangedCallback_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5e279a0
	bool QueryPartTags(int32_t PartID, struct FConstructablePartTagData& OutPartTagData); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.QueryPartTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e26e50
	bool PartHasTag(int32_t PartID, struct FGameplayTag& RequiredTag); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.PartHasTag // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e2a0c0
	bool PartHasAnyTags(int32_t PartID, struct FGameplayTagContainer& RequiredTags); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.PartHasAnyTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e2c2e0
	bool PartHasAllTags(int32_t PartID, struct FGameplayTagContainer& RequiredTags); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.PartHasAllTags // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e2c090
	int32_t PartAttributeToPartID(struct FGameplayAttribute& PartGameplayAttribute); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.PartAttributeToPartID // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e27710
	bool PartAttributeToBaseData(struct FGameplayAttribute& PartGameplayAttribute, struct FConstructablePartAttributeBaseData& OutBaseData); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.PartAttributeToBaseData // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e28680
	void OnConstructableDestroyed(struct AConstructableBase* Constructable, struct AActor* DamageInstigator); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.OnConstructableDestroyed // (Final|Native|Private) // @ game+0x5e29340
	bool GiveAbilityToPart_Server(int32_t PartID, struct TSet<int32_t>& AssociatedParts, struct UGameplayAbility* InAbilityClass, struct FGameplayAbilitySpecHandle& OutHandle, int32_t Level, struct UObject* OptionalSourceObject); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.GiveAbilityToPart_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e28340
	int32_t GetPartTagCount(int32_t PartID, struct FGameplayTag& TagToQuery); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.GetPartTagCount // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e261e0
	bool GetPartAbilityData(struct FGameplayAbilitySpecHandle PartAbilitySpecHandle, struct FConstructablePartAbilityData& OutData); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.GetPartAbilityData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2a700
	struct AConstructableBase* GetOwnerConstructable(); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.GetOwnerConstructable // (Final|Native|Public|Const) // @ game+0x5e2afe0
	void GetAndRegisterPartAttributeChangedCallback_Server(struct UEmbarkAttributeSet* AttributeSetClass, struct FName AttributeName, int32_t PartID, struct UObject* CallbackObject, struct FName CallbackFunctionName_FOnAttributeChangeData, float& OutCurrentValue); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.GetAndRegisterPartAttributeChangedCallback_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e25b70
	struct TArray<struct FGameplayEffectSpec> GetActiveGameplayEffectSpecs(); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.GetActiveGameplayEffectSpecs // (Final|Native|Public|Const) // @ game+0x5e29fd0
	bool CanStartCapability(struct FGameplayAbilitySpecHandle& AbilitySpecHandle); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.CanStartCapability // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2a5b0
	float CalcUtility(struct FGameplayAbilitySpecHandle AbilitySpecHandle); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.CalcUtility // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e24dd0
	void AllocateAttributesForPart_Server(struct UEmbarkAttributeSet* AttributeSetClass, int32_t PartID); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.AllocateAttributesForPart_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5e2bba0
	void AddPartTags(int32_t PartID, struct FGameplayTagContainer& TagsToAdd); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.AddPartTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e25970
	void AddPartTag(int32_t PartID, struct FGameplayTag& TagToAdd); // Function EmbarkConstructable.ConstructableAbilitySystemComponent.AddPartTag // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e27610
};

// Class EmbarkConstructable.ConstructableAbilitySystemGlobals
// Size: 0x320 (Inherited: 0x320)
struct UConstructableAbilitySystemGlobals : UAbilitySystemGlobals {
};

// Class EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayAbilityTargetDataHandleMixinLibrary : UObject {

	struct AActor* GetTargetActor(struct FGameplayAbilityTargetDataHandle& Handle, int32_t Index); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.GetTargetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2d380
	int32_t GetNum(struct FGameplayAbilityTargetDataHandle& Handle); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.GetNum // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4ee5510
	struct UReplicatedSubobject* GetFirstReplicatedSubobject(struct FGameplayAbilityTargetDataHandle& Handle); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.GetFirstReplicatedSubobject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2f150
	void ApplyGameplayEffectSpec(struct FGameplayAbilityTargetDataHandle& Handle, int32_t Index, struct FGameplayEffectSpec& Spec); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.ApplyGameplayEffectSpec // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e30890
	void ApplyEffectToTargets(struct FGameplayAbilityTargetDataHandle& Handle, struct FGameplayEffectSpec& Spec, struct TArray<struct FActiveGameplayEffectHandle>& OutAppliedHandles, bool bApplyAffectedUNormAsEffectLevel); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.ApplyEffectToTargets // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e34cb0
	void AddReplicatedSubobjectTarget(struct FGameplayAbilityTargetDataHandle& Handle, struct UReplicatedSubobject* TargetedObject); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.AddReplicatedSubobjectTarget // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2faf0
	void AddConstructableTargetData(struct FGameplayAbilityTargetDataHandle& Handle, struct AActor* TargetedActor, struct TArray<struct FConstructablePartDamageModelData>& TargetedParts, int32_t PrimaryTargetPartId); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.AddConstructableTargetData // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e348b0
	void AddActorTargetData(struct FGameplayAbilityTargetDataHandle& Handle, struct AActor* TargetedActor, float TargetedActorAffectedDegreeUNorm); // Function EmbarkConstructable.GameplayAbilityTargetDataHandleMixinLibrary.AddActorTargetData // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e379d0
};

// Class EmbarkConstructable.GameplayEffectContextMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayEffectContextMixinLibrary : UObject {

	void SetReplicateAffectedPartIDs(struct FGameplayEffectContextHandle& Handle, bool bReplicate); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetReplicateAffectedPartIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e2d5f0
	void SetRawDamage(struct FGameplayEffectContextHandle& Handle, float RawDamage); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetRawDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2e2f0
	void SetPrimaryTargetPartId(struct FGameplayEffectContextHandle& Handle, int32_t PrimaryAffectedPart); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetPrimaryTargetPartId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e30370
	void SetOriginatorObject(struct FGameplayEffectContextHandle& Handle, struct UObject* Originator); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetOriginatorObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e38440
	void SetEventID(struct FGameplayEffectContextHandle& Handle, int32_t InEventID); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetEventID // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2ea80
	void SetDamageType(struct FGameplayEffectContextHandle& Handle, char DamageType); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetDamageType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e33840
	void SetDamageMitigatedByArmor(struct FGameplayEffectContextHandle& Handle, float DamageMitigatedByArmor); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetDamageMitigatedByArmor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e32530
	void SetAttackingPartInfo(struct FGameplayEffectContextHandle& Handle, struct FConstructablePartAttackerData& AttackingPartInfo); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetAttackingPartInfo // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e36430
	void SetArmorDamage(struct FGameplayEffectContextHandle& Handle, float ArmorDamage); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetArmorDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e34690
	void SetAffectedParts(struct FGameplayEffectContextHandle& Handle, struct TArray<struct FConstructablePartDamageModelData>& AffectedParts); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetAffectedParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e380e0
	void SetAffectActorAttributes(struct FGameplayEffectContextHandle& Handle, bool bShouldAffectActorAttributes); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetAffectActorAttributes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e31bc0
	void SetActorRawTakenDamage(struct FGameplayEffectContextHandle& Handle, float RawDamage); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetActorRawTakenDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e2e2f0
	void SetActorAffectedDegreeUNorm(struct FGameplayEffectContextHandle& Handle, float ActorAffectedDegreeUNorm); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.SetActorAffectedDegreeUNorm // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e316d0
	bool IsReplicatingAffectedPartIDs(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.IsReplicatingAffectedPartIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e36190
	float GetRawDamage(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetRawDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2f300
	int32_t GetPrimaryTargetPartId(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetPrimaryTargetPartId // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2dc80
	struct UObject* GetOriginatorObject(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetOriginatorObject // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e33510
	int32_t GetEventID(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetEventID // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2da90
	char GetDamageType(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetDamageType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e315a0
	float GetDamageMitigatedByArmor(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetDamageMitigatedByArmor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e30ff0
	struct FConstructablePartAttackerData GetAttackingPartInfo(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetAttackingPartInfo // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e35500
	float GetArmorDamage(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetArmorDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2f7f0
	int32_t GetAffectedPartsNum(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetAffectedPartsNum // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e31800
	void GetAffectedParts(struct FGameplayEffectContextHandle& Handle, struct TArray<struct FConstructablePartDamageModelData>& AffectedParts); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetAffectedParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2e530
	struct TArray<int32_t> GetAffectedPartIDs(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetAffectedPartIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e32210
	struct FConstructablePartDamageModelData GetAffectedPart(struct FGameplayEffectContextHandle& Handle, int32_t PartIndex); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetAffectedPart // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e356b0
	bool GetAffectActorAttributes(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetAffectActorAttributes // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e32030
	float GetActorRawTakenDamage(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetActorRawTakenDamage // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e2f300
	float GetActorAffectedDegreeUNorm(struct FGameplayEffectContextHandle& Handle); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.GetActorAffectedDegreeUNorm // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e32120
	void AddAffectedParts(struct FGameplayEffectContextHandle& Handle, struct TArray<struct FConstructablePartDamageModelData>& AffectedParts); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.AddAffectedParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e31350
	void AddAffectedPart(struct FGameplayEffectContextHandle& Handle, struct FConstructablePartDamageModelData& AffectedPart); // Function EmbarkConstructable.GameplayEffectContextMixinLibrary.AddAffectedPart // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e35d50
};

// Class EmbarkConstructable.GrantedTagsMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGrantedTagsMixinLibrary : UObject {

	void AddGrantedTags(struct FGameplayEffectSpecHandle& SpecHandle, struct FGameplayTagContainer& InGameplayTagsToAdd); // Function EmbarkConstructable.GrantedTagsMixinLibrary.AddGrantedTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e2efd0
	void AddGrantedTag(struct FGameplayEffectSpecHandle& SpecHandle, struct FGameplayTag& InTagToAdd); // Function EmbarkConstructable.GrantedTagsMixinLibrary.AddGrantedTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e30b00
};

// Class EmbarkConstructable.ServiceUpdateTimeInfoMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UServiceUpdateTimeInfoMixinLibrary : UObject {

	bool UpdateTimeReturnNeedsUpdate(struct FServiceUpdateTimeInfo& UpdateTimeInfo, float DeltaTime); // Function EmbarkConstructable.ServiceUpdateTimeInfoMixinLibrary.UpdateTimeReturnNeedsUpdate // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e2e950
	void SetTickInterval(struct FServiceUpdateTimeInfo& UpdateTimeInfo, float val); // Function EmbarkConstructable.ServiceUpdateTimeInfoMixinLibrary.SetTickInterval // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e33640
};

// Class EmbarkConstructable.ConstructableBase
// Size: 0x1170 (Inherited: 0x4d0)
struct AConstructableBase : AEmbarkPawn {
	char pad_4d0[0x8]; // 0x4d0(0x08)
	struct FMulticastInlineDelegate OnConstructionComplete; // 0x4d8(0x10)
	struct FMulticastInlineDelegate OnCollidedWithOtherActor; // 0x4e8(0x10)
	struct FMulticastInlineDelegate OnAnyServicePushedData; // 0x4f8(0x10)
	struct FMulticastInlineDelegate OnConstructableDestroyedEvent; // 0x508(0x10)
	bool bIsFullyConstructed; // 0x518(0x01)
	char pad_519[0x3]; // 0x519(0x03)
	struct FRandomStream ConstructionStream; // 0x51c(0x08)
	char pad_524[0x4]; // 0x524(0x04)
	struct UStateInterpolatorComponent* StateInterpolatorComponent; // 0x528(0x08)
	struct FMulticastInlineDelegate OnPostFullyConstructed; // 0x530(0x10)
	struct FRotator InitialRotation; // 0x540(0x18)
	struct TArray<struct USceneComponent*> ExtraClassesToNotDestroyOnPartDestruction; // 0x558(0x10)
	bool bOverrideActorBoundsWithSkeletalMeshBounds; // 0x568(0x01)
	char pad_569[0xb7]; // 0x569(0xb7)
	struct TArray<struct UConstructableServiceComponentBase*> AllServices; // 0x620(0x10)
	char pad_630[0x10]; // 0x630(0x10)
	struct TArray<struct UConstructableStyleDriverComponent*> AllStyleDrivers; // 0x640(0x10)
	struct UConstructableStyleProxyContainer* ProxyContainer; // 0x650(0x08)
	char pad_658[0xb18]; // 0x658(0xb18)

	void TickNativePrePhysicsServices(float DeltaTimeSecs, bool bIsServer); // Function EmbarkConstructable.ConstructableBase.TickNativePrePhysicsServices // (Final|Native|Public|BlueprintCallable) // @ game+0x5e34f20
	void TickNativePostPhysicsServices(float DeltaTimeSecs, bool bIsServer); // Function EmbarkConstructable.ConstructableBase.TickNativePostPhysicsServices // (Final|Native|Public|BlueprintCallable) // @ game+0x5e36840
	void ReceivePreSave(); // Function EmbarkConstructable.ConstructableBase.ReceivePreSave // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void QueryPartsNoLookup(struct FGameplayTagQuery& PartQuery, struct TArray<struct FConstructablePart>& OutParts, bool bAllowDestroyedParts); // Function EmbarkConstructable.ConstructableBase.QueryPartsNoLookup // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e33f30
	void QueryParts(struct FGameplayTagQuery& PartQuery, struct TArray<struct FConstructablePart>& OutParts, bool bAllowDestroyedParts); // Function EmbarkConstructable.ConstructableBase.QueryParts // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e2e680
	void QueryPartIDsNoLookup(struct FGameplayTagQuery PartQuery, struct TSet<int32_t>& OutPartIDs); // Function EmbarkConstructable.ConstructableBase.QueryPartIDsNoLookup // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e31d30
	void QueryPartIDs(struct FGameplayTagQuery PartQuery, struct TSet<int32_t>& OutPartIDs, bool bAllowDestroyedParts); // Function EmbarkConstructable.ConstructableBase.QueryPartIDs // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e2e050
	bool QueryFirstPart(struct FGameplayTagQuery& PartQuery, struct FConstructablePart& OutPart, bool bAllowDestroyedPart, bool bFailOnMultiple); // Function EmbarkConstructable.ConstructableBase.QueryFirstPart // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e33240
	void PumpServiceDataToStyles_Client(float DeltaTimeSecs); // Function EmbarkConstructable.ConstructableBase.PumpServiceDataToStyles_Client // (Final|Native|Public|BlueprintCallable) // @ game+0x5e34800
	void OnDisableOverlaps(); // Function EmbarkConstructable.ConstructableBase.OnDisableOverlaps // (Final|Native|Private) // @ game+0x5e34c90
	void OnActorFinalized(); // Function EmbarkConstructable.ConstructableBase.OnActorFinalized // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool IsValidPartID(int32_t PartID); // Function EmbarkConstructable.ConstructableBase.IsValidPartID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e340f0
	bool IsPartDestroyed(int32_t PartID); // Function EmbarkConstructable.ConstructableBase.IsPartDestroyed // (Final|Native|Public|Const) // @ game+0x5e2f8e0
	bool IsConstructableDestroyed(); // Function EmbarkConstructable.ConstructableBase.IsConstructableDestroyed // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5e38570
	void InitializePartQueryData_Test(); // Function EmbarkConstructable.ConstructableBase.InitializePartQueryData_Test // (Final|Native|Public) // @ game+0x5e36280
	float GetStyleVisualQuality(); // Function EmbarkConstructable.ConstructableBase.GetStyleVisualQuality // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e2ddb0
	struct UPrimitiveComponent* GetStyleComponentFromPartID(int32_t PartID); // Function EmbarkConstructable.ConstructableBase.GetStyleComponentFromPartID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e35060
	bool GetSocketRepIndex(int32_t PartID, struct FName& SocketName, int32_t& OutSocketIndex); // Function EmbarkConstructable.ConstructableBase.GetSocketRepIndex // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e34480
	bool GetSocketDataFromRepIndex(int32_t SocketIndex, int32_t& OutPartId, struct FName& OutSocketName); // Function EmbarkConstructable.ConstructableBase.GetSocketDataFromRepIndex // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e31160
	int32_t GetRootPartID(); // Function EmbarkConstructable.ConstructableBase.GetRootPartID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e35800
	struct FConstructablePart GetRootPart(); // Function EmbarkConstructable.ConstructableBase.GetRootPart // (Final|Native|Public|Const) // @ game+0x5e37c50
	bool GetPartTags(int32_t PartID, struct FGameplayTagContainer& OutGameplayTags); // Function EmbarkConstructable.ConstructableBase.GetPartTags // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e386e0
	bool GetPartSocketGroupTransforms(int32_t PartID, struct FName& SocketGroupName, struct TArray<struct FTransform>& OutTransforms, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableBase.GetPartSocketGroupTransforms // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e300d0
	bool GetPartSocketGroup(int32_t PartID, struct FName& SocketGroupName, struct TArray<struct FConstructableStyleSocket>& OutSocketList, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableBase.GetPartSocketGroup // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e2d740
	struct FConstructablePart GetPartFromIDRef(int32_t PartID); // Function EmbarkConstructable.ConstructableBase.GetPartFromIDRef // (Final|Native|Public|Const) // @ game+0x5e2e840
	struct FConstructablePart GetPartFromID(int32_t PartID); // Function EmbarkConstructable.ConstructableBase.GetPartFromID // (Final|Native|Public|Const) // @ game+0x5e2e460
	int32_t GetNumStyleDrivers(); // Function EmbarkConstructable.ConstructableBase.GetNumStyleDrivers // (Final|Native|Public|Const) // @ game+0x5e2fe20
	int32_t GetLastPartID(); // Function EmbarkConstructable.ConstructableBase.GetLastPartID // (Final|Native|Public|Const) // @ game+0x5e2d720
	int32_t GetFramePartID(); // Function EmbarkConstructable.ConstructableBase.GetFramePartID // (Final|Native|Public|Const) // @ game+0x5e37d10
	bool GetFirstPartSocketGroupTransform(int32_t PartID, struct FName& SocketGroupName, struct FTransform& OutSocketTransform, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableBase.GetFirstPartSocketGroupTransform // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e32ca0
	bool GetFirstPartSocketGroup(int32_t PartID, struct FName& SocketGroupName, struct FConstructableStyleSocket& OutSocket, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableBase.GetFirstPartSocketGroup // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e35910
	struct UConstructableAbilitySystemComponent* GetConstructableASC(); // Function EmbarkConstructable.ConstructableBase.GetConstructableASC // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e33c30
	struct TArray<struct UPrimitiveComponent*> GetAllStyleComponents(); // Function EmbarkConstructable.ConstructableBase.GetAllStyleComponents // (Final|Native|Public|Const) // @ game+0x5e34bb0
	void GetAllParts(struct TArray<struct FConstructablePart>& OutAllParts); // Function EmbarkConstructable.ConstructableBase.GetAllParts // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e32ef0
	void GetAllPartIDs(struct TArray<int32_t>& OutAllPartIDs); // Function EmbarkConstructable.ConstructableBase.GetAllPartIDs // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e32340
	bool GetAllNeedStyleTickServices(struct TArray<struct UConstructableStyleDriverComponent*>& ToWrite, float DeltaTime); // Function EmbarkConstructable.ConstructableBase.GetAllNeedStyleTickServices // (Final|Native|Public|HasOutParms) // @ game+0x5e2d980
	bool GetAllNeedASTickPrePhysicsServices(struct TArray<struct UConstructableServiceComponentBase*>& ToWrite, float DeltaTime); // Function EmbarkConstructable.ConstructableBase.GetAllNeedASTickPrePhysicsServices // (Final|Native|Public|HasOutParms) // @ game+0x5e35280
	bool GetAllNeedASTickPostPhysicsServices(struct TArray<struct UConstructableServiceComponentBase*>& ToWrite, float DeltaTime); // Function EmbarkConstructable.ConstructableBase.GetAllNeedASTickPostPhysicsServices // (Final|Native|Public|HasOutParms) // @ game+0x5e353a0
	struct FRotator GetAgentRotator(); // Function EmbarkConstructable.ConstructableBase.GetAgentRotator // (Final|Native|Public|HasDefaults|Const) // @ game+0x5e30830
	void EnableOverlapEventsForDuration(double& DurationSeconds); // Function EmbarkConstructable.ConstructableBase.EnableOverlapEventsForDuration // (Final|Native|Public|HasOutParms) // @ game+0x5e365f0
	void DestroyPart_Server(int32_t PartID, int32_t EventID, enum class EConstructableHealthChangeReason DestructionMethod); // Function EmbarkConstructable.ConstructableBase.DestroyPart_Server // (Final|Native|Public) // @ game+0x5e366e0
	bool CreateConstructablePart_Server(struct UPrimitiveComponent* StyleComponentClass, struct FConstructablePartIDRange& OutPartIDRange); // Function EmbarkConstructable.ConstructableBase.CreateConstructablePart_Server // (Final|Native|Public|HasOutParms) // @ game+0x5e33740
	void CompleteConstruction(); // Function EmbarkConstructable.ConstructableBase.CompleteConstruction // (Final|Native|Public|BlueprintCallable) // @ game+0x5e33e90
	float CalculateVisualQualityTickInterval(float MaxTickInterval, float MinThrottleDistSq, float MaxThrottleDistSq); // Function EmbarkConstructable.ConstructableBase.CalculateVisualQualityTickInterval // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e36020
};

// Class EmbarkConstructable.ConstructableCapabilityBase
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableCapabilityBase : UObject {
	struct UEmbarkSMInstance* StateMachine; // 0x98(0x08)
};

// Class EmbarkConstructable.ConstructableServiceComponentBase
// Size: 0x180 (Inherited: 0x160)
struct UConstructableServiceComponentBase : UActorComponent {
	bool bOnlyPushChangedValues_Client; // 0x158(0x01)
	bool bIsFullyConstructed; // 0x159(0x01)
	bool bNeedsASServicePump; // 0x15a(0x01)
	char pad_163[0x5]; // 0x163(0x05)
	struct AConstructableBase* OwnerConstructable; // 0x168(0x08)
	char pad_170[0x10]; // 0x170(0x10)

	struct UObject* SimClassType(); // Function EmbarkConstructable.ConstructableServiceComponentBase.SimClassType // (Native|Event|Public|BlueprintEvent) // @ game+0x5e59fb0
	void SetNeedNativePrePhysicsTick(bool bVal); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetNeedNativePrePhysicsTick // (Final|Native|Public) // @ game+0x5e593d0
	void SetNeedNativePostPhysicsTick(bool bVal); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetNeedNativePostPhysicsTick // (Final|Native|Public) // @ game+0x5e528f0
	void SetNeedASPrePhysicsTick(bool bVal); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetNeedASPrePhysicsTick // (Final|Native|Public) // @ game+0x5e58a30
	void SetNeedASPostPhysicsTick(bool bVal); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetNeedASPostPhysicsTick // (Final|Native|Public) // @ game+0x5e530b0
	void SetNativePrePhysicsTickInterval(float val); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetNativePrePhysicsTickInterval // (Final|Native|Public) // @ game+0x5e54aa0
	void SetNativePostPhysicsTickInterval(float val); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetNativePostPhysicsTickInterval // (Final|Native|Public) // @ game+0x5e4fa60
	void SetHasNewData(); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetHasNewData // (Final|Native|Public) // @ game+0x5e53590
	void SetASPrePhysicsTickInterval(float val); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetASPrePhysicsTickInterval // (Final|Native|Public) // @ game+0x5e4fc50
	void SetASPostPhysicsTickInterval(float val); // Function EmbarkConstructable.ConstructableServiceComponentBase.SetASPostPhysicsTickInterval // (Final|Native|Public) // @ game+0x5e4eeb0
	bool OnPumpDataToStyle(float DeltaTimeSecs); // Function EmbarkConstructable.ConstructableServiceComponentBase.OnPumpDataToStyle // (Native|Event|Public|BlueprintEvent) // @ game+0x5e52aa0
	void OnFullyConstructed(); // Function EmbarkConstructable.ConstructableServiceComponentBase.OnFullyConstructed // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct USimConstructableBaseClass* GetSimBaseStatePtr(); // Function EmbarkConstructable.ConstructableServiceComponentBase.GetSimBaseStatePtr // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b49d50
	struct USimConstructableBaseClass* EditSimBaseStatePtr(); // Function EmbarkConstructable.ConstructableServiceComponentBase.EditSimBaseStatePtr // (Final|Native|Public|BlueprintCallable) // @ game+0x5e4f9d0
};

// Class EmbarkConstructable.ConstructableCapabilityServiceBase
// Size: 0x1e0 (Inherited: 0x180)
struct UConstructableCapabilityServiceBase : UConstructableServiceComponentBase {
	struct TArray<struct UConstructableCapabilityBase*> Capabilities; // 0x178(0x10)
	struct TArray<struct FConstructableSMNetworkData> CapabilityStateMachineRepData; // 0x188(0x10)
	struct TArray<struct FConstructableCapabilityEvent> CapabilityEventRepData; // 0x198(0x10)
	struct TArray<struct FConstructableSMNetworkData> NetworkedSMData_Client; // 0x1b0(0x10)
	struct TArray<struct FConstructableCapabilityEvent> NetworkedEventData_Client; // 0x1c0(0x10)
	bool bCapabilityStateMachinesCreated; // 0x1d0(0x01)
	char pad_1d1[0xf]; // 0x1d1(0x0f)

	void SendMultiCasts(); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.SendMultiCasts // (Final|Native|Public) // @ game+0x5e38800
	void ReceiveInitializeComponent(); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.ReceiveInitializeComponent // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ProcessDataReceivedByServer(); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.ProcessDataReceivedByServer // (Final|Native|Public) // @ game+0x5e39fb0
	void OnCapabilityEvent_Client(struct UConstructableCapabilityBase* Capability, struct FConstructableCapabilityEvent& EventData); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.OnCapabilityEvent_Client // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void NetMulticast_StateMachine(struct TArray<struct FConstructableSMNetworkData> Data); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.NetMulticast_StateMachine // (Net|NetReliableNative|Event|NetMulticast|Protected|BlueprintCallable) // @ game+0x5e3a610
	void NetMulticast_EventData(struct TArray<struct FConstructableCapabilityEvent> Data); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.NetMulticast_EventData // (Net|NetReliableNative|Event|NetMulticast|Protected|BlueprintCallable) // @ game+0x5e3e290
	void AddCSMRepData(struct FConstructableSMNetworkData SMData); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.AddCSMRepData // (Final|Native|Protected|BlueprintCallable) // @ game+0x5e3f1d0
	void AddCapabilityEventRepData(struct FConstructableCapabilityEvent CapabilityEvent); // Function EmbarkConstructable.ConstructableCapabilityServiceBase.AddCapabilityEventRepData // (Final|Native|Protected|BlueprintCallable) // @ game+0x5e3d550
};

// Class EmbarkConstructable.ConstructableDynamicAttributes
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableDynamicAttributes : UBlueprintFunctionLibrary {

	bool IsValidAttributeName(struct FName AttributeTypeName); // Function EmbarkConstructable.ConstructableDynamicAttributes.IsValidAttributeName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e3b2a0
	bool GetSetClassesForAttributeName(struct FName AttributeTypeName, struct TArray<struct UObject*>& OutAttributeSetClasses); // Function EmbarkConstructable.ConstructableDynamicAttributes.GetSetClassesForAttributeName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e3d860
	bool GetPartAttributeSetMetaData(struct UObject* BaseClass, struct FConstructablePartAttributeSetMetaData& OutMetaData); // Function EmbarkConstructable.ConstructableDynamicAttributes.GetPartAttributeSetMetaData // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e3cef0
	struct FName GetMaxPrefixVersionName(struct FName Name); // Function EmbarkConstructable.ConstructableDynamicAttributes.GetMaxPrefixVersionName // (Final|Native|Static|Public) // @ game+0x5e396d0
	void GetAllAttributeNames(struct TSet<struct FName>& OutAllAttributeNames); // Function EmbarkConstructable.ConstructableDynamicAttributes.GetAllAttributeNames // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e3d960
};

// Class EmbarkConstructable.ConstructableGameplayAbility
// Size: 0x490 (Inherited: 0x490)
struct UConstructableGameplayAbility : UEmbarkGameplayAbility {
	bool bApplyCostToPartIfApplicable; // 0x488(0x01)

	void ReceiveOnPresave(); // Function EmbarkConstructable.ConstructableGameplayAbility.ReceiveOnPresave // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool CanStartCapability(struct FGameplayAbilitySpecHandle& Handle, struct FGameplayAbilityActorInfo& ScopedActorInfo); // Function EmbarkConstructable.ConstructableGameplayAbility.CanStartCapability // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5e39dd0
	bool CanActivateConstructableAbility(struct FGameplayAbilitySpecHandle& Handle, struct FGameplayAbilityActorInfo& ScopedActorInfo); // Function EmbarkConstructable.ConstructableGameplayAbility.CanActivateConstructableAbility // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x5e3b0e0
	float CalculateUtility(struct FGameplayAbilitySpecHandle& Handle, struct FGameplayAbilityActorInfo& ScopedActorInfo); // Function EmbarkConstructable.ConstructableGameplayAbility.CalculateUtility // (Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x4abfe0
	void ActivateConstructableAbility(struct FGameplayAbilitySpecHandle& Handle, struct FGameplayAbilityActorInfo& ScopedActorInfo); // Function EmbarkConstructable.ConstructableGameplayAbility.ActivateConstructableAbility // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkConstructable.ConstructableGameplayCueNotify_Actor
// Size: 0x410 (Inherited: 0x410)
struct AConstructableGameplayCueNotify_Actor : AGameplayCueNotify_Actor {

	bool OnConstructableDestroyed(struct AConstructableBase* Constructable, struct AActor* DamageInstigator); // Function EmbarkConstructable.ConstructableGameplayCueNotify_Actor.OnConstructableDestroyed // (Native|Event|Public|BlueprintEvent) // @ game+0x5e3f450
	void Handle_OnConstructableDestroyed(struct AConstructableBase* Constructable, struct AActor* DamageInstigator); // Function EmbarkConstructable.ConstructableGameplayCueNotify_Actor.Handle_OnConstructableDestroyed // (Final|Native|Private) // @ game+0x5e3bd40
};

// Class EmbarkConstructable.ConstructableGameplayEffect
// Size: 0xc10 (Inherited: 0xb20)
struct UConstructableGameplayEffect : UEmbarkGameplayEffect {
	struct FGameplayTagQuery TargetPartQuery; // 0xb18(0x48)
	struct FGameplayTagQuery AffectedPartsFilter; // 0xb60(0x48)
	bool bModifiersApplyToPartAttributes; // 0xba8(0x01)
	struct FInheritedTagContainer TagsGrantedToAffectedParts; // 0xbb0(0x60)
};

// Class EmbarkConstructable.ConstructableDamageDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableDamageDataMixinLibrary : UObject {

	void StoreEventTimestamp_Server(struct FConstructableDamageData& DamageData, struct UObject* WorldContextObject); // Function EmbarkConstructable.ConstructableDamageDataMixinLibrary.StoreEventTimestamp_Server // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e3d6d0
	void SetDamageInstigatorPawn(struct FConstructableDamageData& DamageData, struct APawn* DamageInstigatorPawn); // Function EmbarkConstructable.ConstructableDamageDataMixinLibrary.SetDamageInstigatorPawn // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e3ab70
	float GetTimeSinceDamageOnServer(struct FConstructableDamageData& DamageData, struct UObject* WorldContextObject); // Function EmbarkConstructable.ConstructableDamageDataMixinLibrary.GetTimeSinceDamageOnServer // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e3bae0
	struct APawn* GetDamageInstigatorPawn(struct FConstructableDamageData& DamageData); // Function EmbarkConstructable.ConstructableDamageDataMixinLibrary.GetDamageInstigatorPawn // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e3c600
};

// Class EmbarkConstructable.SimConstructableBaseClass
// Size: 0xb0 (Inherited: 0xa0)
struct USimConstructableBaseClass : USimBaseClass {
	struct UConstructableServiceComponentBase* Service; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)

	struct UConstructableServiceComponentBase* GetService(); // Function EmbarkConstructable.SimConstructableBaseClass.GetService // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2f3d5f0
	void FindAndSetServiceForActor(struct AActor* Actor, struct UObject* ServiceClass); // Function EmbarkConstructable.SimConstructableBaseClass.FindAndSetServiceForActor // (Final|Native|Public|BlueprintCallable) // @ game+0x5e53690
	void DeinitFromReplication(); // Function EmbarkConstructable.SimConstructableBaseClass.DeinitFromReplication // (Final|Native|Private) // @ game+0x5e57ce0
};

// Class EmbarkConstructable.ConstructableDamageDataArraySimState
// Size: 0xc0 (Inherited: 0xb0)
struct UConstructableDamageDataArraySimState : USimConstructableBaseClass {
	struct FABArraySizeLimiter ArraySize; // 0xa8(0x04)
	struct TArray<struct FConstructableDamageDataBB> Items; // 0xb0(0x10)

	void OnRep_Items(); // Function EmbarkConstructable.ConstructableDamageDataArraySimState.OnRep_Items // (Final|Native|Public) // @ game+0x5e3c2e0
	void InitForActor(struct AActor* Actor); // Function EmbarkConstructable.ConstructableDamageDataArraySimState.InitForActor // (Final|Native|Public) // @ game+0x5e3dbc0
};

// Class EmbarkConstructable.BiggerConstructableDamageDataArraySimState
// Size: 0xc0 (Inherited: 0xc0)
struct UBiggerConstructableDamageDataArraySimState : UConstructableDamageDataArraySimState {
};

// Class EmbarkConstructable.BiggestConstructableDamageDataArraySimState
// Size: 0xc0 (Inherited: 0xc0)
struct UBiggestConstructableDamageDataArraySimState : UConstructableDamageDataArraySimState {
};

// Class EmbarkConstructable.ConstructableHealthServiceComponent
// Size: 0x3a0 (Inherited: 0x180)
struct UConstructableHealthServiceComponent : UConstructableServiceComponentBase {
	struct FMulticastInlineDelegate OnPartDamageDataUpdated_Interpolated; // 0x178(0x10)
	struct FMulticastInlineDelegate OnPartDamageDataUpdated_Latest; // 0x188(0x10)
	struct FMulticastInlineDelegate OnPartDestroyed; // 0x198(0x10)
	struct FMulticastInlineDelegate OnPartStunStateChanged; // 0x1a8(0x10)
	float HealthInterpolationSpeed_Client; // 0x1b8(0x04)
	enum class EConstructableNumPartsCategory NumPartsCategory; // 0x1bc(0x01)
	float MultiChainPartDestructionTimeMultiplier; // 0x1c0(0x04)
	char pad_1c9[0xb7]; // 0x1c9(0xb7)
	struct FMulticastInlineDelegate OnStaggeredPartDestructionsActiveStatusChanged; // 0x280(0x10)
	char pad_290[0x110]; // 0x290(0x110)

	void ReplicatePartDamageData_Server(struct FConstructableDamageData& DamageData); // Function EmbarkConstructable.ConstructableHealthServiceComponent.ReplicatePartDamageData_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e3dab0
	void RegisterStaggeredPartDestructionTiming(int32_t PartID, float Time); // Function EmbarkConstructable.ConstructableHealthServiceComponent.RegisterStaggeredPartDestructionTiming // (Final|Native|Public) // @ game+0x5e38860
	bool PollLatestHealthData(int32_t PartID, struct FConstructableDamageData& OutLatestHealthData); // Function EmbarkConstructable.ConstructableHealthServiceComponent.PollLatestHealthData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e3dda0
	bool PollInterpolatedHealthData(int32_t PartID, struct FConstructableDamageData& OutInterpolatedHealthData); // Function EmbarkConstructable.ConstructableHealthServiceComponent.PollInterpolatedHealthData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e3c960
	bool IsPartStunned_Server(int32_t PartID); // Function EmbarkConstructable.ConstructableHealthServiceComponent.IsPartStunned_Server // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5e38a00
	void HandlePartDamaged(struct UPrimitiveComponent* OwnerStyleComponent, struct FConstructableDamageData& DamageData); // Function EmbarkConstructable.ConstructableHealthServiceComponent.HandlePartDamaged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	bool GetRegisteredStaggeredPartDestructionTimingForPart(int32_t PartID, float& Timeout); // Function EmbarkConstructable.ConstructableHealthServiceComponent.GetRegisteredStaggeredPartDestructionTimingForPart // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e3cb00
	struct TMap<int32_t, float> GetPartsWithCurrentStaggerDestruction(float TimeNormalizationLength); // Function EmbarkConstructable.ConstructableHealthServiceComponent.GetPartsWithCurrentStaggerDestruction // (Final|Native|Public|Const) // @ game+0x5e39980
	int32_t GetMaxDamageableParts(); // Function EmbarkConstructable.ConstructableHealthServiceComponent.GetMaxDamageableParts // (Final|Native|Public|Const) // @ game+0x5e3d820
	void GetChildPartIdsWithoutRegisterStaggeredPartDestructionTiming(struct FConstructablePart& ForPart, struct TArray<int32_t>& OutPartIDs); // Function EmbarkConstructable.ConstructableHealthServiceComponent.GetChildPartIdsWithoutRegisterStaggeredPartDestructionTiming // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e3b8b0
	void DestroyPartDueToIndirectDestruction(int32_t SourcePartId, struct FConstructablePart& AffectedPart, struct FConstructableDamageData& DamageData); // Function EmbarkConstructable.ConstructableHealthServiceComponent.DestroyPartDueToIndirectDestruction // (Final|Native|Public|HasOutParms) // @ game+0x5e3c750
};

// Class EmbarkConstructable.ConstructableHoverMovementUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableHoverMovementUtils : UBlueprintFunctionLibrary {

	void CalculateThrusterLocalForces(struct FThrusterSimParams& ThrusterSimParams, struct TArray<struct FThrusterDefinition>& InOutThrusters); // Function EmbarkConstructable.ConstructableHoverMovementUtils.CalculateThrusterLocalForces // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e4bc20
};

// Class EmbarkConstructable.ConstructableMovementNetStateBase
// Size: 0xe0 (Inherited: 0xa0)
struct UConstructableMovementNetStateBase : USimBaseClass {
	struct FABBHighCompressedVectorMaxLen2000 Velocity; // 0xa0(0x18)
	struct FABBHighCompressedVectorMaxLen2000 AngularVelocity; // 0xb8(0x18)
	struct UConstructableMovementComponentBase* Service; // 0xd0(0x08)
	char pad_d8[0x8]; // 0xd8(0x08)

	void UpdateNetStateStateFromBaseMovementAS(struct UConstructableMovementComponentBase* InService); // Function EmbarkConstructable.ConstructableMovementNetStateBase.UpdateNetStateStateFromBaseMovementAS // (Final|Native|Public) // @ game+0x5e413d0
	void UpdateBaseMovementStateFromNetStateAS(struct UConstructableMovementComponentBase* InService); // Function EmbarkConstructable.ConstructableMovementNetStateBase.UpdateBaseMovementStateFromNetStateAS // (Final|Native|Public|Const) // @ game+0x5e4af30
	void InitForActor(struct AActor* Actor); // Function EmbarkConstructable.ConstructableMovementNetStateBase.InitForActor // (Final|Native|Public) // @ game+0x5e4b040
};

// Class EmbarkConstructable.ConstructableMovementNetState
// Size: 0x140 (Inherited: 0xe0)
struct UConstructableMovementNetState : UConstructableMovementNetStateBase {
	struct FABBLowCompressedWorldTransform ReplicatedRootTransform; // 0xe0(0x60)

	void OnRep_ReplicatedRootTransform(); // Function EmbarkConstructable.ConstructableMovementNetState.OnRep_ReplicatedRootTransform // (Final|Native|Public) // @ game+0x5e42810
};

// Class EmbarkConstructable.ConstructableMovementNetStateLowCompressed
// Size: 0x140 (Inherited: 0xe0)
struct UConstructableMovementNetStateLowCompressed : UConstructableMovementNetStateBase {
	struct FABBLowCompressedWorldTransform ReplicatedRootTransform; // 0xe0(0x60)

	void OnRep_ReplicatedRootTransform(); // Function EmbarkConstructable.ConstructableMovementNetStateLowCompressed.OnRep_ReplicatedRootTransform // (Final|Native|Public) // @ game+0x5e42810
};

// Class EmbarkConstructable.ConstructableMovementComponentBase
// Size: 0x390 (Inherited: 0x280)
struct UConstructableMovementComponentBase : UEmbarkPawnMovementComponent {
	float AbsGravityZ; // 0x278(0x04)
	struct FRotator LocalSpaceRotator; // 0x280(0x18)
	struct FRotator AgentRotator; // 0x298(0x18)
	struct FMulticastInlineDelegate DoPostInterpolationTransformOverride; // 0x2b0(0x10)
	char pad_2c4[0x7c]; // 0x2c4(0x7c)
	bool bSupportsMovementSupression; // 0x340(0x01)
	char pad_341[0x7]; // 0x341(0x07)
	struct TArray<struct FName> MovementSuppressors; // 0x348(0x10)
	char pad_358[0x8]; // 0x358(0x08)
	struct UTransformInterpolator* CachedTransformInterpolator; // 0x360(0x08)
	char pad_368[0x20]; // 0x368(0x20)
	bool bExternalUpdateEnabled; // 0x388(0x01)
	char pad_389[0x7]; // 0x389(0x07)

	void SetRootReplicationEnabled(bool bEnable); // Function EmbarkConstructable.ConstructableMovementComponentBase.SetRootReplicationEnabled // (Final|Native|Public) // @ game+0x5e4cb60
	void SetPostInterpolationTransformOverride(struct FTransform& Transform); // Function EmbarkConstructable.ConstructableMovementComponentBase.SetPostInterpolationTransformOverride // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e45d70
	void RemovePhysicsSuppressor(struct FName InName); // Function EmbarkConstructable.ConstructableMovementComponentBase.RemovePhysicsSuppressor // (Final|Native|Public) // @ game+0x5e4b8e0
	void RemoveMovementSuppressor(struct FName InName); // Function EmbarkConstructable.ConstructableMovementComponentBase.RemoveMovementSuppressor // (Final|Native|Public) // @ game+0x5e459e0
	void OnPhysicsSuppressionChangeState(bool bNewSupressionState); // Function EmbarkConstructable.ConstructableMovementComponentBase.OnPhysicsSuppressionChangeState // (Native|Event|Public|BlueprintEvent) // @ game+0x5193460
	bool IsRootReplicationEnabled(); // Function EmbarkConstructable.ConstructableMovementComponentBase.IsRootReplicationEnabled // (Final|Native|Public|Const) // @ game+0x5e473f0
	float GetNavAgentPreferredRadius(); // Function EmbarkConstructable.ConstructableMovementComponentBase.GetNavAgentPreferredRadius // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5e46ff0
	float GetDesiredVelocity(); // Function EmbarkConstructable.ConstructableMovementComponentBase.GetDesiredVelocity // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x252dab0
	struct FRotator GetCurrentLocalRotationOffset(); // Function EmbarkConstructable.ConstructableMovementComponentBase.GetCurrentLocalRotationOffset // (Native|Event|Public|HasDefaults|BlueprintEvent|Const) // @ game+0x5e424b0
	void EnableDefaultBlackboardReplication(); // Function EmbarkConstructable.ConstructableMovementComponentBase.EnableDefaultBlackboardReplication // (Final|Native|Protected) // @ game+0x5e424e0
	void AnalyzeOrientation(); // Function EmbarkConstructable.ConstructableMovementComponentBase.AnalyzeOrientation // (Native|Event|Protected|BlueprintEvent) // @ game+0x5e4a220
	void AddPhysicsSuppressor(struct FName InName); // Function EmbarkConstructable.ConstructableMovementComponentBase.AddPhysicsSuppressor // (Final|Native|Public) // @ game+0x5e42770
	void AddMovementSuppressor(struct FName InName); // Function EmbarkConstructable.ConstructableMovementComponentBase.AddMovementSuppressor // (Final|Native|Public) // @ game+0x5e46ea0
};

// Class EmbarkConstructable.FConstructablePartDamagePropagationFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFConstructablePartDamagePropagationFunctionLibrary : UBlueprintFunctionLibrary {

	bool Equals(struct FConstructablePartDamagePropagation& A, struct FConstructablePartDamagePropagation& B); // Function EmbarkConstructable.FConstructablePartDamagePropagationFunctionLibrary.Equals // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e47930
};

// Class EmbarkConstructable.ConstructablePartMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartMixinLibrary : UObject {

	void SetShapeAsSim(struct FConstructablePart& ConstructablePart, int32_t ShapeIndex, bool bNewValueForShape, bool bChangeNonMatchingShapes, bool bNewValueForOtherShapes); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetShapeAsSim // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e40cd0
	void SetRelativeRotationQuat(struct FConstructablePart& ConstructablePart, struct FQuat& QuatRotation); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4c780
	void SetRelativeRotation(struct FConstructablePart& ConstructablePart, struct FRotator& Rotation); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e49220
	void SetRelativeLocation(struct FConstructablePart& ConstructablePart, struct FVector& Location); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e44290
	bool SetPhysicsSphereData(struct FConstructablePart& ConstructablePart, int32_t SphereIndex, struct FTransform& NewTransform, float Radius); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPhysicsSphereData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e406f0
	bool SetPhysicsCapsuleData(struct FConstructablePart& ConstructablePart, int32_t CapsuleIndex, struct FTransform& NewTransform, float Radius, float HalfHeight); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPhysicsCapsuleData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e48390
	bool SetPhysicsBoxData(struct FConstructablePart& ConstructablePart, int32_t BoxIndex, struct FTransform& NewTransform, struct FVector HalfExtent); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPhysicsBoxData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e47120
	void SetPartTransform(struct FConstructablePart& ConstructablePart, bool bSetWorldTransform, struct FTransform& NewTransform); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPartTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4aa30
	void SetPartSimulatePhysics(struct FConstructablePart& ConstructablePart, bool bSimulatePhysics); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPartSimulatePhysics // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5e46a60
	void SetPartShouldAlwaysGenerateOverlaps(struct FConstructablePart& ConstructablePart, bool bShouldAlwaysGenerateOverlaps); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPartShouldAlwaysGenerateOverlaps // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e42640
	void SetPartLinearVelocity(struct FConstructablePart& ConstructablePart, struct FVector& LinearVelocity); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPartLinearVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e47410
	void SetPartCollisionProfileName(struct FConstructablePart& ConstructablePart, struct FName InCollisionProfileName); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPartCollisionProfileName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e46090
	void SetPartAngularVelocityInDegrees(struct FConstructablePart& ConstructablePart, struct FVector& AngularVelocityDegrees); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetPartAngularVelocityInDegrees // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4bdd0
	void SetDampingProperties(struct FConstructablePart& ConstructablePart, float LinearDamping, float AngularDamping); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetDampingProperties // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e49fe0
	void SetDamagePropagation(struct FConstructablePart& ConstructablePart, struct FConstructablePartDamagePropagation& DamageDist); // Function EmbarkConstructable.ConstructablePartMixinLibrary.SetDamagePropagation // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e494d0
	void RefreshSocketGroups(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.RefreshSocketGroups // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4d510
	bool IsVirtualPart(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsVirtualPart // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e44df0
	bool IsValidPartIDForStyle(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsValidPartIDForStyle // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e49620
	bool IsValid(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e42ab0
	bool IsStaticMesh(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsStaticMesh // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e47b50
	bool IsSkeletalMesh(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsSkeletalMesh // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4d050
	bool IsProxy(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsProxy // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e44d10
	bool IsPointInsidePart(struct FConstructablePart& ConstructablePart, struct FVector& Point); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsPointInsidePart // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e41ab0
	bool IsPartDestroyed(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.IsPartDestroyed // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e410e0
	bool HasQueryCollision(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.HasQueryCollision // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e47a70
	bool HasMeshSurfacePoints(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.HasMeshSurfacePoints // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e49020
	struct FTransform GetWorldTransform(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4b980
	struct FQuat GetWorldRotationQuat(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetWorldRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e41930
	struct FRotator GetWorldRotation(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetWorldRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e47020
	struct FVector GetWorldLocation(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e41540
	struct UPrimitiveComponent* GetStyleComponent(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetStyleComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4d5f0
	bool GetSlotTransform(struct FConstructablePart& ConstructablePart, struct FGameplayTagContainer& GameplayTagContainer, bool bWantWorldTransform, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetSlotTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e47c30
	int32_t GetRootPartID(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetRootPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4a420
	struct FTransform GetRelativeTransform(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e47fd0
	struct FQuat GetRelativeRotationQuat(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e423b0
	struct FRotator GetRelativeRotation(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4c3f0
	struct FVector GetRelativeLocation(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4cf10
	bool GetPhysicsSphereData(struct FConstructablePart& ConstructablePart, int32_t SphereIndex, struct FTransform& OutTransform, float& OutRadius); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPhysicsSphereData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e43930
	int32_t GetPhysicsShapeCount(struct FConstructablePart& ConstructablePart, bool bLimitToSimShapes, bool bLimitToQueryShapes); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPhysicsShapeCount // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e42230
	bool GetPhysicsCapsuleData(struct FConstructablePart& ConstructablePart, int32_t CapsuleIndex, struct FTransform& OutTransform, float& OutRadius, float& OutHalfHeight); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPhysicsCapsuleData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e45a80
	bool GetPhysicsBoxData(struct FConstructablePart& ConstructablePart, int32_t BoxIndex, struct FTransform& OutTransform, struct FVector& HalfExtent); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPhysicsBoxData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e42e40
	bool GetPartTransform(struct FConstructablePart& ConstructablePart, bool bWantWorldTransform, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e40220
	bool GetPartTags(struct FConstructablePart& ConstructablePart, struct FGameplayTagContainer& OutGameplayTags); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e41740
	bool GetPartSocketTransform(struct FConstructablePart& ConstructablePart, struct FName& SocketName, struct FTransform& OutTransform, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartSocketTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e40460
	bool GetPartSocketID(struct FConstructablePart& ConstructablePart, struct FName& SocketName, int32_t& OutSocketID); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartSocketID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e43790
	bool GetPartSocketGroupTransforms(struct FConstructablePart& ConstructablePart, struct FName& SocketGroupName, struct TArray<struct FTransform>& OutTransformList, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartSocketGroupTransforms // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e44f10
	bool GetPartSocketGroupNames(struct FConstructablePart& ConstructablePart, struct FName& SocketGroupName, struct TArray<struct FName>& OutSocketGroupNameList); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartSocketGroupNames // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e44b20
	bool GetPartSocketGroup(struct FConstructablePart& ConstructablePart, struct FName& SocketGroupName, struct TArray<struct FConstructableStyleSocket>& OutSocketList, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartSocketGroup // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e43500
	void GetPartsIntersectingSphere(struct FConstructablePart& ConstructablePart, struct FVector& SphereOrigin, float SphereRadius, struct TArray<int32_t>& OutPartIDs); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartsIntersectingSphere // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e432d0
	bool GetPartSimulatePhysics(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartSimulatePhysics // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e48200
	enum class EPartResistanceGroup GetPartResistanceGroup(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartResistanceGroup // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e48630
	bool GetPartParent(struct FConstructablePart& ConstructablePart, struct FConstructablePartParentInfo& OutParentInfo); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartParent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e49840
	struct FName GetPartName(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4b0e0
	bool GetPartMass(struct FConstructablePart& ConstructablePart, float& OutMass); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartMass // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4a750
	bool GetPartLinearVelocityAtLocation(struct FConstructablePart& ConstructablePart, struct FVector& Location, struct FVector& OutLinearVelocity); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartLinearVelocityAtLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4a890
	bool GetPartLinearVelocity(struct FConstructablePart& ConstructablePart, struct FVector& OutLinearVelocity); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartLinearVelocity // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4b210
	bool GetPartInitialRelativeTransform(struct FConstructablePart& ConstructablePart, struct FTransform& OutInitialRelativeTransform); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartInitialRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e45780
	bool GetPartInitialRelativeRotation(struct FConstructablePart& ConstructablePart, struct FRotator& OutInitialRelativeRotation); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartInitialRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4cc40
	void GetPartIDsMatchingTagQuery(struct FConstructablePart& ConstructablePart, struct FGameplayTagQuery& Query, struct TSet<int32_t>& OutPartIDs); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartIDsMatchingTagQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e41bf0
	struct FConstructablePartIDRange GetPartIDRange(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartIDRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4bf00
	bool GetPartIDFromPhysicsBodyIndex(struct FConstructablePart& ConstructablePart, int32_t PhysicsBodyIndex, int32_t& OutPartId); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartIDFromPhysicsBodyIndex // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4b620
	int32_t GetPartIDFromHitResult(struct FConstructablePart& ConstructablePart, struct FHitResult& HitResult); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartIDFromHitResult // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e43d60
	struct FName GetPartCollisionProfileName(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartCollisionProfileName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e48ac0
	bool GetPartChildren(struct FConstructablePart& ConstructablePart, struct TArray<struct FConstructablePart>& OutPartChildren, bool bIsRecursive, bool bAlsoGetDestroyedParts); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartChildren // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e42870
	bool GetPartBounds(struct FConstructablePart& ConstructablePart, struct FBox& OutBounds); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartBounds // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e499b0
	struct FName GetPartBoneName(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartBoneName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e430e0
	struct FBodyInstance GetPartBodyInstance(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartBodyInstance // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e40af0
	bool GetPartAngularVelocityInDegrees(struct FConstructablePart& ConstructablePart, struct FVector& OutAngularVelocityDegrees); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetPartAngularVelocityInDegrees // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e49700
	bool GetNormalizedSocketGroupTransform(struct FConstructablePart& ConstructablePart, struct FName& SocketGroupName, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetNormalizedSocketGroupTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e487b0
	void GetMeshSurfacePointsWorldSpace(struct FConstructablePart& ConstructablePart, struct TArray<struct FVector>& OutPoints); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetMeshSurfacePointsWorldSpace // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4c9d0
	struct TArray<struct FVector> GetMeshSurfacePoints(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetMeshSurfacePoints // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e477c0
	bool GetFirstPartSocketGroupTransform(struct FConstructablePart& ConstructablePart, struct FName& SocketGroupName, struct FTransform& OutTransform, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetFirstPartSocketGroupTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e44600
	bool GetFirstPartSocketGroup(struct FConstructablePart& ConstructablePart, struct FName& SocketGroupName, struct FConstructableStyleSocket& OutSocket, enum class ERelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetFirstPartSocketGroup // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4c530
	struct FConstructablePartDamagePropagation GetDamagePropagation(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetDamagePropagation // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e45120
	struct FName GetAttachSocketName(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.GetAttachSocketName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e40f10
	void DestroyPart(struct FConstructablePart& ConstructablePart, int32_t EventID, enum class EConstructableHealthChangeReason DestructionMethod); // Function EmbarkConstructable.ConstructablePartMixinLibrary.DestroyPart // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e42c10
	void AttachActor(struct FConstructablePart& ConstructablePart, struct AActor* ActorToAttach, enum class EAttachmentRule AttachmentRule); // Function EmbarkConstructable.ConstructablePartMixinLibrary.AttachActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4d710
	void AddSocketData(struct FConstructablePart& ConstructablePart); // Function EmbarkConstructable.ConstructablePartMixinLibrary.AddSocketData // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e49100
	void AddPartTags(struct FConstructablePart& ConstructablePart, struct FGameplayTagContainer& PartTags); // Function EmbarkConstructable.ConstructablePartMixinLibrary.AddPartTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e4c020
	void AddPartImpulseAtLocation(struct FConstructablePart& ConstructablePart, struct FVector& Location, struct FVector& Impulse); // Function EmbarkConstructable.ConstructablePartMixinLibrary.AddPartImpulseAtLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4b3d0
	void AddPartForceAtLocation(struct FConstructablePart& ConstructablePart, struct FVector& Location, struct FVector& Force); // Function EmbarkConstructable.ConstructablePartMixinLibrary.AddPartForceAtLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e475c0
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet0
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet0 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet1
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet1 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet2
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet2 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet3
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet3 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet4
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet4 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet5
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet5 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet6
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet6 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet7
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet7 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet8
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet8 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructableDamageModelAttributeSet_PartSet9
// Size: 0x6b0 (Inherited: 0xb0)
struct UConstructableDamageModelAttributeSet_PartSet9 : UEmbarkAttributeSet {
	struct FAngelscriptGameplayAttributeData Health; // 0xb0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xc8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0xe0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0xf8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x110(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x128(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x140(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x158(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x170(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x188(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x1d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x1e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x200(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x218(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x230(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x248(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x260(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x278(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x290(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x2d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x2f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x308(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x320(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x338(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x350(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x368(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x380(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x398(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3b0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3c8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x3e0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x3f8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x410(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x428(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x440(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x458(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x470(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x488(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4a0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4b8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x4d0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x4e8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x500(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x518(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x530(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x548(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x560(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x578(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x590(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5a8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5c0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x5d8(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x5f0(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x608(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x620(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x638(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x650(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x668(0x18)
	struct FAngelscriptGameplayAttributeData Health; // 0x680(0x18)
	struct FAngelscriptGameplayAttributeData MaxHealth; // 0x698(0x18)
};

// Class EmbarkConstructable.ConstructablePartListMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartListMixinLibrary : UObject {

	bool IsEmpty(struct FConstructablePartList& ConstructablePartList); // Function EmbarkConstructable.ConstructablePartListMixinLibrary.IsEmpty // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e54d40
	struct TArray<struct FConstructablePart> GetPartList(struct FConstructablePartList& ConstructablePartList, struct AActor* Actor); // Function EmbarkConstructable.ConstructablePartListMixinLibrary.GetPartList // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e52150
	struct TArray<int32_t> GetPartIDs(struct FConstructablePartList& ConstructablePartList); // Function EmbarkConstructable.ConstructablePartListMixinLibrary.GetPartIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e546b0
	int32_t GetFirstPartID(struct FConstructablePartList& ConstructablePartList); // Function EmbarkConstructable.ConstructablePartListMixinLibrary.GetFirstPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e52990
	bool ContainsPartID(struct FConstructablePartList& ConstructablePartList, int32_t PartID); // Function EmbarkConstructable.ConstructablePartListMixinLibrary.ContainsPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e59b00
};

// Class EmbarkConstructable.ActorBBReplicatedPartCollection
// Size: 0xc0 (Inherited: 0xb0)
struct UActorBBReplicatedPartCollection : USimConstructableBaseClass {
	struct FABArraySizeLimiter Limiter; // 0xa8(0x04)
	struct TArray<struct FActorBBReplicatedPart> Items; // 0xb0(0x10)

	void OnRep_Items(); // Function EmbarkConstructable.ActorBBReplicatedPartCollection.OnRep_Items // (Final|Native|Public) // @ game+0x5e580e0
	void InitForActor(struct AActor* Actor); // Function EmbarkConstructable.ActorBBReplicatedPartCollection.InitForActor // (Final|Native|Public) // @ game+0x5e51d50
};

// Class EmbarkConstructable.BiggerActorBBReplicatedPartCollection
// Size: 0xc0 (Inherited: 0xc0)
struct UBiggerActorBBReplicatedPartCollection : UActorBBReplicatedPartCollection {
};

// Class EmbarkConstructable.ConstructablePartReplicationServiceComponent
// Size: 0x370 (Inherited: 0x180)
struct UConstructablePartReplicationServiceComponent : UConstructableServiceComponentBase {
	struct FConstructablePartReplicationDataArray PartDataArray; // 0x178(0x128)
	struct FConstructableSkeletalReplicationConfig ReplicationConfig; // 0x2a0(0x48)
	struct TArray<struct FConstructablePartReplicationConfig> ReplicationConfigs; // 0x2e8(0x10)
	bool bHasManyParts; // 0x2f8(0x01)
	char pad_301[0x57]; // 0x301(0x57)
	struct UTransformInterpolator* TransformInterpolator; // 0x358(0x08)
	char pad_360[0x10]; // 0x360(0x10)

	bool SetReplicationType(int32_t PartID, enum class EConstructableReplicationType Type); // Function EmbarkConstructable.ConstructablePartReplicationServiceComponent.SetReplicationType // (Final|Native|Public|BlueprintCallable) // @ game+0x5e52fb0
	enum class EConstructableReplicationType GetReplicationTypeForPartID(int32_t PartID); // Function EmbarkConstructable.ConstructablePartReplicationServiceComponent.GetReplicationTypeForPartID // (Final|Native|Public|Const) // @ game+0x5e526b0
	int32_t GetMaxReplicatedParts(); // Function EmbarkConstructable.ConstructablePartReplicationServiceComponent.GetMaxReplicatedParts // (Final|Native|Public|Const) // @ game+0x5e52c80
};

// Class EmbarkConstructable.ConstructablePartSelectionMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartSelectionMixinLibrary : UObject {

	bool IsValidPartID(struct FConstructablePartSelection& PartSelection); // Function EmbarkConstructable.ConstructablePartSelectionMixinLibrary.IsValidPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e52ec0
	struct FConstructablePart GetConstructablePart(struct FConstructablePartSelection& PartSelection, struct AActor* Actor); // Function EmbarkConstructable.ConstructablePartSelectionMixinLibrary.GetConstructablePart // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e52b50
};

// Class EmbarkConstructable.ConstructablePartTransformMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartTransformMixinLibrary : UObject {

	bool IsValid(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e59470
	struct FTransform GetWorldTransform(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e5a160
	struct FQuat GetWorldRotationQuat(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetWorldRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e57ff0
	struct FRotator GetWorldRotation(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetWorldRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e4ef60
	struct FVector GetWorldLocation(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e59060
	struct FName GetSocketName(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetSocketName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e5aba0
	struct FTransform GetRelativeTransformByParam(struct FConstructablePartTransform& ConstructablePartTransform, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeTransformByParam // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e53ed0
	struct FTransform GetRelativeTransform(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e52400
	struct FQuat GetRelativeRotationQuatByParam(struct FConstructablePartTransform& ConstructablePartTransform, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeRotationQuatByParam // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e51420
	struct FQuat GetRelativeRotationQuat(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e57aa0
	struct FRotator GetRelativeRotationByParam(struct FConstructablePartTransform& ConstructablePartTransform, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeRotationByParam // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e59e70
	struct FRotator GetRelativeRotation(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e54530
	struct FVector GetRelativeLocationByParam(struct FConstructablePartTransform& ConstructablePartTransform, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeLocationByParam // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e598a0
	struct FVector GetRelativeLocation(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e599e0
	struct FName GetPartName(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetPartName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e51330
	int32_t GetPartID(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e52de0
	struct USceneComponent* GetComponent(struct FConstructablePartTransform& ConstructablePartTransform); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.GetComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e51df0
	void AttachComponentToPart(struct FConstructablePartTransform& ConstructablePartTransform, struct USceneComponent* OtherComponent); // Function EmbarkConstructable.ConstructablePartTransformMixinLibrary.AttachComponentToPart // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e52cb0
};

// Class EmbarkConstructable.ConstructablePartSelectionContainerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartSelectionContainerMixinLibrary : UObject {

	void Setup(struct FConstructablePartTransformSelection& PartSelectionContainer, struct AActor* Actor); // Function EmbarkConstructable.ConstructablePartSelectionContainerMixinLibrary.Setup // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e53c20
	struct FConstructablePart GetPart(struct FConstructablePartTransformSelection& PartSelectionContainer); // Function EmbarkConstructable.ConstructablePartSelectionContainerMixinLibrary.GetPart // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e51810
	struct FConstructablePartTransform GetAsPartTransform(struct FConstructablePartTransformSelection& PartSelectionContainer); // Function EmbarkConstructable.ConstructablePartSelectionContainerMixinLibrary.GetAsPartTransform // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e59c60
};

// Class EmbarkConstructable.EmbarkConstructableRecastNavMesh_Base
// Size: 0x6d0 (Inherited: 0x6d0)
struct AEmbarkConstructableRecastNavMesh_Base : ARecastNavMesh {
	float CellSizeAS; // 0x6c8(0x04)
	float CellHeightAS; // 0x6cc(0x04)

	float GetPreferredRadius(); // Function EmbarkConstructable.EmbarkConstructableRecastNavMesh_Base.GetPreferredRadius // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5e519b0
	float GetPreferredHeight(); // Function EmbarkConstructable.EmbarkConstructableRecastNavMesh_Base.GetPreferredHeight // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x5e510a0
};

// Class EmbarkConstructable.ConstructableSkeletalMeshStyleComponent
// Size: 0x1590 (Inherited: 0xc60)
struct UConstructableSkeletalMeshStyleComponent : USimulatedSkinnedMeshComponent {
	char pad_c60[0x8]; // 0xc60(0x08)
	struct TMap<struct FName, struct FGameplayTagContainer> BoneNameToPartTagsMap; // 0xc68(0x50)
	struct TMap<struct FName, struct FGameplayTagContainer> ConstraintNameToTagsMap; // 0xcb8(0x50)
	struct TMap<struct FName, struct FGameplayTagContainer> BoneNameToExtraPartTagsMap; // 0xd08(0x50)
	struct TMap<int32_t, struct FConstructableSkeletalMeshStylePartIDContainer> PartIDToDirectChildPartIDsMapping; // 0xd58(0x50)
	struct TMap<struct FName, struct FGameplayTag> BoneNameToPartResistanceTagMap; // 0xda8(0x50)
	struct TMap<struct FName, enum class EPartResistanceGroup> BoneNameToPartResistanceGroup; // 0xdf8(0x50)
	struct TSet<struct FName> VirtualPartBones; // 0xe48(0x50)
	struct FGameplayTagQuery PartOverlapFilterQuery_Server; // 0xe98(0x48)
	struct FGameplayTagQuery PartOverlapFilterQuery_Client; // 0xee0(0x48)
	struct TMap<struct FName, struct FConstructableSkeletalMeshStyleProxyPartChildren> ProxyPartChildren; // 0xf28(0x50)
	struct FConstructablePartIDRange PartIDRange; // 0xf78(0x08)
	struct TMap<int32_t, enum class EConstructableHealthChangeReason> DestroyedParts; // 0xf80(0x50)
	struct TArray<struct FString> AdditionalSocketGroupDefinition; // 0xfd0(0x10)
	struct TMap<int32_t, struct FConstructableStyleSKSocketGroupContainer> SocketGroups; // 0xfe0(0x50)
	struct TMap<int32_t, struct FConstructableSkeletalMeshStylePartSocketIDContainer> SocketIDs; // 0x1030(0x50)
	struct TMap<int32_t, struct FConstructableSkeletalMeshStylePartSurfacePointsContainer> PartIdToSurfacePoints; // 0x1080(0x50)
	bool bAllowSmallMovementApplyDelayedTransformOptimization; // 0x10d0(0x01)
	bool bIsKinematic; // 0x10d1(0x01)
	char pad_10d2[0x2]; // 0x10d2(0x02)
	float KillZoneOffset; // 0x10d4(0x04)
	bool bAutoWeldKinematics; // 0x10d8(0x01)
	char pad_10d9[0x7]; // 0x10d9(0x07)
	struct FGameplayTagQuery PartsIDsToNotAutoWeldQuery; // 0x10e0(0x48)
	struct FMulticastInlineDelegate OnPartChangedIsWorldSpaceValue_Client; // 0x1128(0x10)
	char pad_1138[0x458]; // 0x1138(0x458)

	bool WeldPartToParent(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.WeldPartToParent // (Final|Native|Public) // @ game+0x5e64b30
	void WeldAllKinematicsExcept(struct TSet<int32_t>& KinematicPartIDsToIgnore); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.WeldAllKinematicsExcept // (Final|Native|Public|HasOutParms) // @ game+0x5e61a30
	void WeldAllKinematics(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.WeldAllKinematics // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5b390
	void UnWeldBody(int32_t BodyInstanceIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.UnWeldBody // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5ea00
	void TermBody(int32_t BodyInstanceIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.TermBody // (Final|Native|Public|BlueprintCallable) // @ game+0x5e62da0
	void SetTerminalRootpartTransform(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetTerminalRootpartTransform // (Final|Native|Public) // @ game+0x5e633d0
	bool SetPhysicsLinearConstraintLimit(int32_t PhysicsConstraintIndex, float NewLimit); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPhysicsLinearConstraintLimit // (Final|Native|Public|BlueprintCallable) // @ game+0x5e65380
	bool SetPhysicsConstraintLimits(int32_t PhysicsConstraintIndex, struct FAngularConstraintData& NewLimits); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPhysicsConstraintLimits // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e614b0
	void SetPartWorldTransform(int32_t PartID, struct FTransform& NewTransform); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPartWorldTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e5b890
	void SetPartSimulatePhysics(int32_t PartID, bool bSimulatePhysics); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPartSimulatePhysics // (Native|Public) // @ game+0x5e633f0
	void SetPartLocalTransform(int32_t PartID, struct FTransform& NewTransform); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPartLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e65050
	void SetPartInWorldSpace(int32_t PartID, bool bIsWorldSpace); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPartInWorldSpace // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5e680
	void SetPartCollisionProfileName(int32_t ParID, struct FName InCollisionProfileName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetPartCollisionProfileName // (Native|Public) // @ game+0x5e5e8b0
	void SetMeshSurfacePoints(int32_t PartID, struct TArray<struct FVector>& Points); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetMeshSurfacePoints // (Native|Public|HasOutParms) // @ game+0x5e60340
	bool SetKinematicConstraintEnabled(int32_t PartID, bool bNewEnabledState); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetKinematicConstraintEnabled // (Final|Native|Public) // @ game+0x5e641c0
	void SetForceClientModeManually(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetForceClientModeManually // (Final|Native|Public|BlueprintCallable) // @ game+0x5e65550
	void SetDampingProperties(int32_t PartID, float LinearDamping, float AngularDamping); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetDampingProperties // (Native|Public) // @ game+0x5e5ede0
	void SetConstraintLinearVelocityTarget(int32_t PhysicsConstraintIndex, struct FVector& NewVelocityTarget); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintLinearVelocityTarget // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e61860
	void SetConstraintLinearPositionTarget(int32_t PhysicsConstraintIndex, struct FVector& NewPositionTarget); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintLinearPositionTarget // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e63100
	void SetConstraintLinearDriveParams(int32_t PhysicsConstraintIndex, float Spring, float Damper, float MaxForce); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintLinearDriveParams // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5dba0
	void SetConstraintAngularVelocityTarget(int32_t PhysicsConstraintIndex, struct FVector& NewVelocityTarget); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintAngularVelocityTarget // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e5efc0
	void SetConstraintAngularOrientationTargetQuat(int32_t PhysicsConstraintIndex, struct FQuat& NewOrientationTarget); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintAngularOrientationTargetQuat // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e65280
	void SetConstraintAngularOrientationTarget(int32_t PhysicsConstraintIndex, struct FRotator& NewOrientationTarget); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintAngularOrientationTarget // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e65850
	void SetConstraintAngularDriveParams(int32_t PhysicsConstraintIndex, float PositionStrength, float VelocityStrength, float AccelerationStrength); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetConstraintAngularDriveParams // (Final|Native|Public|BlueprintCallable) // @ game+0x5e63980
	void SetBoneTransformByName(struct FName BoneName, struct FTransform& InTransform, enum class ESkeletalMeshStyleSpace BoneSpace, bool bDeferRootTransformChanges); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetBoneTransformByName // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e5eaf0
	void SetBodySolverIterations(int32_t Position, int32_t Velocity); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetBodySolverIterations // (Final|Native|Public|BlueprintCallable) // @ game+0x5e60bc0
	void SetBodyCollisionProfileName(int32_t BodyInstanceIndex, struct FName InCollisionProfileName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SetBodyCollisionProfileName // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5fa70
	void SeparateDrivenConstraints(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.SeparateDrivenConstraints // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5b780
	void ResetBoneTransformByName(struct FName BoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.ResetBoneTransformByName // (Final|Native|Public|BlueprintCallable) // @ game+0x5e63200
	bool ReinitializeConstraint(int32_t PhysicsConstraintIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.ReinitializeConstraint // (Final|Native|Public) // @ game+0x5e60940
	void RegisterPartIDAsNotStableForRelativeTransform(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.RegisterPartIDAsNotStableForRelativeTransform // (Final|Native|Public) // @ game+0x5e64a70
	void RefreshPartsAllowedToOverlap(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.RefreshPartsAllowedToOverlap // (Final|Native|Public|BlueprintCallable) // @ game+0x5e64ff0
	void RecalculateBodyPropertiesAfterWelding(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.RecalculateBodyPropertiesAfterWelding // (Final|Native|Public) // @ game+0x5e60cc0
	int32_t PhysicsBodyIndexToPartID(int32_t PhysicsBodyIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.PhysicsBodyIndexToPartID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e62940
	struct FName PhysicsBodyIndexToBoneName(int32_t PhysicsBodyIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.PhysicsBodyIndexToBoneName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5f770
	int32_t PartIDToPhysicsBodyIndex(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.PartIDToPhysicsBodyIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e63ce0
	struct FName PartIDToBoneName(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.PartIDToBoneName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e63f90
	int32_t PartIDToBoneIndex(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.PartIDToBoneIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e655b0
	void OnPartHealthChanged(struct FConstructableDamageData& LatestHealthData); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.OnPartHealthChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnPartDestroyed(struct FConstructableDamageData& DestructionData); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.OnPartDestroyed // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnFullyConstructed(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.OnFullyConstructed // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void MarkForForcedRefreshTransform(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.MarkForForcedRefreshTransform // (Final|Native|Public) // @ game+0x5e630e0
	bool IsVirtualPart(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.IsVirtualPart // (Native|Public|Const) // @ game+0x5e60880
	bool IsPartIDInWorldSpaceTransformMode(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.IsPartIDInWorldSpaceTransformMode // (Final|Native|Public|Const) // @ game+0x5e5e780
	bool IsCollisionEnabledForBone(struct FName BoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.IsCollisionEnabledForBone // (Final|Native|Public|Const) // @ game+0x5e63b60
	bool IsBoneInWorldSpaceTransformMode(int32_t BoneIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.IsBoneInWorldSpaceTransformMode // (Final|Native|Public|Const) // @ game+0x5e62830
	void InitializeTSSConstraint(struct FTSSDriveParams& Parameters); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.InitializeTSSConstraint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e63e10
	void InitializeSLERPConstraint(struct FSLERPDriveParams& Parameters); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.InitializeSLERPConstraint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e65480
	void InitializeLinearConstraint(struct FLinearDriveParams& Parameters); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.InitializeLinearConstraint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e64ea0
	bool HasQueryCollision(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.HasQueryCollision // (Native|Public|Const) // @ game+0x5e5b010
	bool HasMeshSurfacePoints(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.HasMeshSurfacePoints // (Native|Public|Const) // @ game+0x5e60de0
	bool GetSkeletalBodySetups(struct TArray<struct USkeletalBodySetup*>& OutSkeletalBodySetups); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetSkeletalBodySetups // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e65790
	struct USkeletalBodySetup* GetSkeletalBodySetup(int32_t BodyInstanceIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetSkeletalBodySetup // (Final|Native|Public|Const) // @ game+0x5e60450
	int32_t GetRootBodyIndex(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetRootBodyIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5b560
	bool GetPhysicsLinearConstraint(int32_t PhysicsConstraintIndex, struct FLinearConstraintData& OutConstraint); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPhysicsLinearConstraint // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e644f0
	struct FVector GetPhysicsConstraintTwistSwing1Swing2(int32_t PhysicsConstraintIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPhysicsConstraintTwistSwing1Swing2 // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5e5e2e0
	void GetPhysicsConstraintsForBody(int32_t PhysicsBodyIndex, struct TArray<int32_t>& OutConstraintIndices); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPhysicsConstraintsForBody // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e5b160
	struct FName GetPhysicsConstraintName(int32_t PhysicsConstraintIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPhysicsConstraintName // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e5af10
	bool GetPhysicsConstraintLimits(int32_t PhysicsConstraintIndex, struct FAngularConstraintData& OutLimits); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPhysicsConstraintLimits // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e65660
	bool GetPartWorldTransform(int32_t PartID, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPartWorldTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e61270
	bool GetPartMass(int32_t PartID, float& OutMass); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPartMass // (Native|Public|HasOutParms|Const) // @ game+0x5e64920
	bool GetPartLocalTransform(int32_t PartID, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPartLocalTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e62f90
	struct FConstructablePartIDRange GetPartIDRange(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPartIDRange // (Native|Public|Const) // @ game+0x5e61620
	bool GetPartBounds_BodyBoundingBox(int32_t PartID, struct FBox& OutBounds); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPartBounds_BodyBoundingBox // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e5f5f0
	bool GetPartBounds(int32_t PartID, struct FBox& OutBounds); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetPartBounds // (Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e5f210
	struct FName GetParentSocket(struct FName& SocketOrBoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetParentSocket // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e5e1c0
	int32_t GetParentPhysicsBodyIndexFromConstraint(int32_t PhysicsConstraintIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetParentPhysicsBodyIndexFromConstraint // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e64440
	int32_t GetNumConstraintInstances(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetNumConstraintInstances // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e5b6d0
	int32_t GetNumBodyInstances(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetNumBodyInstances // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e5e610
	struct TArray<struct FVector> GetMeshSurfacePoints(int32_t PartID); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetMeshSurfacePoints // (Native|Public|Const) // @ game+0x5e60a60
	struct FTransform GetMeshRootTransform(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetMeshRootTransform // (Final|Native|Public|HasDefaults|Const) // @ game+0x5e5b9d0
	bool GetKinematicConstraintInfo(int32_t PartID, struct FAngularConstraintData& OutAngularConstraintData, struct FRotator& OutInitialKinematicBodiesBoneSpaceRotator); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetKinematicConstraintInfo // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e5f8d0
	bool GetConstraintFrame(int32_t PhysicsConstraintIndex, enum class EConstraintFrame Frame, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetConstraintFrame // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5e60060
	bool GetConstraintForce(int32_t PhysicsConstraintIndex, struct FVector& OutLinearForce, struct FVector& OutAngularForce); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetConstraintForce // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5e64d50
	bool GetConstraintDrive(int32_t PhysicsConstraintIndex, enum class EAngularDriveMode& OutDriveMode); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetConstraintDrive // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e60540
	bool GetConstraintAngularDriveParams(int32_t PhysicsConstraintIndex, float& OutSpring, float& OutDamping, float& OutMaxForce); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetConstraintAngularDriveParams // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e60680
	struct FTransform GetComponentSpaceRefPose(struct FName BoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetComponentSpaceRefPose // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e62a30
	bool GetClosestPointOnPartCollision(int32_t PartID, struct FVector& Point, struct FVector& OutPointOnBody); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetClosestPointOnPartCollision // (Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e5ba30
	int32_t GetChildPhysicsBodyIndexFromConstraint(int32_t ConstraintIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetChildPhysicsBodyIndexFromConstraint // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e5ff40
	struct FTransform GetBoneTransformByName(struct FName BoneName, enum class ESkeletalMeshStyleSpace BoneSpace); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetBoneTransformByName // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5fc60
	struct FTransform GetBoneSpaceRefPose(struct FName BoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetBoneSpaceRefPose // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5ece0
	bool GetBodyTransformFromIndex(int32_t BodyInstanceIndex, struct FTransform& OutTransform); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetBodyTransformFromIndex // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5f0c0
	struct FBodyInstance GetBodyInstanceFromIndex(int32_t BodyInstanceIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetBodyInstanceFromIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5f820
	struct FName GetBodyCollisionProfileName(int32_t BodyInstanceIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetBodyCollisionProfileName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e61c00
	struct UPhysicsAsset* GetActivePhysicsAsset(); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.GetActivePhysicsAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e62d10
	void CopyPoseFromSkeletalComponent(struct USkinnedMeshComponent* InComponentToCopy); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.CopyPoseFromSkeletalComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x5e63540
	void BreakPhysicsConstraint(int32_t PhysicsConstraintIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.BreakPhysicsConstraint // (Final|Native|Public|BlueprintCallable) // @ game+0x5e5b7a0
	int32_t BoneNameToPhysicsBodyIndex(struct FName BoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.BoneNameToPhysicsBodyIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e61730
	int32_t BoneNameToPartID(struct FName BoneName); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.BoneNameToPartID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5b2a0
	int32_t BoneIndexToPartID(int32_t BoneIndex); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.BoneIndexToPartID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e5b4b0
	void AddPartImpulseAtLocation(int32_t PartID, struct FVector& Location, struct FVector& Impulse); // Function EmbarkConstructable.ConstructableSkeletalMeshStyleComponent.AddPartImpulseAtLocation // (Native|Public|HasOutParms|HasDefaults) // @ game+0x5e5e3a0
};

// Class EmbarkConstructable.ConstructableSpawnSizeComponentBase
// Size: 0x160 (Inherited: 0x160)
struct UConstructableSpawnSizeComponentBase : UActorComponent {

	float GetCollisionRadius(); // Function EmbarkConstructable.ConstructableSpawnSizeComponentBase.GetCollisionRadius // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e678a0
	struct FBox GetAutoAcquiredExtent(); // Function EmbarkConstructable.ConstructableSpawnSizeComponentBase.GetAutoAcquiredExtent // (Event|Public|HasDefaults|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkConstructable.ConstructableStaticMeshStyleComponent
// Size: 0x960 (Inherited: 0x790)
struct UConstructableStaticMeshStyleComponent : UStaticMeshComponent {
	char pad_790[0x8]; // 0x790(0x08)
	struct FGameplayTagContainer PartTags; // 0x798(0x20)
	struct FConstructablePartIDRange PartIDRange; // 0x7b8(0x08)
	struct TArray<int32_t> ChildrenPartIDs; // 0x7c0(0x10)
	enum class EPartResistanceGroup ResistanceGroup; // 0x7d0(0x01)
	bool bIsDestroyed; // 0x7d1(0x01)
	enum class EConstructableHealthChangeReason DestroyedReason; // 0x7d2(0x01)
	char pad_7d3[0x5]; // 0x7d3(0x05)
	struct FAngularConstraintData PartAngularConstraint; // 0x7d8(0x40)
	struct TArray<struct FConstructableMeshStyleSlotTransform> SlotTransforms; // 0x818(0x10)
	struct TArray<struct FString> AdditionalSocketGroupDefinition; // 0x828(0x10)
	struct TMap<struct FName, struct FConstructableStyleSocketGroupDataArray> SocketGroupData; // 0x838(0x50)
	struct TMap<struct FName, int32_t> SocketIDs; // 0x888(0x50)
	struct TArray<struct FVector> MeshSurfacePoints; // 0x8d8(0x10)
	char pad_8e8[0x78]; // 0x8e8(0x78)

	void SetMeshSurfacePoints(int32_t PartID, struct TArray<struct FVector>& Points); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.SetMeshSurfacePoints // (Native|Public|HasOutParms) // @ game+0x5e67130
	void OnPartHealthChanged(struct FConstructableDamageData& LatestHealthData); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.OnPartHealthChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnPartDestroyed(struct FConstructableDamageData& DestructionData); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.OnPartDestroyed // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnFullyConstructed(); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.OnFullyConstructed // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool IsVirtualPart(int32_t PartID); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.IsVirtualPart // (Native|Public|Const) // @ game+0x5e6a6c0
	bool HasQueryCollision(int32_t PartID); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.HasQueryCollision // (Native|Public|Const) // @ game+0x5e66120
	bool HasMeshSurfacePoints(int32_t PartID); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.HasMeshSurfacePoints // (Native|Public|Const) // @ game+0x5e67910
	struct TArray<struct FName> GetSocketNames(); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.GetSocketNames // (Final|Native|Public|Const) // @ game+0x5e66060
	struct FConstructablePartIDRange GetPartIDRange(); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.GetPartIDRange // (Native|Public|Const) // @ game+0x5e6a780
	bool GetPartBounds(int32_t PartID, struct FBox& OutBounds); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.GetPartBounds // (Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e6aa90
	struct TArray<struct FVector> GetMeshSurfacePoints(int32_t PartID); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.GetMeshSurfacePoints // (Native|Public|Const) // @ game+0x5e6b920
	bool GetClosestPointOnPartCollision(int32_t PartID, struct FVector& Point, struct FVector& OutPointOnBody); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.GetClosestPointOnPartCollision // (Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e68cd0
	void ApplyAngularConstraints(); // Function EmbarkConstructable.ConstructableStaticMeshStyleComponent.ApplyAngularConstraints // (Final|Native|Public) // @ game+0x5e68100
};

// Class EmbarkConstructable.ConstructableStyleSharedMethods
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableStyleSharedMethods : UObject {
};

// Class EmbarkConstructable.ConstructableStyleAssemblyBase
// Size: 0x3a0 (Inherited: 0x3a0)
struct AConstructableStyleAssemblyBase : AActor {
	struct UConstructableStyleProxyCollectionComponent* ProxyCollectionComponent; // 0x398(0x08)

	struct UPrimitiveComponent* GetStyleComponentFromPartID(int32_t PartID); // Function EmbarkConstructable.ConstructableStyleAssemblyBase.GetStyleComponentFromPartID // (Final|Native|Public|Const) // @ game+0x5e68fc0
	void GetAllStyles(struct AConstructableStyleAssemblyBase* AssemblyToGetFrom, struct TArray<struct UPrimitiveComponent*>& OutAllStyles); // Function EmbarkConstructable.ConstructableStyleAssemblyBase.GetAllStyles // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e65e40
};

// Class EmbarkConstructable.ConstructableStyleAssemblerComponent
// Size: 0x440 (Inherited: 0x430)
struct UConstructableStyleAssemblerComponent : UComponentAssemblerComponentBase {
	struct AConstructableStyleAssemblyBase* StyleAssembly; // 0x428(0x08)
	struct AConstructableStyleAssemblyBase* AlternateStyleAssembly; // 0x430(0x08)
	bool bRuntimeSetupPartID; // 0x438(0x01)
};

// Class EmbarkConstructable.ConstructableComponentAssembler_ApprovedClasses
// Size: 0xe0 (Inherited: 0xe0)
struct UConstructableComponentAssembler_ApprovedClasses : UComponentAssembler_ApprovedClasses {
};

// Class EmbarkConstructable.ConstructableStyleDriverComponent
// Size: 0x170 (Inherited: 0x160)
struct UConstructableStyleDriverComponent : UActorComponent {
	struct AConstructableBase* Constructable; // 0x158(0x08)
	bool bWasASTickJustEnabled; // 0x160(0x01)
	char pad_169[0x7]; // 0x169(0x07)

	void SetNeedsASStyleTick(bool bVal); // Function EmbarkConstructable.ConstructableStyleDriverComponent.SetNeedsASStyleTick // (Final|Native|Public|BlueprintCallable) // @ game+0x5e6a060
	void SetASStyleTickInterval(float val); // Function EmbarkConstructable.ConstructableStyleDriverComponent.SetASStyleTickInterval // (Final|Native|Public|BlueprintCallable) // @ game+0x5e68380
	void OnConstructableDestroyed(struct AActor* DamageInstigator); // Function EmbarkConstructable.ConstructableStyleDriverComponent.OnConstructableDestroyed // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void Handle_ConstructableDestroyed(struct AConstructableBase* InConstructable, struct AActor* InDamageInstigator); // Function EmbarkConstructable.ConstructableStyleDriverComponent.Handle_ConstructableDestroyed // (Final|Native|Private) // @ game+0x5e685d0
	struct AConstructableBase* GetConstructable(); // Function EmbarkConstructable.ConstructableStyleDriverComponent.GetConstructable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b6d1f0
	void BP_OnFullyConstructed(); // Function EmbarkConstructable.ConstructableStyleDriverComponent.BP_OnFullyConstructed // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkConstructable.ConstructableStylePartListMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableStylePartListMixinLibrary : UObject {

	void Setup(struct FConstructableStylePartList& ConstructableStylePartList, struct AActor* Actor); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.Setup // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e6a800
	struct TArray<struct FConstructablePartTransform> GetPartTransforms(struct FConstructableStylePartList& ConstructableStylePartList); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.GetPartTransforms // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e69d00
	struct FConstructablePartTransform GetPartTransformByID(struct FConstructableStylePartList& ConstructableStylePartList, struct UObject* WorldContextObject, int32_t PartID); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.GetPartTransformByID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e6a370
	struct TArray<struct FConstructablePart> GetParts(struct FConstructableStylePartList& ConstructableStylePartList, struct AActor* Owner); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.GetParts // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e6b120
	struct TArray<int32_t> GetPartIDs(struct FConstructableStylePartList& ConstructableStylePartList); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.GetPartIDs // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e67f50
	struct FConstructablePart GetPartByID(struct FConstructableStylePartList& ConstructableStylePartList, struct UObject* WorldContextObject, int32_t PartID, struct AActor* Owner); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.GetPartByID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e695f0
	bool ContainsPartID(struct FConstructableStylePartList& ConstructableStylePartList, int32_t PartID); // Function EmbarkConstructable.ConstructableStylePartListMixinLibrary.ContainsPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e67540
};

// Class EmbarkConstructable.ConstructableStyleProxyMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableStyleProxyMixinLibrary : UObject {

	void SetupWithAssembly(struct FConstructableStyleProxy& StyleProxy, struct AConstructableStyleAssemblyBase* Assembly); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.SetupWithAssembly // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e65aa0
	void Setup(struct FConstructableStyleProxy& StyleProxy, struct AConstructableBase* Constructable); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.Setup // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e67380
	struct FTransform GetWorldTransform(struct FConstructableStyleProxy& StyleProxy); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e69eb0
	struct FQuat GetWorldRotationQuat(struct FConstructableStyleProxy& StyleProxy); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetWorldRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e69a90
	struct FRotator GetWorldRotation(struct FConstructableStyleProxy& StyleProxy); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetWorldRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e6b650
	struct FVector GetWorldLocation(struct FConstructableStyleProxy& StyleProxy); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e6b500
	struct FTransform GetRelativeTransform(struct FConstructableStyleProxy& StyleProxy, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e68880
	struct FQuat GetRelativeRotationQuat(struct FConstructableStyleProxy& StyleProxy, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e6b2e0
	struct FRotator GetRelativeRotation(struct FConstructableStyleProxy& StyleProxy, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e68e30
	struct FVector GetRelativeLocation(struct FConstructableStyleProxy& StyleProxy, enum class EConstructablePartRelativeTransformSpace TransformSpace); // Function EmbarkConstructable.ConstructableStyleProxyMixinLibrary.GetRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e67af0
};

// Class EmbarkConstructable.ConstructableStyleProxyCollectionComponent
// Size: 0x170 (Inherited: 0x160)
struct UConstructableStyleProxyCollectionComponent : UActorComponent {
	struct TArray<struct FConstructableProxyPart> ProxyPartList; // 0x158(0x10)
};

// Class EmbarkConstructable.ConstructableStyleProxyComponent
// Size: 0x770 (Inherited: 0x6c0)
struct UConstructableStyleProxyComponent : UPrimitiveComponent {
	struct FGameplayTagContainer PartTags; // 0x6c0(0x20)
	struct FConstructablePartIDRange PartIDRange; // 0x6e0(0x08)
	char pad_6e8[0x88]; // 0x6e8(0x88)
};

// Class EmbarkConstructable.ConstructableStyleProxyContainer
// Size: 0x150 (Inherited: 0xa0)
struct UConstructableStyleProxyContainer : UObject {
	struct TMap<int32_t, struct FConstructableProxyPart> PartIDToProxyMap; // 0xa0(0x50)
	struct TMap<struct FName, int32_t> PartNameToPartIDMap; // 0xf0(0x50)
	struct AConstructableBase* ConstructableOwner; // 0x140(0x08)
	char pad_148[0x8]; // 0x148(0x08)
};

// Class EmbarkConstructable.ConstructableStyleShapeComponent
// Size: 0x7c0 (Inherited: 0x6f0)
struct UConstructableStyleShapeComponent : UMeshComponent {
	char pad_6f0[0x8]; // 0x6f0(0x08)
	struct UMaterialInstance* ShapeMaterial; // 0x6f8(0x08)
	struct FGameplayTagContainer PartTags; // 0x700(0x20)
	struct FConstructablePartIDRange PartIDRange; // 0x720(0x08)
	char pad_728[0x68]; // 0x728(0x68)
	struct FVector BoxExtent; // 0x790(0x18)
	bool bIsDestroyed; // 0x7a8(0x01)
	char pad_7a9[0x7]; // 0x7a9(0x07)
	struct UBodySetup* BodySetup; // 0x7b0(0x08)
	char pad_7b8[0x8]; // 0x7b8(0x08)

	void OnPartHealthChanged(struct FConstructableDamageData& LatestHealthData); // Function EmbarkConstructable.ConstructableStyleShapeComponent.OnPartHealthChanged // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkConstructable.ConstructablePartTargetingDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartTargetingDataMixinLibrary : UObject {

	void SetTargetObject(struct FConstructablePartTargetingData& TargetingData, struct UObject* TargetObject); // Function EmbarkConstructable.ConstructablePartTargetingDataMixinLibrary.SetTargetObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e6f6e0
	struct UObject* GetTargetObject(struct FConstructablePartTargetingData& TargetingData); // Function EmbarkConstructable.ConstructablePartTargetingDataMixinLibrary.GetTargetObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e709e0
};

// Class EmbarkConstructable.ConstructablePartTargetingEventDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartTargetingEventDataMixinLibrary : UObject {

	void SetTargetObject(struct FConstructablePartTargetingEventData& EventData, struct UObject* TargetObject); // Function EmbarkConstructable.ConstructablePartTargetingEventDataMixinLibrary.SetTargetObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e71440
	struct UObject* GetTargetObject(struct FConstructablePartTargetingEventData& EventData); // Function EmbarkConstructable.ConstructablePartTargetingEventDataMixinLibrary.GetTargetObject // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e6e740
	int32_t GetAffectedPartID(struct FConstructablePartTargetingEventData& EventData); // Function EmbarkConstructable.ConstructablePartTargetingEventDataMixinLibrary.GetAffectedPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e6fe10
};

// Class EmbarkConstructable.ConstructablePartTargetingDataArraySimState
// Size: 0xe0 (Inherited: 0xb0)
struct UConstructablePartTargetingDataArraySimState : USimConstructableBaseClass {
	struct FABArraySizeLimiter ArraySize; // 0xa8(0x04)
	struct TArray<struct FConstructablePartTargetingData> Items; // 0xb0(0x10)
	struct FABArraySizeLimiter ArraySizeConfigOverrides; // 0xc0(0x04)
	struct TArray<struct FConstructablePartConfigOverride> ConfigOverrides; // 0xc8(0x10)
	char pad_d8[0x8]; // 0xd8(0x08)

	void OnRep_Items(); // Function EmbarkConstructable.ConstructablePartTargetingDataArraySimState.OnRep_Items // (Final|Native|Public) // @ game+0x5e72df0
	void OnRep_ConfigOverrides(); // Function EmbarkConstructable.ConstructablePartTargetingDataArraySimState.OnRep_ConfigOverrides // (Final|Native|Public) // @ game+0x5e6c6b0
	void InitForActor(struct AActor* Actor); // Function EmbarkConstructable.ConstructablePartTargetingDataArraySimState.InitForActor // (Final|Native|Public) // @ game+0x5e6eac0
};

// Class EmbarkConstructable.ConstructableTargetingServiceComponent
// Size: 0x6d0 (Inherited: 0x180)
struct UConstructableTargetingServiceComponent : UConstructableServiceComponentBase {
	struct FMulticastInlineDelegate OnPartTargetingDataUpdated_Interpolated; // 0x178(0x10)
	struct TArray<struct FConstructablePartGroupTargetingConfig> PartTargetingConfigs; // 0x188(0x10)
	struct TArray<struct FConstructablePartPivotConfig> RotationOriginConfigs; // 0x198(0x10)
	struct FConstructablePartTargetingConfig DefaultPartTargetingConfig; // 0x1a8(0x120)
	bool bAmortizeTargetingUpdates; // 0x2c8(0x01)
	float MinDistanceForDynamicUpdate; // 0x2cc(0x04)
	float MaxDistanceForDynamicUpdate; // 0x2d0(0x04)
	float DynamicUpdateThrottleAmount; // 0x2d4(0x04)
	struct FMulticastInlineDelegate OnPartStopTargeting_Server; // 0x2d8(0x10)
	struct APlayerState* PlayerState_Client; // 0x2e8(0x08)
	char pad_2f5[0x3db]; // 0x2f5(0x3db)

	void TargetPartRelativeRotation_Server_Quat(int32_t AffectedPartID, struct FQuat& RelativeRotation, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.TargetPartRelativeRotation_Server_Quat // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e74500
	void TargetPartRelativeRotation_Server_NoParams_Quat(int32_t AffectedPartID, struct FQuat& RelativeRotation); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.TargetPartRelativeRotation_Server_NoParams_Quat // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e6d110
	void TargetPartRelativeRotation_Server_NoParams(int32_t AffectedPartID, struct FRotator& RelativeRotation); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.TargetPartRelativeRotation_Server_NoParams // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e73ec0
	void TargetPartRelativeRotation_Server(int32_t AffectedPartID, struct FRotator& RelativeRotation, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.TargetPartRelativeRotation_Server // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e70f20
	void SetAimOffsetForPart(int32_t AffectedPartID, struct FVector AimOffset); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.SetAimOffsetForPart // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x5e6bda0
	void ResetRotatedParts_Server(); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.ResetRotatedParts_Server // (Final|Native|Public) // @ game+0x5e6bd40
	void ResetPartRotation_Server(int32_t AffectedPartID); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.ResetPartRotation_Server // (Final|Native|Public) // @ game+0x5e74700
	bool PollInterpolatedTrackingData(int32_t AffectedPartID, struct FConstructablePartTargetingEventData& OutData); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.PollInterpolatedTrackingData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x5e738d0
	void OverrideTargetingSpeed_Server(int32_t AffectedPartID, float DegreesPerSecond); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.OverrideTargetingSpeed_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5e6fff0
	void OnPartDestroyed(struct UConstructableHealthServiceComponent* HealthServiceComponent, struct UPrimitiveComponent* OwnerStyle, struct FConstructableDamageData& LatestData); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.OnPartDestroyed // (Final|Native|Public|HasOutParms) // @ game+0x5e6beb0
	void MulticastFreezeTrackingAt(int32_t AffectedPartID, int32_t EventID, float ServerTimeToFreeze); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MulticastFreezeTrackingAt // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0x5e71260
	void MakePartTrackWorldOrientation_Server_NoParams(int32_t AffectedPartID, struct FRotator& TargetOrientation); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackWorldOrientation_Server_NoParams // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e741b0
	void MakePartTrackWorldOrientation_Server(int32_t AffectedPartID, struct FRotator& TargetOrientation, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackWorldOrientation_Server // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e6d710
	void MakePartTrackWorldLocation_Server_NoParams(int32_t AffectedPartID, struct FVector& TargetLocation); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackWorldLocation_Server_NoParams // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e70440
	void MakePartTrackWorldLocation_Server(int32_t AffectedPartID, struct FVector& TargetLocation, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackWorldLocation_Server // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e707a0
	void MakePartTrackConstructablePart_Server_NoParams(int32_t AffectedPartID, struct AConstructableBase* ConstructableToTrack, int32_t PartIDToTrack); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackConstructablePart_Server_NoParams // (Final|Native|Public) // @ game+0x5e6fa50
	void MakePartTrackConstructablePart_Server(int32_t AffectedPartID, struct AConstructableBase* ConstructableToTrack, int32_t PartIDToTrack, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackConstructablePart_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e71eb0
	void MakePartTrackComponent_Server_NoParams(int32_t AffectedPartID, struct USceneComponent* ComponentToTrack); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackComponent_Server_NoParams // (Final|Native|Public) // @ game+0x5e71080
	void MakePartTrackComponent_Server(int32_t AffectedPartID, struct USceneComponent* ComponentToTrack, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackComponent_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e70600
	void MakePartTrackActor_Server_NoParams(int32_t AffectedPartID, struct AActor* ActorToTrack); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackActor_Server_NoParams // (Final|Native|Public) // @ game+0x5e6f8e0
	void MakePartTrackActor_Server(int32_t AffectedPartID, struct AActor* ActorToTrack, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartTrackActor_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e6e4c0
	void MakePartStopTracking_Server_NoParams(int32_t AffectedPartID); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartStopTracking_Server_NoParams // (Final|Native|Public) // @ game+0x5e71850
	void MakePartStopTracking_Server(int32_t AffectedPartID, struct FTargetingServiceParams& Params); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartStopTracking_Server // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5e70130
	void MakePartChaseTarget_Server(int32_t AffectedPartID, struct FVector& StartLocation, struct USceneComponent* ComponentToTrack, struct FVector& LocationToTrack, struct FTargetingServiceParams& Params, float MaxSpeed, float OffsetZ, bool bChaseLocation); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.MakePartChaseTarget_Server // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e6cd30
	struct TSet<int32_t> GetPartsRotated_Server(); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.GetPartsRotated_Server // (Final|Native|Public) // @ game+0x5e6d3d0
	struct FConstructablePartTargetingConfig GetPartConfig(int32_t PartID); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.GetPartConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e6e910
	struct FConstructablePartTargetingConfig GetMutablePartConfig(int32_t PartID); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.GetMutablePartConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x5e73be0
	struct FVector GetAimOffset(int32_t AffectedPartID); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.GetAimOffset // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x5e6fce0
	void ClientFreezeTrackingAt_Server(int32_t AffectedPartID, float ServerTimeToFreeze); // Function EmbarkConstructable.ConstructableTargetingServiceComponent.ClientFreezeTrackingAt_Server // (Final|Native|Public|BlueprintCallable) // @ game+0x5e71ca0
};

// Class EmbarkConstructable.ConstructableTrainingComponent
// Size: 0x180 (Inherited: 0x160)
struct UConstructableTrainingComponent : UActorComponent {
	struct TArray<struct FConstructableTrainingShapeInfo> TrainingShapes; // 0x158(0x10)
	struct TArray<struct UShapeComponent*> Shapes; // 0x168(0x10)

	void ConstructShapes(); // Function EmbarkConstructable.ConstructableTrainingComponent.ConstructShapes // (Final|Native|Public) // @ game+0x5e77f10
};

// Class EmbarkConstructable.AngularConstraintDataMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngularConstraintDataMixinLibrary : UObject {

	struct FRotator CalcConstrainedRotation(struct FAngularConstraintData& ConstraintData, struct FRotator RelativeRotation); // Function EmbarkConstructable.AngularConstraintDataMixinLibrary.CalcConstrainedRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e76110
};

// Class EmbarkConstructable.ConstructableUtilsStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableUtilsStatics : UObject {

	void SortStyleComponentsByName(struct TArray<struct USceneComponent*>& OutStyleComponent); // Function EmbarkConstructable.ConstructableUtilsStatics.SortStyleComponentsByName // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e7ab60
	bool IsStyleComponent(struct UActorComponent* MaybeStyleComponent); // Function EmbarkConstructable.ConstructableUtilsStatics.IsStyleComponent // (Final|Native|Static|Public) // @ game+0x5e75210
	bool IsPartIDValid(int32_t PartID); // Function EmbarkConstructable.ConstructableUtilsStatics.IsPartIDValid // (Final|Native|Static|Public) // @ game+0x5e78f50
	bool IsPartDestroyed(struct UPrimitiveComponent* MaybeStyle, int32_t PartID); // Function EmbarkConstructable.ConstructableUtilsStatics.IsPartDestroyed // (Final|Native|Static|Public) // @ game+0x5e76480
	struct UPrimitiveComponent* GetStyleComponentFromPartID(struct TArray<struct UPrimitiveComponent*>& Styles, int32_t PartID); // Function EmbarkConstructable.ConstructableUtilsStatics.GetStyleComponentFromPartID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e7ac10
	void GetPartsIntersectingSphere(struct UPrimitiveComponent* MaybeStyleComponent, struct FVector& SphereOrigin, float SphereRadius, struct TArray<int32_t>& OutPartIDs); // Function EmbarkConstructable.ConstructableUtilsStatics.GetPartsIntersectingSphere // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e76730
	float GetPartMass(struct UPrimitiveComponent* MaybeStyleComponent, struct FName PartName); // Function EmbarkConstructable.ConstructableUtilsStatics.GetPartMass // (Final|Native|Static|Public) // @ game+0x5e78210
	bool GetPartIDsMatchingTagQuery(struct UPrimitiveComponent* MaybeStyleComponent, struct FGameplayTagQuery& TagQuery, struct TSet<int32_t>& OutPartIDs); // Function EmbarkConstructable.ConstructableUtilsStatics.GetPartIDsMatchingTagQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e79560
	struct FConstructablePartIDRange GetPartIDRange(struct UPrimitiveComponent* MaybeStyleComponent); // Function EmbarkConstructable.ConstructableUtilsStatics.GetPartIDRange // (Final|Native|Static|Public) // @ game+0x5e7ada0
	int32_t GetPartIDFromHitResult(struct FHitResult& HitResult); // Function EmbarkConstructable.ConstructableUtilsStatics.GetPartIDFromHitResult // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e78030
	int32_t GetNextAttackEventID(); // Function EmbarkConstructable.ConstructableUtilsStatics.GetNextAttackEventID // (Final|Native|Static|Public) // @ game+0x5e751e0
	void AddSocketData(struct USceneComponent* MaybeStyle); // Function EmbarkConstructable.ConstructableUtilsStatics.AddSocketData // (Final|Native|Static|Public) // @ game+0x5e797d0
};

// Class EmbarkConstructable.ConstructableUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableUtils : UObject {

	void SortByDistanceToReference(struct AConstructableBase* Constructable, struct TSet<int32_t>& PartIDs, struct FVector& Reference, bool bUseSurfacePoints, struct TArray<int32_t>& SortedIDs, struct TArray<float>& SortedDistances); // Function EmbarkConstructable.ConstructableUtils.SortByDistanceToReference // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x5e7a620
	int32_t GetNextAttackEventID(); // Function EmbarkConstructable.ConstructableUtils.GetNextAttackEventID // (Final|Native|Static|Public) // @ game+0x5e75a50
};

// Class EmbarkConstructable.ConstructableStyleComponentMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableStyleComponentMixinLibrary : UObject {

	bool IsStyleProxy(struct UActorComponent* MaybeStyleComponent); // Function EmbarkConstructable.ConstructableStyleComponentMixinLibrary.IsStyleProxy // (Final|Native|Static|Public) // @ game+0x5e78510
	bool IsStyleComponent(struct UActorComponent* MaybeStyleComponent); // Function EmbarkConstructable.ConstructableStyleComponentMixinLibrary.IsStyleComponent // (Final|Native|Static|Public) // @ game+0x5e75210
};

// Class EmbarkConstructable.ConstructableStylePartIDRangeMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableStylePartIDRangeMixinLibrary : UObject {

	bool IsValid(struct FConstructablePartIDRange& PartIDRange); // Function EmbarkConstructable.ConstructableStylePartIDRangeMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e75c60
	bool IsPartIDInRange(struct FConstructablePartIDRange& PartIDRange, int32_t PartID); // Function EmbarkConstructable.ConstructableStylePartIDRangeMixinLibrary.IsPartIDInRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e75eb0
	int32_t GetLastID(struct FConstructablePartIDRange& PartIDRange); // Function EmbarkConstructable.ConstructableStylePartIDRangeMixinLibrary.GetLastID // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e78650
};

// Class EmbarkConstructable.ConstructablePartParentInfoMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructablePartParentInfoMixinLibrary : UObject {

	bool IsValid(struct FConstructablePartParentInfo& PartParentInfo); // Function EmbarkConstructable.ConstructablePartParentInfoMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x5e76010
};

// Class EmbarkConstructable.EmbarkAbilityTask_ClientSendInteractionTargetData
// Size: 0x140 (Inherited: 0xf0)
struct UEmbarkAbilityTask_ClientSendInteractionTargetData : UAbilityTask {
	struct AActor* Target; // 0xf0(0x08)
	int32_t InteractionIndex; // 0xf8(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)
	struct FVector InteractionSourcePoint; // 0x100(0x18)
	bool bHandleInteraction; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
	struct FComponentOrStyle PrimitiveInteractedWith; // 0x120(0x18)
	char pad_138[0x8]; // 0x138(0x08)

	struct UEmbarkAbilityTask_ClientSendInteractionTargetData* ClientSendInteractionTargetData(struct UGameplayAbility* OwningAbility, struct FName TaskInstanceName, struct AActor* Target, int32_t InteractionIndex, struct FVector InteractionSourcePoint, bool bHandleInteraction, struct FComponentOrStyle& PrimitiveInteractedWith); // Function EmbarkConstructable.EmbarkAbilityTask_ClientSendInteractionTargetData.ClientSendInteractionTargetData // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5e79f30
};

// Class EmbarkConstructable.ConstructableBoundsSpatialPartitioning
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableBoundsSpatialPartitioning : UObject {
};

// Class EmbarkConstructable.ConstructableBoundsOctree
// Size: 0x1b0 (Inherited: 0xa0)
struct UConstructableBoundsOctree : UConstructableBoundsSpatialPartitioning {
	char pad_a0[0x110]; // 0xa0(0x110)
};

// Class EmbarkConstructable.ConstructableBoundsSubsystemSettings
// Size: 0xe0 (Inherited: 0xb0)
struct UConstructableBoundsSubsystemSettings : UDeveloperSettings {
	struct UConstructableBoundsSpatialPartitioning* SpatialPartitioningClass; // 0xa8(0x08)
	struct TSoftClassPtr<UObject> PlayableSpaceVolumeClass; // 0xb0(0x28)
};

// Class EmbarkConstructable.ConstructableBoundsSubsystem
// Size: 0x120 (Inherited: 0xb0)
struct UConstructableBoundsSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x68]; // 0xb0(0x68)
	struct UConstructableBoundsSpatialPartitioning* SpatialPartitioning; // 0x118(0x08)

	bool RemoveConstructableWithId(struct FConstructableBoundsId& ID); // Function EmbarkConstructable.ConstructableBoundsSubsystem.RemoveConstructableWithId // (Final|Native|Public|HasOutParms) // @ game+0x5e7b3b0
	void QueryConstructablesWithinSphere(struct FVector& Position, float Radius, struct TArray<struct AConstructableBase*>& OutConstructables); // Function EmbarkConstructable.ConstructableBoundsSubsystem.QueryConstructablesWithinSphere // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e78890
	void QueryConstructablesWithinBox(struct FBox& Box, struct TArray<struct AConstructableBase*>& OutConstructables); // Function EmbarkConstructable.ConstructableBoundsSubsystem.QueryConstructablesWithinBox // (Final|Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x5e78700
	void EnableOverlapEventsForConstructablesWithinBoxForDuration(struct FBox& Box, double& DurationSeconds); // Function EmbarkConstructable.ConstructableBoundsSubsystem.EnableOverlapEventsForConstructablesWithinBoxForDuration // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x5e79c20
	struct FConstructableBoundsId AddConstructable(struct AConstructableBase* Constructable); // Function EmbarkConstructable.ConstructableBoundsSubsystem.AddConstructable // (Final|Native|Public) // @ game+0x5e78420
};

// Class EmbarkConstructable.ConstructableStyleComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UConstructableStyleComponent : UInterface {
};

// Class EmbarkConstructable.ReplicatePartForceMovementNetState
// Size: 0x150 (Inherited: 0x140)
struct UReplicatePartForceMovementNetState : UConstructableMovementNetState {
	uint16_t ThrusterForceRep; // 0x140(0x02)
	char pad_142[0xe]; // 0x142(0x0e)
};

// Class EmbarkConstructable.ReplicatePartForceMovementNetStateLowCompressed
// Size: 0x150 (Inherited: 0x140)
struct UReplicatePartForceMovementNetStateLowCompressed : UConstructableMovementNetStateLowCompressed {
	uint16_t ThrusterForceRep; // 0x140(0x02)
	char pad_142[0xe]; // 0x142(0x0e)
};

// Class EmbarkConstructable.ReplicatedPartForceMovementComponent
// Size: 0x4a0 (Inherited: 0x390)
struct UReplicatedPartForceMovementComponent : UConstructableMovementComponentBase {
	struct FGameplayTagQuery ThrusterPartQuery; // 0x390(0x48)
	bool bFaceInMoveDirectionOverride; // 0x3d8(0x01)
	char pad_3d9[0x7]; // 0x3d9(0x07)
	struct TArray<int32_t> ThrusterPartIDs; // 0x3e0(0x10)
	struct TArray<float> ThrusterForceScalars; // 0x3f0(0x10)
	struct FMulticastInlineDelegate OnStucknessChanged; // 0x400(0x10)
	struct TArray<struct FConstructablePart> ThrusterParts; // 0x410(0x10)
	uint16_t ThrusterForceRep; // 0x420(0x02)
	char pad_422[0x6]; // 0x422(0x06)
	struct AAIController* AIController; // 0x428(0x08)
	struct AConstructableBase* Constructable; // 0x430(0x08)
	struct UConstructableHealthServiceComponent* HealthService; // 0x438(0x08)
	struct UPrimitiveComponent* Body; // 0x440(0x08)
	struct FConstructablePart BasePart; // 0x448(0x38)
	bool bIsPlayerControlled; // 0x480(0x01)
	char pad_481[0x1f]; // 0x481(0x1f)

	void ZeroTruncatedScalars(); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.ZeroTruncatedScalars // (Final|Native|Protected) // @ game+0x5e830f0
	bool ZeroScalarsAndRep(); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.ZeroScalarsAndRep // (Final|Native|Protected) // @ game+0x5ea9270
	void UpdateThrusterForceRep(); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.UpdateThrusterForceRep // (Final|Native|Protected) // @ game+0x5ea8eb0
	struct TArray<float> UnpackToNScalars_Test(uint16_t InputVal, int32_t NumScalars); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.UnpackToNScalars_Test // (Final|Native|Public|Const) // @ game+0x5eb0ee0
	void TickExternal_Server(float DeltaSeconds); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.TickExternal_Server // (Final|Native|Protected) // @ game+0x5e91410
	void TickExternal_Client(float DeltaSeconds); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.TickExternal_Client // (Final|Native|Protected) // @ game+0x5e84bc0
	bool SaveScalar(int32_t Index, float ScalarValue); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.SaveScalar // (Final|Native|Protected) // @ game+0x5eae9c0
	uint16_t PackTo2bits_Test(struct TArray<char>& TruncatedIn); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.PackTo2bits_Test // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e83030
	void OnThrustPartsLoaded(); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.OnThrustPartsLoaded // (Native|Event|Protected|BlueprintEvent) // @ game+0x29fb8f0
	void OnRep_ThrusterForceRep(uint16_t NewThrusterForceRep); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.OnRep_ThrusterForceRep // (Final|Native|Private) // @ game+0x5e82180
	void OnPostFullyConstructed_Internal(struct AConstructableBase* InConstructable); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.OnPostFullyConstructed_Internal // (Final|Native|Protected) // @ game+0x5e95eb0
	void OnPostFullyConstructed(struct AConstructableBase* InConstructable); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.OnPostFullyConstructed // (Native|Event|Protected|BlueprintEvent) // @ game+0x5e95eb0
	void OnPartDestroyed_Impl(struct UConstructableHealthServiceComponent* HealthServiceComponent, struct UPrimitiveComponent* OwnerStyleComponent, struct FConstructableDamageData& LatestData); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.OnPartDestroyed_Impl // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnPartDestroyed(struct UConstructableHealthServiceComponent* HealthServiceComponent, struct UPrimitiveComponent* OwnerStyleComponent, struct FConstructableDamageData& LatestData); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.OnPartDestroyed // (Final|Native|Private|HasOutParms) // @ game+0x5e81080
	void GetThrusterScalars(struct TArray<int32_t>& PartIDs, struct TArray<float>& OutScalars); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.GetThrusterScalars // (Final|Native|Public|HasOutParms|Const) // @ game+0x5e9af00
	float GetThrusterScalar(int32_t PartID); // Function EmbarkConstructable.ReplicatedPartForceMovementComponent.GetThrusterScalar // (Final|Native|Public|Const) // @ game+0x5ea0900
};

