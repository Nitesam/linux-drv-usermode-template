// Class Landscape.ControlPointMeshComponent
// Size: 0x790 (Inherited: 0x790)
struct UControlPointMeshComponent : UStaticMeshComponent {
	float VirtualTextureMainPassMaxDrawDistance; // 0x788(0x04)
};

// Class Landscape.LandscapeSplineInterface
// Size: 0xa0 (Inherited: 0xa0)
struct ULandscapeSplineInterface : UInterface {
};

// Class Landscape.LandscapeProxy
// Size: 0x720 (Inherited: 0x3a0)
struct ALandscapeProxy : APartitionActor {
	struct ULandscapeSplinesComponent* SplineComponent; // 0x3a0(0x08)
	struct FGuid LandscapeGuid; // 0x3a8(0x10)
	char pad_3b8[0x10]; // 0x3b8(0x10)
	bool bEnableNanite; // 0x3c8(0x01)
	char pad_3c9[0x7]; // 0x3c9(0x07)
	struct TArray<struct FLandscapePerLODMaterialOverride> PerLODOverrideMaterials; // 0x3d0(0x10)
	struct FIntPoint LandscapeSectionOffset; // 0x3e0(0x08)
	int32_t MaxLODLevel; // 0x3e8(0x04)
	float ComponentScreenSizeToUseSubSections; // 0x3ec(0x04)
	float LOD0ScreenSize; // 0x3f0(0x04)
	uint32_t LODGroupKey; // 0x3f4(0x04)
	float LOD0DistributionSetting; // 0x3f8(0x04)
	float LODDistributionSetting; // 0x3fc(0x04)
	int32_t ForcedRayTracingLOD; // 0x400(0x04)
	char pad_404[0x4]; // 0x404(0x04)
	struct TArray<struct UGrassInstancedStaticMeshComponent*> GrassPool; // 0x408(0x10)
	int32_t StaticLightingLOD; // 0x418(0x04)
	char pad_41c[0x4]; // 0x41c(0x04)
	struct UPhysicalMaterial* DefaultPhysMaterial; // 0x420(0x08)
	float StreamingDistanceMultiplier; // 0x428(0x04)
	char pad_42c[0x4]; // 0x42c(0x04)
	struct UMaterialInterface* LandscapeMaterial; // 0x430(0x08)
	struct UMaterialInterface* LandscapeHoleMaterial; // 0x438(0x08)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x440(0x10)
	bool bSetCreateRuntimeVirtualTextureVolumes; // 0x450(0x01)
	bool bVirtualTextureRenderWithQuad; // 0x451(0x01)
	bool bVirtualTextureRenderWithQuadHQ; // 0x452(0x01)
	char pad_453[0x1]; // 0x453(0x01)
	int32_t VirtualTextureNumLods; // 0x454(0x04)
	int32_t VirtualTextureLodBias; // 0x458(0x04)
	enum class ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x45c(0x01)
	char pad_45d[0x3]; // 0x45d(0x03)
	float NegativeZBoundsExtension; // 0x460(0x04)
	float PositiveZBoundsExtension; // 0x464(0x04)
	struct TArray<struct ULandscapeComponent*> LandscapeComponents; // 0x468(0x10)
	struct TArray<struct ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // 0x478(0x10)
	struct TArray<struct UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // 0x488(0x10)
	struct ULandscapeNaniteComponent* NaniteComponent; // 0x498(0x08)
	struct TArray<struct ULandscapeNaniteComponent*> NaniteComponents; // 0x4a0(0x10)
	char pad_4b0[0x64]; // 0x4b0(0x64)
	bool bHasLandscapeGrass; // 0x514(0x01)
	char pad_515[0x3]; // 0x515(0x03)
	float GrassTypesMaxDiscardDistance; // 0x518(0x04)
	float StaticLightingResolution; // 0x51c(0x04)
	char CastShadow : 1; // 0x520(0x01)
	char bCastDynamicShadow : 1; // 0x520(0x01)
	char bCastStaticShadow : 1; // 0x520(0x01)
	char pad_520_3 : 5; // 0x520(0x01)
	enum class EShadowCacheInvalidationBehavior ShadowCacheInvalidationBehavior; // 0x521(0x01)
	char bCastContactShadow : 1; // 0x522(0x01)
	char pad_522_1 : 7; // 0x522(0x01)
	char pad_523[0x1]; // 0x523(0x01)
	char bCastFarShadow : 1; // 0x524(0x01)
	char pad_524_1 : 7; // 0x524(0x01)
	char pad_525[0x3]; // 0x525(0x03)
	char bCastHiddenShadow : 1; // 0x528(0x01)
	char pad_528_1 : 7; // 0x528(0x01)
	char pad_529[0x3]; // 0x529(0x03)
	char bCastShadowAsTwoSided : 1; // 0x52c(0x01)
	char pad_52c_1 : 7; // 0x52c(0x01)
	char pad_52d[0x3]; // 0x52d(0x03)
	char bAffectDistanceFieldLighting : 1; // 0x530(0x01)
	char pad_530_1 : 7; // 0x530(0x01)
	struct FLightingChannels LightingChannels; // 0x531(0x01)
	char pad_532[0x2]; // 0x532(0x02)
	char bUseMaterialPositionOffsetInStaticLighting : 1; // 0x534(0x01)
	char bRenderCustomDepth : 1; // 0x534(0x01)
	char pad_534_2 : 6; // 0x534(0x01)
	char pad_535[0x3]; // 0x535(0x03)
	enum class ERendererStencilMask CustomDepthStencilWriteMask; // 0x538(0x01)
	char pad_539[0x3]; // 0x539(0x03)
	int32_t CustomDepthStencilValue; // 0x53c(0x04)
	float LDMaxDrawDistance; // 0x540(0x04)
	struct FLightmassPrimitiveSettings LightmassSettings; // 0x544(0x18)
	int32_t CollisionMipLevel; // 0x55c(0x04)
	int32_t SimpleCollisionMipLevel; // 0x560(0x04)
	char pad_564[0x4]; // 0x564(0x04)
	float EmbarkLegacyCollisionThickness; // 0x568(0x04)
	bool bUseAlphaBlendingForDominantPhysicsLayer; // 0x56c(0x01)
	char pad_56d[0x3]; // 0x56d(0x03)
	struct FBodyInstance BodyInstance; // 0x570(0x190)
	char bGenerateOverlapEvents : 1; // 0x700(0x01)
	char bBakeMaterialPositionOffsetIntoCollision : 1; // 0x700(0x01)
	char pad_700_2 : 6; // 0x700(0x01)
	char pad_701[0x3]; // 0x701(0x03)
	int32_t ComponentSizeQuads; // 0x704(0x04)
	int32_t SubsectionSizeQuads; // 0x708(0x04)
	int32_t NumSubsections; // 0x70c(0x04)
	char bUsedForNavigation : 1; // 0x710(0x01)
	char bFillCollisionUnderLandscapeForNavmesh : 1; // 0x710(0x01)
	char pad_710_2 : 6; // 0x710(0x01)
	char pad_711[0x3]; // 0x711(0x03)
	enum class ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x714(0x01)
	bool bUseDynamicMaterialInstance; // 0x715(0x01)
	bool bUseLandscapeForCullingInvisibleHLODVertices; // 0x716(0x01)
	bool bHasLayersContent; // 0x717(0x01)
	bool bUseCompressedHeightmapStorage; // 0x718(0x01)
	char pad_719[0x7]; // 0x719(0x07)

	void SetVirtualTextureRenderPassType(enum class ERuntimeVirtualTextureMainPassType InType); // Function Landscape.LandscapeProxy.SetVirtualTextureRenderPassType // (Final|Native|Public|BlueprintCallable) // @ game+0x24131b0
	void SetLandscapeMaterialVectorParameterValue(struct FName ParameterName, struct FLinearColor Value); // Function Landscape.LandscapeProxy.SetLandscapeMaterialVectorParameterValue // (Final|RequiredAPI|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x241ae90
	void SetLandscapeMaterialTextureParameterValue(struct FName ParameterName, struct UTexture* Value); // Function Landscape.LandscapeProxy.SetLandscapeMaterialTextureParameterValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x241d980
	void SetLandscapeMaterialScalarParameterValue(struct FName ParameterName, float Value); // Function Landscape.LandscapeProxy.SetLandscapeMaterialScalarParameterValue // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2419e30
	bool LandscapeExportHeightmapToRenderTarget(struct UTextureRenderTarget2D* InRenderTarget, bool InExportHeightIntoRGChannel, bool InExportLandscapeProxies); // Function Landscape.LandscapeProxy.LandscapeExportHeightmapToRenderTarget // (Final|Native|Public|BlueprintCallable) // @ game+0x242ec20
	struct ALandscape* GetLandscapeActor(); // Function Landscape.LandscapeProxy.GetLandscapeActor // (Native|Public|BlueprintCallable) // @ game+0x242f280
	void EditorSetLandscapeMaterial(struct UMaterialInterface* NewLandscapeMaterial); // Function Landscape.LandscapeProxy.EditorSetLandscapeMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x2424450
	void EditorApplySpline(struct USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, struct ULandscapeLayerInfoObject* PaintLayer, struct FName EditLayerName); // Function Landscape.LandscapeProxy.EditorApplySpline // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x241f3a0
	void ChangeLODDistanceFactor(float InLODDistanceFactor); // Function Landscape.LandscapeProxy.ChangeLODDistanceFactor // (Native|Public|BlueprintCallable) // @ game+0x2412c00
	void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections); // Function Landscape.LandscapeProxy.ChangeComponentScreenSizeToUseSubSections // (Native|Public|BlueprintCallable) // @ game+0x242be30
};

// Class Landscape.Landscape
// Size: 0x720 (Inherited: 0x720)
struct ALandscape : ALandscapeProxy {

	void RenderHeightmap(struct FTransform& InWorldTransform, struct FBox2D& InExtents, struct UTextureRenderTarget2D* OutRenderTarget); // Function Landscape.Landscape.RenderHeightmap // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x23d8680
};

// Class Landscape.LandscapeLODStreamingProxy_DEPRECATED
// Size: 0x140 (Inherited: 0x140)
struct ULandscapeLODStreamingProxy_DEPRECATED : UStreamableRenderAsset {
};

// Class Landscape.LandscapeComponent
// Size: 0x8f0 (Inherited: 0x6c0)
struct ULandscapeComponent : UPrimitiveComponent {
	int32_t SectionBaseX; // 0x6b8(0x04)
	int32_t SectionBaseY; // 0x6bc(0x04)
	int32_t ComponentSizeQuads; // 0x6c0(0x04)
	int32_t SubsectionSizeQuads; // 0x6c4(0x04)
	int32_t NumSubsections; // 0x6c8(0x04)
	struct UMaterialInterface* OverrideMaterial; // 0x6d0(0x08)
	struct UMaterialInterface* OverrideHoleMaterial; // 0x6d8(0x08)
	struct TArray<struct UMaterialInstanceConstant*> MaterialInstances; // 0x6e0(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> MaterialInstancesDynamic; // 0x6f0(0x10)
	struct TArray<int8_t> LODIndexToMaterialIndex; // 0x700(0x10)
	struct UTexture2D* XYOffsetmapTexture; // 0x710(0x08)
	char pad_71c[0x4]; // 0x71c(0x04)
	struct FVector4 WeightmapScaleBias; // 0x720(0x20)
	float WeightmapSubsectionOffset; // 0x740(0x04)
	char pad_744[0xc]; // 0x744(0x0c)
	struct FVector4 HeightmapScaleBias; // 0x750(0x20)
	struct FBox CachedLocalBox; // 0x770(0x38)
	struct ULandscapeHeightfieldCollisionComponent* CollisionComponentRef; // 0x7a8(0x08)
	bool bUserTriggeredChangeRequested; // 0x7b0(0x01)
	bool bNaniteActive; // 0x7b1(0x01)
	char pad_7b2[0x6]; // 0x7b2(0x06)
	struct UTexture2D* HeightmapTexture; // 0x7b8(0x08)
	struct TArray<struct FWeightmapLayerAllocationInfo> WeightmapLayerAllocations; // 0x7c0(0x10)
	struct TArray<struct UTexture2D*> WeightmapTextures; // 0x7d0(0x10)
	struct TArray<struct FLandscapePerLODMaterialOverride> PerLODOverrideMaterials; // 0x7e0(0x10)
	struct TArray<struct ULandscapeGrassType*> GrassTypes; // 0x7f0(0x10)
	float GrassTypesMaxDiscardDistance; // 0x800(0x04)
	struct FGuid MapBuildDataId; // 0x804(0x10)
	int32_t CollisionMipLevel; // 0x814(0x04)
	int32_t SimpleCollisionMipLevel; // 0x818(0x04)
	float NegativeZBoundsExtension; // 0x81c(0x04)
	float PositiveZBoundsExtension; // 0x820(0x04)
	float StaticLightingResolution; // 0x824(0x04)
	int32_t ForcedLOD; // 0x828(0x04)
	int32_t LODBias; // 0x82c(0x04)
	struct FGuid StateId; // 0x830(0x10)
	char pad_840[0x20]; // 0x840(0x20)
	struct UMaterialInterface* MobileMaterialInterface; // 0x860(0x08)
	struct TArray<struct UMaterialInterface*> MobileMaterialInterfaces; // 0x868(0x10)
	struct TArray<struct UTexture2D*> MobileWeightmapTextures; // 0x878(0x10)
	struct TArray<struct FWeightmapLayerAllocationInfo> MobileWeightmapLayerAllocations; // 0x888(0x10)
	char pad_898[0x58]; // 0x898(0x58)

	void SetLODBias(int32_t InLODBias); // Function Landscape.LandscapeComponent.SetLODBias // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x23d8cc0
	void SetForcedLOD(int32_t InForcedLOD); // Function Landscape.LandscapeComponent.SetForcedLOD // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x23d51a0
	struct UMaterialInstanceDynamic* GetMaterialInstanceDynamic(int32_t InIndex); // Function Landscape.LandscapeComponent.GetMaterialInstanceDynamic // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x23d8170
	float EditorGetPaintLayerWeightByNameAtLocation(struct FVector& InLocation, struct FName InPaintLayerName); // Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightByNameAtLocation // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x23d8070
	float EditorGetPaintLayerWeightAtLocation(struct FVector& InLocation, struct ULandscapeLayerInfoObject* PaintLayer); // Function Landscape.LandscapeComponent.EditorGetPaintLayerWeightAtLocation // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x23d56b0
};

// Class Landscape.LandscapeGizmoActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct ALandscapeGizmoActor : AActor {
};

// Class Landscape.LandscapeGizmoActiveActor
// Size: 0x3f0 (Inherited: 0x3a0)
struct ALandscapeGizmoActiveActor : ALandscapeGizmoActor {
	char pad_3a0[0x50]; // 0x3a0(0x50)
};

// Class Landscape.LandscapeGizmoRenderComponent
// Size: 0x6c0 (Inherited: 0x6c0)
struct ULandscapeGizmoRenderComponent : UPrimitiveComponent {
};

// Class Landscape.LandscapeGrassType
// Size: 0xd0 (Inherited: 0xa0)
struct ULandscapeGrassType : UObject {
	struct TArray<struct FGrassVariety> GrassVarieties; // 0x98(0x10)
	char bEnableDensityScaling : 1; // 0xa8(0x01)
	uint32_t StateHash; // 0xac(0x04)
	struct UStaticMesh* GrassMesh; // 0xb0(0x08)
	float GrassDensity; // 0xb8(0x04)
	float PlacementJitter; // 0xbc(0x04)
	int32_t StartCullDistance; // 0xc0(0x04)
	int32_t EndCullDistance; // 0xc4(0x04)
	bool RandomRotation; // 0xc8(0x01)
	bool AlignToSurface; // 0xc9(0x01)
	char pad_ce_1 : 7; // 0xce(0x01)
	char pad_cf[0x1]; // 0xcf(0x01)
};

// Class Landscape.LandscapeHeightfieldCollisionComponent
// Size: 0x7a0 (Inherited: 0x6c0)
struct ULandscapeHeightfieldCollisionComponent : UPrimitiveComponent {
	struct TArray<struct ULandscapeLayerInfoObject*> ComponentLayerInfos; // 0x6b8(0x10)
	int32_t SectionBaseX; // 0x6c8(0x04)
	int32_t SectionBaseY; // 0x6cc(0x04)
	int32_t CollisionSizeQuads; // 0x6d0(0x04)
	float CollisionScale; // 0x6d4(0x04)
	int32_t SimpleCollisionSizeQuads; // 0x6d8(0x04)
	struct TArray<char> CollisionQuadFlags; // 0x6e0(0x10)
	struct FGuid HeightfieldGuid; // 0x6f0(0x10)
	struct FBox CachedLocalBox; // 0x700(0x38)
	struct ULandscapeComponent* RenderComponentRef; // 0x738(0x08)
	char pad_744[0xc]; // 0x744(0x0c)
	struct TArray<struct UPhysicalMaterial*> CookedPhysicalMaterials; // 0x750(0x10)
	char pad_760[0x40]; // 0x760(0x40)

	struct ULandscapeComponent* GetRenderComponent(); // Function Landscape.LandscapeHeightfieldCollisionComponent.GetRenderComponent // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x23d9ef0
};

// Class Landscape.LandscapeLayerInfoObject
// Size: 0xc0 (Inherited: 0xa0)
struct ULandscapeLayerInfoObject : UObject {
	struct FName LayerName; // 0x98(0x08)
	struct UPhysicalMaterial* PhysMaterial; // 0xa0(0x08)
	float Hardness; // 0xa8(0x04)
	struct FLinearColor LayerUsageDebugColor; // 0xac(0x10)
};

// Class Landscape.LandscapeMaterialInstanceConstant
// Size: 0x2d0 (Inherited: 0x2c0)
struct ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant {
	struct TArray<struct FLandscapeMaterialTextureStreamingInfo> TextureStreamingInfo; // 0x2b8(0x10)
	char bIsLayerThumbnail : 1; // 0x2c8(0x01)
	char bDisableTessellation : 1; // 0x2c8(0x01)
	char bMobile : 1; // 0x2c8(0x01)
	char bEditorToolUsage : 1; // 0x2c8(0x01)
};

// Class Landscape.LandscapeMeshCollisionComponent
// Size: 0x7c0 (Inherited: 0x7a0)
struct ULandscapeMeshCollisionComponent : ULandscapeHeightfieldCollisionComponent {
	struct FGuid MeshGuid; // 0x7a0(0x10)
	char pad_7b0[0x10]; // 0x7b0(0x10)
};

// Class Landscape.LandscapeMeshProxyActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct ALandscapeMeshProxyActor : AActor {
	struct ULandscapeMeshProxyComponent* LandscapeMeshProxyComponent; // 0x398(0x08)
};

// Class Landscape.LandscapeMeshProxyComponent
// Size: 0x800 (Inherited: 0x790)
struct ULandscapeMeshProxyComponent : UStaticMeshComponent {
	struct FGuid LandscapeGuid; // 0x788(0x10)
	struct TArray<struct FIntPoint> ProxyComponentBases; // 0x798(0x10)
	struct TArray<struct FVector> ProxyComponentCentersObjectSpace; // 0x7a8(0x10)
	struct FVector ComponentXVectorObjectSpace; // 0x7b8(0x18)
	struct FVector ComponentYVectorObjectSpace; // 0x7d0(0x18)
	int32_t ComponentResolution; // 0x7e8(0x04)
	int8_t ProxyLOD; // 0x7ec(0x01)
	uint32_t LODGroupKey; // 0x7f0(0x04)
	char pad_7f9[0x7]; // 0x7f9(0x07)
};

// Class Landscape.LandscapeSettings
// Size: 0x120 (Inherited: 0xb0)
struct ULandscapeSettings : UDeveloperSettings {
	int32_t MaxNumberOfLayers; // 0xa8(0x04)
	int32_t MaxComponents; // 0xac(0x04)
	uint32_t MaxImageImportCacheSizeMegaBytes; // 0xb0(0x04)
	float PaintStrengthGamma; // 0xb4(0x04)
	bool bDisablePaintingStartupSlowdown; // 0xb8(0x01)
	enum class ELandscapeDirtyingMode LandscapeDirtyingMode; // 0xb9(0x01)
	int32_t SideResolutionLimit; // 0xbc(0x04)
	struct TSoftObjectPtr<UMaterialInterface> DefaultLandscapeMaterial; // 0xc0(0x28)
	struct TSoftObjectPtr<ULandscapeLayerInfoObject> DefaultLayerInfoObject; // 0xe8(0x28)
	bool bRestrictiveMode; // 0x110(0x01)
	char pad_117[0x9]; // 0x117(0x09)
};

// Class Landscape.LandscapeSplinesComponent
// Size: 0x6f0 (Inherited: 0x6c0)
struct ULandscapeSplinesComponent : UPrimitiveComponent {
	struct TArray<struct ULandscapeSplineControlPoint*> ControlPoints; // 0x6b8(0x10)
	struct TArray<struct ULandscapeSplineSegment*> Segments; // 0x6c8(0x10)
	struct TArray<struct UMeshComponent*> CookedForeignMeshComponents; // 0x6d8(0x10)

	struct TArray<struct USplineMeshComponent*> GetSplineMeshComponents(); // Function Landscape.LandscapeSplinesComponent.GetSplineMeshComponents // (Final|Native|Public|BlueprintCallable) // @ game+0x23da620
};

// Class Landscape.LandscapeSplineControlPoint
// Size: 0x150 (Inherited: 0xa0)
struct ULandscapeSplineControlPoint : UObject {
	struct FVector Location; // 0x98(0x18)
	struct FRotator Rotation; // 0xb0(0x18)
	float Width; // 0xc8(0x04)
	float LayerWidthRatio; // 0xcc(0x04)
	float SideFalloff; // 0xd0(0x04)
	float LeftSideFalloffFactor; // 0xd4(0x04)
	float RightSideFalloffFactor; // 0xd8(0x04)
	float LeftSideLayerFalloffFactor; // 0xdc(0x04)
	float RightSideLayerFalloffFactor; // 0xe0(0x04)
	float EndFalloff; // 0xe4(0x04)
	struct TArray<struct FLandscapeSplineConnection> ConnectedSegments; // 0xe8(0x10)
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // 0xf8(0x10)
	struct FBox Bounds; // 0x108(0x38)
	struct UControlPointMeshComponent* LocalMeshComponent; // 0x140(0x08)
};

// Class Landscape.LandscapeSplineSegment
// Size: 0x140 (Inherited: 0xa0)
struct ULandscapeSplineSegment : UObject {
	struct FLandscapeSplineSegmentConnection Connections[0x2]; // 0x98(0x30)
	struct FInterpCurveVector SplineInfo; // 0xc8(0x18)
	struct TArray<struct FLandscapeSplineInterpPoint> Points; // 0xe0(0x10)
	struct FBox Bounds; // 0xf0(0x38)
	struct TArray<struct USplineMeshComponent*> LocalMeshComponents; // 0x128(0x10)
};

// Class Landscape.LandscapeStreamingProxy
// Size: 0x7a0 (Inherited: 0x720)
struct ALandscapeStreamingProxy : ALandscapeProxy {
	struct TSoftObjectPtr<ALandscape> LandscapeActorRef; // 0x720(0x28)
	struct TSet<struct FString> OverriddenSharedProperties; // 0x748(0x50)
	char pad_798[0x8]; // 0x798(0x08)
};

// Class Landscape.LandscapeWeightmapUsage
// Size: 0xd0 (Inherited: 0xa0)
struct ULandscapeWeightmapUsage : UObject {
	struct ULandscapeComponent* ChannelUsage[0x4]; // 0x98(0x20)
	struct FGuid LayerGuid; // 0xb8(0x10)
};

// Class Landscape.MaterialExpressionLandscapeGrassOutput
// Size: 0x130 (Inherited: 0x120)
struct UMaterialExpressionLandscapeGrassOutput : UMaterialExpressionCustomOutput {
	struct TArray<struct FGrassInput> GrassTypes; // 0x120(0x10)
};

// Class Landscape.MaterialExpressionLandscapeLayerBlend
// Size: 0x130 (Inherited: 0x120)
struct UMaterialExpressionLandscapeLayerBlend : UMaterialExpression {
	struct TArray<struct FLayerBlendInput> Layers; // 0x120(0x10)
};

// Class Landscape.MaterialExpressionLandscapeLayerCoords
// Size: 0x140 (Inherited: 0x120)
struct UMaterialExpressionLandscapeLayerCoords : UMaterialExpression {
	enum class ETerrainCoordMappingType MappingType; // 0x120(0x01)
	enum class ELandscapeCustomizedCoordType CustomUVType; // 0x121(0x01)
	char pad_122[0x2]; // 0x122(0x02)
	float MappingScale; // 0x124(0x04)
	float MappingRotation; // 0x128(0x04)
	float MappingPanU; // 0x12c(0x04)
	float MappingPanV; // 0x130(0x04)
	char pad_134[0xc]; // 0x134(0x0c)
};

// Class Landscape.ControlPointMeshActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AControlPointMeshActor : AActor {
	struct UControlPointMeshComponent* ControlPointMeshComponent; // 0x398(0x08)
};

// Class Landscape.LandscapeBlueprintBrushBase
// Size: 0x3a0 (Inherited: 0x3a0)
struct ALandscapeBlueprintBrushBase : AActor {

	void RequestLandscapeUpdate(bool bInUserTriggered); // Function Landscape.LandscapeBlueprintBrushBase.RequestLandscapeUpdate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x23e9250
	struct UTextureRenderTarget2D* RenderLayer(struct FLandscapeBrushParameters& InParameters); // Function Landscape.LandscapeBlueprintBrushBase.RenderLayer // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x23ef640
	struct UTextureRenderTarget2D* Render(bool InIsHeightmap, struct UTextureRenderTarget2D* InCombinedResult, struct FName& InWeightmapLayerName); // Function Landscape.LandscapeBlueprintBrushBase.Render // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x23ebfd0
	void Initialize(struct FTransform& InLandscapeTransform, struct FIntPoint& InLandscapeSize, struct FIntPoint& InLandscapeRenderTargetSize); // Function Landscape.LandscapeBlueprintBrushBase.Initialize // (RequiredAPI|Native|Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x23e9af0
	void GetBlueprintRenderDependencies(struct TArray<struct UObject*>& OutStreamableAssets); // Function Landscape.LandscapeBlueprintBrushBase.GetBlueprintRenderDependencies // (RequiredAPI|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class Landscape.LandscapeHLODBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct ULandscapeHLODBuilder : UHLODBuilder {
};

// Class Landscape.LandscapeInfo
// Size: 0x280 (Inherited: 0xa0)
struct ULandscapeInfo : UObject {
	struct TWeakObjectPtr<struct ALandscape> LandscapeActor; // 0x98(0x08)
	struct FGuid LandscapeGuid; // 0xa0(0x10)
	int32_t ComponentSizeQuads; // 0xb0(0x04)
	int32_t SubsectionSizeQuads; // 0xb4(0x04)
	int32_t ComponentNumSubsections; // 0xb8(0x04)
	char pad_c4[0xac]; // 0xc4(0xac)
	struct TArray<struct TWeakObjectPtr<struct ALandscapeStreamingProxy>> StreamingProxies; // 0x170(0x10)
	char pad_180[0x100]; // 0x180(0x100)
};

// Class Landscape.LandscapeInfoMap
// Size: 0xf0 (Inherited: 0xa0)
struct ULandscapeInfoMap : UObject {
	char pad_a0[0x50]; // 0xa0(0x50)
};

// Class Landscape.LandscapeNaniteComponent
// Size: 0x7a0 (Inherited: 0x790)
struct ULandscapeNaniteComponent : UStaticMeshComponent {
	struct FGuid ProxyContentId; // 0x788(0x10)
	bool bEnabled; // 0x798(0x01)
};

// Class Landscape.LandscapeSplineActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ALandscapeSplineActor : AActor {
	struct FGuid LandscapeGuid; // 0x3a0(0x10)
};

// Class Landscape.LandscapeSplineMeshesActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct ALandscapeSplineMeshesActor : APartitionActor {
	struct TArray<struct UStaticMeshComponent*> StaticMeshComponents; // 0x398(0x10)
};

// Class Landscape.LandscapeSubsystem
// Size: 0xd0 (Inherited: 0xb0)
struct ULandscapeSubsystem : UTickableWorldSubsystem {
	char pad_b0[0x20]; // 0xb0(0x20)
};

// Class Landscape.LandscapeTextureStorageProviderFactory
// Size: 0xd0 (Inherited: 0xa0)
struct ULandscapeTextureStorageProviderFactory : UTextureAllMipDataProviderFactory {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class Landscape.MaterialExpressionLandscapeLayerSample
// Size: 0x130 (Inherited: 0x120)
struct UMaterialExpressionLandscapeLayerSample : UMaterialExpression {
	struct FName ParameterName; // 0x120(0x08)
	float PreviewWeight; // 0x128(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)
};

// Class Landscape.MaterialExpressionLandscapeLayerSwitch
// Size: 0x180 (Inherited: 0x120)
struct UMaterialExpressionLandscapeLayerSwitch : UMaterialExpression {
	struct FExpressionInput LayerUsed; // 0x120(0x28)
	struct FExpressionInput LayerNotUsed; // 0x148(0x28)
	struct FName ParameterName; // 0x170(0x08)
	char PreviewUsed : 1; // 0x178(0x01)
	char pad_178_1 : 7; // 0x178(0x01)
	char pad_179[0x7]; // 0x179(0x07)
};

// Class Landscape.MaterialExpressionLandscapeLayerWeight
// Size: 0x1a0 (Inherited: 0x120)
struct UMaterialExpressionLandscapeLayerWeight : UMaterialExpression {
	struct FExpressionInput base; // 0x120(0x28)
	struct FExpressionInput Layer; // 0x148(0x28)
	struct FName ParameterName; // 0x170(0x08)
	float PreviewWeight; // 0x178(0x04)
	char pad_17c[0x4]; // 0x17c(0x04)
	struct FVector ConstBase; // 0x180(0x18)
	char pad_198[0x8]; // 0x198(0x08)
};

// Class Landscape.MaterialExpressionLandscapePhysicalMaterialOutput
// Size: 0x130 (Inherited: 0x120)
struct UMaterialExpressionLandscapePhysicalMaterialOutput : UMaterialExpressionCustomOutput {
	struct TArray<struct FPhysicalMaterialInput> Inputs; // 0x120(0x10)
};

// Class Landscape.MaterialExpressionLandscapeVisibilityMask
// Size: 0x120 (Inherited: 0x120)
struct UMaterialExpressionLandscapeVisibilityMask : UMaterialExpression {
};

