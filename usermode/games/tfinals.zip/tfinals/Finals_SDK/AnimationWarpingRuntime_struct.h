// Enum AnimationWarpingRuntime.EFootPlacementLockType
enum class EFootPlacementLockType : uint8_t {
	Unlocked = 0,
	PivotAroundBall = 1,
	PivotAroundAnkle = 2,
	LockRotation = 3,
	EFootPlacementLockType_MAX = 4
};

// Enum AnimationWarpingRuntime.EPelvisHeightMode
enum class EPelvisHeightMode : uint8_t {
	AllLegs = 0,
	AllPlantedFeet = 1,
	FrontPlantedFeetUphill_FrontFeetDownhill = 2,
	EPelvisHeightMode_MAX = 3
};

// Enum AnimationWarpingRuntime.EActorMovementCompensationMode
enum class EActorMovementCompensationMode : uint8_t {
	ComponentSpace = 0,
	WorldSpace = 1,
	SuddenMotionOnly = 2,
	EActorMovementCompensationMode_MAX = 3
};

// Enum AnimationWarpingRuntime.EOffsetRootBoneMode
enum class EOffsetRootBoneMode : uint8_t {
	Accumulate = 0,
	Interpolate = 1,
	Hold = 2,
	Release = 3,
	EOffsetRootBoneMode_MAX = 4
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementInterpolationSettings
// Size: 0x24 (Inherited: 0x00)
struct FFootPlacementInterpolationSettings {
	float UnplantLinearStiffness; // 0x00(0x04)
	float UnplantLinearDamping; // 0x04(0x04)
	float UnplantAngularStiffness; // 0x08(0x04)
	float UnplantAngularDamping; // 0x0c(0x04)
	float FloorLinearStiffness; // 0x10(0x04)
	float FloorLinearDamping; // 0x14(0x04)
	float FloorAngularStiffness; // 0x18(0x04)
	float FloorAngularDamping; // 0x1c(0x04)
	bool bEnableFloorInterpolation; // 0x20(0x01)
	char pad_21[0x3]; // 0x21(0x03)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementTraceSettings
// Size: 0x1c (Inherited: 0x00)
struct FFootPlacementTraceSettings {
	float StartOffset; // 0x00(0x04)
	float EndOffset; // 0x04(0x04)
	float SweepRadius; // 0x08(0x04)
	enum class ETraceTypeQuery ComplexTraceChannel; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	float MaxGroundPenetration; // 0x10(0x04)
	float SimpleCollisionInfluence; // 0x14(0x04)
	enum class ETraceTypeQuery SimpleTraceChannel; // 0x18(0x01)
	bool bEnabled; // 0x19(0x01)
	char pad_1a[0x2]; // 0x1a(0x02)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementRootDefinition
// Size: 0x20 (Inherited: 0x00)
struct FFootPlacementRootDefinition {
	struct FBoneReference PelvisBone; // 0x00(0x10)
	struct FBoneReference IKRootBone; // 0x10(0x10)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementPelvisSettings
// Size: 0x1c (Inherited: 0x00)
struct FFootPlacementPelvisSettings {
	float MaxOffset; // 0x00(0x04)
	float LinearStiffness; // 0x04(0x04)
	float LinearDamping; // 0x08(0x04)
	float HorizontalRebalancingWeight; // 0x0c(0x04)
	float MaxOffsetHorizontal; // 0x10(0x04)
	float HeelLiftRatio; // 0x14(0x04)
	enum class EPelvisHeightMode PelvisHeightMode; // 0x18(0x01)
	enum class EActorMovementCompensationMode ActorMovementCompensationMode; // 0x19(0x01)
	bool bEnableInterpolation; // 0x1a(0x01)
	char pad_1b[0x1]; // 0x1b(0x01)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacemenLegDefinition
// Size: 0x44 (Inherited: 0x00)
struct FFootPlacemenLegDefinition {
	struct FBoneReference FKFootBone; // 0x00(0x10)
	struct FBoneReference IKFootBone; // 0x10(0x10)
	struct FBoneReference BallBone; // 0x20(0x10)
	int32_t NumBonesInLimb; // 0x30(0x04)
	struct FName SpeedCurveName; // 0x34(0x08)
	struct FName DisableLockCurveName; // 0x3c(0x08)
};

// ScriptStruct AnimationWarpingRuntime.FootPlacementPlantSettings
// Size: 0x34 (Inherited: 0x00)
struct FFootPlacementPlantSettings {
	float SpeedThreshold; // 0x00(0x04)
	float DistanceToGround; // 0x04(0x04)
	enum class EFootPlacementLockType LockType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float UnplantRadius; // 0x0c(0x04)
	float ReplantRadiusRatio; // 0x10(0x04)
	float UnplantAngle; // 0x14(0x04)
	float ReplantAngleRatio; // 0x18(0x04)
	float MaxExtensionRatio; // 0x1c(0x04)
	float MinExtensionRatio; // 0x20(0x04)
	float SeparatingDistance; // 0x24(0x04)
	float UnalignmentSpeedThreshold; // 0x28(0x04)
	float AnkleTwistReduction; // 0x2c(0x04)
	bool bAdjustHeelBeforePlanting; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_FootPlacement
// Size: 0x440 (Inherited: 0x100)
struct FAnimNode_FootPlacement : FAnimNode_SkeletalControlBase {
	enum class EWarpingEvaluationMode PlantSpeedMode; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	struct FBoneReference IKFootRootBone; // 0x104(0x10)
	struct FBoneReference PelvisBone; // 0x114(0x10)
	struct FFootPlacementPelvisSettings PelvisSettings; // 0x124(0x1c)
	struct TArray<struct FFootPlacemenLegDefinition> LegDefinitions; // 0x140(0x10)
	struct FFootPlacementPlantSettings PlantSettings; // 0x150(0x34)
	struct FFootPlacementInterpolationSettings InterpolationSettings; // 0x184(0x24)
	struct FFootPlacementTraceSettings TraceSettings; // 0x1a8(0x1c)
	char pad_1c4[0x27c]; // 0x1c4(0x27c)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_OffsetRootBone
// Size: 0x1c0 (Inherited: 0x100)
struct FAnimNode_OffsetRootBone : FAnimNode_SkeletalControlBase {
	char pad_100[0xc0]; // 0x100(0xc0)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_OrientationWarping
// Size: 0x1d0 (Inherited: 0x100)
struct FAnimNode_OrientationWarping : FAnimNode_SkeletalControlBase {
	enum class EWarpingEvaluationMode Mode; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	float OrientationAngle; // 0x104(0x04)
	float LocomotionAngle; // 0x108(0x04)
	float MinRootMotionSpeedThreshold; // 0x10c(0x04)
	float LocomotionAngleDeltaThreshold; // 0x110(0x04)
	char pad_114[0x4]; // 0x114(0x04)
	struct TArray<struct FBoneReference> SpineBones; // 0x118(0x10)
	struct FBoneReference IKFootRootBone; // 0x128(0x10)
	struct TArray<struct FBoneReference> IKFootBones; // 0x138(0x10)
	enum class EAxis RotationAxis; // 0x148(0x01)
	char pad_149[0x3]; // 0x149(0x03)
	float DistributedBoneOrientationAlpha; // 0x14c(0x04)
	float RotationInterpSpeed; // 0x150(0x04)
	float WarpingAlpha; // 0x154(0x04)
	float OffsetAlpha; // 0x158(0x04)
	float MaxOffsetAngle; // 0x15c(0x04)
	char pad_160[0x70]; // 0x160(0x70)
};

// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootDefinition
// Size: 0x28 (Inherited: 0x00)
struct FSlopeWarpingFootDefinition {
	struct FBoneReference IKFootBone; // 0x00(0x10)
	struct FBoneReference FKFootBone; // 0x10(0x10)
	int32_t NumBonesInLimb; // 0x20(0x04)
	float FootSize; // 0x24(0x04)
};

// ScriptStruct AnimationWarpingRuntime.SlopeWarpingFootData
// Size: 0xb0 (Inherited: 0x00)
struct FSlopeWarpingFootData {
	char pad_0[0xb0]; // 0x00(0xb0)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_SlopeWarping
// Size: 0x318 (Inherited: 0x100)
struct FAnimNode_SlopeWarping : FAnimNode_SkeletalControlBase {
	char pad_100[0x18]; // 0x100(0x18)
	struct FBoneReference IKFootRootBone; // 0x118(0x10)
	struct FBoneReference PelvisBone; // 0x128(0x10)
	struct TArray<struct FSlopeWarpingFootDefinition> FeetDefinitions; // 0x138(0x10)
	struct TArray<struct FSlopeWarpingFootData> FeetData; // 0x148(0x10)
	struct FVectorRK4SpringInterpolator PelvisOffsetInterpolator; // 0x158(0x08)
	char pad_160[0x58]; // 0x160(0x58)
	struct FVector GravityDir; // 0x1b8(0x18)
	struct FVector CustomFloorOffset; // 0x1d0(0x18)
	float CachedDeltaTime; // 0x1e8(0x04)
	char pad_1ec[0x4]; // 0x1ec(0x04)
	struct FVector TargetFloorNormalWorldSpace; // 0x1f0(0x18)
	struct FVectorRK4SpringInterpolator FloorNormalInterpolator; // 0x208(0x08)
	char pad_210[0x58]; // 0x210(0x58)
	struct FVector TargetFloorOffsetLocalSpace; // 0x268(0x18)
	struct FVectorRK4SpringInterpolator FloorOffsetInterpolator; // 0x280(0x08)
	char pad_288[0x58]; // 0x288(0x58)
	float MaxStepHeight; // 0x2e0(0x04)
	char bKeepMeshInsideOfCapsule : 1; // 0x2e4(0x01)
	char bPullPelvisDown : 1; // 0x2e4(0x01)
	char bUseCustomFloorOffset : 1; // 0x2e4(0x01)
	char bWasOnGround : 1; // 0x2e4(0x01)
	char bShowDebug : 1; // 0x2e4(0x01)
	char bFloorSmoothingInitialized : 1; // 0x2e4(0x01)
	char pad_2e4_6 : 2; // 0x2e4(0x01)
	char pad_2e5[0x3]; // 0x2e5(0x03)
	struct FVector ActorLocation; // 0x2e8(0x18)
	struct FVector GravityDirCompSpace; // 0x300(0x18)
};

// ScriptStruct AnimationWarpingRuntime.StrideWarpingFootDefinition
// Size: 0x30 (Inherited: 0x00)
struct FStrideWarpingFootDefinition {
	struct FBoneReference IKFootBone; // 0x00(0x10)
	struct FBoneReference FKFootBone; // 0x10(0x10)
	struct FBoneReference ThighBone; // 0x20(0x10)
};

// ScriptStruct AnimationWarpingRuntime.AnimNode_StrideWarping
// Size: 0x280 (Inherited: 0x100)
struct FAnimNode_StrideWarping : FAnimNode_SkeletalControlBase {
	enum class EWarpingEvaluationMode Mode; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FVector StrideDirection; // 0x108(0x18)
	float StrideScale; // 0x120(0x04)
	float LocomotionSpeed; // 0x124(0x04)
	float MinRootMotionSpeedThreshold; // 0x128(0x04)
	struct FBoneReference PelvisBone; // 0x12c(0x10)
	struct FBoneReference IKFootRootBone; // 0x13c(0x10)
	char pad_14c[0x4]; // 0x14c(0x04)
	struct TArray<struct FStrideWarpingFootDefinition> FootDefinitions; // 0x150(0x10)
	struct FInputClampConstants StrideScaleModifier; // 0x160(0x14)
	char pad_174[0x4]; // 0x174(0x04)
	struct FWarpingVectorValue FloorNormalDirection; // 0x178(0x20)
	struct FWarpingVectorValue GravityDirection; // 0x198(0x20)
	struct FIKFootPelvisPullDownSolver PelvisIKFootSolver; // 0x1b8(0x80)
	bool bOrientStrideDirectionUsingFloorNormal; // 0x238(0x01)
	bool bCompensateIKUsingFKThighRotation; // 0x239(0x01)
	bool bClampIKUsingFKLimits; // 0x23a(0x01)
	char pad_23b[0x45]; // 0x23b(0x45)
};

