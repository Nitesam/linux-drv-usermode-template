// Enum PendulumRuntime.EGroundTraceDistance
enum class EGroundTraceDistance : uint8_t {
	Short = 0,
	Medium = 1,
	Long = 2,
	EGroundTraceDistance_MAX = 3
};

// Enum PendulumRuntime.EPioneerMovementState
enum class EPioneerMovementState : uint8_t {
	PioMove_Running = 0,
	PioMove_Walking = 1,
	PioMove_Tumbling = 2,
	PioMove_Immobilized = 3,
	PioMove_DBNO = 4,
	PioMove_Sliding = 5,
	PioMove_DodgeRolling = 6,
	PioMove_MAX = 7
};

// Enum PendulumRuntime.ETeleportBackReason
enum class ETeleportBackReason : uint8_t {
	TeleportBackReason_FallThroughGround = 0,
	TeleportBackReason_Stuck = 1,
	TeleportBackReason_MAX = 2
};

// Enum PendulumRuntime.EGroundTraceDistanceType
enum class EGroundTraceDistanceType : uint8_t {
	Short = 0,
	Medium = 1,
	Long = 2,
	EGroundTraceDistanceType_MAX = 3
};

// Enum PendulumRuntime.LogicDynamicStateBoolIndices
enum class LogicDynamicStateBoolIndices : uint8_t {
	Count = 0,
	LogicDynamicStateBoolIndices_MAX = 1
};

// Enum PendulumRuntime.LogicTransientStateBoolIndices
enum class LogicTransientStateBoolIndices : uint8_t {
	DisableHipSpring = 0,
	DisableVelocityIntegration = 1,
	BeginBranch = 2,
	EndBranch = 3,
	EarlyBranch = 4,
	Looped = 5,
	InputHasValidInteraction = 6,
	DisableSteepSlopeTraversal = 7,
	AllowUpwardsBounces = 8,
	VelocityCompensateSpring = 9,
	Count = 10,
	LogicTransientStateBoolIndices_MAX = 11
};

// Enum PendulumRuntime.BlendedResultVectorIndices
enum class BlendedResultVectorIndices : uint8_t {
	Velocity = 0,
	Acceleration = 1,
	Count = 2,
	BlendedResultVectorIndices_MAX = 3
};

// Enum PendulumRuntime.BlendedResultQuatIndices
enum class BlendedResultQuatIndices : uint8_t {
	DeltaRotation = 0,
	Count = 1,
	BlendedResultQuatIndices_MAX = 2
};

// Enum PendulumRuntime.PendulumSetEveryFrameMode
enum class PendulumSetEveryFrameMode : uint8_t {
	Disabled = 0,
	SetToTrue = 1,
	SetToFalse = 2,
	PendulumSetEveryFrameMode_MAX = 3
};

// ScriptStruct PendulumRuntime.AnimNode_PendulumPoseEval
// Size: 0xd0 (Inherited: 0x48)
struct FAnimNode_PendulumPoseEval : FAnimNode_Base {
	struct FPendulumAnimationUpdateContext Input; // 0x48(0x50)
	char pad_98[0x38]; // 0x98(0x38)
};

// ScriptStruct PendulumRuntime.PendulumAnimationUpdateContext
// Size: 0x50 (Inherited: 0x00)
struct FPendulumAnimationUpdateContext {
	char pad_0[0x20]; // 0x00(0x20)
	struct APlayerController* PlayerController; // 0x20(0x08)
	struct APawn* Pawn; // 0x28(0x08)
	float EngineDt; // 0x30(0x04)
	bool IsServer; // 0x34(0x01)
	bool IsResimulation; // 0x35(0x01)
	char pad_36[0x1a]; // 0x36(0x1a)
};

// ScriptStruct PendulumRuntime.MovementParameterModifications
// Size: 0x40 (Inherited: 0x00)
struct FMovementParameterModifications {
	float GroundFriction; // 0x00(0x04)
	float BrakingDeceleration; // 0x04(0x04)
	float MaxWalkSpeed; // 0x08(0x04)
	float MaxAcceleration; // 0x0c(0x04)
	struct FVector ModifiedInputVec; // 0x10(0x18)
	struct FRotator ControlRotation; // 0x28(0x18)
};

// ScriptStruct PendulumRuntime.GroundTraceDistances
// Size: 0x0c (Inherited: 0x00)
struct FGroundTraceDistances {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct PendulumRuntime.CharacterBodyProperties
// Size: 0x08 (Inherited: 0x00)
struct FCharacterBodyProperties {
	float Stamina; // 0x00(0x04)
	bool bSprinting; // 0x04(0x01)
	bool bCrouching; // 0x05(0x01)
	enum class EPioneerMovementState MovementMode; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
};

// ScriptStruct PendulumRuntime.PendulumStateInput
// Size: 0x38 (Inherited: 0x00)
struct FPendulumStateInput {
	struct FVector GroundNormal; // 0x00(0x18)
	float GravityZ; // 0x18(0x04)
	float DATA_CapsuleHalfHeightCrouching; // 0x1c(0x04)
	float DATA_CapsuleHalfHeightStanding; // 0x20(0x04)
	float DATA_CapsuleRadius; // 0x24(0x04)
	float CurrentCapsuleHH; // 0x28(0x04)
	struct FGroundTraceDistances GroundTraceDistances; // 0x2c(0x0c)
};

// ScriptStruct PendulumRuntime.PendulumStateOutput
// Size: 0x01 (Inherited: 0x00)
struct FPendulumStateOutput {
	enum class EGroundSuspensionMode GroundSuspensionMode; // 0x00(0x01)
};

// ScriptStruct PendulumRuntime.FallThroughGroundInfo
// Size: 0x58 (Inherited: 0x00)
struct FFallThroughGroundInfo {
	struct FVector NewestGroundedPosition; // 0x00(0x18)
	struct FVector OldestGroundedPosition; // 0x18(0x18)
	struct FVector FallLocation; // 0x30(0x18)
	int32_t LastStoredGroundedPositionTimeStamp; // 0x48(0x04)
	int32_t AttemptTeleportNr; // 0x4c(0x04)
	enum class ETeleportBackReason TeleportBackReason; // 0x50(0x01)
	char StuckCounter; // 0x51(0x01)
	char InputsPressed; // 0x52(0x01)
	bool bIsStuck; // 0x53(0x01)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct PendulumRuntime.StateMachineTempState
// Size: 0x08 (Inherited: 0x00)
struct FStateMachineTempState {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct PendulumRuntime.PendulumMovementStateMachineNodeTempState
// Size: 0x240 (Inherited: 0x08)
struct FPendulumMovementStateMachineNodeTempState : FStateMachineTempState {
	struct FPendulumStateInput SMInput; // 0x08(0x38)
	struct FPendulumStateOutput SMOutput; // 0x40(0x01)
	char pad_41[0xf]; // 0x41(0x0f)
	struct FVector Location; // 0x50(0x18)
	char pad_68[0x8]; // 0x68(0x08)
	struct FQuat Rotation; // 0x70(0x20)
	struct FVector Velocity; // 0x90(0x18)
	struct FVector GroundVelocity; // 0xa8(0x18)
	struct FVector ImpactVelocity; // 0xc0(0x18)
	enum class EGroundTraceDistanceType GroundTraceDistanceType; // 0xd8(0x01)
	char pad_d9[0x3]; // 0xd9(0x03)
	float Stamina; // 0xdc(0x04)
	bool bIsInCrouch; // 0xe0(0x01)
	bool bCollidedWithBottomOfPill; // 0xe1(0x01)
	bool bCollided; // 0xe2(0x01)
	bool bCollidedAboveStepHeight; // 0xe3(0x01)
	bool bIsFeetUnderTerrain; // 0xe4(0x01)
	bool bIsFloorWalkable; // 0xe5(0x01)
	char pad_e6[0x2]; // 0xe6(0x02)
	float DistanceToGround; // 0xe8(0x04)
	enum class EMovementMode RoughMovementMode; // 0xec(0x01)
	char CharacterStance; // 0xed(0x01)
	char LocoMode; // 0xee(0x01)
	char pad_ef[0x1]; // 0xef(0x01)
	struct UPrimitiveComponent* PlatformComponent; // 0xf0(0x08)
	int32_t PlatformPartID; // 0xf8(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)
	struct FHitResult MostRelevantGroundHitResult; // 0x100(0xe8)
	struct FFallThroughGroundInfo FallThroughGroundState; // 0x1e8(0x58)
};

// ScriptStruct PendulumRuntime.PendulumLogicResult
// Size: 0x60 (Inherited: 0x00)
struct FPendulumLogicResult {
	struct FPendulumBoolArray TransientStates; // 0x00(0x20)
	struct FPendulumBoolArray DynamicStates; // 0x20(0x20)
	struct FPendulumBoolArray DynamicStateResetsOnBlendOut; // 0x40(0x20)
};

// ScriptStruct PendulumRuntime.PendulumBoolArray
// Size: 0x20 (Inherited: 0x00)
struct FPendulumBoolArray {
	uint64_t DirtyBits[0x2]; // 0x00(0x10)
	uint64_t Bits[0x2]; // 0x10(0x10)
};

// ScriptStruct PendulumRuntime.PendulumInputs
// Size: 0x08 (Inherited: 0x00)
struct FPendulumInputs {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct PendulumRuntime.BlendedTreeUpdateResult
// Size: 0xb0 (Inherited: 0x00)
struct FBlendedTreeUpdateResult {
	char pad_0[0xb0]; // 0x00(0xb0)
};

// ScriptStruct PendulumRuntime.SimUpdateInput
// Size: 0x58 (Inherited: 0x00)
struct FSimUpdateInput {
	float EngineDt; // 0x00(0x04)
	int32_t StartT; // 0x04(0x04)
	int32_t EndT; // 0x08(0x04)
	char pad_c[0x44]; // 0x0c(0x44)
	bool IsBlendingOut; // 0x50(0x01)
	char pad_51[0x7]; // 0x51(0x07)
};

// ScriptStruct PendulumRuntime.SimUpdateResult
// Size: 0x130 (Inherited: 0x00)
struct FSimUpdateResult {
	char pad_0[0x10]; // 0x00(0x10)
	struct FBlendedTreeUpdateResult BlendedResult; // 0x10(0xb0)
	struct FPendulumLogicResult LogicResult; // 0xc0(0x60)
	char pad_120[0x10]; // 0x120(0x10)
};

// ScriptStruct PendulumRuntime.AnimEvaluateResult
// Size: 0x10 (Inherited: 0x00)
struct FAnimEvaluateResult {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct PendulumRuntime.AnimUpdateInput
// Size: 0x10 (Inherited: 0x00)
struct FAnimUpdateInput {
	float EngineDt; // 0x00(0x04)
	int32_t StartT; // 0x04(0x04)
	int32_t EndT; // 0x08(0x04)
	bool IsBlendingOut; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
};

// ScriptStruct PendulumRuntime.CurveInfo
// Size: 0x18 (Inherited: 0x00)
struct FCurveInfo {
	bool bHasCurveData; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName AnimName; // 0x04(0x08)
	char PendulumIndex; // 0x0c(0x01)
	char pad_d[0x3]; // 0x0d(0x03)
	float MaxSampleVal; // 0x10(0x04)
	float MinSampleVal; // 0x14(0x04)
};

// ScriptStruct PendulumRuntime.ClipCurvesInfo
// Size: 0x90 (Inherited: 0x00)
struct FClipCurvesInfo {
	struct FCurveInfo CurveInfos[0x6]; // 0x00(0x90)
};

// ScriptStruct PendulumRuntime.StatelessClipUpdateContext
// Size: 0x100 (Inherited: 0x00)
struct FStatelessClipUpdateContext {
	int32_t TickOffset; // 0x00(0x04)
	char pad_4[0xc]; // 0x04(0x0c)
	struct FTransform WarpTarget; // 0x10(0x60)
	struct FTransform CurrentTransform; // 0x70(0x60)
	float CurrentCapsuleHH; // 0xd0(0x04)
	bool bUseWarping; // 0xd4(0x01)
	char pad_d5[0x3]; // 0xd5(0x03)
	float ScaleMovementFactor; // 0xd8(0x04)
	bool bUseGravity; // 0xdc(0x01)
	bool bFloorWalkable; // 0xdd(0x01)
	char pad_de[0x2]; // 0xde(0x02)
	struct FVector LastFrameVelocity; // 0xe0(0x18)
	float GravityZ; // 0xf8(0x04)
	char pad_fc[0x4]; // 0xfc(0x04)
};

// ScriptStruct PendulumRuntime.PendulumExecutionContext
// Size: 0xe8 (Inherited: 0x00)
struct FPendulumExecutionContext {
	char pad_0[0x28]; // 0x00(0x28)
	struct UPendulumDataContainer* DataContainer; // 0x28(0x08)
	struct APlayerController* PlayerController; // 0x30(0x08)
	struct AAIController* AIController; // 0x38(0x08)
	struct APawn* Pawn; // 0x40(0x08)
	float EngineDt; // 0x48(0x04)
	float LastInputSyncTime; // 0x4c(0x04)
	int32_t RootT; // 0x50(0x04)
	bool IsServer; // 0x54(0x01)
	bool IsResimulation; // 0x55(0x01)
	bool bIsBetweenFramesSimulation; // 0x56(0x01)
	char pad_57[0x29]; // 0x57(0x29)
	struct FPendulumLogicResult PrevLogicResult; // 0x80(0x60)
	char pad_e0[0x8]; // 0xe0(0x08)
};

// ScriptStruct PendulumRuntime.PendulumDebugContext
// Size: 0x48 (Inherited: 0x00)
struct FPendulumDebugContext {
	struct UPendulumDataContainer* DataContainer; // 0x00(0x08)
	char pad_8[0x30]; // 0x08(0x30)
	struct APlayerController* PlayerController; // 0x38(0x08)
	float EngineDt; // 0x40(0x04)
	bool IsServer; // 0x44(0x01)
	bool IsResimulation; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
};

// ScriptStruct PendulumRuntime.PendulumNodeHandle
// Size: 0x01 (Inherited: 0x00)
struct FPendulumNodeHandle {
	char Index; // 0x00(0x01)
};

// ScriptStruct PendulumRuntime.TimeValidStateChange
// Size: 0x70 (Inherited: 0x00)
struct FTimeValidStateChange {
	int32_t StartTick; // 0x00(0x04)
	int32_t EndTick; // 0x04(0x04)
	struct FPendulumLogicResult Change; // 0x08(0x60)
	bool bResetWhenLeaving; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// ScriptStruct PendulumRuntime.SequencedResultStateChanges
// Size: 0x10 (Inherited: 0x00)
struct FSequencedResultStateChanges {
	struct TArray<struct FTimeValidStateChange> Changes; // 0x00(0x10)
};

// ScriptStruct PendulumRuntime.SimpleTransitionCondition
// Size: 0x68 (Inherited: 0x00)
struct FSimpleTransitionCondition {
	struct FPendulumLogicResult State; // 0x00(0x60)
	bool bHasComplexConditions; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct PendulumRuntime.PendulumSMTransitionInfo
// Size: 0x70 (Inherited: 0x00)
struct FPendulumSMTransitionInfo {
	struct UPendulumTransitionNodeData* ToTransition; // 0x00(0x08)
	struct FSimpleTransitionCondition Condition; // 0x08(0x68)
};

// ScriptStruct PendulumRuntime.PendulumTagOptions
// Size: 0x03 (Inherited: 0x00)
struct FPendulumTagOptions {
	enum class PendulumSetEveryFrameMode SetEveryFrameMode; // 0x00(0x01)
	bool bSyncToGAS; // 0x01(0x01)
	bool bSyncFromGAS; // 0x02(0x01)
};

// ScriptStruct PendulumRuntime.PendulumVariableTableMapping
// Size: 0x60 (Inherited: 0x00)
struct FPendulumVariableTableMapping {
	struct TArray<struct FName> CurveNames; // 0x00(0x10)
	struct TArray<struct FName> DynamicGameplayTagList; // 0x10(0x10)
	struct TArray<struct FPendulumTagOptions> DynamicGameplayTagOptionsList; // 0x20(0x10)
	struct TArray<struct FName> TransientGameplayTagList; // 0x30(0x10)
	struct FPendulumBoolArray ResetEveryFrameDynamicStates; // 0x40(0x20)
};

