// Class EnhancedInput.EnhancedPlayerMappableKeyProfile
// Size: 0x110 (Inherited: 0xa0)
struct UEnhancedPlayerMappableKeyProfile : UObject {
	struct FGameplayTag ProfileIdentifier; // 0x98(0x08)
	struct FPlatformUserId OwningUserId; // 0xa0(0x04)
	struct FText DisplayName; // 0xa8(0x18)
	struct TMap<struct FName, struct FKeyMappingRow> PlayerMappedKeys; // 0xc0(0x50)

	struct FString ToString(); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.ToString // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5010990
	void SetDisplayName(struct FText& NewDisplayName); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.SetDisplayName // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x500fd40
	void ResetToDefault(); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.ResetToDefault // (Native|Public|BlueprintCallable) // @ game+0x2f0e200
	void ResetMappingToDefault(struct FName InMappingName); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.ResetMappingToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x5019600
	int32_t QueryPlayerMappedKeys(struct FPlayerMappableKeyQueryOptions& Options, struct TArray<struct FKey>& OutKeys); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.QueryPlayerMappedKeys // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe9b50
	void K2_FindKeyMapping(struct FPlayerKeyMapping& OutKeyMapping, struct FMapPlayerKeyArgs& InArgs); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.K2_FindKeyMapping // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe2d20
	struct FGameplayTag GetProfileIdentifer(); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.GetProfileIdentifer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3ade0b0
	struct FText GetProfileDisplayName(); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.GetProfileDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe21b0
	struct TMap<struct FName, struct FKeyMappingRow> GetPlayerMappingRows(); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.GetPlayerMappingRows // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe4280
	int32_t GetMappingNamesForKey(struct FKey& InKey, struct TArray<struct FName>& OutMappingNames); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.GetMappingNamesForKey // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ffd4b0
	int32_t GetMappedKeysInRow(struct FName MappingName, struct TArray<struct FKey>& OutKeys); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.GetMappedKeysInRow // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ff3ec0
	void DumpProfileToLog(); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.DumpProfileToLog // (Native|Public|BlueprintCallable|Const) // @ game+0x2b96540
	bool DoesMappingPassQueryOptions(struct FPlayerKeyMapping& PlayerMapping, struct FPlayerMappableKeyQueryOptions& Options); // Function EnhancedInput.EnhancedPlayerMappableKeyProfile.DoesMappingPassQueryOptions // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x500b910
};

// Class EnhancedInput.EnhancedInputUserSettings
// Size: 0x190 (Inherited: 0xa0)
struct UEnhancedInputUserSettings : USaveGame {
	struct FMulticastInlineDelegate OnSettingsChanged; // 0xa0(0x10)
	struct FMulticastInlineDelegate OnSettingsApplied; // 0xb0(0x10)
	char pad_c0[0x20]; // 0xc0(0x20)
	struct FGameplayTag CurrentProfileIdentifier; // 0xe0(0x08)
	struct TMap<struct FGameplayTag, struct UEnhancedPlayerMappableKeyProfile*> SavedKeyProfiles; // 0xe8(0x50)
	struct TWeakObjectPtr<struct ULocalPlayer> OwningLocalPlayer; // 0x138(0x08)
	struct TSet<struct UInputMappingContext*> RegisteredMappingContexts; // 0x140(0x50)

	bool UnregisterInputMappingContexts(struct TSet<struct UInputMappingContext*>& MappingContexts); // Function EnhancedInput.EnhancedInputUserSettings.UnregisterInputMappingContexts // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5015380
	bool UnregisterInputMappingContext(struct UInputMappingContext* IMC); // Function EnhancedInput.EnhancedInputUserSettings.UnregisterInputMappingContext // (Native|Public|BlueprintCallable) // @ game+0x4fec250
	void UnMapPlayerKey(struct FMapPlayerKeyArgs& InArgs, struct FGameplayTagContainer& FailureReason); // Function EnhancedInput.EnhancedInputUserSettings.UnMapPlayerKey // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4feee70
	bool SetKeyProfile(struct FGameplayTag& InProfileId); // Function EnhancedInput.EnhancedInputUserSettings.SetKeyProfile // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fe1060
	void SaveSettings(); // Function EnhancedInput.EnhancedInputUserSettings.SaveSettings // (Native|Public|BlueprintCallable) // @ game+0x17031b0
	void ResetKeyProfileToDefault(struct FGameplayTag& ProfileId, struct FGameplayTagContainer& FailureReason); // Function EnhancedInput.EnhancedInputUserSettings.ResetKeyProfileToDefault // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fe0910
	void ResetAllPlayerKeysInRow(struct FMapPlayerKeyArgs& InArgs, struct FGameplayTagContainer& FailureReason); // Function EnhancedInput.EnhancedInputUserSettings.ResetAllPlayerKeysInRow // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5019d60
	bool RegisterInputMappingContexts(struct TSet<struct UInputMappingContext*>& MappingContexts); // Function EnhancedInput.EnhancedInputUserSettings.RegisterInputMappingContexts // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4ff1160
	bool RegisterInputMappingContext(struct UInputMappingContext* IMC); // Function EnhancedInput.EnhancedInputUserSettings.RegisterInputMappingContext // (Native|Public|BlueprintCallable) // @ game+0x50238f0
	void MapPlayerKey(struct FMapPlayerKeyArgs& InArgs, struct FGameplayTagContainer& FailureReason); // Function EnhancedInput.EnhancedInputUserSettings.MapPlayerKey // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4feb8f0
	void MappingContextRegisteredWithSettings__DelegateSignature(struct UInputMappingContext* IMC); // DelegateFunction EnhancedInput.EnhancedInputUserSettings.MappingContextRegisteredWithSettings__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void MappableKeyProfileChanged__DelegateSignature(struct UEnhancedPlayerMappableKeyProfile* NewProfile); // DelegateFunction EnhancedInput.EnhancedInputUserSettings.MappableKeyProfileChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	bool IsMappingContextRegistered(struct UInputMappingContext* IMC); // Function EnhancedInput.EnhancedInputUserSettings.IsMappingContextRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5019f10
	struct UEnhancedPlayerMappableKeyProfile* GetKeyProfileWithIdentifier(struct FGameplayTag& ProfileId); // Function EnhancedInput.EnhancedInputUserSettings.GetKeyProfileWithIdentifier // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x501a660
	struct FGameplayTag GetCurrentKeyProfileIdentifier(); // Function EnhancedInput.EnhancedInputUserSettings.GetCurrentKeyProfileIdentifier // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5001160
	struct UEnhancedPlayerMappableKeyProfile* GetCurrentKeyProfile(); // Function EnhancedInput.EnhancedInputUserSettings.GetCurrentKeyProfile // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe47c0
	struct TSet<struct FPlayerKeyMapping> FindMappingsInRow(struct FName MappingName); // Function EnhancedInput.EnhancedInputUserSettings.FindMappingsInRow // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x501a9e0
	void EnhancedInputUserSettingsChanged__DelegateSignature(struct UEnhancedInputUserSettings* Settings); // DelegateFunction EnhancedInput.EnhancedInputUserSettings.EnhancedInputUserSettingsChanged__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	void EnhancedInputUserSettingsApplied__DelegateSignature(); // DelegateFunction EnhancedInput.EnhancedInputUserSettings.EnhancedInputUserSettingsApplied__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x4abfe0
	struct UEnhancedPlayerMappableKeyProfile* CreateNewKeyProfile(struct FPlayerMappableKeyProfileCreationArgs& InArgs); // Function EnhancedInput.EnhancedInputUserSettings.CreateNewKeyProfile // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x500f650
	void AsyncSaveSettings(); // Function EnhancedInput.EnhancedInputUserSettings.AsyncSaveSettings // (Native|Public|BlueprintCallable) // @ game+0x16fe8b0
	void ApplySettings(); // Function EnhancedInput.EnhancedInputUserSettings.ApplySettings // (Native|Public|BlueprintCallable) // @ game+0x2b96540
};

// Class EnhancedInput.EnhancedInputActionDelegateBinding
// Size: 0xb0 (Inherited: 0xa0)
struct UEnhancedInputActionDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionDelegateBindings; // 0x98(0x10)
};

// Class EnhancedInput.EnhancedInputActionValueBinding
// Size: 0xb0 (Inherited: 0xa0)
struct UEnhancedInputActionValueBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintEnhancedInputActionBinding> InputActionValueBindings; // 0x98(0x10)
};

// Class EnhancedInput.EnhancedInputComponent
// Size: 0x220 (Inherited: 0x1e0)
struct UEnhancedInputComponent : UInputComponent {
	char pad_1e0[0x40]; // 0x1e0(0x40)

	struct FInputActionValue GetBoundActionValue(struct UInputAction* Action); // Function EnhancedInput.EnhancedInputComponent.GetBoundActionValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ffdcf0
};

// Class EnhancedInput.EnhancedInputDeveloperSettings
// Size: 0x160 (Inherited: 0xb0)
struct UEnhancedInputDeveloperSettings : UDeveloperSettingsBackedByCVars {
	struct TArray<struct FDefaultContextSetting> DefaultMappingContexts; // 0xa8(0x10)
	struct TArray<struct FDefaultContextSetting> DefaultWorldSubsystemMappingContexts; // 0xb8(0x10)
	struct FPerPlatformSettings PlatformSettings; // 0xc8(0x10)
	struct TSoftClassPtr<UObject> UserSettingsClass; // 0xd8(0x28)
	struct TSoftClassPtr<UObject> DefaultPlayerMappableKeyProfileClass; // 0x100(0x28)
	struct TSoftClassPtr<UObject> DefaultWorldInputClass; // 0x128(0x28)
	char bSendTriggeredEventsWhenInputIsFlushed : 1; // 0x150(0x01)
	char bEnableUserSettings : 1; // 0x150(0x01)
	char bEnableDefaultMappingContexts : 1; // 0x150(0x01)
	char bShouldOnlyTriggerLastActionInChord : 1; // 0x150(0x01)
	char bLogOnDeprecatedConfigUsed : 1; // 0x150(0x01)
	char bEnableWorldSubsystem : 1; // 0x150(0x01)
	char bShouldLogAllWorldSubsystemInputs : 1; // 0x150(0x01)
	char pad_158_7 : 1; // 0x158(0x01)
	char pad_159[0x7]; // 0x159(0x07)
};

// Class EnhancedInput.EnhancedInputLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEnhancedInputLibrary : UBlueprintFunctionLibrary {

	void RequestRebuildControlMappingsUsingContext(struct UInputMappingContext* Context, bool bForceImmediately); // Function EnhancedInput.EnhancedInputLibrary.RequestRebuildControlMappingsUsingContext // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0x4ffa670
	struct FInputActionValue MakeInputActionValueOfType(double X, double Y, double Z, enum class EInputActionValueType ValueType); // Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValueOfType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4feb140
	struct FInputActionValue MakeInputActionValue(double X, double Y, double Z, struct FInputActionValue& MatchValueType); // Function EnhancedInput.EnhancedInputLibrary.MakeInputActionValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fdf820
	bool IsActionKeyMappingPlayerMappable(struct FEnhancedActionKeyMapping& ActionKeyMapping); // Function EnhancedInput.EnhancedInputLibrary.IsActionKeyMappingPlayerMappable // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fe7d60
	struct FPlayerMappableKeySlot GetThirdPlayerMappableKeySlot(); // Function EnhancedInput.EnhancedInputLibrary.GetThirdPlayerMappableKeySlot // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5013970
	struct FPlayerMappableKeySlot GetSecondPlayerMappableKeySlot(); // Function EnhancedInput.EnhancedInputLibrary.GetSecondPlayerMappableKeySlot // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4ff93f0
	struct UPlayerMappableKeySettings* GetPlayerMappableKeySettings(struct FEnhancedActionKeyMapping& ActionKeyMapping); // Function EnhancedInput.EnhancedInputLibrary.GetPlayerMappableKeySettings // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fed560
	struct FName GetMappingName(struct FEnhancedActionKeyMapping& ActionKeyMapping); // Function EnhancedInput.EnhancedInputLibrary.GetMappingName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fe4d80
	struct FPlayerMappableKeySlot GetFourthPlayerMappableKeySlot(); // Function EnhancedInput.EnhancedInputLibrary.GetFourthPlayerMappableKeySlot // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4ffca60
	struct FPlayerMappableKeySlot GetFirstPlayerMappableKeySlot(); // Function EnhancedInput.EnhancedInputLibrary.GetFirstPlayerMappableKeySlot // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x501b710
	struct FInputActionValue GetBoundActionValue(struct AActor* Actor, struct UInputAction* Action); // Function EnhancedInput.EnhancedInputLibrary.GetBoundActionValue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5000230
	struct FString Conv_InputActionValueToString(struct FInputActionValue ActionValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToString // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4ff2a00
	bool Conv_InputActionValueToBool(struct FInputActionValue InValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToBool // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4fdfc00
	struct FVector Conv_InputActionValueToAxis3D(struct FInputActionValue ActionValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis3D // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x5007000
	struct FVector2D Conv_InputActionValueToAxis2D(struct FInputActionValue InValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis2D // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x500f0f0
	double Conv_InputActionValueToAxis1D(struct FInputActionValue InValue); // Function EnhancedInput.EnhancedInputLibrary.Conv_InputActionValueToAxis1D // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x4ff00c0
	void BreakInputActionValue(struct FInputActionValue InActionValue, double& X, double& Y, double& Z, enum class EInputActionValueType& Type); // Function EnhancedInput.EnhancedInputLibrary.BreakInputActionValue // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x4fdf310
};

// Class EnhancedInput.EnhancedInputPlatformData
// Size: 0xf0 (Inherited: 0xa0)
struct UEnhancedInputPlatformData : UObject {
	struct TMap<struct UInputMappingContext*, struct UInputMappingContext*> MappingContextRedirects; // 0x98(0x50)

	struct UInputMappingContext* GetContextRedirect(struct UInputMappingContext* InContext); // Function EnhancedInput.EnhancedInputPlatformData.GetContextRedirect // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5015f90
};

// Class EnhancedInput.EnhancedInputPlatformSettings
// Size: 0xe0 (Inherited: 0xb0)
struct UEnhancedInputPlatformSettings : UPlatformSettings {
	struct TArray<struct TSoftClassPtr<UObject>> InputData; // 0xb0(0x10)
	struct TArray<struct UEnhancedInputPlatformData*> InputDataClasses; // 0xc0(0x10)
	bool bShouldLogMappingContextRedirects; // 0xd0(0x01)
	char pad_d1[0xf]; // 0xd1(0x0f)
};

// Class EnhancedInput.EnhancedInputSubsystemInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEnhancedInputSubsystemInterface : UInterface {

	void StopContinuousInputInjectionForPlayerMapping(struct FName MappingName); // Function EnhancedInput.EnhancedInputSubsystemInterface.StopContinuousInputInjectionForPlayerMapping // (Native|Public|BlueprintCallable) // @ game+0x50155b0
	void StopContinuousInputInjectionForAction(struct UInputAction* Action); // Function EnhancedInput.EnhancedInputSubsystemInterface.StopContinuousInputInjectionForAction // (Native|Public|BlueprintCallable) // @ game+0x4ff4e70
	void StartContinuousInputInjectionForPlayerMapping(struct FName MappingName, struct FInputActionValue RawValue, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.StartContinuousInputInjectionForPlayerMapping // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x501da60
	void StartContinuousInputInjectionForAction(struct UInputAction* Action, struct FInputActionValue RawValue, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.StartContinuousInputInjectionForAction // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50239f0
	void RequestRebuildControlMappings(struct FModifyContextOptions& Options, enum class EInputMappingRebuildType RebuildType); // Function EnhancedInput.EnhancedInputSubsystemInterface.RequestRebuildControlMappings // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4fe80e0
	void RemovePlayerMappableConfig(struct UPlayerMappableInputConfig* Config, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemovePlayerMappableConfig // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4ffeb70
	void RemoveMappingContext(struct UInputMappingContext* MappingContext, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveMappingContext // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x500b7d0
	int32_t RemoveAllPlayerMappedKeysForMapping(struct FName MappingName, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveAllPlayerMappedKeysForMapping // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x501ca00
	void RemoveAllPlayerMappedKeys(struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.RemoveAllPlayerMappedKeys // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x500d1c0
	enum class EMappingQueryResult QueryMapKeyInContextSet(struct TArray<struct UInputMappingContext*>& PrioritizedActiveContexts, struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, enum class EMappingQueryIssue BlockingIssues); // Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInContextSet // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4ff1a40
	enum class EMappingQueryResult QueryMapKeyInActiveContextSet(struct UInputMappingContext* InputContext, struct UInputAction* Action, struct FKey Key, struct TArray<struct FMappingQueryIssue>& OutIssues, enum class EMappingQueryIssue BlockingIssues); // Function EnhancedInput.EnhancedInputSubsystemInterface.QueryMapKeyInActiveContextSet // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5014af0
	struct TArray<struct FKey> QueryKeysMappedToAction(struct UInputAction* Action); // Function EnhancedInput.EnhancedInputSubsystemInterface.QueryKeysMappedToAction // (BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ff9260
	void OnUserSettingsChanged(struct UEnhancedInputUserSettings* Settings); // Function EnhancedInput.EnhancedInputSubsystemInterface.OnUserSettingsChanged // (Native|Protected) // @ game+0x4ff2f80
	void OnUserKeyProfileChanged(struct UEnhancedPlayerMappableKeyProfile* InNewProfile); // Function EnhancedInput.EnhancedInputSubsystemInterface.OnUserKeyProfileChanged // (Native|Protected) // @ game+0x5006b40
	int32_t K2_RemovePlayerMappedKeyInSlot(struct FName MappingName, struct FPlayerMappableKeySlot& KeySlot, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.K2_RemovePlayerMappedKeyInSlot // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50200e0
	struct FKey K2_GetPlayerMappedKeyInSlot(struct FName MappingName, struct FPlayerMappableKeySlot& KeySlot); // Function EnhancedInput.EnhancedInputSubsystemInterface.K2_GetPlayerMappedKeyInSlot // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe61c0
	int32_t K2_AddPlayerMappedKeyInSlot(struct FName MappingName, struct FKey NewKey, struct FPlayerMappableKeySlot& KeySlot, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.K2_AddPlayerMappedKeyInSlot // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4ff3520
	void InjectInputVectorForPlayerMapping(struct FName MappingName, struct FVector Value, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputVectorForPlayerMapping // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5015080
	void InjectInputVectorForAction(struct UInputAction* Action, struct FVector Value, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputVectorForAction // (Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5001430
	void InjectInputForPlayerMapping(struct FName MappingName, struct FInputActionValue RawValue, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputForPlayerMapping // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4ff2d70
	void InjectInputForAction(struct UInputAction* Action, struct FInputActionValue RawValue, struct TArray<struct UInputModifier*>& Modifiers, struct TArray<struct UInputTrigger*>& Triggers); // Function EnhancedInput.EnhancedInputSubsystemInterface.InjectInputForAction // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x500f440
	bool HasMappingContext(struct UInputMappingContext* MappingContext, int32_t& OutFoundPriority); // Function EnhancedInput.EnhancedInputSubsystemInterface.HasMappingContext // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ffcc90
	struct UEnhancedInputUserSettings* GetUserSettings(); // Function EnhancedInput.EnhancedInputSubsystemInterface.GetUserSettings // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2f337b0
	struct TArray<struct FKey> GetAllPlayerMappedKeys(struct FName MappingName); // Function EnhancedInput.EnhancedInputSubsystemInterface.GetAllPlayerMappedKeys // (BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4feea20
	struct TArray<struct FEnhancedActionKeyMapping> GetAllPlayerMappableActionKeyMappings(); // Function EnhancedInput.EnhancedInputSubsystemInterface.GetAllPlayerMappableActionKeyMappings // (BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ff4920
	struct TArray<struct FEnhancedActionKeyMapping> GetAllActionKeyMappings(); // Function EnhancedInput.EnhancedInputSubsystemInterface.GetAllActionKeyMappings // (BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ff4f60
	void ClearAllMappings(); // Function EnhancedInput.EnhancedInputSubsystemInterface.ClearAllMappings // (BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x4fdf2f0
	void AddPlayerMappableConfig(struct UPlayerMappableInputConfig* Config, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.AddPlayerMappableConfig // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x4febcd0
	void AddMappingContext(struct UInputMappingContext* MappingContext, int32_t Priority, struct FModifyContextOptions& Options); // Function EnhancedInput.EnhancedInputSubsystemInterface.AddMappingContext // (BlueprintCosmetic|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x50207b0
};

// Class EnhancedInput.EnhancedInputLocalPlayerSubsystem
// Size: 0x260 (Inherited: 0xa0)
struct UEnhancedInputLocalPlayerSubsystem : ULocalPlayerSubsystem {
	char pad_a0[0x1a0]; // 0xa0(0x1a0)
	struct FMulticastInlineDelegate ControlMappingsRebuiltDelegate; // 0x240(0x10)
	struct UEnhancedInputUserSettings* UserSettings; // 0x250(0x08)
	char pad_258[0x8]; // 0x258(0x08)
};

// Class EnhancedInput.EnhancedInputWorldSubsystem
// Size: 0x270 (Inherited: 0xa0)
struct UEnhancedInputWorldSubsystem : UWorldSubsystem {
	char pad_a0[0x1a0]; // 0xa0(0x1a0)
	struct UEnhancedPlayerInput* PlayerInput; // 0x240(0x08)
	char pad_248[0x10]; // 0x248(0x10)
	struct TArray<struct TWeakObjectPtr<struct UInputComponent>> CurrentInputStack; // 0x258(0x10)
	char pad_268[0x8]; // 0x268(0x08)

	bool RemoveActorInputComponent(struct AActor* Actor); // Function EnhancedInput.EnhancedInputWorldSubsystem.RemoveActorInputComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x500a1e0
	void AddActorInputComponent(struct AActor* Actor); // Function EnhancedInput.EnhancedInputWorldSubsystem.AddActorInputComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x500bcf0
};

// Class EnhancedInput.EnhancedPlayerInput
// Size: 0x900 (Inherited: 0x5a0)
struct UEnhancedPlayerInput : UPlayerInput {
	struct TMap<struct UInputAction*, struct FKeyConsumptionOptions> KeyConsumptionData; // 0x5a0(0x50)
	struct TMap<struct UInputMappingContext*, int32_t> AppliedInputContexts; // 0x5f0(0x50)
	struct TArray<struct FEnhancedActionKeyMapping> EnhancedActionMappings; // 0x640(0x10)
	char pad_650[0x50]; // 0x650(0x50)
	struct TMap<struct UInputAction*, struct FInputActionInstance> ActionInstanceData; // 0x6a0(0x50)
	char pad_6f0[0xa0]; // 0x6f0(0xa0)
	struct TMap<struct FKey, struct FVector> KeysPressedThisTick; // 0x790(0x50)
	struct TMap<struct UInputAction*, struct FInjectedInputArray> InputsInjectedThisTick; // 0x7e0(0x50)
	struct TSet<struct UInputAction*> LastInjectedActions; // 0x830(0x50)
	char pad_880[0x80]; // 0x880(0x80)
};

// Class EnhancedInput.InputAction
// Size: 0xf0 (Inherited: 0xa0)
struct UInputAction : UDataAsset {
	struct FText ActionDescription; // 0xa0(0x18)
	bool bTriggerWhenPaused; // 0xb8(0x01)
	bool bConsumeInput; // 0xb9(0x01)
	bool bConsumesActionAndAxisMappings; // 0xba(0x01)
	bool bReserveAllMappings; // 0xbb(0x01)
	int32_t TriggerEventsThatConsumeLegacyKeys; // 0xbc(0x04)
	enum class EInputActionValueType ValueType; // 0xc0(0x01)
	enum class EInputActionAccumulationBehavior AccumulationBehavior; // 0xc1(0x01)
	char pad_c2[0x6]; // 0xc2(0x06)
	struct TArray<struct UInputTrigger*> Triggers; // 0xc8(0x10)
	struct TArray<struct UInputModifier*> Modifiers; // 0xd8(0x10)
	struct UPlayerMappableKeySettings* PlayerMappableKeySettings; // 0xe8(0x08)
};

// Class EnhancedInput.InputDebugKeyDelegateBinding
// Size: 0xb0 (Inherited: 0xa0)
struct UInputDebugKeyDelegateBinding : UInputDelegateBinding {
	struct TArray<struct FBlueprintInputDebugKeyDelegateBinding> InputDebugKeyDelegateBindings; // 0x98(0x10)
};

// Class EnhancedInput.InputMappingContext
// Size: 0xd0 (Inherited: 0xa0)
struct UInputMappingContext : UDataAsset {
	struct TArray<struct FEnhancedActionKeyMapping> Mappings; // 0xa0(0x10)
	struct FText ContextDescription; // 0xb0(0x18)
	char pad_c8[0x8]; // 0xc8(0x08)

	void UnmapKey(struct UInputAction* Action, struct FKey Key); // Function EnhancedInput.InputMappingContext.UnmapKey // (Final|Native|Public|BlueprintCallable) // @ game+0x5016110
	void UnmapAllKeysFromAction(struct UInputAction* Action); // Function EnhancedInput.InputMappingContext.UnmapAllKeysFromAction // (Final|Native|Public|BlueprintCallable) // @ game+0x4ffde50
	void UnmapAll(); // Function EnhancedInput.InputMappingContext.UnmapAll // (Final|Native|Public|BlueprintCallable) // @ game+0x4ffd490
	void UnmapAction(struct UInputAction* Action); // Function EnhancedInput.InputMappingContext.UnmapAction // (Final|Native|Public|BlueprintCallable) // @ game+0x4ffde50
	struct FEnhancedActionKeyMapping MapKey(struct UInputAction* Action, struct FKey ToKey); // Function EnhancedInput.InputMappingContext.MapKey // (Final|Native|Public|BlueprintCallable) // @ game+0x4fec860
};

// Class EnhancedInput.InputModifier
// Size: 0xa0 (Inherited: 0xa0)
struct UInputModifier : UObject {

	struct FInputActionValue ModifyRaw(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue CurrentValue, float DeltaTime); // Function EnhancedInput.InputModifier.ModifyRaw // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x501cc20
	struct FLinearColor GetVisualizationColor(struct FInputActionValue SampleValue, struct FInputActionValue FinalValue); // Function EnhancedInput.InputModifier.GetVisualizationColor // (Native|Event|Public|HasDefaults|BlueprintEvent|Const) // @ game+0x4feda00
};

// Class EnhancedInput.InputModifierDeadZone
// Size: 0xb0 (Inherited: 0xa0)
struct UInputModifierDeadZone : UInputModifier {
	float LowerThreshold; // 0x98(0x04)
	float UpperThreshold; // 0x9c(0x04)
	enum class EDeadZoneType Type; // 0xa0(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)
};

// Class EnhancedInput.InputModifierScalar
// Size: 0xb0 (Inherited: 0xa0)
struct UInputModifierScalar : UInputModifier {
	struct FVector Scalar; // 0x98(0x18)
};

// Class EnhancedInput.InputModifierScaleByDeltaTime
// Size: 0xa0 (Inherited: 0xa0)
struct UInputModifierScaleByDeltaTime : UInputModifier {
};

// Class EnhancedInput.InputModifierNegate
// Size: 0xa0 (Inherited: 0xa0)
struct UInputModifierNegate : UInputModifier {
	bool bX; // 0x98(0x01)
	bool bY; // 0x99(0x01)
	bool bZ; // 0x9a(0x01)
};

// Class EnhancedInput.InputModifierSmooth
// Size: 0xd0 (Inherited: 0xa0)
struct UInputModifierSmooth : UInputModifier {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class EnhancedInput.InputModifierResponseCurveExponential
// Size: 0xb0 (Inherited: 0xa0)
struct UInputModifierResponseCurveExponential : UInputModifier {
	struct FVector CurveExponent; // 0x98(0x18)
};

// Class EnhancedInput.InputModifierResponseCurveUser
// Size: 0xb0 (Inherited: 0xa0)
struct UInputModifierResponseCurveUser : UInputModifier {
	struct UCurveFloat* ResponseX; // 0x98(0x08)
	struct UCurveFloat* ResponseY; // 0xa0(0x08)
	struct UCurveFloat* ResponseZ; // 0xa8(0x08)
};

// Class EnhancedInput.InputModifierFOVScaling
// Size: 0xa0 (Inherited: 0xa0)
struct UInputModifierFOVScaling : UInputModifier {
	float FOVScale; // 0x98(0x04)
	enum class EFOVScalingType FOVScalingType; // 0x9c(0x01)
};

// Class EnhancedInput.InputModifierToWorldSpace
// Size: 0xa0 (Inherited: 0xa0)
struct UInputModifierToWorldSpace : UInputModifier {
};

// Class EnhancedInput.InputModifierSwizzleAxis
// Size: 0xa0 (Inherited: 0xa0)
struct UInputModifierSwizzleAxis : UInputModifier {
	enum class EInputAxisSwizzle Order; // 0x98(0x01)
};

// Class EnhancedInput.InputTrigger
// Size: 0xc0 (Inherited: 0xa0)
struct UInputTrigger : UObject {
	float ActuationThreshold; // 0x98(0x04)
	bool bShouldAlwaysTick; // 0x9c(0x01)
	struct FInputActionValue LastValue; // 0xa0(0x20)

	enum class ETriggerState UpdateState(struct UEnhancedPlayerInput* PlayerInput, struct FInputActionValue ModifiedValue, float DeltaTime); // Function EnhancedInput.InputTrigger.UpdateState // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x4fe3090
	bool IsActuated(struct FInputActionValue& ForValue); // Function EnhancedInput.InputTrigger.IsActuated // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5000c80
	enum class ETriggerType GetTriggerType(); // Function EnhancedInput.InputTrigger.GetTriggerType // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3247a90
};

// Class EnhancedInput.InputTriggerTimedBase
// Size: 0xd0 (Inherited: 0xc0)
struct UInputTriggerTimedBase : UInputTrigger {
	float HeldDuration; // 0xc0(0x04)
	bool bAffectedByTimeDilation; // 0xc4(0x01)
	char pad_c5[0xb]; // 0xc5(0x0b)
};

// Class EnhancedInput.InputTriggerDown
// Size: 0xc0 (Inherited: 0xc0)
struct UInputTriggerDown : UInputTrigger {
};

// Class EnhancedInput.InputTriggerPressed
// Size: 0xc0 (Inherited: 0xc0)
struct UInputTriggerPressed : UInputTrigger {
};

// Class EnhancedInput.InputTriggerReleased
// Size: 0xc0 (Inherited: 0xc0)
struct UInputTriggerReleased : UInputTrigger {
};

// Class EnhancedInput.InputTriggerHold
// Size: 0xe0 (Inherited: 0xd0)
struct UInputTriggerHold : UInputTriggerTimedBase {
	float HoldTimeThreshold; // 0xcc(0x04)
	bool bIsOneShot; // 0xd0(0x01)
	char pad_d5[0xb]; // 0xd5(0x0b)
};

// Class EnhancedInput.InputTriggerHoldAndRelease
// Size: 0xd0 (Inherited: 0xd0)
struct UInputTriggerHoldAndRelease : UInputTriggerTimedBase {
	float HoldTimeThreshold; // 0xc8(0x04)
};

// Class EnhancedInput.InputTriggerTap
// Size: 0xd0 (Inherited: 0xd0)
struct UInputTriggerTap : UInputTriggerTimedBase {
	float TapReleaseTimeThreshold; // 0xc8(0x04)
};

// Class EnhancedInput.InputTriggerPulse
// Size: 0xe0 (Inherited: 0xd0)
struct UInputTriggerPulse : UInputTriggerTimedBase {
	bool bTriggerOnStart; // 0xcc(0x01)
	float Interval; // 0xd0(0x04)
	int32_t TriggerLimit; // 0xd4(0x04)
	char pad_d9[0x7]; // 0xd9(0x07)
};

// Class EnhancedInput.InputTriggerChordAction
// Size: 0xd0 (Inherited: 0xc0)
struct UInputTriggerChordAction : UInputTrigger {
	struct UInputAction* ChordAction; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)
};

// Class EnhancedInput.InputTriggerChordBlocker
// Size: 0xd0 (Inherited: 0xd0)
struct UInputTriggerChordBlocker : UInputTriggerChordAction {
};

// Class EnhancedInput.InputTriggerCombo
// Size: 0xf0 (Inherited: 0xc0)
struct UInputTriggerCombo : UInputTrigger {
	int32_t CurrentComboStepIndex; // 0xc0(0x04)
	float CurrentTimeBetweenComboSteps; // 0xc4(0x04)
	struct TArray<struct FInputComboStepData> ComboActions; // 0xc8(0x10)
	struct TArray<struct FInputCancelAction> InputCancelActions; // 0xd8(0x10)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class EnhancedInput.PlayerMappableInputConfig
// Size: 0x120 (Inherited: 0xa0)
struct UPlayerMappableInputConfig : UPrimaryDataAsset {
	struct FName ConfigName; // 0xa0(0x08)
	struct FText ConfigDisplayName; // 0xa8(0x18)
	bool bIsDeprecated; // 0xc0(0x01)
	char pad_c1[0x7]; // 0xc1(0x07)
	struct UObject* MetaData; // 0xc8(0x08)
	struct TMap<struct UInputMappingContext*, int32_t> Contexts; // 0xd0(0x50)

	void ResetToDefault(); // Function EnhancedInput.PlayerMappableInputConfig.ResetToDefault // (Final|Native|Public|BlueprintCallable) // @ game+0x29fb8f0
	bool IsDeprecated(); // Function EnhancedInput.PlayerMappableInputConfig.IsDeprecated // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b1c7c0
	struct TArray<struct FEnhancedActionKeyMapping> GetPlayerMappableKeys(); // Function EnhancedInput.PlayerMappableInputConfig.GetPlayerMappableKeys // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4feed50
	struct UObject* GetMetadata(); // Function EnhancedInput.PlayerMappableInputConfig.GetMetadata // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ffce10
	struct TMap<struct UInputMappingContext*, int32_t> GetMappingContexts(); // Function EnhancedInput.PlayerMappableInputConfig.GetMappingContexts // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4ff4390
	struct FEnhancedActionKeyMapping GetMappingByName(struct FName MappingName); // Function EnhancedInput.PlayerMappableInputConfig.GetMappingByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x500b200
	struct TArray<struct FEnhancedActionKeyMapping> GetKeysBoundToAction(struct UInputAction* InAction); // Function EnhancedInput.PlayerMappableInputConfig.GetKeysBoundToAction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x50103d0
	struct FText GetDisplayName(); // Function EnhancedInput.PlayerMappableInputConfig.GetDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x4fe21b0
	struct FName GetConfigName(); // Function EnhancedInput.PlayerMappableInputConfig.GetConfigName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2f3d5f0
};

// Class EnhancedInput.PlayerMappableKeySettings
// Size: 0x100 (Inherited: 0xa0)
struct UPlayerMappableKeySettings : UObject {
	struct UObject* MetaData; // 0x98(0x08)
	struct FName Name; // 0xa0(0x08)
	struct FText DisplayName; // 0xa8(0x18)
	struct FText DisplayCategory; // 0xc0(0x18)
	struct FGameplayTagContainer SupportedKeyProfiles; // 0xd8(0x20)
};

