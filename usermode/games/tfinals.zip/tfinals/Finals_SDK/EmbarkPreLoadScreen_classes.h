// Class EmbarkPreLoadScreen.EmbarkPreLoadScreenSettings
// Size: 0xf0 (Inherited: 0xb0)
struct UEmbarkPreLoadScreenSettings : UDeveloperSettings {
	struct FSoftObjectPath ImagePath; // 0xa8(0x20)
	uint32_t ImageWidth; // 0xc8(0x04)
	uint32_t ImageHeight; // 0xcc(0x04)
	float ImageOpacity; // 0xd0(0x04)
	uint32_t HorizontalMargin; // 0xd4(0x04)
	uint32_t VerticalMargin; // 0xd8(0x04)
	enum class EEmbarkPreLoadScreenHorizontalAlignment HorizontalAlignment; // 0xdc(0x01)
	enum class EEmbarkPreLoadScreenVerticalAlignment VerticalAlignment; // 0xdd(0x01)
	float Speed; // 0xe0(0x04)
	enum class EEmbarkPreLoadScreenType Type; // 0xe4(0x01)
	uint32_t FlipbookRows; // 0xe8(0x04)
	uint32_t FlipbookColumns; // 0xec(0x04)
};

