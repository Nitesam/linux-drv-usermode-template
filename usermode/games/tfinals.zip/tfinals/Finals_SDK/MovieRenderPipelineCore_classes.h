// Class MovieRenderPipelineCore.MovieGraphBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieGraphBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FString ResolveFilenameFormatArguments(struct FString InFormatString, struct FMovieGraphFilenameResolveParams& InParams, struct FMovieGraphResolveArgs& OutMergedFormatArgs); // Function MovieRenderPipelineCore.MovieGraphBlueprintLibrary.ResolveFilenameFormatArguments // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b485f0
	struct FIntPoint GetEffectiveOutputResolution(struct UMovieGraphEvaluatedConfig* InEvaluatedGraph, struct FName& InBranchName); // Function MovieRenderPipelineCore.MovieGraphBlueprintLibrary.GetEffectiveOutputResolution // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9b44b40
	struct FFrameRate GetEffectiveFrameRate(struct UMovieGraphOutputSettingNode* InNode, struct FFrameRate& InDefaultRate); // Function MovieRenderPipelineCore.MovieGraphBlueprintLibrary.GetEffectiveFrameRate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9b47fa0
};

// Class MovieRenderPipelineCore.MovieGraphNode
// Size: 0x100 (Inherited: 0xa0)
struct UMovieGraphNode : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct TArray<struct UMovieGraphPin*> InputPins; // 0xb0(0x10)
	struct TArray<struct UMovieGraphPin*> OutputPins; // 0xc0(0x10)
	struct FInstancedPropertyBag DynamicProperties; // 0xd0(0x10)
	struct TArray<struct FMovieGraphPropertyInfo> ExposedPropertyInfo; // 0xe0(0x10)
	struct FGuid Guid; // 0xf0(0x10)
};

// Class MovieRenderPipelineCore.MovieGraphBranchNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphBranchNode : UMovieGraphNode {
};

// Class MovieRenderPipelineCore.MovieGraphSettingNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphSettingNode : UMovieGraphNode {
};

// Class MovieRenderPipelineCore.MovieGraphRenderPassNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphRenderPassNode : UMovieGraphSettingNode {
};

// Class MovieRenderPipelineCore.MovieGraphBurnInNode
// Size: 0x1f0 (Inherited: 0x100)
struct UMovieGraphBurnInNode : UMovieGraphRenderPassNode {
	char bOverride_BurnInClass : 1; // 0x100(0x01)
	char bOverride_bCompositeOntoFinalImage : 1; // 0x100(0x01)
	char pad_100_2 : 6; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FSoftClassPath BurnInClass; // 0x108(0x20)
	bool bCompositeOntoFinalImage; // 0x128(0x01)
	char pad_129[0x67]; // 0x129(0x67)
	struct TMap<struct UObject*, struct UMovieGraphBurnInWidget*> BurnInWidgetInstances; // 0x190(0x50)
	char pad_1e0[0x10]; // 0x1e0(0x10)
};

// Class MovieRenderPipelineCore.MovieGraphBurnInWidget
// Size: 0x350 (Inherited: 0x350)
struct UMovieGraphBurnInWidget : UUserWidget {

	void UpdateForGraph(struct UMovieGraphPipeline* InGraphPipeline); // Function MovieRenderPipelineCore.MovieGraphBurnInWidget.UpdateForGraph // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class MovieRenderPipelineCore.MovieGraphCollectionNode
// Size: 0x120 (Inherited: 0x100)
struct UMovieGraphCollectionNode : UMovieGraphSettingNode {
	char bOverride_CollectionName : 1; // 0x100(0x01)
	char bOverride_QueryClass : 1; // 0x100(0x01)
	char pad_100_2 : 6; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FString CollectionName; // 0x108(0x10)
	struct UMoviePipelineCollectionQuery* QueryClass; // 0x118(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphValueContainer
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieGraphValueContainer : UObject {
	struct FInstancedPropertyBag Value; // 0x98(0x10)

	void SetValueTypeObject(struct UObject* ValueTypeObject); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueTypeObject // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4e810
	void SetValueType(enum class EMovieGraphValueType ValueType); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueType // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4c250
	bool SetValueText(struct FText& InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4d6c0
	bool SetValueString(struct FString InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueString // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4b740
	bool SetValueSerializedString(struct FString NewValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueSerializedString // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4ee40
	bool SetValueObject(struct UObject* InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueObject // (Final|Native|Public|BlueprintCallable) // @ game+0x9b49ad0
	bool SetValueName(struct FName InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueName // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4ce80
	bool SetValueInt64(int64_t InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueInt64 // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4ca80
	bool SetValueInt32(int32_t InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueInt32 // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4df10
	bool SetValueFloat(float InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4f0c0
	bool SetValueEnum(char InValue, struct UEnum* Enum); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueEnum // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4d480
	bool SetValueDouble(double InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueDouble // (Final|Native|Public|BlueprintCallable) // @ game+0x9b499f0
	void SetValueContainerType(enum class EMovieGraphContainerType ContainerType); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueContainerType // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4fa50
	bool SetValueClass(struct UObject* InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueClass // (Final|Native|Public|BlueprintCallable) // @ game+0x9b49ad0
	bool SetValueByte(char InValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueByte // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4c1b0
	bool SetValueBool(bool bInValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.SetValueBool // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4b950
	struct UObject* GetValueTypeObject(); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueTypeObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4b8e0
	enum class EMovieGraphValueType GetValueType(); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4dee0
	bool GetValueText(struct FText& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueText // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b49900
	bool GetValueString(struct FString& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueString // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4ed80
	struct FString GetValueSerializedString(); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueSerializedString // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4bf60
	bool GetValueObject(struct UObject* OutValue, struct UObject* RequestedClass); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4bbd0
	bool GetValueName(struct FName& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4c8c0
	bool GetValueInt64(int64_t& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueInt64 // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4dc70
	bool GetValueInt32(int32_t& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueInt32 // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4f920
	bool GetValueFloat(float& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4c440
	bool GetValueEnum(char& OutValue, struct UEnum* RequestedEnum); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueEnum // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4ba00
	bool GetValueDouble(double& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueDouble // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4ead0
	enum class EMovieGraphContainerType GetValueContainerType(); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueContainerType // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4d070
	bool GetValueClass(struct UObject* OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4de30
	bool GetValueByte(char& OutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueByte // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4a210
	bool GetValueBool(bool& bOutValue); // Function MovieRenderPipelineCore.MovieGraphValueContainer.GetValueBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4b0a0
};

// Class MovieRenderPipelineCore.MovieGraphMember
// Size: 0xe0 (Inherited: 0xb0)
struct UMovieGraphMember : UMovieGraphValueContainer {
	struct FString Description; // 0xa8(0x10)
	struct FString Name; // 0xb8(0x10)
	struct FGuid Guid; // 0xc8(0x10)
	bool bIsEditable; // 0xd8(0x01)
};

// Class MovieRenderPipelineCore.MovieGraphVariable
// Size: 0xf0 (Inherited: 0xe0)
struct UMovieGraphVariable : UMovieGraphMember {
	bool bIsGlobal; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class MovieRenderPipelineCore.MovieGraphInterfaceBase
// Size: 0xf0 (Inherited: 0xe0)
struct UMovieGraphInterfaceBase : UMovieGraphMember {
	bool bIsBranch; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class MovieRenderPipelineCore.MovieGraphInput
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieGraphInput : UMovieGraphInterfaceBase {
};

// Class MovieRenderPipelineCore.MovieGraphOutput
// Size: 0xf0 (Inherited: 0xf0)
struct UMovieGraphOutput : UMovieGraphInterfaceBase {
};

// Class MovieRenderPipelineCore.MovieGraphEvaluatedConfig
// Size: 0xf0 (Inherited: 0xa0)
struct UMovieGraphEvaluatedConfig : UObject {
	struct TMap<struct FName, struct FMovieGraphEvaluatedBranchConfig> BranchConfigMapping; // 0x98(0x50)
};

// Class MovieRenderPipelineCore.MovieGraphConfig
// Size: 0xf0 (Inherited: 0xa0)
struct UMovieGraphConfig : UObject {
	struct TArray<struct UMovieGraphNode*> AllNodes; // 0x98(0x10)
	struct UMovieGraphNode* InputNode; // 0xa8(0x08)
	struct UMovieGraphNode* OutputNode; // 0xb0(0x08)
	struct TArray<struct UMovieGraphVariable*> Variables; // 0xb8(0x10)
	struct TArray<struct UMovieGraphInput*> Inputs; // 0xc8(0x10)
	struct TArray<struct UMovieGraphOutput*> Outputs; // 0xd8(0x10)

	struct TArray<struct UMovieGraphVariable*> GetVariables(bool bIncludeGlobal); // Function MovieRenderPipelineCore.MovieGraphConfig.GetVariables // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b45ec0
	struct UMovieGraphEvaluatedConfig* CreateFlattenedGraph(struct FMovieGraphTraversalContext& InContext); // Function MovieRenderPipelineCore.MovieGraphConfig.CreateFlattenedGraph // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b48b80
	struct UMovieGraphVariable* AddVariable(struct FName InCustomBaseName); // Function MovieRenderPipelineCore.MovieGraphConfig.AddVariable // (Final|Native|Public|BlueprintCallable) // @ game+0x9b48940
};

// Class MovieRenderPipelineCore.MovieGraphTimeStepBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieGraphTimeStepBase : UObject {
};

// Class MovieRenderPipelineCore.MovieGraphRendererBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieGraphRendererBase : UObject {
};

// Class MovieRenderPipelineCore.MovieGraphDataSourceBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMovieGraphDataSourceBase : UObject {
};

// Class MovieRenderPipelineCore.MovieGraphDefaultRenderer
// Size: 0x220 (Inherited: 0xa0)
struct UMovieGraphDefaultRenderer : UMovieGraphRendererBase {
	struct TArray<struct UMovieGraphRenderPassNode*> RenderPassesInUse; // 0x98(0x10)
	char pad_b0[0x170]; // 0xb0(0x170)
};

// Class MovieRenderPipelineCore.MovieGraphDeferredRenderPassNode
// Size: 0x110 (Inherited: 0x100)
struct UMovieGraphDeferredRenderPassNode : UMovieGraphRenderPassNode {
	char pad_100[0x10]; // 0x100(0x10)
};

// Class MovieRenderPipelineCore.MovieGraphEdge
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieGraphEdge : UObject {
	struct UMovieGraphPin* InputPin; // 0x98(0x08)
	struct UMovieGraphPin* OutputPin; // 0xa0(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphFileOutputNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphFileOutputNode : UMovieGraphSettingNode {
};

// Class MovieRenderPipelineCore.MovieGraphGetCVarValueNode
// Size: 0x120 (Inherited: 0x100)
struct UMovieGraphGetCVarValueNode : UMovieGraphSettingNode {
	char bOverride_Name : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FString Name; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphGlobalGameOverridesNode
// Size: 0x130 (Inherited: 0x100)
struct UMovieGraphGlobalGameOverridesNode : UMovieGraphSettingNode {
	char bOverride_GameModeOverride : 1; // 0x100(0x01)
	char bOverride_CinematicQualitySettings : 1; // 0x100(0x01)
	char bOverride_TextureStreaming : 1; // 0x100(0x01)
	char bOverride_UseLODZero : 1; // 0x100(0x01)
	char bOverride_DisableHLODs : 1; // 0x100(0x01)
	char bOverride_UseHighQualityShadows : 1; // 0x100(0x01)
	char bOverride_ShadowDistanceScale : 1; // 0x100(0x01)
	char bOverride_ShadowRadiusThreshold : 1; // 0x100(0x01)
	char bOverride_OverrideViewDistanceScale : 1; // 0x101(0x01)
	char bOverride_ViewDistanceScale : 1; // 0x101(0x01)
	char bOverride_FlushGrassStreaming : 1; // 0x101(0x01)
	char bOverride_FlushStreamingManagers : 1; // 0x101(0x01)
	char bOverride_VirtualTextureFeedbackFactor : 1; // 0x101(0x01)
	char bOverride_DisableGPUTimeout : 1; // 0x101(0x01)
	char pad_101_6 : 2; // 0x101(0x01)
	char pad_102[0x6]; // 0x102(0x06)
	struct AGameModeBase* GameModeOverride; // 0x108(0x08)
	bool bCinematicQualitySettings; // 0x110(0x01)
	enum class EMoviePipelineTextureStreamingMethod TextureStreaming; // 0x111(0x01)
	bool bUseLODZero; // 0x112(0x01)
	bool bDisableHLODs; // 0x113(0x01)
	bool bUseHighQualityShadows; // 0x114(0x01)
	char pad_115[0x3]; // 0x115(0x03)
	int32_t ShadowDistanceScale; // 0x118(0x04)
	float ShadowRadiusThreshold; // 0x11c(0x04)
	int32_t ViewDistanceScale; // 0x120(0x04)
	bool bFlushGrassStreaming; // 0x124(0x01)
	bool bFlushStreamingManagers; // 0x125(0x01)
	char pad_126[0x2]; // 0x126(0x02)
	int32_t VirtualTextureFeedbackFactor; // 0x128(0x04)
	char pad_12c[0x4]; // 0x12c(0x04)
};

// Class MovieRenderPipelineCore.MovieGraphImageSequenceOutputNode
// Size: 0x120 (Inherited: 0x100)
struct UMovieGraphImageSequenceOutputNode : UMovieGraphFileOutputNode {
	char pad_100[0x20]; // 0x100(0x20)
};

// Class MovieRenderPipelineCore.MovieGraphImageSequenceOutputNode_BMP
// Size: 0x120 (Inherited: 0x120)
struct UMovieGraphImageSequenceOutputNode_BMP : UMovieGraphImageSequenceOutputNode {
};

// Class MovieRenderPipelineCore.MovieGraphImageSequenceOutputNode_JPG
// Size: 0x120 (Inherited: 0x120)
struct UMovieGraphImageSequenceOutputNode_JPG : UMovieGraphImageSequenceOutputNode {
};

// Class MovieRenderPipelineCore.MovieGraphImageSequenceOutputNode_PNG
// Size: 0x120 (Inherited: 0x120)
struct UMovieGraphImageSequenceOutputNode_PNG : UMovieGraphImageSequenceOutputNode {
};

// Class MovieRenderPipelineCore.MovieGraphInputNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphInputNode : UMovieGraphNode {
};

// Class MovieRenderPipelineCore.MovieGraphLinearTimeStep
// Size: 0x1b0 (Inherited: 0xa0)
struct UMovieGraphLinearTimeStep : UMovieGraphTimeStepBase {
	struct FMovieGraphTimeStepData CurrentTimeStepData; // 0x98(0x20)
	char pad_c0[0xe0]; // 0xc0(0xe0)
	struct UMovieGraphEngineTimeStep* CustomTimeStep; // 0x1a0(0x08)
	struct UEngineCustomTimeStep* PrevCustomTimeStep; // 0x1a8(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphEngineTimeStep
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieGraphEngineTimeStep : UEngineCustomTimeStep {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class MovieRenderPipelineCore.MovieGraphModifierNode
// Size: 0x130 (Inherited: 0x100)
struct UMovieGraphModifierNode : UMovieGraphSettingNode {
	char bOverride_ModifierName : 1; // 0x100(0x01)
	char bOverride_ModifiedCollectionName : 1; // 0x100(0x01)
	char bOverride_ModifierClass : 1; // 0x100(0x01)
	char pad_100_3 : 5; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FString ModifierName; // 0x108(0x10)
	struct FString ModifiedCollectionName; // 0x118(0x10)
	struct UMoviePipelineCollectionModifier* ModifierClass; // 0x128(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphOutputNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphOutputNode : UMovieGraphNode {
};

// Class MovieRenderPipelineCore.MovieGraphOutputSettingNode
// Size: 0x150 (Inherited: 0x100)
struct UMovieGraphOutputSettingNode : UMovieGraphSettingNode {
	char bOverride_OutputDirectory : 1; // 0x100(0x01)
	char bOverride_FileNameFormat : 1; // 0x100(0x01)
	char bOverride_OutputResolution : 1; // 0x100(0x01)
	char bOverride_OutputFrameRate : 1; // 0x100(0x01)
	char bOverride_bOverwriteExistingOutput : 1; // 0x100(0x01)
	char bOverride_ZeroPadFrameNumbers : 1; // 0x100(0x01)
	char bOverride_FrameNumberOffset : 1; // 0x100(0x01)
	char pad_100_7 : 1; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FDirectoryPath OutputDirectory; // 0x108(0x10)
	struct FString FileNameFormat; // 0x118(0x10)
	struct FIntPoint OutputResolution; // 0x128(0x08)
	struct FFrameRate OutputFrameRate; // 0x130(0x08)
	bool bOverwriteExistingOutput; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	int32_t ZeroPadFrameNumbers; // 0x13c(0x04)
	int32_t FrameNumberOffset; // 0x140(0x04)
	char pad_144[0xc]; // 0x144(0x0c)
};

// Class MovieRenderPipelineCore.MovieGraphPin
// Size: 0xc0 (Inherited: 0xa0)
struct UMovieGraphPin : UObject {
	struct UMovieGraphNode* Node; // 0x98(0x08)
	struct FMovieGraphPinProperties Properties; // 0xa0(0x0c)
	struct TArray<struct UMovieGraphEdge*> Edges; // 0xb0(0x10)
};

// Class MovieRenderPipelineCore.MoviePipelineBase
// Size: 0xd0 (Inherited: 0xa0)
struct UMoviePipelineBase : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)

	void Shutdown(bool bIsError); // Function MovieRenderPipelineCore.MoviePipelineBase.Shutdown // (Final|Native|Public|BlueprintCallable) // @ game+0x298b400
	void RequestShutdown(bool bIsError); // Function MovieRenderPipelineCore.MoviePipelineBase.RequestShutdown // (Final|Native|Public|BlueprintCallable) // @ game+0x3263980
	bool IsShutdownRequested(); // Function MovieRenderPipelineCore.MoviePipelineBase.IsShutdownRequested // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3acf850
	enum class EMovieRenderPipelineState GetPipelineState(); // Function MovieRenderPipelineCore.MoviePipelineBase.GetPipelineState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x29eeb30
};

// Class MovieRenderPipelineCore.MovieGraphPipeline
// Size: 0x1a0 (Inherited: 0xd0)
struct UMovieGraphPipeline : UMoviePipelineBase {
	struct UMovieGraphTimeStepBase* GraphTimeStepInstance; // 0xc8(0x08)
	struct UMovieGraphRendererBase* GraphRendererInstance; // 0xd0(0x08)
	struct UMovieGraphDataSourceBase* GraphDataSourceInstance; // 0xd8(0x08)
	struct UMoviePipelineExecutorJob* CurrentJob; // 0xe0(0x08)
	struct TArray<struct UMoviePipelineExecutorShot*> ActiveShotList; // 0xe8(0x10)
	struct TSet<struct UMovieGraphFileOutputNode*> OutputNodesDataSentTo; // 0xf8(0x50)
	char pad_150[0x50]; // 0x150(0x50)

	void SetInitializationTime(struct FDateTime& InDateTime); // Function MovieRenderPipelineCore.MovieGraphPipeline.SetInitializationTime // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9b4dbc0
	void OnMoviePipelineFinishedImpl(); // Function MovieRenderPipelineCore.MovieGraphPipeline.OnMoviePipelineFinishedImpl // (Native|Protected|BlueprintCallable) // @ game+0x16fe6f0
	void Initialize(struct UMoviePipelineExecutorJob* InJob, struct FMovieGraphInitConfig& InitConfig); // Function MovieRenderPipelineCore.MovieGraphPipeline.Initialize // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4d120
	struct FDateTime GetInitializationTime(); // Function MovieRenderPipelineCore.MovieGraphPipeline.GetInitializationTime // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b49d50
	struct UMoviePipelineExecutorJob* GetCurrentJob(); // Function MovieRenderPipelineCore.MovieGraphPipeline.GetCurrentJob // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x97c6110
};

// Class MovieRenderPipelineCore.MovieGraphPathTracedRendererNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphPathTracedRendererNode : UMovieGraphSettingNode {
};

// Class MovieRenderPipelineCore.MovieGraphEXRSequenceNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphEXRSequenceNode : UMovieGraphSettingNode {
};

// Class MovieRenderPipelineCore.MovieGraphAntiAliasingNode
// Size: 0x100 (Inherited: 0x100)
struct UMovieGraphAntiAliasingNode : UMovieGraphSettingNode {
};

// Class MovieRenderPipelineCore.MovieGraphRenderLayerNode
// Size: 0x120 (Inherited: 0x100)
struct UMovieGraphRenderLayerNode : UMovieGraphSettingNode {
	char bOverride_LayerName : 1; // 0x100(0x01)
	char pad_100_1 : 7; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FString LayerName; // 0x108(0x10)
	char pad_118[0x8]; // 0x118(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphSelectNode
// Size: 0x130 (Inherited: 0x100)
struct UMovieGraphSelectNode : UMovieGraphNode {
	struct TArray<struct FString> SelectOptions; // 0x100(0x10)
	struct FString SelectedOption; // 0x110(0x10)
	struct FString Description; // 0x120(0x10)
};

// Class MovieRenderPipelineCore.MovieGraphSequenceDataSource
// Size: 0xb0 (Inherited: 0xa0)
struct UMovieGraphSequenceDataSource : UMovieGraphDataSourceBase {
	struct ALevelSequenceActor* LevelSequenceActor; // 0x98(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphSetCVarValueNode
// Size: 0x130 (Inherited: 0x100)
struct UMovieGraphSetCVarValueNode : UMovieGraphSettingNode {
	char bOverride_Name : 1; // 0x100(0x01)
	char bOverride_Value : 1; // 0x100(0x01)
	char pad_100_2 : 6; // 0x100(0x01)
	char pad_101[0x7]; // 0x101(0x07)
	struct FString Name; // 0x108(0x10)
	struct FString Value; // 0x118(0x10)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class MovieRenderPipelineCore.MovieGraphSubgraphNode
// Size: 0x130 (Inherited: 0x100)
struct UMovieGraphSubgraphNode : UMovieGraphNode {
	struct TSoftObjectPtr<UMovieGraphConfig> SubgraphAsset; // 0x100(0x28)
	char pad_128[0x8]; // 0x128(0x08)

	void SetSubGraphAsset(struct TSoftObjectPtr<UMovieGraphConfig>& InSubgraphAsset); // Function MovieRenderPipelineCore.MovieGraphSubgraphNode.SetSubGraphAsset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4f7f0
	struct UMovieGraphConfig* GetSubgraphAsset(); // Function MovieRenderPipelineCore.MovieGraphSubgraphNode.GetSubgraphAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b4f090
};

// Class MovieRenderPipelineCore.MovieGraphVariableNode
// Size: 0x120 (Inherited: 0x100)
struct UMovieGraphVariableNode : UMovieGraphNode {
	struct UMovieGraphVariable* GraphVariable; // 0x100(0x08)
	struct FMovieGraphPinProperties OutputPin; // 0x108(0x0c)
	char pad_114[0xc]; // 0x114(0x0c)
};

// Class MovieRenderPipelineCore.MovieJobVariableAssignmentContainer
// Size: 0xd0 (Inherited: 0xa0)
struct UMovieJobVariableAssignmentContainer : UObject {
	struct FInstancedPropertyBag Value; // 0x98(0x10)
	struct TSoftObjectPtr<UMovieGraphConfig> GraphPreset; // 0xa8(0x28)

	bool SetVariableAssignmentEnableState(struct UMovieGraphVariable* InGraphVariable, bool bIsEnabled); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetVariableAssignmentEnableState // (Final|Native|Public|BlueprintCallable) // @ game+0x9b54900
	bool SetValueText(struct FName& PropertyName, struct FText& InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueText // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b59b50
	bool SetValueString(struct FName& PropertyName, struct FString InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueString // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b55740
	bool SetValueSerializedString(struct FName& PropertyName, struct FString NewValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueSerializedString // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b54d80
	bool SetValueObject(struct FName& PropertyName, struct UObject* InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueObject // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4fc40
	bool SetValueName(struct FName& PropertyName, struct FName InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b56fe0
	bool SetValueInt64(struct FName& PropertyName, int64_t InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueInt64 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b50520
	bool SetValueInt32(struct FName& PropertyName, int32_t InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueInt32 // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b51cc0
	bool SetValueFloat(struct FName& PropertyName, float InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueFloat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b529e0
	bool SetValueEnum(struct FName& PropertyName, char InValue, struct UEnum* Enum); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueEnum // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b56b80
	bool SetValueDouble(struct FName& PropertyName, double InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueDouble // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b572a0
	bool SetValueClass(struct FName& PropertyName, struct UObject* InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueClass // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b4fc40
	bool SetValueByte(struct FName& PropertyName, char InValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueByte // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5a000
	bool SetValueBool(struct FName& PropertyName, bool bInValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetValueBool // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b58d30
	void SetGraphConfig(struct TSoftObjectPtr<UMovieGraphConfig>& InGraphConfig); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.SetGraphConfig // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b5a560
	bool GetVariableAssignmentEnableState(struct UMovieGraphVariable* InGraphVariable, bool& bOutIsEnabled); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetVariableAssignmentEnableState // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b51e10
	struct UObject* GetValueTypeObject(struct FName& PropertyName); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueTypeObject // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b52360
	enum class EMovieGraphValueType GetValueType(struct FName& PropertyName); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b5a460
	bool GetValueText(struct FName& PropertyName, struct FText& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueText // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b59e70
	bool GetValueString(struct FName& PropertyName, struct FString& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueString // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b58080
	struct FString GetValueSerializedString(struct FName& PropertyName); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueSerializedString // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b55590
	bool GetValueObject(struct FName& PropertyName, struct UObject* OutValue, struct UObject* RequestedClass); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueObject // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b57bf0
	bool GetValueName(struct FName& PropertyName, struct FName& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueName // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b57860
	bool GetValueInt64(struct FName& PropertyName, int64_t& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueInt64 // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b559a0
	bool GetValueInt32(struct FName& PropertyName, int32_t& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueInt32 // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b59200
	bool GetValueFloat(struct FName& PropertyName, float& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueFloat // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b51220
	bool GetValueEnum(struct FName& PropertyName, char& OutValue, struct UEnum* RequestedEnum); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueEnum // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b56380
	bool GetValueDouble(struct FName& PropertyName, double& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueDouble // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b55090
	enum class EMovieGraphContainerType GetValueContainerType(struct FName& PropertyName); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueContainerType // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b579c0
	bool GetValueClass(struct FName& PropertyName, struct UObject* OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueClass // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b57710
	bool GetValueByte(struct FName& PropertyName, char& OutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueByte // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b52420
	bool GetValueBool(struct FName& PropertyName, bool& bOutValue); // Function MovieRenderPipelineCore.MovieJobVariableAssignmentContainer.GetValueBool // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b54a70
};

// Class MovieRenderPipelineCore.MoviePipelineSetting
// Size: 0xc0 (Inherited: 0xa0)
struct UMoviePipelineSetting : UObject {
	struct TWeakObjectPtr<struct UMoviePipeline> CachedPipeline; // 0x98(0x08)
	bool bEnabled; // 0xa0(0x01)
	char pad_a9[0x17]; // 0xa9(0x17)

	void SetIsEnabled(bool bInEnabled); // Function MovieRenderPipelineCore.MoviePipelineSetting.SetIsEnabled // (Native|Public|BlueprintCallable) // @ game+0x9bb8550
	bool IsEnabled(); // Function MovieRenderPipelineCore.MoviePipelineSetting.IsEnabled // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b24420
	void BuildNewProcessCommandLineArgs(struct TArray<struct FString>& InOutUnrealURLParams, struct TArray<struct FString>& InOutCommandLineArgs, struct TArray<struct FString>& InOutDeviceProfileCvars, struct TArray<struct FString>& InOutExecCmds); // Function MovieRenderPipelineCore.MoviePipelineSetting.BuildNewProcessCommandLineArgs // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b98630
	void BuildNewProcessCommandLine(struct FString& InOutUnrealURLParams, struct FString& InOutCommandLineArgs); // Function MovieRenderPipelineCore.MoviePipelineSetting.BuildNewProcessCommandLine // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bb7760
};

// Class MovieRenderPipelineCore.MoviePipelineCameraSetting
// Size: 0xd0 (Inherited: 0xc0)
struct UMoviePipelineCameraSetting : UMoviePipelineSetting {
	enum class EMoviePipelineShutterTiming ShutterTiming; // 0xb8(0x01)
	float OverscanPercentage; // 0xbc(0x04)
	bool bRenderAllCameras; // 0xc0(0x01)
	char pad_c6[0xa]; // 0xc6(0x0a)
};

// Class MovieRenderPipelineCore.MoviePipelineGameMode
// Size: 0x440 (Inherited: 0x440)
struct AMoviePipelineGameMode : AGameModeBase {
};

// Class MovieRenderPipelineCore.MoviePipelineHighResSetting
// Size: 0xe0 (Inherited: 0xc0)
struct UMoviePipelineHighResSetting : UMoviePipelineSetting {
	int32_t TileCount; // 0xb8(0x04)
	float TextureSharpnessBias; // 0xbc(0x04)
	float OverlapRatio; // 0xc0(0x04)
	bool bOverrideSubSurfaceScattering; // 0xc4(0x01)
	int32_t BurleySampleCount; // 0xc8(0x04)
	bool bAllocateHistoryPerTile; // 0xcc(0x01)
	char pad_d2[0xe]; // 0xd2(0x0e)
};

// Class MovieRenderPipelineCore.MoviePipelineInProcessExecutorSettings
// Size: 0xe0 (Inherited: 0xb0)
struct UMoviePipelineInProcessExecutorSettings : UDeveloperSettings {
	bool bCloseEditor; // 0xa8(0x01)
	struct FString AdditionalCommandLineArguments; // 0xb0(0x10)
	struct FString InheritedCommandLineArguments; // 0xc0(0x10)
	int32_t InitialDelayFrameCount; // 0xd0(0x04)
	char pad_d5[0xb]; // 0xd5(0x0b)
};

// Class MovieRenderPipelineCore.MoviePipelineOutputBase
// Size: 0xc0 (Inherited: 0xc0)
struct UMoviePipelineOutputBase : UMoviePipelineSetting {
};

// Class MovieRenderPipelineCore.MoviePipelineCollection
// Size: 0xc0 (Inherited: 0xa0)
struct UMoviePipelineCollection : UObject {
	struct FString CollectionName; // 0x98(0x10)
	struct TArray<struct UMoviePipelineCollectionQuery*> Queries; // 0xa8(0x10)

	void SetCollectionName(struct FString InName); // Function MovieRenderPipelineCore.MoviePipelineCollection.SetCollectionName // (Final|Native|Public|BlueprintCallable) // @ game+0x9b54600
	struct TArray<struct AActor*> GetMatchingActors(struct UWorld* World, bool bInvertResult); // Function MovieRenderPipelineCore.MoviePipelineCollection.GetMatchingActors // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b590c0
	struct FString GetCollectionName(); // Function MovieRenderPipelineCore.MoviePipelineCollection.GetCollectionName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ea520
	void AddQuery(struct UMoviePipelineCollectionQuery* Query); // Function MovieRenderPipelineCore.MoviePipelineCollection.AddQuery // (Final|Native|Public|BlueprintCallable) // @ game+0x9b51f10
};

// Class MovieRenderPipelineCore.MoviePipelineCollectionModifier
// Size: 0xb0 (Inherited: 0xa0)
struct UMoviePipelineCollectionModifier : UObject {
	struct TArray<struct UMoviePipelineCollection*> Collections; // 0x98(0x10)
	bool bUseInvertedActors; // 0xa8(0x01)

	void SetIsInverted(bool bIsInverted); // Function MovieRenderPipelineCore.MoviePipelineCollectionModifier.SetIsInverted // (Final|Native|Public|BlueprintCallable) // @ game+0x9b55c80
	void SetCollections(struct TArray<struct UMoviePipelineCollection*> InCollections); // Function MovieRenderPipelineCore.MoviePipelineCollectionModifier.SetCollections // (Final|Native|Public|BlueprintCallable) // @ game+0x9b55330
	bool IsInverted(); // Function MovieRenderPipelineCore.MoviePipelineCollectionModifier.IsInverted // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b54520
	struct TArray<struct UMoviePipelineCollection*> GetCollections(); // Function MovieRenderPipelineCore.MoviePipelineCollectionModifier.GetCollections // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b51b60
	void AddCollection(struct UMoviePipelineCollection* Collection); // Function MovieRenderPipelineCore.MoviePipelineCollectionModifier.AddCollection // (Final|Native|Public|BlueprintCallable) // @ game+0x9b58a50
};

// Class MovieRenderPipelineCore.MoviePipelineMaterialModifier
// Size: 0x130 (Inherited: 0xb0)
struct UMoviePipelineMaterialModifier : UMoviePipelineCollectionModifier {
	char pad_b0[0x50]; // 0xb0(0x50)
	struct TSoftObjectPtr<UMaterialInterface> MaterialToApply; // 0x100(0x28)
	char pad_128[0x8]; // 0x128(0x08)

	void UndoModifier(); // Function MovieRenderPipelineCore.MoviePipelineMaterialModifier.UndoModifier // (Native|Public|BlueprintCallable) // @ game+0x2b96540
	void SetMaterial(struct TSoftObjectPtr<UMaterialInterface> InMaterial); // Function MovieRenderPipelineCore.MoviePipelineMaterialModifier.SetMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x9b55d60
	void ApplyModifier(struct UWorld* World); // Function MovieRenderPipelineCore.MoviePipelineMaterialModifier.ApplyModifier // (Native|Public|BlueprintCallable) // @ game+0x48db230
};

// Class MovieRenderPipelineCore.MoviePipelineVisibilityModifier
// Size: 0x110 (Inherited: 0xb0)
struct UMoviePipelineVisibilityModifier : UMoviePipelineCollectionModifier {
	struct TMap<struct TSoftObjectPtr<AActor>, bool> ModifiedActors; // 0xb0(0x50)
	bool bIsHidden; // 0x100(0x01)
	char pad_101[0xf]; // 0x101(0x0f)

	void UndoModifier(); // Function MovieRenderPipelineCore.MoviePipelineVisibilityModifier.UndoModifier // (Native|Public|BlueprintCallable) // @ game+0x2b96540
	void SetHidden(bool bInIsHidden); // Function MovieRenderPipelineCore.MoviePipelineVisibilityModifier.SetHidden // (Final|Native|Public|BlueprintCallable) // @ game+0x9b51ac0
	bool IsHidden(); // Function MovieRenderPipelineCore.MoviePipelineVisibilityModifier.IsHidden // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b576f0
	void ApplyModifier(struct UWorld* World); // Function MovieRenderPipelineCore.MoviePipelineVisibilityModifier.ApplyModifier // (Native|Public|BlueprintCallable) // @ game+0x48db230
};

// Class MovieRenderPipelineCore.MoviePipelineCollectionQuery
// Size: 0xa0 (Inherited: 0xa0)
struct UMoviePipelineCollectionQuery : UObject {
};

// Class MovieRenderPipelineCore.MoviePipelineCollectionCommonQuery
// Size: 0xd0 (Inherited: 0xa0)
struct UMoviePipelineCollectionCommonQuery : UMoviePipelineCollectionQuery {
	struct TArray<ClassPtrProperty> ComponentTypes; // 0x98(0x10)
	enum class EMoviePipelineCollectionCommonQueryMode QueryMode; // 0xa8(0x01)
	struct TArray<struct FString> ActorNames; // 0xb0(0x10)
	struct TArray<struct FName> Tags; // 0xc0(0x10)

	void SetTags(struct TArray<struct FName>& InTags); // Function MovieRenderPipelineCore.MoviePipelineCollectionCommonQuery.SetTags // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b54400
	void SetQueryMode(enum class EMoviePipelineCollectionCommonQueryMode InQueryMode); // Function MovieRenderPipelineCore.MoviePipelineCollectionCommonQuery.SetQueryMode // (Final|Native|Public|BlueprintCallable) // @ game+0x9b50330
	void SetComponentTypes(struct TArray<struct UObject*> InComponentTypes); // Function MovieRenderPipelineCore.MoviePipelineCollectionCommonQuery.SetComponentTypes // (Final|Native|Public|BlueprintCallable) // @ game+0x9b55330
	void SetActorNames(struct TArray<struct FString>& InActorNames); // Function MovieRenderPipelineCore.MoviePipelineCollectionCommonQuery.SetActorNames // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9b551f0
	bool DoesActorMatchQuery(struct AActor* Actor); // Function MovieRenderPipelineCore.MoviePipelineCollectionCommonQuery.DoesActorMatchQuery // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8fe5980
};

// Class MovieRenderPipelineCore.MoviePipelineRenderLayer
// Size: 0xc0 (Inherited: 0xa0)
struct UMoviePipelineRenderLayer : UObject {
	struct FString RenderLayerName; // 0x98(0x10)
	struct TArray<struct UMoviePipelineCollectionModifier*> Modifiers; // 0xa8(0x10)

	void UndoPreview(struct UWorld* World); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.UndoPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x9b59320
	void SetRenderLayerName(struct FString NewName); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.SetRenderLayerName // (Final|Native|Public|BlueprintCallable) // @ game+0x9b54600
	void RemoveModifier(struct UMoviePipelineCollectionModifier* Modifier); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.RemoveModifier // (Final|Native|Public|BlueprintCallable) // @ game+0x9b58880
	void Preview(struct UWorld* World); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.Preview // (Final|Native|Public|BlueprintCallable) // @ game+0x9b573f0
	struct FString GetRenderLayerName(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.GetRenderLayerName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ea520
	struct TArray<struct UMoviePipelineCollectionModifier*> GetModifiers(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.GetModifiers // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b59730
	struct UMoviePipelineCollection* GetCollectionByName(struct FString Name); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.GetCollectionByName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b581b0
	void AddModifier(struct UMoviePipelineCollectionModifier* Modifier); // Function MovieRenderPipelineCore.MoviePipelineRenderLayer.AddModifier // (Final|Native|Public|BlueprintCallable) // @ game+0x9b51f10
};

// Class MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem
// Size: 0xf0 (Inherited: 0xa0)
struct UMoviePipelineRenderLayerSubsystem : UWorldSubsystem {
	struct TArray<struct UMoviePipelineRenderLayer*> RenderLayers; // 0xa0(0x10)
	struct UMoviePipelineRenderLayer* ActiveRenderLayer; // 0xb0(0x08)
	struct UMoviePipelineCollection* ActiveCollection; // 0xb8(0x08)
	struct UMoviePipelineCollectionModifier* ActiveModifier; // 0xc0(0x08)
	struct UMoviePipelineRenderLayer* VisualizationRenderLayer; // 0xc8(0x08)
	struct UMoviePipelineCollection* VisualizationEmptyCollection; // 0xd0(0x08)
	struct UMoviePipelineVisibilityModifier* VisualizationModifier_HideWorld; // 0xd8(0x08)
	struct UMoviePipelineVisibilityModifier* VisualizationModifier_VisibleCollections; // 0xe0(0x08)
	char pad_e8[0x8]; // 0xe8(0x08)

	void SetActiveRenderLayerByObj(struct UMoviePipelineRenderLayer* RenderLayer); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.SetActiveRenderLayerByObj // (Final|Native|Public|BlueprintCallable) // @ game+0x9b57aa0
	void SetActiveRenderLayerByName(struct FString RenderLayerName); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.SetActiveRenderLayerByName // (Final|Native|Public|BlueprintCallable) // @ game+0x9b589a0
	void Reset(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.Reset // (Final|Native|Public|BlueprintCallable) // @ game+0x9b53070
	void RemoveRenderLayer(struct FString RenderLayerName); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.RemoveRenderLayer // (Final|Native|Public|BlueprintCallable) // @ game+0x9b59680
	void PreviewModifier(struct UMoviePipelineCollectionModifier* Modifier); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.PreviewModifier // (Final|Native|Public|BlueprintCallable) // @ game+0x9b58270
	void PreviewCollection(struct UMoviePipelineCollection* Collection); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.PreviewCollection // (Final|Native|Public|BlueprintCallable) // @ game+0x9b52580
	struct TArray<struct UMoviePipelineRenderLayer*> GetRenderLayers(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.GetRenderLayers // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5a640
	struct UMoviePipelineRenderLayerSubsystem* GetFromWorld(struct UWorld* World); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.GetFromWorld // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9b56ce0
	struct UMoviePipelineRenderLayer* GetActiveRenderLayer(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.GetActiveRenderLayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2534ea0
	void ClearModifierPreview(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.ClearModifierPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4fc20
	void ClearCollectionPreview(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.ClearCollectionPreview // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4fc20
	void ClearActiveRenderLayer(); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.ClearActiveRenderLayer // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4fc20
	bool AddRenderLayer(struct UMoviePipelineRenderLayer* RenderLayer); // Function MovieRenderPipelineCore.MoviePipelineRenderLayerSubsystem.AddRenderLayer // (Final|Native|Public|BlueprintCallable) // @ game+0x9b4fb30
};

// Class MovieRenderPipelineCore.MoviePipelineSetting_BlueprintBase
// Size: 0xe0 (Inherited: 0xc0)
struct UMoviePipelineSetting_BlueprintBase : UMoviePipelineSetting {
	struct FText CategoryText; // 0xb8(0x18)
	bool bIsValidOnPrimary; // 0xd0(0x01)
	bool bIsValidOnShots; // 0xd1(0x01)
	bool bCanBeDisabled; // 0xd2(0x01)
	char pad_db[0x5]; // 0xdb(0x05)

	void ReceiveTeardownForPipelineImpl(struct UMoviePipeline* InPipeline); // Function MovieRenderPipelineCore.MoviePipelineSetting_BlueprintBase.ReceiveTeardownForPipelineImpl // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveSetupForPipelineImpl(struct UMoviePipeline* InPipeline); // Function MovieRenderPipelineCore.MoviePipelineSetting_BlueprintBase.ReceiveSetupForPipelineImpl // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct FMoviePipelineFormatArgs ReceiveGetFormatArguments(struct FMoviePipelineFormatArgs& InOutFormatArgs); // Function MovieRenderPipelineCore.MoviePipelineSetting_BlueprintBase.ReceiveGetFormatArguments // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x9b626c0
	void OnEngineTickBeginFrame(); // Function MovieRenderPipelineCore.MoviePipelineSetting_BlueprintBase.OnEngineTickBeginFrame // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class MovieRenderPipelineCore.MoviePipelineViewFamilySetting
// Size: 0xc0 (Inherited: 0xc0)
struct UMoviePipelineViewFamilySetting : UMoviePipelineSetting {
};

// Class MovieRenderPipelineCore.MovieRenderDebugWidget
// Size: 0x350 (Inherited: 0x350)
struct UMovieRenderDebugWidget : UUserWidget {

	void OnInitializedForPipeline(struct UMoviePipeline* ForPipeline); // Function MovieRenderPipelineCore.MovieRenderDebugWidget.OnInitializedForPipeline // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class MovieRenderPipelineCore.MoviePipeline
// Size: 0x490 (Inherited: 0xd0)
struct UMoviePipeline : UMoviePipelineBase {
	struct FMulticastInlineDelegate OnMoviePipelineFinishedDelegate; // 0xc8(0x10)
	struct FMulticastInlineDelegate OnMoviePipelineWorkFinishedDelegate; // 0xd8(0x10)
	struct FMulticastInlineDelegate OnMoviePipelineShotWorkFinishedDelegate; // 0xe8(0x10)
	struct UMoviePipelineCustomTimeStep* CustomTimeStep; // 0xf8(0x08)
	char pad_108[0x8]; // 0x108(0x08)
	struct UEngineCustomTimeStep* CachedPrevCustomTimeStep; // 0x110(0x08)
	struct ULevelSequence* TargetSequence; // 0x118(0x08)
	struct ALevelSequenceActor* LevelSequenceActor; // 0x120(0x08)
	struct UMovieRenderDebugWidget* DebugWidget; // 0x128(0x08)
	struct UTexture* PreviewTexture; // 0x130(0x08)
	char pad_138[0x258]; // 0x138(0x258)
	struct UMovieRenderDebugWidget* DebugWidgetClass; // 0x390(0x08)
	char pad_398[0x8]; // 0x398(0x08)
	struct UMoviePipelineExecutorJob* CurrentJob; // 0x3a0(0x08)
	char pad_3a8[0xe8]; // 0x3a8(0xe8)

	void SetInitializationTime(struct FDateTime& InDateTime); // Function MovieRenderPipelineCore.MoviePipeline.SetInitializationTime // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x9b7b2f0
	void OnMoviePipelineFinishedImpl(); // Function MovieRenderPipelineCore.MoviePipeline.OnMoviePipelineFinishedImpl // (Native|Protected|BlueprintCallable) // @ game+0x16fe6f0
	void Initialize(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipeline.Initialize // (Final|Native|Public|BlueprintCallable) // @ game+0x9b5b520
	struct UTexture* GetPreviewTexture(); // Function MovieRenderPipelineCore.MoviePipeline.GetPreviewTexture // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b7b8f0
	struct UMoviePipelinePrimaryConfig* GetPipelinePrimaryConfig(); // Function MovieRenderPipelineCore.MoviePipeline.GetPipelinePrimaryConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b61db0
	struct UMoviePipelinePrimaryConfig* GetPipelineMasterConfig(); // Function MovieRenderPipelineCore.MoviePipeline.GetPipelineMasterConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b61db0
	struct FDateTime GetInitializationTime(); // Function MovieRenderPipelineCore.MoviePipeline.GetInitializationTime // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b73160
	struct UMoviePipelineExecutorJob* GetCurrentJob(); // Function MovieRenderPipelineCore.MoviePipeline.GetCurrentJob // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b74dd0
};

// Class MovieRenderPipelineCore.MoviePipelineCustomTimeStep
// Size: 0xb0 (Inherited: 0xa0)
struct UMoviePipelineCustomTimeStep : UEngineCustomTimeStep {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class MovieRenderPipelineCore.MoviePipelineAntiAliasingSetting
// Size: 0xe0 (Inherited: 0xc0)
struct UMoviePipelineAntiAliasingSetting : UMoviePipelineSetting {
	int32_t SpatialSampleCount; // 0xb8(0x04)
	int32_t TemporalSampleCount; // 0xbc(0x04)
	bool bOverrideAntiAliasing; // 0xc0(0x01)
	enum class EAntiAliasingMethod AntiAliasingMethod; // 0xc1(0x01)
	int32_t RenderWarmUpCount; // 0xc4(0x04)
	bool bUseCameraCutForWarmUp; // 0xc8(0x01)
	int32_t EngineWarmUpCount; // 0xcc(0x04)
	bool bRenderWarmUpFrames; // 0xd0(0x01)
	char pad_d4[0xc]; // 0xd4(0x0c)
};

// Class MovieRenderPipelineCore.MoviePipelineBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UMoviePipelineBlueprintLibrary : UBlueprintFunctionLibrary {

	void UpdateJobShotListFromSequence(struct ULevelSequence* InSequence, struct UMoviePipelineExecutorJob* InJob, bool& bShotsChanged); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.UpdateJobShotListFromSequence // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9bd9840
	int32_t ResolveVersionNumber(struct FMoviePipelineFilenameResolveParams InParams, bool bGetNextVersion); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.ResolveVersionNumber // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9ba8250
	void ResolveFilenameFormatArguments(struct FString InFormatString, struct FMoviePipelineFilenameResolveParams& InParams, struct FString& OutFinalPath, struct FMoviePipelineFormatArgs& OutMergedFormatArgs); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.ResolveFilenameFormatArguments // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9bc6570
	struct UMoviePipelineQueue* LoadManifestFileFromString(struct FString InManifestFilePath); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.LoadManifestFileFromString // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9bc5a90
	struct FTimecode GetRootTimecode(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetRootTimecode // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bc10e0
	struct FFrameNumber GetRootFrameNumber(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetRootFrameNumber // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x9b92ea0
	enum class EMovieRenderPipelineState GetPipelineState(struct UMoviePipeline* InPipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetPipelineState // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bc11f0
	void GetOverallSegmentCounts(struct UMoviePipeline* InMoviePipeline, int32_t& OutCurrentIndex, int32_t& OutTotalCount); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetOverallSegmentCounts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9bd8810
	void GetOverallOutputFrames(struct UMoviePipeline* InMoviePipeline, int32_t& OutCurrentIndex, int32_t& OutTotalCount); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetOverallOutputFrames // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9bb81d0
	struct FText GetMoviePipelineEngineChangelistLabel(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMoviePipelineEngineChangelistLabel // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bd8f10
	struct FTimecode GetMasterTimecode(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMasterTimecode // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bc10e0
	struct FFrameNumber GetMasterFrameNumber(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMasterFrameNumber // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x9b92ea0
	struct FString GetMapPackageName(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetMapPackageName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9b9fd30
	struct FText GetJobName(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9baa200
	struct FDateTime GetJobInitializationTime(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobInitializationTime // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x9baa350
	struct FText GetJobAuthor(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetJobAuthor // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bb6730
	bool GetEstimatedTimeRemaining(struct UMoviePipeline* InPipeline, struct FTimespan& OutEstimate); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetEstimatedTimeRemaining // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x9bbef30
	struct FIntPoint GetEffectiveOutputResolution(struct UMoviePipelinePrimaryConfig* InPrimaryConfig, struct UMoviePipelineExecutorShot* InPipelineExecutorShot); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetEffectiveOutputResolution // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x9b9ffd0
	struct FTimecode GetCurrentShotTimecode(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentShotTimecode // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bc5b60
	struct FFrameNumber GetCurrentShotFrameNumber(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentShotFrameNumber // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0x9ba8830
	struct ULevelSequence* GetCurrentSequence(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSequence // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bc5730
	struct FMoviePipelineSegmentWorkMetrics GetCurrentSegmentWorkMetrics(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentWorkMetrics // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bc9440
	enum class EMovieRenderShotState GetCurrentSegmentState(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentState // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9baaca0
	void GetCurrentSegmentName(struct UMoviePipeline* InMoviePipeline, struct FText& OutOuterName, struct FText& OutInnerName); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentSegmentName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9bc0f30
	float GetCurrentFocusDistance(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentFocusDistance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bb9590
	float GetCurrentFocalLength(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentFocalLength // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bb6eb0
	struct UMoviePipelineExecutorShot* GetCurrentExecutorShot(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentExecutorShot // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9baab90
	float GetCurrentAperture(struct UMoviePipeline* InMoviePipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCurrentAperture // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9bcd6f0
	float GetCompletionPercentage(struct UMoviePipeline* InPipeline); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.GetCompletionPercentage // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9b9a690
	struct UMoviePipelineSetting* FindOrGetDefaultSettingForShot(struct UMoviePipelineSetting* InSettingType, struct UMoviePipelinePrimaryConfig* InPrimaryConfig, struct UMoviePipelineExecutorShot* InShot); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.FindOrGetDefaultSettingForShot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9bdf890
	struct UMovieSceneSequence* DuplicateSequence(struct UObject* Outer, struct UMovieSceneSequence* InSequence); // Function MovieRenderPipelineCore.MoviePipelineBlueprintLibrary.DuplicateSequence // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9bbbc80
};

// Class MovieRenderPipelineCore.MoviePipelineColorSetting
// Size: 0x160 (Inherited: 0xc0)
struct UMoviePipelineColorSetting : UMoviePipelineSetting {
	struct FOpenColorIODisplayConfiguration OCIOConfiguration; // 0xb8(0xa0)
	bool bDisableToneCurve; // 0x158(0x01)
};

// Class MovieRenderPipelineCore.MoviePipelineCommandLineEncoder
// Size: 0x100 (Inherited: 0xc0)
struct UMoviePipelineCommandLineEncoder : UMoviePipelineSetting {
	struct FString FileNameFormatOverride; // 0xb8(0x10)
	enum class EMoviePipelineEncodeQuality Quality; // 0xc8(0x01)
	struct FString AdditionalCommandLineArgs; // 0xd0(0x10)
	bool bDeleteSourceFiles; // 0xe0(0x01)
	bool bSkipEncodeOnRenderCanceled; // 0xe1(0x01)
	bool bWriteEachFrameDuration; // 0xe2(0x01)
	char pad_e4[0x1c]; // 0xe4(0x1c)
};

// Class MovieRenderPipelineCore.MoviePipelineCommandLineEncoderSettings
// Size: 0x170 (Inherited: 0xb0)
struct UMoviePipelineCommandLineEncoderSettings : UDeveloperSettings {
	struct FString ExecutablePath; // 0xa8(0x10)
	struct FText CodecHelpText; // 0xb8(0x18)
	struct FString VideoCodec; // 0xd0(0x10)
	struct FString AudioCodec; // 0xe0(0x10)
	struct FString OutputFileExtension; // 0xf0(0x10)
	struct FString CommandLineFormat; // 0x100(0x10)
	struct FString VideoInputStringFormat; // 0x110(0x10)
	struct FString AudioInputStringFormat; // 0x120(0x10)
	struct FString EncodeSettings_Low; // 0x130(0x10)
	struct FString EncodeSettings_Med; // 0x140(0x10)
	struct FString EncodeSettings_High; // 0x150(0x10)
	struct FString EncodeSettings_Epic; // 0x160(0x10)
};

// Class MovieRenderPipelineCore.MoviePipelineConfigBase
// Size: 0xf0 (Inherited: 0xa0)
struct UMoviePipelineConfigBase : UObject {
	struct FString DisplayName; // 0x98(0x10)
	struct TArray<struct UMoviePipelineSetting*> Settings; // 0xa8(0x10)
	struct TSoftObjectPtr<UMoviePipelineConfigBase> ConfigOrigin; // 0xb8(0x28)
	char pad_e8[0x8]; // 0xe8(0x08)

	void SetConfigOrigin(struct UMoviePipelineConfigBase* InConfig); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.SetConfigOrigin // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd1580
	void RemoveSetting(struct UMoviePipelineSetting* InSetting); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.RemoveSetting // (Native|Public|BlueprintCallable) // @ game+0x48db230
	struct TArray<struct UMoviePipelineSetting*> GetUserSettings(); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.GetUserSettings // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5010990
	struct UMoviePipelineConfigBase* GetConfigOrigin(); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.GetConfigOrigin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9baeb50
	struct TArray<struct UMoviePipelineSetting*> FindSettingsByClass(struct UMoviePipelineSetting* InClass, bool bIncludeDisabledSettings, bool bExactMatch); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindSettingsByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bbcbf0
	struct UMoviePipelineSetting* FindSettingByClass(struct UMoviePipelineSetting* InClass, bool bIncludeDisabledSettings, bool bExactMatch); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindSettingByClass // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bb9760
	struct UMoviePipelineSetting* FindOrAddSettingByClass(struct UMoviePipelineSetting* InClass, bool bIncludeDisabledSettings, bool bExactMatch); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.FindOrAddSettingByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb0210
	void CopyFrom(struct UMoviePipelineConfigBase* InConfig); // Function MovieRenderPipelineCore.MoviePipelineConfigBase.CopyFrom // (Native|Public|BlueprintCallable) // @ game+0x5e4af30
};

// Class MovieRenderPipelineCore.MoviePipelineDebugSettings
// Size: 0xd0 (Inherited: 0xc0)
struct UMoviePipelineDebugSettings : UMoviePipelineSetting {
	bool bWriteAllSamples; // 0xb8(0x01)
	bool bCaptureFramesWithRenderDoc; // 0xb9(0x01)
	int32_t CaptureFrame; // 0xbc(0x04)
	bool bCaptureUnrealInsightsTrace; // 0xc0(0x01)
	char pad_c7[0x9]; // 0xc7(0x09)
};

// Class MovieRenderPipelineCore.MoviePipelineExecutorBase
// Size: 0x190 (Inherited: 0xa0)
struct UMoviePipelineExecutorBase : UObject {
	struct FMulticastInlineDelegate OnExecutorFinishedDelegate; // 0x98(0x10)
	char pad_b0[0x10]; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnExecutorErroredDelegate; // 0xc0(0x10)
	char pad_d0[0x20]; // 0xd0(0x20)
	struct FMulticastInlineDelegate SocketMessageRecievedDelegate; // 0xf0(0x10)
	struct FMulticastInlineDelegate HTTPResponseRecievedDelegate; // 0x100(0x10)
	struct UMovieRenderDebugWidget* DebugWidgetClass; // 0x110(0x08)
	char pad_118[0x10]; // 0x118(0x10)
	struct FString UserData; // 0x128(0x10)
	struct UMoviePipeline* TargetPipelineClass; // 0x138(0x08)
	char pad_140[0x50]; // 0x140(0x50)

	void SetStatusProgress(float InProgress); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetStatusProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x9baf4a0
	void SetStatusMessage(struct FString InStatus); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetStatusMessage // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5391220
	void SetMoviePipelineClass(struct UObject* InPipelineClass); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SetMoviePipelineClass // (Final|Native|Public|BlueprintCallable) // @ game+0x9bac850
	bool SendSocketMessage(struct FString InMessage); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SendSocketMessage // (Final|Native|Protected|BlueprintCallable) // @ game+0x9bc55f0
	int32_t SendHTTPRequest(struct FString InUrl, struct FString InVerb, struct FString InMessage, struct TMap<struct FString, struct FString>& InHeaders); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.SendHTTPRequest // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x9ba7aa0
	void OnExecutorFinishedImpl(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnExecutorFinishedImpl // (Native|Protected|BlueprintCallable) // @ game+0x2b95cb0
	void OnExecutorErroredImpl(struct UMoviePipeline* ErroredPipeline, bool bFatal, struct FText ErrorReason); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnExecutorErroredImpl // (Native|Protected|BlueprintCallable) // @ game+0x9bc0d50
	void OnBeginFrame(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.OnBeginFrame // (Native|Event|Public|BlueprintEvent) // @ game+0x29789d0
	bool IsSocketConnected(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.IsSocketConnected // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bb8800
	bool IsRendering(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.IsRendering // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x29eeb30
	float GetStatusProgress(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.GetStatusProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x8ee2880
	struct FString GetStatusMessage(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.GetStatusMessage // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3236570
	void Execute(struct UMoviePipelineQueue* InPipelineQueue); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.Execute // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5e413d0
	void DisconnectSocket(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.DisconnectSocket // (Final|Native|Protected|BlueprintCallable) // @ game+0x9bbf740
	bool ConnectSocket(struct FString InHostName, int32_t InPort); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.ConnectSocket // (Final|Native|Protected|BlueprintCallable) // @ game+0x9bc0a50
	void CancelCurrentJob(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.CancelCurrentJob // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x537cec0
	void CancelAllJobs(); // Function MovieRenderPipelineCore.MoviePipelineExecutorBase.CancelAllJobs // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x32add10
};

// Class MovieRenderPipelineCore.MoviePipelineFCPXMLExporter
// Size: 0xf0 (Inherited: 0xc0)
struct UMoviePipelineFCPXMLExporter : UMoviePipelineOutputBase {
	struct FString FileNameFormatOverride; // 0xc0(0x10)
	enum class FCPXMLExportDataSource DataSource; // 0xd0(0x01)
	char pad_d1[0x1f]; // 0xd1(0x1f)
};

// Class MovieRenderPipelineCore.MoviePipelineGameOverrideSetting
// Size: 0x1a0 (Inherited: 0xc0)
struct UMoviePipelineGameOverrideSetting : UMoviePipelineSetting {
	struct AGameModeBase* GameModeOverride; // 0xb8(0x08)
	bool bCinematicQualitySettings; // 0xc0(0x01)
	enum class EMoviePipelineTextureStreamingMethod TextureStreaming; // 0xc1(0x01)
	bool bUseLODZero; // 0xc2(0x01)
	bool bDisableHLODs; // 0xc3(0x01)
	bool bUseHighQualityShadows; // 0xc4(0x01)
	int32_t ShadowDistanceScale; // 0xc8(0x04)
	float ShadowRadiusThreshold; // 0xcc(0x04)
	bool bOverrideViewDistanceScale; // 0xd0(0x01)
	int32_t ViewDistanceScale; // 0xd4(0x04)
	bool bFlushGrassStreaming; // 0xd8(0x01)
	bool bFlushStreamingManagers; // 0xd9(0x01)
	bool bOverrideVirtualTextureFeedbackFactor; // 0xda(0x01)
	int32_t VirtualTextureFeedbackFactor; // 0xdc(0x04)
	char pad_e1[0xbf]; // 0xe1(0xbf)
};

// Class MovieRenderPipelineCore.MoviePipelineLinearExecutorBase
// Size: 0x1b0 (Inherited: 0x190)
struct UMoviePipelineLinearExecutorBase : UMoviePipelineExecutorBase {
	struct UMoviePipelineQueue* Queue; // 0x188(0x08)
	struct UMoviePipelineBase* ActiveMoviePipeline; // 0x190(0x08)
	char pad_1a0[0x10]; // 0x1a0(0x10)
};

// Class MovieRenderPipelineCore.MoviePipelineInProcessExecutor
// Size: 0x200 (Inherited: 0x1b0)
struct UMoviePipelineInProcessExecutor : UMoviePipelineLinearExecutorBase {
	bool bUseCurrentLevel; // 0x1b0(0x01)
	char pad_1b1[0x4f]; // 0x1b1(0x4f)
};

// Class MovieRenderPipelineCore.MoviePipelineOutputSetting
// Size: 0x120 (Inherited: 0xc0)
struct UMoviePipelineOutputSetting : UMoviePipelineSetting {
	struct FDirectoryPath OutputDirectory; // 0xb8(0x10)
	struct FString FileNameFormat; // 0xc8(0x10)
	struct FIntPoint OutputResolution; // 0xd8(0x08)
	bool bUseCustomFrameRate; // 0xe0(0x01)
	struct FFrameRate OutputFrameRate; // 0xe4(0x08)
	bool bOverrideExistingOutput; // 0xf0(0x01)
	char pad_f2[0x2]; // 0xf2(0x02)
	int32_t HandleFrameCount; // 0xf4(0x04)
	int32_t OutputFrameStep; // 0xf8(0x04)
	bool bUseCustomPlaybackRange; // 0xfc(0x01)
	char pad_fd[0x3]; // 0xfd(0x03)
	int32_t CustomStartFrame; // 0x100(0x04)
	int32_t CustomEndFrame; // 0x104(0x04)
	int32_t VersionNumber; // 0x108(0x04)
	bool bAutoVersion; // 0x10c(0x01)
	char pad_10d[0x3]; // 0x10d(0x03)
	int32_t ZeroPadFrameNumbers; // 0x110(0x04)
	int32_t FrameNumberOffset; // 0x114(0x04)
	bool bFlushDiskWritesPerShot; // 0x118(0x01)
	char pad_119[0x7]; // 0x119(0x07)
};

// Class MovieRenderPipelineCore.MoviePipelinePrimaryConfig
// Size: 0x150 (Inherited: 0xf0)
struct UMoviePipelinePrimaryConfig : UMoviePipelineConfigBase {
	struct TMap<struct FString, struct UMoviePipelineShotConfig*> PerShotConfigMapping; // 0xe8(0x50)
	struct UMoviePipelineOutputSetting* OutputSetting; // 0x138(0x08)
	struct TArray<struct UMoviePipelineSetting*> TransientSettings; // 0x140(0x10)

	void InitializeTransientSettings(); // Function MovieRenderPipelineCore.MoviePipelinePrimaryConfig.InitializeTransientSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x9b9d220
	struct TArray<struct UMoviePipelineSetting*> GetTransientSettings(); // Function MovieRenderPipelineCore.MoviePipelinePrimaryConfig.GetTransientSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bbe560
	struct FFrameRate GetEffectiveFrameRate(struct ULevelSequence* InSequence); // Function MovieRenderPipelineCore.MoviePipelinePrimaryConfig.GetEffectiveFrameRate // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9ba52c0
	struct TArray<struct UMoviePipelineSetting*> GetAllSettings(bool bIncludeDisabledSettings, bool bIncludeTransientSettings); // Function MovieRenderPipelineCore.MoviePipelinePrimaryConfig.GetAllSettings // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bc4e00
};

// Class MovieRenderPipelineCore.MoviePipelinePythonHostExecutor
// Size: 0x1a0 (Inherited: 0x190)
struct UMoviePipelinePythonHostExecutor : UMoviePipelineExecutorBase {
	struct UMoviePipelinePythonHostExecutor* ExecutorClass; // 0x188(0x08)
	struct UMoviePipelineQueue* PipelineQueue; // 0x190(0x08)
	struct UWorld* LastLoadedWorld; // 0x198(0x08)

	void OnMapLoad(struct UWorld* InWorld); // Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.OnMapLoad // (Native|Event|Public|BlueprintEvent) // @ game+0x2f74300
	struct UWorld* GetLastLoadedWorld(); // Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.GetLastLoadedWorld // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9baf480
	void ExecuteDelayed(struct UMoviePipelineQueue* InPipelineQueue); // Function MovieRenderPipelineCore.MoviePipelinePythonHostExecutor.ExecuteDelayed // (Native|Event|Public|BlueprintEvent) // @ game+0x9bb86a0
};

// Class MovieRenderPipelineCore.MoviePipelineExecutorShot
// Size: 0x200 (Inherited: 0xa0)
struct UMoviePipelineExecutorShot : UObject {
	bool bEnabled; // 0x98(0x01)
	struct FString OuterName; // 0xa0(0x10)
	struct FString InnerName; // 0xb0(0x10)
	struct TArray<struct FMoviePipelineSidecarCamera> SidecarCameras; // 0xc0(0x10)
	struct UMovieJobVariableAssignmentContainer* VariableAssignments; // 0xd0(0x08)
	char pad_d9[0xaf]; // 0xd9(0xaf)
	float Progress; // 0x188(0x04)
	char pad_18c[0x4]; // 0x18c(0x04)
	struct FString StatusMessage; // 0x190(0x10)
	struct UMoviePipelineShotConfig* ShotOverrideConfig; // 0x1a0(0x08)
	struct TSoftObjectPtr<UMoviePipelineShotConfig> ShotOverridePresetOrigin; // 0x1a8(0x28)
	struct UMovieGraphConfig* GraphConfig; // 0x1d0(0x08)
	struct TSoftObjectPtr<UMovieGraphConfig> GraphPreset; // 0x1d8(0x28)

	bool ShouldRender(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.ShouldRender // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x32a8840
	void SetStatusProgress(float InProgress); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetStatusProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x902c2f0
	void SetStatusMessage(struct FString InStatus); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetStatusMessage // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5a63520
	void SetShotOverridePresetOrigin(struct UMoviePipelineShotConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetShotOverridePresetOrigin // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd9180
	void SetShotOverrideConfiguration(struct UMoviePipelineShotConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetShotOverrideConfiguration // (Final|Native|Public|BlueprintCallable) // @ game+0x9bc5220
	void SetGraphPreset(struct UMovieGraphConfig* InGraphPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetGraphPreset // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb9310
	void SetGraphConfig(struct UMovieGraphConfig* InGraphConfig); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.SetGraphConfig // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb8600
	bool IsUsingGraphConfiguration(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.IsUsingGraphConfiguration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b9d0e0
	float GetStatusProgress(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetStatusProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x9b9c8b0
	struct FString GetStatusMessage(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetStatusMessage // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x5010990
	struct UMoviePipelineShotConfig* GetShotOverridePresetOrigin(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetShotOverridePresetOrigin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9baa7b0
	struct UMoviePipelineShotConfig* GetShotOverrideConfiguration(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetShotOverrideConfiguration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2517770
	struct UMovieGraphConfig* GetGraphPreset(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetGraphPreset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b9ef80
	struct UMovieGraphConfig* GetGraphConfig(); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetGraphConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bae2d0
	struct FString GetCameraName(int32_t InCameraIndex); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.GetCameraName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bc6240
	struct UMoviePipelineShotConfig* AllocateNewShotOverrideConfig(struct UMoviePipelineShotConfig* InConfigType); // Function MovieRenderPipelineCore.MoviePipelineExecutorShot.AllocateNewShotOverrideConfig // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba44a0
};

// Class MovieRenderPipelineCore.MoviePipelineExecutorJob
// Size: 0x1b0 (Inherited: 0xa0)
struct UMoviePipelineExecutorJob : UObject {
	struct FString JobName; // 0x98(0x10)
	struct FSoftObjectPath Sequence; // 0xa8(0x20)
	struct FSoftObjectPath Map; // 0xc8(0x20)
	struct FString Author; // 0xe8(0x10)
	struct FString Comment; // 0xf8(0x10)
	struct TArray<struct UMoviePipelineExecutorShot*> ShotInfo; // 0x108(0x10)
	struct FString UserData; // 0x118(0x10)
	struct UMovieJobVariableAssignmentContainer* VariableAssignments; // 0x128(0x08)
	struct FString StatusMessage; // 0x130(0x10)
	float StatusProgress; // 0x140(0x04)
	bool bIsConsumed; // 0x144(0x01)
	struct UMoviePipelinePrimaryConfig* Configuration; // 0x148(0x08)
	struct TSoftObjectPtr<UMoviePipelinePrimaryConfig> PresetOrigin; // 0x150(0x28)
	bool bEnabled; // 0x178(0x01)
	char pad_17e[0x2]; // 0x17e(0x02)
	struct UMovieGraphConfig* GraphConfig; // 0x180(0x08)
	struct TSoftObjectPtr<UMovieGraphConfig> GraphPreset; // 0x188(0x28)

	void SetStatusProgress(float InProgress); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetStatusProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x902c2f0
	void SetStatusMessage(struct FString InStatus); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetStatusMessage // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x5a63520
	void SetSequence(struct FSoftObjectPath InSequence); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetSequence // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9badbc0
	void SetPresetOrigin(struct UMoviePipelinePrimaryConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetPresetOrigin // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd1f30
	void SetIsEnabled(bool bInEnabled); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetIsEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2f21150
	void SetGraphPreset(struct UMovieGraphConfig* InGraphPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetGraphPreset // (Final|Native|Public|BlueprintCallable) // @ game+0x9b9fa90
	void SetGraphConfig(struct UMovieGraphConfig* InGraphConfig); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetGraphConfig // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba7100
	void SetConsumed(bool bInConsumed); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetConsumed // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x9bd5e40
	void SetConfiguration(struct UMoviePipelinePrimaryConfig* InPreset); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.SetConfiguration // (Final|Native|Public|BlueprintCallable) // @ game+0x9be00c0
	void OnDuplicated(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.OnDuplicated // (Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x16fe6f0
	bool IsUsingGraphConfiguration(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.IsUsingGraphConfiguration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bc05e0
	bool IsEnabled(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.IsEnabled // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x340c590
	bool IsConsumed(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.IsConsumed // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2cd3930
	float GetStatusProgress(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetStatusProgress // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x9b9d070
	struct FString GetStatusMessage(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetStatusMessage // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x9bd9000
	struct UMoviePipelinePrimaryConfig* GetPresetOrigin(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetPresetOrigin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bb11e0
	struct UMovieGraphConfig* GetGraphPreset(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetGraphPreset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9ba9590
	struct UMovieGraphConfig* GetGraphConfig(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetGraphConfig // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bbf1b0
	struct UMoviePipelinePrimaryConfig* GetConfiguration(); // Function MovieRenderPipelineCore.MoviePipelineExecutorJob.GetConfiguration // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2f77df0
};

// Class MovieRenderPipelineCore.MoviePipelineQueue
// Size: 0xe0 (Inherited: 0xa0)
struct UMoviePipelineQueue : UObject {
	struct TArray<struct UMoviePipelineExecutorJob*> Jobs; // 0x98(0x10)
	struct TSoftObjectPtr<UMoviePipelineQueue> QueueOrigin; // 0xa8(0x28)
	char pad_d8[0x8]; // 0xd8(0x08)

	void SetQueueOrigin(struct UMoviePipelineQueue* InConfig); // Function MovieRenderPipelineCore.MoviePipelineQueue.SetQueueOrigin // (Final|Native|Public|BlueprintCallable) // @ game+0x9bdf650
	void SetJobIndex(struct UMoviePipelineExecutorJob* InJob, int32_t Index); // Function MovieRenderPipelineCore.MoviePipelineQueue.SetJobIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd5f30
	struct UMoviePipelineQueue* GetQueueOrigin(); // Function MovieRenderPipelineCore.MoviePipelineQueue.GetQueueOrigin // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9ba6280
	struct TArray<struct UMoviePipelineExecutorJob*> GetJobs(); // Function MovieRenderPipelineCore.MoviePipelineQueue.GetJobs // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9b51b60
	struct UMoviePipelineExecutorJob* DuplicateJob(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineQueue.DuplicateJob // (Final|Native|Public|BlueprintCallable) // @ game+0x9ba1360
	void DeleteJob(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineQueue.DeleteJob // (Final|Native|Public|BlueprintCallable) // @ game+0x9bba2d0
	void DeleteAllJobs(); // Function MovieRenderPipelineCore.MoviePipelineQueue.DeleteAllJobs // (Final|Native|Public|BlueprintCallable) // @ game+0x9b9ff40
	void CopyFrom(struct UMoviePipelineQueue* InQueue); // Function MovieRenderPipelineCore.MoviePipelineQueue.CopyFrom // (Final|Native|Public|BlueprintCallable) // @ game+0x9bd9c70
	struct UMoviePipelineExecutorJob* AllocateNewJob(struct UMoviePipelineExecutorJob* InJobType); // Function MovieRenderPipelineCore.MoviePipelineQueue.AllocateNewJob // (Final|Native|Public|BlueprintCallable) // @ game+0x9bba150
};

// Class MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem
// Size: 0x100 (Inherited: 0xa0)
struct UMoviePipelineQueueEngineSubsystem : UEngineSubsystem {
	struct FMulticastInlineDelegate OnRenderFinished; // 0xa0(0x10)
	struct UMoviePipelineExecutorBase* ActiveExecutor; // 0xb0(0x08)
	struct UMoviePipelineQueue* CurrentQueue; // 0xb8(0x08)
	char pad_c0[0x40]; // 0xc0(0x40)

	void SetConfiguration(struct UMovieRenderDebugWidget* InProgressWidgetClass, bool bRenderPlayerViewport); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.SetConfiguration // (Final|Native|Public|BlueprintCallable) // @ game+0x9bcff20
	void RenderQueueWithExecutorInstance(struct UMoviePipelineExecutorBase* InExecutor); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderQueueWithExecutorInstance // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb7f30
	struct UMoviePipelineExecutorBase* RenderQueueWithExecutor(struct UMoviePipelineExecutorBase* InExecutorType); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderQueueWithExecutor // (Final|Native|Public|BlueprintCallable) // @ game+0x9bdb9e0
	void RenderJob(struct UMoviePipelineExecutorJob* InJob); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.RenderJob // (Final|Native|Public|BlueprintCallable) // @ game+0x9bb94f0
	bool IsRendering(); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.IsRendering // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bcdf90
	struct UMoviePipelineQueue* GetQueue(); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.GetQueue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9bc5b40
	struct UMoviePipelineExecutorBase* GetActiveExecutor(); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.GetActiveExecutor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2534ea0
	struct UMoviePipelineExecutorJob* AllocateJob(struct ULevelSequence* InSequence); // Function MovieRenderPipelineCore.MoviePipelineQueueEngineSubsystem.AllocateJob // (Final|Native|Public|BlueprintCallable) // @ game+0x9bc5e40
};

// Class MovieRenderPipelineCore.MoviePipelineRenderPass
// Size: 0xc0 (Inherited: 0xc0)
struct UMoviePipelineRenderPass : UMoviePipelineSetting {
};

// Class MovieRenderPipelineCore.MoviePipelineShotConfig
// Size: 0xf0 (Inherited: 0xf0)
struct UMoviePipelineShotConfig : UMoviePipelineConfigBase {
};

// Class MovieRenderPipelineCore.MoviePipelineVideoOutputBase
// Size: 0x100 (Inherited: 0xc0)
struct UMoviePipelineVideoOutputBase : UMoviePipelineOutputBase {
	char pad_c0[0x40]; // 0xc0(0x40)
};

