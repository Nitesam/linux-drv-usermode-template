// Class DataflowEnginePlugin.DataflowActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADataflowActor : AActor {
	struct UDataflowComponent* DataflowComponent; // 0x398(0x08)
};

// Class DataflowEnginePlugin.DataflowComponent
// Size: 0x800 (Inherited: 0x6c0)
struct UDataflowComponent : UPrimitiveComponent {
	char pad_6c0[0x140]; // 0x6c0(0x140)
};

