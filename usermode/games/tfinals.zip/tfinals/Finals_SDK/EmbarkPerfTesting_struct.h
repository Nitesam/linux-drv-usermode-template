// Enum EmbarkPerfTesting.EEmbarkPerfTestRoleExecutable
enum class EEmbarkPerfTestRoleExecutable : uint8_t {
	Client = 0,
	Server = 1,
	EEmbarkPerfTestRoleExecutable_MAX = 2
};

// Enum EmbarkPerfTesting.EUnrealInsightsCommand
enum class EUnrealInsightsCommand : uint8_t {
	ExportTimerStatistics = 0,
	ExportCounters = 1,
	EUnrealInsightsCommand_MAX = 2
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestSnapshotContext
// Size: 0x88 (Inherited: 0x00)
struct FEmbarkPerfTestSnapshotContext {
	char pad_0[0xc]; // 0x00(0x0c)
	float CurrentTimeSeconds; // 0x0c(0x04)
	struct FEmbarkPerfTestSnapshotConfig Config; // 0x10(0x28)
	struct TMap<struct FString, struct FString> MetaData; // 0x38(0x50)
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestSnapshotConfig
// Size: 0x28 (Inherited: 0x00)
struct FEmbarkPerfTestSnapshotConfig {
	struct FString Name; // 0x00(0x10)
	float DurationSeconds; // 0x10(0x04)
	bool bStartScreenshot; // 0x14(0x01)
	bool bEndScreenshot; // 0x15(0x01)
	bool bAddTraceBookmarks; // 0x16(0x01)
	bool bAddRegion; // 0x17(0x01)
	struct FName StepMethod; // 0x18(0x08)
	bool bGeneratesSubsteps; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestRunGlobalParams
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkPerfTestRunGlobalParams {
	struct FString TestServerAddress; // 0x00(0x10)
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestRole
// Size: 0x68 (Inherited: 0x00)
struct FEmbarkPerfTestRole {
	enum class EEmbarkPerfTestRoleExecutable ExecutableType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<struct FString, struct FString> Arguments; // 0x08(0x50)
	struct TArray<struct FString> CommandLineSwitches; // 0x58(0x10)
};

// ScriptStruct EmbarkPerfTesting.EmbarkUnrealInsightCommandRequest
// Size: 0x30 (Inherited: 0x00)
struct FEmbarkUnrealInsightCommandRequest {
	enum class EUnrealInsightsCommand Command; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FString> Timers; // 0x08(0x10)
	struct TArray<struct FString> Counters; // 0x18(0x10)
	bool bUsesRegions; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestGauntletScenario
// Size: 0xc8 (Inherited: 0x00)
struct FEmbarkPerfTestGauntletScenario {
	struct FString TestAssetPath; // 0x00(0x10)
	struct FString ScenarioKey; // 0x10(0x10)
	struct TArray<struct FEmbarkPerfTestRole> Roles; // 0x20(0x10)
	struct FString ReportedWorld; // 0x30(0x10)
	struct FString ReportedTestName; // 0x40(0x10)
	struct TMap<struct FString, struct FString> MetaData; // 0x50(0x50)
	enum class EEmbarkPerfTestRoleExecutable Driver; // 0xa0(0x01)
	bool bIsCritical; // 0xa1(0x01)
	char pad_a2[0x6]; // 0xa2(0x06)
	struct TArray<struct FEmbarkUnrealInsightCommandRequest> UnrealInsightCommands; // 0xa8(0x10)
	struct TArray<struct FString> MemreportStatsToExport; // 0xb8(0x10)
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestGauntletSuite
// Size: 0x10 (Inherited: 0x00)
struct FEmbarkPerfTestGauntletSuite {
	struct TArray<struct FEmbarkPerfTestGauntletScenario> Scenarios; // 0x00(0x10)
};

// ScriptStruct EmbarkPerfTesting.EmbarkPerfTestScenarioWrapper
// Size: 0x18 (Inherited: 0x00)
struct FEmbarkPerfTestScenarioWrapper {
	struct FString Key; // 0x00(0x10)
	struct UIEmbarkPerfTestRunScenario* Scenario; // 0x10(0x08)
};

