// Class ImgMedia.ImgMediaSource
// Size: 0x140 (Inherited: 0x100)
struct UImgMediaSource : UBaseMediaSource {
	bool IsPathRelativeToProjectRoot; // 0xf8(0x01)
	struct FFrameRate FrameRateOverride; // 0xfc(0x08)
	struct FString ProxyOverride; // 0x108(0x10)
	bool bFillGapsInSequence; // 0x118(0x01)
	char pad_11a[0x6]; // 0x11a(0x06)
	struct FDirectoryPath SequencePath; // 0x120(0x10)
	char pad_130[0x10]; // 0x130(0x10)

	void SetTokenizedSequencePath(struct FString Path); // Function ImgMedia.ImgMediaSource.SetTokenizedSequencePath // (Final|Native|Public|BlueprintCallable) // @ game+0x9abdec0
	void SetSequencePath(struct FString Path); // Function ImgMedia.ImgMediaSource.SetSequencePath // (Final|Native|Public|BlueprintCallable) // @ game+0x9aa10a0
	void SetMipLevelDistance(float Distance); // Function ImgMedia.ImgMediaSource.SetMipLevelDistance // (Final|Native|Public|BlueprintCallable) // @ game+0x2e7fe30
	void RemoveTargetObject(struct AActor* InActor); // Function ImgMedia.ImgMediaSource.RemoveTargetObject // (Final|Native|Public|BlueprintCallable) // @ game+0x9ab7700
	void RemoveGlobalCamera(struct AActor* InActor); // Function ImgMedia.ImgMediaSource.RemoveGlobalCamera // (Final|Native|Public|BlueprintCallable) // @ game+0x257bb60
	struct FString GetSequencePath(); // Function ImgMedia.ImgMediaSource.GetSequencePath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9aa25a0
	void GetProxies(struct TArray<struct FString>& OutProxies); // Function ImgMedia.ImgMediaSource.GetProxies // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9aa14f0
	void AddTargetObject(struct AActor* InActor); // Function ImgMedia.ImgMediaSource.AddTargetObject // (Final|Native|Public|BlueprintCallable) // @ game+0x9ab1480
	void AddGlobalCamera(struct AActor* InActor); // Function ImgMedia.ImgMediaSource.AddGlobalCamera // (Final|Native|Public|BlueprintCallable) // @ game+0x257bb60
};

