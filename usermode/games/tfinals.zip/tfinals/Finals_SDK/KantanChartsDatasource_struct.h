// ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// Size: 0x10 (Inherited: 0x00)
struct FKantanCartesianDatapoint {
	struct FVector2D Coords; // 0x00(0x10)
};

