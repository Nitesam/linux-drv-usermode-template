// ScriptStruct ConsoleVariablesEditorRuntime.ConsoleVariablesEditorAssetSaveData
// Size: 0x28 (Inherited: 0x00)
struct FConsoleVariablesEditorAssetSaveData {
	struct FString CommandName; // 0x00(0x10)
	struct FString CommandValueAsString; // 0x10(0x10)
	enum class ECheckBoxState CheckedState; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

