// Class ClothingSystemRuntimeCommon.ClothConfigCommon
// Size: 0xa0 (Inherited: 0xa0)
struct UClothConfigCommon : UClothConfigBase {
};

// Class ClothingSystemRuntimeCommon.ClothSharedConfigCommon
// Size: 0xa0 (Inherited: 0xa0)
struct UClothSharedConfigCommon : UClothConfigCommon {
};

// Class ClothingSystemRuntimeCommon.ClothingAssetCustomData
// Size: 0xa0 (Inherited: 0xa0)
struct UClothingAssetCustomData : UObject {
};

// Class ClothingSystemRuntimeCommon.ClothingAssetCommon
// Size: 0x180 (Inherited: 0xd0)
struct UClothingAssetCommon : UClothingAssetBase {
	struct UPhysicsAsset* PhysicsAsset; // 0xc8(0x08)
	struct TMap<struct FName, struct UClothConfigBase*> ClothConfigs; // 0xd0(0x50)
	struct TArray<struct FClothLODDataCommon> LODData; // 0x120(0x10)
	struct TArray<int32_t> LodMap; // 0x130(0x10)
	struct TArray<struct FName> UsedBoneNames; // 0x140(0x10)
	struct TArray<int32_t> UsedBoneIndices; // 0x150(0x10)
	int32_t ReferenceBoneIndex; // 0x160(0x04)
	struct UClothingAssetCustomData* CustomData; // 0x168(0x08)
	bool bIsCopiedFromDifferentSkeletalMesh; // 0x170(0x01)
	char pad_175[0xb]; // 0x175(0x0b)
};

// Class ClothingSystemRuntimeCommon.ClothLODDataCommon_Legacy
// Size: 0x200 (Inherited: 0xa0)
struct UClothLODDataCommon_Legacy : UObject {
	struct UClothPhysicalMeshDataBase_Legacy* PhysicalMeshData; // 0x98(0x08)
	struct FClothPhysicalMeshData ClothPhysicalMeshData; // 0xa0(0xf8)
	struct FClothCollisionData CollisionData; // 0x198(0x40)
	char pad_1e0[0x20]; // 0x1e0(0x20)
};

