// Class CinematicCamera.CameraRig_Crane
// Size: 0x3d0 (Inherited: 0x3a0)
struct ACameraRig_Crane : AActor {
	float CranePitch; // 0x398(0x04)
	float CraneYaw; // 0x39c(0x04)
	float CraneArmLength; // 0x3a0(0x04)
	bool bLockMountPitch; // 0x3a4(0x01)
	bool bLockMountYaw; // 0x3a5(0x01)
	struct USceneComponent* TransformComponent; // 0x3a8(0x08)
	struct USceneComponent* CraneYawControl; // 0x3b0(0x08)
	struct USceneComponent* CranePitchControl; // 0x3b8(0x08)
	struct USceneComponent* CraneCameraMount; // 0x3c0(0x08)
	char pad_3ce[0x2]; // 0x3ce(0x02)
};

// Class CinematicCamera.CameraRig_Rail
// Size: 0x3c0 (Inherited: 0x3a0)
struct ACameraRig_Rail : AActor {
	float CurrentPositionOnRail; // 0x398(0x04)
	bool bLockOrientationToRail; // 0x39c(0x01)
	struct USceneComponent* TransformComponent; // 0x3a0(0x08)
	struct USplineComponent* RailSplineComponent; // 0x3a8(0x08)
	struct USceneComponent* RailCameraMount; // 0x3b0(0x08)
	char pad_3bd[0x3]; // 0x3bd(0x03)

	struct USplineComponent* GetRailSplineComponent(); // Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x2a6c9b0
};

// Class CinematicCamera.CineCameraActor
// Size: 0xb30 (Inherited: 0xab0)
struct ACineCameraActor : ACameraActor {
	struct FCameraLookatTrackingSettings LookatTrackingSettings; // 0xab0(0x68)
	char pad_b18[0x18]; // 0xb18(0x18)

	struct UCineCameraComponent* GetCineCameraComponent(); // Function CinematicCamera.CineCameraActor.GetCineCameraComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a666c0
};

// Class CinematicCamera.CineCameraComponent
// Size: 0xc70 (Inherited: 0xb60)
struct UCineCameraComponent : UCameraComponent {
	struct FCameraFilmbackSettings FilmbackSettings; // 0xb60(0x0c)
	struct FCameraFilmbackSettings Filmback; // 0xb6c(0x0c)
	struct FCameraLensSettings LensSettings; // 0xb78(0x1c)
	char pad_b94[0x4]; // 0xb94(0x04)
	struct FCameraFocusSettings FocusSettings; // 0xb98(0x60)
	struct FPlateCropSettings CropSettings; // 0xbf8(0x04)
	float CurrentFocalLength; // 0xbfc(0x04)
	float CurrentAperture; // 0xc00(0x04)
	float CurrentFocusDistance; // 0xc04(0x04)
	char bOverride_CustomNearClippingPlane : 1; // 0xc08(0x01)
	char pad_c08_1 : 7; // 0xc08(0x01)
	char pad_c09[0x3]; // 0xc09(0x03)
	float CustomNearClippingPlane; // 0xc0c(0x04)
	char pad_c10[0x8]; // 0xc10(0x08)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0xc18(0x10)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0xc28(0x10)
	struct FString DefaultFilmbackPresetName; // 0xc38(0x10)
	struct FString DefaultFilmbackPreset; // 0xc48(0x10)
	struct FString DefaultLensPresetName; // 0xc58(0x10)
	float DefaultLensFocalLength; // 0xc68(0x04)
	float DefaultLensFStop; // 0xc6c(0x04)

	void SetLensSettings(struct FCameraLensSettings& NewLensSettings); // Function CinematicCamera.CineCameraComponent.SetLensSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a6ba50
	void SetLensPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetLensPresetByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a6ef90
	void SetFocusSettings(struct FCameraFocusSettings& NewFocusSettings); // Function CinematicCamera.CineCameraComponent.SetFocusSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a68830
	void SetFilmbackPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a6e520
	void SetFilmback(struct FCameraFilmbackSettings& NewFilmback); // Function CinematicCamera.CineCameraComponent.SetFilmback // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a710a0
	void SetCustomNearClippingPlane(float NewCustomNearClippingPlane); // Function CinematicCamera.CineCameraComponent.SetCustomNearClippingPlane // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a6dcd0
	void SetCurrentFocalLength(float InFocalLength); // Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a69f40
	void SetCurrentAperture(float NewCurrentAperture); // Function CinematicCamera.CineCameraComponent.SetCurrentAperture // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a6dc20
	void SetCropSettings(struct FPlateCropSettings& NewCropSettings); // Function CinematicCamera.CineCameraComponent.SetCropSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a67d50
	void SetCropPresetByName(struct FString InPresetName); // Function CinematicCamera.CineCameraComponent.SetCropPresetByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2a672a0
	float GetVerticalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a68a70
	struct TArray<struct FNamedLensPreset> GetLensPresetsCopy(); // Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a6a1f0
	struct FString GetLensPresetName(); // Function CinematicCamera.CineCameraComponent.GetLensPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a65cf0
	float GetHorizontalFieldOfView(); // Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a6eae0
	struct TArray<struct FNamedFilmbackPreset> GetFilmbackPresetsCopy(); // Function CinematicCamera.CineCameraComponent.GetFilmbackPresetsCopy // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x2a69640
	struct FString GetFilmbackPresetName(); // Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a6c1d0
	struct FString GetDefaultFilmbackPresetName(); // Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a6b1a0
	struct FString GetCropPresetName(); // Function CinematicCamera.CineCameraComponent.GetCropPresetName // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2a67360
};

// Class CinematicCamera.CineCameraSettings
// Size: 0x120 (Inherited: 0xb0)
struct UCineCameraSettings : UDeveloperSettings {
	struct FString DefaultLensPresetName; // 0xa8(0x10)
	float DefaultLensFocalLength; // 0xb8(0x04)
	float DefaultLensFStop; // 0xbc(0x04)
	struct TArray<struct FNamedLensPreset> LensPresets; // 0xc0(0x10)
	struct FString DefaultFilmbackPreset; // 0xd0(0x10)
	struct TArray<struct FNamedFilmbackPreset> FilmbackPresets; // 0xe0(0x10)
	struct FString DefaultCropPresetName; // 0xf0(0x10)
	struct TArray<struct FNamedPlateCropPreset> CropPresets; // 0x100(0x10)
	char pad_118[0x8]; // 0x118(0x08)

	void SetLensPresets(struct TArray<struct FNamedLensPreset>& InLensPresets); // Function CinematicCamera.CineCameraSettings.SetLensPresets // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x2a6b290
	void SetFilmbackPresets(struct TArray<struct FNamedFilmbackPreset>& InFilmbackPresets); // Function CinematicCamera.CineCameraSettings.SetFilmbackPresets // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x2a64960
	void SetDefaultLensPresetName(struct FString InDefaultLensPresetName); // Function CinematicCamera.CineCameraSettings.SetDefaultLensPresetName // (Final|Native|Private|BlueprintCallable) // @ game+0x2a69bc0
	void SetDefaultLensFStop(float InDefaultLensFStop); // Function CinematicCamera.CineCameraSettings.SetDefaultLensFStop // (Final|Native|Private|BlueprintCallable) // @ game+0x2a69ff0
	void SetDefaultLensFocalLength(float InDefaultLensFocalLength); // Function CinematicCamera.CineCameraSettings.SetDefaultLensFocalLength // (Final|Native|Private|BlueprintCallable) // @ game+0x2a65000
	void SetDefaultFilmbackPreset(struct FString InDefaultFilmbackPreset); // Function CinematicCamera.CineCameraSettings.SetDefaultFilmbackPreset // (Final|Native|Private|BlueprintCallable) // @ game+0x2a6e0c0
	void SetDefaultCropPresetName(struct FString InDefaultCropPresetName); // Function CinematicCamera.CineCameraSettings.SetDefaultCropPresetName // (Final|Native|Private|BlueprintCallable) // @ game+0x2a6a340
	void SetCropPresets(struct TArray<struct FNamedPlateCropPreset>& InCropPresets); // Function CinematicCamera.CineCameraSettings.SetCropPresets // (Final|Native|Private|HasOutParms|BlueprintCallable) // @ game+0x2a6dfb0
	struct TArray<struct FString> GetLensPresetNames(); // Function CinematicCamera.CineCameraSettings.GetLensPresetNames // (Final|Native|Private|Const) // @ game+0x2a65970
	bool GetLensPresetByName(struct FString PresetName, struct FCameraLensSettings& LensSettings); // Function CinematicCamera.CineCameraSettings.GetLensPresetByName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a6b5f0
	struct TArray<struct FString> GetFilmbackPresetNames(); // Function CinematicCamera.CineCameraSettings.GetFilmbackPresetNames // (Final|Native|Private|Const) // @ game+0x2a65b40
	bool GetFilmbackPresetByName(struct FString PresetName, struct FCameraFilmbackSettings& FilmbackSettings); // Function CinematicCamera.CineCameraSettings.GetFilmbackPresetByName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a678f0
	struct TArray<struct FString> GetCropPresetNames(); // Function CinematicCamera.CineCameraSettings.GetCropPresetNames // (Final|Native|Private|Const) // @ game+0x2a6c440
	bool GetCropPresetByName(struct FString PresetName, struct FPlateCropSettings& CropSettings); // Function CinematicCamera.CineCameraSettings.GetCropPresetByName // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x2a6b8f0
	struct UCineCameraSettings* GetCineCameraSettings(); // Function CinematicCamera.CineCameraSettings.GetCineCameraSettings // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x2a6e9b0
};

