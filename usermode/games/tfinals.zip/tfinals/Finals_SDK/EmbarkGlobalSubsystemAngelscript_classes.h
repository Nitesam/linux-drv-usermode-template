// Class EmbarkGlobalSubsystemAngelscript.SubsystemFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USubsystemFunctionLibrary : UObject {

	struct UEmbarkGlobalSubsystem* GetGlobalSubsystem(struct UEmbarkGlobalSubsystem* SubsystemClass); // Function EmbarkGlobalSubsystemAngelscript.SubsystemFunctionLibrary.GetGlobalSubsystem // (Final|Native|Static|Public) // @ game+0x695c360
};

