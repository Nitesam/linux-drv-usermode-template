// Class IKRig.IKGoalCreatorInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UIKGoalCreatorInterface : UInterface {

	void AddIKGoals(struct TMap<struct FName, struct FIKRigGoal>& OutGoals); // Function IKRig.IKGoalCreatorInterface.AddIKGoals // (Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x97690d0
};

// Class IKRig.IKRigComponent
// Size: 0x170 (Inherited: 0x160)
struct UIKRigComponent : UActorComponent {
	char pad_160[0x10]; // 0x160(0x10)

	void SetIKRigGoalTransform(struct FName GoalName, struct FTransform Transform, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9743340
	void SetIKRigGoalPositionAndRotation(struct FName GoalName, struct FVector Position, struct FQuat Rotation, float PositionAlpha, float RotationAlpha); // Function IKRig.IKRigComponent.SetIKRigGoalPositionAndRotation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x97692c0
	void SetIKRigGoal(struct FIKRigGoal& Goal); // Function IKRig.IKRigComponent.SetIKRigGoal // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9744200
	void ClearAllGoals(); // Function IKRig.IKRigComponent.ClearAllGoals // (Final|Native|Public|BlueprintCallable) // @ game+0x974faa0
};

// Class IKRig.RetargetChainSettings
// Size: 0x150 (Inherited: 0xa0)
struct URetargetChainSettings : UObject {
	struct FName SourceChain; // 0x98(0x08)
	struct FName TargetChain; // 0xa0(0x08)
	struct FTargetChainSettings Settings; // 0xa8(0xa8)
};

// Class IKRig.RetargetRootSettings
// Size: 0x100 (Inherited: 0xa0)
struct URetargetRootSettings : UObject {
	struct FTargetRootSettings Settings; // 0x98(0x68)
};

// Class IKRig.IKRetargetGlobalSettings
// Size: 0xc0 (Inherited: 0xa0)
struct UIKRetargetGlobalSettings : UObject {
	struct FRetargetGlobalSettings Settings; // 0x98(0x20)
};

// Class IKRig.IKRetargeter
// Size: 0x280 (Inherited: 0xa0)
struct UIKRetargeter : UObject {
	struct TSoftObjectPtr<UIKRigDefinition> SourceIKRigAsset; // 0x98(0x28)
	struct TSoftObjectPtr<UIKRigDefinition> TargetIKRigAsset; // 0xc0(0x28)
	struct TArray<struct FRetargetChainMap> ChainMapping; // 0xe8(0x10)
	struct TArray<struct URetargetChainSettings*> ChainSettings; // 0xf8(0x10)
	struct URetargetRootSettings* RootSettings; // 0x108(0x08)
	struct UIKRetargetGlobalSettings* GlobalSettings; // 0x110(0x08)
	struct TMap<struct FName, struct FRetargetProfile> Profiles; // 0x118(0x50)
	struct FName CurrentProfile; // 0x168(0x08)
	struct TMap<struct FName, struct FIKRetargetPose> SourceRetargetPoses; // 0x170(0x50)
	struct TMap<struct FName, struct FIKRetargetPose> TargetRetargetPoses; // 0x1c0(0x50)
	struct FName CurrentSourceRetargetPose; // 0x210(0x08)
	struct FName CurrentTargetRetargetPose; // 0x218(0x08)
	struct TMap<struct FName, struct FIKRetargetPose> RetargetPoses; // 0x220(0x50)
	struct FName CurrentRetargetPose; // 0x270(0x08)

	void SetRootSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetRootSettings& RootSettings); // Function IKRig.IKRetargeter.SetRootSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x976c380
	void SetGlobalSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FRetargetGlobalSettings& GlobalSettings); // Function IKRig.IKRetargeter.SetGlobalSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9749310
	void SetChainSpeedPlantSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainSpeedPlantSettings& SpeedPlantSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainSpeedPlantSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9768010
	void SetChainSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainSettings& ChainSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9752ba0
	void SetChainIKSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainIKSettings& IKSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainIKSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9769660
	void SetChainFKSettingsInRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FTargetChainFKSettings& FKSettings, struct FName TargetChainName); // Function IKRig.IKRetargeter.SetChainFKSettingsInRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9748ec0
	struct FTargetRootSettings GetRootSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile); // Function IKRig.IKRetargeter.GetRootSettingsFromRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9748270
	void GetRootSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName OptionalProfileName, struct FTargetRootSettings& OutSettings); // Function IKRig.IKRetargeter.GetRootSettingsFromRetargetAsset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x975d860
	struct FRetargetGlobalSettings GetGlobalSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile); // Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x974bd10
	void GetGlobalSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName OptionalProfileName, struct FRetargetGlobalSettings& OutSettings); // Function IKRig.IKRetargeter.GetGlobalSettingsFromRetargetAsset // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9765d40
	struct FTargetChainSettings GetChainUsingGoalFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName IKGoalName); // Function IKRig.IKRetargeter.GetChainUsingGoalFromRetargetAsset // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9777960
	struct FTargetChainSettings GetChainSettingsFromRetargetProfile(struct FRetargetProfile& RetargetProfile, struct FName TargetChainName); // Function IKRig.IKRetargeter.GetChainSettingsFromRetargetProfile // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x974ab60
	struct FTargetChainSettings GetChainSettingsFromRetargetAsset(struct UIKRetargeter* RetargetAsset, struct FName TargetChainName, struct FName OptionalProfileName); // Function IKRig.IKRetargeter.GetChainSettingsFromRetargetAsset // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x9766040
};

// Class IKRig.IKRetargetProcessor
// Size: 0x3e0 (Inherited: 0xa0)
struct UIKRetargetProcessor : UObject {
	char pad_a0[0x140]; // 0xa0(0x140)
	struct UIKRigProcessor* IKRigProcessor; // 0x1e0(0x08)
	char pad_1e8[0x1f8]; // 0x1e8(0x1f8)
};

// Class IKRig.IKRigEffectorGoal
// Size: 0x170 (Inherited: 0xa0)
struct UIKRigEffectorGoal : UObject {
	struct FName GoalName; // 0x98(0x08)
	struct FName BoneName; // 0xa0(0x08)
	float PositionAlpha; // 0xa8(0x04)
	float RotationAlpha; // 0xac(0x04)
	struct FTransform CurrentTransform; // 0xb0(0x60)
	struct FTransform InitialTransform; // 0x110(0x60)
};

// Class IKRig.IKRigDefinition
// Size: 0x170 (Inherited: 0xa0)
struct UIKRigDefinition : UObject {
	struct TSoftObjectPtr<USkeletalMesh> PreviewSkeletalMesh; // 0xa0(0x28)
	struct FIKRigSkeleton Skeleton; // 0xc8(0x70)
	struct TArray<struct UIKRigEffectorGoal*> Goals; // 0x138(0x10)
	struct TArray<struct UIKRigSolver*> Solvers; // 0x148(0x10)
	struct FRetargetDefinition RetargetDefinition; // 0x158(0x18)
};

// Class IKRig.IKRigProcessor
// Size: 0x1c0 (Inherited: 0xa0)
struct UIKRigProcessor : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)
	struct TArray<struct UIKRigSolver*> Solvers; // 0xd0(0x10)
	char pad_e0[0xe0]; // 0xe0(0xe0)
};

// Class IKRig.IKRigSolver
// Size: 0xa0 (Inherited: 0xa0)
struct UIKRigSolver : UObject {
	bool bIsEnabled; // 0x98(0x01)
};

// Class IKRig.IKRig_BodyMoverEffector
// Size: 0xb0 (Inherited: 0xa0)
struct UIKRig_BodyMoverEffector : UObject {
	struct FName GoalName; // 0x98(0x08)
	struct FName BoneName; // 0xa0(0x08)
	float InfluenceMultiplier; // 0xa8(0x04)
};

// Class IKRig.IKRig_BodyMover
// Size: 0xf0 (Inherited: 0xa0)
struct UIKRig_BodyMover : UIKRigSolver {
	struct FName RootBone; // 0xa0(0x08)
	float PositionAlpha; // 0xa8(0x04)
	float PositionPositiveX; // 0xac(0x04)
	float PositionNegativeX; // 0xb0(0x04)
	float PositionPositiveY; // 0xb4(0x04)
	float PositionNegativeY; // 0xb8(0x04)
	float PositionPositiveZ; // 0xbc(0x04)
	float PositionNegativeZ; // 0xc0(0x04)
	float RotationAlpha; // 0xc4(0x04)
	float RotateXAlpha; // 0xc8(0x04)
	float RotateYAlpha; // 0xcc(0x04)
	float RotateZAlpha; // 0xd0(0x04)
	char pad_d4[0x4]; // 0xd4(0x04)
	struct TArray<struct UIKRig_BodyMoverEffector*> Effectors; // 0xd8(0x10)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class IKRig.IKRig_LimbEffector
// Size: 0xb0 (Inherited: 0xa0)
struct UIKRig_LimbEffector : UObject {
	struct FName GoalName; // 0x98(0x08)
	struct FName BoneName; // 0xa0(0x08)
};

// Class IKRig.IKRig_LimbSolver
// Size: 0x100 (Inherited: 0xa0)
struct UIKRig_LimbSolver : UIKRigSolver {
	struct FName RootName; // 0xa0(0x08)
	float ReachPrecision; // 0xa8(0x04)
	enum class EAxis HingeRotationAxis; // 0xac(0x01)
	char pad_ad[0x3]; // 0xad(0x03)
	int32_t MaxIterations; // 0xb0(0x04)
	bool bEnableLimit; // 0xb4(0x01)
	char pad_b5[0x3]; // 0xb5(0x03)
	float MinRotationAngle; // 0xb8(0x04)
	bool bAveragePull; // 0xbc(0x01)
	char pad_bd[0x3]; // 0xbd(0x03)
	float PullDistribution; // 0xc0(0x04)
	float ReachStepAlpha; // 0xc4(0x04)
	bool bEnableTwistCorrection; // 0xc8(0x01)
	enum class EAxis EndBoneForwardAxis; // 0xc9(0x01)
	char pad_ca[0x6]; // 0xca(0x06)
	struct UIKRig_LimbEffector* Effector; // 0xd0(0x08)
	char pad_d8[0x28]; // 0xd8(0x28)
};

// Class IKRig.IKRig_FBIKEffector
// Size: 0xc0 (Inherited: 0xa0)
struct UIKRig_FBIKEffector : UObject {
	struct FName GoalName; // 0x98(0x08)
	struct FName BoneName; // 0xa0(0x08)
	float StrengthAlpha; // 0xa8(0x04)
	float PullChainAlpha; // 0xac(0x04)
	float PinRotation; // 0xb0(0x04)
	int32_t IndexInSolver; // 0xb4(0x04)
};

// Class IKRig.IKRig_FBIKBoneSettings
// Size: 0xf0 (Inherited: 0xa0)
struct UIKRig_FBIKBoneSettings : UObject {
	struct FName bone; // 0x98(0x08)
	float RotationStiffness; // 0xa0(0x04)
	float PositionStiffness; // 0xa4(0x04)
	enum class EPBIKLimitType X; // 0xa8(0x01)
	float MinX; // 0xac(0x04)
	float MaxX; // 0xb0(0x04)
	enum class EPBIKLimitType Y; // 0xb4(0x01)
	float MinY; // 0xb8(0x04)
	float MaxY; // 0xbc(0x04)
	enum class EPBIKLimitType Z; // 0xc0(0x01)
	char pad_c3[0x1]; // 0xc3(0x01)
	float MinZ; // 0xc4(0x04)
	float MaxZ; // 0xc8(0x04)
	bool bUsePreferredAngles; // 0xcc(0x01)
	char pad_cd[0x3]; // 0xcd(0x03)
	struct FVector PreferredAngles; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class IKRig.IKRigFBIKSolver
// Size: 0x170 (Inherited: 0xa0)
struct UIKRigFBIKSolver : UIKRigSolver {
	struct FName RootBone; // 0xa0(0x08)
	int32_t Iterations; // 0xa8(0x04)
	float MassMultiplier; // 0xac(0x04)
	bool bAllowStretch; // 0xb0(0x01)
	enum class EPBIKRootBehavior RootBehavior; // 0xb1(0x01)
	char pad_b2[0x2]; // 0xb2(0x02)
	struct FRootPrePullSettings PrePullRootSettings; // 0xb4(0x20)
	float PullChainAlpha; // 0xd4(0x04)
	float MaxAngle; // 0xd8(0x04)
	float OverRelaxation; // 0xdc(0x04)
	bool bStartSolveFromInputPose; // 0xe0(0x01)
	char pad_e1[0x7]; // 0xe1(0x07)
	struct TArray<struct UIKRig_FBIKEffector*> Effectors; // 0xe8(0x10)
	struct TArray<struct UIKRig_FBIKBoneSettings*> BoneSettings; // 0xf8(0x10)
	char pad_108[0x68]; // 0x108(0x68)
};

// Class IKRig.IKRig_PoleSolverEffector
// Size: 0xb0 (Inherited: 0xa0)
struct UIKRig_PoleSolverEffector : UObject {
	struct FName GoalName; // 0x98(0x08)
	struct FName BoneName; // 0xa0(0x08)
	float Alpha; // 0xa8(0x04)
};

// Class IKRig.IKRig_PoleSolver
// Size: 0xe0 (Inherited: 0xa0)
struct UIKRig_PoleSolver : UIKRigSolver {
	struct FName RootName; // 0xa0(0x08)
	struct FName EndName; // 0xa8(0x08)
	struct UIKRig_PoleSolverEffector* Effector; // 0xb0(0x08)
	char pad_b8[0x28]; // 0xb8(0x28)
};

// Class IKRig.IKRig_SetTransformEffector
// Size: 0xa0 (Inherited: 0xa0)
struct UIKRig_SetTransformEffector : UObject {
	bool bEnablePosition; // 0x98(0x01)
	bool bEnableRotation; // 0x99(0x01)
	float Alpha; // 0x9c(0x04)
};

// Class IKRig.IKRig_SetTransform
// Size: 0xc0 (Inherited: 0xa0)
struct UIKRig_SetTransform : UIKRigSolver {
	struct FName Goal; // 0xa0(0x08)
	struct FName RootBone; // 0xa8(0x08)
	struct UIKRig_SetTransformEffector* Effector; // 0xb0(0x08)
	char pad_b8[0x8]; // 0xb8(0x08)
};

