// Class InterchangeCore.InterchangeFactoryBase
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeFactoryBase : UObject {
	struct UInterchangeResultsContainer* Results; // 0x98(0x08)

	struct UObject* GetFactoryClass(); // Function InterchangeCore.InterchangeFactoryBase.GetFactoryClass // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2db2d70
};

// Class InterchangeCore.InterchangeSourceData
// Size: 0xc0 (Inherited: 0xa0)
struct UInterchangeSourceData : UObject {
	struct FString Filename; // 0x98(0x10)
	char pad_b0[0x10]; // 0xb0(0x10)

	bool SetFilename(struct FString InFilename); // Function InterchangeCore.InterchangeSourceData.SetFilename // (Final|Native|Public|BlueprintCallable) // @ game+0x98e4c50
	struct FString GetFilename(); // Function InterchangeCore.InterchangeSourceData.GetFilename // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ea520
};

// Class InterchangeCore.InterchangeWriterBase
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeWriterBase : UObject {
};

// Class InterchangeCore.InterchangePipelineBase
// Size: 0x160 (Inherited: 0xa0)
struct UInterchangePipelineBase : UObject {
	struct UInterchangeResultsContainer* Results; // 0xa0(0x08)
	struct TMap<struct FName, struct FInterchangePipelinePropertyStates> PropertiesStates; // 0xa8(0x50)
	char pad_f8[0x68]; // 0xf8(0x68)

	void ScriptedSetReimportSourceIndex(struct UObject* ReimportObjectClass, int32_t SourceFileIndex); // Function InterchangeCore.InterchangePipelineBase.ScriptedSetReimportSourceIndex // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x98cbc40
	void ScriptedExecutePreImportPipeline(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct TArray<struct UInterchangeSourceData*>& SourceDatas); // Function InterchangeCore.InterchangePipelineBase.ScriptedExecutePreImportPipeline // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x98c0ff0
	void ScriptedExecutePostImportPipeline(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FString FactoryNodeKey, struct UObject* CreatedAsset, bool bIsAReimport); // Function InterchangeCore.InterchangePipelineBase.ScriptedExecutePostImportPipeline // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x98c4be0
	void ScriptedExecutePostFactoryPipeline(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct FString FactoryNodeKey, struct UObject* CreatedAsset, bool bIsAReimport); // Function InterchangeCore.InterchangePipelineBase.ScriptedExecutePostFactoryPipeline // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x98c50f0
	void ScriptedExecutePipeline(struct UInterchangeBaseNodeContainer* BaseNodeContainer, struct TArray<struct UInterchangeSourceData*>& SourceDatas); // Function InterchangeCore.InterchangePipelineBase.ScriptedExecutePipeline // (RequiredAPI|Native|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x98bcd00
	void ScriptedExecuteExportPipeline(struct UInterchangeBaseNodeContainer* BaseNodeContainer); // Function InterchangeCore.InterchangePipelineBase.ScriptedExecuteExportPipeline // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2f74300
	bool ScriptedCanExecuteOnAnyThread(enum class EInterchangePipelineTask PipelineTask); // Function InterchangeCore.InterchangePipelineBase.ScriptedCanExecuteOnAnyThread // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x98c3d80
	struct FInterchangePipelinePropertyStates FindOrAddPropertyStates(struct FName PropertyPath); // Function InterchangeCore.InterchangePipelineBase.FindOrAddPropertyStates // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98f19b0
	bool DoesPropertyStatesExist(struct FName PropertyPath); // Function InterchangeCore.InterchangePipelineBase.DoesPropertyStatesExist // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98d4c10
};

// Class InterchangeCore.InterchangeResult
// Size: 0xd0 (Inherited: 0xa0)
struct UInterchangeResult : UObject {
	struct FString SourceAssetName; // 0x98(0x10)
	struct FString DestinationAssetName; // 0xa8(0x10)
	ClassPtrProperty AssetType; // 0xb8(0x08)
	struct FString InterchangeKey; // 0xc0(0x10)
};

// Class InterchangeCore.InterchangeResultSuccess
// Size: 0xd0 (Inherited: 0xd0)
struct UInterchangeResultSuccess : UInterchangeResult {
};

// Class InterchangeCore.InterchangeResultWarning
// Size: 0xd0 (Inherited: 0xd0)
struct UInterchangeResultWarning : UInterchangeResult {
};

// Class InterchangeCore.InterchangeResultError
// Size: 0xd0 (Inherited: 0xd0)
struct UInterchangeResultError : UInterchangeResult {
};

// Class InterchangeCore.InterchangeResultWarning_Generic
// Size: 0xf0 (Inherited: 0xd0)
struct UInterchangeResultWarning_Generic : UInterchangeResultWarning {
	struct FText Text; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class InterchangeCore.InterchangeResultError_Generic
// Size: 0xf0 (Inherited: 0xd0)
struct UInterchangeResultError_Generic : UInterchangeResultError {
	struct FText Text; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class InterchangeCore.InterchangeResultError_ReimportFail
// Size: 0xd0 (Inherited: 0xd0)
struct UInterchangeResultError_ReimportFail : UInterchangeResultError {
};

// Class InterchangeCore.InterchangeResultDisplay_Generic
// Size: 0xf0 (Inherited: 0xd0)
struct UInterchangeResultDisplay_Generic : UInterchangeResultSuccess {
	struct FText Text; // 0xd0(0x18)
	char pad_e8[0x8]; // 0xe8(0x08)
};

// Class InterchangeCore.InterchangeResultsContainer
// Size: 0xd0 (Inherited: 0xa0)
struct UInterchangeResultsContainer : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct TArray<struct UInterchangeResult*> Results; // 0xc0(0x10)
};

// Class InterchangeCore.InterchangeTranslatorBase
// Size: 0xb0 (Inherited: 0xa0)
struct UInterchangeTranslatorBase : UObject {
	struct UInterchangeResultsContainer* Results; // 0x98(0x08)
	struct UInterchangeSourceData* SourceData; // 0xa0(0x08)
};

// Class InterchangeCore.InterchangeBaseNode
// Size: 0xd0 (Inherited: 0xa0)
struct UInterchangeBaseNode : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)

	bool SetParentUid(struct FString ParentUid); // Function InterchangeCore.InterchangeBaseNode.SetParentUid // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98e75b0
	bool SetEnabled(bool bIsEnabled); // Function InterchangeCore.InterchangeBaseNode.SetEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98c4df0
	bool SetDisplayLabel(struct FString DisplayName); // Function InterchangeCore.InterchangeBaseNode.SetDisplayLabel // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98dd700
	bool SetAssetName(struct FString AssetName); // Function InterchangeCore.InterchangeBaseNode.SetAssetName // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98edaf0
	bool RemoveTargetNodeUid(struct FString AssetUid); // Function InterchangeCore.InterchangeBaseNode.RemoveTargetNodeUid // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98cbd40
	bool RemoveAttribute(struct FString NodeAttributeKey); // Function InterchangeCore.InterchangeBaseNode.RemoveAttribute // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98d4490
	bool IsEnabled(); // Function InterchangeCore.InterchangeBaseNode.IsEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98e29d0
	void InitializeNode(struct FString UniqueID, struct FString DisplayLabel, enum class EInterchangeNodeContainerType NodeContainerType); // Function InterchangeCore.InterchangeBaseNode.InitializeNode // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98c4130
	bool GetVector2Attribute(struct FString NodeAttributeKey, struct FVector2f& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetVector2Attribute // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x98d8a80
	struct FString GetUniqueId(); // Function InterchangeCore.InterchangeBaseNode.GetUniqueId // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c64e0
	void GetTargetNodeUids(struct TArray<struct FString>& OutTargetAssets); // Function InterchangeCore.InterchangeBaseNode.GetTargetNodeUids // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98cf930
	int32_t GetTargetNodeCount(); // Function InterchangeCore.InterchangeBaseNode.GetTargetNodeCount // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98d6bf0
	bool GetStringAttribute(struct FString NodeAttributeKey, struct FString& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetStringAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ec530
	struct FString GetParentUid(); // Function InterchangeCore.InterchangeBaseNode.GetParentUid // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98e1290
	enum class EInterchangeNodeContainerType GetNodeContainerType(); // Function InterchangeCore.InterchangeBaseNode.GetNodeContainerType // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c27c0
	bool GetLinearColorAttribute(struct FString NodeAttributeKey, struct FLinearColor& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetLinearColorAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ea2e0
	bool GetInt32Attribute(struct FString NodeAttributeKey, int32_t& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetInt32Attribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98f1da0
	bool GetGuidAttribute(struct FString NodeAttributeKey, struct FGuid& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetGuidAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c96e0
	bool GetFloatAttribute(struct FString NodeAttributeKey, float& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetFloatAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98be360
	bool GetDoubleAttribute(struct FString NodeAttributeKey, double& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetDoubleAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98bc6d0
	struct FString GetDisplayLabel(); // Function InterchangeCore.InterchangeBaseNode.GetDisplayLabel // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98f1250
	bool GetBooleanAttribute(struct FString NodeAttributeKey, bool& OutValue); // Function InterchangeCore.InterchangeBaseNode.GetBooleanAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98dba60
	struct FString GetAssetName(); // Function InterchangeCore.InterchangeBaseNode.GetAssetName // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x538a4f0
	bool AddVector2Attribute(struct FString NodeAttributeKey, struct FVector2f& Value); // Function InterchangeCore.InterchangeBaseNode.AddVector2Attribute // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x98e0700
	bool AddTargetNodeUid(struct FString AssetUid); // Function InterchangeCore.InterchangeBaseNode.AddTargetNodeUid // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ddab0
	bool AddStringAttribute(struct FString NodeAttributeKey, struct FString Value); // Function InterchangeCore.InterchangeBaseNode.AddStringAttribute // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98d3e40
	bool AddLinearColorAttribute(struct FString NodeAttributeKey, struct FLinearColor& Value); // Function InterchangeCore.InterchangeBaseNode.AddLinearColorAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x98dd7c0
	bool AddInt32Attribute(struct FString NodeAttributeKey, int32_t& Value); // Function InterchangeCore.InterchangeBaseNode.AddInt32Attribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98bec30
	bool AddGuidAttribute(struct FString NodeAttributeKey, struct FGuid& Value); // Function InterchangeCore.InterchangeBaseNode.AddGuidAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x98db950
	bool AddFloatAttribute(struct FString NodeAttributeKey, float& Value); // Function InterchangeCore.InterchangeBaseNode.AddFloatAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98eae70
	bool AddDoubleAttribute(struct FString NodeAttributeKey, double& Value); // Function InterchangeCore.InterchangeBaseNode.AddDoubleAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98c8c60
	bool AddBooleanAttribute(struct FString NodeAttributeKey, bool& Value); // Function InterchangeCore.InterchangeBaseNode.AddBooleanAttribute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98e4f90
};

// Class InterchangeCore.InterchangeBaseNodeContainer
// Size: 0x140 (Inherited: 0xa0)
struct UInterchangeBaseNodeContainer : UObject {
	struct TMap<struct FString, struct UInterchangeBaseNode*> Nodes; // 0x98(0x50)
	char pad_f0[0x50]; // 0xf0(0x50)

	bool SetNodeParentUid(struct FString NodeUniqueID, struct FString NewParentNodeUid); // Function InterchangeCore.InterchangeBaseNodeContainer.SetNodeParentUid // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98c7350
	void SaveToFile(struct FString Filename); // Function InterchangeCore.InterchangeBaseNodeContainer.SaveToFile // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98d8660
	void ResetChildrenCache(); // Function InterchangeCore.InterchangeBaseNodeContainer.ResetChildrenCache // (Final|Native|Public|BlueprintCallable) // @ game+0x98f1d50
	void ReplaceNode(struct FString NodeUniqueID, struct UInterchangeFactoryBaseNode* NewNode); // Function InterchangeCore.InterchangeBaseNodeContainer.ReplaceNode // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98c8f10
	void LoadFromFile(struct FString Filename); // Function InterchangeCore.InterchangeBaseNodeContainer.LoadFromFile // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98e7370
	bool IsNodeUidValid(struct FString NodeUniqueID); // Function InterchangeCore.InterchangeBaseNodeContainer.IsNodeUidValid // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ecd60
	void GetRoots(struct TArray<struct FString>& RootNodes); // Function InterchangeCore.InterchangeBaseNodeContainer.GetRoots // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ccbc0
	void GetNodes(struct UObject* ClassNode, struct TArray<struct FString>& OutNodes); // Function InterchangeCore.InterchangeBaseNodeContainer.GetNodes // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98de640
	struct TArray<struct FString> GetNodeChildrenUids(struct FString NodeUniqueID); // Function InterchangeCore.InterchangeBaseNodeContainer.GetNodeChildrenUids // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98d5a40
	int32_t GetNodeChildrenCount(struct FString NodeUniqueID); // Function InterchangeCore.InterchangeBaseNodeContainer.GetNodeChildrenCount // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ed450
	struct UInterchangeBaseNode* GetNodeChildren(struct FString NodeUniqueID, int32_t ChildIndex); // Function InterchangeCore.InterchangeBaseNodeContainer.GetNodeChildren // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98e6d60
	struct UInterchangeBaseNode* GetNode(struct FString NodeUniqueID); // Function InterchangeCore.InterchangeBaseNodeContainer.GetNode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98bc290
	struct UInterchangeFactoryBaseNode* GetFactoryNode(struct FString NodeUniqueID); // Function InterchangeCore.InterchangeBaseNodeContainer.GetFactoryNode // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c24e0
	void ComputeChildrenCache(); // Function InterchangeCore.InterchangeBaseNodeContainer.ComputeChildrenCache // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98dea90
	struct FString AddNode(struct UInterchangeBaseNode* Node); // Function InterchangeCore.InterchangeBaseNodeContainer.AddNode // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98d0e90
};

// Class InterchangeCore.InterchangeFactoryBaseNode
// Size: 0x1b0 (Inherited: 0xd0)
struct UInterchangeFactoryBaseNode : UInterchangeBaseNode {
	char pad_d0[0xe0]; // 0xd0(0xe0)

	bool UnsetSkipNodeImport(); // Function InterchangeCore.InterchangeFactoryBaseNode.UnsetSkipNodeImport // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98eb480
	bool UnsetForceNodeReimport(); // Function InterchangeCore.InterchangeFactoryBaseNode.UnsetForceNodeReimport // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98e83d0
	bool ShouldSkipNodeImport(); // Function InterchangeCore.InterchangeFactoryBaseNode.ShouldSkipNodeImport // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98beb10
	bool ShouldForceNodeReimport(); // Function InterchangeCore.InterchangeFactoryBaseNode.ShouldForceNodeReimport // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c6040
	bool SetSkipNodeImport(); // Function InterchangeCore.InterchangeFactoryBaseNode.SetSkipNodeImport // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98defd0
	bool SetReimportStrategyFlags(enum class EReimportStrategyFlags& ReimportStrategyFlags); // Function InterchangeCore.InterchangeFactoryBaseNode.SetReimportStrategyFlags // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98be470
	bool SetForceNodeReimport(); // Function InterchangeCore.InterchangeFactoryBaseNode.SetForceNodeReimport // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98e00b0
	bool SetCustomSubPath(struct FString AttributeValue); // Function InterchangeCore.InterchangeFactoryBaseNode.SetCustomSubPath // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98db110
	bool SetCustomReferenceObject(struct FSoftObjectPath& AttributeValue); // Function InterchangeCore.InterchangeFactoryBaseNode.SetCustomReferenceObject // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x98e02e0
	bool RemoveFactoryDependencyUid(struct FString DependencyUid); // Function InterchangeCore.InterchangeFactoryBaseNode.RemoveFactoryDependencyUid // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98c81c0
	enum class EReimportStrategyFlags GetReimportStrategyFlags(); // Function InterchangeCore.InterchangeFactoryBaseNode.GetReimportStrategyFlags // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98d50c0
	void GetFactoryDependency(int32_t Index, struct FString& OutDependency); // Function InterchangeCore.InterchangeFactoryBaseNode.GetFactoryDependency // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c5620
	int32_t GetFactoryDependenciesCount(); // Function InterchangeCore.InterchangeFactoryBaseNode.GetFactoryDependenciesCount // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x98cc770
	void GetFactoryDependencies(struct TArray<struct FString>& OutDependencies); // Function InterchangeCore.InterchangeFactoryBaseNode.GetFactoryDependencies // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98caba0
	bool GetCustomSubPath(struct FString& AttributeValue); // Function InterchangeCore.InterchangeFactoryBaseNode.GetCustomSubPath // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98dfc70
	bool GetCustomReferenceObject(struct FSoftObjectPath& AttributeValue); // Function InterchangeCore.InterchangeFactoryBaseNode.GetCustomReferenceObject // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x98cf740
	bool AddFactoryDependencyUid(struct FString DependencyUid); // Function InterchangeCore.InterchangeFactoryBaseNode.AddFactoryDependencyUid // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98ea090
};

// Class InterchangeCore.InterchangeSourceNode
// Size: 0x140 (Inherited: 0xd0)
struct UInterchangeSourceNode : UInterchangeBaseNode {
	char pad_d0[0x70]; // 0xd0(0x70)

	bool SetCustomSourceTimelineStart(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomSourceTimelineStart // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98f0a70
	bool SetCustomSourceTimelineEnd(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomSourceTimelineEnd // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98dfa70
	bool SetCustomSourceFrameRateNumerator(int32_t& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomSourceFrameRateNumerator // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98c26a0
	bool SetCustomSourceFrameRateDenominator(int32_t& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomSourceFrameRateDenominator // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98f0750
	bool SetCustomImportUnusedMaterial(bool& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomImportUnusedMaterial // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98e15f0
	bool SetCustomAnimatedTimeStart(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomAnimatedTimeStart // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98e2640
	bool SetCustomAnimatedTimeEnd(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.SetCustomAnimatedTimeEnd // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x98caa40
	void InitializeSourceNode(struct FString UniqueID, struct FString DisplayLabel); // Function InterchangeCore.InterchangeSourceNode.InitializeSourceNode // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x98ec790
	bool GetCustomSourceTimelineStart(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomSourceTimelineStart // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98e94e0
	bool GetCustomSourceTimelineEnd(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomSourceTimelineEnd // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98dbb70
	bool GetCustomSourceFrameRateNumerator(int32_t& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomSourceFrameRateNumerator // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98c7e60
	bool GetCustomSourceFrameRateDenominator(int32_t& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomSourceFrameRateDenominator // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98ec410
	bool GetCustomImportUnusedMaterial(bool& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomImportUnusedMaterial // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98e1ec0
	bool GetCustomAnimatedTimeStart(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomAnimatedTimeStart // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98cd9a0
	bool GetCustomAnimatedTimeEnd(double& AttributeValue); // Function InterchangeCore.InterchangeSourceNode.GetCustomAnimatedTimeEnd // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x98d4140
};

// Class InterchangeCore.InterchangeUserDefinedAttributesAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeUserDefinedAttributesAPI : UObject {

	bool RemoveUserDefinedAttribute(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.RemoveUserDefinedAttribute // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x98cfd80
	void GetUserDefinedAttributeInfos(struct UInterchangeBaseNode* InterchangeNode, struct TArray<struct FInterchangeUserDefinedAttributeInfo>& UserDefinedAttributeInfos); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.GetUserDefinedAttributeInfos // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98ea190
	bool GetUserDefinedAttribute_Int32(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, int32_t& OutValue, struct FString& OutPayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.GetUserDefinedAttribute_Int32 // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98d7620
	bool GetUserDefinedAttribute_FString(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, struct FString& OutValue, struct FString& OutPayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.GetUserDefinedAttribute_FString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98e7670
	bool GetUserDefinedAttribute_Float(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, float& OutValue, struct FString& OutPayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.GetUserDefinedAttribute_Float // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98c5be0
	bool GetUserDefinedAttribute_Double(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, double& OutValue, struct FString& OutPayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.GetUserDefinedAttribute_Double // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98c9a10
	bool GetUserDefinedAttribute_Boolean(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, bool& OutValue, struct FString& OutPayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.GetUserDefinedAttribute_Boolean // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98f1040
	void DuplicateAllUserDefinedAttribute(struct UInterchangeBaseNode* InterchangeSourceNode, struct UInterchangeBaseNode* InterchangeDestinationNode, bool bAddSourceNodeName); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.DuplicateAllUserDefinedAttribute // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x98c8b00
	bool CreateUserDefinedAttribute_Int32(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, int32_t& Value, struct FString PayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.CreateUserDefinedAttribute_Int32 // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98eaf80
	bool CreateUserDefinedAttribute_FString(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, struct FString Value, struct FString PayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.CreateUserDefinedAttribute_FString // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x98c7870
	bool CreateUserDefinedAttribute_Float(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, float& Value, struct FString PayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.CreateUserDefinedAttribute_Float // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98d4260
	bool CreateUserDefinedAttribute_Double(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, double& Value, struct FString PayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.CreateUserDefinedAttribute_Double // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98e18b0
	bool CreateUserDefinedAttribute_Boolean(struct UInterchangeBaseNode* InterchangeNode, struct FString UserDefinedAttributeName, bool& Value, struct FString PayloadKey); // Function InterchangeCore.InterchangeUserDefinedAttributesAPI.CreateUserDefinedAttribute_Boolean // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x98f1eb0
};

