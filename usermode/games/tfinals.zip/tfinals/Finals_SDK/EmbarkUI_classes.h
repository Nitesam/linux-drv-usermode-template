// Class EmbarkUI.AngularProgressBarBase
// Size: 0x350 (Inherited: 0x350)
struct UAngularProgressBarBase : UUserWidget {

	void OnSynchronizeProperties(); // Function EmbarkUI.AngularProgressBarBase.OnSynchronizeProperties // (Native|Event|Public|BlueprintEvent) // @ game+0x3a6dae0
};

// Class EmbarkUI.EmbarkButtonBaseOld
// Size: 0x6c0 (Inherited: 0x690)
struct UEmbarkButtonBaseOld : UButton {
	struct FMulticastInlineDelegate OnDoubleClicked; // 0x688(0x10)
	struct FSlateSound PressedSound; // 0x698(0x18)
	char pad_6b8[0x8]; // 0x6b8(0x08)

	void SimulateMouseLeave(struct FPointerEvent& MouseEvent); // Function EmbarkUI.EmbarkButtonBaseOld.SimulateMouseLeave // (Final|Native|Public|HasOutParms) // @ game+0x68d9db0
	void SimulateMouseEnter(struct FGeometry& MyGeometry, struct FPointerEvent& MouseEvent); // Function EmbarkUI.EmbarkButtonBaseOld.SimulateMouseEnter // (Final|Native|Public|HasOutParms) // @ game+0x68dac70
	void SimulateMouseButtonUp(); // Function EmbarkUI.EmbarkButtonBaseOld.SimulateMouseButtonUp // (Final|Native|Public) // @ game+0x68d56d0
	void SimulateMouseButtonDown(); // Function EmbarkUI.EmbarkButtonBaseOld.SimulateMouseButtonDown // (Final|Native|Public) // @ game+0x68d7ee0
	void SimulateClick(); // Function EmbarkUI.EmbarkButtonBaseOld.SimulateClick // (Final|Native|Public) // @ game+0x33aadf0
	void SetPressedSound(struct FSlateSound& InPressedSound); // Function EmbarkUI.EmbarkButtonBaseOld.SetPressedSound // (Final|Native|Public|HasOutParms) // @ game+0x68d3cc0
	struct FEventReply OnKeyUp(struct FGeometry& MyGeometry, struct FKeyEvent& InKeyEvent); // Function EmbarkUI.EmbarkButtonBaseOld.OnKeyUp // (Final|Native|Public|HasOutParms) // @ game+0x68d7f40
	struct FEventReply OnKeyDown(struct FGeometry& MyGeometry, struct FKeyEvent& InKeyEvent); // Function EmbarkUI.EmbarkButtonBaseOld.OnKeyDown // (Final|Native|Public|HasOutParms) // @ game+0x68d8420
	void OnConstruct(); // Function EmbarkUI.EmbarkButtonBaseOld.OnConstruct // (Native|Event|Public|BlueprintEvent) // @ game+0x2ce7e50
};

// Class EmbarkUI.EmbarkButtonInternalBase
// Size: 0x6d0 (Inherited: 0x690)
struct UEmbarkButtonInternalBase : UButton {
	char pad_690[0x28]; // 0x690(0x28)
	bool bButtonEnabled; // 0x6b8(0x01)
	char pad_6b9[0x17]; // 0x6b9(0x17)
};

// Class EmbarkUI.EmbarkButtonBase
// Size: 0xba0 (Inherited: 0x350)
struct UEmbarkButtonBase : UUserWidget {
	enum class EButtonClickMethod ClickMethod; // 0x348(0x01)
	enum class EButtonTouchMethod TouchMethod; // 0x349(0x01)
	enum class EButtonPressMethod PressMethod; // 0x34a(0x01)
	char pad_353[0xd]; // 0x353(0x0d)
	struct FMulticastInlineDelegate OnEmbarkButtonClicked; // 0x360(0x10)
	struct FMulticastInlineDelegate OnEmbarkButtonDoubleClicked; // 0x370(0x10)
	struct FMulticastInlineDelegate OnEmbarkButtonHovered; // 0x380(0x10)
	struct FMulticastInlineDelegate OnEmbarkButtonUnhovered; // 0x390(0x10)
	struct FMulticastInlineDelegate OnEmbarkButtonStateChanged; // 0x3a0(0x10)
	struct FButtonStyle NormalStyle; // 0x3b0(0x3f0)
	struct FButtonStyle DisabledStyle; // 0x7a0(0x3f0)
	char pad_b90[0x10]; // 0xb90(0x10)

	void UpdateCurrentButtonStyle(); // Function EmbarkUI.EmbarkButtonBase.UpdateCurrentButtonStyle // (Final|Native|Public|BlueprintCallable) // @ game+0x68d7b80
	struct FButtonStyle TempGetNormalButtonStyle(); // Function EmbarkUI.EmbarkButtonBase.TempGetNormalButtonStyle // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x68d8a20
	void SetTouchMethod(enum class EButtonTouchMethod InTouchMethod); // Function EmbarkUI.EmbarkButtonBase.SetTouchMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x68de350
	void SetPressMethod(enum class EButtonPressMethod InPressMethod); // Function EmbarkUI.EmbarkButtonBase.SetPressMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x68d9c40
	void SetIsFocusable(bool bInIsFocusable); // Function EmbarkUI.EmbarkButtonBase.SetIsFocusable // (Final|Native|Public|BlueprintCallable) // @ game+0x68d85d0
	void SetClickMethod(enum class EButtonClickMethod InClickMethod); // Function EmbarkUI.EmbarkButtonBase.SetClickMethod // (Final|Native|Public|BlueprintCallable) // @ game+0x68de1f0
	void OnUnhovered(); // Function EmbarkUI.EmbarkButtonBase.OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnReleased(); // Function EmbarkUI.EmbarkButtonBase.OnReleased // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnPressed(); // Function EmbarkUI.EmbarkButtonBase.OnPressed // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnHovered(); // Function EmbarkUI.EmbarkButtonBase.OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnEnabledStateChanged(bool bInIsEnabled); // Function EmbarkUI.EmbarkButtonBase.OnEnabledStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnDoubleClicked(); // Function EmbarkUI.EmbarkButtonBase.OnDoubleClicked // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnClicked(); // Function EmbarkUI.EmbarkButtonBase.OnClicked // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnButtonStateChanged(enum class EEmbarkButtonState InButtonState); // Function EmbarkUI.EmbarkButtonBase.OnButtonStateChanged // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	bool IsPressed(); // Function EmbarkUI.EmbarkButtonBase.IsPressed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68de290
	bool IsInteractionEnabled(); // Function EmbarkUI.EmbarkButtonBase.IsInteractionEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68d6d80
	void HandleButtonUnhovered(); // Function EmbarkUI.EmbarkButtonBase.HandleButtonUnhovered // (Final|Native|Protected) // @ game+0x68d5b40
	void HandleButtonReleased(); // Function EmbarkUI.EmbarkButtonBase.HandleButtonReleased // (Final|Native|Protected) // @ game+0x68db160
	void HandleButtonPressed(); // Function EmbarkUI.EmbarkButtonBase.HandleButtonPressed // (Final|Native|Protected) // @ game+0x68de2f0
	void HandleButtonHovered(); // Function EmbarkUI.EmbarkButtonBase.HandleButtonHovered // (Final|Native|Protected) // @ game+0x68d9bb0
	void HandleButtonClicked(); // Function EmbarkUI.EmbarkButtonBase.HandleButtonClicked // (Final|Native|Protected) // @ game+0x68d42b0
	bool GetIsFocusable(); // Function EmbarkUI.EmbarkButtonBase.GetIsFocusable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68d4730
	bool GetIsButtonEnabled(); // Function EmbarkUI.EmbarkButtonBase.GetIsButtonEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68d9bd0
	struct FButtonStyle GetDisabledButtonStyle(); // Function EmbarkUI.EmbarkButtonBase.GetDisabledButtonStyle // (Native|Event|Protected|BlueprintEvent) // @ game+0x68d8970
	struct FButtonStyle GetCurrentButtonStyle(); // Function EmbarkUI.EmbarkButtonBase.GetCurrentButtonStyle // (Native|Event|Protected|BlueprintEvent) // @ game+0x68d56f0
	enum class EEmbarkButtonState GetButtonState(); // Function EmbarkUI.EmbarkButtonBase.GetButtonState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68d4ff0
	void BuildStyles(struct UEmbarkButtonStyleBase* InStyle); // Function EmbarkUI.EmbarkButtonBase.BuildStyles // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void BuildSoundStyles(struct UEmbarkButtonSoundStyleBase* InStyle); // Function EmbarkUI.EmbarkButtonBase.BuildSoundStyles // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkUI.EmbarkButtonSoundStyleBase
// Size: 0x110 (Inherited: 0xa0)
struct UEmbarkButtonSoundStyleBase : UObject {
	struct FSlateSound PressedSlateSound; // 0x98(0x18)
	struct FSlateSound HoveredSlateSound; // 0xb0(0x18)
	struct FEmbarkOptionalSlateSound DisabledPressedSlateSound; // 0xc8(0x20)
	struct FEmbarkOptionalSlateSound DisabledHoveredSlateSound; // 0xe8(0x20)

	struct UEmbarkButtonSoundStyleBase* GetButtonSoundStyle(struct UEmbarkButtonSoundStyleBase* InButtonSoundStyle); // Function EmbarkUI.EmbarkButtonSoundStyleBase.GetButtonSoundStyle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x68db750
};

// Class EmbarkUI.EmbarkButtonStyleBase
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkButtonStyleBase : UObject {

	struct FSlateBrush GetNormalPressedBrush(); // Function EmbarkUI.EmbarkButtonStyleBase.GetNormalPressedBrush // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x68d41b0
	struct FSlateBrush GetNormalHighlightBrush(); // Function EmbarkUI.EmbarkButtonStyleBase.GetNormalHighlightBrush // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x68d3ba0
	struct FSlateBrush GetNormalBaseBrush(); // Function EmbarkUI.EmbarkButtonStyleBase.GetNormalBaseBrush // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x68d55d0
	struct FSlateBrush GetDisabledBrush(); // Function EmbarkUI.EmbarkButtonStyleBase.GetDisabledBrush // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x68de5f0
	struct UEmbarkButtonStyleBase* GetButtonStyle(struct UEmbarkButtonStyleBase* InButtonStyle); // Function EmbarkUI.EmbarkButtonStyleBase.GetButtonStyle // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x68d5090
};

// Class EmbarkUI.EmbarkCommonActionWidget
// Size: 0x6c0 (Inherited: 0x500)
struct UEmbarkCommonActionWidget : UCommonActionWidget {
	struct FVector2D InputActionIconSize; // 0x4f8(0x10)
	struct FSlateFontInfo InputActionTextFont; // 0x508(0x58)
	struct FSlateColor InputActionTextColor; // 0x560(0x14)
	enum class ETextTransformPolicy InputActionTextTransformPolicy; // 0x574(0x01)
	struct FMargin InputActionTextPadding; // 0x578(0x10)
	struct FMargin InputActionIconPadding; // 0x588(0x10)
	char pad_59d[0x3]; // 0x59d(0x03)
	struct FSlateBrush InputActionTextRim; // 0x5a0(0xd0)
	bool bUseDynamicTextRimMaterial; // 0x670(0x01)
	enum class EHorizontalAlignment ProgressMaterial_HAlign; // 0x671(0x01)
	enum class EVerticalAlignment ProgressMaterial_VAlign; // 0x672(0x01)
	char pad_673[0x5]; // 0x673(0x05)
	struct UMaterialInstanceDynamic* DynamicInputActionTextRimMaterial; // 0x678(0x08)
	struct FSlateColor InputActionIconColor; // 0x680(0x14)
	char pad_694[0x2c]; // 0x694(0x2c)

	void SetInputActionSlateColor(struct FSlateColor& Color, struct FSlateColor& TextColor); // Function EmbarkUI.EmbarkCommonActionWidget.SetInputActionSlateColor // (Final|Native|Public|HasOutParms) // @ game+0x68db040
	void SetInputActionColor(struct FLinearColor& Color, struct FLinearColor& TextColor); // Function EmbarkUI.EmbarkCommonActionWidget.SetInputActionColor // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x68dd920
	void SetFont(struct FSlateFontInfo& Font); // Function EmbarkUI.EmbarkCommonActionWidget.SetFont // (Final|Native|Public|HasOutParms) // @ game+0x68d9370
	void OnSynchronizeProperties(); // Function EmbarkUI.EmbarkCommonActionWidget.OnSynchronizeProperties // (Native|Event|Public|BlueprintEvent) // @ game+0x2b63d50
	void OnControlMappingsChanged(); // Function EmbarkUI.EmbarkCommonActionWidget.OnControlMappingsChanged // (Final|Native|Protected) // @ game+0x68db540
	void OnConstruct(); // Function EmbarkUI.EmbarkCommonActionWidget.OnConstruct // (Native|Event|Public|BlueprintEvent) // @ game+0x5d60060
};

// Class EmbarkUI.EmbarkCommonActivatableWidgetBase
// Size: 0x4a0 (Inherited: 0x4a0)
struct UEmbarkCommonActivatableWidgetBase : UCommonActivatableWidget {
	enum class EEmbarkWidgetInputMode InputConfig; // 0x498(0x01)
	enum class EMouseCaptureMode GameMouseCaptureMode; // 0x499(0x01)

	void RequestFocus(); // Function EmbarkUI.EmbarkCommonActivatableWidgetBase.RequestFocus // (Final|Native|Protected|BlueprintCallable) // @ game+0x68db830
	void HandleBackAction(); // Function EmbarkUI.EmbarkCommonActivatableWidgetBase.HandleBackAction // (Final|Native|Protected|BlueprintCallable) // @ game+0x68d3ca0
};

// Class EmbarkUI.EmbarkCommonActivatableTransitionWidget
// Size: 0x4e0 (Inherited: 0x4a0)
struct UEmbarkCommonActivatableTransitionWidget : UEmbarkCommonActivatableWidgetBase {
	struct FMulticastInlineDelegate BP_OnTriggerWidgetSwitch; // 0x4a0(0x10)
	char pad_4b0[0xc]; // 0x4b0(0x0c)
	bool bIsTransitioning; // 0x4bc(0x01)
	char pad_4bd[0x23]; // 0x4bd(0x23)

	void TriggerWidgetSwitch(); // Function EmbarkUI.EmbarkCommonActivatableTransitionWidget.TriggerWidgetSwitch // (Final|Native|Protected|BlueprintCallable) // @ game+0x68da220
	bool Transition(struct UWidget* From, struct UWidget* To, enum class ETransitionDirection Direction); // Function EmbarkUI.EmbarkCommonActivatableTransitionWidget.Transition // (Final|Native|Public|BlueprintCallable) // @ game+0x68da510
	bool BP_Transition(struct UWidget* From, struct UWidget* To, enum class ETransitionDirection Direction); // Function EmbarkUI.EmbarkCommonActivatableTransitionWidget.BP_Transition // (Native|Event|Public|BlueprintEvent) // @ game+0x68d4d80
};

// Class EmbarkUI.EmbarkCommonActivatableContainerBase
// Size: 0x320 (Inherited: 0x310)
struct UEmbarkCommonActivatableContainerBase : UCommonActivatableWidgetContainerBase {
	char pad_310[0x10]; // 0x310(0x10)

	void SetTransitionWidget(struct UEmbarkCommonActivatableTransitionWidget* InTransitionWidget); // Function EmbarkUI.EmbarkCommonActivatableContainerBase.SetTransitionWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x68d6020
	struct TArray<struct UCommonActivatableWidget*> GetAllWidgets(); // Function EmbarkUI.EmbarkCommonActivatableContainerBase.GetAllWidgets // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68da160
};

// Class EmbarkUI.EmbarkCommonActivatableWidgetStack
// Size: 0x330 (Inherited: 0x320)
struct UEmbarkCommonActivatableWidgetStack : UEmbarkCommonActivatableContainerBase {
	struct UCommonActivatableWidget* RootContentWidgetClass; // 0x320(0x08)
	struct UCommonActivatableWidget* RootContentWidget; // 0x328(0x08)
};

// Class EmbarkUI.EmbarkCommonActivatableWidgetQueue
// Size: 0x320 (Inherited: 0x320)
struct UEmbarkCommonActivatableWidgetQueue : UEmbarkCommonActivatableContainerBase {
};

// Class EmbarkUI.EmbarkCommonActivatablePersistentWidgetStack
// Size: 0x3c0 (Inherited: 0x330)
struct UEmbarkCommonActivatablePersistentWidgetStack : UEmbarkCommonActivatableWidgetStack {
	struct TArray<struct UCommonActivatableWidget*> PersistentWidgetClasses; // 0x330(0x10)
	char pad_340[0x80]; // 0x340(0x80)
};

// Class EmbarkUI.EmbarkSlateTransitionWidgetInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkSlateTransitionWidgetInterface : UInterface {
};

// Class EmbarkUI.EmbarkCommonActivatableWidgetSwitcher
// Size: 0x2b0 (Inherited: 0x2a0)
struct UEmbarkCommonActivatableWidgetSwitcher : UCommonActivatableWidgetSwitcher {
	char pad_2a0[0x10]; // 0x2a0(0x10)

	void SetTransitionWidget(struct UEmbarkCommonActivatableTransitionWidget* TransitionWidget); // Function EmbarkUI.EmbarkCommonActivatableWidgetSwitcher.SetTransitionWidget // (Final|Native|Public|BlueprintCallable) // @ game+0x68d80f0
};

// Class EmbarkUI.EmbarkCommonBoundActionBar
// Size: 0x2f0 (Inherited: 0x2f0)
struct UEmbarkCommonBoundActionBar : UCommonBoundActionBar {
};

// Class EmbarkUI.EmbarkCommonButtonBase
// Size: 0x1790 (Inherited: 0x1610)
struct UEmbarkCommonButtonBase : UCommonButtonBase {
	char bKeepHoveringEventsOnDisable : 1; // 0x1610(0x01)
	char pad_1610_1 : 7; // 0x1610(0x01)
	char pad_1611[0x7]; // 0x1611(0x07)
	struct FKey TriggeredKey; // 0x1618(0x18)
	char pad_1630[0x8]; // 0x1630(0x08)
	struct TMap<struct FName, struct UEmbarkInputBindingCallbackWrapper*> CallbackMap; // 0x1638(0x50)
	struct TMap<struct UInputAction*, struct UEmbarkInputBindingCallbackWrapper*> EnhancedCallbackMap; // 0x1688(0x50)
	char pad_16d8[0xb8]; // 0x16d8(0xb8)

	void TryFindOwningActivatableWidget(); // Function EmbarkUI.EmbarkCommonButtonBase.TryFindOwningActivatableWidget // (Final|Native|Protected|BlueprintCallable) // @ game+0x68e0ed0
	void SimulateClick(); // Function EmbarkUI.EmbarkCommonButtonBase.SimulateClick // (Final|Native|Public|BlueprintCallable) // @ game+0x33aadf0
	void ResetHeldButtonState(); // Function EmbarkUI.EmbarkCommonButtonBase.ResetHeldButtonState // (Final|Native|Public|BlueprintCallable) // @ game+0x68e48e0
	void RemoveInputActionBinding(struct FDataTableRowHandle& InLegacyActionTableRow); // Function EmbarkUI.EmbarkCommonButtonBase.RemoveInputActionBinding // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68e64d0
	void RemoveEnhancedInputActionBinding(struct UInputAction* InputAction); // Function EmbarkUI.EmbarkCommonButtonBase.RemoveEnhancedInputActionBinding // (Final|Native|Protected|BlueprintCallable) // @ game+0x68e2520
	void RefreshHoldTimes(); // Function EmbarkUI.EmbarkCommonButtonBase.RefreshHoldTimes // (Final|Native|Protected) // @ game+0x68dfa80
	void OnEmbarkButtonReleased(); // Function EmbarkUI.EmbarkCommonButtonBase.OnEmbarkButtonReleased // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void OnEmbarkButtonPressed(); // Function EmbarkUI.EmbarkCommonButtonBase.OnEmbarkButtonPressed // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool GetIsReceivingInputWithErrorMessage(struct FString& OutError); // Function EmbarkUI.EmbarkCommonButtonBase.GetIsReceivingInputWithErrorMessage // (Final|Native|Protected|HasOutParms|Const) // @ game+0x68e5800
	void AddInputActionBinding(struct FDataTableRowHandle& InLegacyActionTableRow, struct FDelegate& Callback, bool bInDisplayInActionBar); // Function EmbarkUI.EmbarkCommonButtonBase.AddInputActionBinding // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68def10
	void AddEnhancedInputActionBinding(struct UInputAction* InputAction, struct FDelegate& Callback, bool bInDisplayInActionBar); // Function EmbarkUI.EmbarkCommonButtonBase.AddEnhancedInputActionBinding // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68e16d0
};

// Class EmbarkUI.EmbarkCommonGameViewportClient
// Size: 0x7c0 (Inherited: 0x740)
struct UEmbarkCommonGameViewportClient : UCommonGameViewportClient {
	struct TArray<struct UWidget*> DesktopNotificationsCache; // 0x738(0x10)
	char pad_750[0x70]; // 0x750(0x70)

	void StopDrawingWindowAttention(); // Function EmbarkUI.EmbarkCommonGameViewportClient.StopDrawingWindowAttention // (Final|Native|Public|BlueprintCallable) // @ game+0x68e2f20
	void ShowDesktopNotification(struct UWidget* Widget, struct FEmbarkDesktopNotificationParams& Params); // Function EmbarkUI.EmbarkCommonGameViewportClient.ShowDesktopNotification // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68e1830
	void ResetExcludedKeys(); // Function EmbarkUI.EmbarkCommonGameViewportClient.ResetExcludedKeys // (Final|Native|Public|BlueprintCallable) // @ game+0x68e3ec0
	void DrawWindowAttention(); // Function EmbarkUI.EmbarkCommonGameViewportClient.DrawWindowAttention // (Final|Native|Public|BlueprintCallable) // @ game+0x68e5900
	void BringWindowToFront(); // Function EmbarkUI.EmbarkCommonGameViewportClient.BringWindowToFront // (Final|Native|Public|BlueprintCallable) // @ game+0x68e2bb0
	void AddPersistentWidgetToViewportContent(struct UWidget* Widget, int32_t ZOrder); // Function EmbarkUI.EmbarkCommonGameViewportClient.AddPersistentWidgetToViewportContent // (Final|Native|Public|BlueprintCallable) // @ game+0x68e6770
	void AddExcludedKey(struct FKey& Key); // Function EmbarkUI.EmbarkCommonGameViewportClient.AddExcludedKey // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68e6cd0
};

// Class EmbarkUI.EmbarkCommonGameViewportClientBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkCommonGameViewportClientBlueprintLibrary : UBlueprintFunctionLibrary {

	struct UEmbarkCommonGameViewportClient* GetViewportClient(); // Function EmbarkUI.EmbarkCommonGameViewportClientBlueprintLibrary.GetViewportClient // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x68e5700
};

// Class EmbarkUI.EmbarkCommonTabListWidgetBase
// Size: 0x4f0 (Inherited: 0x480)
struct UEmbarkCommonTabListWidgetBase : UCommonTabListWidgetBase {
	struct TArray<struct FEmbarkTabDescriptor> RegisteredStaticTabs; // 0x478(0x10)
	char pad_490[0x60]; // 0x490(0x60)

	void SetupStaticTabs(); // Function EmbarkUI.EmbarkCommonTabListWidgetBase.SetupStaticTabs // (Final|Native|Public|BlueprintCallable) // @ game+0x68df330
	bool RegisterDynamicTab(struct FEmbarkTabDescriptor& TabDescriptor); // Function EmbarkUI.EmbarkCommonTabListWidgetBase.RegisterDynamicTab // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x68e2320
	void HandleTabContentCreation(struct FName TabNameID, struct UCommonUserWidget* TabWidget); // Function EmbarkUI.EmbarkCommonTabListWidgetBase.HandleTabContentCreation // (Native|Event|Protected|BlueprintEvent) // @ game+0x68df6e0
	bool GetRegisteredStaticTab(struct FName TabNameID, struct FEmbarkTabDescriptor& OutTabInfo); // Function EmbarkUI.EmbarkCommonTabListWidgetBase.GetRegisteredStaticTab // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x68e3390
	bool GetRegisteredDynamicTab(struct FName TabNameID, struct FEmbarkTabDescriptor& OutTabInfo); // Function EmbarkUI.EmbarkCommonTabListWidgetBase.GetRegisteredDynamicTab // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x68e26a0
	struct UCommonUserWidget* GetActiveTabContent(); // Function EmbarkUI.EmbarkCommonTabListWidgetBase.GetActiveTabContent // (Final|Native|Public|BlueprintCallable) // @ game+0x68e52d0
};

// Class EmbarkUI.EmbarkCommonUIActionRouterBase
// Size: 0x1e0 (Inherited: 0x1e0)
struct UEmbarkCommonUIActionRouterBase : UCommonUIActionRouterBase {

	void SetVirtualClickEnabled(bool bInVirtualClickEnabled); // Function EmbarkUI.EmbarkCommonUIActionRouterBase.SetVirtualClickEnabled // (Final|Native|Public|Const) // @ game+0x68e6f10
};

// Class EmbarkUI.EmbarkDynamicEntryBox
// Size: 0x2e0 (Inherited: 0x2e0)
struct UEmbarkDynamicEntryBox : UDynamicEntryBox {
	bool bAutoWrap; // 0x2d8(0x01)
	float WrapAt; // 0x2dc(0x04)

	void SetWrapAt(float InWrapAt); // Function EmbarkUI.EmbarkDynamicEntryBox.SetWrapAt // (Final|Native|Public|BlueprintCallable) // @ game+0x68e4e00
	void SetAutoWrap(bool bInAutoWrap); // Function EmbarkUI.EmbarkDynamicEntryBox.SetAutoWrap // (Final|Native|Public|BlueprintCallable) // @ game+0x68e7220
};

// Class EmbarkUI.EmbarkEditableTextBase
// Size: 0x8e0 (Inherited: 0x580)
struct UEmbarkEditableTextBase : UEditableText {
	bool bKeepVirtualKeyboardOpenOnFocusLost; // 0x580(0x01)
	char pad_581[0x35f]; // 0x581(0x35f)

	void SetTextBlockStyle(struct FTextBlockStyle& InTextBlockStyle); // Function EmbarkUI.EmbarkEditableTextBase.SetTextBlockStyle // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68dfbb0
	void SetCursorLocation(int32_t& InCursorLocation); // Function EmbarkUI.EmbarkEditableTextBase.SetCursorLocation // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68e0250
	void OnSynchronizeProperties(); // Function EmbarkUI.EmbarkEditableTextBase.OnSynchronizeProperties // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OnConstruct(); // Function EmbarkUI.EmbarkEditableTextBase.OnConstruct // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	int32_t GetCursorLocation(); // Function EmbarkUI.EmbarkEditableTextBase.GetCursorLocation // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x68e14d0
};

// Class EmbarkUI.EmbarkHorizontalMarqueeBox
// Size: 0x240 (Inherited: 0x220)
struct UEmbarkHorizontalMarqueeBox : UHorizontalBox {
	struct FScrollParameters ScrollParameters; // 0x218(0x14)
	char pad_234[0xc]; // 0x234(0x0c)
};

// Class EmbarkUI.EmbarkImageBase
// Size: 0x350 (Inherited: 0x350)
struct UEmbarkImageBase : UImage {

	void OnConstruct(); // Function EmbarkUI.EmbarkImageBase.OnConstruct // (Native|Event|Public|BlueprintEvent) // @ game+0x2f87870
};

// Class EmbarkUI.EmbarkInputBindingCallbackWrapper
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkInputBindingCallbackWrapper : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)

	void ExecuteASCallback(); // Function EmbarkUI.EmbarkInputBindingCallbackWrapper.ExecuteASCallback // (Final|Native|Public|Const) // @ game+0x68e20f0
};

// Class EmbarkUI.EmbarkInputKeySelectorBase
// Size: 0xa00 (Inherited: 0x9d0)
struct UEmbarkInputKeySelectorBase : UInputKeySelector {
	struct FText KeySelection; // 0x9c8(0x18)
	struct FText NoKeySpecified; // 0x9e0(0x18)

	void OnSynchronizeProperties(); // Function EmbarkUI.EmbarkInputKeySelectorBase.OnSynchronizeProperties // (Native|Event|Public|BlueprintEvent) // @ game+0x2f78920
	void OnConstruct(); // Function EmbarkUI.EmbarkInputKeySelectorBase.OnConstruct // (Native|Event|Public|BlueprintEvent) // @ game+0x2b63d50
};

// Class EmbarkUI.EmbarkListView
// Size: 0xd10 (Inherited: 0xcf0)
struct UEmbarkListView : UCommonListView {
	bool bPartialClippingEnabled; // 0xcf0(0x01)
	char pad_cf1[0x3]; // 0xcf1(0x03)
	float PartialClippingMargin; // 0xcf4(0x04)
	bool bScrollBarNoCollapse; // 0xcf8(0x01)
	bool bTrySelectClosestOnFocus; // 0xcf9(0x01)
	char pad_cfa[0x16]; // 0xcfa(0x16)

	void SetTrySelectClosestOnFocus(bool bInTrySelectClosestOnFocus); // Function EmbarkUI.EmbarkListView.SetTrySelectClosestOnFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x68e4480
	void PrewarmListWidgets(struct FVector2D& ExpectedSize); // Function EmbarkUI.EmbarkListView.PrewarmListWidgets // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x68e5330
	void InsertItemAt(struct UObject* Item, int32_t Index); // Function EmbarkUI.EmbarkListView.InsertItemAt // (Final|Native|Public|BlueprintCallable) // @ game+0x68e45c0
};

// Class EmbarkUI.EmbarkLoadingScreenSubsystem
// Size: 0x110 (Inherited: 0xb0)
struct UEmbarkLoadingScreenSubsystem : UScriptGameInstanceSubsystem {
	struct FSoftObjectPath UILoadingScreenConfigurationRef; // 0xb0(0x20)
	char pad_d0[0x40]; // 0xd0(0x40)

	void ShowWidgetLoadingScreen(struct UUserWidget* Widget, struct ULocalPlayer* InPlayer); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.ShowWidgetLoadingScreen // (Final|Native|Public) // @ game+0x68e30a0
	void ShowLoadingScreen(struct FString InMapName); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.ShowLoadingScreen // (Native|Public) // @ game+0x5391220
	void SetNextLoadingScreen(struct FName& Tag); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.SetNextLoadingScreen // (Final|Native|Public|HasOutParms) // @ game+0x68e0460
	void SetCanInterruptLoadingScreen(bool bInCanInterrupt); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.SetCanInterruptLoadingScreen // (Final|Native|Public) // @ game+0x68e46c0
	void SetAutoStopLoadingScreen(bool bInAutoStop); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.SetAutoStopLoadingScreen // (Final|Native|Public) // @ game+0x68e0940
	void OnPreloadContentUrlCallback(struct FURL& InUrl); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.OnPreloadContentUrlCallback // (Final|Native|Protected|HasOutParms) // @ game+0x68e0c70
	void OnPostLoadWorldLoadCallback(struct UWorld* InWorld); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.OnPostLoadWorldLoadCallback // (Final|Native|Protected) // @ game+0x68e2800
	bool IsLoadingScreenVisible(); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.IsLoadingScreenVisible // (Final|Native|Public|Const) // @ game+0x68dfc80
	void HideWidgetLoadingScreen(); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.HideWidgetLoadingScreen // (Final|Native|Public) // @ game+0x68e2440
	void EndLoadingScreen(struct UWorld* InLoadedWorld); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.EndLoadingScreen // (Native|Public) // @ game+0x68df1c0
	void BeginLoadingScreen(struct FString InMapName); // Function EmbarkUI.EmbarkLoadingScreenSubsystem.BeginLoadingScreen // (Native|Public) // @ game+0x68e4080
};

// Class EmbarkUI.IUILoadingScreenBase
// Size: 0xc0 (Inherited: 0xa0)
struct UIUILoadingScreenBase : UObject {
	struct FName Tag; // 0x98(0x08)
	struct TArray<struct FString> MoviePaths; // 0xa0(0x10)
	enum class EMoviePlaybackType PlaybackType; // 0xb0(0x01)
	bool bAllowEngineTick; // 0xb1(0x01)
	float MinimumLoadingScreenDisplayTime; // 0xb4(0x04)
	bool bOverrideStopConfig; // 0xb8(0x01)
	bool bAutoCompleteWhenLoadingCompletes; // 0xb9(0x01)
	bool bWaitForManualStop; // 0xba(0x01)
};

// Class EmbarkUI.UIEmptyLoadingScreen
// Size: 0xf0 (Inherited: 0xc0)
struct UUIEmptyLoadingScreen : UIUILoadingScreenBase {
	struct FSoftObjectPath SpinnerRef; // 0xc0(0x20)
	bool bShowBlackBackground; // 0xe0(0x01)
	char pad_e1[0xf]; // 0xe1(0x0f)
};

// Class EmbarkUI.UIConceptArtLoadingScreen
// Size: 0x260 (Inherited: 0xc0)
struct UUIConceptArtLoadingScreen : UIUILoadingScreenBase {
	struct TArray<struct FUILoadingScreenConfiguration> ConfigurationList; // 0xc0(0x10)
	enum class EUIConceptArtLoadingScreenSelectionStrategy SelectionStrategy; // 0xd0(0x01)
	char pad_d1[0x3]; // 0xd1(0x03)
	int32_t SelectionIndex; // 0xd4(0x04)
	struct FSoftObjectPath SpinnerRef; // 0xd8(0x20)
	struct FSlateFontInfo HeaderFont; // 0xf8(0x58)
	struct FSlateFontInfo SecondHeaderFont; // 0x150(0x58)
	struct FSlateFontInfo SubtitleFont; // 0x1a8(0x58)
	struct FSlateFontInfo SecondSubtitleFont; // 0x200(0x58)
	char pad_258[0x8]; // 0x258(0x08)
};

// Class EmbarkUI.UITipsLoadingScreen
// Size: 0x1b0 (Inherited: 0xc0)
struct UUITipsLoadingScreen : UIUILoadingScreenBase {
	struct TArray<struct FUILoadingScreenConfiguration> ConfigurationList; // 0xc0(0x10)
	struct FSoftObjectPath SpinnerRef; // 0xd0(0x20)
	struct FSlateFontInfo HeaderFont; // 0xf0(0x58)
	struct FSlateFontInfo SubtitleFont; // 0x148(0x58)
	float RefreshDeltaSeconds; // 0x1a0(0x04)
	char pad_1a4[0xc]; // 0x1a4(0x0c)
};

// Class EmbarkUI.UILoadingScreenConfigurationDataAsset
// Size: 0xf0 (Inherited: 0xa0)
struct UUILoadingScreenConfigurationDataAsset : UDataAsset {
	struct TMap<struct FName, struct UIUILoadingScreenBase*> LoadingScreens; // 0xa0(0x50)
};

// Class EmbarkUI.EmbarkEnumLocalizationMapping
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkEnumLocalizationMapping : UPrimaryDataAsset {
	struct FString EnumFullName; // 0xa0(0x10)
	struct TArray<struct FText> EnumValueTexts; // 0xb0(0x10)
};

// Class EmbarkUI.EmbarkMaterialBox
// Size: 0x240 (Inherited: 0x210)
struct UEmbarkMaterialBox : UContentWidget {
	bool bRenderToTexture; // 0x208(0x01)
	enum class EMaterialBoxScaling Scaling; // 0x209(0x01)
	float OversizeScaling; // 0x20c(0x04)
	struct UMaterialInterface* EffectMaterial; // 0x210(0x08)
	struct TArray<struct UMaterialInterface*> AdditionalMaterials; // 0x218(0x10)
	struct FName TextureParameter; // 0x228(0x08)
	char pad_236[0xa]; // 0x236(0x0a)

	void SetTextureParameter(struct FName TextureParameter); // Function EmbarkUI.EmbarkMaterialBox.SetTextureParameter // (Final|Native|Public|BlueprintCallable) // @ game+0x68eb630
	void SetRenderToTexture(bool bInRenderToTexture); // Function EmbarkUI.EmbarkMaterialBox.SetRenderToTexture // (Final|Native|Public|BlueprintCallable) // @ game+0x68ee530
	void SetEffectMaterial(struct UMaterialInterface* EffectMaterial, char Index); // Function EmbarkUI.EmbarkMaterialBox.SetEffectMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0x68ed120
	struct UMaterialInstanceDynamic* GetEffectMaterial(char Index); // Function EmbarkUI.EmbarkMaterialBox.GetEffectMaterial // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68edb70
};

// Class EmbarkUI.EmbarkUserWidget
// Size: 0x3c0 (Inherited: 0x370)
struct UEmbarkUserWidget : UCommonUserWidget {
	struct TMap<struct FName, struct UEmbarkInputBindingCallbackWrapper*> InputActionCallbackMap; // 0x370(0x50)

	void RenameInputComponent(struct FString NewName); // Function EmbarkUI.EmbarkUserWidget.RenameInputComponent // (Final|Native|Protected|Const) // @ game+0x3fa9500
	void RemoveInputActionBinding(struct FDataTableRowHandle& InputActionData); // Function EmbarkUI.EmbarkUserWidget.RemoveInputActionBinding // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68f0920
	struct UWidget* GetCurrentFocus(); // Function EmbarkUI.EmbarkUserWidget.GetCurrentFocus // (BlueprintCosmetic|Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	void BP_SetIsEnabled(bool bInIsEnabled); // Function EmbarkUI.EmbarkUserWidget.BP_SetIsEnabled // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	struct UWidget* BP_GetDesiredFocusTarget(); // Function EmbarkUI.EmbarkUserWidget.BP_GetDesiredFocusTarget // (Event|Protected|BlueprintEvent|Const) // @ game+0x4abfe0
	void AddInputActionBinding(struct FDataTableRowHandle& InputActionData, struct FDelegate& Callback, bool bIsPersistent, bool bInDisplayInActionBar); // Function EmbarkUI.EmbarkUserWidget.AddInputActionBinding // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68f5e80
};

// Class EmbarkUI.EmbarkModalWidget
// Size: 0x410 (Inherited: 0x3c0)
struct UEmbarkModalWidget : UEmbarkUserWidget {
	struct FDelegate UpNavigation; // 0x3c0(0x10)
	struct FDelegate DownNavigation; // 0x3d0(0x10)
	struct FDelegate RightNavigation; // 0x3e0(0x10)
	struct FDelegate LeftNavigation; // 0x3f0(0x10)
	char pad_400[0x10]; // 0x400(0x10)

	struct UWidget* NavigateUp(enum class EUINavigation InNavigation); // Function EmbarkUI.EmbarkModalWidget.NavigateUp // (Native|Event|Protected|BlueprintEvent) // @ game+0x68efb10
	struct UWidget* NavigateRight(enum class EUINavigation InNavigation); // Function EmbarkUI.EmbarkModalWidget.NavigateRight // (Native|Event|Protected|BlueprintEvent) // @ game+0x68e7c90
	struct UWidget* NavigateLeft(enum class EUINavigation InNavigation); // Function EmbarkUI.EmbarkModalWidget.NavigateLeft // (Native|Event|Protected|BlueprintEvent) // @ game+0x68ec1d0
	struct UWidget* NavigateDown(enum class EUINavigation InNavigation); // Function EmbarkUI.EmbarkModalWidget.NavigateDown // (Native|Event|Protected|BlueprintEvent) // @ game+0x68eb230
	void MakeInputActionBlocking(); // Function EmbarkUI.EmbarkModalWidget.MakeInputActionBlocking // (Final|Native|Protected) // @ game+0x68ea250
};

// Class EmbarkUI.EmbarkOverlayingContainer
// Size: 0x230 (Inherited: 0x210)
struct UEmbarkOverlayingContainer : UContentWidget {
	int32_t LayerOffset; // 0x208(0x04)
	bool bValidateLayerOffsetAgainstOwnChildren; // 0x20c(0x01)
	char pad_215[0x1b]; // 0x215(0x1b)

	void SetOverlayingState(bool bInIsHovered); // Function EmbarkUI.EmbarkOverlayingContainer.SetOverlayingState // (Final|Native|Public|BlueprintCallable) // @ game+0x68ece00
	bool IsOverlaying(); // Function EmbarkUI.EmbarkOverlayingContainer.IsOverlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68e9bb0
};

// Class EmbarkUI.EmbarkPatchCheckAsync
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkPatchCheckAsync : UBlueprintAsyncActionBase {
	char pad_a0[0x20]; // 0xa0(0x20)

	struct UEmbarkPatchCheckAsync* StartPatchCheck(struct UObject* WorldContextObject, struct UObject* CallbackObject, struct FName& CallbackFunctionName); // Function EmbarkUI.EmbarkPatchCheckAsync.StartPatchCheck // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x68ea7b0
};

// Class EmbarkUI.EmbarkRichTextBlockBase
// Size: 0x950 (Inherited: 0x910)
struct UEmbarkRichTextBlockBase : URichTextBlock {
	struct FMulticastInlineDelegate OnBeforeGenerateLayout; // 0x910(0x10)
	struct FMulticastInlineDelegate OnAfterGenerateLayout; // 0x920(0x10)
	char pad_930[0x10]; // 0x930(0x10)
	struct UDataTable* EmptyStyleSet; // 0x940(0x08)
	char pad_948[0x8]; // 0x948(0x08)

	void SetInternalDefaultTextStyle(struct FTextBlockStyle& InTextStyle); // Function EmbarkUI.EmbarkRichTextBlockBase.SetInternalDefaultTextStyle // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68e8ba0
	void OnConstruct(); // Function EmbarkUI.EmbarkRichTextBlockBase.OnConstruct // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkUI.EmbarkRichTextBlockColorDecorator
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRichTextBlockColorDecorator : URichTextBlockDecorator {

	struct FLinearColor GetColorForId(struct FString ColorKey, struct FString OpacityKey); // Function EmbarkUI.EmbarkRichTextBlockColorDecorator.GetColorForId // (Event|Public|HasDefaults|BlueprintEvent|Const) // @ game+0x4abfe0
};

// Class EmbarkUI.EmbarkRichtTextBlockStyleAndColorDecorator
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRichtTextBlockStyleAndColorDecorator : UEmbarkRichTextBlockColorDecorator {

	bool GetFontForId(struct FString FontKey, struct FTextBlockStyle& OutFontInfo); // Function EmbarkUI.EmbarkRichtTextBlockStyleAndColorDecorator.GetFontForId // (Native|Event|Public|HasOutParms|BlueprintEvent|Const) // @ game+0x68e85f0
};

// Class EmbarkUI.EmbarkRichTextBlockIconImageDecorator
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkRichTextBlockIconImageDecorator : URichTextBlockDecorator {
	float ScaleFactor; // 0x98(0x04)

	struct UTexture2D* GetInputActionIcon(struct FName Tag); // Function EmbarkUI.EmbarkRichTextBlockIconImageDecorator.GetInputActionIcon // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool CheckForText(struct FName Tag, struct FText& ResultText); // Function EmbarkUI.EmbarkRichTextBlockIconImageDecorator.CheckForText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkUI.EmbarkRichTextBlockWidgetDecorator
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkRichTextBlockWidgetDecorator : URichTextBlockDecorator {
	struct TArray<struct UWidget*> GeneratedWidgets; // 0x98(0x10)

	bool Supports(struct FString Name); // Function EmbarkUI.EmbarkRichTextBlockWidgetDecorator.Supports // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	void OnWidgetInitialized(struct UWidget* Widget, struct TMap<struct FString, struct FString>& MetaData, struct FText& Content, struct FTextBlockStyle& TextStyle, struct UEmbarkRichTextBlockBase* RichTextBlock); // Function EmbarkUI.EmbarkRichTextBlockWidgetDecorator.OnWidgetInitialized // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	struct TArray<struct UWidget*> GetGeneratedWidgets(); // Function EmbarkUI.EmbarkRichTextBlockWidgetDecorator.GetGeneratedWidgets // (Final|Native|Protected|BlueprintCallable|BlueprintPure|Const) // @ game+0x68ec160
	struct UWidget* CreateEntry(struct TMap<struct FString, struct FString>& MetaData, struct FText& Content, struct FTextBlockStyle& TextStyle, struct UEmbarkRichTextBlockBase* RichTextBlock); // Function EmbarkUI.EmbarkRichTextBlockWidgetDecorator.CreateEntry // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ClearWidgets(); // Function EmbarkUI.EmbarkRichTextBlockWidgetDecorator.ClearWidgets // (Final|Native|Protected|BlueprintCallable) // @ game+0x68eabe0
};

// Class EmbarkUI.EmbarkSavingIndicatorSubsystem
// Size: 0xd0 (Inherited: 0xb0)
struct UEmbarkSavingIndicatorSubsystem : UScriptGameInstanceSubsystem {
	char pad_b0[0x20]; // 0xb0(0x20)

	void EndSave(); // Function EmbarkUI.EmbarkSavingIndicatorSubsystem.EndSave // (Native|Public) // @ game+0x29789d0
	void BeginSave(); // Function EmbarkUI.EmbarkSavingIndicatorSubsystem.BeginSave // (Native|Public) // @ game+0x16fe8b0
};

// Class EmbarkUI.EmbarkScrollBoxBase
// Size: 0xd70 (Inherited: 0xd60)
struct UEmbarkScrollBoxBase : UScrollBox {
	bool bPartialClippingEnabled; // 0xd58(0x01)
	float PartialClippingMargin; // 0xd5c(0x04)
	bool bScrollBarNoCollapse; // 0xd60(0x01)
	char pad_d66[0xa]; // 0xd66(0x0a)

	void UpdateStyle(struct FSlateBrush& BottomShadowBrush, struct FSlateBrush& LeftShadowBrush, struct FSlateBrush& RightShadowBrush, struct FSlateBrush& TopShadowBrush); // Function EmbarkUI.EmbarkScrollBoxBase.UpdateStyle // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68e8860
	void UpdateScrollbarStyle(struct FSlateBrush& ForegroundBrush, struct FSlateBrush& BackgroundBrush, int32_t Thickness); // Function EmbarkUI.EmbarkScrollBoxBase.UpdateScrollbarStyle // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68ef250
	void UpdateFullScrollbarStyle(struct FScrollBarStyle& TrackBrush); // Function EmbarkUI.EmbarkScrollBoxBase.UpdateFullScrollbarStyle // (Final|Native|Protected|HasOutParms|BlueprintCallable) // @ game+0x68ebb50
	void SetAllowRightClickDragScrolling(bool bInAllowRightClickDragScrolling); // Function EmbarkUI.EmbarkScrollBoxBase.SetAllowRightClickDragScrolling // (Final|Native|Public|BlueprintCallable) // @ game+0x68eae00
	void OnSynchronizeProperties(); // Function EmbarkUI.EmbarkScrollBoxBase.OnSynchronizeProperties // (Native|Event|Public|BlueprintEvent) // @ game+0x2ce7e50
	void OnConstruct(); // Function EmbarkUI.EmbarkScrollBoxBase.OnConstruct // (Native|Event|Public|BlueprintEvent) // @ game+0x2f930f0
};

// Class EmbarkUI.EmbarkSubtitleWidget
// Size: 0x3e0 (Inherited: 0x3c0)
struct UEmbarkSubtitleWidget : UEmbarkUserWidget {
	char pad_3c0[0x20]; // 0x3c0(0x20)

	void StopSubtitles(struct UObject* InSubtitleOwner); // Function EmbarkUI.EmbarkSubtitleWidget.StopSubtitles // (Final|Native|Static|Protected|BlueprintCallable) // @ game+0x68eca60
	void SetSubtitle(struct UObject* InSubtitleOwner, struct TArray<struct FString>& InSubtitleLines); // Function EmbarkUI.EmbarkSubtitleWidget.SetSubtitle // (Final|Native|Static|Protected|HasOutParms|BlueprintCallable) // @ game+0x68ea290
	void OnSetSubtitleTextChanged(struct FText& InSubtitleText); // Function EmbarkUI.EmbarkSubtitleWidget.OnSetSubtitleTextChanged // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void OnSetSubtitleText(struct FText& InSubtitleText); // Function EmbarkUI.EmbarkSubtitleWidget.OnSetSubtitleText // (Final|Native|Private|HasOutParms) // @ game+0x68ee850
};

// Class EmbarkUI.EmbarkText3DActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct AEmbarkText3DActor : AActor {
	struct FMulticastInlineDelegate OnTextGeneratedDelegate; // 0x398(0x10)
	struct USceneComponent* Text3DComponent; // 0x3a8(0x08)

	void SetText(struct FText& Text); // Function EmbarkUI.EmbarkText3DActor.SetText // (Final|Native|Public|HasOutParms) // @ game+0x68efa30
	void OnTextGenerated(); // Function EmbarkUI.EmbarkText3DActor.OnTextGenerated // (Final|Native|Private) // @ game+0x68eade0
	struct FText GetText(); // Function EmbarkUI.EmbarkText3DActor.GetText // (Final|Native|Public|Const) // @ game+0x68ed2a0
};

// Class EmbarkUI.EmbarkTextBlockBase
// Size: 0x400 (Inherited: 0x3e0)
struct UEmbarkTextBlockBase : UTextBlock {
	bool bEnableTextScrolling; // 0x3d8(0x01)
	struct FScrollParameters ScrollParameters; // 0x3dc(0x14)
	char pad_3f5[0xb]; // 0x3f5(0x0b)

	void SetWrapTextAt(float InWrapTextAt); // Function EmbarkUI.EmbarkTextBlockBase.SetWrapTextAt // (Final|Native|Public) // @ game+0x68e7af0
	void SetLineHeight(float InLineHeightPercentage); // Function EmbarkUI.EmbarkTextBlockBase.SetLineHeight // (Final|Native|Public) // @ game+0x68e9990
	void SetColorBinding(); // Function EmbarkUI.EmbarkTextBlockBase.SetColorBinding // (Final|Native|Public) // @ game+0x68e8f90
	void SetColorAndOpacityDelegate(struct FDelegate InDelegate); // Function EmbarkUI.EmbarkTextBlockBase.SetColorAndOpacityDelegate // (Final|Native|Public) // @ game+0x68eb4f0
	void ResetCompleteScrollState(); // Function EmbarkUI.EmbarkTextBlockBase.ResetCompleteScrollState // (Final|Native|Public) // @ game+0x68ea270
	void OnSynchronizeProperties(); // Function EmbarkUI.EmbarkTextBlockBase.OnSynchronizeProperties // (Native|Event|Public|BlueprintEvent) // @ game+0x32a8d60
	void OnConstruct(); // Function EmbarkUI.EmbarkTextBlockBase.OnConstruct // (Native|Event|Public|BlueprintEvent) // @ game+0x3b06180
	struct FSlateColor GetNativeColor(); // Function EmbarkUI.EmbarkTextBlockBase.GetNativeColor // (Native|Event|Public|BlueprintEvent) // @ game+0x68ee160
};

// Class EmbarkUI.EmbarkTileView
// Size: 0xd30 (Inherited: 0xd20)
struct UEmbarkTileView : UCommonTileView {
	bool bPartialClippingEnabled; // 0xd18(0x01)
	float PartialClippingMargin; // 0xd1c(0x04)
	bool bScrollBarNoCollapse; // 0xd20(0x01)
	bool bTrySelectClosestOnFocus; // 0xd21(0x01)
	char pad_d27[0x9]; // 0xd27(0x09)

	void SetTrySelectClosestOnFocus(bool bInTrySelectClosestOnFocus); // Function EmbarkUI.EmbarkTileView.SetTrySelectClosestOnFocus // (Final|Native|Public|BlueprintCallable) // @ game+0x68e9410
	void PrewarmTileWidgets(struct FVector2D& ExpectedSize); // Function EmbarkUI.EmbarkTileView.PrewarmTileWidgets // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x68e5330
	void InsertItemAt(struct UObject* Item, int32_t Index); // Function EmbarkUI.EmbarkTileView.InsertItemAt // (Final|Native|Public|BlueprintCallable) // @ game+0x68e45c0
};

// Class EmbarkUI.EmbarkTooltipOverlay
// Size: 0x230 (Inherited: 0x220)
struct UEmbarkTooltipOverlay : UOverlay {
	char pad_220[0x10]; // 0x220(0x10)

	bool OnVisualizeTooltip(struct UUserWidget* UserWidget); // Function EmbarkUI.EmbarkTooltipOverlay.OnVisualizeTooltip // (Native|Event|Protected|BlueprintEvent) // @ game+0x68eb590
};

// Class EmbarkUI.EmbarkTooltipPresenter
// Size: 0x230 (Inherited: 0x210)
struct UEmbarkTooltipPresenter : UPanelWidget {
	char pad_210[0x18]; // 0x210(0x18)
	struct UUserWidget* ActiveTooltipWidget; // 0x228(0x08)

	void SetContent(struct UUserWidget* UserWidget); // Function EmbarkUI.EmbarkTooltipPresenter.SetContent // (Final|Native|Protected|BlueprintCallable) // @ game+0x68f7280
	bool GetCustomPosition(struct UUserWidget* UserWidget, struct FVector2D& OutResult); // Function EmbarkUI.EmbarkTooltipPresenter.GetCustomPosition // (Native|Event|Protected|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x68f25b0
};

// Class EmbarkUI.EmbarkUIRenderUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUIRenderUtils : UBlueprintFunctionLibrary {

	void ResizeRenderTarget(struct UTextureRenderTarget2D* RenderTarget, int32_t Width, int32_t Height); // Function EmbarkUI.EmbarkUIRenderUtils.ResizeRenderTarget // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x68f2c70
	void RenderWidgetToRenderTarget(struct UUserWidget* Widget, struct UTextureRenderTarget2D* RenderTarget, float DeltaTime, bool bUseGammaCorrection); // Function EmbarkUI.EmbarkUIRenderUtils.RenderWidgetToRenderTarget // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x68f6730
	void ProjectWorldToWidgetPositions(struct APlayerController* PlayerController, struct TArray<struct FVector>& WorldPositions, struct TArray<struct FUIWorldToWidgetProjectionResult>& OutResults); // Function EmbarkUI.EmbarkUIRenderUtils.ProjectWorldToWidgetPositions // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x68f0540
	struct FVector2D MeasureText(struct FText& Text, struct FSlateFontInfo& Font); // Function EmbarkUI.EmbarkUIRenderUtils.MeasureText // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x68f0370
	struct FVector2D GetTextureSize(struct UTexture* Texture); // Function EmbarkUI.EmbarkUIRenderUtils.GetTextureSize // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x68f3b40
	int32_t GetTextLineHeight(struct FSlateFontInfo& FontInfo, float ScaleY); // Function EmbarkUI.EmbarkUIRenderUtils.GetTextLineHeight // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x68f11f0
	bool EnsureRenderTargetSize(struct UTextureRenderTarget2D* RenderTarget, int32_t Width, int32_t Height); // Function EmbarkUI.EmbarkUIRenderUtils.EnsureRenderTargetSize // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x68f33a0
	void DrawTextToCanvas(struct UCanvas* Canvas, struct FSlateFontInfo& FontInfo, struct FText& Text, struct FVector2D& ScreenPosition, struct FVector2D& Scale, struct FLinearColor& Color, bool bDrawOutline); // Function EmbarkUI.EmbarkUIRenderUtils.DrawTextToCanvas // (Final|RequiredAPI|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x68f7870
	struct UTextureRenderTarget2D* CreateRenderTarget(struct UObject* Owner, int32_t Width, int32_t Height, enum class ETextureRenderTargetFormat RenderTargetFormat, struct FLinearColor ClearColor); // Function EmbarkUI.EmbarkUIRenderUtils.CreateRenderTarget // (Final|RequiredAPI|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x68f1e20
};

// Class EmbarkUI.EmbarkUISettings
// Size: 0x110 (Inherited: 0xb0)
struct UEmbarkUISettings : UDeveloperSettings {
	struct FSoftObjectPath DefaultLoadingScreenBackgroundImage; // 0xa8(0x20)
	struct FSoftObjectPath DefaultLoadingScreenSpinner; // 0xc8(0x20)
	struct FSoftObjectPath DefaultLoadingScreenGradient; // 0xe8(0x20)
	float AnalogStickNavigationPrecision; // 0x108(0x04)
};

// Class EmbarkUI.EmbarkUIStyleDataAsset
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUIStyleDataAsset : UDataAsset {
};

// Class EmbarkUI.EmbarkUIStyleColors
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUIStyleColors : UEmbarkUIStyleDataAsset {
};

// Class EmbarkUI.EmbarkUIStyleOpacity
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUIStyleOpacity : UEmbarkUIStyleDataAsset {
};

// Class EmbarkUI.EmbarkUIStyleTextStyle
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUIStyleTextStyle : UEmbarkUIStyleDataAsset {
};

// Class EmbarkUI.EmbarkUITextureStreamingBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUITextureStreamingBlueprintLibrary : UBlueprintFunctionLibrary {

	bool StreamTexture(struct TSoftObjectPtr<UTexture2D>& TexturePtr, struct UObject* CallbackObject, struct FName CallbackFunction, bool bCallbackOnNullTexture); // Function EmbarkUI.EmbarkUITextureStreamingBlueprintLibrary.StreamTexture // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x68f5ae0
	bool RequestStreamTexture(struct TSoftObjectPtr<UTexture2D>& TexturePtr); // Function EmbarkUI.EmbarkUITextureStreamingBlueprintLibrary.RequestStreamTexture // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x68f2ed0
};

// Class EmbarkUI.EmbarkViewport
// Size: 0x260 (Inherited: 0x260)
struct UEmbarkViewport : UViewport {
};

// Class EmbarkUI.EmbarkWebBrowser
// Size: 0x250 (Inherited: 0x250)
struct UEmbarkWebBrowser : UWebBrowser {
};

// Class EmbarkUI.EmbarkWidgetAnimationSubsystem
// Size: 0x180 (Inherited: 0xa0)
struct UEmbarkWidgetAnimationSubsystem : UWorldSubsystem {
	struct TArray<struct FWidgetAnimationRuntimePlayCache> RuntimePlayCaches; // 0xa0(0x10)
	char pad_b0[0x8]; // 0xb0(0x08)
	struct TArray<struct FPooledDynamicMaterial> PooledDynamicMaterials; // 0xb8(0x10)
	struct TMap<struct UUserWidget*, struct FEmbarkWidgetAnimationArray> WidgetCurrentlyActiveAnimations; // 0xc8(0x50)
	char pad_118[0x18]; // 0x118(0x18)
	struct TMap<struct FEmbarkWidgetAnimationIdNames, struct FWidgetAnimationRuntimePlayCache> TemplateAnimations; // 0x130(0x50)

	void HandleUserWidgetNotifySubsystem(struct UUserWidget* UserWidget, uint32_t NotifyReason); // Function EmbarkUI.EmbarkWidgetAnimationSubsystem.HandleUserWidgetNotifySubsystem // (Final|Native|Private) // @ game+0x68f3bf0
};

// Class EmbarkUI.EmbarkWidgetAnimationFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWidgetAnimationFunctionLibrary : UBlueprintFunctionLibrary {

	void UnbindAllFromAnimationFinished(struct UUserWidget* UserWidget, struct UWidgetAnimation* Animation); // Function EmbarkUI.EmbarkWidgetAnimationFunctionLibrary.UnbindAllFromAnimationFinished // (Final|Native|Static|Public) // @ game+0x68f6d20
	void StopAnimation(struct UUserWidget* UserWidget, struct UWidgetAnimation* Animation, bool bCallOnFinishedCallbacks); // Function EmbarkUI.EmbarkWidgetAnimationFunctionLibrary.StopAnimation // (Final|Native|Static|Public) // @ game+0x68f7120
	void PlayAnimation(struct UUserWidget* UserWidget, struct UWidgetAnimation* Animation, bool bRestoreState, int32_t NumberOfLoops, bool bApplyFirstFrameImmediately); // Function EmbarkUI.EmbarkWidgetAnimationFunctionLibrary.PlayAnimation // (Final|Native|Static|Public) // @ game+0x68f1410
	float PauseAnimation(struct UUserWidget* UserWidget, struct UWidgetAnimation* Animation); // Function EmbarkUI.EmbarkWidgetAnimationFunctionLibrary.PauseAnimation // (Final|Native|Static|Public) // @ game+0x68f3500
	bool IsAnimationPlaying(struct UUserWidget* UserWidget, struct UWidgetAnimation* Animation); // Function EmbarkUI.EmbarkWidgetAnimationFunctionLibrary.IsAnimationPlaying // (Final|Native|Static|Public) // @ game+0x68f5680
	void BindToAnimationFinished(struct UUserWidget* UserWidget, struct UWidgetAnimation* Animation, struct FDelegate Delegate); // Function EmbarkUI.EmbarkWidgetAnimationFunctionLibrary.BindToAnimationFinished // (Final|Native|Static|Public) // @ game+0x68f57b0
};

// Class EmbarkUI.EmbarkWidgetBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWidgetBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetInputMode_GameOnly_WithoutForceFocus(struct APlayerController* PlayerController, bool bFlushInput); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.SetInputMode_GameOnly_WithoutForceFocus // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0x68fdbd0
	void QueryGPUUtilizationPercentAsync(); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.QueryGPUUtilizationPercentAsync // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x68f9440
	bool IsGPUUtilizationQuerySupported(); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.IsGPUUtilizationQuerySupported // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x68fcc50
	struct FPerformanceOverlayStats GetPerformanceOverlayStats(); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.GetPerformanceOverlayStats // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x68f9dd0
	float GetLastGPUUtilizationPercent(); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.GetLastGPUUtilizationPercent // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x68fe110
	struct FDeveloperPerformanceOverlayStats GetDeveloperPerformanceOverlayStats(); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.GetDeveloperPerformanceOverlayStats // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x68f8f90
	struct UAsyncTaskDownloadImage* DownloadImage(struct FString URL); // Function EmbarkUI.EmbarkWidgetBlueprintLibrary.DownloadImage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x68fc0a0
};

// Class EmbarkUI.EmbarkWidgetComponent
// Size: 0x840 (Inherited: 0x830)
struct UEmbarkWidgetComponent : UWidgetComponent {
	enum class TextureFilter RenderTargetTextureFilter; // 0x830(0x01)
	char pad_831[0xf]; // 0x831(0x0f)
};

// Class EmbarkUI.EmbarkWidgetStyles
// Size: 0x830 (Inherited: 0xb0)
struct UEmbarkWidgetStyles : UDeveloperSettings {
	bool bOverridesEnabled; // 0xa8(0x01)
	float CornerRadius; // 0xac(0x04)
	struct FScrollBarStyle DefaultScrollBarStyle; // 0xb0(0x770)
	struct FMargin DefaultScrollBarPadding; // 0x820(0x10)
};

// Class EmbarkUI.QRCodeGeneratorLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UQRCodeGeneratorLibrary : UBlueprintFunctionLibrary {

	struct UTexture2D* GenerateQRCode(struct FString TextToEncode, bool bTransparent); // Function EmbarkUI.QRCodeGeneratorLibrary.GenerateQRCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x68fda40
};

// Class EmbarkUI.RenderOnTopContentContainer
// Size: 0x220 (Inherited: 0x210)
struct URenderOnTopContentContainer : UContentWidget {
	char pad_210[0x10]; // 0x210(0x10)

	void SetActive(bool bActive); // Function EmbarkUI.RenderOnTopContentContainer.SetActive // (Final|Native|Public|BlueprintCallable) // @ game+0x68f81b0
};

// Class EmbarkUI.RenderOnTopDriverContainer
// Size: 0x220 (Inherited: 0x210)
struct URenderOnTopDriverContainer : UContentWidget {
	char pad_210[0x10]; // 0x210(0x10)
};

// Class EmbarkUI.SuperUIDraw
// Size: 0xd0 (Inherited: 0xa0)
struct USuperUIDraw : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct FVector2D Size; // 0xc0(0x10)

	void Tile(struct FSuperUILayout& Layout, struct UMaterialInterface* Material, struct FLinearColor Tint); // Function EmbarkUI.SuperUIDraw.Tile // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x68f9ee0
	void Text(struct FSuperUILayout& Layout, struct FText Text, struct FSlateFontInfo& FontInfo, struct FLinearColor Tint); // Function EmbarkUI.SuperUIDraw.Text // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x68fe820
	void PushRenderTransformTranslate(struct FVector2D Translation); // Function EmbarkUI.SuperUIDraw.PushRenderTransformTranslate // (Final|Native|Public|HasDefaults) // @ game+0x68f8a10
	void PushRenderTransformScale(float Scale, struct FVector2D LayoutPivot); // Function EmbarkUI.SuperUIDraw.PushRenderTransformScale // (Final|Native|Public|HasDefaults) // @ game+0x68faae0
	void PushClip(struct FSuperUILayout& Layout); // Function EmbarkUI.SuperUIDraw.PushClip // (Final|Native|Public|HasOutParms) // @ game+0x68fb1a0
	void PopRenderTransform(); // Function EmbarkUI.SuperUIDraw.PopRenderTransform // (Final|Native|Public) // @ game+0x68f9570
	void PopClip(); // Function EmbarkUI.SuperUIDraw.PopClip // (Final|Native|Public) // @ game+0x68fccc0
	struct FVector2D MeasureText(struct FText& Text, struct FSlateFontInfo& FontInfo); // Function EmbarkUI.SuperUIDraw.MeasureText // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x68fd700
	void Brush(struct FSuperUILayout& Layout, struct FSlateBrush& InBrush, struct FLinearColor Tint); // Function EmbarkUI.SuperUIDraw.Brush // (Final|Native|Public|HasOutParms|HasDefaults) // @ game+0x68f8dd0
};

// Class EmbarkUI.SuperUIWidget
// Size: 0x390 (Inherited: 0x350)
struct USuperUIWidget : UUserWidget {
	char pad_350[0x8]; // 0x350(0x08)
	struct FMulticastInlineDelegate OnMakeView; // 0x358(0x10)
	char pad_368[0x10]; // 0x368(0x10)
	struct USuperUIDraw* SuperUIDraw; // 0x378(0x08)
	struct TArray<struct FSuperUIInput> Inputs; // 0x380(0x10)
};

// Class EmbarkUI.UIAnimationState
// Size: 0xe0 (Inherited: 0xa0)
struct UUIAnimationState : UObject {
	struct FGeometry InitialParticipantGeometry; // 0x98(0x38)
	float Distance; // 0xd0(0x04)
	float AnimationProgress; // 0xd4(0x04)

	bool ShouldApplyAnimation(); // Function EmbarkUI.UIAnimationState.ShouldApplyAnimation // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x339d9b0
	bool IsAnimationOngoing(); // Function EmbarkUI.UIAnimationState.IsAnimationOngoing // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68fdcd0
};

// Class EmbarkUI.UIAnimationParticipantContainer
// Size: 0x270 (Inherited: 0x210)
struct UUIAnimationParticipantContainer : UContentWidget {
	bool bStartAnimationWithZeroRenderOpacity; // 0x208(0x01)
	bool bInitWithAnimationDone; // 0x209(0x01)
	struct UUIAnimationState* AnimationState; // 0x210(0x08)
	struct FMulticastInlineDelegate OnGlobalAnimationStarted; // 0x218(0x10)
	struct FMulticastInlineDelegate OnGlobalAnimationCompleted; // 0x228(0x10)
	struct FMulticastInlineDelegate OnAnimationStarted; // 0x238(0x10)
	struct FMulticastInlineDelegate OnAnimationCompleted; // 0x248(0x10)
	char pad_25a[0x16]; // 0x25a(0x16)

	void TickAnimation(struct FUIAnimationTickParameter& Parameter); // Function EmbarkUI.UIAnimationParticipantContainer.TickAnimation // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void PreTickAnimation(bool bIsAnimating, float AnimationProgress); // Function EmbarkUI.UIAnimationParticipantContainer.PreTickAnimation // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void GlobalAnimationStart(); // Function EmbarkUI.UIAnimationParticipantContainer.GlobalAnimationStart // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void GlobalAnimationComplete(); // Function EmbarkUI.UIAnimationParticipantContainer.GlobalAnimationComplete // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void AnimationStart(); // Function EmbarkUI.UIAnimationParticipantContainer.AnimationStart // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void AnimationComplete(); // Function EmbarkUI.UIAnimationParticipantContainer.AnimationComplete // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class EmbarkUI.UIAnimationDriverContainer
// Size: 0x240 (Inherited: 0x210)
struct UUIAnimationDriverContainer : UContentWidget {
	float AnimationTimeElapsed; // 0x208(0x04)
	float AnimationDurationSeconds; // 0x20c(0x04)
	float AnimationParticipantDurationSeconds; // 0x210(0x04)
	bool bEvenTimeSpacing; // 0x214(0x01)
	char pad_21d[0x23]; // 0x21d(0x23)

	void StopAnimation(); // Function EmbarkUI.UIAnimationDriverContainer.StopAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x68fbbb0
	void StartAnimation(); // Function EmbarkUI.UIAnimationDriverContainer.StartAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x68fec60
	void PopulateStateDistance(struct TArray<struct UUIAnimationState*>& States, struct FGeometry& ContainerGeometry); // Function EmbarkUI.UIAnimationDriverContainer.PopulateStateDistance // (Native|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x68fcff0
	bool IsAnimating(); // Function EmbarkUI.UIAnimationDriverContainer.IsAnimating // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68fa0c0
};

// Class EmbarkUI.UIMetaDataAsset
// Size: 0xc0 (Inherited: 0xa0)
struct UUIMetaDataAsset : UPrimaryDataAsset {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TArray<struct UUIMetaDataItem*> Items; // 0xa8(0x10)
	char pad_b8[0x8]; // 0xb8(0x08)
};

// Class EmbarkUI.UIMetaDataItem
// Size: 0xa0 (Inherited: 0xa0)
struct UUIMetaDataItem : UObject {

	int64_t GetKey(); // Function EmbarkUI.UIMetaDataItem.GetKey // (Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2db2d70
	struct FString GetDebugDisplayName(); // Function EmbarkUI.UIMetaDataItem.GetDebugDisplayName // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x2e2a990
};

// Class EmbarkUI.IUIMetaDataRepository
// Size: 0xa0 (Inherited: 0xa0)
struct UIUIMetaDataRepository : UDataAsset {

	void Uninitialize(); // Function EmbarkUI.IUIMetaDataRepository.Uninitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x2b95cb0
	bool IsInitialized(); // Function EmbarkUI.IUIMetaDataRepository.IsInitialized // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3acf850
	void Initialize(); // Function EmbarkUI.IUIMetaDataRepository.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x2b96540
	struct UUIMetaDataItem* GetItemByKey(struct UObject* ItemClass, int64_t Key); // Function EmbarkUI.IUIMetaDataRepository.GetItemByKey // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x68fcde0
};

// Class EmbarkUI.UIMetaDataRepository
// Size: 0x110 (Inherited: 0xa0)
struct UUIMetaDataRepository : UIUIMetaDataRepository {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TMap<int64_t, struct UUIMetaDataItem*> ItemMap; // 0xa8(0x50)
	char pad_f8[0x18]; // 0xf8(0x18)
};

// Class EmbarkUI.UISimpleAnimationContainer
// Size: 0x230 (Inherited: 0x210)
struct UUISimpleAnimationContainer : UContentWidget {
	bool bIsPulsing; // 0x208(0x01)
	float PulseMinOpacity; // 0x20c(0x04)
	float PulseDuration; // 0x210(0x04)
	float FadeInDuration; // 0x214(0x04)
	float FadeOutDuration; // 0x218(0x04)
	char pad_221[0xf]; // 0x221(0x0f)

	void RestartAnimation(); // Function EmbarkUI.UISimpleAnimationContainer.RestartAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x690e500
	void PlayExitAnimation(); // Function EmbarkUI.UISimpleAnimationContainer.PlayExitAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0x6926cc0
};

// Class EmbarkUI.UITextureDownloadCache
// Size: 0x160 (Inherited: 0xa0)
struct UUITextureDownloadCache : UWorldSubsystem {
	char pad_a0[0xc0]; // 0xa0(0xc0)
};

// Class EmbarkUI.UITextureProvider
// Size: 0x110 (Inherited: 0xa0)
struct UUITextureProvider : UObject {
	struct FMulticastInlineDelegate OnTextureLoaded; // 0x98(0x10)
	struct FMulticastInlineDelegate OnTextureLoadFailed; // 0xa8(0x10)
	struct UAsyncTaskDownloadImage* ImageDownloader; // 0xb8(0x08)
	struct UTexture2DDynamic* DynamicTexture; // 0xc0(0x08)
	char pad_d0[0x40]; // 0xd0(0x40)

	double TimeSinceStreamingStarted(); // Function EmbarkUI.UITextureProvider.TimeSinceStreamingStarted // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6906270
	double TimeSinceStreamingEnded(); // Function EmbarkUI.UITextureProvider.TimeSinceStreamingEnded // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x693b6d0
	void StartTextureRetrieval(struct APlayerController* PlayerController, struct FString InUrl); // Function EmbarkUI.UITextureProvider.StartTextureRetrieval // (Final|Native|Public|BlueprintCallable) // @ game+0x693a7c0
	void SetOptional(bool bInOptional); // Function EmbarkUI.UITextureProvider.SetOptional // (Final|Native|Public|BlueprintCallable) // @ game+0x692ebb0
	void SetOnImage(struct UImage* Target, bool bMatchSize); // Function EmbarkUI.UITextureProvider.SetOnImage // (Final|Native|Public|BlueprintCallable) // @ game+0x69231a0
	void ReleaseTexture(); // Function EmbarkUI.UITextureProvider.ReleaseTexture // (Final|Native|Public|BlueprintCallable) // @ game+0x69098a0
	void OnTextureStreamedIn(); // Function EmbarkUI.UITextureProvider.OnTextureStreamedIn // (Final|Native|Private) // @ game+0x6917490
	void OnDownloadSuccess(struct UTexture2DDynamic* Texture); // Function EmbarkUI.UITextureProvider.OnDownloadSuccess // (Final|Native|Private) // @ game+0x693c7b0
	void OnDownloadFailed(enum class EUITextureDownloadFailure Failure); // Function EmbarkUI.UITextureProvider.OnDownloadFailed // (Final|Native|Private) // @ game+0x6933a20
	void OnDirectDownloadFailed(struct UTexture2DDynamic* Texture); // Function EmbarkUI.UITextureProvider.OnDirectDownloadFailed // (Final|Native|Private) // @ game+0x6908d50
	bool IsTextureLoadingComplete(); // Function EmbarkUI.UITextureProvider.IsTextureLoadingComplete // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x68ff350
	enum class EUITextureProviderState GetState(); // Function EmbarkUI.UITextureProvider.GetState // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x17033a0
	bool GetOptionalDownloadFailure(enum class EUITextureDownloadFailure& OutFailure); // Function EmbarkUI.UITextureProvider.GetOptionalDownloadFailure // (Final|Native|Public|HasOutParms|Const) // @ game+0x6913460
};

// Class EmbarkUI.WatermarkBaseWidget
// Size: 0x3a0 (Inherited: 0x350)
struct UWatermarkBaseWidget : UUserWidget {
	struct UWidget* WatermarkContent; // 0x348(0x08)
	struct FText Label; // 0x350(0x18)
	float TimeThreshold; // 0x368(0x04)
	struct FWatermarkGrid Grid; // 0x36c(0x0c)
	char pad_380[0x20]; // 0x380(0x20)

	void SetPath(struct FString InPath); // Function EmbarkUI.WatermarkBaseWidget.SetPath // (Final|Native|Public|BlueprintCallable) // @ game+0x690c380
};

// Class EmbarkUI.EmbarkUIUtils
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkUIUtils : UBlueprintFunctionLibrary {

	struct FString PrintAllOwningUserWidgets(struct UWidget* Widget); // Function EmbarkUI.EmbarkUIUtils.PrintAllOwningUserWidgets // (Final|Native|Static|Public) // @ game+0x6938c40
	bool IsWidgetReachableForInput(struct UWidget* Widget); // Function EmbarkUI.EmbarkUIUtils.IsWidgetReachableForInput // (Final|Native|Static|Public) // @ game+0x69378e0
	bool IsWidgetInActiveRoot(struct UWidget* Widget, struct ULocalPlayer* LocalPlayer); // Function EmbarkUI.EmbarkUIUtils.IsWidgetInActiveRoot // (Final|Native|Static|Public) // @ game+0x69096a0
	struct FEnhancedActionKeyMapping GetKeyMappingForInputActionOfInputType(struct ULocalPlayer* LocalPlayer, enum class ECommonInputType InputType, struct UInputAction* EnhancedInputAction); // Function EmbarkUI.EmbarkUIUtils.GetKeyMappingForInputActionOfInputType // (Final|Native|Static|Public) // @ game+0x692fbb0
	struct FSlateBrush GetIconForEnhancedInputAction(struct UCommonInputSubsystem* CommonInputSubsystem, struct UInputAction* EnhancedInputAction); // Function EmbarkUI.EmbarkUIUtils.GetIconForEnhancedInputAction // (Final|Native|Static|Public) // @ game+0x6922090
	struct FKey GetFirstKeyForInputType(struct ULocalPlayer* LocalPlayer, enum class ECommonInputType InputType, struct UInputAction* EnhancedInputAction); // Function EmbarkUI.EmbarkUIUtils.GetFirstKeyForInputType // (Final|Native|Static|Public) // @ game+0x693b950
	struct UInputAction* GetEnhancedInputClickAction(); // Function EmbarkUI.EmbarkUIUtils.GetEnhancedInputClickAction // (Final|Native|Static|Public) // @ game+0x69346f0
	struct UInputAction* GetEnhancedInputBackAction(); // Function EmbarkUI.EmbarkUIUtils.GetEnhancedInputBackAction // (Final|Native|Static|Public) // @ game+0x690c430
	void EnableSlateNavigation(); // Function EmbarkUI.EmbarkUIUtils.EnableSlateNavigation // (Final|Native|Static|Public) // @ game+0x6927ba0
	void EnableAnalogNavigation(); // Function EmbarkUI.EmbarkUIUtils.EnableAnalogNavigation // (Final|Native|Static|Public) // @ game+0x690f010
	void DisableSlateNavigation(); // Function EmbarkUI.EmbarkUIUtils.DisableSlateNavigation // (Final|Native|Static|Public) // @ game+0x693a270
	void DisableAnalogNavigation(); // Function EmbarkUI.EmbarkUIUtils.DisableAnalogNavigation // (Final|Native|Static|Public) // @ game+0x690e520
};

