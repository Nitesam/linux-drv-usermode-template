// Class ConsoleVariablesEditorRuntime.ConsoleVariablesAsset
// Size: 0xc0 (Inherited: 0xa0)
struct UConsoleVariablesAsset : UObject {
	struct FString VariableCollectionDescription; // 0xa0(0x10)
	struct TArray<struct FConsoleVariablesEditorAssetSaveData> SavedCommands; // 0xb0(0x10)

	void SetVariableCollectionDescription(struct FString InVariableCollectionDescription); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.SetVariableCollectionDescription // (Final|Native|Public|BlueprintCallable) // @ game+0x9c1d860
	void ReplaceSavedCommands(struct TArray<struct FConsoleVariablesEditorAssetSaveData>& Replacement); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.ReplaceSavedCommands // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9c1f6b0
	bool RemoveConsoleVariable(struct FString InCommandString); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.RemoveConsoleVariable // (Final|Native|Public|BlueprintCallable) // @ game+0x9c224a0
	struct FString GetVariableCollectionDescription(); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetVariableCollectionDescription // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x25387e0
	int32_t GetSavedCommandsCount(); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x32aeb20
	struct TArray<struct FString> GetSavedCommandsAsStringArray(bool bOnlyIncludeChecked); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsAsStringArray // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9c1fdb0
	struct FString GetSavedCommandsAsCommaSeparatedString(bool bOnlyIncludeChecked); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommandsAsCommaSeparatedString // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9c1eca0
	struct TArray<struct FConsoleVariablesEditorAssetSaveData> GetSavedCommands(); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.GetSavedCommands // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9c1e6e0
	bool FindSavedDataByCommandString(struct FString InCommandString, struct FConsoleVariablesEditorAssetSaveData& OutValue, enum class ESearchCase SearchCase); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.FindSavedDataByCommandString // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x9c1d9b0
	void ExecuteSavedCommands(struct UObject* WorldContextObject, bool bOnlyIncludeChecked); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.ExecuteSavedCommands // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x9c22250
	void CopyFrom(struct UConsoleVariablesAsset* InAssetToCopy); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.CopyFrom // (Final|Native|Public|BlueprintCallable) // @ game+0x9c1e780
	void AddOrSetConsoleObjectSavedData(struct FConsoleVariablesEditorAssetSaveData& InData); // Function ConsoleVariablesEditorRuntime.ConsoleVariablesAsset.AddOrSetConsoleObjectSavedData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9c223d0
};

