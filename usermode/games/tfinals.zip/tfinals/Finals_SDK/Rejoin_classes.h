// Class Rejoin.RejoinCheck
// Size: 0x200 (Inherited: 0xa0)
struct URejoinCheck : UObject {
	enum class ERejoinStatus LastKnownStatus; // 0x98(0x01)
	bool bRejoinAfterCheck; // 0x99(0x01)
	bool bAttemptingRejoin; // 0x9a(0x01)
	char pad_a3[0x15d]; // 0xa3(0x15d)
};

