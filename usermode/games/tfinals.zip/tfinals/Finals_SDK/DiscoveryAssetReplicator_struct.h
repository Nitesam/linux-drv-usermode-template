// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_CharacterCustomizationItem
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_CharacterCustomizationItem : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_WeaponCharmDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_WeaponCharmDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_WeaponSkinDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_WeaponSkinDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_WeaponStickerDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_WeaponStickerDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_AnimationCustomizationDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_AnimationCustomizationDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_WeaponAttachmentDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_WeaponAttachmentDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_DiscoveryItemCardDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_DiscoveryItemCardDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_CharacterArchetypeDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_CharacterArchetypeDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_CharacterInGameEmoteDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_CharacterInGameEmoteDataAsset : FAssetReplicatorIdBase {
};

// ScriptStruct DiscoveryAssetReplicator.AssetReplicatorId_CharacterExpressionDataAsset
// Size: 0x10 (Inherited: 0x10)
struct FAssetReplicatorId_CharacterExpressionDataAsset : FAssetReplicatorIdBase {
};

