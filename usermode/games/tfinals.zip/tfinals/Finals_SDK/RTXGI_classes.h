// Class RTXGI.DDGICapture
// Size: 0x3a0 (Inherited: 0x3a0)
struct ADDGICapture : AActor {
	struct UDDGICaptureComponent* DDGICaptureComponent; // 0x398(0x08)
};

// Class RTXGI.DDGICaptureRegistry
// Size: 0xb0 (Inherited: 0xa0)
struct UDDGICaptureRegistry : UObject {
	struct TArray<struct FDDGIVolumeCaptureData> CapturedVolumes; // 0x98(0x10)
};

// Class RTXGI.DDGICaptureComponent
// Size: 0x430 (Inherited: 0x3c0)
struct UDDGICaptureComponent : USceneComponent {
	struct TArray<struct FDDGILevelCaptureData> CapturedLevels; // 0x3c0(0x10)
	bool bAllowDDGICascades; // 0x3d0(0x01)
	char pad_3d1[0x5f]; // 0x3d1(0x5f)
};

// Class RTXGI.DDGIVolume
// Size: 0x3e0 (Inherited: 0x3d0)
struct ADDGIVolume : AVolume {
	struct UDDGIVolumeComponent* DDGIVolumeComponent; // 0x3d0(0x08)
	char pad_3d8[0x8]; // 0x3d8(0x08)
};

// Class RTXGI.DDGIVolumeComponent
// Size: 0x520 (Inherited: 0x3c0)
struct UDDGIVolumeComponent : USceneComponent {
	char pad_3c0[0x8]; // 0x3c0(0x08)
	bool EnableVolume; // 0x3c8(0x01)
	char pad_3c9[0x3]; // 0x3c9(0x03)
	float UpdatePriority; // 0x3cc(0x04)
	float CullFactor; // 0x3d0(0x04)
	int32_t LightingPriority; // 0x3d4(0x04)
	float BlendingDistance; // 0x3d8(0x04)
	float BlendingCutoffDistance; // 0x3dc(0x04)
	bool RuntimeStatic; // 0x3e0(0x01)
	char pad_3e1[0x3]; // 0x3e1(0x03)
	enum class EDDGIRaysPerProbe RaysPerProbe; // 0x3e4(0x04)
	struct FIntVector ProbeCounts; // 0x3e8(0x0c)
	float ProbeMaxRayDistance; // 0x3f4(0x04)
	float ProbeHistoryWeight; // 0x3f8(0x04)
	struct FProbeRelocation ProbeRelocation; // 0x3fc(0x0c)
	bool VisualizeProbes; // 0x408(0x01)
	char pad_409[0x3]; // 0x409(0x03)
	float probeDistanceExponent; // 0x40c(0x04)
	float probeIrradianceEncodingGamma; // 0x410(0x04)
	float probeChangeThreshold; // 0x414(0x04)
	float probeBrightnessThreshold; // 0x418(0x04)
	float probeSkyOcclusionMultiplier; // 0x41c(0x04)
	float probeSkyOcclusionWeightExponent; // 0x420(0x04)
	float probeSkyOcclusionDistanceThreshold; // 0x424(0x04)
	float ViewBias; // 0x428(0x04)
	float NormalBias; // 0x42c(0x04)
	float LightMultiplier; // 0x430(0x04)
	float EmissiveMultiplier; // 0x434(0x04)
	float VolumetricFogMultiplier; // 0x438(0x04)
	float IrradianceScalar; // 0x43c(0x04)
	struct FLightingChannels LightingChannels; // 0x440(0x01)
	char pad_441[0x7]; // 0x441(0x07)
	struct TArray<struct FGuid> IrradianceNeighborId; // 0x448(0x10)
	struct FGuid VolumeId; // 0x458(0x10)
	char pad_468[0xb8]; // 0x468(0xb8)

	void ToggleVolume(bool IsVolumeEnabled); // Function RTXGI.DDGIVolumeComponent.ToggleVolume // (Final|Native|Public|BlueprintCallable) // @ game+0x5af2ed0
	void SetLightMultiplier(float NewLightMultiplier); // Function RTXGI.DDGIVolumeComponent.SetLightMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x5ad7b50
	void SetIrradianceScalar(float NewIrradianceScalar); // Function RTXGI.DDGIVolumeComponent.SetIrradianceScalar // (Final|Native|Public|BlueprintCallable) // @ game+0x5af2020
	void SetEmissiveMultiplier(float NewEmissiveMultiplier); // Function RTXGI.DDGIVolumeComponent.SetEmissiveMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0x5ac1660
	float GetLightMultiplier(); // Function RTXGI.DDGIVolumeComponent.GetLightMultiplier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5acbb70
	float GetIrradianceScalar(); // Function RTXGI.DDGIVolumeComponent.GetIrradianceScalar // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5aebac0
	float GetEmissiveMultiplier(); // Function RTXGI.DDGIVolumeComponent.GetEmissiveMultiplier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5ac97f0
	void DDGIClearVolumes(); // Function RTXGI.DDGIVolumeComponent.DDGIClearVolumes // (Final|Exec|Native|Public) // @ game+0x5ab9e30
	void ClearProbeData(); // Function RTXGI.DDGIVolumeComponent.ClearProbeData // (Final|Native|Public|BlueprintCallable) // @ game+0x5af8fd0
};

// Class RTXGI.RTXGIPluginSettings
// Size: 0x1c0 (Inherited: 0xb0)
struct URTXGIPluginSettings : UDeveloperSettings {
	enum class ERTXGIQualityPreset Preset; // 0xa8(0x01)
	bool Enabled; // 0xa9(0x01)
	enum class ERTXGISurfacesMode SurfacesMode; // 0xaa(0x01)
	enum class ERTXGIVolumetricsMode VolumetricsMode; // 0xab(0x01)
	enum class ERTXGICompositeMode CompositeMode; // 0xac(0x01)
	enum class EDDGISkyLightType SkyLightOnRayMissType; // 0xb0(0x04)
	bool SkyLightOnRayMissApplyBelowHorizon; // 0xb4(0x01)
	float ResolutionScale; // 0xb8(0x04)
	float NormalPower; // 0xbc(0x04)
	int32_t PathsPerPixel; // 0xc0(0x04)
	int32_t RaysPerPath; // 0xc4(0x04)
	float RayMaxLength; // 0xc8(0x04)
	float RayNormalBias; // 0xcc(0x04)
	float RayViewBias; // 0xd0(0x04)
	float RoughnessThreshold; // 0xd4(0x04)
	float RadianceBoost; // 0xd8(0x04)
	enum class ERTXGIPathTraceCheckerboardMode CheckerboardMode; // 0xdc(0x01)
	enum class ERTXGIPathTraceDenoiseMode DenoiseMode; // 0xdd(0x01)
	bool PTShaderExecutionReordering; // 0xde(0x01)
	bool DDGIDynamicUpdate; // 0xdf(0x01)
	bool DDGISoftwareRayTracing; // 0xe0(0x01)
	enum class ERTXGIDDGIRayDataBitDepth DDGIRayDataBitDepth; // 0xe1(0x01)
	enum class ERTXGIDDGIDistanceBitDepth DDGIProbeDistanceBitDepth; // 0xe2(0x01)
	float DDGIVolumetricFogIrradianceScale; // 0xe4(0x04)
	float DDGIVolumetricFogMaxContribution; // 0xe8(0x04)
	float DDGIVolumetricFogViewBias; // 0xec(0x04)
	float DDGIFadeTime; // 0xf0(0x04)
	float DDGIFadeScreenRadiusThreshold; // 0xf4(0x04)
	bool DDGIIrradianceNeighbors; // 0xf8(0x01)
	bool DDGISkyOcclusionEnable; // 0xf9(0x01)
	char pad_fb[0x1]; // 0xfb(0x01)
	float DDGISkyOcclusionExponent; // 0xfc(0x04)
	int32_t DDGIMaxRaysPerProbeInGame; // 0x100(0x04)
	float DDGIMaxRayDistanceInGame; // 0x104(0x04)
	float DDGITextureMipBias; // 0x108(0x04)
	int32_t DDGIFrameRayBudget; // 0x10c(0x04)
	int32_t DDGIMaxVolumesToAllowForUpdate; // 0x110(0x04)
	int32_t DDGIMaxVolumesToConsiderForUpdate; // 0x114(0x04)
	float DDGIPriorityScreenPercentage; // 0x118(0x04)
	float DDGICullDistanceInfluence; // 0x11c(0x04)
	int32_t DDGIUpdateAllVolumesEveryFrame; // 0x120(0x04)
	bool DDGIProbeSerialization; // 0x124(0x01)
	bool DDGIShaderExecutionReordering; // 0x125(0x01)
	bool VisRTMaterials; // 0x126(0x01)
	enum class ERTXGIVisDDGIProbeData VisDDGIProbeDataMode; // 0x127(0x01)
	enum class ERTXGIVisDDGIProbeView VisDDGIProbeViewMode; // 0x128(0x01)
	char pad_129[0x3]; // 0x129(0x03)
	float VisDDGIProbeRadius; // 0x12c(0x04)
	float VisDDGIProbeDistanceScale; // 0x130(0x04)
	char pad_134[0x8c]; // 0x134(0x8c)
};

