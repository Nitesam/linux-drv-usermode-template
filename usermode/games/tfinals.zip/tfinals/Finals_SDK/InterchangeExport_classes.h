// Class InterchangeExport.InterchangeTextureWriter
// Size: 0xa0 (Inherited: 0xa0)
struct UInterchangeTextureWriter : UInterchangeWriterBase {
};

