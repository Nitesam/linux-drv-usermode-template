// Class AudioCapture.AudioCapture
// Size: 0x120 (Inherited: 0x120)
struct UAudioCapture : UAudioGenerator {

	void StopCapturingAudio(); // Function AudioCapture.AudioCapture.StopCapturingAudio // (Final|Native|Public|BlueprintCallable) // @ game+0x9c65590
	void StartCapturingAudio(); // Function AudioCapture.AudioCapture.StartCapturingAudio // (Final|Native|Public|BlueprintCallable) // @ game+0x9c63fb0
	bool IsCapturingAudio(); // Function AudioCapture.AudioCapture.IsCapturingAudio // (Final|Native|Public|BlueprintCallable) // @ game+0x9c61ae0
	bool GetAudioCaptureDeviceInfo(struct FAudioCaptureDeviceInfo& OutInfo); // Function AudioCapture.AudioCapture.GetAudioCaptureDeviceInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9c66160
};

// Class AudioCapture.AudioCaptureFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioCaptureFunctionLibrary : UBlueprintFunctionLibrary {

	struct UAudioCapture* CreateAudioCapture(); // Function AudioCapture.AudioCaptureFunctionLibrary.CreateAudioCapture // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9c64a00
};

// Class AudioCapture.AudioCaptureBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAudioCaptureBlueprintLibrary : UBlueprintFunctionLibrary {

	void GetAvailableAudioInputDevices(struct UObject* WorldContextObject, struct FDelegate& OnObtainDevicesEvent); // Function AudioCapture.AudioCaptureBlueprintLibrary.GetAvailableAudioInputDevices // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9c65ee0
	struct FString Conv_AudioInputDeviceInfoToString(struct FAudioInputDeviceInfo& Info); // Function AudioCapture.AudioCaptureBlueprintLibrary.Conv_AudioInputDeviceInfoToString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x9c61960
};

// Class AudioCapture.AudioCaptureComponent
// Size: 0xae0 (Inherited: 0xa20)
struct UAudioCaptureComponent : USynthComponent {
	int32_t JitterLatencyFrames; // 0xa20(0x04)
	char pad_a24[0xbc]; // 0xa24(0xbc)
};

