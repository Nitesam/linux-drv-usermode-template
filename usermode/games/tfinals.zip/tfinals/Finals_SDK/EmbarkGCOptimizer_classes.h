// Class EmbarkGCOptimizer.EmbarkWorldPartitionRuntimeCellTransformerGCOptimizer
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkWorldPartitionRuntimeCellTransformerGCOptimizer : UWorldPartitionRuntimeCellTransformer {
};

// Class EmbarkGCOptimizer.NonGCObjectsContainer
// Size: 0xb0 (Inherited: 0xa0)
struct UNonGCObjectsContainer : UObject {
	struct TArray<struct UObject*> Objects; // 0x98(0x10)
};

// Class EmbarkGCOptimizer.WorldPartitionNonGCObjects
// Size: 0x3c0 (Inherited: 0x3a0)
struct AWorldPartitionNonGCObjects : AActor {
	struct UNonGCObjectsContainer* NonGC; // 0x398(0x08)
	struct TArray<struct UObject*> ShouldGC; // 0x3a0(0x10)
	bool bIsEnabled; // 0x3b0(0x01)
	char pad_3b9[0x7]; // 0x3b9(0x07)
};

