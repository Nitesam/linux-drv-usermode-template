// Enum EmbarkLNG.ELNGDebugVisFlags
enum class ELNGDebugVisFlags : uint8_t {
	None = 0,
	DrawNodes = 1,
	DrawLinks = 2,
	DrawEncroachmentChecks = 4,
	DrawSuccessfulNodeChecks = 8,
	DrawRejectedEdges_StepHeight = 16,
	DrawRejectedEdges_PathSlope = 32,
	DrawRejectedEdges_TraversalSweep = 64,
	DrawRejectedEdges_InvalidNodeData = 128,
	DrawAllRejectedEdges = 240,
	DrawAll = 255,
	ELNGDebugVisFlags_MAX = 256
};

// Enum EmbarkLNG.ELNGEdgeRejectReason
enum class ELNGEdgeRejectReason : uint8_t {
	None = 0,
	Proximity = 1,
	StepHeight = 2,
	PathSlope = 3,
	TraversalSweep = 4,
	InvalidNodeData = 5,
	ELNGEdgeRejectReason_MAX = 6
};

// Enum EmbarkLNG.ELNGDebugEntryType
enum class ELNGDebugEntryType : uint8_t {
	NodeGenerationCheck = 0,
	EdgeConnectionCheck = 1,
	ELNGDebugEntryType_MAX = 2
};

// Enum EmbarkLNG.ELNGNodeType
enum class ELNGNodeType : uint8_t {
	Invalid = 0,
	GraphNode = 1,
	Blocked = 2,
	All = 3,
	ELNGNodeType_MAX = 4
};

// ScriptStruct EmbarkLNG.LNGGenerationDebugEntry
// Size: 0x1f0 (Inherited: 0x00)
struct FLNGGenerationDebugEntry {
	enum class ELNGDebugEntryType EntryType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FVector NodeInitialTraceStart; // 0x08(0x18)
	struct FVector NodeInitialTraceEnd; // 0x20(0x18)
	struct FVector NodeGroundHitLocation; // 0x38(0x18)
	struct FVector NodeGroundImpactNormal; // 0x50(0x18)
	bool bIsEncroachmentFailure; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
	struct FVector NodeEncroachmentImpactNormal; // 0x70(0x18)
	struct FVector NodeEncroachmentHitLocation; // 0x88(0x18)
	struct FVector EdgeNodeAWorldLocation; // 0xa0(0x18)
	struct FVector EdgeNodeBWorldLocation; // 0xb8(0x18)
	enum class ELNGEdgeRejectReason EdgeRejectReason; // 0xd0(0x01)
	char pad_d1[0x7]; // 0xd1(0x07)
	struct FVector EdgeTraversalSweepHitLocation; // 0xd8(0x18)
	struct FVector EdgeTraversalSweepImpactNormal; // 0xf0(0x18)
	struct FHitResult RejectedHitResult; // 0x108(0xe8)
};

// ScriptStruct EmbarkLNG.LNGActorDebugData
// Size: 0x68 (Inherited: 0x00)
struct FLNGActorDebugData {
	struct TArray<struct FLNGGenerationDebugEntry> AllDebugEntries; // 0x00(0x10)
	struct FVector OffsetLocation; // 0x10(0x18)
	struct FVector ImpactNormal; // 0x28(0x18)
	int32_t TotalPointsRejectedDueToNoGround; // 0x40(0x04)
	int32_t TotalPointsChecked; // 0x44(0x04)
	int32_t TotalPointsRejectedDueToSteepSlope; // 0x48(0x04)
	int32_t TotalPointsRejectedDueToAgentVolumeCollision; // 0x4c(0x04)
	int32_t EdgesRejectedProximity; // 0x50(0x04)
	int32_t EdgesRejectedStepHeight; // 0x54(0x04)
	int32_t EdgesRejectedPathSlope; // 0x58(0x04)
	int32_t EdgesRejectedTraversalSweep; // 0x5c(0x04)
	int32_t PotentialEdgesConsidered; // 0x60(0x04)
	int32_t EdgesAdded; // 0x64(0x04)
};

// ScriptStruct EmbarkLNG.LNGGenerationSettings
// Size: 0x18 (Inherited: 0x00)
struct FLNGGenerationSettings {
	float Radius; // 0x00(0x04)
	float Height; // 0x04(0x04)
	float MaxStepHeight; // 0x08(0x04)
	float MaxWalkableSlopeAngleDegrees; // 0x0c(0x04)
	float MaxGridDistanceForConnection; // 0x10(0x04)
	float HeightDrawingZOffset; // 0x14(0x04)
};

// ScriptStruct EmbarkLNG.LNGHitResult
// Size: 0x60 (Inherited: 0x00)
struct FLNGHitResult {
	char bBlockingHit : 1; // 0x00(0x01)
	char pad_0_1 : 7; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Time; // 0x04(0x04)
	float Distance; // 0x08(0x04)
	char pad_c[0x4]; // 0x0c(0x04)
	struct FVector GridLocation; // 0x10(0x18)
	struct FVector WorldLocation; // 0x28(0x18)
	struct FGuid NodeGuid; // 0x40(0x10)
	struct FGuid StartNodeGuid; // 0x50(0x10)
};

// ScriptStruct EmbarkLNG.LNGPathNode
// Size: 0xb0 (Inherited: 0x00)
struct FLNGPathNode {
	struct FVector StartLocationGrid; // 0x00(0x18)
	struct FVector EndLocationGrid; // 0x18(0x18)
	struct FVector StartLocationWorld; // 0x30(0x18)
	struct FVector EndLocationWorld; // 0x48(0x18)
	struct FVector StartLocationGround; // 0x60(0x18)
	struct FVector EndLocationGround; // 0x78(0x18)
	struct FGuid StartNodeGuid; // 0x90(0x10)
	struct FGuid EndNodeGuid; // 0xa0(0x10)
};

// ScriptStruct EmbarkLNG.LNGPath
// Size: 0x10 (Inherited: 0x00)
struct FLNGPath {
	struct TArray<struct FLNGPathNode> Nodes; // 0x00(0x10)
};

// ScriptStruct EmbarkLNG.LNGNode
// Size: 0xa0 (Inherited: 0x00)
struct FLNGNode {
	struct TWeakObjectPtr<struct AActor> AssociatedActor; // 0x00(0x08)
	struct FVector GridLocation; // 0x08(0x18)
	struct FVector GroundLocationWorld; // 0x20(0x18)
	struct FGuid NodeGuid; // 0x38(0x10)
	enum class ELNGNodeType NodeType; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct TSet<struct FGuid> EdgeNodeGuids; // 0x50(0x50)
};

// ScriptStruct EmbarkLNG.LNGNodeContainer
// Size: 0xa0 (Inherited: 0x00)
struct FLNGNodeContainer {
	struct TMap<struct FGuid, struct FLNGNode> Nodes; // 0x00(0x50)
	struct TMap<struct FVector, struct FGuid> GridLocationToGuidMap; // 0x50(0x50)
};

// ScriptStruct EmbarkLNG.LNGGraph
// Size: 0xc0 (Inherited: 0x00)
struct FLNGGraph {
	struct FLNGNodeContainer NodeContainer; // 0x00(0xa0)
	struct FVector OffsetLocation; // 0xa0(0x18)
	float GridSize; // 0xb8(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

