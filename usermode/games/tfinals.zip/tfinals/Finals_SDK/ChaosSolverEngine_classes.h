// Class ChaosSolverEngine.ChaosDebugDrawComponent
// Size: 0x160 (Inherited: 0x160)
struct UChaosDebugDrawComponent : UActorComponent {
};

// Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0x160 (Inherited: 0x160)
struct UChaosEventListenerComponent : UActorComponent {
};

// Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x370 (Inherited: 0x160)
struct UChaosGameplayEventDispatcher : UChaosEventListenerComponent {
	char pad_160[0xc0]; // 0x160(0xc0)
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations; // 0x220(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations; // 0x270(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FRemovalEventCallbackWrapper> RemovalEventRegistrations; // 0x2c0(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FCrumblingEventCallbackWrapper> CrumblingEventRegistrations; // 0x310(0x50)
	char pad_360[0x10]; // 0x360(0x10)
};

// Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0xa0 (Inherited: 0xa0)
struct UChaosNotifyHandlerInterface : UInterface {
};

// Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UChaosSolverEngineBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision); // Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x2556490
};

// Class ChaosSolverEngine.ChaosSolver
// Size: 0xa0 (Inherited: 0xa0)
struct UChaosSolver : UObject {
};

// Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x490 (Inherited: 0x3a0)
struct AChaosSolverActor : AActor {
	struct FChaosSolverConfiguration Properties; // 0x398(0x68)
	float TimeStepMultiplier; // 0x400(0x04)
	int32_t CollisionIterations; // 0x404(0x04)
	int32_t PushOutIterations; // 0x408(0x04)
	int32_t PushOutPairIterations; // 0x40c(0x04)
	float ClusterConnectionFactor; // 0x410(0x04)
	enum class EClusterConnectionTypeEnum ClusterUnionConnectionType; // 0x414(0x01)
	bool DoGenerateCollisionData; // 0x415(0x01)
	struct FSolverCollisionFilterSettings CollisionFilterSettings; // 0x418(0x10)
	bool DoGenerateBreakingData; // 0x428(0x01)
	struct FSolverBreakingFilterSettings BreakingFilterSettings; // 0x42c(0x10)
	bool DoGenerateTrailingData; // 0x43c(0x01)
	struct FSolverTrailingFilterSettings TrailingFilterSettings; // 0x440(0x10)
	float MassScale; // 0x450(0x04)
	bool bHasFloor; // 0x454(0x01)
	char pad_455[0x3]; // 0x455(0x03)
	float FloorHeight; // 0x458(0x04)
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl; // 0x45c(0x03)
	char pad_45f[0x1]; // 0x45f(0x01)
	struct UBillboardComponent* SpriteComponent; // 0x460(0x08)
	char pad_468[0x18]; // 0x468(0x18)
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // 0x480(0x08)
	char pad_488[0x8]; // 0x488(0x08)

	void SetSolverActive(bool bActive); // Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2550780
	void SetAsCurrentWorldSolver(); // Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x25506d0
};

// Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0xd0 (Inherited: 0xb0)
struct UChaosSolverSettings : UDeveloperSettings {
	struct FSoftClassPath DefaultChaosSolverActorClass; // 0xb0(0x20)
};

