// Enum MeshModelingToolsExp.EBakeNormalSpace
enum class EBakeNormalSpace : uint8_t {
	Tangent = 0,
	Object = 1,
	EBakeNormalSpace_MAX = 2
};

// Enum MeshModelingToolsExp.EBakeCurvatureTypeMode
enum class EBakeCurvatureTypeMode : uint8_t {
	MeanAverage = 0,
	Max = 1,
	Min = 2,
	Gaussian = 3
};

// Enum MeshModelingToolsExp.EBakeCurvatureColorMode
enum class EBakeCurvatureColorMode : uint8_t {
	Grayscale = 0,
	RedBlue = 1,
	RedGreenBlue = 2,
	EBakeCurvatureColorMode_MAX = 3
};

// Enum MeshModelingToolsExp.EBakeCurvatureClampMode
enum class EBakeCurvatureClampMode : uint8_t {
	None = 0,
	OnlyPositive = 1,
	OnlyNegative = 2,
	EBakeCurvatureClampMode_MAX = 3
};

// Enum MeshModelingToolsExp.EExtrudeMeshSelectionInteractionMode
enum class EExtrudeMeshSelectionInteractionMode : uint8_t {
	Interactive = 0,
	Fixed = 1,
	EExtrudeMeshSelectionInteractionMode_MAX = 2
};

// Enum MeshModelingToolsExp.EExtrudeMeshSelectionRegionModifierMode
enum class EExtrudeMeshSelectionRegionModifierMode : uint8_t {
	OriginalShape = 0,
	FlattenToPlane = 1,
	RaycastToPlane = 2,
	EExtrudeMeshSelectionRegionModifierMode_MAX = 3
};

// Enum MeshModelingToolsExp.EPlaneBrushSideMode
enum class EPlaneBrushSideMode : uint8_t {
	BothSides = 0,
	PushDown = 1,
	PullTowards = 2,
	EPlaneBrushSideMode_MAX = 3
};

// Enum MeshModelingToolsExp.EVertexColorPaintBrushOpBlendMode
enum class EVertexColorPaintBrushOpBlendMode : uint8_t {
	Lerp = 0,
	Mix = 1,
	Multiply = 2,
	EVertexColorPaintBrushOpBlendMode_MAX = 3
};

// Enum MeshModelingToolsExp.EOffsetMeshSelectionInteractionMode
enum class EOffsetMeshSelectionInteractionMode : uint8_t {
	Fixed = 0,
	EOffsetMeshSelectionInteractionMode_MAX = 1
};

// Enum MeshModelingToolsExp.EOffsetMeshSelectionDirectionMode
enum class EOffsetMeshSelectionDirectionMode : uint8_t {
	VertexNormals = 0,
	FaceNormals = 1,
	ConstantWidth = 2,
	EOffsetMeshSelectionDirectionMode_MAX = 3
};

// Enum MeshModelingToolsExp.EPatternToolShape
enum class EPatternToolShape : uint8_t {
	Line = 0,
	Grid = 1,
	Circle = 2,
	EPatternToolShape_MAX = 3
};

// Enum MeshModelingToolsExp.EPatternToolSingleAxis
enum class EPatternToolSingleAxis : uint8_t {
	XAxis = 0,
	YAxis = 1,
	ZAxis = 2,
	EPatternToolSingleAxis_MAX = 3
};

// Enum MeshModelingToolsExp.EPatternToolSinglePlane
enum class EPatternToolSinglePlane : uint8_t {
	XYPlane = 0,
	XZPlane = 1,
	YZPlane = 2,
	EPatternToolSinglePlane_MAX = 3
};

// Enum MeshModelingToolsExp.EPatternToolAxisSpacingMode
enum class EPatternToolAxisSpacingMode : uint8_t {
	ByCount = 0,
	StepSize = 1,
	Packed = 2,
	EPatternToolAxisSpacingMode_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshBoundaryConstraint
enum class EMeshBoundaryConstraint : uint8_t {
	Fixed = 7,
	Refine = 5,
	Free = 1,
	EMeshBoundaryConstraint_MAX = 8
};

// Enum MeshModelingToolsExp.EGroupBoundaryConstraint
enum class EGroupBoundaryConstraint : uint8_t {
	Fixed = 7,
	Refine = 5,
	Free = 1,
	Ignore = 0,
	EGroupBoundaryConstraint_MAX = 8
};

// Enum MeshModelingToolsExp.EMaterialBoundaryConstraint
enum class EMaterialBoundaryConstraint : uint8_t {
	Fixed = 7,
	Refine = 5,
	Free = 1,
	Ignore = 0,
	EMaterialBoundaryConstraint_MAX = 8
};

// Enum MeshModelingToolsExp.ERevolveSplineSampleMode
enum class ERevolveSplineSampleMode : uint8_t {
	ControlPointsOnly = 0,
	PolyLineMaxError = 1,
	UniformSpacingAlongCurve = 2,
	ERevolveSplineSampleMode_MAX = 3
};

// Enum MeshModelingToolsExp.EAlignObjectsAlignTypes
enum class EAlignObjectsAlignTypes : uint8_t {
	Pivots = 0,
	BoundingBoxes = 1,
	EAlignObjectsAlignTypes_MAX = 2
};

// Enum MeshModelingToolsExp.EAlignObjectsAlignToOptions
enum class EAlignObjectsAlignToOptions : uint8_t {
	FirstSelected = 0,
	LastSelected = 1,
	Combined = 2,
	EAlignObjectsAlignToOptions_MAX = 3
};

// Enum MeshModelingToolsExp.EAlignObjectsBoxPoint
enum class EAlignObjectsBoxPoint : uint8_t {
	Center = 0,
	Bottom = 1,
	Top = 2,
	Left = 3,
	Right = 4,
	Front = 5,
	Back = 6,
	Min = 7,
	Max = 8
};

// Enum MeshModelingToolsExp.EBakeMapType
enum class EBakeMapType : int32_t {
	None = 0,
	TangentSpaceNormal = 1,
	ObjectSpaceNormal = 2,
	FaceNormal = 4,
	BentNormal = 8,
	Position = 16,
	Curvature = 32,
	AmbientOcclusion = 64,
	Texture = 128,
	MultiTexture = 256,
	VertexColor = 512,
	MaterialID = 1024,
	PolyGroupID = 2048,
	All = 2047,
	EBakeMapType_MAX = 2049
};

// Enum MeshModelingToolsExp.EBakeVertexOutput
enum class EBakeVertexOutput : uint8_t {
	RGBA = 0,
	PerChannel = 1,
	EBakeVertexOutput_MAX = 2
};

// Enum MeshModelingToolsExp.EBakeVertexChannel
enum class EBakeVertexChannel : uint8_t {
	R = 0,
	G = 1,
	B = 2,
	A = 3,
	RGBA = 4,
	EBakeVertexChannel_MAX = 5
};

// Enum MeshModelingToolsExp.EBakeScaleMethod
enum class EBakeScaleMethod : uint8_t {
	BakeFullScale = 0,
	BakeNonuniformScale = 1,
	DoNotBakeScale = 2,
	EBakeScaleMethod_MAX = 3
};

// Enum MeshModelingToolsExp.EConvertToPolygonsMode
enum class EConvertToPolygonsMode : uint8_t {
	FaceNormalDeviation = 0,
	FindPolygons = 1,
	FromUVIslands = 2,
	FromNormalSeams = 3,
	FromConnectedTris = 4,
	FromFurthestPointSampling = 5,
	CopyFromLayer = 6,
	EConvertToPolygonsMode_MAX = 7
};

// Enum MeshModelingToolsExp.ECubeGridToolFaceSelectionMode
enum class ECubeGridToolFaceSelectionMode : uint8_t {
	OutsideBasedOnNormal = 0,
	InsideBasedOnNormal = 1,
	OutsideBasedOnViewRay = 2,
	InsideBasedOnViewRay = 3,
	ECubeGridToolFaceSelectionMode_MAX = 4
};

// Enum MeshModelingToolsExp.ECubeGridToolAction
enum class ECubeGridToolAction : uint8_t {
	NoAction = 0,
	Push = 1,
	Pull = 2,
	Flip = 3,
	SlideForward = 4,
	SlideBack = 5,
	DecreaseGridPower = 6,
	IncreaseGridPower = 7,
	CornerMode = 8,
	ResetFromActor = 9,
	Done = 10,
	Cancel = 11,
	ECubeGridToolAction_MAX = 12
};

// Enum MeshModelingToolsExp.EGroupTopologyDeformationStrategy
enum class EGroupTopologyDeformationStrategy : uint8_t {
	Linear = 0,
	Laplacian = 1,
	EGroupTopologyDeformationStrategy_MAX = 2
};

// Enum MeshModelingToolsExp.EWeightScheme
enum class EWeightScheme : uint8_t {
	Uniform = 0,
	Umbrella = 1,
	Valence = 2,
	MeanValue = 3,
	Cotangent = 4,
	ClampedCotangent = 5,
	IDTCotangent = 6,
	EWeightScheme_MAX = 7
};

// Enum MeshModelingToolsExp.EQuickTransformerMode
enum class EQuickTransformerMode : uint8_t {
	AxisTranslation = 0,
	AxisRotation = 1,
	EQuickTransformerMode_MAX = 2
};

// Enum MeshModelingToolsExp.EDisplaceMeshToolDisplaceType
enum class EDisplaceMeshToolDisplaceType : uint8_t {
	Constant = 0,
	DisplacementMap = 1,
	RandomNoise = 2,
	PerlinNoise = 3,
	SineWave = 4,
	EDisplaceMeshToolDisplaceType_MAX = 5
};

// Enum MeshModelingToolsExp.EDisplaceMeshToolSubdivisionType
enum class EDisplaceMeshToolSubdivisionType : uint8_t {
	Flat = 0,
	PNTriangles = 1,
	EDisplaceMeshToolSubdivisionType_MAX = 2
};

// Enum MeshModelingToolsExp.EDisplaceMeshToolTriangleSelectionType
enum class EDisplaceMeshToolTriangleSelectionType : uint8_t {
	None = 0,
	Material = 1,
	EDisplaceMeshToolTriangleSelectionType_MAX = 2
};

// Enum MeshModelingToolsExp.EDisplaceMeshToolChannelType
enum class EDisplaceMeshToolChannelType : uint8_t {
	Red = 0,
	Green = 1,
	Blue = 2,
	Alpha = 3,
	EDisplaceMeshToolChannelType_MAX = 4
};

// Enum MeshModelingToolsExp.EDrawPolyPathWidthMode
enum class EDrawPolyPathWidthMode : uint8_t {
	Fixed = 0,
	Interactive = 1,
	EDrawPolyPathWidthMode_MAX = 2
};

// Enum MeshModelingToolsExp.EDrawPolyPathRadiusMode
enum class EDrawPolyPathRadiusMode : uint8_t {
	Fixed = 0,
	Interactive = 1,
	EDrawPolyPathRadiusMode_MAX = 2
};

// Enum MeshModelingToolsExp.EDrawPolyPathExtrudeMode
enum class EDrawPolyPathExtrudeMode : uint8_t {
	Flat = 0,
	Fixed = 1,
	Interactive = 2,
	RampFixed = 3,
	RampInteractive = 4,
	EDrawPolyPathExtrudeMode_MAX = 5
};

// Enum MeshModelingToolsExp.EDrawPolyPathExtrudeDirection
enum class EDrawPolyPathExtrudeDirection : uint8_t {
	SelectionNormal = 0,
	WorldX = 1,
	WorldY = 2,
	WorldZ = 3,
	LocalX = 4,
	LocalY = 5,
	LocalZ = 6,
	EDrawPolyPathExtrudeDirection_MAX = 7
};

// Enum MeshModelingToolsExp.EDynamicMeshSculptBrushType
enum class EDynamicMeshSculptBrushType : uint8_t {
	Move = 0,
	PullKelvin = 1,
	PullSharpKelvin = 2,
	Smooth = 3,
	Offset = 4,
	SculptView = 5,
	SculptMax = 6,
	Inflate = 7,
	ScaleKelvin = 8,
	Pinch = 9,
	TwistKelvin = 10,
	Flatten = 11,
	Plane = 12,
	PlaneViewAligned = 13,
	FixedPlane = 14,
	Resample = 15,
	LastValue = 16,
	EDynamicMeshSculptBrushType_MAX = 17
};

// Enum MeshModelingToolsExp.EEditPivotSnapDragRotationMode
enum class EEditPivotSnapDragRotationMode : uint8_t {
	Ignore = 0,
	Align = 1,
	AlignFlipped = 2,
	LastValue = 3,
	EEditPivotSnapDragRotationMode_MAX = 4
};

// Enum MeshModelingToolsExp.EEditPivotToolActions
enum class EEditPivotToolActions : uint8_t {
	NoAction = 0,
	Center = 1,
	Bottom = 2,
	Top = 3,
	Left = 4,
	Right = 5,
	Front = 6,
	Back = 7,
	WorldOrigin = 8,
	EEditPivotToolActions_MAX = 9
};

// Enum MeshModelingToolsExp.EHoleFillToolActions
enum class EHoleFillToolActions : uint8_t {
	NoAction = 0,
	SelectAll = 1,
	ClearSelection = 2,
	EHoleFillToolActions_MAX = 3
};

// Enum MeshModelingToolsExp.ELatticeInterpolationType
enum class ELatticeInterpolationType : uint8_t {
	Linear = 0,
	Cubic = 1,
	ELatticeInterpolationType_MAX = 2
};

// Enum MeshModelingToolsExp.ELatticeDeformerToolAction
enum class ELatticeDeformerToolAction : uint8_t {
	NoAction = 0,
	Constrain = 1,
	ClearConstraints = 2,
	ELatticeDeformerToolAction_MAX = 3
};

// Enum MeshModelingToolsExp.EBrushActionMode
enum class EBrushActionMode : uint8_t {
	Paint = 0,
	FloodFill = 1,
	EBrushActionMode_MAX = 2
};

// Enum MeshModelingToolsExp.EMeshAttributePaintToolActions
enum class EMeshAttributePaintToolActions : uint8_t {
	NoAction = 0,
	EMeshAttributePaintToolActions_MAX = 1
};

// Enum MeshModelingToolsExp.EMeshGroupPaintInteractionType
enum class EMeshGroupPaintInteractionType : uint8_t {
	Brush = 0,
	Fill = 1,
	GroupFill = 2,
	PolyLasso = 3,
	LastValue = 4,
	EMeshGroupPaintInteractionType_MAX = 5
};

// Enum MeshModelingToolsExp.EMeshGroupPaintBrushType
enum class EMeshGroupPaintBrushType : uint8_t {
	Paint = 0,
	Erase = 1,
	LastValue = 2,
	EMeshGroupPaintBrushType_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshGroupPaintBrushAreaType
enum class EMeshGroupPaintBrushAreaType : uint8_t {
	Connected = 0,
	Volumetric = 1,
	EMeshGroupPaintBrushAreaType_MAX = 2
};

// Enum MeshModelingToolsExp.EMeshGroupPaintVisibilityType
enum class EMeshGroupPaintVisibilityType : uint8_t {
	None = 0,
	FrontFacing = 1,
	Unoccluded = 2,
	EMeshGroupPaintVisibilityType_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshGroupPaintToolActions
enum class EMeshGroupPaintToolActions : uint8_t {
	NoAction = 0,
	ClearFrozen = 1,
	FreezeCurrent = 2,
	FreezeOthers = 3,
	GrowCurrent = 4,
	ShrinkCurrent = 5,
	ClearCurrent = 6,
	FloodFillCurrent = 7,
	ClearAll = 8,
	EMeshGroupPaintToolActions_MAX = 9
};

// Enum MeshModelingToolsExp.EMeshInspectorToolDrawIndexMode
enum class EMeshInspectorToolDrawIndexMode : uint8_t {
	None = 0,
	VertexID = 1,
	TriangleID = 2,
	GroupID = 3,
	EdgeID = 4,
	EMeshInspectorToolDrawIndexMode_MAX = 5
};

// Enum MeshModelingToolsExp.EMeshInspectorMaterialMode
enum class EMeshInspectorMaterialMode : uint8_t {
	Original = 0,
	FlatShaded = 1,
	Grey = 2,
	Transparent = 3,
	TangentNormal = 4,
	VertexColor = 5,
	GroupColor = 6,
	Checkerboard = 7,
	Override = 8,
	EMeshInspectorMaterialMode_MAX = 9
};

// Enum MeshModelingToolsExp.EMeshSelectionToolActions
enum class EMeshSelectionToolActions : uint8_t {
	NoAction = 0,
	SelectAll = 1,
	SelectAllByMaterial = 2,
	ClearSelection = 3,
	InvertSelection = 4,
	GrowSelection = 5,
	ShrinkSelection = 6,
	ExpandToConnected = 7,
	SelectLargestComponentByTriCount = 8,
	SelectLargestComponentByArea = 9,
	OptimizeSelection = 10,
	DeleteSelected = 11,
	DisconnectSelected = 12,
	SeparateSelected = 13,
	DuplicateSelected = 14,
	FlipSelected = 15,
	CreateGroup = 16,
	SmoothBoundary = 17,
	CycleSelectionMode = 18,
	CycleViewMode = 19,
	EMeshSelectionToolActions_MAX = 20
};

// Enum MeshModelingToolsExp.EMeshSelectionToolPrimaryMode
enum class EMeshSelectionToolPrimaryMode : uint8_t {
	Brush = 0,
	VolumetricBrush = 1,
	AngleFiltered = 2,
	Visible = 3,
	AllConnected = 4,
	AllInGroup = 5,
	ByMaterial = 6,
	ByMaterialAll = 7,
	ByUVIsland = 8,
	AllWithinAngle = 9,
	EMeshSelectionToolPrimaryMode_MAX = 10
};

// Enum MeshModelingToolsExp.EMeshFacesColorMode
enum class EMeshFacesColorMode : uint8_t {
	None = 0,
	ByGroup = 1,
	ByMaterialID = 2,
	ByUVIsland = 3,
	EMeshFacesColorMode_MAX = 4
};

// Enum MeshModelingToolsExp.ENonlinearOperationType
enum class ENonlinearOperationType : uint8_t {
	Bend = 0,
	Flare = 1,
	Twist = 2,
	ENonlinearOperationType_MAX = 3
};

// Enum MeshModelingToolsExp.EFlareProfileType
enum class EFlareProfileType : uint8_t {
	SinMode = 0,
	SinSquaredMode = 1,
	TriangleMode = 2,
	EFlareProfileType_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshSpaceDeformerToolAction
enum class EMeshSpaceDeformerToolAction : uint8_t {
	NoAction = 0,
	ShiftToCenter = 1,
	EMeshSpaceDeformerToolAction_MAX = 2
};

// Enum MeshModelingToolsExp.EMeshVertexPaintInteractionType
enum class EMeshVertexPaintInteractionType : uint8_t {
	Brush = 0,
	TriFill = 1,
	Fill = 2,
	GroupFill = 3,
	PolyLasso = 4,
	LastValue = 5,
	EMeshVertexPaintInteractionType_MAX = 6
};

// Enum MeshModelingToolsExp.EMeshVertexPaintColorChannel
enum class EMeshVertexPaintColorChannel : uint8_t {
	Red = 0,
	Green = 1,
	Blue = 2,
	Alpha = 3,
	EMeshVertexPaintColorChannel_MAX = 4
};

// Enum MeshModelingToolsExp.EMeshVertexPaintColorBlendMode
enum class EMeshVertexPaintColorBlendMode : uint8_t {
	Lerp = 0,
	Mix = 1,
	Multiply = 2,
	EMeshVertexPaintColorBlendMode_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshVertexPaintBrushType
enum class EMeshVertexPaintBrushType : uint8_t {
	Paint = 0,
	Erase = 1,
	Soften = 2,
	Smooth = 3,
	LastValue = 4,
	EMeshVertexPaintBrushType_MAX = 5
};

// Enum MeshModelingToolsExp.EMeshVertexPaintSecondaryActionType
enum class EMeshVertexPaintSecondaryActionType : uint8_t {
	Erase = 0,
	Soften = 1,
	Smooth = 2,
	EMeshVertexPaintSecondaryActionType_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshVertexPaintBrushAreaType
enum class EMeshVertexPaintBrushAreaType : uint8_t {
	Connected = 0,
	Volumetric = 1,
	EMeshVertexPaintBrushAreaType_MAX = 2
};

// Enum MeshModelingToolsExp.EMeshVertexPaintVisibilityType
enum class EMeshVertexPaintVisibilityType : uint8_t {
	None = 0,
	FrontFacing = 1,
	Unoccluded = 2,
	EMeshVertexPaintVisibilityType_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshVertexPaintMaterialMode
enum class EMeshVertexPaintMaterialMode : uint8_t {
	LitVertexColor = 0,
	UnlitVertexColor = 1,
	OriginalMaterial = 2,
	EMeshVertexPaintMaterialMode_MAX = 3
};

// Enum MeshModelingToolsExp.EMeshVertexPaintToolActions
enum class EMeshVertexPaintToolActions : uint8_t {
	NoAction = 0,
	PaintAll = 1,
	EraseAll = 2,
	FillBlack = 3,
	FillWhite = 4,
	ApplyCurrentUtility = 5,
	EMeshVertexPaintToolActions_MAX = 6
};

// Enum MeshModelingToolsExp.EMeshVertexPaintToolUtilityOperations
enum class EMeshVertexPaintToolUtilityOperations : uint8_t {
	BlendAllSeams = 0,
	FillChannels = 1,
	InvertChannels = 2,
	CopyChannelToChannel = 3,
	SwapChannels = 4,
	CopyFromWeightMap = 5,
	CopyToOtherLODs = 6,
	CopyToSingleLOD = 7,
	EMeshVertexPaintToolUtilityOperations_MAX = 8
};

// Enum MeshModelingToolsExp.EMeshVertexSculptBrushType
enum class EMeshVertexSculptBrushType : uint8_t {
	Move = 0,
	PullKelvin = 1,
	PullSharpKelvin = 2,
	Smooth = 3,
	SmoothFill = 4,
	Offset = 5,
	SculptView = 6,
	SculptMax = 7,
	Inflate = 8,
	ScaleKelvin = 9,
	Pinch = 10,
	TwistKelvin = 11,
	Flatten = 12,
	Plane = 13,
	PlaneViewAligned = 14,
	FixedPlane = 15,
	LastValue = 16,
	EMeshVertexSculptBrushType_MAX = 17
};

// Enum MeshModelingToolsExp.EMeshVertexSculptBrushFilterType
enum class EMeshVertexSculptBrushFilterType : uint8_t {
	None = 0,
	Component = 1,
	PolyGroup = 2,
	EMeshVertexSculptBrushFilterType_MAX = 3
};

// Enum MeshModelingToolsExp.EMirrorSaveMode
enum class EMirrorSaveMode : uint8_t {
	InputObjects = 0,
	NewObjects = 1,
	EMirrorSaveMode_MAX = 2
};

// Enum MeshModelingToolsExp.EMirrorOperationMode
enum class EMirrorOperationMode : uint8_t {
	MirrorAndAppend = 0,
	MirrorExisting = 1,
	EMirrorOperationMode_MAX = 2
};

// Enum MeshModelingToolsExp.EMirrorToolAction
enum class EMirrorToolAction : uint8_t {
	NoAction = 0,
	ShiftToCenter = 1,
	Left = 2,
	Right = 3,
	Up = 4,
	Down = 5,
	Forward = 6,
	Backward = 7,
	EMirrorToolAction_MAX = 8
};

// Enum MeshModelingToolsExp.EOffsetMeshToolOffsetType
enum class EOffsetMeshToolOffsetType : uint8_t {
	Iterative = 0,
	Implicit = 1,
	EOffsetMeshToolOffsetType_MAX = 2
};

// Enum MeshModelingToolsExp.ECollisionGeometryMode
enum class ECollisionGeometryMode : uint8_t {
	Default = 0,
	SimpleAndComplex = 1,
	UseSimpleAsComplex = 2,
	UseComplexAsSimple = 3,
	ECollisionGeometryMode_MAX = 4
};

// Enum MeshModelingToolsExp.EExtractCollisionOutputType
enum class EExtractCollisionOutputType : uint8_t {
	Simple = 0,
	Complex = 1,
	EExtractCollisionOutputType_MAX = 2
};

// Enum MeshModelingToolsExp.ESetCollisionGeometryInputMode
enum class ESetCollisionGeometryInputMode : uint8_t {
	CombineAll = 0,
	PerInputObject = 1,
	PerMeshComponent = 2,
	PerMeshGroup = 3,
	ESetCollisionGeometryInputMode_MAX = 4
};

// Enum MeshModelingToolsExp.ECollisionGeometryType
enum class ECollisionGeometryType : uint8_t {
	CopyFromInputs = 0,
	AlignedBoxes = 1,
	OrientedBoxes = 2,
	MinimalSpheres = 3,
	Capsules = 4,
	ConvexHulls = 5,
	SweptHulls = 6,
	LevelSets = 7,
	MinVolume = 10,
	Empty = 11,
	ECollisionGeometryType_MAX = 12
};

// Enum MeshModelingToolsExp.EProjectedHullAxis
enum class EProjectedHullAxis : uint8_t {
	X = 0,
	Y = 1,
	Z = 2,
	SmallestBoxDimension = 3,
	SmallestVolume = 4,
	EProjectedHullAxis_MAX = 5
};

// Enum MeshModelingToolsExp.ESimpleCollisionEditorToolAction
enum class ESimpleCollisionEditorToolAction : uint8_t {
	NoAction = 0,
	AddSphere = 1,
	AddBox = 2,
	AddCapsule = 3,
	Duplicate = 4,
	DeleteSelected = 5,
	DeleteAll = 6,
	ESimpleCollisionEditorToolAction_MAX = 7
};

// Enum MeshModelingToolsExp.EPlaneCutToolActions
enum class EPlaneCutToolActions : uint8_t {
	NoAction = 0,
	Cut = 1,
	FlipPlane = 2,
	EPlaneCutToolActions_MAX = 3
};

// Enum MeshModelingToolsExp.EOcclusionTriangleSamplingUIMode
enum class EOcclusionTriangleSamplingUIMode : uint8_t {
	Vertices = 0,
	VerticesAndCentroids = 1,
	EOcclusionTriangleSamplingUIMode_MAX = 2
};

// Enum MeshModelingToolsExp.EOcclusionCalculationUIMode
enum class EOcclusionCalculationUIMode : uint8_t {
	GeneralizedWindingNumber = 0,
	RaycastOcclusionSamples = 1,
	EOcclusionCalculationUIMode_MAX = 2
};

// Enum MeshModelingToolsExp.EOccludedAction
enum class EOccludedAction : uint8_t {
	Remove = 0,
	SetNewGroup = 1,
	EOccludedAction_MAX = 2
};

// Enum MeshModelingToolsExp.EBrushToolSizeType
enum class EBrushToolSizeType : uint8_t {
	Adaptive = 0,
	World = 1,
	EBrushToolSizeType_MAX = 2
};

// Enum MeshModelingToolsExp.EMeshSculptFalloffType
enum class EMeshSculptFalloffType : uint8_t {
	Smooth = 0,
	Linear = 1,
	Inverse = 2,
	Round = 3,
	BoxSmooth = 4,
	BoxLinear = 5,
	BoxInverse = 6,
	BoxRound = 7,
	LastValue = 8,
	EMeshSculptFalloffType_MAX = 9
};

// Enum MeshModelingToolsExp.ESmoothMeshToolSmoothType
enum class ESmoothMeshToolSmoothType : uint8_t {
	Iterative = 0,
	Implicit = 1,
	Diffusion = 2,
	ESmoothMeshToolSmoothType_MAX = 3
};

// Enum MeshModelingToolsExp.ETransformMeshesTransformMode
enum class ETransformMeshesTransformMode : uint8_t {
	SharedGizmo = 0,
	SharedGizmoLocal = 1,
	PerObjectGizmo = 2,
	LastValue = 3,
	ETransformMeshesTransformMode_MAX = 4
};

// Enum MeshModelingToolsExp.ETransformMeshesSnapDragSource
enum class ETransformMeshesSnapDragSource : uint8_t {
	ClickPoint = 0,
	Pivot = 1,
	LastValue = 2,
	ETransformMeshesSnapDragSource_MAX = 3
};

// Enum MeshModelingToolsExp.ETransformMeshesSnapDragRotationMode
enum class ETransformMeshesSnapDragRotationMode : uint8_t {
	Ignore = 0,
	Align = 1,
	AlignFlipped = 2,
	LastValue = 3,
	ETransformMeshesSnapDragRotationMode_MAX = 4
};

// Enum MeshModelingToolsExp.EVoxelBlendOperation
enum class EVoxelBlendOperation : uint8_t {
	Union = 0,
	Subtract = 1,
	EVoxelBlendOperation_MAX = 2
};

// Enum MeshModelingToolsExp.EWeldMeshEdgesAttributeUIMode
enum class EWeldMeshEdgesAttributeUIMode : uint8_t {
	None = 0,
	OnWeldedMeshEdgesOnly = 1,
	OnFullMesh = 2,
	EWeldMeshEdgesAttributeUIMode_MAX = 3
};

// ScriptStruct MeshModelingToolsExp.BakeMultiMeshDetailProperties
// Size: 0x18 (Inherited: 0x00)
struct FBakeMultiMeshDetailProperties {
	struct UStaticMesh* SourceMesh; // 0x00(0x08)
	struct UTexture2D* SourceTexture; // 0x08(0x08)
	int32_t SourceTextureUVLayer; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct MeshModelingToolsExp.PerlinLayerProperties
// Size: 0x08 (Inherited: 0x00)
struct FPerlinLayerProperties {
	float Frequency; // 0x00(0x04)
	float Intensity; // 0x04(0x04)
};

// ScriptStruct MeshModelingToolsExp.EditPivotTarget
// Size: 0x10 (Inherited: 0x00)
struct FEditPivotTarget {
	struct UTransformProxy* TransformProxy; // 0x00(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x08(0x08)
};

// ScriptStruct MeshModelingToolsExp.PhysicsSphereData
// Size: 0xa0 (Inherited: 0x00)
struct FPhysicsSphereData {
	float Radius; // 0x00(0x04)
	char pad_4[0xc]; // 0x04(0x0c)
	struct FTransform Transform; // 0x10(0x60)
	struct FKShapeElem Element; // 0x70(0x30)
};

// ScriptStruct MeshModelingToolsExp.PhysicsBoxData
// Size: 0xb0 (Inherited: 0x00)
struct FPhysicsBoxData {
	struct FVector Dimensions; // 0x00(0x18)
	char pad_18[0x8]; // 0x18(0x08)
	struct FTransform Transform; // 0x20(0x60)
	struct FKShapeElem Element; // 0x80(0x30)
};

// ScriptStruct MeshModelingToolsExp.PhysicsCapsuleData
// Size: 0xa0 (Inherited: 0x00)
struct FPhysicsCapsuleData {
	float Radius; // 0x00(0x04)
	float Length; // 0x04(0x04)
	char pad_8[0x8]; // 0x08(0x08)
	struct FTransform Transform; // 0x10(0x60)
	struct FKShapeElem Element; // 0x70(0x30)
};

// ScriptStruct MeshModelingToolsExp.PhysicsConvexData
// Size: 0x38 (Inherited: 0x00)
struct FPhysicsConvexData {
	int32_t NumVertices; // 0x00(0x04)
	int32_t NumFaces; // 0x04(0x04)
	struct FKShapeElem Element; // 0x08(0x30)
};

// ScriptStruct MeshModelingToolsExp.PhysicsLevelSetData
// Size: 0x30 (Inherited: 0x00)
struct FPhysicsLevelSetData {
	struct FKShapeElem Element; // 0x00(0x30)
};

// ScriptStruct MeshModelingToolsExp.BrushToolRadius
// Size: 0x14 (Inherited: 0x00)
struct FBrushToolRadius {
	enum class EBrushToolSizeType SizeType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float AdaptiveSize; // 0x04(0x04)
	float WorldRadius; // 0x08(0x04)
	char pad_c[0x8]; // 0x0c(0x08)
};

// ScriptStruct MeshModelingToolsExp.TransformMeshesTarget
// Size: 0x10 (Inherited: 0x00)
struct FTransformMeshesTarget {
	struct UTransformProxy* TransformProxy; // 0x00(0x08)
	struct UCombinedTransformGizmo* TransformGizmo; // 0x08(0x08)
};

