// ScriptStruct ActorBlackBoard.BlackBoardVariableDeltaCompressionPtr
// Size: 0x78 (Inherited: 0x00)
struct FBlackBoardVariableDeltaCompressionPtr {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct ActorBlackBoard.ABBLowCompressedVectorMaxLen200
// Size: 0x18 (Inherited: 0x00)
struct FABBLowCompressedVectorMaxLen200 {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.BlackBoardDeltaCompressionPtr
// Size: 0x78 (Inherited: 0x00)
struct FBlackBoardDeltaCompressionPtr {
	char pad_0[0x78]; // 0x00(0x78)
};

// ScriptStruct ActorBlackBoard.ABFloatQuantization
// Size: 0x0c (Inherited: 0x00)
struct FABFloatQuantization {
	float MaxVal; // 0x00(0x04)
	float MinVal; // 0x04(0x04)
	char BitCount; // 0x08(0x01)
	char SmallChangeBitCount; // 0x09(0x01)
	char pad_a[0x2]; // 0x0a(0x02)
};

// ScriptStruct ActorBlackBoard.ABFloat
// Size: 0x10 (Inherited: 0x00)
struct FABFloat {
	struct FABFloatQuantization Quantization; // 0x00(0x0c)
	float Value; // 0x0c(0x04)
};

// ScriptStruct ActorBlackBoard.ABIntQuantization
// Size: 0x0c (Inherited: 0x00)
struct FABIntQuantization {
	int32_t MaxVal; // 0x00(0x04)
	int32_t MinVal; // 0x04(0x04)
	char SmallChangeBitCount; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct ActorBlackBoard.ABInt
// Size: 0x10 (Inherited: 0x00)
struct FABInt {
	struct FABIntQuantization Quantization; // 0x00(0x0c)
	int32_t Value; // 0x0c(0x04)
};

// ScriptStruct ActorBlackBoard.ABArraySizeLimiter
// Size: 0x04 (Inherited: 0x00)
struct FABArraySizeLimiter {
	int32_t MaxArraySize; // 0x00(0x04)
};

// ScriptStruct ActorBlackBoard.ABBCompressedVectorBase
// Size: 0x18 (Inherited: 0x00)
struct FABBCompressedVectorBase {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.ABBHighCompressedWorldVector
// Size: 0x18 (Inherited: 0x00)
struct FABBHighCompressedWorldVector {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.ABBLowCompressedWorldVector
// Size: 0x18 (Inherited: 0x00)
struct FABBLowCompressedWorldVector {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.ABBHighCompressedVectorMaxLen2000
// Size: 0x18 (Inherited: 0x00)
struct FABBHighCompressedVectorMaxLen2000 {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.ABBLowCompressedVectorMaxLen2000
// Size: 0x18 (Inherited: 0x00)
struct FABBLowCompressedVectorMaxLen2000 {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.ABBHighCompressedVectorMaxLen200
// Size: 0x18 (Inherited: 0x00)
struct FABBHighCompressedVectorMaxLen200 {
	struct FVector Vector; // 0x00(0x18)
};

// ScriptStruct ActorBlackBoard.ABBCustomCompressedVector
// Size: 0x28 (Inherited: 0x00)
struct FABBCustomCompressedVector {
	struct FVector Vector; // 0x00(0x18)
	struct FABFloatQuantization Quantization; // 0x18(0x0c)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct ActorBlackBoard.ABBCompressedQuatBase
// Size: 0x20 (Inherited: 0x00)
struct FABBCompressedQuatBase {
	struct FQuat Quat; // 0x00(0x20)
};

// ScriptStruct ActorBlackBoard.ABBHighCompressedQuat
// Size: 0x20 (Inherited: 0x00)
struct FABBHighCompressedQuat {
	struct FQuat Quat; // 0x00(0x20)
};

// ScriptStruct ActorBlackBoard.ABBLowCompressedQuat
// Size: 0x20 (Inherited: 0x00)
struct FABBLowCompressedQuat {
	struct FQuat Quat; // 0x00(0x20)
};

// ScriptStruct ActorBlackBoard.ABBUltraLowCompressedQuat
// Size: 0x20 (Inherited: 0x00)
struct FABBUltraLowCompressedQuat {
	struct FQuat Quat; // 0x00(0x20)
};

// ScriptStruct ActorBlackBoard.ABBCompressedTransformBase
// Size: 0x60 (Inherited: 0x00)
struct FABBCompressedTransformBase {
	struct FTransform Transform; // 0x00(0x60)
};

// ScriptStruct ActorBlackBoard.ABBLowCompressedWorldTransform
// Size: 0x60 (Inherited: 0x00)
struct FABBLowCompressedWorldTransform {
	struct FTransform Transform; // 0x00(0x60)
};

// ScriptStruct ActorBlackBoard.ABBHighCompressedWorldTransform
// Size: 0x60 (Inherited: 0x00)
struct FABBHighCompressedWorldTransform {
	struct FTransform Transform; // 0x00(0x60)
};

// ScriptStruct ActorBlackBoard.ABBLowCompressedLocalTransform
// Size: 0x60 (Inherited: 0x00)
struct FABBLowCompressedLocalTransform {
	struct FTransform Transform; // 0x00(0x60)
};

// ScriptStruct ActorBlackBoard.ABBHighCompressedLocalTransform
// Size: 0x60 (Inherited: 0x00)
struct FABBHighCompressedLocalTransform {
	struct FTransform Transform; // 0x00(0x60)
};

// ScriptStruct ActorBlackBoard.ABBWeakPtr
// Size: 0x08 (Inherited: 0x00)
struct FABBWeakPtr {
	struct TWeakObjectPtr<struct UObject> MemberObj; // 0x00(0x08)
};

// ScriptStruct ActorBlackBoard.ABBWeakConstPtr
// Size: 0x08 (Inherited: 0x00)
struct FABBWeakConstPtr {
	struct TWeakObjectPtr<struct UObject> MemberObject; // 0x00(0x08)
};

// ScriptStruct ActorBlackBoard.ActorBlackBoardTestInternalFixedArrayNetTestStruct
// Size: 0x14 (Inherited: 0x00)
struct FActorBlackBoardTestInternalFixedArrayNetTestStruct {
	int32_t A; // 0x00(0x04)
	struct FABInt B; // 0x04(0x10)
};

// ScriptStruct ActorBlackBoard.ActorBlackBoardTestInternalFixedArrayNetTestStructWithArray
// Size: 0x40 (Inherited: 0x00)
struct FActorBlackBoardTestInternalFixedArrayNetTestStructWithArray {
	int32_t X; // 0x00(0x04)
	struct FActorBlackBoardTestInternalFixedArrayNetTestStruct TestArrayInsideStruct[0x3]; // 0x04(0x3c)
};

// ScriptStruct ActorBlackBoard.ActorBlackBoardTestTArrayNetTestStructInner
// Size: 0x20 (Inherited: 0x00)
struct FActorBlackBoardTestTArrayNetTestStructInner {
	int32_t MaxLean; // 0x00(0x04)
	struct FABArraySizeLimiter SizeLimiter; // 0x04(0x04)
	struct TArray<struct FActorBlackBoardTestInternalFixedArrayNetTestStruct> TestStruct1; // 0x08(0x10)
	int32_t MaxLean2; // 0x18(0x04)
	char pad_1c[0x4]; // 0x1c(0x04)
};

// ScriptStruct ActorBlackBoard.TransformAndVelocityBBVariable
// Size: 0x01 (Inherited: 0x00)
struct FTransformAndVelocityBBVariable {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct ActorBlackBoard.ActorTransformCollection
// Size: 0x10 (Inherited: 0x00)
struct FActorTransformCollection {
	char pad_0[0x10]; // 0x00(0x10)
};

// ScriptStruct ActorBlackBoard.ObjectRelativeLocation
// Size: 0x60 (Inherited: 0x00)
struct FObjectRelativeLocation {
	char pad_0[0x60]; // 0x00(0x60)
};

