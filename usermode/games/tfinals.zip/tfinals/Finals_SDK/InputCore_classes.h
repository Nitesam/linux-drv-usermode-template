// Class InputCore.InputCoreTypes
// Size: 0xa0 (Inherited: 0xa0)
struct UInputCoreTypes : UObject {
};

