// Class AudioWidgets.AudioMeter
// Size: 0x770 (Inherited: 0x1f0)
struct UAudioMeter : UWidget {
	struct TArray<struct FMeterChannelInfo> MeterChannelInfo; // 0x1f0(0x10)
	struct FDelegate MeterChannelInfoDelegate; // 0x200(0x10)
	struct FAudioMeterStyle WidgetStyle; // 0x210(0x4d0)
	enum class EOrientation Orientation; // 0x6e0(0x01)
	char pad_6e1[0x3]; // 0x6e1(0x03)
	struct FLinearColor BackgroundColor; // 0x6e4(0x10)
	struct FLinearColor MeterBackgroundColor; // 0x6f4(0x10)
	struct FLinearColor MeterValueColor; // 0x704(0x10)
	struct FLinearColor MeterPeakColor; // 0x714(0x10)
	struct FLinearColor MeterClippingColor; // 0x724(0x10)
	struct FLinearColor MeterScaleColor; // 0x734(0x10)
	struct FLinearColor MeterScaleLabelColor; // 0x744(0x10)
	char pad_754[0x1c]; // 0x754(0x1c)

	void SetMeterValueColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterValueColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f873c0
	void SetMeterScaleLabelColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f7a160
	void SetMeterScaleColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterScaleColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f67dd0
	void SetMeterPeakColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterPeakColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f78ce0
	void SetMeterClippingColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterClippingColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f77620
	void SetMeterChannelInfo(struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo); // Function AudioWidgets.AudioMeter.SetMeterChannelInfo // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x8f88860
	void SetMeterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetMeterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f6cbd0
	void SetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioMeter.SetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f67f90
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo__DelegateSignature(); // DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature // (Public|Delegate) // @ game+0x4abfe0
	struct TArray<struct FMeterChannelInfo> GetMeterChannelInfo(); // Function AudioWidgets.AudioMeter.GetMeterChannelInfo // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8f7f680
};

// Class AudioWidgets.AudioRadialSlider
// Size: 0x410 (Inherited: 0x1f0)
struct UAudioRadialSlider : UWidget {
	float Value; // 0x1f0(0x04)
	struct FDelegate ValueDelegate; // 0x1f4(0x10)
	enum class EAudioRadialSliderLayout WidgetLayout; // 0x204(0x01)
	char pad_205[0x3]; // 0x205(0x03)
	struct FLinearColor CenterBackgroundColor; // 0x208(0x10)
	struct FLinearColor SliderProgressColor; // 0x218(0x10)
	struct FLinearColor SliderBarColor; // 0x228(0x10)
	struct FVector2D HandStartEndRatio; // 0x238(0x10)
	struct FText UnitsText; // 0x248(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x260(0x10)
	bool ShowLabelOnlyOnHover; // 0x270(0x01)
	bool ShowUnitsText; // 0x271(0x01)
	bool IsUnitsTextReadOnly; // 0x272(0x01)
	bool IsValueTextReadOnly; // 0x273(0x01)
	float SliderThickness; // 0x274(0x04)
	struct FVector2D OutputRange; // 0x278(0x10)
	struct FMulticastInlineDelegate OnValueChanged; // 0x288(0x10)
	char pad_298[0x178]; // 0x298(0x178)

	void SetWidgetLayout(enum class EAudioRadialSliderLayout InLayout); // Function AudioWidgets.AudioRadialSlider.SetWidgetLayout // (Final|Native|Public|BlueprintCallable) // @ game+0x8f7f240
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8f79590
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8f83df0
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioRadialSlider.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x8f63690
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0x8f77e20
	void SetSliderThickness(float InThickness); // Function AudioWidgets.AudioRadialSlider.SetSliderThickness // (Final|Native|Public|BlueprintCallable) // @ game+0x8f6f5c0
	void SetSliderProgressColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f6fd90
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f7a5d0
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioRadialSlider.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x8f6a610
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0x8f75ff0
	void SetOutputRange(struct FVector2D InOutputRange); // Function AudioWidgets.AudioRadialSlider.SetOutputRange // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f66000
	void SetHandStartEndRatio(struct FVector2D InHandStartEndRatio); // Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f69f60
	void SetCenterBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f735d0
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioRadialSlider.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8f6a710
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioRadialSlider.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8f71f80
};

// Class AudioWidgets.AudioVolumeRadialSlider
// Size: 0x410 (Inherited: 0x410)
struct UAudioVolumeRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioFrequencyRadialSlider
// Size: 0x410 (Inherited: 0x410)
struct UAudioFrequencyRadialSlider : UAudioRadialSlider {
};

// Class AudioWidgets.AudioSliderBase
// Size: 0xa40 (Inherited: 0x1f0)
struct UAudioSliderBase : UWidget {
	float Value; // 0x1f0(0x04)
	char pad_1f4[0x4]; // 0x1f4(0x04)
	struct FText UnitsText; // 0x1f8(0x18)
	struct FLinearColor TextLabelBackgroundColor; // 0x210(0x10)
	struct FDelegate TextLabelBackgroundColorDelegate; // 0x220(0x10)
	bool ShowLabelOnlyOnHover; // 0x230(0x01)
	bool ShowUnitsText; // 0x231(0x01)
	bool IsUnitsTextReadOnly; // 0x232(0x01)
	bool IsValueTextReadOnly; // 0x233(0x01)
	struct FDelegate ValueDelegate; // 0x234(0x10)
	struct FLinearColor SliderBackgroundColor; // 0x244(0x10)
	struct FDelegate SliderBackgroundColorDelegate; // 0x254(0x10)
	struct FLinearColor SliderBarColor; // 0x264(0x10)
	struct FDelegate SliderBarColorDelegate; // 0x274(0x10)
	struct FLinearColor SliderThumbColor; // 0x284(0x10)
	struct FDelegate SliderThumbColorDelegate; // 0x294(0x10)
	struct FLinearColor WidgetBackgroundColor; // 0x2a4(0x10)
	struct FDelegate WidgetBackgroundColorDelegate; // 0x2b4(0x10)
	enum class EOrientation Orientation; // 0x2c4(0x01)
	char pad_2c5[0x3]; // 0x2c5(0x03)
	struct FMulticastInlineDelegate OnValueChanged; // 0x2c8(0x10)
	char pad_2d8[0x768]; // 0x2d8(0x768)

	void SetWidgetBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f67e90
	void SetValueTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8f6d540
	void SetUnitsTextReadOnly(bool bIsReadOnly); // Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x8f68d00
	void SetUnitsText(struct FText Units); // Function AudioWidgets.AudioSliderBase.SetUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x8f7a450
	void SetTextLabelBackgroundColor(struct FSlateColor InColor); // Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor // (Final|Native|Public|BlueprintCallable) // @ game+0x8f6e200
	void SetSliderThumbColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderThumbColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f80550
	void SetSliderBarColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBarColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f67c40
	void SetSliderBackgroundColor(struct FLinearColor InValue); // Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x8f6cb10
	void SetShowUnitsText(bool bShowUnitsText); // Function AudioWidgets.AudioSliderBase.SetShowUnitsText // (Final|Native|Public|BlueprintCallable) // @ game+0x8f68bc0
	void SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover); // Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover // (Final|Native|Public|BlueprintCallable) // @ game+0x8f7d670
	float GetSliderValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetSliderValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8f722b0
	float GetOutputValue(float InSliderValue); // Function AudioWidgets.AudioSliderBase.GetOutputValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8f68510
	float GetLinValue(float OutputValue); // Function AudioWidgets.AudioSliderBase.GetLinValue // (Final|Native|Public|BlueprintCallable) // @ game+0x8f722b0
};

// Class AudioWidgets.AudioSlider
// Size: 0xa50 (Inherited: 0xa40)
struct UAudioSlider : UAudioSliderBase {
	struct TWeakObjectPtr<struct UCurveFloat> LinToOutputCurve; // 0xa40(0x08)
	struct TWeakObjectPtr<struct UCurveFloat> OutputToLinCurve; // 0xa48(0x08)
};

// Class AudioWidgets.AudioVolumeSlider
// Size: 0xa50 (Inherited: 0xa50)
struct UAudioVolumeSlider : UAudioSlider {
};

// Class AudioWidgets.AudioFrequencySlider
// Size: 0xa50 (Inherited: 0xa40)
struct UAudioFrequencySlider : UAudioSliderBase {
	struct FVector2D OutputRange; // 0xa40(0x10)
};

