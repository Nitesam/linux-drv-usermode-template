// Class InteractiveToolsFramework.AssetBackedTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UAssetBackedTarget : UInterface {
};

// Class InteractiveToolsFramework.GizmoBaseComponent
// Size: 0x6f0 (Inherited: 0x6c0)
struct UGizmoBaseComponent : UPrimitiveComponent {
	struct FLinearColor Color; // 0x6b8(0x10)
	float HoverSizeMultiplier; // 0x6c8(0x04)
	float PixelHitDistanceThreshold; // 0x6cc(0x04)
	struct UGizmoViewContext* GizmoViewContext; // 0x6d8(0x08)
	char pad_6e0[0x10]; // 0x6e0(0x10)

	void UpdateWorldLocalState(bool bWorldIn); // Function InteractiveToolsFramework.GizmoBaseComponent.UpdateWorldLocalState // (Final|Native|Public) // @ game+0x9357320
	void UpdateHoverState(bool bHoveringIn); // Function InteractiveToolsFramework.GizmoBaseComponent.UpdateHoverState // (Final|Native|Public) // @ game+0x935beb0
};

// Class InteractiveToolsFramework.InteractiveCommandArguments
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveCommandArguments : UObject {
};

// Class InteractiveToolsFramework.InteractiveCommandResult
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveCommandResult : UObject {
};

// Class InteractiveToolsFramework.InteractiveCommand
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveCommand : UObject {
};

// Class InteractiveToolsFramework.InteractiveGizmoBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveGizmoBuilder : UObject {
};

// Class InteractiveToolsFramework.ToolContextTransactionProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UToolContextTransactionProvider : UInterface {
};

// Class InteractiveToolsFramework.InternalToolFrameworkActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AInternalToolFrameworkActor : AActor {
	bool bIsSelectableInEditor; // 0x398(0x01)
};

// Class InteractiveToolsFramework.ToolFrameworkComponent
// Size: 0xa0 (Inherited: 0xa0)
struct UToolFrameworkComponent : UInterface {
};

// Class InteractiveToolsFramework.InteractiveToolCameraFocusAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolCameraFocusAPI : UInterface {
};

// Class InteractiveToolsFramework.InteractiveToolNestedAcceptCancelAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolNestedAcceptCancelAPI : UInterface {
};

// Class InteractiveToolsFramework.InteractiveToolExclusiveToolAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolExclusiveToolAPI : UInterface {
};

// Class InteractiveToolsFramework.InteractiveToolEditorGizmoAPI
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolEditorGizmoAPI : UInterface {
};

// Class InteractiveToolsFramework.MaterialProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UMaterialProvider : UInterface {
};

// Class InteractiveToolsFramework.MeshDescriptionCommitter
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshDescriptionCommitter : UInterface {
};

// Class InteractiveToolsFramework.MeshDescriptionProvider
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshDescriptionProvider : UInterface {
};

// Class InteractiveToolsFramework.GizmoBaseVec2ParameterSource
// Size: 0xc0 (Inherited: 0xa0)
struct UGizmoBaseVec2ParameterSource : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class InteractiveToolsFramework.GizmoLocalVec2ParameterSource
// Size: 0xf0 (Inherited: 0xc0)
struct UGizmoLocalVec2ParameterSource : UGizmoBaseVec2ParameterSource {
	struct FVector2D Value; // 0xb8(0x10)
	struct FGizmoVec2ParameterChange LastChange; // 0xc8(0x20)
};

// Class InteractiveToolsFramework.GizmoBaseFloatParameterSource
// Size: 0xc0 (Inherited: 0xa0)
struct UGizmoBaseFloatParameterSource : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class InteractiveToolsFramework.GizmoAxisTranslationParameterSource
// Size: 0x200 (Inherited: 0xc0)
struct UGizmoAxisTranslationParameterSource : UGizmoBaseFloatParameterSource {
	char pad_c0[0x80]; // 0xc0(0x80)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0x140(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // 0x150(0x10)
	float Parameter; // 0x160(0x04)
	struct FGizmoFloatParameterChange LastChange; // 0x164(0x08)
	char pad_16c[0x4]; // 0x16c(0x04)
	struct FVector CurTranslationAxis; // 0x170(0x18)
	struct FVector CurTranslationOrigin; // 0x188(0x18)
	struct FTransform InitialTransform; // 0x1a0(0x60)
};

// Class InteractiveToolsFramework.GizmoPlaneTranslationParameterSource
// Size: 0x290 (Inherited: 0xc0)
struct UGizmoPlaneTranslationParameterSource : UGizmoBaseVec2ParameterSource {
	char pad_c0[0xc0]; // 0xc0(0xc0)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0x180(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // 0x190(0x10)
	struct FVector2D Parameter; // 0x1a0(0x10)
	struct FGizmoVec2ParameterChange LastChange; // 0x1b0(0x20)
	struct FVector CurTranslationOrigin; // 0x1d0(0x18)
	struct FVector CurTranslationNormal; // 0x1e8(0x18)
	struct FVector CurTranslationAxisX; // 0x200(0x18)
	struct FVector CurTranslationAxisY; // 0x218(0x18)
	struct FTransform InitialTransform; // 0x230(0x60)
};

// Class InteractiveToolsFramework.GizmoAxisRotationParameterSource
// Size: 0x200 (Inherited: 0xc0)
struct UGizmoAxisRotationParameterSource : UGizmoBaseFloatParameterSource {
	char pad_c0[0x80]; // 0xc0(0x80)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0x140(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // 0x150(0x10)
	float Angle; // 0x160(0x04)
	struct FGizmoFloatParameterChange LastChange; // 0x164(0x08)
	char pad_16c[0x4]; // 0x16c(0x04)
	struct FVector CurRotationAxis; // 0x170(0x18)
	struct FVector CurRotationOrigin; // 0x188(0x18)
	struct FTransform InitialTransform; // 0x1a0(0x60)
};

// Class InteractiveToolsFramework.GizmoUniformScaleParameterSource
// Size: 0x1d0 (Inherited: 0xc0)
struct UGizmoUniformScaleParameterSource : UGizmoBaseVec2ParameterSource {
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0xb8(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // 0xc8(0x10)
	float ScaleMultiplier; // 0xd8(0x04)
	struct FVector2D Parameter; // 0xe0(0x10)
	struct FGizmoVec2ParameterChange LastChange; // 0xf0(0x20)
	struct FVector CurScaleOrigin; // 0x110(0x18)
	struct FVector CurScaleNormal; // 0x128(0x18)
	struct FVector CurScaleAxisX; // 0x140(0x18)
	struct FVector CurScaleAxisY; // 0x158(0x18)
	struct FTransform InitialTransform; // 0x170(0x60)
};

// Class InteractiveToolsFramework.GizmoAxisScaleParameterSource
// Size: 0x180 (Inherited: 0xc0)
struct UGizmoAxisScaleParameterSource : UGizmoBaseFloatParameterSource {
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0xb8(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // 0xc8(0x10)
	float ScaleMultiplier; // 0xd8(0x04)
	bool bClampToZero; // 0xdc(0x01)
	float Parameter; // 0xe0(0x04)
	struct FGizmoFloatParameterChange LastChange; // 0xe4(0x08)
	struct FVector CurScaleAxis; // 0xf0(0x18)
	struct FVector CurScaleOrigin; // 0x108(0x18)
	struct FTransform InitialTransform; // 0x120(0x60)
};

// Class InteractiveToolsFramework.GizmoPlaneScaleParameterSource
// Size: 0x220 (Inherited: 0xc0)
struct UGizmoPlaneScaleParameterSource : UGizmoBaseVec2ParameterSource {
	char pad_c0[0x40]; // 0xc0(0x40)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0x100(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource; // 0x110(0x10)
	float ScaleMultiplier; // 0x120(0x04)
	bool bUseEqualScaling; // 0x124(0x01)
	bool bClampToZero; // 0x125(0x01)
	char pad_126[0x2]; // 0x126(0x02)
	struct FVector2D Parameter; // 0x128(0x10)
	struct FGizmoVec2ParameterChange LastChange; // 0x138(0x20)
	struct FVector CurScaleOrigin; // 0x158(0x18)
	struct FVector CurScaleNormal; // 0x170(0x18)
	struct FVector CurScaleAxisX; // 0x188(0x18)
	struct FVector CurScaleAxisY; // 0x1a0(0x18)
	char pad_1b8[0x8]; // 0x1b8(0x08)
	struct FTransform InitialTransform; // 0x1c0(0x60)
};

// Class InteractiveToolsFramework.PhysicsDataSource
// Size: 0xa0 (Inherited: 0xa0)
struct UPhysicsDataSource : UInterface {
};

// Class InteractiveToolsFramework.PrimitiveComponentBackedTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UPrimitiveComponentBackedTarget : UInterface {
};

// Class InteractiveToolsFramework.SkeletalMeshBackedTarget
// Size: 0xa0 (Inherited: 0xa0)
struct USkeletalMeshBackedTarget : UAssetBackedTarget {
};

// Class InteractiveToolsFramework.StaticMeshBackedTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UStaticMeshBackedTarget : UAssetBackedTarget {
};

// Class InteractiveToolsFramework.InputBehavior
// Size: 0xa0 (Inherited: 0xa0)
struct UInputBehavior : UObject {
};

// Class InteractiveToolsFramework.AnyButtonInputBehavior
// Size: 0xf0 (Inherited: 0xa0)
struct UAnyButtonInputBehavior : UInputBehavior {
	char pad_a0[0x50]; // 0xa0(0x50)
};

// Class InteractiveToolsFramework.ClickDragInputBehavior
// Size: 0x1b0 (Inherited: 0xf0)
struct UClickDragInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0xa0]; // 0xf0(0xa0)
	bool bUpdateModifiersDuringDrag; // 0x190(0x01)
	char pad_191[0x1f]; // 0x191(0x1f)
};

// Class InteractiveToolsFramework.LocalClickDragInputBehavior
// Size: 0x2f0 (Inherited: 0x1b0)
struct ULocalClickDragInputBehavior : UClickDragInputBehavior {
	char pad_1b0[0x140]; // 0x1b0(0x140)
};

// Class InteractiveToolsFramework.KeyAsModifierInputBehavior
// Size: 0x110 (Inherited: 0xa0)
struct UKeyAsModifierInputBehavior : UInputBehavior {
	char pad_a0[0x70]; // 0xa0(0x70)
};

// Class InteractiveToolsFramework.MouseHoverBehavior
// Size: 0x110 (Inherited: 0xa0)
struct UMouseHoverBehavior : UInputBehavior {
	char pad_a0[0x70]; // 0xa0(0x70)
};

// Class InteractiveToolsFramework.LocalMouseHoverBehavior
// Size: 0x250 (Inherited: 0x110)
struct ULocalMouseHoverBehavior : UMouseHoverBehavior {
	char pad_110[0x140]; // 0x110(0x140)
};

// Class InteractiveToolsFramework.MouseWheelInputBehavior
// Size: 0x1a0 (Inherited: 0xf0)
struct UMouseWheelInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0xb0]; // 0xf0(0xb0)
};

// Class InteractiveToolsFramework.MultiClickSequenceInputBehavior
// Size: 0x1a0 (Inherited: 0xf0)
struct UMultiClickSequenceInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0xb0]; // 0xf0(0xb0)
};

// Class InteractiveToolsFramework.SingleClickInputBehavior
// Size: 0x1a0 (Inherited: 0xf0)
struct USingleClickInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0x40]; // 0xf0(0x40)
	bool HitTestOnRelease; // 0x130(0x01)
	char pad_131[0x6f]; // 0x131(0x6f)
};

// Class InteractiveToolsFramework.LocalSingleClickInputBehavior
// Size: 0x270 (Inherited: 0x1a0)
struct ULocalSingleClickInputBehavior : USingleClickInputBehavior {
	char pad_1a0[0xd0]; // 0x1a0(0xd0)
};

// Class InteractiveToolsFramework.SingleClickOrDragInputBehavior
// Size: 0x1f0 (Inherited: 0xf0)
struct USingleClickOrDragInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0xa0]; // 0xf0(0xa0)
	bool bBeginDragIfClickTargetNotHit; // 0x190(0x01)
	char pad_191[0x3]; // 0x191(0x03)
	float ClickDistanceThreshold; // 0x194(0x04)
	char pad_198[0x58]; // 0x198(0x58)
};

// Class InteractiveToolsFramework.SingleKeyCaptureBehavior
// Size: 0x180 (Inherited: 0xa0)
struct USingleKeyCaptureBehavior : UInputBehavior {
	char pad_a0[0xe0]; // 0xa0(0xe0)
};

// Class InteractiveToolsFramework.WidgetBaseBehavior
// Size: 0xa0 (Inherited: 0xa0)
struct UWidgetBaseBehavior : UInterface {
};

// Class InteractiveToolsFramework.AxisAngleGizmoBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UAxisAngleGizmoBuilder : UInteractiveGizmoBuilder {
};

// Class InteractiveToolsFramework.InteractiveGizmo
// Size: 0xb0 (Inherited: 0xa0)
struct UInteractiveGizmo : UObject {
	struct UInputBehaviorSet* InputBehaviors; // 0xa0(0x08)
	char pad_a8[0x8]; // 0xa8(0x08)
};

// Class InteractiveToolsFramework.AxisAngleGizmo
// Size: 0x240 (Inherited: 0xb0)
struct UAxisAngleGizmo : UInteractiveGizmo {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0xb8(0x10)
	struct TScriptInterface<IGizmoFloatParameterSource> AngleSource; // 0xc8(0x10)
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // 0xd8(0x10)
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // 0xe8(0x10)
	struct UClickDragInputBehavior* MouseBehavior; // 0xf8(0x08)
	char pad_100[0x80]; // 0x100(0x80)
	bool bInInteraction; // 0x180(0x01)
	char pad_181[0x7]; // 0x181(0x07)
	struct FVector RotationOrigin; // 0x188(0x18)
	struct FVector RotationAxis; // 0x1a0(0x18)
	struct FVector RotationPlaneX; // 0x1b8(0x18)
	struct FVector RotationPlaneY; // 0x1d0(0x18)
	struct FVector InteractionStartPoint; // 0x1e8(0x18)
	struct FVector InteractionCurPoint; // 0x200(0x18)
	float InteractionStartAngle; // 0x218(0x04)
	float InteractionCurAngle; // 0x21c(0x04)
	char pad_220[0x20]; // 0x220(0x20)
};

// Class InteractiveToolsFramework.AxisPositionGizmoBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UAxisPositionGizmoBuilder : UInteractiveGizmoBuilder {
};

// Class InteractiveToolsFramework.AxisPositionGizmo
// Size: 0x230 (Inherited: 0xb0)
struct UAxisPositionGizmo : UInteractiveGizmo {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0xb8(0x10)
	struct TScriptInterface<IGizmoFloatParameterSource> ParameterSource; // 0xc8(0x10)
	struct UGizmoViewContext* GizmoViewContext; // 0xd8(0x08)
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // 0xe0(0x10)
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // 0xf0(0x10)
	struct UClickDragInputBehavior* MouseBehavior; // 0x100(0x08)
	bool bEnableSignedAxis; // 0x108(0x01)
	char pad_109[0x88]; // 0x109(0x88)
	bool bInInteraction; // 0x191(0x01)
	char pad_192[0x6]; // 0x192(0x06)
	struct FVector InteractionOrigin; // 0x198(0x18)
	struct FVector InteractionAxis; // 0x1b0(0x18)
	struct FVector InteractionStartPoint; // 0x1c8(0x18)
	struct FVector InteractionCurPoint; // 0x1e0(0x18)
	float InteractionStartParameter; // 0x1f8(0x04)
	float InteractionCurParameter; // 0x1fc(0x04)
	float ParameterSign; // 0x200(0x04)
	char pad_204[0x2c]; // 0x204(0x2c)
};

// Class InteractiveToolsFramework.GizmoConstantAxisSource
// Size: 0xd0 (Inherited: 0xa0)
struct UGizmoConstantAxisSource : UObject {
	struct FVector Origin; // 0xa0(0x18)
	struct FVector Direction; // 0xb8(0x18)
};

// Class InteractiveToolsFramework.GizmoConstantFrameAxisSource
// Size: 0x100 (Inherited: 0xa0)
struct UGizmoConstantFrameAxisSource : UObject {
	struct FVector Origin; // 0xa0(0x18)
	struct FVector Direction; // 0xb8(0x18)
	struct FVector TangentX; // 0xd0(0x18)
	struct FVector TangentY; // 0xe8(0x18)
};

// Class InteractiveToolsFramework.GizmoWorldAxisSource
// Size: 0xc0 (Inherited: 0xa0)
struct UGizmoWorldAxisSource : UObject {
	struct FVector Origin; // 0xa0(0x18)
	int32_t AxisIndex; // 0xb8(0x04)
	char pad_bc[0x4]; // 0xbc(0x04)
};

// Class InteractiveToolsFramework.GizmoComponentAxisSource
// Size: 0xb0 (Inherited: 0xa0)
struct UGizmoComponentAxisSource : UObject {
	struct USceneComponent* Component; // 0xa0(0x08)
	int32_t AxisIndex; // 0xa8(0x04)
	bool bLocalAxes; // 0xac(0x01)
	char pad_ad[0x3]; // 0xad(0x03)
};

// Class InteractiveToolsFramework.BrushStampIndicatorBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UBrushStampIndicatorBuilder : UInteractiveGizmoBuilder {
};

// Class InteractiveToolsFramework.BrushStampIndicator
// Size: 0x150 (Inherited: 0xb0)
struct UBrushStampIndicator : UInteractiveGizmo {
	bool bVisible; // 0xa8(0x01)
	float BrushRadius; // 0xac(0x04)
	float BrushFalloff; // 0xb0(0x04)
	struct FVector BrushPosition; // 0xb8(0x18)
	struct FVector BrushNormal; // 0xd0(0x18)
	bool bDrawIndicatorLines; // 0xe8(0x01)
	bool bDrawRadiusCircle; // 0xe9(0x01)
	char pad_eb[0x1]; // 0xeb(0x01)
	int32_t SampleStepCount; // 0xec(0x04)
	struct FLinearColor LineColor; // 0xf0(0x10)
	float LineThickness; // 0x100(0x04)
	bool bDepthTested; // 0x104(0x01)
	bool bDrawSecondaryLines; // 0x105(0x01)
	char pad_106[0x2]; // 0x106(0x02)
	float SecondaryLineThickness; // 0x108(0x04)
	struct FLinearColor SecondaryLineColor; // 0x10c(0x10)
	char pad_11c[0x4]; // 0x11c(0x04)
	struct UPrimitiveComponent* AttachedComponent; // 0x120(0x08)
	char pad_128[0x28]; // 0x128(0x28)
};

// Class InteractiveToolsFramework.GizmoActor
// Size: 0x3a0 (Inherited: 0x3a0)
struct AGizmoActor : AInternalToolFrameworkActor {
};

// Class InteractiveToolsFramework.CombinedTransformGizmoActor
// Size: 0x430 (Inherited: 0x3a0)
struct ACombinedTransformGizmoActor : AGizmoActor {
	struct UPrimitiveComponent* TranslateX; // 0x3a0(0x08)
	struct UPrimitiveComponent* TranslateY; // 0x3a8(0x08)
	struct UPrimitiveComponent* TranslateZ; // 0x3b0(0x08)
	struct UPrimitiveComponent* TranslateYZ; // 0x3b8(0x08)
	struct UPrimitiveComponent* TranslateXZ; // 0x3c0(0x08)
	struct UPrimitiveComponent* TranslateXY; // 0x3c8(0x08)
	struct UPrimitiveComponent* RotateX; // 0x3d0(0x08)
	struct UPrimitiveComponent* RotateY; // 0x3d8(0x08)
	struct UPrimitiveComponent* RotateZ; // 0x3e0(0x08)
	struct UPrimitiveComponent* RotationSphere; // 0x3e8(0x08)
	struct UPrimitiveComponent* UniformScale; // 0x3f0(0x08)
	struct UPrimitiveComponent* AxisScaleX; // 0x3f8(0x08)
	struct UPrimitiveComponent* AxisScaleY; // 0x400(0x08)
	struct UPrimitiveComponent* AxisScaleZ; // 0x408(0x08)
	struct UPrimitiveComponent* PlaneScaleYZ; // 0x410(0x08)
	struct UPrimitiveComponent* PlaneScaleXZ; // 0x418(0x08)
	struct UPrimitiveComponent* PlaneScaleXY; // 0x420(0x08)
	char pad_428[0x8]; // 0x428(0x08)
};

// Class InteractiveToolsFramework.CombinedTransformGizmoBuilder
// Size: 0x160 (Inherited: 0xa0)
struct UCombinedTransformGizmoBuilder : UInteractiveGizmoBuilder {
	char pad_a0[0xc0]; // 0xa0(0xc0)
};

// Class InteractiveToolsFramework.CombinedTransformGizmo
// Size: 0x410 (Inherited: 0xb0)
struct UCombinedTransformGizmo : UInteractiveGizmo {
	struct UTransformProxy* ActiveTarget; // 0xa8(0x08)
	bool bSnapToWorldGrid; // 0xb0(0x01)
	bool bGridSizeIsExplicit; // 0xb4(0x01)
	struct FVector ExplicitGridSize; // 0xb8(0x18)
	bool bRotationGridSizeIsExplicit; // 0xd0(0x01)
	char pad_d3[0x5]; // 0xd3(0x05)
	struct FRotator ExplicitRotationGridSize; // 0xd8(0x18)
	bool bSnapToWorldRotGrid; // 0xf0(0x01)
	bool bUseContextCoordinateSystem; // 0xf1(0x01)
	char pad_f2[0x2]; // 0xf2(0x02)
	enum class EToolContextCoordinateSystem CurrentCoordinateSystem; // 0xf4(0x04)
	bool bUseContextGizmoMode; // 0xf8(0x01)
	enum class EToolContextTransformGizmoMode ActiveGizmoMode; // 0xf9(0x01)
	char pad_fa[0x126]; // 0xfa(0x126)
	struct TArray<struct UPrimitiveComponent*> ActiveComponents; // 0x220(0x10)
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos; // 0x230(0x10)
	char pad_240[0x50]; // 0x240(0x50)
	struct UGizmoConstantFrameAxisSource* CameraAxisSource; // 0x290(0x08)
	struct UGizmoComponentAxisSource* AxisXSource; // 0x298(0x08)
	struct UGizmoComponentAxisSource* AxisYSource; // 0x2a0(0x08)
	struct UGizmoComponentAxisSource* AxisZSource; // 0x2a8(0x08)
	struct UGizmoComponentAxisSource* UnitAxisXSource; // 0x2b0(0x08)
	struct UGizmoComponentAxisSource* UnitAxisYSource; // 0x2b8(0x08)
	struct UGizmoComponentAxisSource* UnitAxisZSource; // 0x2c0(0x08)
	struct UGizmoTransformChangeStateTarget* StateTarget; // 0x2c8(0x08)
	char pad_2d0[0x140]; // 0x2d0(0x140)
};

// Class InteractiveToolsFramework.GizmoArrowComponent
// Size: 0x710 (Inherited: 0x6f0)
struct UGizmoArrowComponent : UGizmoBaseComponent {
	struct FVector Direction; // 0x6e8(0x18)
	float Gap; // 0x700(0x04)
	float Length; // 0x704(0x04)
	float Thickness; // 0x708(0x04)
};

// Class InteractiveToolsFramework.GizmoBoxComponent
// Size: 0x740 (Inherited: 0x6f0)
struct UGizmoBoxComponent : UGizmoBaseComponent {
	struct FVector Origin; // 0x6e8(0x18)
	struct FQuat Rotation; // 0x700(0x20)
	struct FVector Dimensions; // 0x720(0x18)
	float LineThickness; // 0x738(0x04)
	bool bRemoveHiddenLines; // 0x73c(0x01)
	bool bEnableAxisFlip; // 0x73d(0x01)
};

// Class InteractiveToolsFramework.GizmoCircleComponent
// Size: 0x710 (Inherited: 0x6f0)
struct UGizmoCircleComponent : UGizmoBaseComponent {
	struct FVector Normal; // 0x6e8(0x18)
	float Radius; // 0x700(0x04)
	float Thickness; // 0x704(0x04)
	int32_t NumSides; // 0x708(0x04)
	bool bViewAligned; // 0x70c(0x01)
	bool bDrawFullCircle; // 0x70d(0x01)
	bool bOnlyAllowFrontFacingHits; // 0x70e(0x01)
};

// Class InteractiveToolsFramework.GizmoElementBase
// Size: 0x180 (Inherited: 0xa0)
struct UGizmoElementBase : UObject {
	bool bEnabled; // 0x98(0x01)
	bool bEnabledForPerspectiveProjection; // 0x99(0x01)
	bool bEnabledForOrthographicProjection; // 0x9a(0x01)
	bool bEnabledForDefaultState; // 0x9b(0x01)
	bool bEnabledForHoveringState; // 0x9c(0x01)
	bool bEnabledForInteractingState; // 0x9d(0x01)
	uint32_t PartIdentifier; // 0xa0(0x04)
	struct FGizmoElementMeshRenderStateAttributes MeshRenderAttributes; // 0xa4(0x60)
	enum class EGizmoElementState ElementState; // 0x104(0x01)
	enum class EGizmoElementInteractionState ElementInteractionState; // 0x108(0x04)
	enum class EGizmoElementViewDependentType ViewDependentType; // 0x10c(0x04)
	struct FVector ViewDependentAxis; // 0x110(0x18)
	float ViewDependentAngleTol; // 0x128(0x04)
	float ViewDependentAxialMaxCosAngleTol; // 0x12c(0x04)
	float ViewDependentPlanarMinCosAngleTol; // 0x130(0x04)
	enum class EGizmoElementViewAlignType ViewAlignType; // 0x134(0x04)
	struct FVector ViewAlignAxis; // 0x138(0x18)
	struct FVector ViewAlignNormal; // 0x150(0x18)
	float ViewAlignAxialAngleTol; // 0x168(0x04)
	float ViewAlignAxialMaxCosAngleTol; // 0x16c(0x04)
	float PixelHitDistanceThreshold; // 0x170(0x04)
	char pad_177[0x9]; // 0x177(0x09)
};

// Class InteractiveToolsFramework.GizmoElementLineBase
// Size: 0x1d0 (Inherited: 0x180)
struct UGizmoElementLineBase : UGizmoElementBase {
	struct FGizmoElementLineRenderStateAttributes LineRenderAttributes; // 0x178(0x3c)
	float LineThickness; // 0x1b4(0x04)
	bool bScreenSpaceLine; // 0x1b8(0x01)
	float HoverLineThicknessMultiplier; // 0x1bc(0x04)
	float InteractLineThicknessMultiplier; // 0x1c0(0x04)
	char pad_1c9[0x7]; // 0x1c9(0x07)
};

// Class InteractiveToolsFramework.GizmoElementCircleBase
// Size: 0x240 (Inherited: 0x1d0)
struct UGizmoElementCircleBase : UGizmoElementLineBase {
	struct FVector Center; // 0x1c8(0x18)
	struct FVector Axis0; // 0x1e0(0x18)
	struct FVector Axis1; // 0x1f8(0x18)
	double Radius; // 0x210(0x08)
	int32_t NumSegments; // 0x218(0x04)
	enum class EGizmoElementPartialType PartialType; // 0x21c(0x04)
	double PartialStartAngle; // 0x220(0x08)
	double PartialEndAngle; // 0x228(0x08)
	double PartialViewDependentMaxCosTol; // 0x230(0x08)
};

// Class InteractiveToolsFramework.GizmoElementArc
// Size: 0x240 (Inherited: 0x240)
struct UGizmoElementArc : UGizmoElementCircleBase {
	double InnerRadius; // 0x238(0x08)
};

// Class InteractiveToolsFramework.GizmoElementArrow
// Size: 0x200 (Inherited: 0x180)
struct UGizmoElementArrow : UGizmoElementBase {
	struct UGizmoElementCylinder* CylinderElement; // 0x180(0x08)
	struct UGizmoElementCone* ConeElement; // 0x188(0x08)
	struct UGizmoElementBox* BoxElement; // 0x190(0x08)
	struct FVector base; // 0x198(0x18)
	struct FVector Direction; // 0x1b0(0x18)
	struct FVector SideDirection; // 0x1c8(0x18)
	float BodyLength; // 0x1e0(0x04)
	float BodyRadius; // 0x1e4(0x04)
	float HeadLength; // 0x1e8(0x04)
	float HeadRadius; // 0x1ec(0x04)
	int32_t NumSides; // 0x1f0(0x04)
	enum class EGizmoElementArrowHeadType HeadType; // 0x1f4(0x04)
	char pad_1f8[0x8]; // 0x1f8(0x08)
};

// Class InteractiveToolsFramework.GizmoElementBox
// Size: 0x1e0 (Inherited: 0x180)
struct UGizmoElementBox : UGizmoElementBase {
	struct FVector Center; // 0x178(0x18)
	struct FVector Dimensions; // 0x190(0x18)
	struct FVector UpDirection; // 0x1a8(0x18)
	struct FVector SideDirection; // 0x1c0(0x18)
};

// Class InteractiveToolsFramework.GizmoElementCircle
// Size: 0x240 (Inherited: 0x240)
struct UGizmoElementCircle : UGizmoElementCircleBase {
	bool bDrawMesh; // 0x238(0x01)
	bool bDrawLine; // 0x239(0x01)
	bool bHitMesh; // 0x23a(0x01)
	bool bHitLine; // 0x23b(0x01)
};

// Class InteractiveToolsFramework.GizmoElementCone
// Size: 0x1c0 (Inherited: 0x180)
struct UGizmoElementCone : UGizmoElementBase {
	struct FVector Origin; // 0x178(0x18)
	struct FVector Direction; // 0x190(0x18)
	float Height; // 0x1a8(0x04)
	float Radius; // 0x1ac(0x04)
	int32_t NumSides; // 0x1b0(0x04)
	char pad_1bc[0x4]; // 0x1bc(0x04)
};

// Class InteractiveToolsFramework.GizmoElementCylinder
// Size: 0x1c0 (Inherited: 0x180)
struct UGizmoElementCylinder : UGizmoElementBase {
	struct FVector base; // 0x178(0x18)
	struct FVector Direction; // 0x190(0x18)
	float Height; // 0x1a8(0x04)
	float Radius; // 0x1ac(0x04)
	int32_t NumSides; // 0x1b0(0x04)
	char pad_1bc[0x4]; // 0x1bc(0x04)
};

// Class InteractiveToolsFramework.GizmoElementGroup
// Size: 0x1e0 (Inherited: 0x1d0)
struct UGizmoElementGroup : UGizmoElementLineBase {
	bool bConstantScale; // 0x1c8(0x01)
	bool bHitOwner; // 0x1c9(0x01)
	struct TArray<struct UGizmoElementBase*> Elements; // 0x1d0(0x10)
};

// Class InteractiveToolsFramework.GizmoElementHitTarget
// Size: 0x100 (Inherited: 0xa0)
struct UGizmoElementHitTarget : UObject {
	struct UGizmoElementBase* GizmoElement; // 0xa0(0x08)
	struct UGizmoViewContext* GizmoViewContext; // 0xa8(0x08)
	struct UTransformProxy* GizmoTransformProxy; // 0xb0(0x08)
	char pad_b8[0x48]; // 0xb8(0x48)
};

// Class InteractiveToolsFramework.GizmoElementHitMultiTarget
// Size: 0x100 (Inherited: 0xa0)
struct UGizmoElementHitMultiTarget : UObject {
	struct UGizmoElementBase* GizmoElement; // 0xa0(0x08)
	struct UGizmoViewContext* GizmoViewContext; // 0xa8(0x08)
	struct UTransformProxy* GizmoTransformProxy; // 0xb0(0x08)
	char pad_b8[0x48]; // 0xb8(0x48)
};

// Class InteractiveToolsFramework.GizmoElementRectangle
// Size: 0x220 (Inherited: 0x1d0)
struct UGizmoElementRectangle : UGizmoElementLineBase {
	struct FVector Center; // 0x1c8(0x18)
	float Width; // 0x1e0(0x04)
	float Height; // 0x1e4(0x04)
	struct FVector UpDirection; // 0x1e8(0x18)
	struct FVector SideDirection; // 0x200(0x18)
	bool bDrawMesh; // 0x218(0x01)
	bool bDrawLine; // 0x219(0x01)
	bool bHitMesh; // 0x21a(0x01)
	bool bHitLine; // 0x21b(0x01)
};

// Class InteractiveToolsFramework.GizmoElementTorus
// Size: 0x250 (Inherited: 0x240)
struct UGizmoElementTorus : UGizmoElementCircleBase {
	double InnerRadius; // 0x238(0x08)
	int32_t NumInnerSlices; // 0x240(0x04)
	bool bEndCaps; // 0x244(0x01)
	char pad_24d[0x3]; // 0x24d(0x03)
};

// Class InteractiveToolsFramework.GizmoTransformSource
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoTransformSource : UInterface {

	void SetTransform(struct FTransform& NewTransform); // Function InteractiveToolsFramework.GizmoTransformSource.SetTransform // (Native|Public|HasOutParms|HasDefaults) // @ game+0x93b7e30
	struct FTransform GetTransform(); // Function InteractiveToolsFramework.GizmoTransformSource.GetTransform // (Native|Public|HasDefaults|Const) // @ game+0x93895e0
};

// Class InteractiveToolsFramework.GizmoAxisSource
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoAxisSource : UInterface {

	bool HasTangentVectors(); // Function InteractiveToolsFramework.GizmoAxisSource.HasTangentVectors // (Native|Public|Const) // @ game+0x93a7e50
	void GetTangentVectors(struct FVector& TangentXOut, struct FVector& TangentYOut); // Function InteractiveToolsFramework.GizmoAxisSource.GetTangentVectors // (Native|Public|HasOutParms|HasDefaults|Const) // @ game+0x939c170
	struct FVector GetOrigin(); // Function InteractiveToolsFramework.GizmoAxisSource.GetOrigin // (Native|Public|HasDefaults|Const) // @ game+0x9381240
	struct FVector GetDirection(); // Function InteractiveToolsFramework.GizmoAxisSource.GetDirection // (Native|Public|HasDefaults|Const) // @ game+0x939aaa0
};

// Class InteractiveToolsFramework.GizmoClickTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoClickTarget : UInterface {

	void UpdateInteractingState(bool bInteracting); // Function InteractiveToolsFramework.GizmoClickTarget.UpdateInteractingState // (Native|Public) // @ game+0x939dc50
	void UpdateHoverState(bool bHovering); // Function InteractiveToolsFramework.GizmoClickTarget.UpdateHoverState // (Native|Public) // @ game+0x936d7d0
};

// Class InteractiveToolsFramework.GizmoClickMultiTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoClickMultiTarget : UInterface {

	void UpdateInteractingState(bool bInteracting, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateInteractingState // (Native|Public) // @ game+0x93a60f0
	void UpdateHoverState(bool bHovering, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateHoverState // (Native|Public) // @ game+0x9385b10
	void UpdateHittableState(bool bHittable, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateHittableState // (Native|Public) // @ game+0x938e9d0
};

// Class InteractiveToolsFramework.GizmoRenderTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoRenderTarget : UInterface {
};

// Class InteractiveToolsFramework.GizmoRenderMultiTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoRenderMultiTarget : UInterface {

	void UpdateVisibilityState(bool bVisible, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoRenderMultiTarget.UpdateVisibilityState // (Native|Public) // @ game+0x9385b10
};

// Class InteractiveToolsFramework.GizmoStateTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoStateTarget : UInterface {

	void EndUpdate(); // Function InteractiveToolsFramework.GizmoStateTarget.EndUpdate // (Native|Public) // @ game+0x67d49e0
	void BeginUpdate(); // Function InteractiveToolsFramework.GizmoStateTarget.BeginUpdate // (Native|Public) // @ game+0x1520a60
};

// Class InteractiveToolsFramework.GizmoFloatParameterSource
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoFloatParameterSource : UInterface {

	void SetParameter(float NewValue); // Function InteractiveToolsFramework.GizmoFloatParameterSource.SetParameter // (Native|Public) // @ game+0x93bd6b0
	float GetParameter(); // Function InteractiveToolsFramework.GizmoFloatParameterSource.GetParameter // (Native|Public|Const) // @ game+0x93b3220
	void EndModify(); // Function InteractiveToolsFramework.GizmoFloatParameterSource.EndModify // (Native|Public) // @ game+0x5d49150
	void BeginModify(); // Function InteractiveToolsFramework.GizmoFloatParameterSource.BeginModify // (Native|Public) // @ game+0x67d49e0
};

// Class InteractiveToolsFramework.GizmoVec2ParameterSource
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoVec2ParameterSource : UInterface {

	void SetParameter(struct FVector2D& NewValue); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.SetParameter // (Native|Public|HasOutParms|HasDefaults) // @ game+0x93b72c0
	struct FVector2D GetParameter(); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.GetParameter // (Native|Public|HasDefaults|Const) // @ game+0x936d050
	void EndModify(); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.EndModify // (Native|Public) // @ game+0x5d49150
	void BeginModify(); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.BeginModify // (Native|Public) // @ game+0x67d49e0
};

// Class InteractiveToolsFramework.GizmoLineHandleComponent
// Size: 0x730 (Inherited: 0x6f0)
struct UGizmoLineHandleComponent : UGizmoBaseComponent {
	struct FVector Normal; // 0x6e8(0x18)
	float HandleSize; // 0x700(0x04)
	float Thickness; // 0x704(0x04)
	struct FVector Direction; // 0x708(0x18)
	float Length; // 0x720(0x04)
	bool bImageScale; // 0x724(0x01)
	char pad_72d[0x3]; // 0x72d(0x03)
};

// Class InteractiveToolsFramework.GizmoRectangleComponent
// Size: 0x740 (Inherited: 0x6f0)
struct UGizmoRectangleComponent : UGizmoBaseComponent {
	struct FVector DirectionX; // 0x6e8(0x18)
	struct FVector DirectionY; // 0x700(0x18)
	bool bOrientYAccordingToCamera; // 0x718(0x01)
	float OffsetX; // 0x71c(0x04)
	float OffsetY; // 0x720(0x04)
	float LengthX; // 0x724(0x04)
	float LengthY; // 0x728(0x04)
	float Thickness; // 0x72c(0x04)
	char SegmentFlags; // 0x730(0x01)
	char pad_736[0xa]; // 0x736(0x0a)
};

// Class InteractiveToolsFramework.GizmoViewContext
// Size: 0x250 (Inherited: 0xa0)
struct UGizmoViewContext : UObject {
	char pad_a0[0x1b0]; // 0xa0(0x1b0)
};

// Class InteractiveToolsFramework.GizmoLambdaHitTarget
// Size: 0x160 (Inherited: 0xa0)
struct UGizmoLambdaHitTarget : UObject {
	char pad_a0[0xc0]; // 0xa0(0xc0)
};

// Class InteractiveToolsFramework.GizmoComponentHitTarget
// Size: 0x170 (Inherited: 0xa0)
struct UGizmoComponentHitTarget : UObject {
	struct UPrimitiveComponent* Component; // 0xa0(0x08)
	char pad_a8[0xc8]; // 0xa8(0xc8)
};

// Class InteractiveToolsFramework.IntervalGizmoActor
// Size: 0x3c0 (Inherited: 0x3a0)
struct AIntervalGizmoActor : AGizmoActor {
	struct UGizmoLineHandleComponent* UpIntervalComponent; // 0x3a0(0x08)
	struct UGizmoLineHandleComponent* DownIntervalComponent; // 0x3a8(0x08)
	struct UGizmoLineHandleComponent* ForwardIntervalComponent; // 0x3b0(0x08)
	char pad_3b8[0x8]; // 0x3b8(0x08)
};

// Class InteractiveToolsFramework.IntervalGizmoBuilder
// Size: 0x130 (Inherited: 0xa0)
struct UIntervalGizmoBuilder : UInteractiveGizmoBuilder {
	char pad_a0[0x90]; // 0xa0(0x90)
};

// Class InteractiveToolsFramework.IntervalGizmo
// Size: 0x270 (Inherited: 0xb0)
struct UIntervalGizmo : UInteractiveGizmo {
	struct UGizmoTransformChangeStateTarget* StateTarget; // 0xa8(0x08)
	char pad_b8[0x50]; // 0xb8(0x50)
	struct UTransformProxy* TransformProxy; // 0x108(0x08)
	struct TArray<struct UPrimitiveComponent*> ActiveComponents; // 0x110(0x10)
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos; // 0x120(0x10)
	char pad_130[0x18]; // 0x130(0x18)
	struct UGizmoComponentAxisSource* AxisYSource; // 0x148(0x08)
	struct UGizmoComponentAxisSource* AxisZSource; // 0x150(0x08)
	char pad_158[0x118]; // 0x158(0x118)
};

// Class InteractiveToolsFramework.GizmoAxisIntervalParameterSource
// Size: 0xd0 (Inherited: 0xc0)
struct UGizmoAxisIntervalParameterSource : UGizmoBaseFloatParameterSource {
	struct TScriptInterface<IGizmoFloatParameterSource> FloatParameterSource; // 0xb8(0x10)
	float MinParameter; // 0xc8(0x04)
	float MaxParameter; // 0xcc(0x04)
};

// Class InteractiveToolsFramework.GizmoLocalFloatParameterSource
// Size: 0xd0 (Inherited: 0xc0)
struct UGizmoLocalFloatParameterSource : UGizmoBaseFloatParameterSource {
	float Value; // 0xb8(0x04)
	struct FGizmoFloatParameterChange LastChange; // 0xbc(0x08)
	char pad_cc[0x4]; // 0xcc(0x04)
};

// Class InteractiveToolsFramework.PlanePositionGizmoBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UPlanePositionGizmoBuilder : UInteractiveGizmoBuilder {
};

// Class InteractiveToolsFramework.PlanePositionGizmo
// Size: 0x2e0 (Inherited: 0xb0)
struct UPlanePositionGizmo : UInteractiveGizmo {
	char pad_b0[0x8]; // 0xb0(0x08)
	struct TScriptInterface<IGizmoAxisSource> AxisSource; // 0xb8(0x10)
	struct TScriptInterface<IGizmoVec2ParameterSource> ParameterSource; // 0xc8(0x10)
	struct TScriptInterface<IGizmoClickTarget> HitTarget; // 0xd8(0x10)
	struct TScriptInterface<IGizmoStateTarget> StateTarget; // 0xe8(0x10)
	struct UClickDragInputBehavior* MouseBehavior; // 0xf8(0x08)
	bool bEnableSignedAxis; // 0x100(0x01)
	bool bFlipX; // 0x101(0x01)
	bool bFlipY; // 0x102(0x01)
	char pad_103[0x8d]; // 0x103(0x8d)
	bool bInInteraction; // 0x190(0x01)
	char pad_191[0x7]; // 0x191(0x07)
	struct FVector InteractionOrigin; // 0x198(0x18)
	struct FVector InteractionNormal; // 0x1b0(0x18)
	struct FVector InteractionAxisX; // 0x1c8(0x18)
	struct FVector InteractionAxisY; // 0x1e0(0x18)
	struct FVector InteractionStartPoint; // 0x1f8(0x18)
	struct FVector InteractionCurPoint; // 0x210(0x18)
	struct FVector2D InteractionStartParameter; // 0x228(0x10)
	struct FVector2D InteractionCurParameter; // 0x238(0x10)
	struct FVector2D ParameterSigns; // 0x248(0x10)
	char pad_258[0x88]; // 0x258(0x88)
};

// Class InteractiveToolsFramework.RepositionableTransformGizmoBuilder
// Size: 0x160 (Inherited: 0x160)
struct URepositionableTransformGizmoBuilder : UCombinedTransformGizmoBuilder {
};

// Class InteractiveToolsFramework.RepositionableTransformGizmo
// Size: 0x4b0 (Inherited: 0x410)
struct URepositionableTransformGizmo : UCombinedTransformGizmo {
	char pad_410[0x90]; // 0x410(0x90)
	struct UGizmoTransformChangeStateTarget* RepositionStateTarget; // 0x4a0(0x08)
	char pad_4a8[0x8]; // 0x4a8(0x08)
};

// Class InteractiveToolsFramework.ScalableSphereGizmoBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UScalableSphereGizmoBuilder : UInteractiveGizmoBuilder {
};

// Class InteractiveToolsFramework.ScalableSphereGizmo
// Size: 0x170 (Inherited: 0xb0)
struct UScalableSphereGizmo : UInteractiveGizmo {
	char pad_b0[0x40]; // 0xb0(0x40)
	float HitErrorThreshold; // 0xf0(0x04)
	char pad_f4[0x4]; // 0xf4(0x04)
	struct FText TransactionDescription; // 0xf8(0x18)
	float Radius; // 0x110(0x04)
	bool bIsHovering; // 0x114(0x01)
	bool bIsDragging; // 0x115(0x01)
	char pad_116[0x2]; // 0x116(0x02)
	struct UTransformProxy* ActiveTarget; // 0x118(0x08)
	struct FVector ActiveAxis; // 0x120(0x18)
	struct FVector DragStartWorldPosition; // 0x138(0x18)
	struct FVector DragCurrentPositionProjected; // 0x150(0x18)
	float InteractionStartParameter; // 0x168(0x04)
	char pad_16c[0x4]; // 0x16c(0x04)
};

// Class InteractiveToolsFramework.ScalableSphereGizmoInputBehavior
// Size: 0x140 (Inherited: 0xf0)
struct UScalableSphereGizmoInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0x50]; // 0xf0(0x50)
};

// Class InteractiveToolsFramework.GizmoNilStateTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UGizmoNilStateTarget : UObject {
};

// Class InteractiveToolsFramework.GizmoLambdaStateTarget
// Size: 0x120 (Inherited: 0xa0)
struct UGizmoLambdaStateTarget : UObject {
	char pad_a0[0x80]; // 0xa0(0x80)
};

// Class InteractiveToolsFramework.GizmoObjectModifyStateTarget
// Size: 0xd0 (Inherited: 0xa0)
struct UGizmoObjectModifyStateTarget : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct TScriptInterface<IToolContextTransactionProvider> TransactionManager; // 0xc0(0x10)
};

// Class InteractiveToolsFramework.GizmoTransformChangeStateTarget
// Size: 0x1b0 (Inherited: 0xa0)
struct UGizmoTransformChangeStateTarget : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
	struct TScriptInterface<IToolContextTransactionProvider> TransactionManager; // 0xc0(0x10)
	char pad_d0[0xe0]; // 0xd0(0xe0)
};

// Class InteractiveToolsFramework.CombinedTransformGizmoContextObject
// Size: 0xd0 (Inherited: 0xa0)
struct UCombinedTransformGizmoContextObject : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)
};

// Class InteractiveToolsFramework.TransformProxy
// Size: 0x220 (Inherited: 0xa0)
struct UTransformProxy : UObject {
	char pad_a0[0xa0]; // 0xa0(0xa0)
	bool bRotatePerObject; // 0x140(0x01)
	bool bSetPivotMode; // 0x141(0x01)
	char pad_142[0x1e]; // 0x142(0x1e)
	struct FTransform SharedTransform; // 0x160(0x60)
	struct FTransform InitialSharedTransform; // 0x1c0(0x60)
};

// Class InteractiveToolsFramework.GizmoBaseTransformSource
// Size: 0xc0 (Inherited: 0xa0)
struct UGizmoBaseTransformSource : UObject {
	char pad_a0[0x20]; // 0xa0(0x20)
};

// Class InteractiveToolsFramework.GizmoComponentWorldTransformSource
// Size: 0xd0 (Inherited: 0xc0)
struct UGizmoComponentWorldTransformSource : UGizmoBaseTransformSource {
	struct USceneComponent* Component; // 0xb8(0x08)
	bool bModifyComponentOnTransform; // 0xc0(0x01)
	char pad_c9[0x7]; // 0xc9(0x07)
};

// Class InteractiveToolsFramework.GizmoScaledTransformSource
// Size: 0x150 (Inherited: 0xc0)
struct UGizmoScaledTransformSource : UGizmoBaseTransformSource {
	struct TScriptInterface<IGizmoTransformSource> ChildTransformSource; // 0xb8(0x10)
	char pad_d0[0x80]; // 0xd0(0x80)
};

// Class InteractiveToolsFramework.GizmoTransformProxyTransformSource
// Size: 0xe0 (Inherited: 0xc0)
struct UGizmoTransformProxyTransformSource : UGizmoBaseTransformSource {
	struct UTransformProxy* Proxy; // 0xb8(0x08)
	char pad_c8[0x18]; // 0xc8(0x18)
};

// Class InteractiveToolsFramework.GizmoScaledAndUnscaledTransformSources
// Size: 0xe0 (Inherited: 0xc0)
struct UGizmoScaledAndUnscaledTransformSources : UGizmoBaseTransformSource {
	struct TScriptInterface<IGizmoTransformSource> ScaledTransformSource; // 0xb8(0x10)
	struct TScriptInterface<IGizmoTransformSource> UnscaledTransformSource; // 0xc8(0x10)
};

// Class InteractiveToolsFramework.InteractiveToolPropertySet
// Size: 0x120 (Inherited: 0xa0)
struct UInteractiveToolPropertySet : UObject {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TMap<struct FString, struct UInteractiveToolPropertySet*> CachedPropertiesMap; // 0xa8(0x50)
	bool bIsPropertySetEnabled; // 0xf8(0x01)
	char pad_f9[0x27]; // 0xf9(0x27)
};

// Class InteractiveToolsFramework.BrushBaseProperties
// Size: 0x130 (Inherited: 0x120)
struct UBrushBaseProperties : UInteractiveToolPropertySet {
	float BrushSize; // 0x118(0x04)
	bool bSpecifyRadius; // 0x11c(0x01)
	float BrushRadius; // 0x120(0x04)
	float BrushStrength; // 0x124(0x04)
	float BrushFalloffAmount; // 0x128(0x04)
	bool bShowStrength; // 0x12c(0x01)
	bool bShowFalloff; // 0x12d(0x01)
};

// Class InteractiveToolsFramework.BrushAdjusterInputBehavior
// Size: 0x140 (Inherited: 0xf0)
struct UBrushAdjusterInputBehavior : UAnyButtonInputBehavior {
	char pad_f0[0x50]; // 0xf0(0x50)
};

// Class InteractiveToolsFramework.InteractiveTool
// Size: 0x110 (Inherited: 0xa0)
struct UInteractiveTool : UObject {
	char pad_a0[0x30]; // 0xa0(0x30)
	struct UInputBehaviorSet* InputBehaviors; // 0xd0(0x08)
	struct TArray<struct UObject*> ToolPropertyObjects; // 0xd8(0x10)
	char pad_e8[0x28]; // 0xe8(0x28)
};

// Class InteractiveToolsFramework.SingleSelectionTool
// Size: 0x120 (Inherited: 0x110)
struct USingleSelectionTool : UInteractiveTool {
	char pad_110[0x8]; // 0x110(0x08)
	struct UToolTarget* Target; // 0x118(0x08)
};

// Class InteractiveToolsFramework.MeshSurfacePointTool
// Size: 0x180 (Inherited: 0x120)
struct UMeshSurfacePointTool : USingleSelectionTool {
	char pad_120[0x50]; // 0x120(0x50)
	struct TWeakObjectPtr<struct UWorld> TargetWorld; // 0x170(0x08)
	char pad_178[0x8]; // 0x178(0x08)
};

// Class InteractiveToolsFramework.BaseBrushTool
// Size: 0x300 (Inherited: 0x180)
struct UBaseBrushTool : UMeshSurfacePointTool {
	struct UBrushBaseProperties* BrushProperties; // 0x178(0x08)
	bool bInBrushStroke; // 0x180(0x01)
	float WorldToLocalScale; // 0x184(0x04)
	struct FBrushStampData LastBrushStamp; // 0x188(0x128)
	char pad_2b5[0xb]; // 0x2b5(0x0b)
	struct TSoftClassPtr<UObject> PropertyClass; // 0x2c0(0x28)
	struct UBrushStampIndicator* BrushStampIndicator; // 0x2e8(0x08)
	char pad_2f0[0x10]; // 0x2f0(0x10)
};

// Class InteractiveToolsFramework.InteractiveToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolBuilder : UObject {
};

// Class InteractiveToolsFramework.ClickDragToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UClickDragToolBuilder : UInteractiveToolBuilder {
};

// Class InteractiveToolsFramework.ClickDragTool
// Size: 0x120 (Inherited: 0x110)
struct UClickDragTool : UInteractiveTool {
	char pad_110[0x10]; // 0x110(0x10)
};

// Class InteractiveToolsFramework.InteractiveToolWithToolTargetsBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractiveToolWithToolTargetsBuilder : UInteractiveToolBuilder {
};

// Class InteractiveToolsFramework.MeshSurfacePointToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshSurfacePointToolBuilder : UInteractiveToolWithToolTargetsBuilder {
};

// Class InteractiveToolsFramework.SingleClickToolBuilder
// Size: 0xa0 (Inherited: 0xa0)
struct USingleClickToolBuilder : UInteractiveToolBuilder {
};

// Class InteractiveToolsFramework.SingleClickTool
// Size: 0x120 (Inherited: 0x110)
struct USingleClickTool : UInteractiveTool {
	char pad_110[0x10]; // 0x110(0x10)
};

// Class InteractiveToolsFramework.ContextObjectStore
// Size: 0xb0 (Inherited: 0xa0)
struct UContextObjectStore : UObject {
	struct TArray<struct UObject*> ContextObjects; // 0x98(0x10)
};

// Class InteractiveToolsFramework.InputBehaviorSet
// Size: 0xb0 (Inherited: 0xa0)
struct UInputBehaviorSet : UObject {
	struct TArray<struct FBehaviorInfo> Behaviors; // 0x98(0x10)
};

// Class InteractiveToolsFramework.InputBehaviorSource
// Size: 0xa0 (Inherited: 0xa0)
struct UInputBehaviorSource : UInterface {
};

// Class InteractiveToolsFramework.LocalInputBehaviorSource
// Size: 0xe0 (Inherited: 0xa0)
struct ULocalInputBehaviorSource : UObject {
	char pad_a0[0x40]; // 0xa0(0x40)
};

// Class InteractiveToolsFramework.InputRouter
// Size: 0x200 (Inherited: 0xa0)
struct UInputRouter : UObject {
	bool bAutoInvalidateOnHover; // 0x98(0x01)
	bool bAutoInvalidateOnCapture; // 0x99(0x01)
	char pad_a2[0x6]; // 0xa2(0x06)
	struct UInputBehaviorSet* ActiveInputBehaviors; // 0xa8(0x08)
	char pad_b0[0x150]; // 0xb0(0x150)
};

// Class InteractiveToolsFramework.InteractionMechanic
// Size: 0xa0 (Inherited: 0xa0)
struct UInteractionMechanic : UObject {
};

// Class InteractiveToolsFramework.InteractiveGizmoManager
// Size: 0x130 (Inherited: 0xa0)
struct UInteractiveGizmoManager : UObject {
	struct TArray<struct FActiveGizmo> ActiveGizmos; // 0xa0(0x10)
	char pad_b0[0x18]; // 0xb0(0x18)
	struct TMap<struct FString, struct UInteractiveGizmoBuilder*> GizmoBuilders; // 0xc8(0x50)
	char pad_118[0x18]; // 0x118(0x18)
};

// Class InteractiveToolsFramework.InteractiveToolManager
// Size: 0x210 (Inherited: 0xa0)
struct UInteractiveToolManager : UObject {
	char pad_a0[0x28]; // 0xa0(0x28)
	struct UInteractiveTool* ActiveLeftTool; // 0xc8(0x08)
	struct UInteractiveTool* ActiveRightTool; // 0xd0(0x08)
	char pad_d8[0x80]; // 0xd8(0x80)
	struct TMap<struct FString, struct UInteractiveToolBuilder*> ToolBuilders; // 0x158(0x50)
	char pad_1a8[0x68]; // 0x1a8(0x68)
};

// Class InteractiveToolsFramework.InteractiveToolsContext
// Size: 0x3a0 (Inherited: 0xa0)
struct UInteractiveToolsContext : UObject {
	char pad_a0[0x28]; // 0xa0(0x28)
	struct UInputRouter* InputRouter; // 0xc8(0x08)
	struct UToolTargetManager* TargetManager; // 0xd0(0x08)
	struct UInteractiveToolManager* ToolManager; // 0xd8(0x08)
	struct UInteractiveGizmoManager* GizmoManager; // 0xe0(0x08)
	struct UContextObjectStore* ContextObjectStore; // 0xe8(0x08)
	char pad_f0[0x280]; // 0xf0(0x280)
	struct TSoftClassPtr<UObject> ToolManagerClass; // 0x370(0x28)
	char pad_398[0x8]; // 0x398(0x08)
};

// Class InteractiveToolsFramework.MultiSelectionTool
// Size: 0x130 (Inherited: 0x110)
struct UMultiSelectionTool : UInteractiveTool {
	char pad_110[0x8]; // 0x110(0x08)
	struct TArray<struct UToolTarget*> Targets; // 0x118(0x10)
	char pad_128[0x8]; // 0x128(0x08)
};

// Class InteractiveToolsFramework.SceneSnappingManager
// Size: 0xa0 (Inherited: 0xa0)
struct USceneSnappingManager : UObject {
};

// Class InteractiveToolsFramework.SelectionSet
// Size: 0xb0 (Inherited: 0xa0)
struct USelectionSet : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class InteractiveToolsFramework.MeshSelectionSet
// Size: 0xf0 (Inherited: 0xb0)
struct UMeshSelectionSet : USelectionSet {
	struct TArray<int32_t> Vertices; // 0xb0(0x10)
	struct TArray<int32_t> Edges; // 0xc0(0x10)
	struct TArray<int32_t> Faces; // 0xd0(0x10)
	struct TArray<int32_t> Groups; // 0xe0(0x10)
};

// Class InteractiveToolsFramework.ToolTargetManager
// Size: 0xb0 (Inherited: 0xa0)
struct UToolTargetManager : UObject {
	struct TArray<struct UToolTargetFactory*> Factories; // 0xa0(0x10)
};

// Class InteractiveToolsFramework.ToolTarget
// Size: 0xa0 (Inherited: 0xa0)
struct UToolTarget : UObject {
};

// Class InteractiveToolsFramework.PrimitiveComponentToolTarget
// Size: 0xb0 (Inherited: 0xa0)
struct UPrimitiveComponentToolTarget : UToolTarget {
	char pad_a0[0x10]; // 0xa0(0x10)
};

// Class InteractiveToolsFramework.ToolTargetFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UToolTargetFactory : UObject {
};

// Class InteractiveToolsFramework.PrimitiveComponentToolTargetFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UPrimitiveComponentToolTargetFactory : UToolTargetFactory {
};

