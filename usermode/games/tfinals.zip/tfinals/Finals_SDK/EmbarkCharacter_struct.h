// ScriptStruct EmbarkCharacter.BasedMovementInfoBP
// Size: 0x48 (Inherited: 0x00)
struct FBasedMovementInfoBP {
	struct UPrimitiveComponent* MovementBase; // 0x00(0x08)
	struct FName BoneName; // 0x08(0x08)
	struct FVector_NetQuantize100 Location; // 0x10(0x18)
	struct FRotator Rotation; // 0x28(0x18)
	bool bServerHasBaseComponent; // 0x40(0x01)
	bool bRelativeLocation; // 0x41(0x01)
	bool bRelativeRotation; // 0x42(0x01)
	bool bServerHasVelocity; // 0x43(0x01)
	bool bIsBaseUnresolved; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
};

