// Class EmbarkSoundCueNodes.SoundNodeDistanceCrossFadeEmbark
// Size: 0xd0 (Inherited: 0xc0)
struct USoundNodeDistanceCrossFadeEmbark : USoundNode {
	struct TArray<struct FDistanceDatum> CrossFadeInput; // 0xb8(0x10)
	bool bPreserveInitialDistance; // 0xc8(0x01)
};

// Class EmbarkSoundCueNodes.SoundNodePitchModulatorEmbark
// Size: 0xe0 (Inherited: 0xc0)
struct USoundNodePitchModulatorEmbark : USoundNode {
	struct TArray<struct FEmbarkModulatorParams> ModulationParams; // 0xb8(0x10)
	struct FVector2D ClampRange; // 0xc8(0x10)
};

// Class EmbarkSoundCueNodes.SoundNodeVolumeModulatorEmbark
// Size: 0xe0 (Inherited: 0xc0)
struct USoundNodeVolumeModulatorEmbark : USoundNode {
	struct TArray<struct FEmbarkModulatorParams> ModulationParams; // 0xb8(0x10)
	struct FVector2D ClampRange; // 0xc8(0x10)
};

