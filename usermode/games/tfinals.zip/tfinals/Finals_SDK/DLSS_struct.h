// Enum DLSS.EDLSSSettingOverride
enum class EDLSSSettingOverride : uint8_t {
	Enabled = 0,
	Disabled = 1,
	UseProjectSettings = 2,
	EDLSSSettingOverride_MAX = 3
};

// Enum DLSS.EDLSSPreset
enum class EDLSSPreset : uint8_t {
	Default = 0,
	A = 1,
	B = 2,
	C = 3,
	D = 4,
	E = 5,
	F = 6,
	G = 7,
	H = 8,
	I = 9,
	J = 10,
	K = 11,
	L = 12,
	M = 13,
	N = 14,
	O = 15,
	MAX = 16
};

// Enum DLSS.EDLSSRRPreset
enum class EDLSSRRPreset : uint8_t {
	Default = 0,
	A = 1,
	B = 2,
	C = 3,
	D = 4,
	E = 5,
	F = 6,
	G = 7,
	H = 8,
	I = 9,
	J = 10,
	K = 11,
	L = 12,
	M = 13,
	N = 14,
	O = 15,
	MAX = 16
};

