// Class MetasoundEngine.MetasoundGeneratorHandle
// Size: 0x150 (Inherited: 0xa0)
struct UMetasoundGeneratorHandle : UObject {
	char pad_a0[0xb0]; // 0xa0(0xb0)

	bool WatchOutput(struct FName OutputName, struct FDelegate& OnOutputValueChanged, struct FName AnalyzerName, struct FName AnalyzerOutputName); // Function MetasoundEngine.MetasoundGeneratorHandle.WatchOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6700670
	void OnOutputValueChangedMulticast__DelegateSignature(struct FName Name, struct FMetaSoundOutput& Output); // DelegateFunction MetasoundEngine.MetasoundGeneratorHandle.OnOutputValueChangedMulticast__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x4abfe0
	struct UMetasoundGeneratorHandle* CreateMetaSoundGeneratorHandle(struct UAudioComponent* OnComponent); // Function MetasoundEngine.MetasoundGeneratorHandle.CreateMetaSoundGeneratorHandle // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x66c87d0
	bool ApplyParameterPack(struct UMetasoundParameterPack* Pack); // Function MetasoundEngine.MetasoundGeneratorHandle.ApplyParameterPack // (Final|Native|Public|BlueprintCallable) // @ game+0x6714d90
};

// Class MetasoundEngine.MetasoundOutputBlueprintAccess
// Size: 0xa0 (Inherited: 0xa0)
struct UMetasoundOutputBlueprintAccess : UBlueprintFunctionLibrary {

	bool IsTime(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsTime // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x679e0e0
	bool IsString(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsString // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6735670
	bool IsInt32(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsInt32 // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6790200
	bool IsFloat(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsFloat // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6761530
	bool IsBool(struct FMetaSoundOutput& Output); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.IsBool // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6693d80
	float GetTimeSeconds(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetTimeSeconds // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6771db0
	struct FString GetString(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetString // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x66ab0a0
	int32_t GetInt32(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetInt32 // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x673e7c0
	float GetFloat(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetFloat // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x66d12b0
	bool GetBool(struct FMetaSoundOutput& Output, bool& Success); // Function MetasoundEngine.MetasoundOutputBlueprintAccess.GetBool // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x6725500
};

// Class MetasoundEngine.MetaSoundOutputSubsystem
// Size: 0xc0 (Inherited: 0xb0)
struct UMetaSoundOutputSubsystem : UTickableWorldSubsystem {
	struct TArray<struct UMetasoundGeneratorHandle*> TrackedGenerators; // 0xb0(0x10)

	bool WatchOutput(struct UAudioComponent* AudioComponent, struct FName OutputName, struct FDelegate& OnOutputValueChanged, struct FName AnalyzerName, struct FName AnalyzerOutputName); // Function MetasoundEngine.MetaSoundOutputSubsystem.WatchOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x679db40
};

// Class MetasoundEngine.MetaSoundSettings
// Size: 0xf0 (Inherited: 0xb0)
struct UMetaSoundSettings : UDeveloperSettings {
	bool bAutoUpdateEnabled; // 0xa8(0x01)
	struct TArray<struct FMetasoundFrontendClassName> AutoUpdateDenylist; // 0xb0(0x10)
	struct TArray<struct FDefaultMetaSoundAssetAutoUpdateSettings> AutoUpdateAssetDenylist; // 0xc0(0x10)
	bool bAutoUpdateLogWarningOnDroppedConnection; // 0xd0(0x01)
	char pad_d2[0x6]; // 0xd2(0x06)
	struct TArray<struct FDirectoryPath> DirectoriesToRegister; // 0xd8(0x10)
	int32_t DenyListCacheChangeID; // 0xe8(0x04)
	char pad_ec[0x4]; // 0xec(0x04)
};

// Class MetasoundEngine.MetasoundEditorGraphBase
// Size: 0xd0 (Inherited: 0xd0)
struct UMetasoundEditorGraphBase : UEdGraph {
};

// Class MetasoundEngine.MetaSoundPatch
// Size: 0x3d0 (Inherited: 0xa0)
struct UMetaSoundPatch : UObject {
	char pad_a0[0x68]; // 0xa0(0x68)
	struct FMetasoundFrontendDocument RootMetaSoundDocument; // 0x108(0x1c8)
	struct TSet<struct FString> ReferencedAssetClassKeys; // 0x2d0(0x50)
	struct TSet<struct UObject*> ReferencedAssetClassObjects; // 0x320(0x50)
	struct TSet<struct FSoftObjectPath> ReferenceAssetClassCache; // 0x370(0x50)
	struct FGuid AssetClassID; // 0x3c0(0x10)
};

// Class MetasoundEngine.MetaSoundAssetSubsystem
// Size: 0x250 (Inherited: 0xa0)
struct UMetaSoundAssetSubsystem : UEngineSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TArray<struct FMetaSoundAsyncAssetDependencies> LoadingDependencies; // 0xa8(0x10)
	char pad_b8[0x198]; // 0xb8(0x198)

	void UnregisterAssetClassesInDirectories(struct TArray<struct FMetaSoundAssetDirectory>& Directories); // Function MetasoundEngine.MetaSoundAssetSubsystem.UnregisterAssetClassesInDirectories // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x671f040
	void RegisterAssetClassesInDirectories(struct TArray<struct FMetaSoundAssetDirectory>& Directories); // Function MetasoundEngine.MetaSoundAssetSubsystem.RegisterAssetClassesInDirectories // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67353c0
};

// Class MetasoundEngine.MetaSoundBuilderBase
// Size: 0xd0 (Inherited: 0xa0)
struct UMetaSoundBuilderBase : UObject {
	struct FMetaSoundFrontendDocumentBuilder Builder; // 0x98(0x30)
	bool bIsAttached; // 0xc8(0x01)

	void SetNodeInputDefault(struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, struct FMetasoundFrontendLiteral& Literal, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.SetNodeInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6765270
	void SetGraphInputDefault(struct FName InputName, struct FMetasoundFrontendLiteral& Literal, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.SetGraphInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6715420
	void RemoveNodeInputDefault(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveNodeInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x672b870
	void RemoveNode(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66adac0
	void RemoveInterface(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveInterface // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66b26f0
	void RemoveGraphOutput(struct FName Name, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveGraphOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6751970
	void RemoveGraphInput(struct FName Name, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.RemoveGraphInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66d92d0
	bool NodesAreConnected(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle, struct FMetaSoundBuilderNodeInputHandle& InputHandle); // Function MetasoundEngine.MetaSoundBuilderBase.NodesAreConnected // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x66ac8c0
	bool NodeOutputIsConnected(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle); // Function MetasoundEngine.MetaSoundBuilderBase.NodeOutputIsConnected // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6734620
	bool NodeInputIsConnected(struct FMetaSoundBuilderNodeInputHandle& InputHandle); // Function MetasoundEngine.MetaSoundBuilderBase.NodeInputIsConnected // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x675cb20
	bool IsPreset(); // Function MetasoundEngine.MetaSoundBuilderBase.IsPreset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x66c7160
	bool InterfaceIsDeclared(struct FName InterfaceName); // Function MetasoundEngine.MetaSoundBuilderBase.InterfaceIsDeclared // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6710680
	struct UObject* GetReferencedPresetAsset(); // Function MetasoundEngine.MetaSoundBuilderBase.GetReferencedPresetAsset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x672ee70
	void GetNodeOutputData(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle, struct FName& Name, struct FName& DataType, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeOutputData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6780770
	struct FMetasoundFrontendLiteral GetNodeInputDefault(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeInputDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x675f900
	void GetNodeInputData(struct FMetaSoundBuilderNodeInputHandle& InputHandle, struct FName& Name, struct FName& DataType, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeInputData // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6710900
	struct FMetasoundFrontendLiteral GetNodeInputClassDefault(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.GetNodeInputClassDefault // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x678df10
	struct TArray<struct FMetaSoundBuilderNodeOutputHandle> FindNodeOutputsByDataType(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult, struct FName DataType); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputsByDataType // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6731f50
	struct TArray<struct FMetaSoundBuilderNodeOutputHandle> FindNodeOutputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x674b330
	struct FMetaSoundNodeHandle FindNodeOutputParent(struct FMetaSoundBuilderNodeOutputHandle& OutputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputParent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6772440
	struct FMetaSoundBuilderNodeOutputHandle FindNodeOutputByName(struct FMetaSoundNodeHandle& NodeHandle, struct FName OutputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeOutputByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67644a0
	struct TArray<struct FMetaSoundBuilderNodeInputHandle> FindNodeInputsByDataType(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult, struct FName DataType); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputsByDataType // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6721210
	struct TArray<struct FMetaSoundBuilderNodeInputHandle> FindNodeInputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67066f0
	struct FMetaSoundNodeHandle FindNodeInputParent(struct FMetaSoundBuilderNodeInputHandle& InputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputParent // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6772440
	struct FMetaSoundBuilderNodeInputHandle FindNodeInputByName(struct FMetaSoundNodeHandle& NodeHandle, struct FName InputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeInputByName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66aaf20
	struct FMetasoundFrontendVersion FindNodeClassVersion(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindNodeClassVersion // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66eee40
	struct TArray<struct FMetaSoundNodeHandle> FindInterfaceOutputNodes(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindInterfaceOutputNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66ffdc0
	struct TArray<struct FMetaSoundNodeHandle> FindInterfaceInputNodes(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindInterfaceInputNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66ca9f0
	struct FMetaSoundNodeHandle FindGraphOutputNode(struct FName OutputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindGraphOutputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66bae40
	struct FMetaSoundNodeHandle FindGraphInputNode(struct FName InputName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.FindGraphInputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66eaa30
	void DisconnectNodesByInterfaceBindings(struct FMetaSoundNodeHandle& FromNodeHandle, struct FMetaSoundNodeHandle& ToNodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodesByInterfaceBindings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67a0330
	void DisconnectNodes(struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x671f130
	void DisconnectNodeOutput(struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodeOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66c8200
	void DisconnectNodeInput(struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.DisconnectNodeInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6785880
	void ConvertToPreset(struct TScriptInterface<IMetaSoundDocumentInterface>& ReferencedNodeClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConvertToPreset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66af070
	void ConvertFromPreset(enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConvertFromPreset // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6736610
	bool ContainsNodeOutput(struct FMetaSoundBuilderNodeOutputHandle& Output); // Function MetasoundEngine.MetaSoundBuilderBase.ContainsNodeOutput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6693a80
	bool ContainsNodeInput(struct FMetaSoundBuilderNodeInputHandle& Input); // Function MetasoundEngine.MetaSoundBuilderBase.ContainsNodeInput // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x671f6b0
	bool ContainsNode(struct FMetaSoundNodeHandle& Node); // Function MetasoundEngine.MetaSoundBuilderBase.ContainsNode // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x67052b0
	void ConnectNodesByInterfaceBindings(struct FMetaSoundNodeHandle& FromNodeHandle, struct FMetaSoundNodeHandle& ToNodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodesByInterfaceBindings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x670e850
	void ConnectNodes(struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodes // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66d2a30
	void ConnectNodeOutputToGraphOutput(struct FName GraphOutputName, struct FMetaSoundBuilderNodeOutputHandle& NodeOutputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeOutputToGraphOutput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67347a0
	struct TArray<struct FMetaSoundBuilderNodeInputHandle> ConnectNodeOutputsToMatchingGraphInterfaceOutputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeOutputsToMatchingGraphInterfaceOutputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6721b80
	void ConnectNodeInputToGraphInput(struct FName GraphInputName, struct FMetaSoundBuilderNodeInputHandle& NodeInputHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeInputToGraphInput // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67965f0
	struct TArray<struct FMetaSoundBuilderNodeOutputHandle> ConnectNodeInputsToMatchingGraphInterfaceInputs(struct FMetaSoundNodeHandle& NodeHandle, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.ConnectNodeInputsToMatchingGraphInterfaceInputs // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x670da00
	struct FMetaSoundNodeHandle AddNodeByClassName(struct FMetasoundFrontendClassName& ClassName, int32_t MajorVersion, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.AddNodeByClassName // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66f9880
	struct FMetaSoundNodeHandle AddNode(struct TScriptInterface<IMetaSoundDocumentInterface>& NodeClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.AddNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x679dda0
	void AddInterface(struct FName InterfaceName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderBase.AddInterface // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6712e20
	struct FMetaSoundBuilderNodeInputHandle AddGraphOutputNode(struct FName Name, struct FName DataType, struct FMetasoundFrontendLiteral DefaultValue, enum class EMetaSoundBuilderResult& OutResult, bool bIsConstructorOutput); // Function MetasoundEngine.MetaSoundBuilderBase.AddGraphOutputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x679c790
	struct FMetaSoundBuilderNodeOutputHandle AddGraphInputNode(struct FName Name, struct FName DataType, struct FMetasoundFrontendLiteral DefaultValue, enum class EMetaSoundBuilderResult& OutResult, bool bIsConstructorInput); // Function MetasoundEngine.MetaSoundBuilderBase.AddGraphInputNode // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6779c20
};

// Class MetasoundEngine.MetaSoundPatchBuilder
// Size: 0xd0 (Inherited: 0xd0)
struct UMetaSoundPatchBuilder : UMetaSoundBuilderBase {

	struct TScriptInterface<IMetaSoundDocumentInterface> Build(struct UObject* Parent, struct FMetaSoundBuilderOptions& Options); // Function MetasoundEngine.MetaSoundPatchBuilder.Build // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6789ed0
};

// Class MetasoundEngine.MetaSoundSourceBuilder
// Size: 0xe0 (Inherited: 0xd0)
struct UMetaSoundSourceBuilder : UMetaSoundBuilderBase {
	char pad_d0[0x10]; // 0xd0(0x10)

	void SetFormat(enum class EMetaSoundOutputAudioFormat OutputFormat, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundSourceBuilder.SetFormat // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66d9b40
	bool GetLiveUpdatesEnabled(); // Function MetasoundEngine.MetaSoundSourceBuilder.GetLiveUpdatesEnabled // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x66a42d0
	struct TScriptInterface<IMetaSoundDocumentInterface> Build(struct UObject* Parent, struct FMetaSoundBuilderOptions& Options); // Function MetasoundEngine.MetaSoundSourceBuilder.Build // (Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x6789ed0
	void Audition(struct UObject* Parent, struct UAudioComponent* AudioComponent, struct FDelegate OnCreateGenerator, bool bLiveUpdatesEnabled); // Function MetasoundEngine.MetaSoundSourceBuilder.Audition // (Final|Native|Public|BlueprintCallable) // @ game+0x6739430
};

// Class MetasoundEngine.MetaSoundBuilderSubsystem
// Size: 0x150 (Inherited: 0xa0)
struct UMetaSoundBuilderSubsystem : UEngineSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	struct TMap<struct FName, struct UMetaSoundBuilderBase*> NamedBuilders; // 0xa8(0x50)
	struct TMap<struct FName, struct TWeakObjectPtr<struct UMetaSoundBuilderBase>> AssetBuilders; // 0xf8(0x50)
	char pad_148[0x8]; // 0x148(0x08)

	bool UnregisterSourceBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.UnregisterSourceBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x66b9840
	bool UnregisterPatchBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.UnregisterPatchBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x66b9840
	bool UnregisterBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.UnregisterBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x66b9840
	void RegisterSourceBuilder(struct FName BuilderName, struct UMetaSoundSourceBuilder* Builder); // Function MetasoundEngine.MetaSoundBuilderSubsystem.RegisterSourceBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x66d4090
	void RegisterPatchBuilder(struct FName BuilderName, struct UMetaSoundPatchBuilder* Builder); // Function MetasoundEngine.MetaSoundBuilderSubsystem.RegisterPatchBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x66d4090
	void RegisterBuilder(struct FName BuilderName, struct UMetaSoundBuilderBase* Builder); // Function MetasoundEngine.MetaSoundBuilderSubsystem.RegisterBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x66d4090
	bool IsInterfaceRegistered(struct FName InInterfaceName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.IsInterfaceRegistered // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x66d0c80
	struct UMetaSoundSourceBuilder* FindSourceBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.FindSourceBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x67897a0
	struct UMetaSoundPatchBuilder* FindPatchBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.FindPatchBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x6702740
	struct UMetaSoundBuilderBase* FindBuilder(struct FName BuilderName); // Function MetasoundEngine.MetaSoundBuilderSubsystem.FindBuilder // (Final|Native|Public|BlueprintCallable) // @ game+0x676fb00
	struct FMetasoundFrontendLiteral CreateStringMetaSoundLiteral(struct FString Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateStringMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x670f4c0
	struct FMetasoundFrontendLiteral CreateStringArrayMetaSoundLiteral(struct TArray<struct FString>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateStringArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67992e0
	struct UMetaSoundSourceBuilder* CreateSourcePresetBuilder(struct FName BuilderName, struct TScriptInterface<IMetaSoundDocumentInterface>& ReferencedSourceClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateSourcePresetBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x674ef40
	struct UMetaSoundSourceBuilder* CreateSourceBuilder(struct FName BuilderName, struct FMetaSoundBuilderNodeOutputHandle& OnPlayNodeOutput, struct FMetaSoundBuilderNodeInputHandle& OnFinishedNodeInput, struct TArray<struct FMetaSoundBuilderNodeInputHandle>& AudioOutNodeInputs, enum class EMetaSoundBuilderResult& OutResult, enum class EMetaSoundOutputAudioFormat OutputFormat, bool bIsOneShot); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateSourceBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67507f0
	struct UMetaSoundPatchBuilder* CreatePatchPresetBuilder(struct FName BuilderName, struct TScriptInterface<IMetaSoundDocumentInterface>& ReferencedPatchClass, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreatePatchPresetBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6780ce0
	struct UMetaSoundPatchBuilder* CreatePatchBuilder(struct FName BuilderName, enum class EMetaSoundBuilderResult& OutResult); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreatePatchBuilder // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6761e30
	struct FMetasoundFrontendLiteral CreateObjectMetaSoundLiteral(struct UObject* Value); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateObjectMetaSoundLiteral // (Final|Native|Public|BlueprintCallable) // @ game+0x66c0770
	struct FMetasoundFrontendLiteral CreateObjectArrayMetaSoundLiteral(struct TArray<struct UObject*>& Value); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateObjectArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67889c0
	struct FMetasoundFrontendLiteral CreateMetaSoundLiteralFromParam(struct FAudioParameter& Param); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateMetaSoundLiteralFromParam // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6786300
	struct FMetasoundFrontendLiteral CreateIntMetaSoundLiteral(int32_t Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateIntMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x678d740
	struct FMetasoundFrontendLiteral CreateIntArrayMetaSoundLiteral(struct TArray<int32_t>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateIntArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67214e0
	struct FMetasoundFrontendLiteral CreateFloatMetaSoundLiteral(float Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateFloatMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6710ff0
	struct FMetasoundFrontendLiteral CreateFloatArrayMetaSoundLiteral(struct TArray<float>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateFloatArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x6770110
	struct FMetasoundFrontendLiteral CreateBoolMetaSoundLiteral(bool Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateBoolMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x67076b0
	struct FMetasoundFrontendLiteral CreateBoolArrayMetaSoundLiteral(struct TArray<bool>& Value, struct FName& DataType); // Function MetasoundEngine.MetaSoundBuilderSubsystem.CreateBoolArrayMetaSoundLiteral // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x66a3bc0
};

// Class MetasoundEngine.MetaSoundSource
// Size: 0x900 (Inherited: 0x4f0)
struct UMetaSoundSource : USoundWaveProcedural {
	char pad_4f0[0x70]; // 0x4f0(0x70)
	struct FMetasoundFrontendDocument RootMetaSoundDocument; // 0x560(0x1c8)
	struct TSet<struct FString> ReferencedAssetClassKeys; // 0x728(0x50)
	struct TSet<struct UObject*> ReferencedAssetClassObjects; // 0x778(0x50)
	struct TSet<struct FSoftObjectPath> ReferenceAssetClassCache; // 0x7c8(0x50)
	enum class EMetaSoundOutputAudioFormat OutputFormat; // 0x818(0x01)
	char pad_819[0x3]; // 0x819(0x03)
	struct FGuid AssetClassID; // 0x81c(0x10)
	char pad_82c[0xd4]; // 0x82c(0xd4)
};

