// Class AngelscriptCode.AngelscriptActorLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptActorLibrary : UObject {

	void SetbRunConstructionScriptOnDrag(struct AActor* Actor, bool Value); // Function AngelscriptCode.AngelscriptActorLibrary.SetbRunConstructionScriptOnDrag // (Final|Native|Static|Public) // @ game+0x3f6fac0
	void SetActorTransform(struct AActor* Actor, struct FTransform& NewTransform); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f735a0
	void SetActorRotationQuat(struct AActor* Actor, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f702e0
	void SetActorRotation(struct AActor* Actor, struct FRotator& NewRotation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6eb30
	void SetActorRelativeTransform(struct AActor* Actor, struct FTransform& NewRelativeTransform); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f72c20
	void SetActorRelativeRotationQuat(struct AActor* Actor, struct FQuat& NewRelativeRotation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f73f30
	void SetActorRelativeRotation(struct AActor* Actor, struct FRotator& NewRelativeRotation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6f410
	void SetActorRelativeLocation(struct AActor* Actor, struct FVector& NewRelativeLocation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f727e0
	void SetActorQuat(struct AActor* Actor, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f702e0
	void SetActorLocationAndRotationQuat(struct AActor* Actor, struct FVector& NewLocation, struct FQuat& NewRotation, bool bTeleport); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorLocationAndRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6fcf0
	void SetActorLocationAndRotation(struct AActor* Actor, struct FVector& NewLocation, struct FRotator& NewRotation, bool bTeleport); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorLocationAndRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f74790
	void SetActorLocation(struct AActor* Actor, struct FVector& NewLocation); // Function AngelscriptCode.AngelscriptActorLibrary.SetActorLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f73b60
	void RerunConstructionScripts(struct AActor* Actor); // Function AngelscriptCode.AngelscriptActorLibrary.RerunConstructionScripts // (Final|Native|Static|Public) // @ game+0x257bb60
	struct FTransform GetActorRelativeTransform(struct AActor* Actor); // Function AngelscriptCode.AngelscriptActorLibrary.GetActorRelativeTransform // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f73100
	struct FRotator GetActorRelativeRotation(struct AActor* Actor); // Function AngelscriptCode.AngelscriptActorLibrary.GetActorRelativeRotation // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f74e20
	struct FVector GetActorRelativeLocation(struct AActor* Actor); // Function AngelscriptCode.AngelscriptActorLibrary.GetActorRelativeLocation // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f710b0
	struct FQuat GetActorQuat(struct AActor* Actor); // Function AngelscriptCode.AngelscriptActorLibrary.GetActorQuat // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f73470
	void AttachToComponent(struct AActor* Actor, struct USceneComponent* Parent, struct FName SocketName, enum class EAttachmentRule AttachmentRule); // Function AngelscriptCode.AngelscriptActorLibrary.AttachToComponent // (Final|Native|Static|Public) // @ game+0x3f703e0
	void AttachToActor(struct AActor* Actor, struct AActor* ParentActor, struct FName SocketName, enum class EAttachmentRule AttachmentRule); // Function AngelscriptCode.AngelscriptActorLibrary.AttachToActor // (Final|Native|Static|Public) // @ game+0x3f706c0
	void AddActorWorldTransform(struct AActor* Actor, struct FTransform& DeltaTransform); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f73970
	void AddActorWorldRotationQuat(struct AActor* Actor, struct FQuat& DeltaRotation); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorWorldRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f73d90
	void AddActorWorldRotation(struct AActor* Actor, struct FRotator& DeltaRotation); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorWorldRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f72660
	void AddActorWorldOffset(struct AActor* Actor, struct FVector& DeltaLocation); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorWorldOffset // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f71e20
	void AddActorLocalTransform(struct AActor* Actor, struct FTransform& DeltaTransform); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorLocalTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f74090
	void AddActorLocalRotationQuat(struct AActor* Actor, struct FQuat& DeltaRotation); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorLocalRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f75750
	void AddActorLocalRotation(struct AActor* Actor, struct FRotator& DeltaRotation); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorLocalRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f74ac0
	void AddActorLocalOffset(struct AActor* Actor, struct FVector& DeltaLocation); // Function AngelscriptCode.AngelscriptActorLibrary.AddActorLocalOffset // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f73350
};

// Class AngelscriptCode.AngelscriptAllScriptRootsCommandlet
// Size: 0xf0 (Inherited: 0xf0)
struct UAngelscriptAllScriptRootsCommandlet : UCommandlet {
};

// Class AngelscriptCode.AngelscriptComponentLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptComponentLibrary : UObject {

	void SetWorldTransform(struct USceneComponent* Component, struct FTransform& NewTransform); // Function AngelscriptCode.AngelscriptComponentLibrary.SetWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6ece0
	void SetWorldRotationQuat(struct USceneComponent* Component, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetWorldRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f74be0
	void SetWorldRotation(struct USceneComponent* Component, struct FRotator& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetWorldRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6fbb0
	void SetWorldLocationAndRotationQuat(struct USceneComponent* Component, struct FVector& NewLocation, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetWorldLocationAndRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f700b0
	void SetWorldLocationAndRotation(struct USceneComponent* Component, struct FVector& NewLocation, struct FRotator& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetWorldLocationAndRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f74590
	void SetWorldLocation(struct USceneComponent* Component, struct FVector& NewLocation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetWorldLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f718b0
	void SetRelativeTransform(struct USceneComponent* Component, struct FTransform& NewTransform); // Function AngelscriptCode.AngelscriptComponentLibrary.SetRelativeTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6f2c0
	void SetRelativeRotationQuat(struct USceneComponent* Component, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f737d0
	void SetRelativeRotation(struct USceneComponent* Component, struct FRotator& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f70d10
	void SetRelativeLocationAndRotationQuat(struct USceneComponent* Component, struct FVector& NewLocation, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetRelativeLocationAndRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f75280
	void SetRelativeLocationAndRotation(struct USceneComponent* Component, struct FVector& NewLocation, struct FRotator& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetRelativeLocationAndRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6f8e0
	void SetRelativeLocation(struct USceneComponent* Component, struct FVector& NewLocation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f72e60
	void SetComponentQuat(struct USceneComponent* Component, struct FQuat& NewRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.SetComponentQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f74be0
	void SetbVisualizeComponent(struct USceneComponent* Component, bool bVisualize); // Function AngelscriptCode.AngelscriptComponentLibrary.SetbVisualizeComponent // (Final|Native|Static|Public) // @ game+0x3f6fac0
	bool IsAttachedTo_Actor(struct USceneComponent* Component, struct AActor* CheckActor); // Function AngelscriptCode.AngelscriptComponentLibrary.IsAttachedTo_Actor // (Final|Native|Static|Public) // @ game+0x3f74470
	bool IsAttachedTo(struct USceneComponent* Component, struct USceneComponent* CheckComponent); // Function AngelscriptCode.AngelscriptComponentLibrary.IsAttachedTo // (Final|Native|Static|Public) // @ game+0x3f70bd0
	struct FQuat GetSocketQuaternion(struct USceneComponent* Component, struct FName& SocketName); // Function AngelscriptCode.AngelscriptComponentLibrary.GetSocketQuaternion // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f71cd0
	struct FVector GetShapeCenter(struct USceneComponent* Component); // Function AngelscriptCode.AngelscriptComponentLibrary.GetShapeCenter // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f72980
	struct FVector GetRelativeScale3D(struct USceneComponent* Component); // Function AngelscriptCode.AngelscriptComponentLibrary.GetRelativeScale3D // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f74280
	struct FRotator GetRelativeRotation(struct USceneComponent* Component); // Function AngelscriptCode.AngelscriptComponentLibrary.GetRelativeRotation // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f755c0
	struct FVector GetRelativeLocation(struct USceneComponent* Component); // Function AngelscriptCode.AngelscriptComponentLibrary.GetRelativeLocation // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f743c0
	struct FQuat GetComponentQuat(struct USceneComponent* Component); // Function AngelscriptCode.AngelscriptComponentLibrary.GetComponentQuat // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f750c0
	struct FBoxSphereBounds GetBounds(struct USceneComponent* Component); // Function AngelscriptCode.AngelscriptComponentLibrary.GetBounds // (Final|Native|Static|Public|HasDefaults) // @ game+0x3f72520
	void AttachToComponent(struct USceneComponent* Component, struct USceneComponent* Parent, struct FName& SocketName, enum class EAttachmentRule AttachmentRule); // Function AngelscriptCode.AngelscriptComponentLibrary.AttachToComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f72a30
	void AddWorldTransform(struct USceneComponent* Component, struct FTransform& DeltaTransform); // Function AngelscriptCode.AngelscriptComponentLibrary.AddWorldTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6f030
	void AddWorldRotationQuat(struct USceneComponent* Component, struct FQuat& DeltaRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddWorldRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f6ee30
	void AddWorldRotation(struct USceneComponent* Component, struct FRotator& DeltaRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddWorldRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f71a70
	void AddWorldOffset(struct USceneComponent* Component, struct FVector& DeltaLocation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddWorldOffset // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f71310
	void AddRelativeRotationQuat(struct USceneComponent* Component, struct FQuat& DeltaRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddRelativeRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f73250
	void AddRelativeRotation(struct USceneComponent* Component, struct FRotator& DeltaRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddRelativeRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f70e30
	void AddRelativeLocation(struct USceneComponent* Component, struct FVector& DeltaLocation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddRelativeLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f72250
	void AddLocalTransform(struct USceneComponent* Component, struct FTransform& DeltaTransform); // Function AngelscriptCode.AngelscriptComponentLibrary.AddLocalTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f70f60
	void AddLocalRotationQuat(struct USceneComponent* Component, struct FQuat& DeltaRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddLocalRotationQuat // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f70ad0
	void AddLocalRotation(struct USceneComponent* Component, struct FRotator& DeltaRotation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddLocalRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f72000
	void AddLocalOffset(struct USceneComponent* Component, struct FVector& DeltaLocation); // Function AngelscriptCode.AngelscriptComponentLibrary.AddLocalOffset // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f71570
};

// Class AngelscriptCode.AngelscriptHitResultLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptHitResultLibrary : UObject {

	void SetComponent(struct FHitResult& HitResult, struct UPrimitiveComponent* Component); // Function AngelscriptCode.AngelscriptHitResultLibrary.SetComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f86320
	void SetbStartPenetrating(struct FHitResult& HitResult, bool bStartPenetrating); // Function AngelscriptCode.AngelscriptHitResultLibrary.SetbStartPenetrating // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f7c2e0
	void SetBlockingHit(struct FHitResult& HitResult, bool bIsBlocking); // Function AngelscriptCode.AngelscriptHitResultLibrary.SetBlockingHit // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f76230
	void SetbBlockingHit(struct FHitResult& HitResult, bool bIsBlocking); // Function AngelscriptCode.AngelscriptHitResultLibrary.SetbBlockingHit // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f76230
	void SetActor(struct FHitResult& HitResult, struct AActor* Actor); // Function AngelscriptCode.AngelscriptHitResultLibrary.SetActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f77dd0
	void Reset(struct FHitResult& HitResult); // Function AngelscriptCode.AngelscriptHitResultLibrary.Reset // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f7f380
	struct UPhysicalMaterial* GetPhysMaterial(struct FHitResult& HitResult); // Function AngelscriptCode.AngelscriptHitResultLibrary.GetPhysMaterial // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f84fc0
	struct UPrimitiveComponent* GetComponent(struct FHitResult& HitResult); // Function AngelscriptCode.AngelscriptHitResultLibrary.GetComponent // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f82bc0
	bool GetbStartPenetrating(struct FHitResult& HitResult); // Function AngelscriptCode.AngelscriptHitResultLibrary.GetbStartPenetrating // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f85730
	bool GetbBlockingHit(struct FHitResult& HitResult); // Function AngelscriptCode.AngelscriptHitResultLibrary.GetbBlockingHit // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f790f0
	struct AActor* GetActor(struct FHitResult& HitResult); // Function AngelscriptCode.AngelscriptHitResultLibrary.GetActor // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f87120
};

// Class AngelscriptCode.AngelscriptMathLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptMathLibrary : UObject {

	uint32_t WrapUInt(uint32_t X, uint32_t Min, uint32_t Max); // Function AngelscriptCode.AngelscriptMathLibrary.WrapUInt // (Final|Native|Static|Public) // @ game+0x3f7ddd0
	int32_t WrapInt(int32_t X, int32_t Min, int32_t Max); // Function AngelscriptCode.AngelscriptMathLibrary.WrapInt // (Final|Native|Static|Public) // @ game+0x3f79eb0
	uint32_t WrapIndexUInt(uint32_t Value, uint32_t Min, uint32_t Max); // Function AngelscriptCode.AngelscriptMathLibrary.WrapIndexUInt // (Final|Native|Static|Public) // @ game+0x3f7e9b0
	int32_t WrapIndex(int32_t Value, int32_t Min, int32_t Max); // Function AngelscriptCode.AngelscriptMathLibrary.WrapIndex // (Final|Native|Static|Public) // @ game+0x3f833c0
	float WrapFloat(float X, float Min, float Max); // Function AngelscriptCode.AngelscriptMathLibrary.WrapFloat // (Final|Native|Static|Public) // @ game+0x3f7bc80
	double WrapDouble(double X, double Min, double Max); // Function AngelscriptCode.AngelscriptMathLibrary.WrapDouble // (Final|Native|Static|Public) // @ game+0x3f76870
	struct FTransform TInterpTo(struct FTransform& Current, struct FTransform& Target, float DeltaTime, float InterpSpeed); // Function AngelscriptCode.AngelscriptMathLibrary.TInterpTo // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f82d50
	void SinCos_64(double& ScalarSin, double& ScalarCos, double Value); // Function AngelscriptCode.AngelscriptMathLibrary.SinCos_64 // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f78e60
	void SinCos_32(float& ScalarSin, float& ScalarCos, float Value); // Function AngelscriptCode.AngelscriptMathLibrary.SinCos_32 // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f7f610
	struct FRotator RInterpShortestPathTo(struct FRotator& Current, struct FRotator& Target, float DeltaTime, float InterpSpeed); // Function AngelscriptCode.AngelscriptMathLibrary.RInterpShortestPathTo // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f782e0
	struct FRotator RInterpConstantShortestPathTo(struct FRotator& Current, struct FRotator& Target, float DeltaTime, float InterpSpeedDegrees); // Function AngelscriptCode.AngelscriptMathLibrary.RInterpConstantShortestPathTo // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f81f60
	double Modf_64(double InValue, double& OutIntPart); // Function AngelscriptCode.AngelscriptMathLibrary.Modf_64 // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f76130
	float Modf_32(float InValue, float& OutIntPart); // Function AngelscriptCode.AngelscriptMathLibrary.Modf_32 // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f828d0
	bool LineBoxIntersection(struct FBox& Box, struct FVector& Start, struct FVector& End); // Function AngelscriptCode.AngelscriptMathLibrary.LineBoxIntersection // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7a320
	struct FRotator LerpShortestPath(struct FRotator& A, struct FRotator& B, double Alpha); // Function AngelscriptCode.AngelscriptMathLibrary.LerpShortestPath // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f75850
};

// Class AngelscriptCode.AngelscriptFVectorMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFVectorMixinLibrary : UObject {

	struct FString ToColorString(struct FVector& Vector); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.ToColorString // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7b1f0
	double SizeSquared2D(struct FVector& Vector, struct FVector& UpDirection); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.SizeSquared2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80bd0
	double Size2D(struct FVector& Vector, struct FVector& UpDirection); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.Size2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f778a0
	struct FVector PointPlaneProject(struct FVector& Vector, struct FVector& PlaneBase, struct FVector& PlaneNormal); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.PointPlaneProject // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f79480
	struct FVector MoveTowards(struct FVector& Vector, struct FVector& Target, double StepSize); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.MoveTowards // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f83960
	double DistSquared2D(struct FVector& Vector, struct FVector& Other, struct FVector& UpDirection); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.DistSquared2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f84700
	double Dist2D(struct FVector& Vector, struct FVector& Other, struct FVector& UpDirection); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.Dist2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f765f0
	struct FVector ConstrainToPlane(struct FVector& Vector, struct FVector& PlaneUp); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.ConstrainToPlane // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f77c60
	struct FVector ConstrainToDirection(struct FVector& Vector, struct FVector& Direction); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.ConstrainToDirection // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7e670
	double AngularDistanceForNormals(struct FVector& A, struct FVector& B); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.AngularDistanceForNormals // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f84cc0
	double AngularDistance(struct FVector& A, struct FVector& B); // Function AngelscriptCode.AngelscriptFVectorMixinLibrary.AngularDistance // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7e120
};

// Class AngelscriptCode.AngelscriptFVector3fMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFVector3fMixinLibrary : UObject {

	struct FString ToColorString(struct FVector3f& Vector); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.ToColorString // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f869a0
	float SizeSquared2D(struct FVector3f& Vector, struct FVector3f& UpDirection); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.SizeSquared2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f84e50
	float Size2D(struct FVector3f& Vector, struct FVector3f& UpDirection); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.Size2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f84540
	struct FVector3f PointPlaneProject(struct FVector3f& Vector, struct FVector3f& PlaneBase, struct FVector3f& PlaneNormal); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.PointPlaneProject // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7cbe0
	float DistSquared2D(struct FVector3f& Vector, struct FVector3f& Other, struct FVector3f& UpDirection); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.DistSquared2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7c990
	float Dist2D(struct FVector3f& Vector, struct FVector3f& Other, struct FVector3f& UpDirection); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.Dist2D // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7eb70
	struct FVector3f ConstrainToPlane(struct FVector3f& Vector, struct FVector3f& PlaneUp); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.ConstrainToPlane // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7b400
	struct FVector3f ConstrainToDirection(struct FVector3f& Vector, struct FVector3f& Direction); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.ConstrainToDirection // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f77210
	float AngularDistanceForNormals(struct FVector3f& A, struct FVector3f& B); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.AngularDistanceForNormals // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f785d0
	float AngularDistance(struct FVector3f& A, struct FVector3f& B); // Function AngelscriptCode.AngelscriptFVector3fMixinLibrary.AngularDistance // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f85fe0
};

// Class AngelscriptCode.AngelscriptFRotatorLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFRotatorLibrary : UObject {

	struct FRotator MakeFromAxes(struct FVector& Forward, struct FVector& Right, struct FVector& Up); // Function AngelscriptCode.AngelscriptFRotatorLibrary.MakeFromAxes // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7f1b0
	struct FVector GetUpVector(struct FRotator& Rotator); // Function AngelscriptCode.AngelscriptFRotatorLibrary.GetUpVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f76a80
	struct FVector GetRightVector(struct FRotator& Rotator); // Function AngelscriptCode.AngelscriptFRotatorLibrary.GetRightVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f83b80
	struct FVector GetForwardVector(struct FRotator& Rotator); // Function AngelscriptCode.AngelscriptFRotatorLibrary.GetForwardVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f79a00
	struct FRotator Compose(struct FRotator& A, struct FRotator& B); // Function AngelscriptCode.AngelscriptFRotatorLibrary.Compose // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f84a20
};

// Class AngelscriptCode.AngelscriptFRotator3fLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFRotator3fLibrary : UObject {

	struct FRotator3f MakeFromAxes(struct FVector3f& Forward, struct FVector3f& Right, struct FVector3f& Up); // Function AngelscriptCode.AngelscriptFRotator3fLibrary.MakeFromAxes // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f77070
	struct FVector3f GetUpVector(struct FRotator3f& Rotator); // Function AngelscriptCode.AngelscriptFRotator3fLibrary.GetUpVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f83f30
	struct FVector3f GetRightVector(struct FRotator3f& Rotator); // Function AngelscriptCode.AngelscriptFRotator3fLibrary.GetRightVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7c060
	struct FVector3f GetForwardVector(struct FRotator3f& Rotator); // Function AngelscriptCode.AngelscriptFRotator3fLibrary.GetForwardVector // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7c720
	struct FRotator3f Compose(struct FRotator3f& A, struct FRotator3f& B); // Function AngelscriptCode.AngelscriptFRotator3fLibrary.Compose // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7b620
};

// Class AngelscriptCode.AngelscriptFQuatLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFQuatLibrary : UObject {

	struct FQuat MakeFromZY(struct FVector& ZAxis, struct FVector& YAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromZY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f87db0
	struct FQuat MakeFromZX(struct FVector& ZAxis, struct FVector& XAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromZX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7b2d0
	struct FQuat MakeFromZ(struct FVector& ZAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80a80
	struct FQuat MakeFromYZ(struct FVector& YAxis, struct FVector& ZAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromYZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7b9c0
	struct FQuat MakeFromYX(struct FVector& YAxis, struct FVector& XAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromYX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7acb0
	struct FQuat MakeFromY(struct FVector& YAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f853d0
	struct FQuat MakeFromXZ(struct FVector& XAxis, struct FVector& ZAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromXZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f87c80
	struct FQuat MakeFromXY(struct FVector& XAxis, struct FVector& YAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromXY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f77390
	struct FQuat MakeFromX(struct FVector& XAxis); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f86500
	struct FQuat MakeFromAxes(struct FVector& Forward, struct FVector& Right, struct FVector& Up); // Function AngelscriptCode.AngelscriptFQuatLibrary.MakeFromAxes // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f78cf0
};

// Class AngelscriptCode.AngelscriptFQuat4fLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFQuat4fLibrary : UObject {

	struct FQuat4f MakeFromZY(struct FVector3f& ZAxis, struct FVector3f& YAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromZY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f87b10
	struct FQuat4f MakeFromZX(struct FVector3f& ZAxis, struct FVector3f& XAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromZX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f86b10
	struct FQuat4f MakeFromZ(struct FVector3f& ZAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7c230
	struct FQuat4f MakeFromYZ(struct FVector3f& YAxis, struct FVector3f& ZAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromYZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7baf0
	struct FQuat4f MakeFromYX(struct FVector3f& YAxis, struct FVector3f& XAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromYX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7aaa0
	struct FQuat4f MakeFromY(struct FVector3f& YAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f826c0
	struct FQuat4f MakeFromXZ(struct FVector3f& XAxis, struct FVector3f& ZAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromXZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80160
	struct FQuat4f MakeFromXY(struct FVector3f& XAxis, struct FVector3f& YAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromXY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7df70
	struct FQuat4f MakeFromX(struct FVector3f& XAxis); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f82a10
	struct FQuat4f MakeFromAxes(struct FVector3f& Forward, struct FVector3f& Right, struct FVector3f& Up); // Function AngelscriptCode.AngelscriptFQuat4fLibrary.MakeFromAxes // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7bec0
};

// Class AngelscriptCode.AngelscriptFTransformLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFTransformLibrary : UObject {

	struct FRotator TransformRotation(struct FTransform& Transform, struct FRotator& R); // Function AngelscriptCode.AngelscriptFTransformLibrary.TransformRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f81c50
	void SetRotation(struct FTransform& Transform, struct FRotator& NewRotation); // Function AngelscriptCode.AngelscriptFTransformLibrary.SetRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f82770
	struct FTransform MakeFromZY(struct FVector& ZAxis, struct FVector& YAxis); // Function AngelscriptCode.AngelscriptFTransformLibrary.MakeFromZY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7c7e0
	struct FTransform MakeFromZX(struct FVector& ZAxis, struct FVector& XAxis); // Function AngelscriptCode.AngelscriptFTransformLibrary.MakeFromZX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7e7e0
	struct FTransform MakeFromYZ(struct FVector& YAxis, struct FVector& ZAxis); // Function AngelscriptCode.AngelscriptFTransformLibrary.MakeFromYZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f76420
	struct FTransform MakeFromYX(struct FVector& YAxis, struct FVector& XAxis); // Function AngelscriptCode.AngelscriptFTransformLibrary.MakeFromYX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7af70
	struct FTransform MakeFromXZ(struct FVector& XAxis, struct FVector& ZAxis); // Function AngelscriptCode.AngelscriptFTransformLibrary.MakeFromXZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f86c40
	struct FTransform MakeFromXY(struct FVector& XAxis, struct FVector& YAxis); // Function AngelscriptCode.AngelscriptFTransformLibrary.MakeFromXY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f85e70
	struct FRotator InverseTransformRotation(struct FTransform& Transform, struct FRotator& R); // Function AngelscriptCode.AngelscriptFTransformLibrary.InverseTransformRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7a620
	void BlendWith(struct FTransform& Transform, struct FTransform& OtherAtom, double Alpha); // Function AngelscriptCode.AngelscriptFTransformLibrary.BlendWith // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7cdb0
	void Blend(struct FTransform& Transform, struct FTransform& Atom1, struct FTransform& Atom2, double Alpha); // Function AngelscriptCode.AngelscriptFTransformLibrary.Blend // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f787e0
};

// Class AngelscriptCode.AngelscriptFTransform3fLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptFTransform3fLibrary : UObject {

	struct FRotator3f TransformRotation(struct FTransform3f& Transform, struct FRotator3f& R); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.TransformRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80650
	void SetRotation(struct FTransform3f& Transform, struct FRotator3f& NewRotation); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.SetRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7dc30
	struct FTransform3f MakeFromZY(struct FVector3f& ZAxis, struct FVector3f& YAxis); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.MakeFromZY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f81940
	struct FTransform3f MakeFromZX(struct FVector3f& ZAxis, struct FVector3f& XAxis); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.MakeFromZX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f774c0
	struct FTransform3f MakeFromYZ(struct FVector3f& YAxis, struct FVector3f& ZAxis); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.MakeFromYZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f7a8a0
	struct FTransform3f MakeFromYX(struct FVector3f& YAxis, struct FVector3f& XAxis); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.MakeFromYX // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80d90
	struct FTransform3f MakeFromXZ(struct FVector3f& XAxis, struct FVector3f& ZAxis); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.MakeFromXZ // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80010
	struct FTransform3f MakeFromXY(struct FVector3f& XAxis, struct FVector3f& YAxis); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.MakeFromXY // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f75fb0
	struct FRotator3f InverseTransformRotation(struct FTransform3f& Transform, struct FRotator3f& R); // Function AngelscriptCode.AngelscriptFTransform3fLibrary.InverseTransformRotation // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3f80840
};

// Class AngelscriptCode.AngelscriptSettings
// Size: 0x110 (Inherited: 0xa0)
struct UAngelscriptSettings : UObject {
	struct TArray<struct FString> PreprocessorFlags; // 0x98(0x10)
	struct TArray<struct FString> BannedPreprocessorFlags; // 0xa8(0x10)
	bool bAllowImplicitPropertyAccessors; // 0xb8(0x01)
	bool bAutomaticImports; // 0xb9(0x01)
	bool bWarnOnManualImportStatements; // 0xba(0x01)
	enum class EAngelscriptMathNamespace MathNamespace; // 0xbb(0x01)
	bool bDefaultFunctionBlueprintCallable; // 0xbc(0x01)
	enum class EAngelscriptPropertyEditSpecifier DefaultPropertyEditSpecifier; // 0xbd(0x01)
	enum class EAngelscriptPropertyEditSpecifier DefaultPropertyEditSpecifierForStructs; // 0xbe(0x01)
	enum class EAngelscriptPropertyBlueprintSpecifier DefaultPropertyBlueprintSpecifier; // 0xbf(0x01)
	bool bMarkNonUpropertyPropertiesAsTransient; // 0xc0(0x01)
	enum class EAngelscriptStaticClassMode StaticClassDeprecation; // 0xc1(0x01)
	bool bUseScriptNameForBlueprintLibraryNamespaces; // 0xc2(0x01)
	bool bAllowRawConstructorsForComponentsAndActors; // 0xc3(0x01)
	bool bForceConstWithinDevelopmentOnlyFunctions; // 0xc4(0x01)
	struct TArray<struct FString> BlueprintLibraryNamespacePrefixesToStrip; // 0xc8(0x10)
	struct TArray<struct FString> BlueprintLibraryNamespaceSuffixesToStrip; // 0xd8(0x10)
	float EditorMaximumScriptExecutionTime; // 0xe8(0x04)
	bool bScriptFloatIsFloat64; // 0xec(0x01)
	bool bDeprecateDoubleType; // 0xed(0x01)
	bool bWarnOnFloatConstantsForDoubleValues; // 0xee(0x01)
	bool bWarnIntegerDivision; // 0xef(0x01)
	bool bErrorWhenUsingInvalidWorldContext; // 0xf0(0x01)
	bool bAllowCDOAsWorldContext; // 0xf1(0x01)
	bool bWarnOnUnusedReturnValueForConstMethods; // 0xf2(0x01)
	bool bWarnOnImplicitSignedUnsignedConversion; // 0xf3(0x01)
	bool bErrorOnIncorrectEditorOnlyCode; // 0xf4(0x01)
	bool bWarnOnDivergentComparisonOperatorOverloads; // 0xf5(0x01)
	bool bWarnOnIncrementDecrementInComplexExpression; // 0xf6(0x01)
	struct TArray<struct FName> AdditionalEditorOnlyScriptPackageNames; // 0xf8(0x10)
	bool bRuntimeModifiableEditProperties; // 0x108(0x01)
	char pad_10d[0x3]; // 0x10d(0x03)
};

// Class AngelscriptCode.AngelscriptTestCommandlet
// Size: 0xf0 (Inherited: 0xf0)
struct UAngelscriptTestCommandlet : UCommandlet {
};

// Class AngelscriptCode.AngelscriptTestUserSettings
// Size: 0xb0 (Inherited: 0xb0)
struct UAngelscriptTestUserSettings : UDeveloperSettings {
	bool bRunUnitTestsOnHotReload; // 0xa8(0x01)
	int32_t LimitNModulesToTestOnHotReload; // 0xac(0x04)
};

// Class AngelscriptCode.AngelscriptTestSettings
// Size: 0x180 (Inherited: 0xb0)
struct UAngelscriptTestSettings : UDeveloperSettings {
	bool bEnableTestDiscovery; // 0xa8(0x01)
	struct FString IntegrationTestMapRoot; // 0xb0(0x10)
	int32_t GarbageCollectEveryNTests; // 0xc0(0x04)
	char pad_c5[0x3]; // 0xc5(0x03)
	struct TSoftClassPtr<UObject> UnitTestGameInstanceClass; // 0xc8(0x28)
	bool bEnableCodeCoverage; // 0xf0(0x01)
	char pad_f1[0x7]; // 0xf1(0x07)
	struct TArray<struct FString> CoverageExcludePatterns; // 0xf8(0x10)
	bool bEnableDebugBreaksInTests; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FString IntegrationTestNamingConvention; // 0x110(0x10)
	struct FString UnitTestNamingConvention; // 0x120(0x10)
	char pad_130[0x10]; // 0x130(0x10)
	float DefaultSessionTestTimeout; // 0x140(0x04)
	char pad_144[0x4]; // 0x144(0x04)
	struct FString SessionTestMapRoot; // 0x148(0x10)
	bool bEnableNetworkEmulation; // 0x158(0x01)
	char pad_159[0x3]; // 0x159(0x03)
	int32_t InPacketsMinLatency; // 0x15c(0x04)
	int32_t InPacketsMaxLatency; // 0x160(0x04)
	int32_t InPacketsPacketLossPercentage; // 0x164(0x04)
	int32_t OutPacketsMinLatency; // 0x168(0x04)
	int32_t OutPacketsMaxLatency; // 0x16c(0x04)
	int32_t OutPacketsPacketLossPercentage; // 0x170(0x04)
	char pad_174[0xc]; // 0x174(0x0c)
};

// Class AngelscriptCode.AngelscriptWorldLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptWorldLibrary : UObject {

	struct TArray<struct ULevelStreaming*> GetStreamingLevels(struct UWorld* World); // Function AngelscriptCode.AngelscriptWorldLibrary.GetStreamingLevels // (Final|Native|Static|Public) // @ game+0x3f8ba80
};

// Class AngelscriptCode.ASClass
// Size: 0x350 (Inherited: 0x2f0)
struct UASClass : UClass {
	char pad_2f0[0x60]; // 0x2f0(0x60)

	bool IsDeveloperOnly(); // Function AngelscriptCode.ASClass.IsDeveloperOnly // (Final|Native|Public|Const) // @ game+0x3f8ba50
	struct FString GetSourceFilePath(); // Function AngelscriptCode.ASClass.GetSourceFilePath // (Final|Native|Public|Const) // @ game+0x3f89500
	struct FString GetRelativeSourceFilePath(); // Function AngelscriptCode.ASClass.GetRelativeSourceFilePath // (Final|Native|Public|Const) // @ game+0x3f8df50
};

// Class AngelscriptCode.ASFunction
// Size: 0x210 (Inherited: 0x160)
struct UASFunction : UFunction {
	char pad_160[0xb0]; // 0x160(0xb0)
};

// Class AngelscriptCode.ASFunction_NotThreadSafe
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_NotThreadSafe : UASFunction {
};

// Class AngelscriptCode.ASFunction_NoParams
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_NoParams : UASFunction {
};

// Class AngelscriptCode.ASFunction_DWordArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DWordArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_QWordArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_QWordArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatExtendedToDoubleArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatExtendedToDoubleArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatExtendedToDoubleReturn
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatExtendedToDoubleReturn : UASFunction {
};

// Class AngelscriptCode.ASFunction_DoubleArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DoubleArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_ByteArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ByteArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_ReferenceArg
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ReferenceArg : UASFunction {
};

// Class AngelscriptCode.ASFunction_ObjectReturn
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ObjectReturn : UASFunction {
};

// Class AngelscriptCode.ASFunction_DWordReturn
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DWordReturn : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatReturn
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatReturn : UASFunction {
};

// Class AngelscriptCode.ASFunction_DoubleReturn
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DoubleReturn : UASFunction {
};

// Class AngelscriptCode.ASFunction_ByteReturn
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ByteReturn : UASFunction {
};

// Class AngelscriptCode.ASFunction_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_NotThreadSafe_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_NotThreadSafe_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_NoParams_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_NoParams_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_DWordArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DWordArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_QWordArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_QWordArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatExtendedToDoubleArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatExtendedToDoubleArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatExtendedToDoubleReturn_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatExtendedToDoubleReturn_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_DoubleArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DoubleArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_ByteArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ByteArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_ReferenceArg_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ReferenceArg_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_ObjectReturn_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ObjectReturn_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_DWordReturn_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DWordReturn_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_FloatReturn_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_FloatReturn_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_DoubleReturn_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_DoubleReturn_JIT : UASFunction {
};

// Class AngelscriptCode.ASFunction_ByteReturn_JIT
// Size: 0x210 (Inherited: 0x210)
struct UASFunction_ByteReturn_JIT : UASFunction {
};

// Class AngelscriptCode.ASStruct
// Size: 0x160 (Inherited: 0x140)
struct UASStruct : UScriptStruct {
	char pad_140[0x20]; // 0x140(0x20)
};

// Class AngelscriptCode.FakeNetDriver
// Size: 0x840 (Inherited: 0x840)
struct UFakeNetDriver : UNetDriver {
};

// Class AngelscriptCode.GameplayLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayLibrary : UObject {

	void AsyncSaveGameToSlot(struct USaveGame* SaveGameObject, struct FString SlotName, int32_t UserIndex, struct FDelegate Delegate); // Function AngelscriptCode.GameplayLibrary.AsyncSaveGameToSlot // (Final|Native|Static|Public) // @ game+0x3f89b90
	void AsyncLoadGameFromSlot(struct FString SlotName, int32_t UserIndex, struct FDelegate Delegate); // Function AngelscriptCode.GameplayLibrary.AsyncLoadGameFromSlot // (Final|Native|Static|Public) // @ game+0x3f8ca30
};

// Class AngelscriptCode.GameplayTagContainerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayTagContainerMixinLibrary : UObject {

	void RemoveTags(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer TagsToRemove); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.RemoveTags // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f88db0
	bool RemoveTag(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTag& TagToRemove); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.RemoveTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f925d0
	int32_t Num(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.Num // (Final|Native|Static|Public|HasOutParms) // @ game+0x2aff900
	bool MatchesQuery(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagQuery& Query); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.MatchesQuery // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f90e90
	struct FGameplayTag Last(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.Last // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f923d0
	bool IsValid(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f915d0
	bool IsEmpty(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.IsEmpty // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f913d0
	bool HasTagExact(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTag& TagToCheck); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.HasTagExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f91a60
	bool HasTag(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTag& TagToCheck); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.HasTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8bbf0
	bool HasAnyExact(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer& ContainerToCheck); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.HasAnyExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f91c00
	bool HasAny(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer& ContainerToCheck); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.HasAny // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f880e0
	bool HasAllExact(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer& ContainerToCheck); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.HasAllExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f905c0
	bool HasAll(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer& ContainerToCheck); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.HasAll // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8e840
	struct FGameplayTagContainer GetGameplayTagParents(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.GetGameplayTagParents // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8de50
	struct FGameplayTag First(struct FGameplayTagContainer& GameplayTagContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.First // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8be80
	struct FGameplayTagContainer FilterExact(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer& OtherContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.FilterExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8ef80
	struct FGameplayTagContainer Filter(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTagContainer& OtherContainer); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.Filter // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8f210
	void AddTagFast(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTag& TagToAdd); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.AddTagFast // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8cf10
	void AddTag(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTag& TagToAdd); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.AddTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f90980
	void AddLeafTag(struct FGameplayTagContainer& GameplayTagContainer, struct FGameplayTag& TagToAdd); // Function AngelscriptCode.GameplayTagContainerMixinLibrary.AddLeafTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f8fd60
};

// Class AngelscriptCode.GameplayTagMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayTagMixinLibrary : UObject {

	struct FGameplayTag RequestDirectParent(struct FGameplayTag& GameplayTag); // Function AngelscriptCode.GameplayTagMixinLibrary.RequestDirectParent // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f93850
	bool MatchesTagExact(struct FGameplayTag& GameplayTag, struct FGameplayTag& TagToCheck); // Function AngelscriptCode.GameplayTagMixinLibrary.MatchesTagExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f93910
	int32_t MatchesTagDepth(struct FGameplayTag& GameplayTag, struct FGameplayTag& TagToCheck); // Function AngelscriptCode.GameplayTagMixinLibrary.MatchesTagDepth // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f96710
	bool MatchesTag(struct FGameplayTag& GameplayTag, struct FGameplayTag& TagToCheck); // Function AngelscriptCode.GameplayTagMixinLibrary.MatchesTag // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f96270
	bool MatchesAnyExact(struct FGameplayTag& GameplayTag, struct FGameplayTagContainer& ContainerToCheck); // Function AngelscriptCode.GameplayTagMixinLibrary.MatchesAnyExact // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f98ab0
	bool MatchesAny(struct FGameplayTag& GameplayTag, struct FGameplayTagContainer& ContainerToCheck); // Function AngelscriptCode.GameplayTagMixinLibrary.MatchesAny // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f98070
	bool IsValid(struct FGameplayTag& GameplayTag); // Function AngelscriptCode.GameplayTagMixinLibrary.IsValid // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9acf0
	struct FGameplayTagContainer GetSingleTagContainer(struct FGameplayTag& GameplayTag); // Function AngelscriptCode.GameplayTagMixinLibrary.GetSingleTagContainer // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f96e30
	struct FGameplayTagContainer GetGameplayTagParents(struct FGameplayTag& GameplayTag); // Function AngelscriptCode.GameplayTagMixinLibrary.GetGameplayTagParents // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f957c0
};

// Class AngelscriptCode.GameplayTagQueryMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UGameplayTagQueryMixinLibrary : UObject {

	bool Matches(struct FGameplayTagQuery& GameplayTagQuery, struct FGameplayTagContainer& Tags); // Function AngelscriptCode.GameplayTagQueryMixinLibrary.Matches // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9c080
	bool IsEmpty(struct FGameplayTagQuery& GameplayTagQuery); // Function AngelscriptCode.GameplayTagQueryMixinLibrary.IsEmpty // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9bb10
	struct FString GetDescription(struct FGameplayTagQuery& GameplayTagQuery); // Function AngelscriptCode.GameplayTagQueryMixinLibrary.GetDescription // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f92d00
};

// Class AngelscriptCode.InputComponentScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UInputComponentScriptMixinLibrary : UObject {

	void RemoveActionBindingForHandle(struct UInputComponent* Component, int32_t Handle); // Function AngelscriptCode.InputComponentScriptMixinLibrary.RemoveActionBindingForHandle // (Final|Native|Static|Public) // @ game+0x3f98640
	void RemoveAction(struct UInputComponent* Component, struct FName& ActionName, enum class EInputEvent KeyEvent); // Function AngelscriptCode.InputComponentScriptMixinLibrary.RemoveAction // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9c390
	void BindVectorAxis(struct UInputComponent* Component, struct FKey& AxisKey, struct FDelegate& Delegate); // Function AngelscriptCode.InputComponentScriptMixinLibrary.BindVectorAxis // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f98740
	void BindKey(struct UInputComponent* Component, struct FKey& Key, enum class EInputEvent KeyEvent, struct FDelegate& Delegate, bool bConsumeInput); // Function AngelscriptCode.InputComponentScriptMixinLibrary.BindKey // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9bc40
	void BindChord(struct UInputComponent* Component, struct FInputChord& Chord, enum class EInputEvent KeyEvent, struct FDelegate& Delegate); // Function AngelscriptCode.InputComponentScriptMixinLibrary.BindChord // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f96f20
	void BindAxisKey(struct UInputComponent* Component, struct FName& AxisKey, struct FDelegate& Delegate, bool bConsumeInput); // Function AngelscriptCode.InputComponentScriptMixinLibrary.BindAxisKey // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f93c10
	void BindAxis(struct UInputComponent* Component, struct FName& AxisName, struct FDelegate& Delegate, bool bConsumeInput); // Function AngelscriptCode.InputComponentScriptMixinLibrary.BindAxis // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f935e0
	int32_t BindAction(struct UInputComponent* Component, struct FName& ActionName, enum class EInputEvent KeyEvent, struct FDelegate& Delegate, bool bConsumeInput); // Function AngelscriptCode.InputComponentScriptMixinLibrary.BindAction // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9a1b0
};

// Class AngelscriptCode.ControllerInputScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UControllerInputScriptMixinLibrary : UObject {

	void PushInputComponent(struct AController* Controller, struct UInputComponent* Component); // Function AngelscriptCode.ControllerInputScriptMixinLibrary.PushInputComponent // (Final|Native|Static|Public) // @ game+0x3f9b590
	void PopInputComponent(struct AController* Controller, struct UInputComponent* Component); // Function AngelscriptCode.ControllerInputScriptMixinLibrary.PopInputComponent // (Final|Native|Static|Public) // @ game+0x3f93e00
};

// Class AngelscriptCode.PlayerControllerInputScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerControllerInputScriptMixinLibrary : UObject {

	struct UPlayerInput* GetPlayerInput(struct APlayerController* PlayerController); // Function AngelscriptCode.PlayerControllerInputScriptMixinLibrary.GetPlayerInput // (Final|Native|Static|Public) // @ game+0x3f969a0
};

// Class AngelscriptCode.PlayerInputScriptMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UPlayerInputScriptMixinLibrary : UObject {

	void SetMouseSensitivity(struct UPlayerInput* PlayerInput, float Sensitivity); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.SetMouseSensitivity // (Final|Native|Static|Public) // @ game+0x3f98370
	void RemoveAxisMapping(struct UPlayerInput* PlayerInput, struct FInputAxisKeyMapping& KeyMapping); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.RemoveAxisMapping // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f95c30
	void RemoveActionMapping(struct UPlayerInput* PlayerInput, struct FInputActionKeyMapping& KeyMapping); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.RemoveActionMapping // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f99590
	void InvertAxis(struct UPlayerInput* PlayerInput, struct FName AxisName); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.InvertAxis // (Final|Native|Static|Public) // @ game+0x3f96390
	float GetMouseSensitivityY(struct UPlayerInput* PlayerInput); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.GetMouseSensitivityY // (Final|Native|Static|Public) // @ game+0x3f976a0
	float GetMouseSensitivityX(struct UPlayerInput* PlayerInput); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.GetMouseSensitivityX // (Final|Native|Static|Public) // @ game+0x3f95160
	struct TArray<struct FInputAxisKeyMapping> GetKeysForAxis(struct UPlayerInput* PlayerInput, struct FName AxisName); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.GetKeysForAxis // (Final|Native|Static|Public) // @ game+0x3f9a490
	struct TArray<struct FInputActionKeyMapping> GetKeysForAction(struct UPlayerInput* PlayerInput, struct FName ActionName); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.GetKeysForAction // (Final|Native|Static|Public) // @ game+0x3f95ae0
	struct TArray<struct FInputAxisKeyMapping> GetEngineDefinedAxisMappings(struct UPlayerInput* PlayerInput, struct FName AxisName); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.GetEngineDefinedAxisMappings // (Final|Native|Static|Public) // @ game+0x3f931c0
	struct TArray<struct FInputActionKeyMapping> GetEngineDefinedActionMappings(struct UPlayerInput* PlayerInput, struct FName ActionName); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.GetEngineDefinedActionMappings // (Final|Native|Static|Public) // @ game+0x3f9b840
	void ForceRebuildingKeyMaps(struct UPlayerInput* PlayerInput, bool bRestoreDefaults); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.ForceRebuildingKeyMaps // (Final|Native|Static|Public) // @ game+0x3f96590
	void AddAxisMapping(struct UPlayerInput* PlayerInput, struct FInputAxisKeyMapping& KeyMapping); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.AddAxisMapping // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f94fb0
	void AddActionMapping(struct UPlayerInput* PlayerInput, struct FInputActionKeyMapping& KeyMapping); // Function AngelscriptCode.PlayerInputScriptMixinLibrary.AddActionMapping // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f94cf0
};

// Class AngelscriptCode.TestTerminatorComponent
// Size: 0x160 (Inherited: 0x160)
struct UTestTerminatorComponent : UActorComponent {

	void ServerTerminatorReplicated(); // Function AngelscriptCode.TestTerminatorComponent.ServerTerminatorReplicated // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x3a6dae0
};

// Class AngelscriptCode.TestTerminator
// Size: 0x3b0 (Inherited: 0x3a0)
struct ATestTerminator : AActor {
	char pad_3a0[0x10]; // 0x3a0(0x10)
};

// Class AngelscriptCode.LatentAutomationCommand
// Size: 0xc0 (Inherited: 0xa0)
struct ULatentAutomationCommand : UObject {
	struct UWorld* World; // 0x98(0x08)
	bool bAllowTimeout; // 0xa0(0x01)
	bool bAlsoRunOnClient; // 0xa1(0x01)
	char pad_aa[0x16]; // 0xaa(0x16)

	bool UpdateOnClient(); // Function AngelscriptCode.LatentAutomationCommand.UpdateOnClient // (Native|Event|Public|BlueprintEvent) // @ game+0x3acf850
	bool Update(); // Function AngelscriptCode.LatentAutomationCommand.Update // (Native|Event|Public|BlueprintEvent) // @ game+0x29eeb30
	bool HasAuthority(); // Function AngelscriptCode.LatentAutomationCommand.HasAuthority // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f954d0
	struct FString DescribeOnClient(); // Function AngelscriptCode.LatentAutomationCommand.DescribeOnClient // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	struct FString Describe(); // Function AngelscriptCode.LatentAutomationCommand.Describe // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
	bool BeforeOnClient(); // Function AngelscriptCode.LatentAutomationCommand.BeforeOnClient // (Native|Event|Public|BlueprintEvent) // @ game+0x2b960b0
	void Before(); // Function AngelscriptCode.LatentAutomationCommand.Before // (Native|Event|Public|BlueprintEvent) // @ game+0x2cd47f0
	bool AfterOnClient(); // Function AngelscriptCode.LatentAutomationCommand.AfterOnClient // (Native|Event|Public|BlueprintEvent) // @ game+0x3247a90
	void After(); // Function AngelscriptCode.LatentAutomationCommand.After // (Native|Event|Public|BlueprintEvent) // @ game+0x2b96540
};

// Class AngelscriptCode.LatentAutomationCommandClientExecutor
// Size: 0x3c0 (Inherited: 0x3a0)
struct ALatentAutomationCommandClientExecutor : AActor {
	char pad_3a0[0x10]; // 0x3a0(0x10)
	struct ULatentAutomationCommand* LatentCommand; // 0x3b0(0x08)
	bool bCanStartBefore; // 0x3b8(0x01)
	bool bCanStartUpdate; // 0x3b9(0x01)
	bool bCanStartAfter; // 0x3ba(0x01)
	char pad_3bb[0x5]; // 0x3bb(0x05)

	void ServerLatentCommandDescribeOnClient(struct FString NewDescription); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerLatentCommandDescribeOnClient // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f93a30
	void ServerLatentCommandClientReady(); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerLatentCommandClientReady // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2c7fe60
	void ServerLatentCommandClientDone(); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerLatentCommandClientDone // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2c9af60
	void ServerLatentCommandClientChecked(); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerLatentCommandClientChecked // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x2c83ad0
	void ServerFail(struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerFail // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f98a00
	void ServerAssertTrue(bool bExpression, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerAssertTrue // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f99400
	void ServerAssertSame(struct UObject* Expected, struct UObject* Actual, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerAssertSame // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f95980
	void ServerAssertNull(struct UObject* Object, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerAssertNull // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f99e80
	void ServerAssertNotSame(struct UObject* Expected, struct UObject* Actual, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerAssertNotSame // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f95320
	void ServerAssertNotNull(struct UObject* Object, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerAssertNotNull // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f99860
	void ServerAssertFalse(bool bExpression, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.ServerAssertFalse // (Final|Net|NetReliableNative|Event|Private|NetServer) // @ game+0x3f93400
	void Fail(struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.Fail // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9b790
	void AssertTrue(bool bExpression, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.AssertTrue // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9b950
	void AssertSame(struct UObject* Expected, struct UObject* Actual, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.AssertSame // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9b270
	void AssertNull(struct UObject* Object, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.AssertNull // (Final|Native|Public|BlueprintCallable) // @ game+0x3f92ff0
	void AssertNotSame(struct UObject* Expected, struct UObject* Actual, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.AssertNotSame // (Final|Native|Public|BlueprintCallable) // @ game+0x3f990f0
	void AssertNotNull(struct UObject* Object, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.AssertNotNull // (Final|Native|Public|BlueprintCallable) // @ game+0x3f96170
	void AssertFalse(bool bExpression, struct FString Message); // Function AngelscriptCode.LatentAutomationCommandClientExecutor.AssertFalse // (Final|Native|Public|BlueprintCallable) // @ game+0x3f95210
};

// Class AngelscriptCode.RuntimeFloatCurveMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct URuntimeFloatCurveMixinLibrary : UObject {

	void SetPreInfinityExtrap(struct UCurveFloat* Curve, enum class ERichCurveExtrapolation Extrapolation); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetPreInfinityExtrap // (Final|Native|Static|Public) // @ game+0x3fa5510
	void SetPostInfinityExtrap(struct UCurveFloat* Curve, enum class ERichCurveExtrapolation Extrapolation); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetPostInfinityExtrap // (Final|Native|Static|Public) // @ game+0x3fa1970
	void SetKeyUserTangentWeights(struct UCurveFloat* Curve, struct FCurveKeyHandle KeyHandle, float ArriveTangentWeight, float LeaveTangentWeight); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetKeyUserTangentWeights // (Final|Native|Static|Public) // @ game+0x3fa98d0
	void SetKeyUserTangents(struct UCurveFloat* Curve, struct FCurveKeyHandle KeyHandle, float ArriveTangent, float LeaveTangent); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetKeyUserTangents // (Final|Native|Static|Public) // @ game+0x3f9fc30
	void SetKeyTangentWeightMode(struct UCurveFloat* Curve, struct FCurveKeyHandle KeyHandle, enum class ERichCurveTangentWeightMode NewTangentWeightMode, bool bAutoSetTangents); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetKeyTangentWeightMode // (Final|Native|Static|Public) // @ game+0x3fa5170
	void SetKeyTangentMode(struct UCurveFloat* Curve, struct FCurveKeyHandle KeyHandle, enum class ERichCurveTangentMode NewTangentMode, bool bAutoSetTangents); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetKeyTangentMode // (Final|Native|Static|Public) // @ game+0x3fa03f0
	void SetKeyInterpMode(struct UCurveFloat* Curve, struct FCurveKeyHandle KeyHandle, enum class ERichCurveInterpMode NewInterpMode, bool bAutoSetTangents); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetKeyInterpMode // (Final|Native|Static|Public) // @ game+0x3faa190
	void SetDefaultValue(struct UCurveFloat* Curve, float DefaultValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.SetDefaultValue // (Final|Native|Static|Public) // @ game+0x3f9cd20
	void GetValueRange_Double(struct FRuntimeFloatCurve& Target, double& MinValue, double& MaxValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.GetValueRange_Double // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9c860
	void GetValueRange(struct FRuntimeFloatCurve& Target, float& MinValue, float& MaxValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.GetValueRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fa05a0
	void GetTimeRange_Double(struct FRuntimeFloatCurve& Target, double& MinTime, double& MaxTime); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.GetTimeRange_Double // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9e6e0
	void GetTimeRange(struct FRuntimeFloatCurve& Target, float& MinTime, float& MaxTime); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.GetTimeRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fa7850
	int32_t GetNumKeys(struct FRuntimeFloatCurve& Target); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.GetNumKeys // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fa6af0
	float GetFloatValue(struct FRuntimeFloatCurve& Target, float InTime, float DefaultValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.GetFloatValue // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9c560
	bool Equals(struct FRuntimeFloatCurve& Target, struct FRuntimeFloatCurve& Other); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.Equals // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fa4dc0
	void AutoSetTangents(struct UCurveFloat* Curve); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AutoSetTangents // (Final|Native|Static|Public) // @ game+0x3fa9360
	struct FCurveKeyHandle AddSmartAutoCurveKey(struct UCurveFloat* Curve, float InTime, float InValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddSmartAutoCurveKey // (Final|Native|Static|Public) // @ game+0x3fa8eb0
	struct FCurveKeyHandle AddLinearCurveKey(struct UCurveFloat* Curve, float InTime, float InValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddLinearCurveKey // (Final|Native|Static|Public) // @ game+0x3f9e380
	void AddDefaultKey(struct FRuntimeFloatCurve& Target, float InTime, float InValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddDefaultKey // (Final|Native|Static|Public|HasOutParms) // @ game+0x3f9f780
	struct FCurveKeyHandle AddCurveKeyWeightedLeaveTangent(struct UCurveFloat* Curve, float InTime, float InValue, bool bBrokenTangent, float ArriveTangent, float LeaveTangent, float ArriveTangentWeight, float LeaveTangentWeight); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddCurveKeyWeightedLeaveTangent // (Final|Native|Static|Public) // @ game+0x3fa25c0
	struct FCurveKeyHandle AddCurveKeyWeightedBothTangent(struct UCurveFloat* Curve, float InTime, float InValue, bool bBrokenTangent, float ArriveTangent, float LeaveTangent, float ArriveTangentWeight, float LeaveTangentWeight); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddCurveKeyWeightedBothTangent // (Final|Native|Static|Public) // @ game+0x3f9ce60
	struct FCurveKeyHandle AddCurveKeyWeightedArriveTangent(struct UCurveFloat* Curve, float InTime, float InValue, bool bBrokenTangent, float ArriveTangent, float LeaveTangent, float ArriveTangentWeight, float LeaveTangentWeight); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddCurveKeyWeightedArriveTangent // (Final|Native|Static|Public) // @ game+0x3fa5600
	struct FCurveKeyHandle AddCurveKeyTangent(struct UCurveFloat* Curve, float InTime, float InValue, float Tangent); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddCurveKeyTangent // (Final|Native|Static|Public) // @ game+0x3f9f410
	struct FCurveKeyHandle AddCurveKeyBrokenTangent(struct UCurveFloat* Curve, float InTime, float InValue, float ArriveTangent, float LeaveTangent); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddCurveKeyBrokenTangent // (Final|Native|Static|Public) // @ game+0x3fa7ac0
	struct FCurveKeyHandle AddCurveKey(struct UCurveFloat* Curve, float InTime, float InValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddCurveKey // (Final|Native|Static|Public) // @ game+0x3f9e380
	struct FCurveKeyHandle AddConstantCurveKey(struct UCurveFloat* Curve, float InTime, float InValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddConstantCurveKey // (Final|Native|Static|Public) // @ game+0x3fa12c0
	struct FCurveKeyHandle AddAutoCurveKey(struct UCurveFloat* Curve, float InTime, float InValue); // Function AngelscriptCode.RuntimeFloatCurveMixinLibrary.AddAutoCurveKey // (Final|Native|Static|Public) // @ game+0x3f9f0a0
};

// Class AngelscriptCode.RuntimeVectorCurveMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct URuntimeVectorCurveMixinLibrary : UObject {

	void GetValueRange(struct FRuntimeVectorCurve& Target, struct FVector& MinValue, struct FVector& MaxValue); // Function AngelscriptCode.RuntimeVectorCurveMixinLibrary.GetValueRange // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fa3870
	struct FVector GetValue(struct FRuntimeVectorCurve& Target, float InTime, struct FVector DefaultValue); // Function AngelscriptCode.RuntimeVectorCurveMixinLibrary.GetValue // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fa0030
	void GetTimeRange(struct FRuntimeVectorCurve& Target, float& MinTime, float& MaxTime); // Function AngelscriptCode.RuntimeVectorCurveMixinLibrary.GetTimeRange // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fa6140
	void AddDefaultKey(struct FRuntimeVectorCurve& Target, float InTime, struct FVector& InValue); // Function AngelscriptCode.RuntimeVectorCurveMixinLibrary.AddDefaultKey // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fa6e70
};

// Class AngelscriptCode.ScriptEngineSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UScriptEngineSubsystem : UEngineSubsystem {
	char pad_a0[0x8]; // 0xa0(0x08)
	bool bIsTickableWhenPaused; // 0xa8(0x01)
	bool bIsTickableInEditor; // 0xa9(0x01)
	char pad_aa[0x6]; // 0xaa(0x06)

	void BP_Tick(float DeltaTime); // Function AngelscriptCode.ScriptEngineSubsystem.BP_Tick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool BP_ShouldCreateSubsystem(struct UObject* Outer); // Function AngelscriptCode.ScriptEngineSubsystem.BP_ShouldCreateSubsystem // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3f9ca30
	void BP_Initialize(); // Function AngelscriptCode.ScriptEngineSubsystem.BP_Initialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_Deinitialize(); // Function AngelscriptCode.ScriptEngineSubsystem.BP_Deinitialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptCode.ScriptGameInstanceSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UScriptGameInstanceSubsystem : UGameInstanceSubsystem {
	char pad_a0[0x10]; // 0xa0(0x10)

	void BP_Tick(float DeltaTime); // Function AngelscriptCode.ScriptGameInstanceSubsystem.BP_Tick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool BP_ShouldCreateSubsystem(struct UObject* Outer); // Function AngelscriptCode.ScriptGameInstanceSubsystem.BP_ShouldCreateSubsystem // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3f9ca30
	void BP_Initialize(); // Function AngelscriptCode.ScriptGameInstanceSubsystem.BP_Initialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct UGameInstance* BP_GetGameInstance(); // Function AngelscriptCode.ScriptGameInstanceSubsystem.BP_GetGameInstance // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa23f0
	void BP_Deinitialize(); // Function AngelscriptCode.ScriptGameInstanceSubsystem.BP_Deinitialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptCode.ScriptLocalPlayerSubsystem
// Size: 0xa0 (Inherited: 0xa0)
struct UScriptLocalPlayerSubsystem : ULocalPlayerSubsystem {

	bool BP_ShouldCreateSubsystem(struct UObject* Outer); // Function AngelscriptCode.ScriptLocalPlayerSubsystem.BP_ShouldCreateSubsystem // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3f9ca30
	void BP_PlayerControllerChanged(struct APlayerController* NewPlayerController); // Function AngelscriptCode.ScriptLocalPlayerSubsystem.BP_PlayerControllerChanged // (Native|Event|Public|BlueprintEvent) // @ game+0x257bb60
	void BP_Initialize(); // Function AngelscriptCode.ScriptLocalPlayerSubsystem.BP_Initialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	struct ULocalPlayer* BP_GetLocalPlayer(); // Function AngelscriptCode.ScriptLocalPlayerSubsystem.BP_GetLocalPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f9ee70
	void BP_Deinitialize(); // Function AngelscriptCode.ScriptLocalPlayerSubsystem.BP_Deinitialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptCode.ScriptWorldSubsystem
// Size: 0xb0 (Inherited: 0xa0)
struct UScriptWorldSubsystem : UWorldSubsystem {
	char pad_a0[0x9]; // 0xa0(0x09)
	bool bCreateForLevelEditorWorlds; // 0xa9(0x01)
	bool bCreateForGameWorlds; // 0xaa(0x01)
	bool bTickWhenPaused; // 0xab(0x01)
	char pad_ac[0x4]; // 0xac(0x04)

	void BP_UpdateStreamingState(); // Function AngelscriptCode.ScriptWorldSubsystem.BP_UpdateStreamingState // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_Tick(float DeltaTime); // Function AngelscriptCode.ScriptWorldSubsystem.BP_Tick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool BP_ShouldCreateSubsystem(struct UObject* Outer); // Function AngelscriptCode.ScriptWorldSubsystem.BP_ShouldCreateSubsystem // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x3f9ca30
	void BP_PostInitialize(); // Function AngelscriptCode.ScriptWorldSubsystem.BP_PostInitialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnWorldComponentsUpdated(); // Function AngelscriptCode.ScriptWorldSubsystem.BP_OnWorldComponentsUpdated // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_OnWorldBeginPlay(); // Function AngelscriptCode.ScriptWorldSubsystem.BP_OnWorldBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_Initialize(); // Function AngelscriptCode.ScriptWorldSubsystem.BP_Initialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void BP_Deinitialize(); // Function AngelscriptCode.ScriptWorldSubsystem.BP_Deinitialize // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptCode.SessionTestCase
// Size: 0x140 (Inherited: 0xa0)
struct USessionTestCase : UObject {
	struct FString MapName; // 0x98(0x10)
	struct FString Description; // 0xa8(0x10)
	struct FString Tags; // 0xb8(0x10)
	float TimeoutSeconds; // 0xc8(0x04)
	int32_t NumClients; // 0xcc(0x04)
	int32_t NetworkLatencyMS; // 0xd0(0x04)
	float PacketLossPercent; // 0xd4(0x04)
	bool bSuppressLogErrors; // 0xd8(0x01)
	char pad_e1[0x5f]; // 0xe1(0x5f)

	bool UpdateServer(); // Function AngelscriptCode.SessionTestCase.UpdateServer // (Native|Event|Public|BlueprintEvent) // @ game+0x2b5ca40
	bool UpdateClient(); // Function AngelscriptCode.SessionTestCase.UpdateClient // (Native|Event|Public|BlueprintEvent) // @ game+0x3247a90
	void SetupServer(); // Function AngelscriptCode.SessionTestCase.SetupServer // (Native|Event|Public|BlueprintEvent) // @ game+0x16fe8b0
	void SetupClient(); // Function AngelscriptCode.SessionTestCase.SetupClient // (Native|Event|Public|BlueprintEvent) // @ game+0x17031b0
	void SetStep(struct FString StepName); // Function AngelscriptCode.SessionTestCase.SetStep // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa0e80
	void Log(struct FString Message); // Function AngelscriptCode.SessionTestCase.Log // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa9500
	bool IsServer(); // Function AngelscriptCode.SessionTestCase.IsServer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f9e2e0
	bool IsClient(); // Function AngelscriptCode.SessionTestCase.IsClient // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3faa130
	bool HasFailed(); // Function AngelscriptCode.SessionTestCase.HasFailed // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f9f3d0
	float GetStepElapsedTime(); // Function AngelscriptCode.SessionTestCase.GetStepElapsedTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f9df40
	struct FString GetStep(); // Function AngelscriptCode.SessionTestCase.GetStep // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f9db10
	int32_t GetNumClients(); // Function AngelscriptCode.SessionTestCase.GetNumClients // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3f9f330
	int32_t GetErrorCount(); // Function AngelscriptCode.SessionTestCase.GetErrorCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa6be0
	float GetElapsedTime(); // Function AngelscriptCode.SessionTestCase.GetElapsedTime // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa1b40
	int32_t GetClientIndex(); // Function AngelscriptCode.SessionTestCase.GetClientIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3fa8e50
	void Fail(struct FString Message); // Function AngelscriptCode.SessionTestCase.Fail // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9d2b0
	void AssertTrue(bool bCondition, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertTrue // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa73b0
	void AssertStringNotContains(struct FString Haystack, struct FString Needle, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertStringNotContains // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa3530
	void AssertStringContains(struct FString Haystack, struct FString Needle, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertStringContains // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9e8b0
	void AssertNotEqualsString(struct FString NotExpected, struct FString Actual, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertNotEqualsString // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa1640
	void AssertNotEqualsName(struct FName NotExpected, struct FName Actual, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertNotEqualsName // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa5370
	void AssertNotEqualsInt(int32_t NotExpected, int32_t Actual, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertNotEqualsInt // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa9770
	void AssertNotEqualsFloat(float NotExpected, float Actual, struct FString Message, float Tolerance); // Function AngelscriptCode.SessionTestCase.AssertNotEqualsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa1480
	void AssertFalse(bool bCondition, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertFalse // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa0b10
	void AssertEventually(bool bCondition, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertEventually // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9c760
	void AssertEqualsVector(struct FVector Expected, struct FVector Actual, struct FString Message, float Tolerance); // Function AngelscriptCode.SessionTestCase.AssertEqualsVector // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x3fa6c30
	void AssertEqualsString(struct FString Expected, struct FString Actual, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertEqualsString // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa9180
	void AssertEqualsName(struct FName Expected, struct FName Actual, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertEqualsName // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa4410
	void AssertEqualsInt(int32_t Expected, int32_t Actual, struct FString Message); // Function AngelscriptCode.SessionTestCase.AssertEqualsInt // (Final|Native|Public|BlueprintCallable) // @ game+0x3f9d510
	void AssertEqualsFloat(float Expected, float Actual, struct FString Message, float Tolerance); // Function AngelscriptCode.SessionTestCase.AssertEqualsFloat // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa8b40
	void AddExpectedError(struct FString Regex, int32_t Occurrences); // Function AngelscriptCode.SessionTestCase.AddExpectedError // (Final|Native|Public|BlueprintCallable) // @ game+0x3fa5ca0
};

// Class AngelscriptCode.SoftReferenceStatics
// Size: 0xa0 (Inherited: 0xa0)
struct USoftReferenceStatics : UObject {
};

// Class AngelscriptCode.SubsystemLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct USubsystemLibrary : UObject {

	struct UWorldSubsystem* GetWorldSubsystem(struct UObject* WorldContextObject, struct UWorldSubsystem* Class); // Function AngelscriptCode.SubsystemLibrary.GetWorldSubsystem // (Final|Native|Static|Public) // @ game+0x3fdc110
	struct ULocalPlayerSubsystem* GetLocalPlayerSubSystemFromPlayerController(struct APlayerController* PlayerController, struct ULocalPlayerSubsystem* Class); // Function AngelscriptCode.SubsystemLibrary.GetLocalPlayerSubSystemFromPlayerController // (Final|Native|Static|Public) // @ game+0x3fd04e0
	struct ULocalPlayerSubsystem* GetLocalPlayerSubsystemFromLocalPlayer(struct UObject* WorldContextObject, struct ULocalPlayer* LocalPlayer, struct ULocalPlayerSubsystem* Class); // Function AngelscriptCode.SubsystemLibrary.GetLocalPlayerSubsystemFromLocalPlayer // (Final|Native|Static|Public) // @ game+0x3fad660
	struct ULocalPlayerSubsystem* GetLocalPlayerSubsystem(struct UObject* WorldContextObject, struct ULocalPlayerSubsystem* Class); // Function AngelscriptCode.SubsystemLibrary.GetLocalPlayerSubsystem // (Final|Native|Static|Public) // @ game+0x3fe6570
	struct UGameInstanceSubsystem* GetGameInstanceSubsystem(struct UObject* WorldContextObject, struct UGameInstanceSubsystem* Class); // Function AngelscriptCode.SubsystemLibrary.GetGameInstanceSubsystem // (Final|Native|Static|Public) // @ game+0x3fb9f40
	struct UEngineSubsystem* GetEngineSubsystem(struct UEngineSubsystem* Class); // Function AngelscriptCode.SubsystemLibrary.GetEngineSubsystem // (Final|Native|Static|Public) // @ game+0x3fcfcc0
};

// Class AngelscriptCode.AssetManagerMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAssetManagerMixinLibrary : UObject {

	void ScanPathsForPrimaryAssets(struct UAssetManager* AssetManager, struct FPrimaryAssetType PrimaryAssetType, struct TArray<struct FString>& Paths, struct UObject* BaseClass, bool bHasBlueprintClasses, bool bIsEditorOnly, bool bForceSynchronousScan); // Function AngelscriptCode.AssetManagerMixinLibrary.ScanPathsForPrimaryAssets // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fce1d0
	void GetPrimaryAssetTypeInfoList(struct UAssetManager* AssetManager, struct TArray<struct FPrimaryAssetTypeInfo>& AssetTypeInfoList); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetTypeInfoList // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fe5e90
	bool GetPrimaryAssetTypeInfo(struct UAssetManager* AssetManager, struct FPrimaryAssetType PrimaryAssetType, struct FPrimaryAssetTypeInfo& AssetTypeInfo); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetTypeInfo // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fdbf80
	struct FPrimaryAssetRules GetPrimaryAssetRules(struct UAssetManager* AssetManager, struct FPrimaryAssetId& PrimaryAssetId); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetRules // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fcbd40
	struct UObject* GetPrimaryAssetObject(struct UAssetManager* AssetManager, struct FPrimaryAssetId& PrimaryAssetId); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetObject // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fad8c0
	bool GetPrimaryAssetIdList(struct UAssetManager* AssetManager, struct FPrimaryAssetType PrimaryAssetType, struct TArray<struct FPrimaryAssetId>& PrimaryAssetIdList); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetIdList // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fafdf0
	struct FPrimaryAssetId GetPrimaryAssetIdForObject(struct UAssetManager* AssetManager, struct UObject* Object); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetIdForObject // (Final|Native|Static|Public|HasDefaults) // @ game+0x3faaa80
	bool GetPrimaryAssetDataList(struct UAssetManager* AssetManager, struct FPrimaryAssetType PrimaryAssetType, struct TArray<struct FAssetData>& AssetDataList); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetDataList // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fcfaf0
	bool GetPrimaryAssetData(struct UAssetManager* AssetManager, struct FPrimaryAssetId& PrimaryAssetId, struct FAssetData& AssetData); // Function AngelscriptCode.AssetManagerMixinLibrary.GetPrimaryAssetData // (Final|Native|Static|Public|HasOutParms|HasDefaults) // @ game+0x3fe5fd0
	void CallOrRegister_OnCompletedInitialScan(struct UAssetManager* AssetManager, struct UObject* Object, struct FName& FunctionName); // Function AngelscriptCode.AssetManagerMixinLibrary.CallOrRegister_OnCompletedInitialScan // (Final|Native|Static|Public|HasOutParms) // @ game+0x3fb23e0
};

// Class AngelscriptCode.ObjectInWorld
// Size: 0xa0 (Inherited: 0xa0)
struct UObjectInWorld : UObject {
	struct UWorld* World; // 0x98(0x08)

	void SetWorldContext(struct UObject* WorldContext); // Function AngelscriptCode.ObjectInWorld.SetWorldContext // (Final|Native|Public) // @ game+0x3fc13f0
	void SetWorld(struct UWorld* InWorld); // Function AngelscriptCode.ObjectInWorld.SetWorld // (Final|Native|Public) // @ game+0x3fc6fd0
	void DestroyObject(); // Function AngelscriptCode.ObjectInWorld.DestroyObject // (Final|Native|Public) // @ game+0x3fb15d0
};

// Class AngelscriptCode.ObjectTickable
// Size: 0xb0 (Inherited: 0xa0)
struct UObjectTickable : UObject {
	struct UWorld* World; // 0xa0(0x08)
	bool bTickWhilePaused; // 0xa8(0x01)
	char pad_a9[0x7]; // 0xa9(0x07)

	void SetWorldContext(struct UObject* WorldContext); // Function AngelscriptCode.ObjectTickable.SetWorldContext // (Final|Native|Public) // @ game+0x3faa8e0
	void SetWorld(struct UWorld* InWorld); // Function AngelscriptCode.ObjectTickable.SetWorld // (Final|Native|Public) // @ game+0x3faae70
	void DestroyObject(); // Function AngelscriptCode.ObjectTickable.DestroyObject // (Final|Native|Public) // @ game+0x3fb15d0
	void BP_Tick(float DeltaTime); // Function AngelscriptCode.ObjectTickable.BP_Tick // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
};

// Class AngelscriptCode.WidgetBlueprintStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UWidgetBlueprintStatics : UObject {

	struct UUserWidget* CreateWidget(struct UObject* WorldContextObject, struct UUserWidget* WidgetType, struct APlayerController* OwningPlayer); // Function AngelscriptCode.WidgetBlueprintStatics.CreateWidget // (Final|Native|Static|Public) // @ game+0x3fce010
	void CancelDragDrop(); // Function AngelscriptCode.WidgetBlueprintStatics.CancelDragDrop // (Final|Native|Static|Public) // @ game+0x3fe61e0
};

// Class AngelscriptCode.AngelscriptWidgetMixinLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAngelscriptWidgetMixinLibrary : UObject {

	struct FWidgetTransform GetRenderTransform(struct UWidget* Widget); // Function AngelscriptCode.AngelscriptWidgetMixinLibrary.GetRenderTransform // (Final|Native|Static|Public) // @ game+0x3fb2c10
};

// Class AngelscriptCode.WorldCollisionStatics
// Size: 0xa0 (Inherited: 0xa0)
struct UWorldCollisionStatics : UObject {
};

