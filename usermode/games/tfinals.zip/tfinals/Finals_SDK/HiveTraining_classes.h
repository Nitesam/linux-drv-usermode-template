// Class HiveTraining.MLTrainingComponent
// Size: 0x160 (Inherited: 0x160)
struct UMLTrainingComponent : UActorComponent {

	bool Uninitialize(); // Function HiveTraining.MLTrainingComponent.Uninitialize // (Native|Event|Public|BlueprintEvent) // @ game+0x9030c60
	void SoftReset(); // Function HiveTraining.MLTrainingComponent.SoftReset // (Native|Event|Public|BlueprintEvent) // @ game+0x90549c0
	void SignalInitialPolicyDone(); // Function HiveTraining.MLTrainingComponent.SignalInitialPolicyDone // (Native|Event|Public|BlueprintEvent) // @ game+0x2ff11a0
	bool SetInitialPolicy(struct UMLModelData* Model); // Function HiveTraining.MLTrainingComponent.SetInitialPolicy // (Native|Event|Public|BlueprintEvent) // @ game+0x9054430
	bool Initialize(struct UMLDataAssetBase* Configuration, bool bInIsValidationAgent); // Function HiveTraining.MLTrainingComponent.Initialize // (Native|Event|Public|BlueprintEvent) // @ game+0x90548b0
	struct UMLTrainingPolicy* GetTrainingPolicy(); // Function HiveTraining.MLTrainingComponent.GetTrainingPolicy // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x90541e0
	struct UMLInspectorPolicyComponent* GetInspectorComponentClass(); // Function HiveTraining.MLTrainingComponent.GetInspectorComponentClass // (Native|Event|Public|BlueprintEvent|Const) // @ game+0x9054510
};

// Class HiveTraining.MLTickableTrainingComponent
// Size: 0x3d0 (Inherited: 0x160)
struct UMLTickableTrainingComponent : UMLTrainingComponent {
	struct UMLTrainingPolicy* TrainingPolicy; // 0x160(0x08)
	struct UMLPolicy* InitialPolicy; // 0x168(0x08)
	struct UObservationSet* ObservationSet; // 0x170(0x08)
	char pad_178[0x258]; // 0x178(0x258)

	bool Uninitialize_Native(); // Function HiveTraining.MLTickableTrainingComponent.Uninitialize_Native // (Final|Native|Public) // @ game+0x5198790
	bool Initialize_Native(struct UMLDataAssetBase* Configuration, bool bInIsValidationAgent); // Function HiveTraining.MLTickableTrainingComponent.Initialize_Native // (Native|Public) // @ game+0x90535c0
};

// Class HiveTraining.MLTrainingSubsystem
// Size: 0x1f0 (Inherited: 0xb0)
struct UMLTrainingSubsystem : UTickableWorldSubsystem {
	struct FDelegate OnModelReady; // 0xb0(0x10)
	struct FDelegate OnGenerateDerivedData; // 0xc0(0x10)
	struct UMLRegistryConnection* Registry; // 0xd0(0x08)
	struct TMap<struct FName, struct UMLTrainingConnection*> Trainers; // 0xd8(0x50)
	char pad_128[0xc8]; // 0x128(0xc8)

	void UnregisterAgent(struct FAgentIdentity Identity); // Function HiveTraining.MLTrainingSubsystem.UnregisterAgent // (Final|Native|Public) // @ game+0x9050c80
	void RegisterModelType(struct FName ModelType); // Function HiveTraining.MLTrainingSubsystem.RegisterModelType // (Final|Native|Public) // @ game+0x5d5b910
	struct FAgentIdentity RegisterAgent(struct FName ModelType, bool bIsValidation); // Function HiveTraining.MLTrainingSubsystem.RegisterAgent // (Final|Native|Public) // @ game+0x9055f10
	void PushValidationMetrics(struct FName ModelName, struct FHiveMetaData& MetaData); // Function HiveTraining.MLTrainingSubsystem.PushValidationMetrics // (Final|Native|Public|HasOutParms) // @ game+0x9055250
	void PushMetrics(struct FName ModelName, struct FHiveMetaData& MetaData); // Function HiveTraining.MLTrainingSubsystem.PushMetrics // (Final|Native|Public|HasOutParms) // @ game+0x9055250
	void Push(struct FAgentIdentity Identity, struct FMLTrainingInferenceInput& Input); // Function HiveTraining.MLTrainingSubsystem.Push // (Final|Native|Public|HasOutParms) // @ game+0x90557a0
	bool Pull(struct FAgentIdentity Identity, struct FMLInferenceOutput& OutResponse); // Function HiveTraining.MLTrainingSubsystem.Pull // (Final|Native|Public|HasOutParms) // @ game+0x90504d0
	void LoadModel(struct FName ModelName, struct TArray<char>& ModelData, struct FModelInfo& ModelInfo); // Function HiveTraining.MLTrainingSubsystem.LoadModel // (Final|Native|Public|HasOutParms) // @ game+0x9050fd0
};

// Class HiveTraining.MLTrainingConnection
// Size: 0x150 (Inherited: 0xa0)
struct UMLTrainingConnection : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UHiveModelRpcClient* ModelClient; // 0xb0(0x08)
	struct UHiveModelServiceRpcClient* ServiceClient; // 0xb8(0x08)
	char pad_c0[0x68]; // 0xc0(0x68)
	struct UMLDataAssetBase* Configuration; // 0x128(0x08)
	char pad_130[0x20]; // 0x130(0x20)
};

// Class HiveTraining.MLRegistryConnection
// Size: 0xd0 (Inherited: 0xa0)
struct UMLRegistryConnection : UObject {
	char pad_a0[0x10]; // 0xa0(0x10)
	struct UHiveMLRegistryRpcClient* Client; // 0xb0(0x08)
	struct UHiveMLRegistryServiceRpcClient* ClientV2; // 0xb8(0x08)
	struct UHiveRegistryServiceRpcClient* ClientHV1; // 0xc0(0x08)
	char pad_c8[0x8]; // 0xc8(0x08)
};

