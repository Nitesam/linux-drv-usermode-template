// Class EmbarkCharacter.EmbarkCharacterBase
// Size: 0xb30 (Inherited: 0x780)
struct AEmbarkCharacterBase : ACharacter {
	char pad_780[0x38]; // 0x780(0x38)
	struct UEmbarkAbilitySystemComponent* AbilitySystem; // 0x7b8(0x08)
	struct UStateInterpolatorComponent* StateInterpolatorComponent; // 0x7c0(0x08)
	struct UReplicationSettingsComponent* ReplicationSettingsComponent; // 0x7c8(0x08)
	struct UEmbarkPawnComponent* PossessionEventComponent; // 0x7d0(0x08)
	struct UEmbarkSkeletalMeshComponent* EmbarkMesh; // 0x7d8(0x08)
	struct UEmbarkCharacterMovementComponent* EmbarkCharacterMovement; // 0x7e0(0x08)
	struct FMulticastInlineDelegate OnRecordingStateChanged; // 0x7e8(0x10)
	bool bInfiniteAmmo; // 0x7f8(0x01)
	char pad_7f9[0x7]; // 0x7f9(0x07)
	struct FMulticastInlineDelegate OnPlayerStateReplicated; // 0x800(0x10)
	bool bDisableWhenOutOfBounds; // 0x810(0x01)
	bool bReplicateTeamId; // 0x811(0x01)
	enum class EEmbarkTeamId TeamId; // 0x812(0x01)
	char pad_813[0x15]; // 0x813(0x15)
	struct AController* CachedController; // 0x828(0x08)
	char pad_830[0x270]; // 0x830(0x270)
	struct FBlackBoardVariableDeltaCompressionPtr BlackBoardReplicationPtr; // 0xaa0(0x78)
	struct UPendulumDataContainer* SimulationLogicData; // 0xb18(0x08)
	bool bIsRecording; // 0xb20(0x01)
	char pad_b21[0xf]; // 0xb21(0x0f)

	bool UsePendulumSystemForCharacter(); // Function EmbarkCharacter.EmbarkCharacterBase.UsePendulumSystemForCharacter // (Final|Native|Public|Const) // @ game+0x5fcf2a0
	void TriggerInputAction(struct FName InputAction, enum class EInputEvent InputEvent); // Function EmbarkCharacter.EmbarkCharacterBase.TriggerInputAction // (Final|Native|Public|BlueprintCallable) // @ game+0x5fcebe0
	void StopStandingOnCurrentMovementBase(); // Function EmbarkCharacter.EmbarkCharacterBase.StopStandingOnCurrentMovementBase // (Final|Native|Public|BlueprintCallable) // @ game+0x5fcfa60
	void SetUseMixedGASReplication(); // Function EmbarkCharacter.EmbarkCharacterBase.SetUseMixedGASReplication // (Final|Native|Public) // @ game+0x5fd12a0
	void SetIsRecording(bool bInIsRecording); // Function EmbarkCharacter.EmbarkCharacterBase.SetIsRecording // (Final|Native|Public|BlueprintCallable) // @ game+0x5fcd5c0
	void SetDefaultNetDormancy(enum class ENetDormancy DefaultNetDormancy); // Function EmbarkCharacter.EmbarkCharacterBase.SetDefaultNetDormancy // (Final|Native|Public) // @ game+0x5da4710
	float ReceiveTakeDamage(float DamageAmount, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* DamageCauser); // Function EmbarkCharacter.EmbarkCharacterBase.ReceiveTakeDamage // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveSetupPlayerInputComponent(struct UInputComponent* PlayerInputComponent); // Function EmbarkCharacter.EmbarkCharacterBase.ReceiveSetupPlayerInputComponent // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceivePostInitializeComponents(); // Function EmbarkCharacter.EmbarkCharacterBase.ReceivePostInitializeComponents // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnRep_PlayerState(); // Function EmbarkCharacter.EmbarkCharacterBase.ReceiveOnRep_PlayerState // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveOnRep_Controller(); // Function EmbarkCharacter.EmbarkCharacterBase.ReceiveOnRep_Controller // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveEmbarkOnUnPossessed(struct AController* InController); // Function EmbarkCharacter.EmbarkCharacterBase.ReceiveEmbarkOnUnPossessed // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void ReceiveEmbarkOnPossessed(struct AController* InController); // Function EmbarkCharacter.EmbarkCharacterBase.ReceiveEmbarkOnPossessed // (Event|Protected|BlueprintEvent) // @ game+0x4abfe0
	void OverrideWith(struct AEmbarkCharacterBase* OldCharacter); // Function EmbarkCharacter.EmbarkCharacterBase.OverrideWith // (Event|Public|BlueprintEvent) // @ game+0x4abfe0
	bool IsStandingOn(struct UPrimitiveComponent* Component, struct FName& BoneName); // Function EmbarkCharacter.EmbarkCharacterBase.IsStandingOn // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x5fd3880
	struct FVector GetShootLocation(); // Function EmbarkCharacter.EmbarkCharacterBase.GetShootLocation // (Native|Event|Public|HasDefaults|BlueprintEvent|Const) // @ game+0x5fcd090
	enum class EGameplayEffectReplicationMode GetReplicationMode(); // Function EmbarkCharacter.EmbarkCharacterBase.GetReplicationMode // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5fcc930
	struct FPendulumExecutionContext GetPendulumSimulationContext(); // Function EmbarkCharacter.EmbarkCharacterBase.GetPendulumSimulationContext // (Final|Native|Public|Const) // @ game+0x5fcbd10
	struct FPendulumExecutionContext GetPendulumPresentationContext(); // Function EmbarkCharacter.EmbarkCharacterBase.GetPendulumPresentationContext // (Final|Native|Public|Const) // @ game+0x5fd0630
	struct FVector GetPawnViewLocationBP(); // Function EmbarkCharacter.EmbarkCharacterBase.GetPawnViewLocationBP // (Native|Event|Protected|HasDefaults|BlueprintEvent|Const) // @ game+0x5fcf850
	bool GetIsRecording(); // Function EmbarkCharacter.EmbarkCharacterBase.GetIsRecording // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5fcda50
	struct FBasedMovementInfoBP GetBasedMovementBP(); // Function EmbarkCharacter.EmbarkCharacterBase.GetBasedMovementBP // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5fd0890
	void FillInAnimationContext(struct FPendulumAnimationUpdateContext& AnimationContext); // Function EmbarkCharacter.EmbarkCharacterBase.FillInAnimationContext // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x5fd39f0
	void EmbarkOnUnPossessed_Internal(struct AController* InController); // Function EmbarkCharacter.EmbarkCharacterBase.EmbarkOnUnPossessed_Internal // (Final|Native|Private) // @ game+0x5fcc5a0
	void EmbarkOnPossessed_Internal(struct AController* InController); // Function EmbarkCharacter.EmbarkCharacterBase.EmbarkOnPossessed_Internal // (Final|Native|Private) // @ game+0x5fd3360
	struct FPendulumExecutionContext EditPendulumSimulationContext(); // Function EmbarkCharacter.EmbarkCharacterBase.EditPendulumSimulationContext // (Final|Native|Public) // @ game+0x5fcbd10
	void BP_SetTeam(enum class EEmbarkTeamId NewTeam); // Function EmbarkCharacter.EmbarkCharacterBase.BP_SetTeam // (Final|Native|Public|BlueprintCallable) // @ game+0x5fccfe0
	void BP_OutsideWorldBoundsEvent(); // Function EmbarkCharacter.EmbarkCharacterBase.BP_OutsideWorldBoundsEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x5fd12e0
	enum class EEmbarkTeamId BP_GetTeam(); // Function EmbarkCharacter.EmbarkCharacterBase.BP_GetTeam // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x5fceba0
	void BP_FellOutOfWorldEvent(struct UDamageType* dmgType); // Function EmbarkCharacter.EmbarkCharacterBase.BP_FellOutOfWorldEvent // (Native|Event|Public|BlueprintEvent) // @ game+0x5fcf9b0
};

