// Class ACLPlugin.AnimationCompressionLibraryDatabase
// Size: 0x1e0 (Inherited: 0xa0)
struct UAnimationCompressionLibraryDatabase : UObject {
	struct TArray<char> CookedCompressedBytes; // 0x98(0x10)
	struct TArray<uint64_t> CookedAnimSequenceMappings; // 0xa8(0x10)
	char pad_c0[0x110]; // 0xc0(0x110)
	uint32_t MaxStreamRequestSizeKB; // 0x1d0(0x04)
	char pad_1d4[0xc]; // 0x1d4(0x0c)

	void SetVisualFidelity(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UAnimationCompressionLibraryDatabase* DatabaseAsset, enum class ACLVisualFidelityChangeResult& Result, enum class ACLVisualFidelity VisualFidelity); // Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x9707e70
	enum class ACLVisualFidelity GetVisualFidelity(struct UAnimationCompressionLibraryDatabase* DatabaseAsset); // Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9703c70
};

// Class ACLPlugin.AnimBoneCompressionCodec_ACLBase
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimBoneCompressionCodec_ACLBase : UAnimBoneCompressionCodec {
};

// Class ACLPlugin.AnimBoneCompressionCodec_ACL
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimBoneCompressionCodec_ACL : UAnimBoneCompressionCodec_ACLBase {
};

// Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimBoneCompressionCodec_ACLCustom : UAnimBoneCompressionCodec_ACLBase {
};

// Class ACLPlugin.AnimBoneCompressionCodec_ACLDatabase
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimBoneCompressionCodec_ACLDatabase : UAnimBoneCompressionCodec_ACLBase {
	struct UAnimationCompressionLibraryDatabase* DatabaseAsset; // 0xa8(0x08)
};

// Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe
// Size: 0xb0 (Inherited: 0xb0)
struct UAnimBoneCompressionCodec_ACLSafe : UAnimBoneCompressionCodec_ACLBase {
};

// Class ACLPlugin.AnimCurveCompressionCodec_ACL
// Size: 0xa0 (Inherited: 0xa0)
struct UAnimCurveCompressionCodec_ACL : UAnimCurveCompressionCodec {
};

