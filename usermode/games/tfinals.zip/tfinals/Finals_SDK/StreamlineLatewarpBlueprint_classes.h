// Class StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp
// Size: 0xa0 (Inherited: 0xa0)
struct UStreamlineLibraryLatewarp : UBlueprintFunctionLibrary {

	void SetLatewarpPredictiveRendering(bool Enabled); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.SetLatewarpPredictiveRendering // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5a85110
	void SetLatewarpMode(enum class EStreamlineLatewarpMode LatewarpMode); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.SetLatewarpMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5a87aa0
	enum class EStreamlineFeatureSupport QueryLatewarpSupport(); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.QueryLatewarpSupport // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a87d20
	bool IsLatewarpSupported(); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.IsLatewarpSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a87a70
	bool IsLatewarpModeSupported(enum class EStreamlineLatewarpMode LatewarpMode); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.IsLatewarpModeSupported // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a84a20
	struct TArray<enum class EStreamlineLatewarpMode> GetSupportedLatewarpModes(); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.GetSupportedLatewarpModes // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a84fe0
	bool GetLatewarpPredictiveRendering(); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.GetLatewarpPredictiveRendering // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x5a85360
	enum class EStreamlineLatewarpMode GetLatewarpMode(); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.GetLatewarpMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a85070
	enum class EStreamlineLatewarpMode GetDefaultLatewarpMode(); // Function StreamlineLatewarpBlueprint.StreamlineLibraryLatewarp.GetDefaultLatewarpMode // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5a87870
};

