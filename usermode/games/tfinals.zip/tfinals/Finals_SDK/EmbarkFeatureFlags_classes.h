// Class EmbarkFeatureFlags.FeatureFlagNativeFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UFeatureFlagNativeFunctionLibrary : UBlueprintFunctionLibrary {

	bool UseKneeHeightMovement(); // Function EmbarkFeatureFlags.FeatureFlagNativeFunctionLibrary.UseKneeHeightMovement // (Final|Native|Static|Public) // @ game+0x50c7130
	bool UseDefaultUnrealMovement(); // Function EmbarkFeatureFlags.FeatureFlagNativeFunctionLibrary.UseDefaultUnrealMovement // (Final|Native|Static|Public) // @ game+0x50c4dc0
	bool IsLocalPlaytest(); // Function EmbarkFeatureFlags.FeatureFlagNativeFunctionLibrary.IsLocalPlaytest // (Final|Native|Static|Public) // @ game+0x50c74d0
	bool IsDevMode(); // Function EmbarkFeatureFlags.FeatureFlagNativeFunctionLibrary.IsDevMode // (Final|Native|Static|Public) // @ game+0x50c70b0
	bool IsAutoplayQuickTest(); // Function EmbarkFeatureFlags.FeatureFlagNativeFunctionLibrary.IsAutoplayQuickTest // (Final|Native|Static|Public) // @ game+0x50c7410
};

