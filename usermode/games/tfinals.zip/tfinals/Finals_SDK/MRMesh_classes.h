// Class MRMesh.MockDataMeshTrackerComponent
// Size: 0x430 (Inherited: 0x3c0)
struct UMockDataMeshTrackerComponent : USceneComponent {
	struct FMulticastInlineDelegate OnMeshTrackerUpdated; // 0x3c0(0x10)
	bool ScanWorld; // 0x3d0(0x01)
	bool RequestNormals; // 0x3d1(0x01)
	bool RequestVertexConfidence; // 0x3d2(0x01)
	enum class EMeshTrackerVertexColorMode VertexColorMode; // 0x3d3(0x01)
	char pad_3d4[0x4]; // 0x3d4(0x04)
	struct TArray<struct FColor> BlockVertexColors; // 0x3d8(0x10)
	struct FLinearColor VertexColorFromConfidenceZero; // 0x3e8(0x10)
	struct FLinearColor VertexColorFromConfidenceOne; // 0x3f8(0x10)
	float UpdateInterval; // 0x408(0x04)
	char pad_40c[0x4]; // 0x40c(0x04)
	struct UMRMeshComponent* MRMesh; // 0x410(0x08)
	char pad_418[0x18]; // 0x418(0x18)

	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<float>& Confidence); // DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x4abfe0
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b96610
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b98b70
};

// Class MRMesh.MRMeshBodyHolder
// Size: 0x2a0 (Inherited: 0xa0)
struct UMRMeshBodyHolder : UObject {
	struct UBodySetup* BodySetup; // 0xa0(0x08)
	struct FBodyInstance BodyInstance; // 0xa8(0x190)
	char pad_238[0x68]; // 0x238(0x68)
};

// Class MRMesh.MRMeshComponent
// Size: 0x740 (Inherited: 0x6c0)
struct UMRMeshComponent : UPrimitiveComponent {
	struct UMaterialInterface* Material; // 0x6c0(0x08)
	struct UMaterialInterface* WireframeMaterial; // 0x6c8(0x08)
	bool bCreateMeshProxySections; // 0x6d0(0x01)
	bool bUpdateNavMeshOnMeshUpdate; // 0x6d1(0x01)
	char pad_6d2[0x1]; // 0x6d2(0x01)
	bool bNeverCreateCollisionMesh; // 0x6d3(0x01)
	char pad_6d4[0x44]; // 0x6d4(0x44)
	struct TArray<struct UMRMeshBodyHolder*> BodyHolders; // 0x718(0x10)
	char pad_728[0x18]; // 0x728(0x18)

	void SetWireframeMaterial(struct UMaterialInterface* InMaterial); // Function MRMesh.MRMeshComponent.SetWireframeMaterial // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b9b6e0
	void SetWireframeColor(struct FLinearColor& InColor); // Function MRMesh.MRMeshComponent.SetWireframeColor // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x2b933f0
	void SetUseWireframe(bool bUseWireframe); // Function MRMesh.MRMeshComponent.SetUseWireframe // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b96560
	void SetEnableMeshOcclusion(bool bEnable); // Function MRMesh.MRMeshComponent.SetEnableMeshOcclusion // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b8ff30
	void RequestNavMeshUpdate(); // Function MRMesh.MRMeshComponent.RequestNavMeshUpdate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b96da0
	bool IsConnected(); // Function MRMesh.MRMeshComponent.IsConnected // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b923a0
	struct FLinearColor GetWireframeColor(); // Function MRMesh.MRMeshComponent.GetWireframeColor // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b90000
	bool GetUseWireframe(); // Function MRMesh.MRMeshComponent.GetUseWireframe // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b99a50
	bool GetEnableMeshOcclusion(); // Function MRMesh.MRMeshComponent.GetEnableMeshOcclusion // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b8db00
	void ForceNavMeshUpdate(); // Function MRMesh.MRMeshComponent.ForceNavMeshUpdate // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b92470
	void Clear(); // Function MRMesh.MRMeshComponent.Clear // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b977f0
};

// Class MRMesh.MeshReconstructorBase
// Size: 0xa0 (Inherited: 0xa0)
struct UMeshReconstructorBase : UObject {

	void StopReconstruction(); // Function MRMesh.MeshReconstructorBase.StopReconstruction // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b96540
	void StartReconstruction(); // Function MRMesh.MeshReconstructorBase.StartReconstruction // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2b95cb0
	void PauseReconstruction(); // Function MRMesh.MeshReconstructorBase.PauseReconstruction // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x17031b0
	bool IsReconstructionStarted(); // Function MRMesh.MeshReconstructorBase.IsReconstructionStarted // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x29eeb30
	bool IsReconstructionPaused(); // Function MRMesh.MeshReconstructorBase.IsReconstructionPaused // (RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2b960b0
	void DisconnectMRMesh(); // Function MRMesh.MeshReconstructorBase.DisconnectMRMesh // (RequiredAPI|Native|Public) // @ game+0x16fe6f0
	void ConnectMRMesh(struct UMRMeshComponent* Mesh); // Function MRMesh.MeshReconstructorBase.ConnectMRMesh // (RequiredAPI|Native|Public) // @ game+0x2b8dcf0
};

