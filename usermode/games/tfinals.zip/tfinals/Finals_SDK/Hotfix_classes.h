// Class Hotfix.OnlineHotfixManager
// Size: 0x2e0 (Inherited: 0xa0)
struct UOnlineHotfixManager : UObject {
	char pad_a0[0x1f8]; // 0xa0(0x1f8)
	struct FString OSSName; // 0x298(0x10)
	struct FString HotfixManagerClassName; // 0x2a8(0x10)
	struct FString DebugPrefix; // 0x2b8(0x10)
	struct TArray<struct UObject*> AssetsHotfixedFromIniFiles; // 0x2c8(0x10)
	char pad_2d8[0x8]; // 0x2d8(0x08)

	void StartHotfixProcess(); // Function Hotfix.OnlineHotfixManager.StartHotfixProcess // (Native|Public|BlueprintCallable) // @ game+0x2f877e0
};

// Class Hotfix.UpdateManager
// Size: 0x270 (Inherited: 0xa0)
struct UUpdateManager : UObject {
	char pad_a0[0x58]; // 0xa0(0x58)
	float UpdateCheckStartDelay; // 0xf8(0x04)
	float UpdateCheckCachedResponseDelay; // 0xfc(0x04)
	float HotfixCheckCompleteDelay; // 0x100(0x04)
	float UpdateCheckCompleteDelay; // 0x104(0x04)
	float HotfixAvailabilityCheckCompleteDelay; // 0x108(0x04)
	float UpdateCheckAvailabilityCompleteDelay; // 0x10c(0x04)
	char pad_110[0x4]; // 0x110(0x04)
	int32_t AppSuspendedUpdateCheckTimeSeconds; // 0x114(0x04)
	char pad_118[0x8]; // 0x118(0x08)
	bool bPlatformEnvironmentDetected; // 0x120(0x01)
	bool bInitialUpdateFinished; // 0x121(0x01)
	bool bCheckHotfixAvailabilityOnly; // 0x122(0x01)
	enum class EUpdateState CurrentUpdateState; // 0x123(0x01)
	int32_t WorstNumFilesPendingLoadViewed; // 0x124(0x04)
	char pad_128[0x4]; // 0x128(0x04)
	enum class EHotfixResult LastHotfixResult; // 0x12c(0x01)
	char pad_12d[0x23]; // 0x12d(0x23)
	struct FDateTime LastUpdateCheck[0x2]; // 0x150(0x10)
	enum class EUpdateCompletionStatus LastCompletionResult[0x2]; // 0x160(0x02)
	char pad_162[0x26]; // 0x162(0x26)
	struct UEnum* UpdateStateEnum; // 0x188(0x08)
	struct UEnum* UpdateCompletionEnum; // 0x190(0x08)
	struct FUpdateContextDefinition UpdateContextDefinitionUnknown; // 0x198(0x68)
	struct TArray<struct FUpdateContextDefinition> UpdateContextDefinitions; // 0x200(0x10)
	char pad_210[0x60]; // 0x210(0x60)
};

