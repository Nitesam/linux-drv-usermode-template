// Class InterchangeMessages.InterchangeResultMeshWarning
// Size: 0xe0 (Inherited: 0xd0)
struct UInterchangeResultMeshWarning : UInterchangeResultWarning {
	struct FString MeshName; // 0xd0(0x10)
};

// Class InterchangeMessages.InterchangeResultTextureWarning
// Size: 0xe0 (Inherited: 0xd0)
struct UInterchangeResultTextureWarning : UInterchangeResultWarning {
	struct FString TextureName; // 0xd0(0x10)
};

// Class InterchangeMessages.InterchangeResultMeshError
// Size: 0xe0 (Inherited: 0xd0)
struct UInterchangeResultMeshError : UInterchangeResultError {
	struct FString MeshName; // 0xd0(0x10)
};

// Class InterchangeMessages.InterchangeResultMeshWarning_Generic
// Size: 0x100 (Inherited: 0xe0)
struct UInterchangeResultMeshWarning_Generic : UInterchangeResultMeshWarning {
	struct FText Text; // 0xe0(0x18)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class InterchangeMessages.InterchangeResultMeshError_Generic
// Size: 0x100 (Inherited: 0xe0)
struct UInterchangeResultMeshError_Generic : UInterchangeResultMeshError {
	struct FText Text; // 0xe0(0x18)
	char pad_f8[0x8]; // 0xf8(0x08)
};

// Class InterchangeMessages.InterchangeResultMeshWarning_TooManyUVs
// Size: 0xf0 (Inherited: 0xe0)
struct UInterchangeResultMeshWarning_TooManyUVs : UInterchangeResultMeshWarning {
	int32_t ExcessUVs; // 0xe0(0x04)
	char pad_e4[0xc]; // 0xe4(0x0c)
};

// Class InterchangeMessages.InterchangeResultTextureWarning_TextureFileDoNotExist
// Size: 0x110 (Inherited: 0xe0)
struct UInterchangeResultTextureWarning_TextureFileDoNotExist : UInterchangeResultTextureWarning {
	struct FText Text; // 0xe0(0x18)
	struct FString MaterialName; // 0xf8(0x10)
	char pad_108[0x8]; // 0x108(0x08)
};

