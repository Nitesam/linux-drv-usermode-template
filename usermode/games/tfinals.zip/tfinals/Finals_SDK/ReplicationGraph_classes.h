// Class ReplicationGraph.ReplicationGraph
// Size: 0x5e0 (Inherited: 0xa0)
struct UReplicationGraph : UReplicationDriver {
	struct UNetReplicationGraphConnection* ReplicationConnectionManagerClass; // 0x98(0x08)
	struct UNetDriver* NetDriver; // 0xa0(0x08)
	struct TArray<struct UNetReplicationGraphConnection*> Connections; // 0xa8(0x10)
	struct TArray<struct UNetReplicationGraphConnection*> PendingConnections; // 0xb8(0x10)
	char pad_d0[0x38]; // 0xd0(0x38)
	struct TArray<struct UReplicationGraphNode*> GlobalGraphNodes; // 0x108(0x10)
	struct TArray<struct UReplicationGraphNode*> PrepareForReplicationNodes; // 0x118(0x10)
	char pad_128[0x4b8]; // 0x128(0x4b8)
};

// Class ReplicationGraph.BasicReplicationGraph
// Size: 0x610 (Inherited: 0x5e0)
struct UBasicReplicationGraph : UReplicationGraph {
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // 0x5e0(0x08)
	struct UReplicationGraphNode_ActorList* AlwaysRelevantNode; // 0x5e8(0x08)
	struct TArray<struct FConnectionAlwaysRelevantNodePair> AlwaysRelevantForConnectionList; // 0x5f0(0x10)
	struct TArray<struct AActor*> ActorsWithoutNetConnection; // 0x600(0x10)
};

// Class ReplicationGraph.ReplicationGraphNode
// Size: 0xc0 (Inherited: 0xa0)
struct UReplicationGraphNode : UObject {
	struct TArray<struct UReplicationGraphNode*> AllChildNodes; // 0x98(0x10)
	char pad_b0[0x10]; // 0xb0(0x10)
};

// Class ReplicationGraph.ReplicationGraphNode_ActorList
// Size: 0x140 (Inherited: 0xc0)
struct UReplicationGraphNode_ActorList : UReplicationGraphNode {
	char pad_c0[0x80]; // 0xc0(0x80)
};

// Class ReplicationGraph.ReplicationGraphNode_ActorListFrequencyBuckets
// Size: 0x180 (Inherited: 0xc0)
struct UReplicationGraphNode_ActorListFrequencyBuckets : UReplicationGraphNode {
	char pad_c0[0xc0]; // 0xc0(0xc0)
};

// Class ReplicationGraph.ReplicationGraphNode_DynamicSpatialFrequency
// Size: 0x170 (Inherited: 0x140)
struct UReplicationGraphNode_DynamicSpatialFrequency : UReplicationGraphNode_ActorList {
	char pad_140[0x30]; // 0x140(0x30)
};

// Class ReplicationGraph.ReplicationGraphNode_ConnectionDormancyNode
// Size: 0x1c0 (Inherited: 0x140)
struct UReplicationGraphNode_ConnectionDormancyNode : UReplicationGraphNode_ActorList {
	char pad_140[0x80]; // 0x140(0x80)
};

// Class ReplicationGraph.ReplicationGraphNode_DormancyNode
// Size: 0x150 (Inherited: 0x140)
struct UReplicationGraphNode_DormancyNode : UReplicationGraphNode_ActorList {
	char pad_140[0x10]; // 0x140(0x10)
};

// Class ReplicationGraph.ReplicationGraphNode_GridCell
// Size: 0x190 (Inherited: 0x140)
struct UReplicationGraphNode_GridCell : UReplicationGraphNode_ActorList {
	char pad_140[0x40]; // 0x140(0x40)
	struct UReplicationGraphNode* DynamicNode; // 0x180(0x08)
	struct UReplicationGraphNode_DormancyNode* DormancyNode; // 0x188(0x08)
};

// Class ReplicationGraph.ReplicationGraphNode_GridSpatialization2D
// Size: 0x2f0 (Inherited: 0xc0)
struct UReplicationGraphNode_GridSpatialization2D : UReplicationGraphNode {
	char pad_c0[0x230]; // 0xc0(0x230)
};

// Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant
// Size: 0xe0 (Inherited: 0xc0)
struct UReplicationGraphNode_AlwaysRelevant : UReplicationGraphNode {
	struct UReplicationGraphNode* ChildNode; // 0xc0(0x08)
	char pad_c8[0x18]; // 0xc8(0x18)
};

// Class ReplicationGraph.ReplicationGraphNode_AlwaysRelevant_ForConnection
// Size: 0x1b0 (Inherited: 0x140)
struct UReplicationGraphNode_AlwaysRelevant_ForConnection : UReplicationGraphNode_ActorList {
	char pad_140[0x10]; // 0x140(0x10)
	struct TArray<struct FAlwaysRelevantActorInfo> PastRelevantActors; // 0x150(0x10)
	char pad_160[0x50]; // 0x160(0x50)
};

// Class ReplicationGraph.ReplicationGraphNode_TearOff_ForConnection
// Size: 0xe0 (Inherited: 0xc0)
struct UReplicationGraphNode_TearOff_ForConnection : UReplicationGraphNode {
	struct TArray<struct FTearOffActorInfo> TearOffActors; // 0xc0(0x10)
	char pad_d0[0x10]; // 0xd0(0x10)
};

// Class ReplicationGraph.NetReplicationGraphConnection
// Size: 0x3f0 (Inherited: 0xa0)
struct UNetReplicationGraphConnection : UReplicationConnectionDriver {
	struct UNetConnection* NetConnection; // 0x98(0x08)
	char pad_a8[0x13c]; // 0xa8(0x13c)
	struct TWeakObjectPtr<struct AReplicationGraphDebugActor> DebugActor; // 0x1e4(0x08)
	char pad_1ec[0x4]; // 0x1ec(0x04)
	struct TArray<struct FLastLocationGatherInfo> LastGatherLocations; // 0x1f0(0x10)
	char pad_200[0xb0]; // 0x200(0xb0)
	struct TArray<struct UReplicationGraphNode*> ConnectionGraphNodes; // 0x2b0(0x10)
	struct UReplicationGraphNode_TearOff_ForConnection* TearOffNode; // 0x2c0(0x08)
	char pad_2c8[0x128]; // 0x2c8(0x128)
};

// Class ReplicationGraph.ReplicationGraphDebugActor
// Size: 0x3b0 (Inherited: 0x3a0)
struct AReplicationGraphDebugActor : AActor {
	struct UReplicationGraph* ReplicationGraph; // 0x398(0x08)
	struct UNetReplicationGraphConnection* ConnectionManager; // 0x3a0(0x08)

	void ServerStopDebugging(); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerStopDebugging // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x516b950
	void ServerStartDebugging(); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerStartDebugging // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x517ad90
	void ServerSetPeriodFrameForClass(struct UObject* Class, int32_t PeriodFrame); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetPeriodFrameForClass // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x516a9a0
	void ServerSetCullDistanceForClass(struct UObject* Class, float CullDistance); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetCullDistanceForClass // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x51780a0
	void ServerSetConditionalActorBreakpoint(struct AActor* Actor); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerSetConditionalActorBreakpoint // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x353c490
	void ServerPrintCullDistances(); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintCullDistances // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x2c9af60
	void ServerPrintAllActorInfo(struct FString Str); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerPrintAllActorInfo // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x516ba40
	void ServerCellInfo(); // Function ReplicationGraph.ReplicationGraphDebugActor.ServerCellInfo // (Net|NetReliableNative|Event|Public|NetServer) // @ game+0x2c84830
	void ClientCellInfo(struct FVector CellLocation, struct FVector CellExtent, struct TArray<struct AActor*> Actors); // Function ReplicationGraph.ReplicationGraphDebugActor.ClientCellInfo // (Net|NetReliableNative|Event|Public|HasDefaults|NetClient) // @ game+0x51720c0
};

