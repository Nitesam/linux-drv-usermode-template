// Class ActorQuery.ActorQuerySubsystem
// Size: 0x2c0 (Inherited: 0xa0)
struct UActorQuerySubsystem : UWorldSubsystem {
	struct FActorQueryClassRegistry ActorComponentClassRegistry; // 0xa0(0xc0)
	struct FActorQueryStorage Storage; // 0x160(0x100)
	struct TMap<struct FActorQuerySignature, struct FCachedActorQueryView> CachedViews; // 0x260(0x50)
	char pad_2b0[0x10]; // 0x2b0(0x10)

	bool ReceiveShouldCreateSubsystem(struct UObject* InOuter); // Function ActorQuery.ActorQuerySubsystem.ReceiveShouldCreateSubsystem // (Event|Public|BlueprintEvent|Const) // @ game+0x4abfe0
};

