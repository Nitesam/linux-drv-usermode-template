// Class EmbarkFire.EmbarkFireDebugManager
// Size: 0xb0 (Inherited: 0xa0)
struct UEmbarkFireDebugManager : UObject {
	struct UEmbarkFireObjectStorage* ObjectStorage; // 0x98(0x08)
	struct UEmbarkFireObjectGraph* ObjectGraph; // 0xa0(0x08)
	struct UEmbarkFireSettings* EmbarkFireSettings; // 0xa8(0x08)
};

// Class EmbarkFire.EmbarkFireFunctionLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkFireFunctionLibrary : UBlueprintFunctionLibrary {

	void UnregisterOnStateChangedCallbackForComponent_Client(struct UObject* WorldContextObject, struct USceneComponent* Component); // Function EmbarkFire.EmbarkFireFunctionLibrary.UnregisterOnStateChangedCallbackForComponent_Client // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b58d50
	void UnregisterHandle_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle); // Function EmbarkFire.EmbarkFireFunctionLibrary.UnregisterHandle_Server // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b59200
	void SetSphereLocation_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle, struct FVector Location); // Function EmbarkFire.EmbarkFireFunctionLibrary.SetSphereLocation_Server // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x5b4abf0
	void SetObjectHeatInvulnerability(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle& Handle, bool bInvulnerable); // Function EmbarkFire.EmbarkFireFunctionLibrary.SetObjectHeatInvulnerability // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5b54730
	void SetInstigator_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle, struct FInstigator& Instigator); // Function EmbarkFire.EmbarkFireFunctionLibrary.SetInstigator_Server // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5b50be0
	void SetHeat_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle, float Heat, struct FInstigator& Instigator); // Function EmbarkFire.EmbarkFireFunctionLibrary.SetHeat_Server // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5b51cd0
	void RegisterOnStateChangedCallbackForComponent_Client(struct UObject* WorldContextObject, struct USceneComponent* Component, struct FDelegate Callback); // Function EmbarkFire.EmbarkFireFunctionLibrary.RegisterOnStateChangedCallbackForComponent_Client // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b5c6e0
	struct FEmbarkFireObjectHandle RegisterObject_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectStateInitData& InitData); // Function EmbarkFire.EmbarkFireFunctionLibrary.RegisterObject_Server // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5b4f610
	bool IsHandleValid(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle); // Function EmbarkFire.EmbarkFireFunctionLibrary.IsHandleValid // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b59d90
	struct UEmbarkFireSubsystem* GetEmbarkFireSubsystem_Server(struct UObject* WorldContextObject); // Function EmbarkFire.EmbarkFireFunctionLibrary.GetEmbarkFireSubsystem_Server // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5b51550
	struct UEmbarkFireClientSubsystem* GetEmbarkFireSubsystem_Client(struct UObject* WorldContextObject); // Function EmbarkFire.EmbarkFireFunctionLibrary.GetEmbarkFireSubsystem_Client // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x5b466f0
	void EnableHandle_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle); // Function EmbarkFire.EmbarkFireFunctionLibrary.EnableHandle_Server // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b447f0
	void DisableHandle_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle); // Function EmbarkFire.EmbarkFireFunctionLibrary.DisableHandle_Server // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b54ba0
	void ClearAllHeat_Server(struct UObject* WorldContextObject); // Function EmbarkFire.EmbarkFireFunctionLibrary.ClearAllHeat_Server // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x5b527e0
	void AddHeatTransferAreaAtLocation(struct UObject* WorldContextObject, struct FVector& Location, struct FEmbarkFireHeatTransferAreaSettings& Settings); // Function EmbarkFire.EmbarkFireFunctionLibrary.AddHeatTransferAreaAtLocation // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x5b5bcf0
	void AddHeat_Server(struct UObject* WorldContextObject, struct FEmbarkFireObjectHandle Handle, float HeatToAdd, struct FInstigator& Instigator); // Function EmbarkFire.EmbarkFireFunctionLibrary.AddHeat_Server // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x5b45140
};

// Class EmbarkFire.EmbarkFireObjectGraphGroup_BurnableEnvironment
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkFireObjectGraphGroup_BurnableEnvironment : UActorComponent {
};

// Class EmbarkFire.EmbarkFireObjectGraphGroup_BurnableGameplayObjects
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkFireObjectGraphGroup_BurnableGameplayObjects : UActorComponent {
};

// Class EmbarkFire.EmbarkFireObjectGraphGroup_BurnablePlayer
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkFireObjectGraphGroup_BurnablePlayer : UActorComponent {
};

// Class EmbarkFire.EmbarkFireObjectGraphGroup_HeatModifier
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkFireObjectGraphGroup_HeatModifier : UActorComponent {
};

// Class EmbarkFire.EmbarkFireObjectGraphGroup_ActiveFire
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkFireObjectGraphGroup_ActiveFire : UActorComponent {
};

// Class EmbarkFire.EmbarkFireObjectGraphGroup_HeatTransferArea
// Size: 0x160 (Inherited: 0x160)
struct UEmbarkFireObjectGraphGroup_HeatTransferArea : UActorComponent {
};

// Class EmbarkFire.EmbarkFireObjectGraph
// Size: 0x230 (Inherited: 0xa0)
struct UEmbarkFireObjectGraph : UObject {
	char pad_a0[0x168]; // 0xa0(0x168)
	struct UEmbarkFireSubsystem* FireSubsystem; // 0x208(0x08)
	struct UEmbarkFireObjectStorage* ObjectStorage; // 0x210(0x08)
	struct UEmbarkDistanceQueryManager* DQM; // 0x218(0x08)
	char pad_220[0x10]; // 0x220(0x10)

	void OnDistanceQueryManagerData(struct FEmbarkDistanceQueryInfo Info, bool bOverlapping); // Function EmbarkFire.EmbarkFireObjectGraph.OnDistanceQueryManagerData // (Final|Native|Private) // @ game+0x5b44e80
};

// Class EmbarkFire.EmbarkFireObjectStorage
// Size: 0x360 (Inherited: 0xa0)
struct UEmbarkFireObjectStorage : UObject {
	struct UEmbarkFireSubsystem* FireSubsystem; // 0x98(0x08)
	char pad_a8[0x2b8]; // 0xa8(0x2b8)
};

// Class EmbarkFire.EmbarkFireReplicationActor
// Size: 0x620 (Inherited: 0x3a0)
struct AEmbarkFireReplicationActor : AActor {
	struct FReplicatedEmbarkFireStateFastArray FireStateFastArray; // 0x398(0x178)
	char pad_518[0xe8]; // 0x518(0xe8)
	struct UEmbarkFireSubsystem* FireSubsystem; // 0x600(0x08)
	struct UEmbarkFireClientSubsystem* ClientFireSubsystem; // 0x608(0x08)
	struct UEmbarkFireObjectStorage* ObjectStorage; // 0x610(0x08)
	struct UEmbarkFireEffectsDataAsset* FireEffectsDataAsset; // 0x618(0x08)
};

// Class EmbarkFire.EmbarkFireEffectsDataAsset
// Size: 0x1f0 (Inherited: 0xa0)
struct UEmbarkFireEffectsDataAsset : UDataAsset {
	int32_t FXGridSize; // 0xa0(0x04)
	struct FName ActiveFireCountParameterName; // 0xa4(0x08)
	struct FName ActiveFiresParameterName; // 0xac(0x08)
	struct FName LocationsParameterName; // 0xb4(0x08)
	struct FName BoundsParameterName; // 0xbc(0x08)
	struct FName IntensityParameterName; // 0xc4(0x08)
	float FadeOutTime; // 0xcc(0x04)
	struct FEmbarkFireSurfaceEffectSettings DefaultSurfaceEffectSettings; // 0xd0(0xc8)
	struct TMap<enum class EPhysicalSurface, struct FEmbarkFireSurfaceEffectSettings> PhysicalSurfaceEffectSettings; // 0x198(0x50)
	char pad_1e8[0x8]; // 0x1e8(0x08)
};

// Class EmbarkFire.EmbarkFireSettings
// Size: 0xf0 (Inherited: 0xb0)
struct UEmbarkFireSettings : UDeveloperSettings {
	float HeatTransferRate; // 0xa8(0x04)
	struct TSoftObjectPtr<UEmbarkFireEffectsDataAsset> FireEffectsDataAsset; // 0xb0(0x28)
	int32_t MaximumNumberOfIgnitedFires; // 0xd8(0x04)
	int32_t FiresToSimulatePerFrame; // 0xdc(0x04)
	int32_t FireEffectsToUpdatePerFrame; // 0xe0(0x04)
	float DebugDrawDistanceFromCamera; // 0xe4(0x04)
	float DebugDrawAngleFromCamera; // 0xe8(0x04)
};

// Class EmbarkFire.EmbarkFireSimulationManager
// Size: 0xc0 (Inherited: 0xa0)
struct UEmbarkFireSimulationManager : UObject {
	struct UEmbarkFireSubsystem* FireSubsystem; // 0x98(0x08)
	struct UEmbarkFireObjectStorage* ObjectStorage; // 0xa0(0x08)
	struct UEmbarkFireObjectGraph* ObjectGraph; // 0xa8(0x08)
	struct UEmbarkFireSettings* EmbarkFireSettings; // 0xb0(0x08)
};

// Class EmbarkFire.EmbarkFireClientSubsystem
// Size: 0x110 (Inherited: 0xa0)
struct UEmbarkFireClientSubsystem : UWorldSubsystem {
	char pad_a0[0x68]; // 0xa0(0x68)
	struct UEmbarkFireClientSubsystem* FireClientSubsystem; // 0x108(0x08)
};

// Class EmbarkFire.EmbarkFireSubsystem
// Size: 0x1c0 (Inherited: 0xa0)
struct UEmbarkFireSubsystem : UWorldSubsystem {
	struct UEmbarkFireObjectStorage* ObjectStorage; // 0xa0(0x08)
	struct UEmbarkFireObjectGraph* ObjectGraph; // 0xa8(0x08)
	struct UEmbarkFireSimulationManager* SimulationManager; // 0xb0(0x08)
	struct UEmbarkFireDebugManager* DebugManager; // 0xb8(0x08)
	struct AEmbarkFireReplicationActor* ReplicationActor; // 0xc0(0x08)
	char pad_c8[0xf8]; // 0xc8(0xf8)
};

