// Class AnimationBudgetAllocator.AnimationBudgetAllocatorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UAnimationBudgetAllocatorFactory : UObject {
};

// Class AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {

	void UnregisterComponentForSignificanceCalculation(struct UObject* WorldContextObject, struct USkeletalMeshComponentBudgeted* InComponent); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.UnregisterComponentForSignificanceCalculation // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a09340
	void UnregisterComponent(struct UObject* WorldContextObject, struct USkeletalMeshComponentBudgeted* InComponent); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.UnregisterComponent // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a14b60
	void SetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.SetParameters // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5a15140
	void SetComponentSignificance(struct UObject* WorldContextObject, struct USkeletalMeshComponentBudgeted* Component, float Significance, bool bNeverSkip, bool bTickEvenIfNotRendered, bool bAllowReducedWork, bool bForceInterpolate); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.SetComponentSignificance // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a12a50
	void RegisterComponentForSignificanceCalculation(struct UObject* WorldContextObject, struct USkeletalMeshComponentBudgeted* InComponent); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.RegisterComponentForSignificanceCalculation // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a154f0
	void RegisterComponent(struct UObject* WorldContextObject, struct USkeletalMeshComponentBudgeted* InComponent); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.RegisterComponent // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a13000
	struct USkeletalMeshComponentBudgeted* RecalculatePrerequisite(struct UObject* WorldContextObject, struct USkeletalMeshComponentBudgeted* ForComp); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.RecalculatePrerequisite // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a09bf0
	struct TArray<struct FEmbarkAnimBudgetAllocatorComponentData> GetAllRegisteredComponents(struct UObject* WorldContextObject); // Function AnimationBudgetAllocator.EmbarkAnimationBudgetBlueprintLibrary.GetAllRegisteredComponents // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a0a450
};

// Class AnimationBudgetAllocator.EmbarkAnimationBudgetAllocatorFactory
// Size: 0xa0 (Inherited: 0xa0)
struct UEmbarkAnimationBudgetAllocatorFactory : UAnimationBudgetAllocatorFactory {
};

// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0xa0 (Inherited: 0xa0)
struct UAnimationBudgetBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters // (Final|Native|Static|Private|HasOutParms|BlueprintCallable) // @ game+0x5a0b3c0
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget // (Final|Native|Static|Private|BlueprintCallable) // @ game+0x5a157d0
};

// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0x10e0 (Inherited: 0x10b0)
struct USkeletalMeshComponentBudgeted : USkeletalMeshComponent {
	char pad_10b0[0x20]; // 0x10b0(0x20)
	char bAutoRegisterWithBudgetAllocator : 1; // 0x10d0(0x01)
	char bAutoCalculateSignificance : 1; // 0x10d0(0x01)
	char bShouldUseActorRenderedFlag : 1; // 0x10d0(0x01)
	char pad_10d0_3 : 5; // 0x10d0(0x01)
	char pad_10d1[0xf]; // 0x10d1(0x0f)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator // (Final|Native|Public|BlueprintCallable) // @ game+0x5a152f0
};

